//line a2g_classes.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_core_reducers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_A_New()}; return nil }

var A_arbace_core_reducers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_A_new}

var A_arbace_core_reducers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_A"})

func init() { i := A_arbace_core_reducers_A_class.Info(); i.IsInstance = A_arbace_core_reducers_A_InstanceOf; i.Init = A_arbace_core_reducers_A_Init; i.Table = A_arbace_core_reducers_A_members; jrt.RegisterGoType(A_arbace_core_reducers_A_class, reflect.TypeFor[A_arbace_core_reducers_A]()) }

func A_arbace_core_reducers_append_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_append_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_append_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_append_BANG__A_New()}; return nil }

func A_arbace_core_reducers_append_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_append_BANG__A_fn_class)}; return nil }

var A_arbace_core_reducers_append_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_append_BANG__A_invoke, New: A_arbace_core_reducers_append_BANG__A_new, Get: A_arbace_core_reducers_append_BANG__A_get}

var A_arbace_core_reducers_append_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$append_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "append_BANG_", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_append_BANG__A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_append_BANG__A_class.Info(); i.IsInstance = A_arbace_core_reducers_append_BANG__A_InstanceOf; i.Init = A_arbace_core_reducers_append_BANG__A_Init; i.Table = A_arbace_core_reducers_append_BANG__A_members; jrt.RegisterGoType(A_arbace_core_reducers_append_BANG__A_class, reflect.TypeFor[A_arbace_core_reducers_append_BANG__A]()) }

func A_arbace_core_reducers_cat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_cat_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_cat_A).Invoke_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_core_reducers_cat_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_cat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_cat_A_New()}; return nil }

func A_arbace_core_reducers_cat_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_cat_A_fn_class)}; return nil }

var A_arbace_core_reducers_cat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_cat_A_invoke, New: A_arbace_core_reducers_cat_A_new, Get: A_arbace_core_reducers_cat_A_get}

var A_arbace_core_reducers_cat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$cat", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "cat", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_cat_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_cat_A_class.Info(); i.IsInstance = A_arbace_core_reducers_cat_A_InstanceOf; i.Init = A_arbace_core_reducers_cat_A_Init; i.Table = A_arbace_core_reducers_cat_A_members; jrt.RegisterGoType(A_arbace_core_reducers_cat_A_class, reflect.TypeFor[A_arbace_core_reducers_cat_A]()) }

func A_arbace_core_reducers_cat_fn__153000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_cat_fn__153000141_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_cat_fn__153000141_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_cat_fn__153000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_cat_fn__153000141_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_cat_fn__153000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_cat_fn__153000141_A_fn_class)}; return nil }

var A_arbace_core_reducers_cat_fn__153000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_cat_fn__153000141_A_invoke, New: A_arbace_core_reducers_cat_fn__153000141_A_new, Get: A_arbace_core_reducers_cat_fn__153000141_A_get}

var A_arbace_core_reducers_cat_fn__153000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$cat$fn__153000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_cat_A_class, Simple: "fn__153000141", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_cat_fn__153000141_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_cat_fn__153000141_A_class.Info(); i.IsInstance = A_arbace_core_reducers_cat_fn__153000141_A_InstanceOf; i.Init = A_arbace_core_reducers_cat_fn__153000141_A_Init; i.Table = A_arbace_core_reducers_cat_fn__153000141_A_members; jrt.RegisterGoType(A_arbace_core_reducers_cat_fn__153000141_A_class, reflect.TypeFor[A_arbace_core_reducers_cat_fn__153000141_A]()) }

func A_arbace_core_reducers_defcurried_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_defcurried_A).DoInvoke_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_core_reducers_defcurried_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_defcurried_A_New()}; return nil }

func A_arbace_core_reducers_defcurried_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_defcurried_A_fn_class)}; return nil }

var A_arbace_core_reducers_defcurried_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_defcurried_A_invoke, New: A_arbace_core_reducers_defcurried_A_new, Get: A_arbace_core_reducers_defcurried_A_get}

var A_arbace_core_reducers_defcurried_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$defcurried", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR6_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "defcurried", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_defcurried_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_defcurried_A_class.Info(); i.IsInstance = A_arbace_core_reducers_defcurried_A_InstanceOf; i.Init = A_arbace_core_reducers_defcurried_A_Init; i.Table = A_arbace_core_reducers_defcurried_A_members; jrt.RegisterGoType(A_arbace_core_reducers_defcurried_A_class, reflect.TypeFor[A_arbace_core_reducers_defcurried_A]()) }

func A_arbace_core_reducers_do_curried_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_do_curried_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_core_reducers_do_curried_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_do_curried_A_New()}; return nil }

func A_arbace_core_reducers_do_curried_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_do_curried_A_fn_class)}; return nil }

var A_arbace_core_reducers_do_curried_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_do_curried_A_invoke, New: A_arbace_core_reducers_do_curried_A_new, Get: A_arbace_core_reducers_do_curried_A_get}

var A_arbace_core_reducers_do_curried_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$do_curried", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "do_curried", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_do_curried_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_do_curried_A_class.Info(); i.IsInstance = A_arbace_core_reducers_do_curried_A_InstanceOf; i.Init = A_arbace_core_reducers_do_curried_A_Init; i.Table = A_arbace_core_reducers_do_curried_A_members; jrt.RegisterGoType(A_arbace_core_reducers_do_curried_A_class, reflect.TypeFor[A_arbace_core_reducers_do_curried_A]()) }

func A_arbace_core_reducers_do_rfn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_do_rfn_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_do_rfn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_do_rfn_A_New()}; return nil }

func A_arbace_core_reducers_do_rfn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_do_rfn_A_fn_class)}; return nil }

var A_arbace_core_reducers_do_rfn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_do_rfn_A_invoke, New: A_arbace_core_reducers_do_rfn_A_new, Get: A_arbace_core_reducers_do_rfn_A_get}

var A_arbace_core_reducers_do_rfn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$do_rfn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "do_rfn", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_do_rfn_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_do_rfn_A_class.Info(); i.IsInstance = A_arbace_core_reducers_do_rfn_A_InstanceOf; i.Init = A_arbace_core_reducers_do_rfn_A_Init; i.Table = A_arbace_core_reducers_do_rfn_A_members; jrt.RegisterGoType(A_arbace_core_reducers_do_rfn_A_class, reflect.TypeFor[A_arbace_core_reducers_do_rfn_A]()) }

func A_arbace_core_reducers_do_rfn_fn__153000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_do_rfn_fn__153000066_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_do_rfn_fn__153000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_do_rfn_fn__153000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class)}; return nil }

var A_arbace_core_reducers_do_rfn_fn__153000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_do_rfn_fn__153000066_A_invoke, New: A_arbace_core_reducers_do_rfn_fn__153000066_A_new, Get: A_arbace_core_reducers_do_rfn_fn__153000066_A_get}

var A_arbace_core_reducers_do_rfn_fn__153000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$do_rfn$fn__153000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_do_rfn_A_class, Simple: "fn__153000066", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_do_rfn_fn__153000066_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_do_rfn_fn__153000066_A_class.Info(); i.IsInstance = A_arbace_core_reducers_do_rfn_fn__153000066_A_InstanceOf; i.Init = A_arbace_core_reducers_do_rfn_fn__153000066_A_Init; i.Table = A_arbace_core_reducers_do_rfn_fn__153000066_A_members; jrt.RegisterGoType(A_arbace_core_reducers_do_rfn_fn__153000066_A_class, reflect.TypeFor[A_arbace_core_reducers_do_rfn_fn__153000066_A]()) }

func A_arbace_core_reducers_drop_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_drop_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_core_reducers_drop_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_drop_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_drop_A_New()}; return nil }

func A_arbace_core_reducers_drop_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_drop_A_fn_class)}; return nil }

var A_arbace_core_reducers_drop_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_drop_A_invoke, New: A_arbace_core_reducers_drop_A_new, Get: A_arbace_core_reducers_drop_A_get}

var A_arbace_core_reducers_drop_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$drop", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "drop", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_drop_A_class.Info(); i.IsInstance = A_arbace_core_reducers_drop_A_InstanceOf; i.Init = A_arbace_core_reducers_drop_A_Init; i.Table = A_arbace_core_reducers_drop_A_members; jrt.RegisterGoType(A_arbace_core_reducers_drop_A_class, reflect.TypeFor[A_arbace_core_reducers_drop_A]()) }

func A_arbace_core_reducers_drop_fn__153000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_drop_fn__153000125_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_drop_fn__153000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_drop_fn__153000125_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_drop_fn__153000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_drop_fn__153000125_A_fn_class)}; return nil }

var A_arbace_core_reducers_drop_fn__153000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_drop_fn__153000125_A_invoke, New: A_arbace_core_reducers_drop_fn__153000125_A_new, Get: A_arbace_core_reducers_drop_fn__153000125_A_get}

var A_arbace_core_reducers_drop_fn__153000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$drop$fn__153000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_drop_A_class, Simple: "fn__153000125", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_fn__153000125_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_drop_fn__153000125_A_class.Info(); i.IsInstance = A_arbace_core_reducers_drop_fn__153000125_A_InstanceOf; i.Init = A_arbace_core_reducers_drop_fn__153000125_A_Init; i.Table = A_arbace_core_reducers_drop_fn__153000125_A_members; jrt.RegisterGoType(A_arbace_core_reducers_drop_fn__153000125_A_class, reflect.TypeFor[A_arbace_core_reducers_drop_fn__153000125_A]()) }

func A_arbace_core_reducers_drop_fn__153000127_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_drop_fn__153000127_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_drop_fn__153000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_drop_fn__153000127_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_drop_fn__153000127_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_drop_fn__153000127_A_fn_class)}; return nil }

var A_arbace_core_reducers_drop_fn__153000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_drop_fn__153000127_A_invoke, New: A_arbace_core_reducers_drop_fn__153000127_A_new, Get: A_arbace_core_reducers_drop_fn__153000127_A_get}

var A_arbace_core_reducers_drop_fn__153000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$drop$fn__153000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_drop_A_class, Simple: "fn__153000127", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_fn__153000127_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_drop_fn__153000127_A_class.Info(); i.IsInstance = A_arbace_core_reducers_drop_fn__153000127_A_InstanceOf; i.Init = A_arbace_core_reducers_drop_fn__153000127_A_Init; i.Table = A_arbace_core_reducers_drop_fn__153000127_A_members; jrt.RegisterGoType(A_arbace_core_reducers_drop_fn__153000127_A_class, reflect.TypeFor[A_arbace_core_reducers_drop_fn__153000127_A]()) }

func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class)}; return nil }

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_invoke, New: A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_new, Get: A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_get}

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$drop$fn__153000127$fn__153000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_drop_fn__153000127_A_class, Simple: "fn__153000128", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_class.Info(); i.IsInstance = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_InstanceOf; i.Init = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_Init; i.Table = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_members; jrt.RegisterGoType(A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_class, reflect.TypeFor[A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A]()) }

func A_arbace_core_reducers_eval153000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000004_A_New()}; return nil }

var A_arbace_core_reducers_eval153000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000004_A_new}

var A_arbace_core_reducers_eval153000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000004", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000004_A"})

func init() { i := A_arbace_core_reducers_eval153000004_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000004_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000004_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000004_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000004_A]()) }

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New()}; return nil }

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_invoke, New: A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_new, Get: A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_get}

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000004$loading__1927001464__auto____153000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_eval153000004_A_class, Simple: "loading__1927001464__auto____153000005", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_Init; i.Table = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A]()) }

func A_arbace_core_reducers_eval153000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000008_A_New()}; return nil }

var A_arbace_core_reducers_eval153000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000008_A_new}

var A_arbace_core_reducers_eval153000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000008", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000008_A"})

func init() { i := A_arbace_core_reducers_eval153000008_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000008_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000008_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000008_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000008_A]()) }

func A_arbace_core_reducers_eval153000008_fn__153000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000008_fn__153000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_reducers_eval153000008_fn__153000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000008_fn__153000009_A_New()}; return nil }

func A_arbace_core_reducers_eval153000008_fn__153000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000008_fn__153000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000008_fn__153000009_A_invoke, New: A_arbace_core_reducers_eval153000008_fn__153000009_A_new, Get: A_arbace_core_reducers_eval153000008_fn__153000009_A_get}

var A_arbace_core_reducers_eval153000008_fn__153000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000008$fn__153000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_eval153000008_A_class, Simple: "fn__153000009", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000008_fn__153000009_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000008_fn__153000009_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000008_fn__153000009_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000008_fn__153000009_A_Init; i.Table = A_arbace_core_reducers_eval153000008_fn__153000009_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000008_fn__153000009_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000008_fn__153000009_A]()) }

func A_arbace_core_reducers_eval153000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000031_A_New()}; return nil }

var A_arbace_core_reducers_eval153000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000031_A_new}

var A_arbace_core_reducers_eval153000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000031", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_A"})

func init() { i := A_arbace_core_reducers_eval153000031_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000031_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000031_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000031_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000031_A]()) }

func A_arbace_core_reducers_eval153000031_fn__153000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000031_fn__153000032_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_eval153000031_fn__153000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000031_fn__153000032_A_New()}; return nil }

func A_arbace_core_reducers_eval153000031_fn__153000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000031_fn__153000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000031_fn__153000032_A_invoke, New: A_arbace_core_reducers_eval153000031_fn__153000032_A_new, Get: A_arbace_core_reducers_eval153000031_fn__153000032_A_get}

var A_arbace_core_reducers_eval153000031_fn__153000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000031$fn__153000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_eval153000031_A_class, Simple: "fn__153000032", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_fn__153000032_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000031_fn__153000032_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000031_fn__153000032_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000031_fn__153000032_A_Init; i.Table = A_arbace_core_reducers_eval153000031_fn__153000032_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000031_fn__153000032_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000031_fn__153000032_A]()) }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_invoke, New: A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_new, Get: A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_get}

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000031$fn__153000032$G__153000023__153000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_eval153000031_fn__153000032_A_class, Simple: "G__153000023__153000043", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_Init; i.Table = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A]()) }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New()}; return nil }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_invoke, New: A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_new, Get: A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_get}

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000031$fn__153000032$G__153000024__153000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_eval153000031_fn__153000032_A_class, Simple: "G__153000024__153000037", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_Init; i.Table = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A]()) }

func A_arbace_core_reducers_eval153000132_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000132_A_New()}; return nil }

var A_arbace_core_reducers_eval153000132_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000132_A_new}

var A_arbace_core_reducers_eval153000132_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000132", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000132", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000132_A"})

func init() { i := A_arbace_core_reducers_eval153000132_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000132_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000132_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000132_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000132_A]()) }

func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New()}; return nil }

func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_invoke, New: A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_new, Get: A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_get}

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000132$__GT_Cat__153000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_reducers_eval153000132_A_class, Simple: "__GT_Cat__153000138", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_Init; i.Table = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A]()) }

func A_arbace_core_reducers_eval153000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000157_A_New()}; return nil }

var A_arbace_core_reducers_eval153000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000157_A_new}

var A_arbace_core_reducers_eval153000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000157", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000157_A"})

func init() { i := A_arbace_core_reducers_eval153000157_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000157_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000157_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000157_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000157_A]()) }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000157_fn__153000158_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000157_fn__153000158_A_New()}; return nil }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000157_fn__153000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000157_fn__153000158_A_invoke, New: A_arbace_core_reducers_eval153000157_fn__153000158_A_new, Get: A_arbace_core_reducers_eval153000157_fn__153000158_A_get}

var A_arbace_core_reducers_eval153000157_fn__153000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000157$fn__153000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_eval153000157_A_class, Simple: "fn__153000158", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000157_fn__153000158_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000157_fn__153000158_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000157_fn__153000158_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000157_fn__153000158_A_Init; i.Table = A_arbace_core_reducers_eval153000157_fn__153000158_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000157_fn__153000158_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000157_fn__153000158_A]()) }

func A_arbace_core_reducers_eval153000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000161_A_New()}; return nil }

var A_arbace_core_reducers_eval153000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000161_A_new}

var A_arbace_core_reducers_eval153000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000161", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000161_A"})

func init() { i := A_arbace_core_reducers_eval153000161_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000161_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000161_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000161_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000161_A]()) }

func A_arbace_core_reducers_eval153000161_fn__153000162_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000161_fn__153000162_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_eval153000161_fn__153000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000161_fn__153000162_A_New()}; return nil }

func A_arbace_core_reducers_eval153000161_fn__153000162_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000161_fn__153000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000161_fn__153000162_A_invoke, New: A_arbace_core_reducers_eval153000161_fn__153000162_A_new, Get: A_arbace_core_reducers_eval153000161_fn__153000162_A_get}

var A_arbace_core_reducers_eval153000161_fn__153000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000161$fn__153000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_eval153000161_A_class, Simple: "fn__153000162", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000161_fn__153000162_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000161_fn__153000162_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000161_fn__153000162_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000161_fn__153000162_A_Init; i.Table = A_arbace_core_reducers_eval153000161_fn__153000162_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000161_fn__153000162_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000161_fn__153000162_A]()) }

func A_arbace_core_reducers_eval153000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000165_A_New()}; return nil }

var A_arbace_core_reducers_eval153000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000165_A_new}

var A_arbace_core_reducers_eval153000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000165", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000165_A"})

func init() { i := A_arbace_core_reducers_eval153000165_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000165_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000165_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000165_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000165_A]()) }

func A_arbace_core_reducers_eval153000165_fn__153000166_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000165_fn__153000166_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_eval153000165_fn__153000166_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000165_fn__153000166_A_New()}; return nil }

func A_arbace_core_reducers_eval153000165_fn__153000166_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000165_fn__153000166_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000165_fn__153000166_A_invoke, New: A_arbace_core_reducers_eval153000165_fn__153000166_A_new, Get: A_arbace_core_reducers_eval153000165_fn__153000166_A_get}

var A_arbace_core_reducers_eval153000165_fn__153000166_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000165$fn__153000166", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_eval153000165_A_class, Simple: "fn__153000166", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000165_fn__153000166_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000165_fn__153000166_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000165_fn__153000166_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000165_fn__153000166_A_Init; i.Table = A_arbace_core_reducers_eval153000165_fn__153000166_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000165_fn__153000166_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000165_fn__153000166_A]()) }

func A_arbace_core_reducers_eval153000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000169_A_New()}; return nil }

var A_arbace_core_reducers_eval153000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000169_A_new}

var A_arbace_core_reducers_eval153000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000169", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000169_A"})

func init() { i := A_arbace_core_reducers_eval153000169_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000169_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000169_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000169_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000169_A]()) }

func A_arbace_core_reducers_eval153000169_fn__153000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_eval153000169_fn__153000170_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_eval153000169_fn__153000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000169_fn__153000170_A_New()}; return nil }

func A_arbace_core_reducers_eval153000169_fn__153000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class)}; return nil }

var A_arbace_core_reducers_eval153000169_fn__153000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_eval153000169_fn__153000170_A_invoke, New: A_arbace_core_reducers_eval153000169_fn__153000170_A_new, Get: A_arbace_core_reducers_eval153000169_fn__153000170_A_get}

var A_arbace_core_reducers_eval153000169_fn__153000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000169$fn__153000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_eval153000169_A_class, Simple: "fn__153000170", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000169_fn__153000170_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_eval153000169_fn__153000170_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000169_fn__153000170_A_InstanceOf; i.Init = A_arbace_core_reducers_eval153000169_fn__153000170_A_Init; i.Table = A_arbace_core_reducers_eval153000169_fn__153000170_A_members; jrt.RegisterGoType(A_arbace_core_reducers_eval153000169_fn__153000170_A_class, reflect.TypeFor[A_arbace_core_reducers_eval153000169_fn__153000170_A]()) }

func A_arbace_core_reducers_filter_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_filter_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_core_reducers_filter_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_filter_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_filter_A_New()}; return nil }

func A_arbace_core_reducers_filter_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_filter_A_fn_class)}; return nil }

var A_arbace_core_reducers_filter_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_filter_A_invoke, New: A_arbace_core_reducers_filter_A_new, Get: A_arbace_core_reducers_filter_A_get}

var A_arbace_core_reducers_filter_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$filter", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "filter", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_filter_A_class.Info(); i.IsInstance = A_arbace_core_reducers_filter_A_InstanceOf; i.Init = A_arbace_core_reducers_filter_A_Init; i.Table = A_arbace_core_reducers_filter_A_members; jrt.RegisterGoType(A_arbace_core_reducers_filter_A_class, reflect.TypeFor[A_arbace_core_reducers_filter_A]()) }

func A_arbace_core_reducers_filter_fn__153000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_filter_fn__153000094_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_filter_fn__153000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_filter_fn__153000094_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_filter_fn__153000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_filter_fn__153000094_A_fn_class)}; return nil }

var A_arbace_core_reducers_filter_fn__153000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_filter_fn__153000094_A_invoke, New: A_arbace_core_reducers_filter_fn__153000094_A_new, Get: A_arbace_core_reducers_filter_fn__153000094_A_get}

var A_arbace_core_reducers_filter_fn__153000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$filter$fn__153000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_filter_A_class, Simple: "fn__153000094", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_fn__153000094_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_filter_fn__153000094_A_class.Info(); i.IsInstance = A_arbace_core_reducers_filter_fn__153000094_A_InstanceOf; i.Init = A_arbace_core_reducers_filter_fn__153000094_A_Init; i.Table = A_arbace_core_reducers_filter_fn__153000094_A_members; jrt.RegisterGoType(A_arbace_core_reducers_filter_fn__153000094_A_class, reflect.TypeFor[A_arbace_core_reducers_filter_fn__153000094_A]()) }

func A_arbace_core_reducers_filter_fn__153000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_filter_fn__153000096_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_filter_fn__153000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_filter_fn__153000096_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_filter_fn__153000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_filter_fn__153000096_A_fn_class)}; return nil }

var A_arbace_core_reducers_filter_fn__153000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_filter_fn__153000096_A_invoke, New: A_arbace_core_reducers_filter_fn__153000096_A_new, Get: A_arbace_core_reducers_filter_fn__153000096_A_get}

var A_arbace_core_reducers_filter_fn__153000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$filter$fn__153000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_filter_A_class, Simple: "fn__153000096", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_fn__153000096_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_filter_fn__153000096_A_class.Info(); i.IsInstance = A_arbace_core_reducers_filter_fn__153000096_A_InstanceOf; i.Init = A_arbace_core_reducers_filter_fn__153000096_A_Init; i.Table = A_arbace_core_reducers_filter_fn__153000096_A_members; jrt.RegisterGoType(A_arbace_core_reducers_filter_fn__153000096_A_class, reflect.TypeFor[A_arbace_core_reducers_filter_fn__153000096_A]()) }

func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class)}; return nil }

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_invoke, New: A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_new, Get: A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_get}

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$filter$fn__153000096$fn__153000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_filter_fn__153000096_A_class, Simple: "fn__153000097", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_class.Info(); i.IsInstance = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_InstanceOf; i.Init = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_Init; i.Table = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_members; jrt.RegisterGoType(A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_class, reflect.TypeFor[A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A]()) }

func A_arbace_core_reducers_fjfork_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_fjfork_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_fjfork_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_fjfork_A_New()}; return nil }

func A_arbace_core_reducers_fjfork_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_fjfork_A_fn_class)}; return nil }

var A_arbace_core_reducers_fjfork_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_fjfork_A_invoke, New: A_arbace_core_reducers_fjfork_A_new, Get: A_arbace_core_reducers_fjfork_A_get}

var A_arbace_core_reducers_fjfork_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$fjfork", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "fjfork", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjfork_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_fjfork_A_class.Info(); i.IsInstance = A_arbace_core_reducers_fjfork_A_InstanceOf; i.Init = A_arbace_core_reducers_fjfork_A_Init; i.Table = A_arbace_core_reducers_fjfork_A_members; jrt.RegisterGoType(A_arbace_core_reducers_fjfork_A_class, reflect.TypeFor[A_arbace_core_reducers_fjfork_A]()) }

func A_arbace_core_reducers_fjinvoke_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_fjinvoke_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_fjinvoke_A_New()}; return nil }

func A_arbace_core_reducers_fjinvoke_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_fjinvoke_A_fn_class)}; return nil }

var A_arbace_core_reducers_fjinvoke_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_fjinvoke_A_invoke, New: A_arbace_core_reducers_fjinvoke_A_new, Get: A_arbace_core_reducers_fjinvoke_A_get}

var A_arbace_core_reducers_fjinvoke_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$fjinvoke", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "fjinvoke", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjinvoke_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_fjinvoke_A_class.Info(); i.IsInstance = A_arbace_core_reducers_fjinvoke_A_InstanceOf; i.Init = A_arbace_core_reducers_fjinvoke_A_Init; i.Table = A_arbace_core_reducers_fjinvoke_A_members; jrt.RegisterGoType(A_arbace_core_reducers_fjinvoke_A_class, reflect.TypeFor[A_arbace_core_reducers_fjinvoke_A]()) }

func A_arbace_core_reducers_fjjoin_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_fjjoin_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_fjjoin_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_fjjoin_A_New()}; return nil }

func A_arbace_core_reducers_fjjoin_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_fjjoin_A_fn_class)}; return nil }

var A_arbace_core_reducers_fjjoin_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_fjjoin_A_invoke, New: A_arbace_core_reducers_fjjoin_A_new, Get: A_arbace_core_reducers_fjjoin_A_get}

var A_arbace_core_reducers_fjjoin_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$fjjoin", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "fjjoin", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjjoin_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_fjjoin_A_class.Info(); i.IsInstance = A_arbace_core_reducers_fjjoin_A_InstanceOf; i.Init = A_arbace_core_reducers_fjjoin_A_Init; i.Table = A_arbace_core_reducers_fjjoin_A_members; jrt.RegisterGoType(A_arbace_core_reducers_fjjoin_A_class, reflect.TypeFor[A_arbace_core_reducers_fjjoin_A]()) }

func A_arbace_core_reducers_fjtask_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_fjtask_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_fjtask_A_New()}; return nil }

func A_arbace_core_reducers_fjtask_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_fjtask_A_fn_class)}; return nil }

var A_arbace_core_reducers_fjtask_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_fjtask_A_invoke, New: A_arbace_core_reducers_fjtask_A_new, Get: A_arbace_core_reducers_fjtask_A_get}

var A_arbace_core_reducers_fjtask_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$fjtask", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "fjtask", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjtask_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_fjtask_A_class.Info(); i.IsInstance = A_arbace_core_reducers_fjtask_A_InstanceOf; i.Init = A_arbace_core_reducers_fjtask_A_Init; i.Table = A_arbace_core_reducers_fjtask_A_members; jrt.RegisterGoType(A_arbace_core_reducers_fjtask_A_class, reflect.TypeFor[A_arbace_core_reducers_fjtask_A]()) }

func A_arbace_core_reducers_flatten_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_flatten_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_flatten_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_flatten_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_flatten_A_New()}; return nil }

func A_arbace_core_reducers_flatten_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_flatten_A_fn_class)}; return nil }

var A_arbace_core_reducers_flatten_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_flatten_A_invoke, New: A_arbace_core_reducers_flatten_A_new, Get: A_arbace_core_reducers_flatten_A_get}

var A_arbace_core_reducers_flatten_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$flatten", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "flatten", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_flatten_A_class.Info(); i.IsInstance = A_arbace_core_reducers_flatten_A_InstanceOf; i.Init = A_arbace_core_reducers_flatten_A_Init; i.Table = A_arbace_core_reducers_flatten_A_members; jrt.RegisterGoType(A_arbace_core_reducers_flatten_A_class, reflect.TypeFor[A_arbace_core_reducers_flatten_A]()) }

func A_arbace_core_reducers_flatten_fn__153000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_flatten_fn__153000104_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_flatten_fn__153000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_flatten_fn__153000104_A_New()}; return nil }

func A_arbace_core_reducers_flatten_fn__153000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_flatten_fn__153000104_A_fn_class)}; return nil }

var A_arbace_core_reducers_flatten_fn__153000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_flatten_fn__153000104_A_invoke, New: A_arbace_core_reducers_flatten_fn__153000104_A_new, Get: A_arbace_core_reducers_flatten_fn__153000104_A_get}

var A_arbace_core_reducers_flatten_fn__153000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$flatten$fn__153000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_flatten_A_class, Simple: "fn__153000104", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_fn__153000104_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_flatten_fn__153000104_A_class.Info(); i.IsInstance = A_arbace_core_reducers_flatten_fn__153000104_A_InstanceOf; i.Init = A_arbace_core_reducers_flatten_fn__153000104_A_Init; i.Table = A_arbace_core_reducers_flatten_fn__153000104_A_members; jrt.RegisterGoType(A_arbace_core_reducers_flatten_fn__153000104_A_class, reflect.TypeFor[A_arbace_core_reducers_flatten_fn__153000104_A]()) }

func A_arbace_core_reducers_flatten_fn__153000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_flatten_fn__153000106_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_flatten_fn__153000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_flatten_fn__153000106_A_New()}; return nil }

func A_arbace_core_reducers_flatten_fn__153000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_flatten_fn__153000106_A_fn_class)}; return nil }

var A_arbace_core_reducers_flatten_fn__153000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_flatten_fn__153000106_A_invoke, New: A_arbace_core_reducers_flatten_fn__153000106_A_new, Get: A_arbace_core_reducers_flatten_fn__153000106_A_get}

var A_arbace_core_reducers_flatten_fn__153000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$flatten$fn__153000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_flatten_A_class, Simple: "fn__153000106", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_fn__153000106_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_flatten_fn__153000106_A_class.Info(); i.IsInstance = A_arbace_core_reducers_flatten_fn__153000106_A_InstanceOf; i.Init = A_arbace_core_reducers_flatten_fn__153000106_A_Init; i.Table = A_arbace_core_reducers_flatten_fn__153000106_A_members; jrt.RegisterGoType(A_arbace_core_reducers_flatten_fn__153000106_A_class, reflect.TypeFor[A_arbace_core_reducers_flatten_fn__153000106_A]()) }

func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class)}; return nil }

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_invoke, New: A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_new, Get: A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_get}

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$flatten$fn__153000106$fn__153000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_flatten_fn__153000106_A_class, Simple: "fn__153000107", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_class.Info(); i.IsInstance = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_InstanceOf; i.Init = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_Init; i.Table = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_members; jrt.RegisterGoType(A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_class, reflect.TypeFor[A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A]()) }

func A_arbace_core_reducers_fn__153000016_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_fn__153000016_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_reducers_fn__153000016_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_fn__153000016_A_New()}; return nil }

func A_arbace_core_reducers_fn__153000016_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_fn__153000016_A_fn_class)}; return nil }

var A_arbace_core_reducers_fn__153000016_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_fn__153000016_A_invoke, New: A_arbace_core_reducers_fn__153000016_A_new, Get: A_arbace_core_reducers_fn__153000016_A_get}

var A_arbace_core_reducers_fn__153000016_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$fn__153000016", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "fn__153000016", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fn__153000016_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_fn__153000016_A_class.Info(); i.IsInstance = A_arbace_core_reducers_fn__153000016_A_InstanceOf; i.Init = A_arbace_core_reducers_fn__153000016_A_Init; i.Table = A_arbace_core_reducers_fn__153000016_A_members; jrt.RegisterGoType(A_arbace_core_reducers_fn__153000016_A_class, reflect.TypeFor[A_arbace_core_reducers_fn__153000016_A]()) }

func A_arbace_core_reducers_fold_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 2: return this.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_fold_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_fold_A_New()}; return nil }

func A_arbace_core_reducers_fold_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_fold_A_fn_class)}; return nil }

var A_arbace_core_reducers_fold_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_fold_A_invoke, New: A_arbace_core_reducers_fold_A_new, Get: A_arbace_core_reducers_fold_A_get}

var A_arbace_core_reducers_fold_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$fold", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "fold", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fold_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_fold_A_class.Info(); i.IsInstance = A_arbace_core_reducers_fold_A_InstanceOf; i.Init = A_arbace_core_reducers_fold_A_Init; i.Table = A_arbace_core_reducers_fold_A_members; jrt.RegisterGoType(A_arbace_core_reducers_fold_A_class, reflect.TypeFor[A_arbace_core_reducers_fold_A]()) }

func A_arbace_core_reducers_foldcat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_foldcat_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_foldcat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_foldcat_A_New()}; return nil }

func A_arbace_core_reducers_foldcat_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_foldcat_A_fn_class)}; return nil }

var A_arbace_core_reducers_foldcat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_foldcat_A_invoke, New: A_arbace_core_reducers_foldcat_A_new, Get: A_arbace_core_reducers_foldcat_A_get}

var A_arbace_core_reducers_foldcat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$foldcat", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "foldcat", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldcat_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_foldcat_A_class.Info(); i.IsInstance = A_arbace_core_reducers_foldcat_A_InstanceOf; i.Init = A_arbace_core_reducers_foldcat_A_Init; i.Table = A_arbace_core_reducers_foldcat_A_members; jrt.RegisterGoType(A_arbace_core_reducers_foldcat_A_class, reflect.TypeFor[A_arbace_core_reducers_foldcat_A]()) }

func A_arbace_core_reducers_folder_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_folder_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_folder_A_New()}; return nil }

func A_arbace_core_reducers_folder_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_folder_A_fn_class)}; return nil }

var A_arbace_core_reducers_folder_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_folder_A_invoke, New: A_arbace_core_reducers_folder_A_new, Get: A_arbace_core_reducers_folder_A_get}

var A_arbace_core_reducers_folder_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$folder", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "folder", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_folder_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_folder_A_class.Info(); i.IsInstance = A_arbace_core_reducers_folder_A_InstanceOf; i.Init = A_arbace_core_reducers_folder_A_Init; i.Table = A_arbace_core_reducers_folder_A_members; jrt.RegisterGoType(A_arbace_core_reducers_folder_A_class, reflect.TypeFor[A_arbace_core_reducers_folder_A]()) }

func A_arbace_core_reducers_folder_reify__153000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Coll_fold_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Coll_reduce_O__O(args[0]); case 2: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Coll_reduce_O_O__O(args[0], args[1]); case 3: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Meta__IPersistentMap(); case 4: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_core_reducers_folder_reify__153000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2])}; return nil }

var A_arbace_core_reducers_folder_reify__153000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 coll_fold (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_core_reducers_folder_reify__153000055_A_invoke, New: A_arbace_core_reducers_folder_reify__153000055_A_new}

var A_arbace_core_reducers_folder_reify__153000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$folder$reify__153000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_class, A_arbace_core_reducers_CollFold_A_class, lang.IObj_class}, Declaring: A_arbace_core_reducers_folder_A_class, Simple: "reify__153000055", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_folder_reify__153000055_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_folder_reify__153000055_A_class.Info(); i.IsInstance = A_arbace_core_reducers_folder_reify__153000055_A_InstanceOf; i.Table = A_arbace_core_reducers_folder_reify__153000055_A_members; jrt.RegisterGoType(A_arbace_core_reducers_folder_reify__153000055_A_class, reflect.TypeFor[A_arbace_core_reducers_folder_reify__153000055_A]()) }

func A_arbace_core_reducers_foldvec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_foldvec_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_foldvec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_foldvec_A_New()}; return nil }

func A_arbace_core_reducers_foldvec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_foldvec_A_fn_class)}; return nil }

var A_arbace_core_reducers_foldvec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_foldvec_A_invoke, New: A_arbace_core_reducers_foldvec_A_new, Get: A_arbace_core_reducers_foldvec_A_get}

var A_arbace_core_reducers_foldvec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$foldvec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "foldvec", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_foldvec_A_class.Info(); i.IsInstance = A_arbace_core_reducers_foldvec_A_InstanceOf; i.Init = A_arbace_core_reducers_foldvec_A_Init; i.Table = A_arbace_core_reducers_foldvec_A_members; jrt.RegisterGoType(A_arbace_core_reducers_foldvec_A_class, reflect.TypeFor[A_arbace_core_reducers_foldvec_A]()) }

func A_arbace_core_reducers_foldvec_fc__153000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_foldvec_fc__153000150_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_foldvec_fc__153000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_foldvec_fc__153000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class)}; return nil }

var A_arbace_core_reducers_foldvec_fc__153000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_foldvec_fc__153000150_A_invoke, New: A_arbace_core_reducers_foldvec_fc__153000150_A_new, Get: A_arbace_core_reducers_foldvec_fc__153000150_A_get}

var A_arbace_core_reducers_foldvec_fc__153000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$foldvec$fc__153000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_foldvec_A_class, Simple: "fc__153000150", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_fc__153000150_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_foldvec_fc__153000150_A_class.Info(); i.IsInstance = A_arbace_core_reducers_foldvec_fc__153000150_A_InstanceOf; i.Init = A_arbace_core_reducers_foldvec_fc__153000150_A_Init; i.Table = A_arbace_core_reducers_foldvec_fc__153000150_A_members; jrt.RegisterGoType(A_arbace_core_reducers_foldvec_fc__153000150_A_class, reflect.TypeFor[A_arbace_core_reducers_foldvec_fc__153000150_A]()) }

func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class)}; return nil }

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_invoke, New: A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_new, Get: A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_get}

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$foldvec$fc__153000150$fn__153000151", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_foldvec_fc__153000150_A_class, Simple: "fn__153000151", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_class.Info(); i.IsInstance = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_InstanceOf; i.Init = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_Init; i.Table = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_members; jrt.RegisterGoType(A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_class, reflect.TypeFor[A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A]()) }

func A_arbace_core_reducers_foldvec_fn__153000154_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_foldvec_fn__153000154_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_reducers_foldvec_fn__153000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_foldvec_fn__153000154_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class)}; return nil }

var A_arbace_core_reducers_foldvec_fn__153000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_foldvec_fn__153000154_A_invoke, New: A_arbace_core_reducers_foldvec_fn__153000154_A_new, Get: A_arbace_core_reducers_foldvec_fn__153000154_A_get}

var A_arbace_core_reducers_foldvec_fn__153000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$foldvec$fn__153000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_foldvec_A_class, Simple: "fn__153000154", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_fn__153000154_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_foldvec_fn__153000154_A_class.Info(); i.IsInstance = A_arbace_core_reducers_foldvec_fn__153000154_A_InstanceOf; i.Init = A_arbace_core_reducers_foldvec_fn__153000154_A_Init; i.Table = A_arbace_core_reducers_foldvec_fn__153000154_A_members; jrt.RegisterGoType(A_arbace_core_reducers_foldvec_fn__153000154_A_class, reflect.TypeFor[A_arbace_core_reducers_foldvec_fn__153000154_A]()) }

func A_arbace_core_reducers_map_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_map_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_core_reducers_map_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_map_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_map_A_New()}; return nil }

func A_arbace_core_reducers_map_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_map_A_fn_class)}; return nil }

var A_arbace_core_reducers_map_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_map_A_invoke, New: A_arbace_core_reducers_map_A_new, Get: A_arbace_core_reducers_map_A_get}

var A_arbace_core_reducers_map_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$map", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "map", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_map_A_class.Info(); i.IsInstance = A_arbace_core_reducers_map_A_InstanceOf; i.Init = A_arbace_core_reducers_map_A_Init; i.Table = A_arbace_core_reducers_map_A_members; jrt.RegisterGoType(A_arbace_core_reducers_map_A_class, reflect.TypeFor[A_arbace_core_reducers_map_A]()) }

func A_arbace_core_reducers_map_fn__153000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_map_fn__153000078_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_map_fn__153000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_map_fn__153000078_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_map_fn__153000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_map_fn__153000078_A_fn_class)}; return nil }

var A_arbace_core_reducers_map_fn__153000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_map_fn__153000078_A_invoke, New: A_arbace_core_reducers_map_fn__153000078_A_new, Get: A_arbace_core_reducers_map_fn__153000078_A_get}

var A_arbace_core_reducers_map_fn__153000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$map$fn__153000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_map_A_class, Simple: "fn__153000078", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_fn__153000078_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_map_fn__153000078_A_class.Info(); i.IsInstance = A_arbace_core_reducers_map_fn__153000078_A_InstanceOf; i.Init = A_arbace_core_reducers_map_fn__153000078_A_Init; i.Table = A_arbace_core_reducers_map_fn__153000078_A_members; jrt.RegisterGoType(A_arbace_core_reducers_map_fn__153000078_A_class, reflect.TypeFor[A_arbace_core_reducers_map_fn__153000078_A]()) }

func A_arbace_core_reducers_map_fn__153000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_map_fn__153000080_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_map_fn__153000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_map_fn__153000080_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_map_fn__153000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_map_fn__153000080_A_fn_class)}; return nil }

var A_arbace_core_reducers_map_fn__153000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_map_fn__153000080_A_invoke, New: A_arbace_core_reducers_map_fn__153000080_A_new, Get: A_arbace_core_reducers_map_fn__153000080_A_get}

var A_arbace_core_reducers_map_fn__153000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$map$fn__153000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_map_A_class, Simple: "fn__153000080", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_fn__153000080_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_map_fn__153000080_A_class.Info(); i.IsInstance = A_arbace_core_reducers_map_fn__153000080_A_InstanceOf; i.Init = A_arbace_core_reducers_map_fn__153000080_A_Init; i.Table = A_arbace_core_reducers_map_fn__153000080_A_members; jrt.RegisterGoType(A_arbace_core_reducers_map_fn__153000080_A_class, reflect.TypeFor[A_arbace_core_reducers_map_fn__153000080_A]()) }

func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_map_fn__153000080_fn__153000081_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_map_fn__153000080_fn__153000081_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_core_reducers_map_fn__153000080_fn__153000081_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class)}; return nil }

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_invoke, New: A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_new, Get: A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_get}

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$map$fn__153000080$fn__153000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_map_fn__153000080_A_class, Simple: "fn__153000081", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_fn__153000080_fn__153000081_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_class.Info(); i.IsInstance = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_InstanceOf; i.Init = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_Init; i.Table = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_members; jrt.RegisterGoType(A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_class, reflect.TypeFor[A_arbace_core_reducers_map_fn__153000080_fn__153000081_A]()) }

func A_arbace_core_reducers_mapcat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_mapcat_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_core_reducers_mapcat_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_mapcat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_mapcat_A_New()}; return nil }

func A_arbace_core_reducers_mapcat_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_mapcat_A_fn_class)}; return nil }

var A_arbace_core_reducers_mapcat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_mapcat_A_invoke, New: A_arbace_core_reducers_mapcat_A_new, Get: A_arbace_core_reducers_mapcat_A_get}

var A_arbace_core_reducers_mapcat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$mapcat", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "mapcat", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_mapcat_A_class.Info(); i.IsInstance = A_arbace_core_reducers_mapcat_A_InstanceOf; i.Init = A_arbace_core_reducers_mapcat_A_Init; i.Table = A_arbace_core_reducers_mapcat_A_members; jrt.RegisterGoType(A_arbace_core_reducers_mapcat_A_class, reflect.TypeFor[A_arbace_core_reducers_mapcat_A]()) }

func A_arbace_core_reducers_mapcat_fn__153000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_mapcat_fn__153000085_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class)}; return nil }

var A_arbace_core_reducers_mapcat_fn__153000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_mapcat_fn__153000085_A_invoke, New: A_arbace_core_reducers_mapcat_fn__153000085_A_new, Get: A_arbace_core_reducers_mapcat_fn__153000085_A_get}

var A_arbace_core_reducers_mapcat_fn__153000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$mapcat$fn__153000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_mapcat_A_class, Simple: "fn__153000085", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000085_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_mapcat_fn__153000085_A_class.Info(); i.IsInstance = A_arbace_core_reducers_mapcat_fn__153000085_A_InstanceOf; i.Init = A_arbace_core_reducers_mapcat_fn__153000085_A_Init; i.Table = A_arbace_core_reducers_mapcat_fn__153000085_A_members; jrt.RegisterGoType(A_arbace_core_reducers_mapcat_fn__153000085_A_class, reflect.TypeFor[A_arbace_core_reducers_mapcat_fn__153000085_A]()) }

func A_arbace_core_reducers_mapcat_fn__153000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_mapcat_fn__153000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class)}; return nil }

var A_arbace_core_reducers_mapcat_fn__153000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_mapcat_fn__153000087_A_invoke, New: A_arbace_core_reducers_mapcat_fn__153000087_A_new, Get: A_arbace_core_reducers_mapcat_fn__153000087_A_get}

var A_arbace_core_reducers_mapcat_fn__153000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$mapcat$fn__153000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_mapcat_A_class, Simple: "fn__153000087", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000087_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_mapcat_fn__153000087_A_class.Info(); i.IsInstance = A_arbace_core_reducers_mapcat_fn__153000087_A_InstanceOf; i.Init = A_arbace_core_reducers_mapcat_fn__153000087_A_Init; i.Table = A_arbace_core_reducers_mapcat_fn__153000087_A_members; jrt.RegisterGoType(A_arbace_core_reducers_mapcat_fn__153000087_A_class, reflect.TypeFor[A_arbace_core_reducers_mapcat_fn__153000087_A]()) }

func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class)}; return nil }

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_invoke, New: A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_new, Get: A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_get}

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$mapcat$fn__153000087$f1__153000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_reducers_mapcat_fn__153000087_A_class, Simple: "f1__153000088", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_class.Info(); i.IsInstance = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_InstanceOf; i.Init = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_Init; i.Table = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_members; jrt.RegisterGoType(A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_class, reflect.TypeFor[A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A]()) }

func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class)}; return nil }

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_invoke, New: A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_new, Get: A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_get}

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$mapcat$fn__153000087$fn__153000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_mapcat_fn__153000087_A_class, Simple: "fn__153000090", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_class.Info(); i.IsInstance = A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_InstanceOf; i.Init = A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_Init; i.Table = A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_members; jrt.RegisterGoType(A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_class, reflect.TypeFor[A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A]()) }

func A_arbace_core_reducers_monoid_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_monoid_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_monoid_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_monoid_A_New()}; return nil }

func A_arbace_core_reducers_monoid_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_monoid_A_fn_class)}; return nil }

var A_arbace_core_reducers_monoid_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_monoid_A_invoke, New: A_arbace_core_reducers_monoid_A_new, Get: A_arbace_core_reducers_monoid_A_get}

var A_arbace_core_reducers_monoid_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$monoid", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "monoid", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_monoid_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_monoid_A_class.Info(); i.IsInstance = A_arbace_core_reducers_monoid_A_InstanceOf; i.Init = A_arbace_core_reducers_monoid_A_Init; i.Table = A_arbace_core_reducers_monoid_A_members; jrt.RegisterGoType(A_arbace_core_reducers_monoid_A_class, reflect.TypeFor[A_arbace_core_reducers_monoid_A]()) }

func A_arbace_core_reducers_monoid_m__153000147_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_monoid_m__153000147_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_monoid_m__153000147_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_monoid_m__153000147_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_monoid_m__153000147_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_monoid_m__153000147_A_fn_class)}; return nil }

var A_arbace_core_reducers_monoid_m__153000147_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_monoid_m__153000147_A_invoke, New: A_arbace_core_reducers_monoid_m__153000147_A_new, Get: A_arbace_core_reducers_monoid_m__153000147_A_get}

var A_arbace_core_reducers_monoid_m__153000147_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$monoid$m__153000147", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_monoid_A_class, Simple: "m__153000147", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_monoid_m__153000147_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_monoid_m__153000147_A_class.Info(); i.IsInstance = A_arbace_core_reducers_monoid_m__153000147_A_InstanceOf; i.Init = A_arbace_core_reducers_monoid_m__153000147_A_Init; i.Table = A_arbace_core_reducers_monoid_m__153000147_A_members; jrt.RegisterGoType(A_arbace_core_reducers_monoid_m__153000147_A_class, reflect.TypeFor[A_arbace_core_reducers_monoid_m__153000147_A]()) }

func A_arbace_core_reducers_reduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_reduce_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_reduce_A_New()}; return nil }

func A_arbace_core_reducers_reduce_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_reduce_A_fn_class)}; return nil }

var A_arbace_core_reducers_reduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_reduce_A_invoke, New: A_arbace_core_reducers_reduce_A_new, Get: A_arbace_core_reducers_reduce_A_get}

var A_arbace_core_reducers_reduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$reduce", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "reduce", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_reduce_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_reduce_A_class.Info(); i.IsInstance = A_arbace_core_reducers_reduce_A_InstanceOf; i.Init = A_arbace_core_reducers_reduce_A_Init; i.Table = A_arbace_core_reducers_reduce_A_members; jrt.RegisterGoType(A_arbace_core_reducers_reduce_A_class, reflect.TypeFor[A_arbace_core_reducers_reduce_A]()) }

func A_arbace_core_reducers_reducer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_reducer_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_reducer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_reducer_A_New()}; return nil }

func A_arbace_core_reducers_reducer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_reducer_A_fn_class)}; return nil }

var A_arbace_core_reducers_reducer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_reducer_A_invoke, New: A_arbace_core_reducers_reducer_A_new, Get: A_arbace_core_reducers_reducer_A_get}

var A_arbace_core_reducers_reducer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$reducer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "reducer", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_reducer_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_reducer_A_class.Info(); i.IsInstance = A_arbace_core_reducers_reducer_A_InstanceOf; i.Init = A_arbace_core_reducers_reducer_A_Init; i.Table = A_arbace_core_reducers_reducer_A_members; jrt.RegisterGoType(A_arbace_core_reducers_reducer_A_class, reflect.TypeFor[A_arbace_core_reducers_reducer_A]()) }

func A_arbace_core_reducers_reducer_reify__153000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).Coll_reduce_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).Coll_reduce_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).Meta__IPersistentMap(); case 3: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_core_reducers_reducer_reify__153000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2])}; return nil }

var A_arbace_core_reducers_reducer_reify__153000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_core_reducers_reducer_reify__153000052_A_invoke, New: A_arbace_core_reducers_reducer_reify__153000052_A_new}

var A_arbace_core_reducers_reducer_reify__153000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$reducer$reify__153000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_class, lang.IObj_class}, Declaring: A_arbace_core_reducers_reducer_A_class, Simple: "reify__153000052", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_reducer_reify__153000052_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_reducer_reify__153000052_A_class.Info(); i.IsInstance = A_arbace_core_reducers_reducer_reify__153000052_A_InstanceOf; i.Table = A_arbace_core_reducers_reducer_reify__153000052_A_members; jrt.RegisterGoType(A_arbace_core_reducers_reducer_reify__153000052_A_class, reflect.TypeFor[A_arbace_core_reducers_reducer_reify__153000052_A]()) }

func A_arbace_core_reducers_remove_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_remove_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_core_reducers_remove_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_remove_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_remove_A_New()}; return nil }

func A_arbace_core_reducers_remove_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_remove_A_fn_class)}; return nil }

var A_arbace_core_reducers_remove_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_remove_A_invoke, New: A_arbace_core_reducers_remove_A_new, Get: A_arbace_core_reducers_remove_A_get}

var A_arbace_core_reducers_remove_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$remove", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "remove", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_remove_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_remove_A_class.Info(); i.IsInstance = A_arbace_core_reducers_remove_A_InstanceOf; i.Init = A_arbace_core_reducers_remove_A_Init; i.Table = A_arbace_core_reducers_remove_A_members; jrt.RegisterGoType(A_arbace_core_reducers_remove_A_class, reflect.TypeFor[A_arbace_core_reducers_remove_A]()) }

func A_arbace_core_reducers_remove_fn__153000101_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_remove_fn__153000101_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_remove_fn__153000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_remove_fn__153000101_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_remove_fn__153000101_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_remove_fn__153000101_A_fn_class)}; return nil }

var A_arbace_core_reducers_remove_fn__153000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_remove_fn__153000101_A_invoke, New: A_arbace_core_reducers_remove_fn__153000101_A_new, Get: A_arbace_core_reducers_remove_fn__153000101_A_get}

var A_arbace_core_reducers_remove_fn__153000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$remove$fn__153000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_remove_A_class, Simple: "fn__153000101", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_remove_fn__153000101_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_remove_fn__153000101_A_class.Info(); i.IsInstance = A_arbace_core_reducers_remove_fn__153000101_A_InstanceOf; i.Init = A_arbace_core_reducers_remove_fn__153000101_A_Init; i.Table = A_arbace_core_reducers_remove_fn__153000101_A_members; jrt.RegisterGoType(A_arbace_core_reducers_remove_fn__153000101_A_class, reflect.TypeFor[A_arbace_core_reducers_remove_fn__153000101_A]()) }

func A_arbace_core_reducers_rfn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_rfn_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_rfn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_rfn_A_New()}; return nil }

func A_arbace_core_reducers_rfn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_rfn_A_fn_class)}; return nil }

var A_arbace_core_reducers_rfn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_rfn_A_invoke, New: A_arbace_core_reducers_rfn_A_new, Get: A_arbace_core_reducers_rfn_A_get}

var A_arbace_core_reducers_rfn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$rfn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "rfn", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_rfn_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_rfn_A_class.Info(); i.IsInstance = A_arbace_core_reducers_rfn_A_InstanceOf; i.Init = A_arbace_core_reducers_rfn_A_Init; i.Table = A_arbace_core_reducers_rfn_A_members; jrt.RegisterGoType(A_arbace_core_reducers_rfn_A_class, reflect.TypeFor[A_arbace_core_reducers_rfn_A]()) }

func A_arbace_core_reducers_take_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_core_reducers_take_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_take_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_A_New()}; return nil }

func A_arbace_core_reducers_take_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_A_invoke, New: A_arbace_core_reducers_take_A_new, Get: A_arbace_core_reducers_take_A_get}

var A_arbace_core_reducers_take_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "take", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_A_InstanceOf; i.Init = A_arbace_core_reducers_take_A_Init; i.Table = A_arbace_core_reducers_take_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_A_class, reflect.TypeFor[A_arbace_core_reducers_take_A]()) }

func A_arbace_core_reducers_take_fn__153000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_fn__153000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_take_fn__153000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_fn__153000118_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_take_fn__153000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_fn__153000118_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_fn__153000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_fn__153000118_A_invoke, New: A_arbace_core_reducers_take_fn__153000118_A_new, Get: A_arbace_core_reducers_take_fn__153000118_A_get}

var A_arbace_core_reducers_take_fn__153000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take$fn__153000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_take_A_class, Simple: "fn__153000118", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_fn__153000118_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_fn__153000118_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_fn__153000118_A_InstanceOf; i.Init = A_arbace_core_reducers_take_fn__153000118_A_Init; i.Table = A_arbace_core_reducers_take_fn__153000118_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_fn__153000118_A_class, reflect.TypeFor[A_arbace_core_reducers_take_fn__153000118_A]()) }

func A_arbace_core_reducers_take_fn__153000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_fn__153000120_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_take_fn__153000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_fn__153000120_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_take_fn__153000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_fn__153000120_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_fn__153000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_fn__153000120_A_invoke, New: A_arbace_core_reducers_take_fn__153000120_A_new, Get: A_arbace_core_reducers_take_fn__153000120_A_get}

var A_arbace_core_reducers_take_fn__153000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take$fn__153000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_take_A_class, Simple: "fn__153000120", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_fn__153000120_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_fn__153000120_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_fn__153000120_A_InstanceOf; i.Init = A_arbace_core_reducers_take_fn__153000120_A_Init; i.Table = A_arbace_core_reducers_take_fn__153000120_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_fn__153000120_A_class, reflect.TypeFor[A_arbace_core_reducers_take_fn__153000120_A]()) }

func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_fn__153000120_fn__153000121_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_take_fn__153000120_fn__153000121_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_core_reducers_take_fn__153000120_fn__153000121_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_invoke, New: A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_new, Get: A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_get}

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take$fn__153000120$fn__153000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_take_fn__153000120_A_class, Simple: "fn__153000121", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_fn__153000120_fn__153000121_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_InstanceOf; i.Init = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_Init; i.Table = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_class, reflect.TypeFor[A_arbace_core_reducers_take_fn__153000120_fn__153000121_A]()) }

func A_arbace_core_reducers_take_while_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_while_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_core_reducers_take_while_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_take_while_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_while_A_New()}; return nil }

func A_arbace_core_reducers_take_while_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_while_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_while_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_while_A_invoke, New: A_arbace_core_reducers_take_while_A_new, Get: A_arbace_core_reducers_take_while_A_get}

var A_arbace_core_reducers_take_while_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take_while", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_A_class, Simple: "take_while", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_while_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_while_A_InstanceOf; i.Init = A_arbace_core_reducers_take_while_A_Init; i.Table = A_arbace_core_reducers_take_while_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_while_A_class, reflect.TypeFor[A_arbace_core_reducers_take_while_A]()) }

func A_arbace_core_reducers_take_while_fn__153000111_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_while_fn__153000111_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_take_while_fn__153000111_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_while_fn__153000111_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_take_while_fn__153000111_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_while_fn__153000111_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_while_fn__153000111_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_while_fn__153000111_A_invoke, New: A_arbace_core_reducers_take_while_fn__153000111_A_new, Get: A_arbace_core_reducers_take_while_fn__153000111_A_get}

var A_arbace_core_reducers_take_while_fn__153000111_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take_while$fn__153000111", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_take_while_A_class, Simple: "fn__153000111", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_fn__153000111_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_while_fn__153000111_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_while_fn__153000111_A_InstanceOf; i.Init = A_arbace_core_reducers_take_while_fn__153000111_A_Init; i.Table = A_arbace_core_reducers_take_while_fn__153000111_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_while_fn__153000111_A_class, reflect.TypeFor[A_arbace_core_reducers_take_while_fn__153000111_A]()) }

func A_arbace_core_reducers_take_while_fn__153000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_while_fn__153000113_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_take_while_fn__153000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_while_fn__153000113_A_New_O(args[0])}; return nil }

func A_arbace_core_reducers_take_while_fn__153000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_while_fn__153000113_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_while_fn__153000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_while_fn__153000113_A_invoke, New: A_arbace_core_reducers_take_while_fn__153000113_A_new, Get: A_arbace_core_reducers_take_while_fn__153000113_A_get}

var A_arbace_core_reducers_take_while_fn__153000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take_while$fn__153000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_reducers_take_while_A_class, Simple: "fn__153000113", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_fn__153000113_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_while_fn__153000113_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_while_fn__153000113_A_InstanceOf; i.Init = A_arbace_core_reducers_take_while_fn__153000113_A_Init; i.Table = A_arbace_core_reducers_take_while_fn__153000113_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_while_fn__153000113_A_class, reflect.TypeFor[A_arbace_core_reducers_take_while_fn__153000113_A]()) }

func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class)}; return nil }

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_invoke, New: A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_new, Get: A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_get}

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$take_while$fn__153000113$fn__153000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_take_while_fn__153000113_A_class, Simple: "fn__153000114", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_class.Info(); i.IsInstance = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_InstanceOf; i.Init = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_Init; i.Table = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_members; jrt.RegisterGoType(A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_class, reflect.TypeFor[A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A]()) }

func A_arbace_core_reducers_Cat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_Cat_A).Coll_fold_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_reducers_Cat_A).Coll_reduce_O__O(args[0]); case 2: return this.(*A_arbace_core_reducers_Cat_A).Coll_reduce_O_O__O(args[0], args[1]); case 3: return this.(*A_arbace_core_reducers_Cat_A).Count__I(); case 4: return A_arbace_core_reducers_Cat_A_GetBasis__IPersistentVector(); case 5: return this.(*A_arbace_core_reducers_Cat_A).Seq__ISeq()}; return nil }

func A_arbace_core_reducers_Cat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_Cat_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_Cat_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_core_reducers_Cat_A).F_cnt; case 1: return o.(*A_arbace_core_reducers_Cat_A).F_left; case 2: return o.(*A_arbace_core_reducers_Cat_A).F_right}; return nil }

var A_arbace_core_reducers_Cat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 coll_fold (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 count ()I\nM9 getBasis ()Larbace.lang.IPersistentVector;\nM1 seq ()Larbace.lang.ISeq;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG17 cnt Ljava.lang.Object;\nG17 left Ljava.lang.Object;\nG17 right Ljava.lang.Object;", Invoke: A_arbace_core_reducers_Cat_A_invoke, New: A_arbace_core_reducers_Cat_A_new, Get: A_arbace_core_reducers_Cat_A_get}

var A_arbace_core_reducers_Cat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers.Cat", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_class, lang.Counted_class, A_arbace_core_reducers_CollFold_A_class, lang.Seqable_class, lang.IType_class}, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_Cat_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_Cat_A_class.Info(); i.IsInstance = A_arbace_core_reducers_Cat_A_InstanceOf; i.Init = A_arbace_core_reducers_Cat_A_Init; i.Table = A_arbace_core_reducers_Cat_A_members; jrt.RegisterGoType(A_arbace_core_reducers_Cat_A_class, reflect.TypeFor[A_arbace_core_reducers_Cat_A]()) }

func A_arbace_core_reducers_Cat_fn__153000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_Cat_fn__153000133_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_reducers_Cat_fn__153000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_reducers_Cat_fn__153000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_Cat_fn__153000133_A_fn_class)}; return nil }

var A_arbace_core_reducers_Cat_fn__153000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_Cat_fn__153000133_A_invoke, New: A_arbace_core_reducers_Cat_fn__153000133_A_new, Get: A_arbace_core_reducers_Cat_fn__153000133_A_get}

var A_arbace_core_reducers_Cat_fn__153000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers.Cat$fn__153000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_Cat_A_class, Simple: "fn__153000133", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_Cat_fn__153000133_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_Cat_fn__153000133_A_class.Info(); i.IsInstance = A_arbace_core_reducers_Cat_fn__153000133_A_InstanceOf; i.Init = A_arbace_core_reducers_Cat_fn__153000133_A_Init; i.Table = A_arbace_core_reducers_Cat_fn__153000133_A_members; jrt.RegisterGoType(A_arbace_core_reducers_Cat_fn__153000133_A_class, reflect.TypeFor[A_arbace_core_reducers_Cat_fn__153000133_A]()) }

func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class)}; return nil }

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_invoke, New: A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_new, Get: A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_get}

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers.Cat$fn__153000133$fn__153000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_reducers_Cat_fn__153000133_A_class, Simple: "fn__153000134", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_class.Info(); i.IsInstance = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_InstanceOf; i.Init = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_Init; i.Table = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_members; jrt.RegisterGoType(A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_class, reflect.TypeFor[A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A]()) }

func A_arbace_core_reducers_CollFold_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_reducers_CollFold_A).Coll_fold_O_O_O__O(args[0], args[1], args[2])}; return nil }

var A_arbace_core_reducers_CollFold_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 coll_fold (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_reducers_CollFold_A_invoke}

var A_arbace_core_reducers_CollFold_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers.CollFold", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_CollFold_A"})

func init() { i := A_arbace_core_reducers_CollFold_A_class.Info(); i.IsInstance = A_arbace_core_reducers_CollFold_A_InstanceOf; i.Table = A_arbace_core_reducers_CollFold_A_members }

func A_arbace_core_reducers__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_reducers__init_A_Load__O(); case 1: return A_arbace_core_reducers__init_A_Unit0__O(); case 2: return A_arbace_core_reducers__init_A_Unit1__O(); case 3: return A_arbace_core_reducers__init_A_Unit10__O(); case 4: return A_arbace_core_reducers__init_A_Unit11__O(); case 5: return A_arbace_core_reducers__init_A_Unit12__O(); case 6: return A_arbace_core_reducers__init_A_Unit13__O(); case 7: return A_arbace_core_reducers__init_A_Unit14__O(); case 8: return A_arbace_core_reducers__init_A_Unit15__O(); case 9: return A_arbace_core_reducers__init_A_Unit16__O(); case 10: return A_arbace_core_reducers__init_A_Unit17__O(); case 11: return A_arbace_core_reducers__init_A_Unit18__O(); case 12: return A_arbace_core_reducers__init_A_Unit19__O(); case 13: return A_arbace_core_reducers__init_A_Unit2__O(); case 14: return A_arbace_core_reducers__init_A_Unit20__O(); case 15: return A_arbace_core_reducers__init_A_Unit21__O(); case 16: return A_arbace_core_reducers__init_A_Unit22__O(); case 17: return A_arbace_core_reducers__init_A_Unit23__O(); case 18: return A_arbace_core_reducers__init_A_Unit24__O(); case 19: return A_arbace_core_reducers__init_A_Unit25__O(); case 20: return A_arbace_core_reducers__init_A_Unit26__O(); case 21: return A_arbace_core_reducers__init_A_Unit27__O(); case 22: return A_arbace_core_reducers__init_A_Unit28__O(); case 23: return A_arbace_core_reducers__init_A_Unit29__O(); case 24: return A_arbace_core_reducers__init_A_Unit3__O(); case 25: return A_arbace_core_reducers__init_A_Unit30__O(); case 26: return A_arbace_core_reducers__init_A_Unit31__O(); case 27: return A_arbace_core_reducers__init_A_Unit32__O(); case 28: return A_arbace_core_reducers__init_A_Unit33__O(); case 29: return A_arbace_core_reducers__init_A_Unit34__O(); case 30: return A_arbace_core_reducers__init_A_Unit35__O(); case 31: return A_arbace_core_reducers__init_A_Unit36__O(); case 32: return A_arbace_core_reducers__init_A_Unit37__O(); case 33: return A_arbace_core_reducers__init_A_Unit38__O(); case 34: return A_arbace_core_reducers__init_A_Unit39__O(); case 35: return A_arbace_core_reducers__init_A_Unit4__O(); case 36: return A_arbace_core_reducers__init_A_Unit40__O(); case 37: return A_arbace_core_reducers__init_A_Unit41__O(); case 38: return A_arbace_core_reducers__init_A_Unit42__O(); case 39: return A_arbace_core_reducers__init_A_Unit43__O(); case 40: return A_arbace_core_reducers__init_A_Unit44__O(); case 41: return A_arbace_core_reducers__init_A_Unit45__O(); case 42: return A_arbace_core_reducers__init_A_Unit46__O(); case 43: return A_arbace_core_reducers__init_A_Unit47__O(); case 44: return A_arbace_core_reducers__init_A_Unit5__O(); case 45: return A_arbace_core_reducers__init_A_Unit6__O(); case 46: return A_arbace_core_reducers__init_A_Unit7__O(); case 47: return A_arbace_core_reducers__init_A_Unit8__O(); case 48: return A_arbace_core_reducers__init_A_Unit9__O()}; return nil }

func A_arbace_core_reducers__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers__init_A_New()}; return nil }

var A_arbace_core_reducers__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_reducers__init_A_invoke, New: A_arbace_core_reducers__init_A_new}

var A_arbace_core_reducers__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers__init_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers__init_A_class.Info(); i.IsInstance = A_arbace_core_reducers__init_A_InstanceOf; i.Init = A_arbace_core_reducers__init_A_Init; i.Table = A_arbace_core_reducers__init_A_members; jrt.RegisterGoType(A_arbace_core_reducers__init_A_class, reflect.TypeFor[A_arbace_core_reducers__init_A]()) }
