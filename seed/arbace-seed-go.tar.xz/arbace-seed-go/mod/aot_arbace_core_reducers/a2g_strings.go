//line a2g_strings.ae:1
package aot_arbace_core_reducers

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("exclude")

var Lit_4 *jrt.String = jrt.Intern("reduce")

var Lit_5 *jrt.String = jrt.Intern("map")

var Lit_6 *jrt.String = jrt.Intern("mapcat")

var Lit_7 *jrt.String = jrt.Intern("filter")

var Lit_8 *jrt.String = jrt.Intern("remove")

var Lit_9 *jrt.String = jrt.Intern("take")

var Lit_10 *jrt.String = jrt.Intern("take-while")

var Lit_11 *jrt.String = jrt.Intern("drop")

var Lit_12 *jrt.String = jrt.Intern("flatten")

var Lit_13 *jrt.String = jrt.Intern("cat")

var Lit_14 *jrt.String = jrt.Intern("arbace.walk")

var Lit_15 *jrt.String = jrt.Intern("as")

var Lit_16 *jrt.String = jrt.Intern("walk")

var Lit_17 *jrt.String = jrt.Intern("commute")

var Lit_18 *jrt.String = jrt.Intern("deref")

var Lit_19 *jrt.String = jrt.Intern("conj")

var Lit_20 *jrt.String = jrt.Intern("arbace.core.reducers")

var Lit_21 *jrt.String = jrt.Intern("doc")

var Lit_22 *jrt.String = jrt.Intern("A library for reduction and parallel folding. Alpha and subject\n      to change.")

var Lit_23 *jrt.String = jrt.Intern("author")

var Lit_24 *jrt.String = jrt.Intern("Rich Hickey")

var Lit_25 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_26 *jrt.String = jrt.Intern("fjtask")

var Lit_27 *jrt.String = jrt.Intern("pool")

var Lit_28 *jrt.String = jrt.Intern("arbace.core.protocols")

var Lit_29 *jrt.String = jrt.Intern("kv-reduce")

var Lit_30 *jrt.String = jrt.Intern("coll-reduce")

var Lit_31 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_32 *jrt.String = jrt.Intern("arbace.core.reducers.CollFold")

var Lit_33 *jrt.String = jrt.Intern("coll-fold")

var Lit_34 *jrt.String = jrt.Intern("fold")

var Lit_35 *jrt.String = jrt.Intern("vec")

var Lit_36 *jrt.String = jrt.Intern("seq")

var Lit_37 *jrt.String = jrt.Intern("butlast")

var Lit_38 *jrt.String = jrt.Intern("concat")

var Lit_39 *jrt.String = jrt.Intern("list")

var Lit_40 *jrt.String = jrt.Intern("defn")

var Lit_41 *jrt.String = jrt.Intern("fn")

var Lit_42 *jrt.String = jrt.Intern("apply")

var Lit_43 *jrt.String = jrt.Intern("vector")

var Lit_44 *jrt.String = jrt.Intern("x__153000058__auto__")

var Lit_45 *jrt.String = jrt.Intern("do-curried")

var Lit_46 *jrt.String = jrt.Intern("postwalk")

var Lit_47 *jrt.String = jrt.Intern("sequential?")

var Lit_48 *jrt.String = jrt.Intern("vector?")

var Lit_49 *jrt.String = jrt.Intern("identity")

var Lit_50 *jrt.String = jrt.Intern("do-rfn")

var Lit_51 *jrt.String = jrt.Intern("folder")

var Lit_52 *jrt.String = jrt.Intern("reduced")

var Lit_53 *jrt.String = jrt.Intern("complement")

var Lit_54 *jrt.String = jrt.Intern("reducer")

var Lit_55 *jrt.String = jrt.Intern("atom")

var Lit_56 *jrt.String = jrt.Intern("swap!")

var Lit_57 *jrt.String = jrt.Intern("dec")

var Lit_58 *jrt.String = jrt.Intern("else")

var Lit_59 *jrt.String = jrt.Intern("append!")

var Lit_60 *jrt.String = jrt.Intern("empty?")

var Lit_61 *jrt.String = jrt.Intern("subvec")

var Lit_62 *jrt.String = jrt.Intern("foldvec")

var Lit_63 *jrt.String = jrt.Intern("fjinvoke")

var Lit_64 *jrt.String = jrt.Intern("fjfork")

var Lit_65 *jrt.String = jrt.Intern("fjjoin")

var Lit_66 *jrt.String = jrt.Intern("arbace.core.reducers$append_BANG_")

var Lit_67 *jrt.String = jrt.Intern("arbace.core.reducers$cat")

var Lit_68 *jrt.String = jrt.Intern("arbace.core.reducers$cat$fn__153000141")

var Lit_69 *jrt.String = jrt.Intern("arbace.core.reducers$defcurried")

var Lit_70 *jrt.String = jrt.Intern("arbace.core.reducers$do_curried")

var Lit_71 *jrt.String = jrt.Intern("arbace.core.reducers$do_rfn")

var Lit_72 *jrt.String = jrt.Intern("arbace.core.reducers$do_rfn$fn__153000066")

var Lit_73 *jrt.String = jrt.Intern("arbace.core.reducers$drop")

var Lit_74 *jrt.String = jrt.Intern("arbace.core.reducers$drop$fn__153000125")

var Lit_75 *jrt.String = jrt.Intern("arbace.core.reducers$drop$fn__153000127")

var Lit_76 *jrt.String = jrt.Intern("arbace.core.reducers$drop$fn__153000127$fn__153000128")

var Lit_77 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000004$loading__1927001464__auto____153000005")

var Lit_78 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000008$fn__153000009")

var Lit_79 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000031$fn__153000032")

var Lit_80 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000031$fn__153000032$G__153000023__153000043")

var Lit_81 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000031$fn__153000032$G__153000024__153000037")

var Lit_82 *jrt.String = jrt.Intern("coll_fold")

var Lit_83 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000132$__GT_Cat__153000138")

var Lit_84 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000157$fn__153000158")

var Lit_85 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000161$fn__153000162")

var Lit_86 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000165$fn__153000166")

var Lit_87 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000169$fn__153000170")

var Lit_88 *jrt.String = jrt.Intern("arbace.core.reducers$filter")

var Lit_89 *jrt.String = jrt.Intern("arbace.core.reducers$filter$fn__153000094")

var Lit_90 *jrt.String = jrt.Intern("arbace.core.reducers$filter$fn__153000096")

var Lit_91 *jrt.String = jrt.Intern("arbace.core.reducers$filter$fn__153000096$fn__153000097")

var Lit_92 *jrt.String = jrt.Intern("arbace.core.reducers$fjfork")

var Lit_93 *jrt.String = jrt.Intern("arbace.core.reducers$fjinvoke")

var Lit_94 *jrt.String = jrt.Intern("arbace.core.reducers$fjjoin")

var Lit_95 *jrt.String = jrt.Intern("arbace.core.reducers$fjtask")

var Lit_96 *jrt.String = jrt.Intern("arbace.core.reducers$flatten")

var Lit_97 *jrt.String = jrt.Intern("arbace.core.reducers$flatten$fn__153000104")

var Lit_98 *jrt.String = jrt.Intern("arbace.core.reducers$flatten$fn__153000106")

var Lit_99 *jrt.String = jrt.Intern("arbace.core.reducers$flatten$fn__153000106$fn__153000107")

var Lit_100 *jrt.String = jrt.Intern("arbace.core.reducers$fn__153000016")

var Lit_101 *jrt.String = jrt.Intern("arbace.core.reducers$fold")

var Lit_102 *jrt.String = jrt.Intern("arbace.core.reducers$foldcat")

var Lit_103 *jrt.String = jrt.Intern("arbace.core.reducers$folder")

var Lit_104 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec")

var Lit_105 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec$fc__153000150")

var Lit_106 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec$fc__153000150$fn__153000151")

var Lit_107 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec$fn__153000154")

var Lit_108 *jrt.String = jrt.Intern("arbace.core.reducers$map")

var Lit_109 *jrt.String = jrt.Intern("arbace.core.reducers$map$fn__153000078")

var Lit_110 *jrt.String = jrt.Intern("arbace.core.reducers$map$fn__153000080")

var Lit_111 *jrt.String = jrt.Intern("arbace.core.reducers$map$fn__153000080$fn__153000081")

var Lit_112 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat")

var Lit_113 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000085")

var Lit_114 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000087")

var Lit_115 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000087$f1__153000088")

var Lit_116 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000087$fn__153000090")

var Lit_117 *jrt.String = jrt.Intern("arbace.core.reducers$monoid")

var Lit_118 *jrt.String = jrt.Intern("arbace.core.reducers$monoid$m__153000147")

var Lit_119 *jrt.String = jrt.Intern("arbace.core.reducers$reduce")

var Lit_120 *jrt.String = jrt.Intern("arbace.core.reducers$reducer")

var Lit_121 *jrt.String = jrt.Intern("arbace.core.reducers$remove")

var Lit_122 *jrt.String = jrt.Intern("arbace.core.reducers$remove$fn__153000101")

var Lit_123 *jrt.String = jrt.Intern("arbace.core.reducers$rfn")

var Lit_124 *jrt.String = jrt.Intern("arbace.core.reducers$take")

var Lit_125 *jrt.String = jrt.Intern("arbace.core.reducers$take$fn__153000118")

var Lit_126 *jrt.String = jrt.Intern("arbace.core.reducers$take$fn__153000120")

var Lit_127 *jrt.String = jrt.Intern("arbace.core.reducers$take$fn__153000120$fn__153000121")

var Lit_128 *jrt.String = jrt.Intern("arbace.core.reducers$take_while")

var Lit_129 *jrt.String = jrt.Intern("arbace.core.reducers$take_while$fn__153000111")

var Lit_130 *jrt.String = jrt.Intern("arbace.core.reducers$take_while$fn__153000113")

var Lit_131 *jrt.String = jrt.Intern("arbace.core.reducers$take_while$fn__153000113$fn__153000114")

var Lit_132 *jrt.String = jrt.Intern("cnt")

var Lit_133 *jrt.String = jrt.Intern("left")

var Lit_134 *jrt.String = jrt.Intern("right")

var Lit_135 *jrt.String = jrt.Intern("arbace.core.reducers.Cat$fn__153000133")

var Lit_136 *jrt.String = jrt.Intern("arbace.core.reducers.Cat$fn__153000133$fn__153000134")

var Lit_137 *jrt.String = jrt.Intern("in-ns")

var Lit_138 *jrt.String = jrt.Intern("alias")

var Lit_139 *jrt.String = jrt.Intern("core")

var Lit_140 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_141 *jrt.String = jrt.Intern("line")

var Lit_142 *jrt.String = jrt.Intern("column")

var Lit_143 *jrt.String = jrt.Intern("file")

var Lit_144 *jrt.String = jrt.Intern("arbace/core/reducers.ae")

var Lit_145 *jrt.String = jrt.Intern("arglists")

var Lit_146 *jrt.String = jrt.Intern("f")

var Lit_147 *jrt.String = jrt.Intern("tag")

var Lit_148 *jrt.String = jrt.Intern("Callable")

var Lit_149 *jrt.String = jrt.Intern("private")

var Lit_150 *jrt.String = jrt.Intern("task")

var Lit_151 *jrt.String = jrt.Intern("coll")

var Lit_152 *jrt.String = jrt.Intern("init")

var Lit_153 *jrt.String = jrt.Intern("Like core/reduce except:\n     When init is not provided, (f) is used.\n     Maps are reduced with reduce-kv")

var Lit_154 *jrt.String = jrt.Intern("CollFold")

var Lit_155 *jrt.String = jrt.Intern("alter-meta!")

var Lit_156 *jrt.String = jrt.Intern("assoc")

var Lit_157 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_158 *jrt.String = jrt.Intern("n")

var Lit_159 *jrt.String = jrt.Intern("combinef")

var Lit_160 *jrt.String = jrt.Intern("reducef")

var Lit_161 *jrt.String = jrt.Intern("alter-var-root")

var Lit_162 *jrt.String = jrt.Intern("merge")

var Lit_163 *jrt.String = jrt.Intern("on")

var Lit_164 *jrt.String = jrt.Intern("on-interface")

var Lit_165 *jrt.String = jrt.Intern("sigs")

var Lit_166 *jrt.String = jrt.Intern("name")

var Lit_167 *jrt.String = jrt.Intern("var")

var Lit_168 *jrt.String = jrt.Intern("method-map")

var Lit_169 *jrt.String = jrt.Intern("method-builders")

var Lit_170 *jrt.String = jrt.Intern("intern")

var Lit_171 *jrt.String = jrt.Intern("*ns*")

var Lit_172 *jrt.String = jrt.Intern("with-meta")

var Lit_173 *jrt.String = jrt.Intern("protocol")

var Lit_174 *jrt.String = jrt.Intern("-reset-methods")

var Lit_175 *jrt.String = jrt.Intern("Reduces a collection using a (potentially parallel) reduce-combine\n  strategy. The collection is partitioned into groups of approximately\n  n (default 512), each of which is reduced with reducef (with a seed\n  value obtained by calling (combinef) with no arguments). The results\n  of these reductions are then reduced with combinef (default\n  reducef). combinef must be associative, and, when called with no\n  arguments, (combinef) must produce its identity element. These\n  operations may be performed in parallel, but the results will\n  preserve order.")

var Lit_176 *jrt.String = jrt.Intern("added")

var Lit_177 *jrt.String = jrt.Intern("1.5")

var Lit_178 *jrt.String = jrt.Intern("xf")

var Lit_179 *jrt.String = jrt.Intern("Given a reducible collection, and a transformation function xf,\n  returns a reducible collection, where any supplied reducing\n  fn will be transformed by xf. xf is a function of reducing fn to\n  reducing fn.")

var Lit_180 *jrt.String = jrt.Intern("Given a foldable collection, and a transformation function xf,\n  returns a foldable collection, where any supplied reducing\n  fn will be transformed by xf. xf is a function of reducing fn to\n  reducing fn.")

var Lit_181 *jrt.String = jrt.Intern("meta")

var Lit_182 *jrt.String = jrt.Intern("args")

var Lit_183 *jrt.String = jrt.Intern("body")

var Lit_184 *jrt.String = jrt.Intern("defcurried")

var Lit_185 *jrt.String = jrt.Intern("&")

var Lit_186 *jrt.String = jrt.Intern("Builds another arity of the fn that returns a fn awaiting the last\n  param")

var Lit_187 *jrt.String = jrt.Intern("f1")

var Lit_188 *jrt.String = jrt.Intern("k")

var Lit_189 *jrt.String = jrt.Intern("fkv")

var Lit_190 *jrt.String = jrt.Intern("rfn")

var Lit_191 *jrt.String = jrt.Intern("Builds 3-arity reducing fn given names of wrapped fn and key, and k/v impl.")

var Lit_192 *jrt.String = jrt.Intern("Applies f to every value in the reduction of coll. Foldable.")

var Lit_193 *jrt.String = jrt.Intern("Applies f to every value in the reduction of coll, concatenating the result\n  colls of (f val). Foldable.")

var Lit_194 *jrt.String = jrt.Intern("pred")

var Lit_195 *jrt.String = jrt.Intern("Retains values in the reduction of coll for which (pred val)\n  returns logical true. Foldable.")

var Lit_196 *jrt.String = jrt.Intern("Removes values in the reduction of coll for which (pred val)\n  returns logical true. Foldable.")

var Lit_197 *jrt.String = jrt.Intern("Takes any nested combination of sequential things (lists, vectors,\n  etc.) and returns their contents as a single, flat foldable\n  collection.")

var Lit_198 *jrt.String = jrt.Intern("Ends the reduction of coll when (pred val) returns logical false.")

var Lit_199 *jrt.String = jrt.Intern("Ends the reduction of coll after consuming n values.")

var Lit_200 *jrt.String = jrt.Intern("Elides the first n values from the reduction of coll.")

var Lit_201 *jrt.String = jrt.Intern("arbace.core.reducers.Cat")

var Lit_202 *jrt.String = jrt.Intern("->Cat")

var Lit_203 *jrt.String = jrt.Intern("Positional factory function for class arbace.core.reducers.Cat.")

var Lit_204 *jrt.String = jrt.Intern("ctor")

var Lit_205 *jrt.String = jrt.Intern("A high-performance combining fn that yields the catenation of the\n  reduced values. The result is reducible, foldable, seqable and\n  counted, providing the identity collections are reducible, seqable\n  and counted. The single argument version will build a combining fn\n  with the supplied identity constructor. Tests for identity\n  with (zero? (count x)). See also foldcat.")

var Lit_206 *jrt.String = jrt.Intern("acc")

var Lit_207 *jrt.String = jrt.Intern("java.util.Collection")

var Lit_208 *jrt.String = jrt.Intern("x")

var Lit_209 *jrt.String = jrt.Intern(".adds x to acc and returns acc")

var Lit_210 *jrt.String = jrt.Intern("foldcat")

var Lit_211 *jrt.String = jrt.Intern("Equivalent to (fold cat append! coll)")

var Lit_212 *jrt.String = jrt.Intern("monoid")

var Lit_213 *jrt.String = jrt.Intern("op")

var Lit_214 *jrt.String = jrt.Intern("Builds a combining fn out of the supplied operator and identity\n  constructor. op must be associative and ctor called with no args\n  must return an identity value for it.")

var Lit_215 *jrt.String = jrt.Intern("v")

var Lit_216 *jrt.String = jrt.Intern("extend")

var Lit_217 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_218 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_219 *jrt.String = jrt.Intern("arbace.lang.PersistentHashMap")
