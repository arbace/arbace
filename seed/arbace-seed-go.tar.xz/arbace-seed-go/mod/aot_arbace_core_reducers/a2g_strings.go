//line a2g_strings.ae:1
package aot_arbace_core_reducers

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn6,reduceyn3,mapyn6,mapcatyn6,filteryn6,removeyn4,takeyn10,take-whileyn4,dropyn7,flattenyn3,catyn11,arbace.walkkn2,asyn4,walkkn3,dockn6,authorys11,arbace.core4,defnys11,arbace.core2,fnyn20,x__153000058__auto__kn4,elsev11,arbace.core7,requirev11,arbace.core5,referR0,R1,V10,R2,R3,R4,R5,R6,R7,R8,R9,R10,R11,V3,R12,R13,R14,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn20,arbace.core.reducersm4,R15,s80,A library for reduction and parallel folding. Alpha and subject\n      to change.R16,s11,Rich Hickeyv11,arbace.core13,*loaded-libs*v20,arbace.core.reducers6,fjtaskv20,arbace.core.reducers4,poolv21,arbace.core.protocols9,kv-reducev21,arbace.core.protocols11,coll-reducev20,arbace.core.reducers6,reducev11,arbace.core18,-cache-protocol-fnC29,arbace.core.reducers.CollFoldv20,arbace.core.reducers9,coll-foldv20,arbace.core.reducers4,foldl512,v11,arbace.core3,vecv11,arbace.core3,seqv11,arbace.core7,butlastv11,arbace.core6,concatv11,arbace.core4,listR17,R18,v11,arbace.core5,applyv11,arbace.core6,vectorR19,v20,arbace.core.reducers10,do-curriedR18,v11,arbace.walk8,postwalkv11,arbace.core11,sequential?v11,arbace.core7,vector?v11,arbace.core8,identityv11,arbace.core6,removev20,arbace.core.reducers6,do-rfnv20,arbace.core.reducers6,folderv20,arbace.core.reducers3,mapv11,arbace.core7,reducedv20,arbace.core.reducers6,mapcatv20,arbace.core.reducers6,filterv11,arbace.core10,complementv20,arbace.core.reducers6,removev20,arbace.core.reducers7,flattenv20,arbace.core.reducers7,reducerv20,arbace.core.reducers10,take-whilev11,arbace.core4,atomv11,arbace.core5,swap!v11,arbace.core3,decv20,arbace.core.reducers4,takev20,arbace.core.reducers4,dropR20,v20,arbace.core.reducers3,catv20,arbace.core.reducers7,append!v11,arbace.core6,empty?v11,arbace.core6,subvecv20,arbace.core.reducers7,foldvecv20,arbace.core.reducers8,fjinvokel0,v20,arbace.core.reducers6,fjforkv20,arbace.core.reducers6,fjjoin")

var Lit_1 *jrt.String = jrt.Intern("arbace.core.reducers$cat$fn__153000141")

var Lit_2 *jrt.String = jrt.Intern("arbace.core.reducers$do_rfn$fn__153000066")

var Lit_3 *jrt.String = jrt.Intern("arbace.core.reducers$drop$fn__153000127")

var Lit_4 *jrt.String = jrt.Intern("arbace.core.reducers$drop$fn__153000125")

var Lit_5 *jrt.String = jrt.Intern("arbace.core.reducers$drop$fn__153000127$fn__153000128")

var Lit_6 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000031$fn__153000032$G__153000024__153000037")

var Lit_7 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000031$fn__153000032$G__153000023__153000043")

var Lit_8 *jrt.String = jrt.Intern("coll_fold")

var Lit_9 *jrt.String = jrt.Intern("arbace.core.reducers$filter$fn__153000096")

var Lit_10 *jrt.String = jrt.Intern("arbace.core.reducers$filter$fn__153000094")

var Lit_11 *jrt.String = jrt.Intern("arbace.core.reducers$filter$fn__153000096$fn__153000097")

var Lit_12 *jrt.String = jrt.Intern("arbace.core.reducers$flatten$fn__153000106")

var Lit_13 *jrt.String = jrt.Intern("arbace.core.reducers$flatten$fn__153000104")

var Lit_14 *jrt.String = jrt.Intern("arbace.core.reducers$flatten$fn__153000106$fn__153000107")

var Lit_15 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec$fc__153000150")

var Lit_16 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec$fn__153000154")

var Lit_17 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec$fc__153000150$fn__153000151")

var Lit_18 *jrt.String = jrt.Intern("arbace.core.reducers$map$fn__153000080")

var Lit_19 *jrt.String = jrt.Intern("arbace.core.reducers$map$fn__153000078")

var Lit_20 *jrt.String = jrt.Intern("arbace.core.reducers$map$fn__153000080$fn__153000081")

var Lit_21 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000087")

var Lit_22 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000085")

var Lit_23 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000087$f1__153000088")

var Lit_24 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat$fn__153000087$fn__153000090")

var Lit_25 *jrt.String = jrt.Intern("arbace.core.reducers$monoid$m__153000147")

var Lit_26 *jrt.String = jrt.Intern("arbace.core.reducers$remove$fn__153000101")

var Lit_27 *jrt.String = jrt.Intern("arbace.core.reducers$take$fn__153000120")

var Lit_28 *jrt.String = jrt.Intern("arbace.core.reducers$take$fn__153000118")

var Lit_29 *jrt.String = jrt.Intern("arbace.core.reducers$take$fn__153000120$fn__153000121")

var Lit_30 *jrt.String = jrt.Intern("arbace.core.reducers$take_while$fn__153000113")

var Lit_31 *jrt.String = jrt.Intern("arbace.core.reducers$take_while$fn__153000111")

var Lit_32 *jrt.String = jrt.Intern("arbace.core.reducers$take_while$fn__153000113$fn__153000114")

var Lit_33 *jrt.String = jrt.Intern("v20,arbace.core.reducers8,fjinvokev20,arbace.core.reducers6,fjforkv20,arbace.core.reducers6,fjtaskv20,arbace.core.reducers9,coll-foldv20,arbace.core.reducers6,fjjoinv21,arbace.core.protocols11,coll-reducev11,arbace.core6,concatv11,arbace.core3,seq")

var Lit_34 *jrt.String = jrt.Intern("cnt")

var Lit_35 *jrt.String = jrt.Intern("left")

var Lit_36 *jrt.String = jrt.Intern("right")

var Lit_37 *jrt.String = jrt.Intern("arbace.core.reducers.Cat$fn__153000133")

var Lit_38 *jrt.String = jrt.Intern("arbace.core.reducers.Cat$fn__153000133$fn__153000134")

var Lit_39 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.coreyn4,corekn4,linekn6,columnkn4,filekn8,arglistskn3,tagyn8,Callablekn7,privateyn1,fyn4,taskyn4,collyn4,inityn1,nyn8,combinefyn7,reducefkn2,onyn29,arbace.core.reducers.CollFoldkn12,on-interfacekn4,sigskn9,coll-foldkn4,namekn3,varkn10,method-mapkn15,method-builderskn8,protocolyn8,CollFoldkn5,addedyn2,xfyn4,nameyn3,docyn4,metayn4,argsyn4,bodyyn1,&yn2,f1yn1,kyn3,fkvyn4,predyn3,cntyn4,leftyn5,rightyn4,ctoryn20,java.util.Collectionyn1,xyn2,opyn1,vv11,arbace.core5,in-nsMyn20,arbace.core.reducersm4,R0,s80,A library for reduction and parallel folding. Alpha and subject\n      to change.R1,s11,Rich Hickeym4,R0,s80,A library for reduction and parallel folding. Alpha and subject\n      to change.R1,s11,Rich HickeyR2,v11,arbace.core5,aliasR3,R2,v11,arbace.core20,*warn-on-reflection*v20,arbace.core.reducers4,poolm6,R4,i22,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,fjtaskm8,R7,L1,V1,Myn1,fm2,R8,R9,R4,i24,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers8,fjinvokem10,R10,TR7,L1,V1,R11,R4,i27,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,fjforkm10,R10,TR7,L1,V1,R12,R4,i32,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,fjjoinm10,R10,TR7,L1,V1,R12,R4,i34,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,reducem10,R7,L2,V2,R11,R13,V3,R11,R14,R13,R0,s106,Like core/reduce except:\n     When init is not provided, (f) is used.\n     Maps are reduced with reduce-kvR4,i38,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers8,CollFoldm6,R4,i48,R5,i1,R6,s23,arbace/core/reducers.aem6,R4,i48,R5,i1,R6,s23,arbace/core/reducers.aeC29,arbace.core.reducers.CollFoldv11,arbace.core11,alter-meta!v11,arbace.core5,assocR0,v11,arbace.core20,assert-same-protocolL1,Myn9,coll-foldm4,R0,nR7,L1,V4,R13,R15,R16,R17,v11,arbace.core14,alter-var-rootv11,arbace.core5,mergem4,R18,R19,R20,C29,arbace.core.reducers.CollFoldR21,m2,R22,m8,R8,nR23,Myn9,coll-foldm4,R0,nR7,L1,V4,R13,R15,R16,R17,R7,L1,V4,R13,R15,R16,R17,R0,nR24,R25,m2,R22,R22,R26,v11,arbace.core6,internv11,arbace.core4,*ns*v11,arbace.core9,with-metaMyn9,coll-foldm4,R0,nR7,L1,V4,R13,R15,R16,R17,m8,R8,nR23,Myn9,coll-foldm4,R0,nR7,L1,V4,R13,R15,R16,R17,R7,L1,V4,R13,R15,R16,R17,R0,nR27,v11,arbace.core14,-reset-methodsR28,v20,arbace.core.reducers4,foldm12,R7,L3,V2,R17,R13,V3,R16,R17,R13,V4,R15,R16,R17,R13,R0,s554,Reduces a collection using a (potentially parallel) reduce-combine\n  strategy. The collection is partitioned into groups of approximately\n  n (default 512), each of which is reduced with reducef (with a seed\n  value obtained by calling (combinef) with no arguments). The results\n  of these reductions are then reduced with combinef (default\n  reducef). combinef must be associative, and, when called with no\n  arguments, (combinef) must produce its identity element. These\n  operations may be performed in parallel, but the results will\n  preserve order.R29,s3,1.5R4,i51,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers7,reducerm12,R7,L1,V2,R13,R30,R0,s207,Given a reducible collection, and a transformation function xf,\n  returns a reducible collection, where any supplied reducing\n  fn will be transformed by xf. xf is a function of reducing fn to\n  reducing fn.R29,s3,1.5R4,i67,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,folderm12,R7,L1,V2,R13,R30,R0,s205,Given a foldable collection, and a transformation function xf,\n  returns a foldable collection, where any supplied reducing\n  fn will be transformed by xf. xf is a function of reducing fn to\n  reducing fn.R29,s3,1.5R4,i81,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers10,do-curriedm10,R10,TR7,L1,V5,R31,R32,R33,R34,R35,R4,i99,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers10,defcurriedm12,R10,TR7,L1,V6,R31,R32,R33,R34,R36,R35,R0,s74,Builds another arity of the fn that returns a fn awaiting the last\n  paramR4,i106,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,do-rfnm10,R10,TR7,L1,V3,R37,R38,R39,R4,i112,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers3,rfnm12,R10,TR7,L1,V2,V2,R37,R38,R39,R0,s75,Builds 3-arity reducing fn given names of wrapped fn and key, and k/v impl.R4,i123,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers3,mapm12,R7,L2,V1,R11,V2,R11,R13,R0,s60,Applies f to every value in the reduction of coll. Foldable.R29,s3,1.5R4,i128,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,mapcatm12,R7,L2,V1,R11,V2,R11,R13,R0,s105,Applies f to every value in the reduction of coll, concatenating the result\n  colls of (f val). Foldable.R29,s3,1.5R4,i138,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,filterm12,R7,L2,V1,R40,V2,R40,R13,R0,s94,Retains values in the reduction of coll for which (pred val)\n  returns logical true. Foldable.R29,s3,1.5R4,i154,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,removem12,R7,L2,V1,R40,V2,R40,R13,R0,s94,Removes values in the reduction of coll for which (pred val)\n  returns logical true. Foldable.R29,s3,1.5R4,i167,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers7,flattenm12,R7,L2,V0,V1,R13,R0,s142,Takes any nested combination of sequential things (lists, vectors,\n  etc.) and returns their contents as a single, flat foldable\n  collection.R29,s3,1.5R4,i174,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers10,take-whilem12,R7,L2,V1,R40,V2,R40,R13,R0,s65,Ends the reduction of coll when (pred val) returns logical false.R29,s3,1.5R4,i189,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers4,takem12,R7,L2,V1,R15,V2,R15,R13,R0,s52,Ends the reduction of coll after consuming n values.R29,s3,1.5R4,i201,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers4,dropm12,R7,L2,V1,R15,V2,R15,R13,R0,s53,Elides the first n values from the reduction of coll.R29,s3,1.5R4,i215,R5,i1,R6,s23,arbace/core/reducers.aeC24,arbace.core.reducers.Catv20,arbace.core.reducers5,->Catm10,R7,L1,V3,R41,R42,R43,R0,s63,Positional factory function for class arbace.core.reducers.Cat.R4,i230,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers3,catm12,R7,L3,V0,V1,R44,V2,R42,R43,R0,s373,A high-performance combining fn that yields the catenation of the\n  reduced values. The result is reducible, foldable, seqable and\n  counted, providing the identity collections are reducible, seqable\n  and counted. The single argument version will build a combining fn\n  with the supplied identity constructor. Tests for identity\n  with (zero? (count x)). See also foldcat.R29,s3,1.5R4,i255,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers7,append!m12,R7,L1,V2,Myn3,accm2,R8,R45,R46,R0,s30,.adds x to acc and returns accR29,s3,1.5R4,i275,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers7,foldcatm12,R7,L1,V1,R13,R0,s37,Equivalent to (fold cat append! coll)R29,s3,1.5R4,i281,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers6,monoidm12,R7,L1,V2,R47,R44,R0,s170,Builds a combining fn out of the supplied operator and identity\n  constructor. op must be associative and ctor called with no args\n  must return an identity value for it.R29,s3,1.5R4,i287,R5,i1,R6,s23,arbace/core/reducers.aev20,arbace.core.reducers7,foldvecm10,R10,TR7,L1,V4,R48,R15,R16,R17,R4,i298,R5,i1,R6,s23,arbace/core/reducers.aev11,arbace.core6,extendR22,C16,java.lang.ObjectC29,arbace.lang.IPersistentVectorC29,arbace.lang.PersistentHashMap")

var Lit_40 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000004$loading__1927001464__auto____153000005")

var Lit_41 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000008$fn__153000009")

var Lit_42 *jrt.String = jrt.Intern("arbace.core.reducers$fn__153000016")

var Lit_43 *jrt.String = jrt.Intern("arbace.core.reducers$fjtask")

var Lit_44 *jrt.String = jrt.Intern("arbace.core.reducers$fjinvoke")

var Lit_45 *jrt.String = jrt.Intern("arbace.core.reducers$fjfork")

var Lit_46 *jrt.String = jrt.Intern("arbace.core.reducers$fjjoin")

var Lit_47 *jrt.String = jrt.Intern("arbace.core.reducers$reduce")

var Lit_48 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000031$fn__153000032")

var Lit_49 *jrt.String = jrt.Intern("arbace.core.reducers$fold")

var Lit_50 *jrt.String = jrt.Intern("arbace.core.reducers$reducer")

var Lit_51 *jrt.String = jrt.Intern("arbace.core.reducers$folder")

var Lit_52 *jrt.String = jrt.Intern("arbace.core.reducers$do_curried")

var Lit_53 *jrt.String = jrt.Intern("arbace.core.reducers$defcurried")

var Lit_54 *jrt.String = jrt.Intern("arbace.core.reducers$do_rfn")

var Lit_55 *jrt.String = jrt.Intern("arbace.core.reducers$rfn")

var Lit_56 *jrt.String = jrt.Intern("arbace.core.reducers$map")

var Lit_57 *jrt.String = jrt.Intern("arbace.core.reducers$mapcat")

var Lit_58 *jrt.String = jrt.Intern("arbace.core.reducers$filter")

var Lit_59 *jrt.String = jrt.Intern("arbace.core.reducers$remove")

var Lit_60 *jrt.String = jrt.Intern("arbace.core.reducers$flatten")

var Lit_61 *jrt.String = jrt.Intern("arbace.core.reducers$take_while")

var Lit_62 *jrt.String = jrt.Intern("arbace.core.reducers$take")

var Lit_63 *jrt.String = jrt.Intern("arbace.core.reducers$drop")

var Lit_64 *jrt.String = jrt.Intern("arbace.core.reducers.Cat")

var Lit_65 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000132$__GT_Cat__153000138")

var Lit_66 *jrt.String = jrt.Intern("arbace.core.reducers$cat")

var Lit_67 *jrt.String = jrt.Intern("arbace.core.reducers$append_BANG_")

var Lit_68 *jrt.String = jrt.Intern("arbace.core.reducers$foldcat")

var Lit_69 *jrt.String = jrt.Intern("arbace.core.reducers$monoid")

var Lit_70 *jrt.String = jrt.Intern("arbace.core.reducers$foldvec")

var Lit_71 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000157$fn__153000158")

var Lit_72 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000161$fn__153000162")

var Lit_73 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000165$fn__153000166")

var Lit_74 *jrt.String = jrt.Intern("arbace.core.reducers$eval153000169$fn__153000170")
