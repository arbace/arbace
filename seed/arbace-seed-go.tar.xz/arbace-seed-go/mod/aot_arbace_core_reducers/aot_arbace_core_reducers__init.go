//line aot_arbace_core_reducers__init.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_reducers__init_A_Load__O() any { A_arbace_core_reducers__init_A_Init(); jrt.StartCheck(); A_arbace_core_reducers__init_A_Unit0__O(); A_arbace_core_reducers__init_A_Unit1__O(); A_arbace_core_reducers__init_A_Unit2__O(); A_arbace_core_reducers__init_A_Unit3__O(); A_arbace_core_reducers__init_A_Unit4__O(); A_arbace_core_reducers__init_A_Unit5__O(); A_arbace_core_reducers__init_A_Unit6__O(); A_arbace_core_reducers__init_A_Unit7__O(); A_arbace_core_reducers__init_A_Unit8__O(); A_arbace_core_reducers__init_A_Unit9__O(); A_arbace_core_reducers__init_A_Unit10__O(); A_arbace_core_reducers__init_A_Unit11__O(); A_arbace_core_reducers__init_A_Unit12__O(); A_arbace_core_reducers__init_A_Unit13__O(); A_arbace_core_reducers__init_A_Unit14__O(); A_arbace_core_reducers__init_A_Unit15__O(); A_arbace_core_reducers__init_A_Unit16__O(); A_arbace_core_reducers__init_A_Unit17__O(); A_arbace_core_reducers__init_A_Unit18__O(); A_arbace_core_reducers__init_A_Unit19__O(); A_arbace_core_reducers__init_A_Unit20__O(); A_arbace_core_reducers__init_A_Unit21__O(); A_arbace_core_reducers__init_A_Unit22__O(); A_arbace_core_reducers__init_A_Unit23__O(); A_arbace_core_reducers__init_A_Unit24__O(); A_arbace_core_reducers__init_A_Unit25__O(); A_arbace_core_reducers__init_A_Unit26__O(); A_arbace_core_reducers__init_A_Unit27__O(); A_arbace_core_reducers__init_A_Unit28__O(); A_arbace_core_reducers__init_A_Unit29__O(); A_arbace_core_reducers__init_A_Unit30__O(); A_arbace_core_reducers__init_A_Unit31__O(); A_arbace_core_reducers__init_A_Unit32__O(); A_arbace_core_reducers__init_A_Unit33__O(); A_arbace_core_reducers__init_A_Unit34__O(); A_arbace_core_reducers__init_A_Unit35__O(); A_arbace_core_reducers__init_A_Unit36__O(); A_arbace_core_reducers__init_A_Unit37__O(); A_arbace_core_reducers__init_A_Unit38__O(); A_arbace_core_reducers__init_A_Unit39__O(); A_arbace_core_reducers__init_A_Unit40__O(); A_arbace_core_reducers__init_A_Unit41__O(); A_arbace_core_reducers__init_A_Unit42__O(); A_arbace_core_reducers__init_A_Unit43__O(); A_arbace_core_reducers__init_A_Unit44__O(); A_arbace_core_reducers__init_A_Unit45__O(); A_arbace_core_reducers__init_A_Unit46__O(); A_arbace_core_reducers__init_A_Unit47__O(); return nil }



func A_arbace_core_reducers__init_A_Unit0__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_core_reducers__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers__init_A_const_1) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit1__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_2)) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit2__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 any = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_core_reducers__init_A_Unit3__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1)).Equals_O__Z(A_arbace_core_reducers__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_core_reducers_eval153000008_fn__153000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }







func A_arbace_core_reducers__init_A_Unit4__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var root_3 any = A_arbace_core_reducers__init_A_const_4.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_alias_A_fn_class); var ifn_5 lang.IFn; if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = A_arbace_core_reducers__init_A_const_5; var arg_7 any = A_arbace_core_reducers__init_A_const_6; if linked_4 == nil { return ifn_5.Invoke_O_O__O(arg_6, arg_7) } else { return linked_4.(*aot_arbace_core.A_arbace_core_alias_A).Invoke_O_O_O__O(root_3, arg_6, arg_7) } }
func A_arbace_core_reducers__init_A_Unit5__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return A_arbace_core_reducers__init_A_const_7.Set_O__O(jrt.Boolean_TRUE.Ref()) }



func A_arbace_core_reducers__init_A_Unit6__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_8; var tmp2 any = A_arbace_core_reducers_fn__153000016_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_core_reducers_fn__153000016_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_core_reducers_fn__153000016_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_9)); return A_arbace_core_reducers__init_A_const_8 }

func A_arbace_core_reducers__init_A_Unit7__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_10; var tmp2 any = A_arbace_core_reducers_fjtask_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_core_reducers_fjtask_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_core_reducers_fjtask_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_11)); return A_arbace_core_reducers__init_A_const_10 }


func A_arbace_core_reducers__init_A_Unit8__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_12; var tmp2 any = A_arbace_core_reducers_fjinvoke_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_core_reducers_fjinvoke_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_core_reducers_fjinvoke_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_13)); return A_arbace_core_reducers__init_A_const_12 }




func A_arbace_core_reducers__init_A_Unit9__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_14; var tmp2 any = A_arbace_core_reducers_fjfork_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_core_reducers_fjfork_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_core_reducers_fjfork_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_15)); return A_arbace_core_reducers__init_A_const_14 }

func A_arbace_core_reducers__init_A_Unit10__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_16; var tmp2 any = A_arbace_core_reducers_fjjoin_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_reducers_fjjoin_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_core_reducers_fjjoin_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_17)); return A_arbace_core_reducers__init_A_const_16 }



func A_arbace_core_reducers__init_A_Unit11__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_18; var tmp2 any = A_arbace_core_reducers_reduce_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_core_reducers_reduce_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_core_reducers_reduce_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_19)); return A_arbace_core_reducers__init_A_const_18 }









func A_arbace_core_reducers__init_A_Unit12__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_21)); v__1927001498__auto____1 = A_arbace_core_reducers__init_A_const_20; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_20; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_22)); A_arbace_core_reducers__init_A_const_20.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_core_reducers__init_A_const_20 } }
//line :48:1
func A_arbace_core_reducers__init_A_Unit13__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_core_reducers__init_A_const_23 }
//line :48:1
func A_arbace_core_reducers__init_A_Unit14__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_reducers__init_A_const_25.GetRawRoot__O(), A_arbace_core_reducers__init_A_const_26, nil) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit15__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_core_reducers__init_A_const_27.Invoke_O_O__O(A_arbace_core_reducers__init_A_const_20, A_arbace_core_reducers__init_A_const_28) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit16__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_29.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20; var tmp3 any = A_arbace_core_reducers__init_A_const_30.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_core_reducers__init_A_const_31; var tmp6 any = A_arbace_core_reducers__init_A_const_32; var tmp7 any = A_arbace_core_reducers__init_A_const_33; var tmp8 any = A_arbace_core_reducers__init_A_const_34; var tmp9 any = A_arbace_core_reducers__init_A_const_20; var tmp10 any = A_arbace_core_reducers__init_A_const_35; var tmp11 any = A_arbace_core_reducers__init_A_const_36; var tmp12 any = A_arbace_core_reducers__init_A_const_37; var tmp13 any; var root_31 any = A_arbace_core_reducers__init_A_const_38.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = A_arbace_core_reducers__init_A_const_39.Get__O(); var arg_35 any; var root_26 any = A_arbace_core_reducers__init_A_const_40.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = A_arbace_core_reducers__init_A_const_41; var arg_30 any; var root_21 any = A_arbace_core_reducers__init_A_const_30.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_core_reducers__init_A_const_42; var arg_25 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_reducers__init_A_const_43, A_arbace_core_reducers__init_A_const_20)); if linked_22 == nil { arg_30 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { arg_30 = linked_22.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; if linked_27 == nil { arg_35 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_35 = linked_27.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_32 == nil { tmp13 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { tmp13 = linked_32.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_core_reducers_eval153000031_fn__153000032_A_New(); var tmp16 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class = fncls__36d; tmp16 = fncls__36d } else { tmp16 = fncls__36 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))))) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit17__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var root_55 any = A_arbace_core_reducers__init_A_const_44.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); if linked_56 == nil { return ifn_57.Invoke_O__O(arg_58) } else { return linked_56.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_55, arg_58) } }
//line :48:1
func A_arbace_core_reducers__init_A_Unit18__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_core_reducers__init_A_const_45 }


func A_arbace_core_reducers__init_A_Unit19__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_46; var tmp2 any = A_arbace_core_reducers_fold_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_core_reducers_fold_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_core_reducers_fold_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_47)); return A_arbace_core_reducers__init_A_const_46 }















func A_arbace_core_reducers__init_A_Unit20__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_48; var tmp2 any = A_arbace_core_reducers_reducer_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_core_reducers_reducer_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_core_reducers_reducer_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_49)); return A_arbace_core_reducers__init_A_const_48 }













func A_arbace_core_reducers__init_A_Unit21__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_50; var tmp2 any = A_arbace_core_reducers_folder_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_core_reducers_folder_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_core_reducers_folder_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_51)); return A_arbace_core_reducers__init_A_const_50 }

















func A_arbace_core_reducers__init_A_Unit22__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_52; var tmp2 any = A_arbace_core_reducers_do_curried_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_core_reducers_do_curried_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_core_reducers_do_curried_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_53)); return A_arbace_core_reducers__init_A_const_52 }






func A_arbace_core_reducers__init_A_Unit23__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_54; var tmp2 any = A_arbace_core_reducers_defcurried_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_core_reducers_defcurried_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, true); A_arbace_core_reducers_defcurried_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 6)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_55)); return A_arbace_core_reducers__init_A_const_54 }
//line :106:1
func A_arbace_core_reducers__init_A_Unit24__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); A_arbace_core_reducers__init_A_const_54.SetMacro__V(); return nil }
//line :106:1
func A_arbace_core_reducers__init_A_Unit25__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); return A_arbace_core_reducers__init_A_const_54 }





func A_arbace_core_reducers__init_A_Unit26__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_56; var tmp2 any = A_arbace_core_reducers_do_rfn_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_core_reducers_do_rfn_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_core_reducers_do_rfn_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_57)); return A_arbace_core_reducers__init_A_const_56 }










func A_arbace_core_reducers__init_A_Unit27__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_58; var tmp2 any = A_arbace_core_reducers_rfn_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_core_reducers_rfn_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_core_reducers_rfn_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_59)); return A_arbace_core_reducers__init_A_const_58 }
//line :123:1
func A_arbace_core_reducers__init_A_Unit28__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); A_arbace_core_reducers__init_A_const_58.SetMacro__V(); return nil }
//line :123:1
func A_arbace_core_reducers__init_A_Unit29__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); return A_arbace_core_reducers__init_A_const_58 }




func A_arbace_core_reducers__init_A_Unit30__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_60; var tmp2 any = A_arbace_core_reducers_map_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_core_reducers_map_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_core_reducers_map_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_61)); return A_arbace_core_reducers__init_A_const_60 }









func A_arbace_core_reducers__init_A_Unit31__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(138, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_62; var tmp2 any = A_arbace_core_reducers_mapcat_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_core_reducers_mapcat_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_core_reducers_mapcat_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_63)); return A_arbace_core_reducers__init_A_const_62 }















func A_arbace_core_reducers__init_A_Unit32__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_64; var tmp2 any = A_arbace_core_reducers_filter_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_core_reducers_filter_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_core_reducers_filter_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_65)); return A_arbace_core_reducers__init_A_const_64 }












func A_arbace_core_reducers__init_A_Unit33__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_66; var tmp2 any = A_arbace_core_reducers_remove_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_core_reducers_remove_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_core_reducers_remove_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_67)); return A_arbace_core_reducers__init_A_const_66 }






func A_arbace_core_reducers__init_A_Unit34__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_68; var tmp2 any = A_arbace_core_reducers_flatten_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_core_reducers_flatten_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_core_reducers_flatten_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_69)); return A_arbace_core_reducers__init_A_const_68 }














func A_arbace_core_reducers__init_A_Unit35__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_70; var tmp2 any = A_arbace_core_reducers_take_while_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_core_reducers_take_while_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_core_reducers_take_while_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_71)); return A_arbace_core_reducers__init_A_const_70 }











func A_arbace_core_reducers__init_A_Unit36__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_72; var tmp2 any = A_arbace_core_reducers_take_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_core_reducers_take_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_core_reducers_take_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_73)); return A_arbace_core_reducers__init_A_const_72 }













func A_arbace_core_reducers__init_A_Unit37__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_74; var tmp2 any = A_arbace_core_reducers_drop_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_core_reducers_drop_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_core_reducers_drop_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_75)); return A_arbace_core_reducers__init_A_const_74 }














func A_arbace_core_reducers__init_A_Unit38__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_64)); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_78)); var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_77; var tmp3 any = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New(); var tmp4 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class = fncls__74d; tmp4 = fncls__74d } else { tmp4 = fncls__74 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); return A_arbace_core_reducers__init_A_const_76 }
























func A_arbace_core_reducers__init_A_Unit39__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_79; var tmp2 any = A_arbace_core_reducers_cat_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_core_reducers_cat_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_core_reducers_cat_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_80)); return A_arbace_core_reducers__init_A_const_79 }



















func A_arbace_core_reducers__init_A_Unit40__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_81; var tmp2 any = A_arbace_core_reducers_append_BANG__A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_core_reducers_append_BANG__A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_core_reducers_append_BANG__A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_82)); return A_arbace_core_reducers__init_A_const_81 }





func A_arbace_core_reducers__init_A_Unit41__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_83; var tmp2 any = A_arbace_core_reducers_foldcat_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_core_reducers_foldcat_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_core_reducers_foldcat_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_84)); return A_arbace_core_reducers__init_A_const_83 }





func A_arbace_core_reducers__init_A_Unit42__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_85; var tmp2 any = A_arbace_core_reducers_monoid_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_core_reducers_monoid_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_core_reducers_monoid_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_86)); return A_arbace_core_reducers__init_A_const_85 }










func A_arbace_core_reducers__init_A_Unit43__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_87; var tmp2 any = A_arbace_core_reducers_foldvec_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_core_reducers_foldvec_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_core_reducers_foldvec_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_88)); return A_arbace_core_reducers__init_A_const_87 }















func A_arbace_core_reducers__init_A_Unit44__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp3 any = A_arbace_core_reducers__init_A_const_90; var tmp4 any = A_arbace_core_reducers_eval153000157_fn__153000158_A_New(); var tmp5 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class = fncls__80d; tmp5 = fncls__80d } else { tmp5 = fncls__80 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit45__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_91; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 any = A_arbace_core_reducers_eval153000161_fn__153000162_A_New(); var tmp6 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class = fncls__87d; tmp6 = fncls__87d } else { tmp6 = fncls__87 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit46__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_92; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 any = A_arbace_core_reducers_eval153000165_fn__153000166_A_New(); var tmp6 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class = fncls__94d; tmp6 = fncls__94d } else { tmp6 = fncls__94 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit47__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_93; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 any = A_arbace_core_reducers_eval153000169_fn__153000170_A_New(); var tmp6 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class = fncls__101d; tmp6 = fncls__101d } else { tmp6 = fncls__101 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }









type A_arbace_core_reducers__init_A struct{ jrt.Object }

var A_arbace_core_reducers__init_A_const_pool *jrt.RefArray

var A_arbace_core_reducers__init_A_const_0 *lang.Var

var A_arbace_core_reducers__init_A_const_1 any

var A_arbace_core_reducers__init_A_const_2 any

var A_arbace_core_reducers__init_A_const_3 any

var A_arbace_core_reducers__init_A_const_4 *lang.Var

var A_arbace_core_reducers__init_A_const_5 any

var A_arbace_core_reducers__init_A_const_6 any

var A_arbace_core_reducers__init_A_const_7 *lang.Var

var A_arbace_core_reducers__init_A_const_8 *lang.Var

var A_arbace_core_reducers__init_A_const_9 any

var A_arbace_core_reducers__init_A_const_10 *lang.Var

var A_arbace_core_reducers__init_A_const_11 any

var A_arbace_core_reducers__init_A_const_12 *lang.Var

var A_arbace_core_reducers__init_A_const_13 any

var A_arbace_core_reducers__init_A_const_14 *lang.Var

var A_arbace_core_reducers__init_A_const_15 any

var A_arbace_core_reducers__init_A_const_16 *lang.Var

var A_arbace_core_reducers__init_A_const_17 any

var A_arbace_core_reducers__init_A_const_18 *lang.Var

var A_arbace_core_reducers__init_A_const_19 any

var A_arbace_core_reducers__init_A_const_20 *lang.Var

var A_arbace_core_reducers__init_A_const_21 any

var A_arbace_core_reducers__init_A_const_22 any

var A_arbace_core_reducers__init_A_const_23 *jrt.Class

var A_arbace_core_reducers__init_A_const_24 *lang.Var

var A_arbace_core_reducers__init_A_const_25 *lang.Var

var A_arbace_core_reducers__init_A_const_26 *lang.Keyword

var A_arbace_core_reducers__init_A_const_27 *lang.Var

var A_arbace_core_reducers__init_A_const_28 any

var A_arbace_core_reducers__init_A_const_29 *lang.Var

var A_arbace_core_reducers__init_A_const_30 *lang.Var

var A_arbace_core_reducers__init_A_const_31 any

var A_arbace_core_reducers__init_A_const_32 *lang.Keyword

var A_arbace_core_reducers__init_A_const_33 any

var A_arbace_core_reducers__init_A_const_34 *lang.Keyword

var A_arbace_core_reducers__init_A_const_35 *lang.Keyword

var A_arbace_core_reducers__init_A_const_36 any

var A_arbace_core_reducers__init_A_const_37 *lang.Keyword

var A_arbace_core_reducers__init_A_const_38 *lang.Var

var A_arbace_core_reducers__init_A_const_39 *lang.Var

var A_arbace_core_reducers__init_A_const_40 *lang.Var

var A_arbace_core_reducers__init_A_const_41 any

var A_arbace_core_reducers__init_A_const_42 any

var A_arbace_core_reducers__init_A_const_43 *lang.Keyword

var A_arbace_core_reducers__init_A_const_44 *lang.Var

var A_arbace_core_reducers__init_A_const_45 any

var A_arbace_core_reducers__init_A_const_46 *lang.Var

var A_arbace_core_reducers__init_A_const_47 any

var A_arbace_core_reducers__init_A_const_48 *lang.Var

var A_arbace_core_reducers__init_A_const_49 any

var A_arbace_core_reducers__init_A_const_50 *lang.Var

var A_arbace_core_reducers__init_A_const_51 any

var A_arbace_core_reducers__init_A_const_52 *lang.Var

var A_arbace_core_reducers__init_A_const_53 any

var A_arbace_core_reducers__init_A_const_54 *lang.Var

var A_arbace_core_reducers__init_A_const_55 any

var A_arbace_core_reducers__init_A_const_56 *lang.Var

var A_arbace_core_reducers__init_A_const_57 any

var A_arbace_core_reducers__init_A_const_58 *lang.Var

var A_arbace_core_reducers__init_A_const_59 any

var A_arbace_core_reducers__init_A_const_60 *lang.Var

var A_arbace_core_reducers__init_A_const_61 any

var A_arbace_core_reducers__init_A_const_62 *lang.Var

var A_arbace_core_reducers__init_A_const_63 any

var A_arbace_core_reducers__init_A_const_64 *lang.Var

var A_arbace_core_reducers__init_A_const_65 any

var A_arbace_core_reducers__init_A_const_66 *lang.Var

var A_arbace_core_reducers__init_A_const_67 any

var A_arbace_core_reducers__init_A_const_68 *lang.Var

var A_arbace_core_reducers__init_A_const_69 any

var A_arbace_core_reducers__init_A_const_70 *lang.Var

var A_arbace_core_reducers__init_A_const_71 any

var A_arbace_core_reducers__init_A_const_72 *lang.Var

var A_arbace_core_reducers__init_A_const_73 any

var A_arbace_core_reducers__init_A_const_74 *lang.Var

var A_arbace_core_reducers__init_A_const_75 any

var A_arbace_core_reducers__init_A_const_76 *jrt.Class

var A_arbace_core_reducers__init_A_const_77 *lang.Var

var A_arbace_core_reducers__init_A_const_78 any

var A_arbace_core_reducers__init_A_const_79 *lang.Var

var A_arbace_core_reducers__init_A_const_80 any

var A_arbace_core_reducers__init_A_const_81 *lang.Var

var A_arbace_core_reducers__init_A_const_82 any

var A_arbace_core_reducers__init_A_const_83 *lang.Var

var A_arbace_core_reducers__init_A_const_84 any

var A_arbace_core_reducers__init_A_const_85 *lang.Var

var A_arbace_core_reducers__init_A_const_86 any

var A_arbace_core_reducers__init_A_const_87 *lang.Var

var A_arbace_core_reducers__init_A_const_88 any

var A_arbace_core_reducers__init_A_const_89 *lang.Var

var A_arbace_core_reducers__init_A_const_90 *lang.Keyword

var A_arbace_core_reducers__init_A_const_91 *jrt.Class

var A_arbace_core_reducers__init_A_const_92 *jrt.Class

var A_arbace_core_reducers__init_A_const_93 *jrt.Class

var A_arbace_core_reducers__init_A_init jrt.ClassInit

func A_arbace_core_reducers__init_A_Init() { if !A_arbace_core_reducers__init_A_init.Done() { A_arbace_core_reducers__init_A_init.Run(A_arbace_core_reducers__init_A_clinit) } }

func A_arbace_core_reducers__init_A_clinit() { A_arbace_core_reducers__init_A_clinit_p0(); A_arbace_core_reducers__init_A_clinit_p1(); A_arbace_core_reducers__init_A_clinit_p2(); A_arbace_core_reducers__init_A_clinit_p3(); A_arbace_core_reducers__init_A_clinit_p4(); A_arbace_core_reducers__init_A_clinit_p5(); A_arbace_core_reducers__init_A_clinit_p6(); A_arbace_core_reducers__init_A_clinit_p7() }

func A_arbace_core_reducers__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_reducers__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_39, 143); A_arbace_core_reducers__init_A_const_0 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[49]); A_arbace_core_reducers__init_A_const_1 = A_arbace_core_reducers__init_A_const_pool.A[50]; A_arbace_core_reducers__init_A_const_2 = A_arbace_core_reducers__init_A_const_pool.A[51]; A_arbace_core_reducers__init_A_const_3 = A_arbace_core_reducers__init_A_const_pool.A[52]; A_arbace_core_reducers__init_A_const_4 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[53]); A_arbace_core_reducers__init_A_const_5 = A_arbace_core_reducers__init_A_const_pool.A[54]; A_arbace_core_reducers__init_A_const_6 = A_arbace_core_reducers__init_A_const_pool.A[55]; A_arbace_core_reducers__init_A_const_7 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[56]); A_arbace_core_reducers__init_A_const_8 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[57]); A_arbace_core_reducers__init_A_const_9 = A_arbace_core_reducers__init_A_const_pool.A[58]; A_arbace_core_reducers__init_A_const_10 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[59]); A_arbace_core_reducers__init_A_const_11 = A_arbace_core_reducers__init_A_const_pool.A[60]; A_arbace_core_reducers__init_A_const_12 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[61]) }

func A_arbace_core_reducers__init_A_clinit_p1() { A_arbace_core_reducers__init_A_const_13 = A_arbace_core_reducers__init_A_const_pool.A[62]; A_arbace_core_reducers__init_A_const_14 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[63]); A_arbace_core_reducers__init_A_const_15 = A_arbace_core_reducers__init_A_const_pool.A[64]; A_arbace_core_reducers__init_A_const_16 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[65]); A_arbace_core_reducers__init_A_const_17 = A_arbace_core_reducers__init_A_const_pool.A[66]; A_arbace_core_reducers__init_A_const_18 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[67]); A_arbace_core_reducers__init_A_const_19 = A_arbace_core_reducers__init_A_const_pool.A[68]; A_arbace_core_reducers__init_A_const_20 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[69]); A_arbace_core_reducers__init_A_const_21 = A_arbace_core_reducers__init_A_const_pool.A[70]; A_arbace_core_reducers__init_A_const_22 = A_arbace_core_reducers__init_A_const_pool.A[71]; A_arbace_core_reducers__init_A_const_23 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[72]); A_arbace_core_reducers__init_A_const_24 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[73]); A_arbace_core_reducers__init_A_const_25 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[74]) }

func A_arbace_core_reducers__init_A_clinit_p2() { A_arbace_core_reducers__init_A_const_26 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[75]); A_arbace_core_reducers__init_A_const_27 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[76]); A_arbace_core_reducers__init_A_const_28 = A_arbace_core_reducers__init_A_const_pool.A[77]; A_arbace_core_reducers__init_A_const_29 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[78]); A_arbace_core_reducers__init_A_const_30 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[79]); A_arbace_core_reducers__init_A_const_31 = A_arbace_core_reducers__init_A_const_pool.A[80]; A_arbace_core_reducers__init_A_const_32 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[81]); A_arbace_core_reducers__init_A_const_33 = A_arbace_core_reducers__init_A_const_pool.A[82]; A_arbace_core_reducers__init_A_const_34 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[83]); A_arbace_core_reducers__init_A_const_35 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[84]); A_arbace_core_reducers__init_A_const_36 = A_arbace_core_reducers__init_A_const_pool.A[85]; A_arbace_core_reducers__init_A_const_37 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[86]); A_arbace_core_reducers__init_A_const_38 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[87]) }

func A_arbace_core_reducers__init_A_clinit_p3() { A_arbace_core_reducers__init_A_const_39 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[88]); A_arbace_core_reducers__init_A_const_40 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[89]); A_arbace_core_reducers__init_A_const_41 = A_arbace_core_reducers__init_A_const_pool.A[90]; A_arbace_core_reducers__init_A_const_42 = A_arbace_core_reducers__init_A_const_pool.A[91]; A_arbace_core_reducers__init_A_const_43 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[92]); A_arbace_core_reducers__init_A_const_44 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[93]); A_arbace_core_reducers__init_A_const_45 = A_arbace_core_reducers__init_A_const_pool.A[94]; A_arbace_core_reducers__init_A_const_46 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[95]); A_arbace_core_reducers__init_A_const_47 = A_arbace_core_reducers__init_A_const_pool.A[96]; A_arbace_core_reducers__init_A_const_48 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[97]); A_arbace_core_reducers__init_A_const_49 = A_arbace_core_reducers__init_A_const_pool.A[98]; A_arbace_core_reducers__init_A_const_50 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[99]); A_arbace_core_reducers__init_A_const_51 = A_arbace_core_reducers__init_A_const_pool.A[100] }

func A_arbace_core_reducers__init_A_clinit_p4() { A_arbace_core_reducers__init_A_const_52 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[101]); A_arbace_core_reducers__init_A_const_53 = A_arbace_core_reducers__init_A_const_pool.A[102]; A_arbace_core_reducers__init_A_const_54 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[103]); A_arbace_core_reducers__init_A_const_55 = A_arbace_core_reducers__init_A_const_pool.A[104]; A_arbace_core_reducers__init_A_const_56 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[105]); A_arbace_core_reducers__init_A_const_57 = A_arbace_core_reducers__init_A_const_pool.A[106]; A_arbace_core_reducers__init_A_const_58 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[107]); A_arbace_core_reducers__init_A_const_59 = A_arbace_core_reducers__init_A_const_pool.A[108]; A_arbace_core_reducers__init_A_const_60 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[109]); A_arbace_core_reducers__init_A_const_61 = A_arbace_core_reducers__init_A_const_pool.A[110]; A_arbace_core_reducers__init_A_const_62 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[111]); A_arbace_core_reducers__init_A_const_63 = A_arbace_core_reducers__init_A_const_pool.A[112]; A_arbace_core_reducers__init_A_const_64 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[113]) }

func A_arbace_core_reducers__init_A_clinit_p5() { A_arbace_core_reducers__init_A_const_65 = A_arbace_core_reducers__init_A_const_pool.A[114]; A_arbace_core_reducers__init_A_const_66 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[115]); A_arbace_core_reducers__init_A_const_67 = A_arbace_core_reducers__init_A_const_pool.A[116]; A_arbace_core_reducers__init_A_const_68 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[117]); A_arbace_core_reducers__init_A_const_69 = A_arbace_core_reducers__init_A_const_pool.A[118]; A_arbace_core_reducers__init_A_const_70 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[119]); A_arbace_core_reducers__init_A_const_71 = A_arbace_core_reducers__init_A_const_pool.A[120]; A_arbace_core_reducers__init_A_const_72 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[121]); A_arbace_core_reducers__init_A_const_73 = A_arbace_core_reducers__init_A_const_pool.A[122]; A_arbace_core_reducers__init_A_const_74 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[123]); A_arbace_core_reducers__init_A_const_75 = A_arbace_core_reducers__init_A_const_pool.A[124]; A_arbace_core_reducers__init_A_const_76 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[125]); A_arbace_core_reducers__init_A_const_77 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[126]) }

func A_arbace_core_reducers__init_A_clinit_p6() { A_arbace_core_reducers__init_A_const_78 = A_arbace_core_reducers__init_A_const_pool.A[127]; A_arbace_core_reducers__init_A_const_79 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[128]); A_arbace_core_reducers__init_A_const_80 = A_arbace_core_reducers__init_A_const_pool.A[129]; A_arbace_core_reducers__init_A_const_81 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[130]); A_arbace_core_reducers__init_A_const_82 = A_arbace_core_reducers__init_A_const_pool.A[131]; A_arbace_core_reducers__init_A_const_83 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[132]); A_arbace_core_reducers__init_A_const_84 = A_arbace_core_reducers__init_A_const_pool.A[133]; A_arbace_core_reducers__init_A_const_85 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[134]); A_arbace_core_reducers__init_A_const_86 = A_arbace_core_reducers__init_A_const_pool.A[135]; A_arbace_core_reducers__init_A_const_87 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[136]); A_arbace_core_reducers__init_A_const_88 = A_arbace_core_reducers__init_A_const_pool.A[137]; A_arbace_core_reducers__init_A_const_89 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[138]); A_arbace_core_reducers__init_A_const_90 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[139]) }

func A_arbace_core_reducers__init_A_clinit_p7() { A_arbace_core_reducers__init_A_const_91 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[140]); A_arbace_core_reducers__init_A_const_92 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[141]); A_arbace_core_reducers__init_A_const_93 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[142]) }

func A_arbace_core_reducers__init_A_New() *A_arbace_core_reducers__init_A { A_arbace_core_reducers__init_A_Init(); t := &A_arbace_core_reducers__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers__init_A) Ctor() {}

func (t *A_arbace_core_reducers__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers__init_A_class }

func (t *A_arbace_core_reducers__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers__init_A); return ok }

func A_arbace_core_reducers__init_A_Cast(x any) *A_arbace_core_reducers__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers__init_A_class)) }; return v }
