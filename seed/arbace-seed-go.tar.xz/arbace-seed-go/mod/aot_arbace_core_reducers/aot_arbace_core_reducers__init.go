//line aot_arbace_core_reducers__init.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_reducers__init_A_Load__O() any { A_arbace_core_reducers__init_A_Init(); jrt.StartCheck(); A_arbace_core_reducers__init_A_Unit0__O(); A_arbace_core_reducers__init_A_Unit1__O(); A_arbace_core_reducers__init_A_Unit2__O(); A_arbace_core_reducers__init_A_Unit3__O(); A_arbace_core_reducers__init_A_Unit4__O(); A_arbace_core_reducers__init_A_Unit5__O(); A_arbace_core_reducers__init_A_Unit6__O(); A_arbace_core_reducers__init_A_Unit7__O(); A_arbace_core_reducers__init_A_Unit8__O(); A_arbace_core_reducers__init_A_Unit9__O(); A_arbace_core_reducers__init_A_Unit10__O(); A_arbace_core_reducers__init_A_Unit11__O(); A_arbace_core_reducers__init_A_Unit12__O(); A_arbace_core_reducers__init_A_Unit13__O(); A_arbace_core_reducers__init_A_Unit14__O(); A_arbace_core_reducers__init_A_Unit15__O(); A_arbace_core_reducers__init_A_Unit16__O(); A_arbace_core_reducers__init_A_Unit17__O(); A_arbace_core_reducers__init_A_Unit18__O(); A_arbace_core_reducers__init_A_Unit19__O(); A_arbace_core_reducers__init_A_Unit20__O(); A_arbace_core_reducers__init_A_Unit21__O(); A_arbace_core_reducers__init_A_Unit22__O(); A_arbace_core_reducers__init_A_Unit23__O(); A_arbace_core_reducers__init_A_Unit24__O(); A_arbace_core_reducers__init_A_Unit25__O(); A_arbace_core_reducers__init_A_Unit26__O(); A_arbace_core_reducers__init_A_Unit27__O(); A_arbace_core_reducers__init_A_Unit28__O(); A_arbace_core_reducers__init_A_Unit29__O(); A_arbace_core_reducers__init_A_Unit30__O(); A_arbace_core_reducers__init_A_Unit31__O(); A_arbace_core_reducers__init_A_Unit32__O(); A_arbace_core_reducers__init_A_Unit33__O(); A_arbace_core_reducers__init_A_Unit34__O(); A_arbace_core_reducers__init_A_Unit35__O(); A_arbace_core_reducers__init_A_Unit36__O(); A_arbace_core_reducers__init_A_Unit37__O(); A_arbace_core_reducers__init_A_Unit38__O(); A_arbace_core_reducers__init_A_Unit39__O(); A_arbace_core_reducers__init_A_Unit40__O(); A_arbace_core_reducers__init_A_Unit41__O(); A_arbace_core_reducers__init_A_Unit42__O(); A_arbace_core_reducers__init_A_Unit43__O(); A_arbace_core_reducers__init_A_Unit44__O(); A_arbace_core_reducers__init_A_Unit45__O(); A_arbace_core_reducers__init_A_Unit46__O(); A_arbace_core_reducers__init_A_Unit47__O(); return nil }



func A_arbace_core_reducers__init_A_Unit0__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_core_reducers__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers__init_A_const_1) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit1__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_2)) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit2__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :9:1
func A_arbace_core_reducers__init_A_Unit3__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1)).Equals_O__Z(A_arbace_core_reducers__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_core_reducers_eval153000008_fn__153000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }







func A_arbace_core_reducers__init_A_Unit4__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var root_5 any = A_arbace_core_reducers__init_A_const_4.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_alias_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_core_reducers__init_A_const_5; var arg_9 any = A_arbace_core_reducers__init_A_const_6; if linked_6 == nil { return ifn_7.Invoke_O_O__O(arg_8, arg_9) } else { return linked_6.(*aot_arbace_core.A_arbace_core_alias_A).Invoke_O_O_O__O(root_5, arg_8, arg_9) } }
func A_arbace_core_reducers__init_A_Unit5__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return A_arbace_core_reducers__init_A_const_7.Set_O__O(jrt.Boolean_TRUE.Ref()) }



func A_arbace_core_reducers__init_A_Unit6__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__11 any = A_arbace_core_reducers_fn__153000016_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_core_reducers_fn__153000016_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_core_reducers_fn__153000016_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__11, tmp3, nil); tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_9)); return A_arbace_core_reducers__init_A_const_8 }

func A_arbace_core_reducers__init_A_Unit7__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__13 any = A_arbace_core_reducers_fjtask_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_reducers_fjtask_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_core_reducers_fjtask_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__13, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_11)); return A_arbace_core_reducers__init_A_const_10 }


func A_arbace_core_reducers__init_A_Unit8__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__15 any = A_arbace_core_reducers_fjinvoke_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_core_reducers_fjinvoke_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_core_reducers_fjinvoke_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__15, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_13)); return A_arbace_core_reducers__init_A_const_12 }




func A_arbace_core_reducers__init_A_Unit9__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__17 any = A_arbace_core_reducers_fjfork_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_reducers_fjfork_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_core_reducers_fjfork_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__17, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_15)); return A_arbace_core_reducers__init_A_const_14 }

func A_arbace_core_reducers__init_A_Unit10__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__19 any = A_arbace_core_reducers_fjjoin_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_core_reducers_fjjoin_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_core_reducers_fjjoin_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__19, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_17)); return A_arbace_core_reducers__init_A_const_16 }



func A_arbace_core_reducers__init_A_Unit11__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__21 any = A_arbace_core_reducers_reduce_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_core_reducers_reduce_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_core_reducers_reduce_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__21, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_19)); return A_arbace_core_reducers__init_A_const_18 }









func A_arbace_core_reducers__init_A_Unit12__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_21)); v__1927001498__auto____1 = A_arbace_core_reducers__init_A_const_20; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_20; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_22)); A_arbace_core_reducers__init_A_const_20.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_core_reducers__init_A_const_20 } }
//line :48:1
func A_arbace_core_reducers__init_A_Unit13__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_core_reducers__init_A_const_23 }
//line :48:1
func A_arbace_core_reducers__init_A_Unit14__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_reducers__init_A_const_25.GetRawRoot__O(), A_arbace_core_reducers__init_A_const_26, nil) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit15__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_core_reducers__init_A_const_27.Invoke_O_O__O(A_arbace_core_reducers__init_A_const_20, A_arbace_core_reducers__init_A_const_28) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit16__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_29.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20; var tmp3 any = A_arbace_core_reducers__init_A_const_30.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_core_reducers__init_A_const_31; var tmp6 any = A_arbace_core_reducers__init_A_const_32; var tmp7 any = A_arbace_core_reducers__init_A_const_33; var tmp8 any = A_arbace_core_reducers__init_A_const_34; var tmp9 any = A_arbace_core_reducers__init_A_const_20; var tmp10 any = A_arbace_core_reducers__init_A_const_35; var tmp11 any = A_arbace_core_reducers__init_A_const_36; var tmp12 any = A_arbace_core_reducers__init_A_const_37; var tmp13 any; var root_47 any = A_arbace_core_reducers__init_A_const_38.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_core_reducers__init_A_const_39.Get__O(); var arg_51 any; var root_52 any = A_arbace_core_reducers__init_A_const_40.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = A_arbace_core_reducers__init_A_const_41; var arg_56 any; var root_57 any = A_arbace_core_reducers__init_A_const_30.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = A_arbace_core_reducers__init_A_const_42; var arg_61 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_reducers__init_A_const_43, A_arbace_core_reducers__init_A_const_20)); if linked_58 == nil { arg_56 = ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { arg_56 = linked_58.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_57, arg_60, arg_61) }; if linked_53 == nil { arg_51 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { arg_51 = linked_53.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; if linked_48 == nil { tmp13 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { tmp13 = linked_48.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; var tmp14 any = tmp13; var tmp15 *lang.Compiler_AOTFn; var fnbody__63 any = A_arbace_core_reducers_eval153000031_fn__153000032_A_New(); var tmp16 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class = fncls__62d; tmp16 = fncls__62d } else { tmp16 = fncls__62 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp16, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15.Ref())))) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit17__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var root_64 any = A_arbace_core_reducers__init_A_const_44.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); if linked_65 == nil { return ifn_66.Invoke_O__O(arg_67) } else { return linked_65.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_64, arg_67) } }
//line :48:1
func A_arbace_core_reducers__init_A_Unit18__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_core_reducers__init_A_const_45 }


func A_arbace_core_reducers__init_A_Unit19__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__69 any = A_arbace_core_reducers_fold_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_core_reducers_fold_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_core_reducers_fold_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_47)); return A_arbace_core_reducers__init_A_const_46 }















func A_arbace_core_reducers__init_A_Unit20__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__71 any = A_arbace_core_reducers_reducer_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_core_reducers_reducer_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_core_reducers_reducer_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_49)); return A_arbace_core_reducers__init_A_const_48 }













func A_arbace_core_reducers__init_A_Unit21__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__73 any = A_arbace_core_reducers_folder_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_core_reducers_folder_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_core_reducers_folder_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_51)); return A_arbace_core_reducers__init_A_const_50 }

















func A_arbace_core_reducers__init_A_Unit22__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__75 any = A_arbace_core_reducers_do_curried_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_core_reducers_do_curried_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_core_reducers_do_curried_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_53)); return A_arbace_core_reducers__init_A_const_52 }






func A_arbace_core_reducers__init_A_Unit23__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_54; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__77 any = A_arbace_core_reducers_defcurried_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_core_reducers_defcurried_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, true, nil); A_arbace_core_reducers_defcurried_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__77, tmp3, nil, 6); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_55)); return A_arbace_core_reducers__init_A_const_54 }
//line :106:1
func A_arbace_core_reducers__init_A_Unit24__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); A_arbace_core_reducers__init_A_const_54.SetMacro__V(); return nil }
//line :106:1
func A_arbace_core_reducers__init_A_Unit25__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); return A_arbace_core_reducers__init_A_const_54 }





func A_arbace_core_reducers__init_A_Unit26__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__79 any = A_arbace_core_reducers_do_rfn_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_core_reducers_do_rfn_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_core_reducers_do_rfn_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_57)); return A_arbace_core_reducers__init_A_const_56 }










func A_arbace_core_reducers__init_A_Unit27__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__81 any = A_arbace_core_reducers_rfn_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_core_reducers_rfn_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_core_reducers_rfn_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_59)); return A_arbace_core_reducers__init_A_const_58 }
//line :123:1
func A_arbace_core_reducers__init_A_Unit28__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); A_arbace_core_reducers__init_A_const_58.SetMacro__V(); return nil }
//line :123:1
func A_arbace_core_reducers__init_A_Unit29__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); return A_arbace_core_reducers__init_A_const_58 }




func A_arbace_core_reducers__init_A_Unit30__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__83 any = A_arbace_core_reducers_map_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_core_reducers_map_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_core_reducers_map_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__83, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_61)); return A_arbace_core_reducers__init_A_const_60 }









func A_arbace_core_reducers__init_A_Unit31__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(138, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__85 any = A_arbace_core_reducers_mapcat_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_core_reducers_mapcat_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_core_reducers_mapcat_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_63)); return A_arbace_core_reducers__init_A_const_62 }















func A_arbace_core_reducers__init_A_Unit32__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__87 any = A_arbace_core_reducers_filter_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_core_reducers_filter_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_core_reducers_filter_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__87, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_65)); return A_arbace_core_reducers__init_A_const_64 }












func A_arbace_core_reducers__init_A_Unit33__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__89 any = A_arbace_core_reducers_remove_A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_core_reducers_remove_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_core_reducers_remove_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__89, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_67)); return A_arbace_core_reducers__init_A_const_66 }






func A_arbace_core_reducers__init_A_Unit34__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__91 any = A_arbace_core_reducers_flatten_A_New(); var tmp3 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_core_reducers_flatten_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); A_arbace_core_reducers_flatten_A_fn_class = fncls__90d; tmp3 = fncls__90d } else { tmp3 = fncls__90 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__91, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_69)); return A_arbace_core_reducers__init_A_const_68 }














func A_arbace_core_reducers__init_A_Unit35__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__93 any = A_arbace_core_reducers_take_while_A_New(); var tmp3 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_core_reducers_take_while_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); A_arbace_core_reducers_take_while_A_fn_class = fncls__92d; tmp3 = fncls__92d } else { tmp3 = fncls__92 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__93, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_71)); return A_arbace_core_reducers__init_A_const_70 }











func A_arbace_core_reducers__init_A_Unit36__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__95 any = A_arbace_core_reducers_take_A_New(); var tmp3 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_core_reducers_take_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_core_reducers_take_A_fn_class = fncls__94d; tmp3 = fncls__94d } else { tmp3 = fncls__94 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_73)); return A_arbace_core_reducers__init_A_const_72 }













func A_arbace_core_reducers__init_A_Unit37__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__97 any = A_arbace_core_reducers_drop_A_New(); var tmp3 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_core_reducers_drop_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_core_reducers_drop_A_fn_class = fncls__96d; tmp3 = fncls__96d } else { tmp3 = fncls__96 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_75)); return A_arbace_core_reducers__init_A_const_74 }














func A_arbace_core_reducers__init_A_Unit38__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_64)); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_78)); var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_77; var tmp3 *lang.Compiler_AOTFn; var fnbody__99 any = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New(); var tmp4 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class = fncls__98d; tmp4 = fncls__98d } else { tmp4 = fncls__98 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__99, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); return A_arbace_core_reducers__init_A_const_76 }
























func A_arbace_core_reducers__init_A_Unit39__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__101 any = A_arbace_core_reducers_cat_A_New(); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_core_reducers_cat_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_core_reducers_cat_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__101, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_80)); return A_arbace_core_reducers__init_A_const_79 }



















func A_arbace_core_reducers__init_A_Unit40__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__103 any = A_arbace_core_reducers_append_BANG__A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_core_reducers_append_BANG__A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_core_reducers_append_BANG__A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_82)); return A_arbace_core_reducers__init_A_const_81 }





func A_arbace_core_reducers__init_A_Unit41__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__105 any = A_arbace_core_reducers_foldcat_A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_core_reducers_foldcat_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_core_reducers_foldcat_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__105, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_84)); return A_arbace_core_reducers__init_A_const_83 }





func A_arbace_core_reducers__init_A_Unit42__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__107 any = A_arbace_core_reducers_monoid_A_New(); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_core_reducers_monoid_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_core_reducers_monoid_A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__107, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_86)); return A_arbace_core_reducers__init_A_const_85 }










func A_arbace_core_reducers__init_A_Unit43__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__109 any = A_arbace_core_reducers_foldvec_A_New(); var tmp3 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_core_reducers_foldvec_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_core_reducers_foldvec_A_fn_class = fncls__108d; tmp3 = fncls__108d } else { tmp3 = fncls__108 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__109, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_88)); return A_arbace_core_reducers__init_A_const_87 }















func A_arbace_core_reducers__init_A_Unit44__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp3 any = A_arbace_core_reducers__init_A_const_90; var tmp4 *lang.Compiler_AOTFn; var fnbody__117 any = A_arbace_core_reducers_eval153000157_fn__153000158_A_New(); var tmp5 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class = fncls__116d; tmp5 = fncls__116d } else { tmp5 = fncls__116 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__117, tmp5, nil); return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref()))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit45__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_91; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 *lang.Compiler_AOTFn; var fnbody__125 any = A_arbace_core_reducers_eval153000161_fn__153000162_A_New(); var tmp6 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class = fncls__124d; tmp6 = fncls__124d } else { tmp6 = fncls__124 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__125, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit46__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_92; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 *lang.Compiler_AOTFn; var fnbody__133 any = A_arbace_core_reducers_eval153000165_fn__153000166_A_New(); var tmp6 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class = fncls__132d; tmp6 = fncls__132d } else { tmp6 = fncls__132 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__133, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit47__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_93; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 *lang.Compiler_AOTFn; var fnbody__141 any = A_arbace_core_reducers_eval153000169_fn__153000170_A_New(); var tmp6 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class = fncls__140d; tmp6 = fncls__140d } else { tmp6 = fncls__140 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }









type A_arbace_core_reducers__init_A struct{ jrt.Object }

var A_arbace_core_reducers__init_A_const_pool *jrt.RefArray

var A_arbace_core_reducers__init_A_const_0 *lang.Var

var A_arbace_core_reducers__init_A_const_1 any

var A_arbace_core_reducers__init_A_const_2 any

var A_arbace_core_reducers__init_A_const_3 any

var A_arbace_core_reducers__init_A_const_4 *lang.Var

var A_arbace_core_reducers__init_A_const_5 any

var A_arbace_core_reducers__init_A_const_6 any

var A_arbace_core_reducers__init_A_const_7 *lang.Var

var A_arbace_core_reducers__init_A_const_8 *lang.Var

var A_arbace_core_reducers__init_A_const_9 any

var A_arbace_core_reducers__init_A_const_10 *lang.Var

var A_arbace_core_reducers__init_A_const_11 any

var A_arbace_core_reducers__init_A_const_12 *lang.Var

var A_arbace_core_reducers__init_A_const_13 any

var A_arbace_core_reducers__init_A_const_14 *lang.Var

var A_arbace_core_reducers__init_A_const_15 any

var A_arbace_core_reducers__init_A_const_16 *lang.Var

var A_arbace_core_reducers__init_A_const_17 any

var A_arbace_core_reducers__init_A_const_18 *lang.Var

var A_arbace_core_reducers__init_A_const_19 any

var A_arbace_core_reducers__init_A_const_20 *lang.Var

var A_arbace_core_reducers__init_A_const_21 any

var A_arbace_core_reducers__init_A_const_22 any

var A_arbace_core_reducers__init_A_const_23 *jrt.Class

var A_arbace_core_reducers__init_A_const_24 *lang.Var

var A_arbace_core_reducers__init_A_const_25 *lang.Var

var A_arbace_core_reducers__init_A_const_26 *lang.Keyword

var A_arbace_core_reducers__init_A_const_27 *lang.Var

var A_arbace_core_reducers__init_A_const_28 any

var A_arbace_core_reducers__init_A_const_29 *lang.Var

var A_arbace_core_reducers__init_A_const_30 *lang.Var

var A_arbace_core_reducers__init_A_const_31 any

var A_arbace_core_reducers__init_A_const_32 *lang.Keyword

var A_arbace_core_reducers__init_A_const_33 any

var A_arbace_core_reducers__init_A_const_34 *lang.Keyword

var A_arbace_core_reducers__init_A_const_35 *lang.Keyword

var A_arbace_core_reducers__init_A_const_36 any

var A_arbace_core_reducers__init_A_const_37 *lang.Keyword

var A_arbace_core_reducers__init_A_const_38 *lang.Var

var A_arbace_core_reducers__init_A_const_39 *lang.Var

var A_arbace_core_reducers__init_A_const_40 *lang.Var

var A_arbace_core_reducers__init_A_const_41 any

var A_arbace_core_reducers__init_A_const_42 any

var A_arbace_core_reducers__init_A_const_43 *lang.Keyword

var A_arbace_core_reducers__init_A_const_44 *lang.Var

var A_arbace_core_reducers__init_A_const_45 any

var A_arbace_core_reducers__init_A_const_46 *lang.Var

var A_arbace_core_reducers__init_A_const_47 any

var A_arbace_core_reducers__init_A_const_48 *lang.Var

var A_arbace_core_reducers__init_A_const_49 any

var A_arbace_core_reducers__init_A_const_50 *lang.Var

var A_arbace_core_reducers__init_A_const_51 any

var A_arbace_core_reducers__init_A_const_52 *lang.Var

var A_arbace_core_reducers__init_A_const_53 any

var A_arbace_core_reducers__init_A_const_54 *lang.Var

var A_arbace_core_reducers__init_A_const_55 any

var A_arbace_core_reducers__init_A_const_56 *lang.Var

var A_arbace_core_reducers__init_A_const_57 any

var A_arbace_core_reducers__init_A_const_58 *lang.Var

var A_arbace_core_reducers__init_A_const_59 any

var A_arbace_core_reducers__init_A_const_60 *lang.Var

var A_arbace_core_reducers__init_A_const_61 any

var A_arbace_core_reducers__init_A_const_62 *lang.Var

var A_arbace_core_reducers__init_A_const_63 any

var A_arbace_core_reducers__init_A_const_64 *lang.Var

var A_arbace_core_reducers__init_A_const_65 any

var A_arbace_core_reducers__init_A_const_66 *lang.Var

var A_arbace_core_reducers__init_A_const_67 any

var A_arbace_core_reducers__init_A_const_68 *lang.Var

var A_arbace_core_reducers__init_A_const_69 any

var A_arbace_core_reducers__init_A_const_70 *lang.Var

var A_arbace_core_reducers__init_A_const_71 any

var A_arbace_core_reducers__init_A_const_72 *lang.Var

var A_arbace_core_reducers__init_A_const_73 any

var A_arbace_core_reducers__init_A_const_74 *lang.Var

var A_arbace_core_reducers__init_A_const_75 any

var A_arbace_core_reducers__init_A_const_76 *jrt.Class

var A_arbace_core_reducers__init_A_const_77 *lang.Var

var A_arbace_core_reducers__init_A_const_78 any

var A_arbace_core_reducers__init_A_const_79 *lang.Var

var A_arbace_core_reducers__init_A_const_80 any

var A_arbace_core_reducers__init_A_const_81 *lang.Var

var A_arbace_core_reducers__init_A_const_82 any

var A_arbace_core_reducers__init_A_const_83 *lang.Var

var A_arbace_core_reducers__init_A_const_84 any

var A_arbace_core_reducers__init_A_const_85 *lang.Var

var A_arbace_core_reducers__init_A_const_86 any

var A_arbace_core_reducers__init_A_const_87 *lang.Var

var A_arbace_core_reducers__init_A_const_88 any

var A_arbace_core_reducers__init_A_const_89 *lang.Var

var A_arbace_core_reducers__init_A_const_90 *lang.Keyword

var A_arbace_core_reducers__init_A_const_91 *jrt.Class

var A_arbace_core_reducers__init_A_const_92 *jrt.Class

var A_arbace_core_reducers__init_A_const_93 *jrt.Class

var A_arbace_core_reducers__init_A_init jrt.ClassInit

func A_arbace_core_reducers__init_A_Init() { if !A_arbace_core_reducers__init_A_init.Done() { A_arbace_core_reducers__init_A_init.Run(A_arbace_core_reducers__init_A_clinit) } }

func A_arbace_core_reducers__init_A_clinit() { A_arbace_core_reducers__init_A_clinit_p0(); A_arbace_core_reducers__init_A_clinit_p1(); A_arbace_core_reducers__init_A_clinit_p2(); A_arbace_core_reducers__init_A_clinit_p3(); A_arbace_core_reducers__init_A_clinit_p4(); A_arbace_core_reducers__init_A_clinit_p5(); A_arbace_core_reducers__init_A_clinit_p6(); A_arbace_core_reducers__init_A_clinit_p7() }

func A_arbace_core_reducers__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_reducers__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_39, 143); A_arbace_core_reducers__init_A_const_0 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[49]); A_arbace_core_reducers__init_A_const_1 = A_arbace_core_reducers__init_A_const_pool.A[50]; A_arbace_core_reducers__init_A_const_2 = A_arbace_core_reducers__init_A_const_pool.A[51]; A_arbace_core_reducers__init_A_const_3 = A_arbace_core_reducers__init_A_const_pool.A[52]; A_arbace_core_reducers__init_A_const_4 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[53]); A_arbace_core_reducers__init_A_const_5 = A_arbace_core_reducers__init_A_const_pool.A[54]; A_arbace_core_reducers__init_A_const_6 = A_arbace_core_reducers__init_A_const_pool.A[55]; A_arbace_core_reducers__init_A_const_7 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[56]); A_arbace_core_reducers__init_A_const_8 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[57]); A_arbace_core_reducers__init_A_const_9 = A_arbace_core_reducers__init_A_const_pool.A[58]; A_arbace_core_reducers__init_A_const_10 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[59]); A_arbace_core_reducers__init_A_const_11 = A_arbace_core_reducers__init_A_const_pool.A[60]; A_arbace_core_reducers__init_A_const_12 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[61]) }

func A_arbace_core_reducers__init_A_clinit_p1() { A_arbace_core_reducers__init_A_const_13 = A_arbace_core_reducers__init_A_const_pool.A[62]; A_arbace_core_reducers__init_A_const_14 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[63]); A_arbace_core_reducers__init_A_const_15 = A_arbace_core_reducers__init_A_const_pool.A[64]; A_arbace_core_reducers__init_A_const_16 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[65]); A_arbace_core_reducers__init_A_const_17 = A_arbace_core_reducers__init_A_const_pool.A[66]; A_arbace_core_reducers__init_A_const_18 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[67]); A_arbace_core_reducers__init_A_const_19 = A_arbace_core_reducers__init_A_const_pool.A[68]; A_arbace_core_reducers__init_A_const_20 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[69]); A_arbace_core_reducers__init_A_const_21 = A_arbace_core_reducers__init_A_const_pool.A[70]; A_arbace_core_reducers__init_A_const_22 = A_arbace_core_reducers__init_A_const_pool.A[71]; A_arbace_core_reducers__init_A_const_23 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[72]); A_arbace_core_reducers__init_A_const_24 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[73]); A_arbace_core_reducers__init_A_const_25 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[74]) }

func A_arbace_core_reducers__init_A_clinit_p2() { A_arbace_core_reducers__init_A_const_26 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[75]); A_arbace_core_reducers__init_A_const_27 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[76]); A_arbace_core_reducers__init_A_const_28 = A_arbace_core_reducers__init_A_const_pool.A[77]; A_arbace_core_reducers__init_A_const_29 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[78]); A_arbace_core_reducers__init_A_const_30 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[79]); A_arbace_core_reducers__init_A_const_31 = A_arbace_core_reducers__init_A_const_pool.A[80]; A_arbace_core_reducers__init_A_const_32 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[81]); A_arbace_core_reducers__init_A_const_33 = A_arbace_core_reducers__init_A_const_pool.A[82]; A_arbace_core_reducers__init_A_const_34 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[83]); A_arbace_core_reducers__init_A_const_35 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[84]); A_arbace_core_reducers__init_A_const_36 = A_arbace_core_reducers__init_A_const_pool.A[85]; A_arbace_core_reducers__init_A_const_37 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[86]); A_arbace_core_reducers__init_A_const_38 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[87]) }

func A_arbace_core_reducers__init_A_clinit_p3() { A_arbace_core_reducers__init_A_const_39 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[88]); A_arbace_core_reducers__init_A_const_40 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[89]); A_arbace_core_reducers__init_A_const_41 = A_arbace_core_reducers__init_A_const_pool.A[90]; A_arbace_core_reducers__init_A_const_42 = A_arbace_core_reducers__init_A_const_pool.A[91]; A_arbace_core_reducers__init_A_const_43 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[92]); A_arbace_core_reducers__init_A_const_44 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[93]); A_arbace_core_reducers__init_A_const_45 = A_arbace_core_reducers__init_A_const_pool.A[94]; A_arbace_core_reducers__init_A_const_46 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[95]); A_arbace_core_reducers__init_A_const_47 = A_arbace_core_reducers__init_A_const_pool.A[96]; A_arbace_core_reducers__init_A_const_48 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[97]); A_arbace_core_reducers__init_A_const_49 = A_arbace_core_reducers__init_A_const_pool.A[98]; A_arbace_core_reducers__init_A_const_50 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[99]); A_arbace_core_reducers__init_A_const_51 = A_arbace_core_reducers__init_A_const_pool.A[100] }

func A_arbace_core_reducers__init_A_clinit_p4() { A_arbace_core_reducers__init_A_const_52 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[101]); A_arbace_core_reducers__init_A_const_53 = A_arbace_core_reducers__init_A_const_pool.A[102]; A_arbace_core_reducers__init_A_const_54 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[103]); A_arbace_core_reducers__init_A_const_55 = A_arbace_core_reducers__init_A_const_pool.A[104]; A_arbace_core_reducers__init_A_const_56 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[105]); A_arbace_core_reducers__init_A_const_57 = A_arbace_core_reducers__init_A_const_pool.A[106]; A_arbace_core_reducers__init_A_const_58 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[107]); A_arbace_core_reducers__init_A_const_59 = A_arbace_core_reducers__init_A_const_pool.A[108]; A_arbace_core_reducers__init_A_const_60 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[109]); A_arbace_core_reducers__init_A_const_61 = A_arbace_core_reducers__init_A_const_pool.A[110]; A_arbace_core_reducers__init_A_const_62 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[111]); A_arbace_core_reducers__init_A_const_63 = A_arbace_core_reducers__init_A_const_pool.A[112]; A_arbace_core_reducers__init_A_const_64 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[113]) }

func A_arbace_core_reducers__init_A_clinit_p5() { A_arbace_core_reducers__init_A_const_65 = A_arbace_core_reducers__init_A_const_pool.A[114]; A_arbace_core_reducers__init_A_const_66 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[115]); A_arbace_core_reducers__init_A_const_67 = A_arbace_core_reducers__init_A_const_pool.A[116]; A_arbace_core_reducers__init_A_const_68 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[117]); A_arbace_core_reducers__init_A_const_69 = A_arbace_core_reducers__init_A_const_pool.A[118]; A_arbace_core_reducers__init_A_const_70 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[119]); A_arbace_core_reducers__init_A_const_71 = A_arbace_core_reducers__init_A_const_pool.A[120]; A_arbace_core_reducers__init_A_const_72 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[121]); A_arbace_core_reducers__init_A_const_73 = A_arbace_core_reducers__init_A_const_pool.A[122]; A_arbace_core_reducers__init_A_const_74 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[123]); A_arbace_core_reducers__init_A_const_75 = A_arbace_core_reducers__init_A_const_pool.A[124]; A_arbace_core_reducers__init_A_const_76 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[125]); A_arbace_core_reducers__init_A_const_77 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[126]) }

func A_arbace_core_reducers__init_A_clinit_p6() { A_arbace_core_reducers__init_A_const_78 = A_arbace_core_reducers__init_A_const_pool.A[127]; A_arbace_core_reducers__init_A_const_79 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[128]); A_arbace_core_reducers__init_A_const_80 = A_arbace_core_reducers__init_A_const_pool.A[129]; A_arbace_core_reducers__init_A_const_81 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[130]); A_arbace_core_reducers__init_A_const_82 = A_arbace_core_reducers__init_A_const_pool.A[131]; A_arbace_core_reducers__init_A_const_83 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[132]); A_arbace_core_reducers__init_A_const_84 = A_arbace_core_reducers__init_A_const_pool.A[133]; A_arbace_core_reducers__init_A_const_85 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[134]); A_arbace_core_reducers__init_A_const_86 = A_arbace_core_reducers__init_A_const_pool.A[135]; A_arbace_core_reducers__init_A_const_87 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[136]); A_arbace_core_reducers__init_A_const_88 = A_arbace_core_reducers__init_A_const_pool.A[137]; A_arbace_core_reducers__init_A_const_89 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[138]); A_arbace_core_reducers__init_A_const_90 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[139]) }

func A_arbace_core_reducers__init_A_clinit_p7() { A_arbace_core_reducers__init_A_const_91 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[140]); A_arbace_core_reducers__init_A_const_92 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[141]); A_arbace_core_reducers__init_A_const_93 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[142]) }

func A_arbace_core_reducers__init_A_New() *A_arbace_core_reducers__init_A { A_arbace_core_reducers__init_A_Init(); t := &A_arbace_core_reducers__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers__init_A) Ctor() {}

func (t *A_arbace_core_reducers__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers__init_A_class }

func (t *A_arbace_core_reducers__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers__init_A); return ok }

func A_arbace_core_reducers__init_A_Cast(x any) *A_arbace_core_reducers__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers__init_A_class)) }; return v }
