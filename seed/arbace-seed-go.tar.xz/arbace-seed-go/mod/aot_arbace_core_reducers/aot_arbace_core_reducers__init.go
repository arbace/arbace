//line aot_arbace_core_reducers__init.ae:1
package aot_arbace_core_reducers

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_reducers__init_A_Load__O() any { A_arbace_core_reducers__init_A_Init(); A_arbace_core_reducers__init_A_Unit0__O(); A_arbace_core_reducers__init_A_Unit1__O(); A_arbace_core_reducers__init_A_Unit2__O(); A_arbace_core_reducers__init_A_Unit3__O(); A_arbace_core_reducers__init_A_Unit4__O(); A_arbace_core_reducers__init_A_Unit5__O(); A_arbace_core_reducers__init_A_Unit6__O(); A_arbace_core_reducers__init_A_Unit7__O(); A_arbace_core_reducers__init_A_Unit8__O(); A_arbace_core_reducers__init_A_Unit9__O(); A_arbace_core_reducers__init_A_Unit10__O(); A_arbace_core_reducers__init_A_Unit11__O(); A_arbace_core_reducers__init_A_Unit12__O(); A_arbace_core_reducers__init_A_Unit13__O(); A_arbace_core_reducers__init_A_Unit14__O(); A_arbace_core_reducers__init_A_Unit15__O(); A_arbace_core_reducers__init_A_Unit16__O(); A_arbace_core_reducers__init_A_Unit17__O(); A_arbace_core_reducers__init_A_Unit18__O(); A_arbace_core_reducers__init_A_Unit19__O(); A_arbace_core_reducers__init_A_Unit20__O(); A_arbace_core_reducers__init_A_Unit21__O(); A_arbace_core_reducers__init_A_Unit22__O(); A_arbace_core_reducers__init_A_Unit23__O(); A_arbace_core_reducers__init_A_Unit24__O(); A_arbace_core_reducers__init_A_Unit25__O(); A_arbace_core_reducers__init_A_Unit26__O(); A_arbace_core_reducers__init_A_Unit27__O(); A_arbace_core_reducers__init_A_Unit28__O(); A_arbace_core_reducers__init_A_Unit29__O(); A_arbace_core_reducers__init_A_Unit30__O(); A_arbace_core_reducers__init_A_Unit31__O(); A_arbace_core_reducers__init_A_Unit32__O(); A_arbace_core_reducers__init_A_Unit33__O(); A_arbace_core_reducers__init_A_Unit34__O(); A_arbace_core_reducers__init_A_Unit35__O(); A_arbace_core_reducers__init_A_Unit36__O(); A_arbace_core_reducers__init_A_Unit37__O(); A_arbace_core_reducers__init_A_Unit38__O(); A_arbace_core_reducers__init_A_Unit39__O(); A_arbace_core_reducers__init_A_Unit40__O(); A_arbace_core_reducers__init_A_Unit41__O(); A_arbace_core_reducers__init_A_Unit42__O(); A_arbace_core_reducers__init_A_Unit43__O(); A_arbace_core_reducers__init_A_Unit44__O(); A_arbace_core_reducers__init_A_Unit45__O(); A_arbace_core_reducers__init_A_Unit46__O(); A_arbace_core_reducers__init_A_Unit47__O(); return nil }



func A_arbace_core_reducers__init_A_Unit0__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers__init_A_const_1) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit1__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_2)) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit2__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New(); var tmp2 *jrt.Class; A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_Init(); tmp2 = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_core_reducers__init_A_Unit3__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1)).Equals_O__Z(A_arbace_core_reducers__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_core_reducers_eval153000008_fn__153000009_A_New(); var tmp2 *jrt.Class; A_arbace_core_reducers_eval153000008_fn__153000009_A_Init(); tmp2 = A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }







func A_arbace_core_reducers__init_A_Unit4__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_4).GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_reducers__init_A_const_5, A_arbace_core_reducers__init_A_const_6) }
func A_arbace_core_reducers__init_A_Unit5__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_7; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }



func A_arbace_core_reducers__init_A_Unit6__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_8; var tmp2 any = A_arbace_core_reducers_fn__153000016_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_fn__153000016_A_Init(); tmp3 = A_arbace_core_reducers_fn__153000016_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_9)); return A_arbace_core_reducers__init_A_const_8.Ref() }

func A_arbace_core_reducers__init_A_Unit7__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_10; var tmp2 any = A_arbace_core_reducers_fjtask_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_fjtask_A_Init(); tmp3 = A_arbace_core_reducers_fjtask_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_11)); return A_arbace_core_reducers__init_A_const_10.Ref() }


func A_arbace_core_reducers__init_A_Unit8__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_12; var tmp2 any = A_arbace_core_reducers_fjinvoke_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_fjinvoke_A_Init(); tmp3 = A_arbace_core_reducers_fjinvoke_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_13)); return A_arbace_core_reducers__init_A_const_12.Ref() }




func A_arbace_core_reducers__init_A_Unit9__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_14; var tmp2 any = A_arbace_core_reducers_fjfork_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_fjfork_A_Init(); tmp3 = A_arbace_core_reducers_fjfork_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_15)); return A_arbace_core_reducers__init_A_const_14.Ref() }

func A_arbace_core_reducers__init_A_Unit10__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_16; var tmp2 any = A_arbace_core_reducers_fjjoin_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_fjjoin_A_Init(); tmp3 = A_arbace_core_reducers_fjjoin_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_17)); return A_arbace_core_reducers__init_A_const_16.Ref() }



func A_arbace_core_reducers__init_A_Unit11__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_18; var tmp2 any = A_arbace_core_reducers_reduce_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_reduce_A_Init(); tmp3 = A_arbace_core_reducers_reduce_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_19)); return A_arbace_core_reducers__init_A_const_18.Ref() }









func A_arbace_core_reducers__init_A_Unit12__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_20; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_21)); v__1927001498__auto____1 = A_arbace_core_reducers__init_A_const_20.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_20; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_22)); var tmp3 *lang.Var = A_arbace_core_reducers__init_A_const_20; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_core_reducers__init_A_const_20.Ref() } }
//line :48:1
func A_arbace_core_reducers__init_A_Unit13__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_core_reducers__init_A_const_23.Ref() }
//line :48:1
func A_arbace_core_reducers__init_A_Unit14__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_24).GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_core_reducers__init_A_const_25).GetRawRoot__O(), A_arbace_core_reducers__init_A_const_26.Ref(), nil) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit15__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return Up_Var_IFn(A_arbace_core_reducers__init_A_const_27).Invoke_O_O__O(A_arbace_core_reducers__init_A_const_20.Ref(), A_arbace_core_reducers__init_A_const_28) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit16__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_29).GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20.Ref(); var tmp3 any = jrt.NN(A_arbace_core_reducers__init_A_const_30).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_25).GetRawRoot__O()); var tmp5 any = A_arbace_core_reducers__init_A_const_31; var tmp6 any = A_arbace_core_reducers__init_A_const_32.Ref(); var tmp7 any = A_arbace_core_reducers__init_A_const_33; var tmp8 any = A_arbace_core_reducers__init_A_const_34.Ref(); var tmp9 any = A_arbace_core_reducers__init_A_const_20.Ref(); var tmp10 any = A_arbace_core_reducers__init_A_const_35.Ref(); var tmp11 any = A_arbace_core_reducers__init_A_const_36; var tmp12 any = A_arbace_core_reducers__init_A_const_37.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_40).GetRawRoot__O()); var tmp14 any = A_arbace_core_reducers__init_A_const_41; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_30).GetRawRoot__O()); var tmp16 any = A_arbace_core_reducers__init_A_const_42; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_38).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_core_reducers__init_A_const_39).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_reducers__init_A_const_43.Ref(), A_arbace_core_reducers__init_A_const_20.Ref()))))); var tmp18 any = A_arbace_core_reducers_eval153000031_fn__153000032_A_New(); var tmp19 *jrt.Class; A_arbace_core_reducers_eval153000031_fn__153000032_A_Init(); tmp19 = A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit17__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_44).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_core_reducers__init_A_const_20).GetRawRoot__O()) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit18__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_core_reducers__init_A_const_45 }


func A_arbace_core_reducers__init_A_Unit19__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_46; var tmp2 any = A_arbace_core_reducers_fold_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_fold_A_Init(); tmp3 = A_arbace_core_reducers_fold_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_47)); return A_arbace_core_reducers__init_A_const_46.Ref() }















func A_arbace_core_reducers__init_A_Unit20__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_48; var tmp2 any = A_arbace_core_reducers_reducer_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_reducer_A_Init(); tmp3 = A_arbace_core_reducers_reducer_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_49)); return A_arbace_core_reducers__init_A_const_48.Ref() }













func A_arbace_core_reducers__init_A_Unit21__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_50; var tmp2 any = A_arbace_core_reducers_folder_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_folder_A_Init(); tmp3 = A_arbace_core_reducers_folder_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_51)); return A_arbace_core_reducers__init_A_const_50.Ref() }

















func A_arbace_core_reducers__init_A_Unit22__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_52; var tmp2 any = A_arbace_core_reducers_do_curried_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_do_curried_A_Init(); tmp3 = A_arbace_core_reducers_do_curried_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_53)); return A_arbace_core_reducers__init_A_const_52.Ref() }






func A_arbace_core_reducers__init_A_Unit23__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_54; var tmp2 any = A_arbace_core_reducers_defcurried_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_defcurried_A_Init(); tmp3 = A_arbace_core_reducers_defcurried_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 6)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_55)); return A_arbace_core_reducers__init_A_const_54.Ref() }
//line :106:1
func A_arbace_core_reducers__init_A_Unit24__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); jrt.NN(A_arbace_core_reducers__init_A_const_54).SetMacro__V(); return nil }
//line :106:1
func A_arbace_core_reducers__init_A_Unit25__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); return A_arbace_core_reducers__init_A_const_54.Ref() }





func A_arbace_core_reducers__init_A_Unit26__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(112, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_56; var tmp2 any = A_arbace_core_reducers_do_rfn_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_do_rfn_A_Init(); tmp3 = A_arbace_core_reducers_do_rfn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_57)); return A_arbace_core_reducers__init_A_const_56.Ref() }










func A_arbace_core_reducers__init_A_Unit27__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_58; var tmp2 any = A_arbace_core_reducers_rfn_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_rfn_A_Init(); tmp3 = A_arbace_core_reducers_rfn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_59)); return A_arbace_core_reducers__init_A_const_58.Ref() }
//line :123:1
func A_arbace_core_reducers__init_A_Unit28__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); jrt.NN(A_arbace_core_reducers__init_A_const_58).SetMacro__V(); return nil }
//line :123:1
func A_arbace_core_reducers__init_A_Unit29__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); return A_arbace_core_reducers__init_A_const_58.Ref() }




func A_arbace_core_reducers__init_A_Unit30__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_60; var tmp2 any = A_arbace_core_reducers_map_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_map_A_Init(); tmp3 = A_arbace_core_reducers_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_61)); return A_arbace_core_reducers__init_A_const_60.Ref() }









func A_arbace_core_reducers__init_A_Unit31__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_62; var tmp2 any = A_arbace_core_reducers_mapcat_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_mapcat_A_Init(); tmp3 = A_arbace_core_reducers_mapcat_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_63)); return A_arbace_core_reducers__init_A_const_62.Ref() }















func A_arbace_core_reducers__init_A_Unit32__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_64; var tmp2 any = A_arbace_core_reducers_filter_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_filter_A_Init(); tmp3 = A_arbace_core_reducers_filter_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_65)); return A_arbace_core_reducers__init_A_const_64.Ref() }












func A_arbace_core_reducers__init_A_Unit33__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_66; var tmp2 any = A_arbace_core_reducers_remove_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_remove_A_Init(); tmp3 = A_arbace_core_reducers_remove_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_67)); return A_arbace_core_reducers__init_A_const_66.Ref() }






func A_arbace_core_reducers__init_A_Unit34__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(174, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_68; var tmp2 any = A_arbace_core_reducers_flatten_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_flatten_A_Init(); tmp3 = A_arbace_core_reducers_flatten_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_69)); return A_arbace_core_reducers__init_A_const_68.Ref() }














func A_arbace_core_reducers__init_A_Unit35__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(189, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_70; var tmp2 any = A_arbace_core_reducers_take_while_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_take_while_A_Init(); tmp3 = A_arbace_core_reducers_take_while_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_71)); return A_arbace_core_reducers__init_A_const_70.Ref() }











func A_arbace_core_reducers__init_A_Unit36__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_72; var tmp2 any = A_arbace_core_reducers_take_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_take_A_Init(); tmp3 = A_arbace_core_reducers_take_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_73)); return A_arbace_core_reducers__init_A_const_72.Ref() }













func A_arbace_core_reducers__init_A_Unit37__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(215, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_74; var tmp2 any = A_arbace_core_reducers_drop_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_drop_A_Init(); tmp3 = A_arbace_core_reducers_drop_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_75)); return A_arbace_core_reducers__init_A_const_74.Ref() }














func A_arbace_core_reducers__init_A_Unit38__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(230, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_201)); var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_77; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_78)); var tmp3 *lang.Var = A_arbace_core_reducers__init_A_const_77; var tmp4 any = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New(); var tmp5 *jrt.Class; A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_Init(); tmp5 = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_core_reducers__init_A_const_76.Ref() }
























func A_arbace_core_reducers__init_A_Unit39__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_79; var tmp2 any = A_arbace_core_reducers_cat_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_cat_A_Init(); tmp3 = A_arbace_core_reducers_cat_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_79; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_80)); return A_arbace_core_reducers__init_A_const_79.Ref() }



















func A_arbace_core_reducers__init_A_Unit40__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(275, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_81; var tmp2 any = A_arbace_core_reducers_append_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_append_BANG__A_Init(); tmp3 = A_arbace_core_reducers_append_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_81; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_82)); return A_arbace_core_reducers__init_A_const_81.Ref() }





func A_arbace_core_reducers__init_A_Unit41__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(281, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_83; var tmp2 any = A_arbace_core_reducers_foldcat_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_foldcat_A_Init(); tmp3 = A_arbace_core_reducers_foldcat_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_83; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_84)); return A_arbace_core_reducers__init_A_const_83.Ref() }





func A_arbace_core_reducers__init_A_Unit42__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_85; var tmp2 any = A_arbace_core_reducers_monoid_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_monoid_A_Init(); tmp3 = A_arbace_core_reducers_monoid_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_85; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_86)); return A_arbace_core_reducers__init_A_const_85.Ref() }










func A_arbace_core_reducers__init_A_Unit43__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(298, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_87; var tmp2 any = A_arbace_core_reducers_foldvec_A_New(); var tmp3 *jrt.Class; A_arbace_core_reducers_foldvec_A_Init(); tmp3 = A_arbace_core_reducers_foldvec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_87; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_88)); return A_arbace_core_reducers__init_A_const_87.Ref() }















func A_arbace_core_reducers__init_A_Unit44__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_89).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_core_reducers__init_A_const_20).GetRawRoot__O(); var tmp3 any = A_arbace_core_reducers__init_A_const_90.Ref(); var tmp4 any = A_arbace_core_reducers_eval153000157_fn__153000158_A_New(); var tmp5 *jrt.Class; A_arbace_core_reducers_eval153000157_fn__153000158_A_Init(); tmp5 = A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit45__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_89).GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_91.Ref(); var tmp3 any = jrt.NN(A_arbace_core_reducers__init_A_const_20).GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90.Ref(); var tmp5 any = A_arbace_core_reducers_eval153000161_fn__153000162_A_New(); var tmp6 *jrt.Class; A_arbace_core_reducers_eval153000161_fn__153000162_A_Init(); tmp6 = A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit46__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_89).GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_92.Ref(); var tmp3 any = jrt.NN(A_arbace_core_reducers__init_A_const_20).GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90.Ref(); var tmp5 any = A_arbace_core_reducers_eval153000165_fn__153000166_A_New(); var tmp6 *jrt.Class; A_arbace_core_reducers_eval153000165_fn__153000166_A_Init(); tmp6 = A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit47__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers__init_A_const_89).GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_93.Ref(); var tmp3 any = jrt.NN(A_arbace_core_reducers__init_A_const_20).GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90.Ref(); var tmp5 any = A_arbace_core_reducers_eval153000169_fn__153000170_A_New(); var tmp6 *jrt.Class; A_arbace_core_reducers_eval153000169_fn__153000170_A_Init(); tmp6 = A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }









type A_arbace_core_reducers__init_A struct{ jrt.Object }

var A_arbace_core_reducers__init_A_const_0 *lang.Var

var A_arbace_core_reducers__init_A_const_1 any

var A_arbace_core_reducers__init_A_const_2 any

var A_arbace_core_reducers__init_A_const_3 any

var A_arbace_core_reducers__init_A_const_4 *lang.Var

var A_arbace_core_reducers__init_A_const_5 any

var A_arbace_core_reducers__init_A_const_6 any

var A_arbace_core_reducers__init_A_const_7 *lang.Var

var A_arbace_core_reducers__init_A_const_8 *lang.Var

var A_arbace_core_reducers__init_A_const_9 any

var A_arbace_core_reducers__init_A_const_10 *lang.Var

var A_arbace_core_reducers__init_A_const_11 any

var A_arbace_core_reducers__init_A_const_12 *lang.Var

var A_arbace_core_reducers__init_A_const_13 any

var A_arbace_core_reducers__init_A_const_14 *lang.Var

var A_arbace_core_reducers__init_A_const_15 any

var A_arbace_core_reducers__init_A_const_16 *lang.Var

var A_arbace_core_reducers__init_A_const_17 any

var A_arbace_core_reducers__init_A_const_18 *lang.Var

var A_arbace_core_reducers__init_A_const_19 any

var A_arbace_core_reducers__init_A_const_20 *lang.Var

var A_arbace_core_reducers__init_A_const_21 any

var A_arbace_core_reducers__init_A_const_22 any

var A_arbace_core_reducers__init_A_const_23 *jrt.Class

var A_arbace_core_reducers__init_A_const_24 *lang.Var

var A_arbace_core_reducers__init_A_const_25 *lang.Var

var A_arbace_core_reducers__init_A_const_26 *lang.Keyword

var A_arbace_core_reducers__init_A_const_27 *lang.Var

var A_arbace_core_reducers__init_A_const_28 any

var A_arbace_core_reducers__init_A_const_29 *lang.Var

var A_arbace_core_reducers__init_A_const_30 *lang.Var

var A_arbace_core_reducers__init_A_const_31 any

var A_arbace_core_reducers__init_A_const_32 *lang.Keyword

var A_arbace_core_reducers__init_A_const_33 any

var A_arbace_core_reducers__init_A_const_34 *lang.Keyword

var A_arbace_core_reducers__init_A_const_35 *lang.Keyword

var A_arbace_core_reducers__init_A_const_36 any

var A_arbace_core_reducers__init_A_const_37 *lang.Keyword

var A_arbace_core_reducers__init_A_const_38 *lang.Var

var A_arbace_core_reducers__init_A_const_39 *lang.Var

var A_arbace_core_reducers__init_A_const_40 *lang.Var

var A_arbace_core_reducers__init_A_const_41 any

var A_arbace_core_reducers__init_A_const_42 any

var A_arbace_core_reducers__init_A_const_43 *lang.Keyword

var A_arbace_core_reducers__init_A_const_44 *lang.Var

var A_arbace_core_reducers__init_A_const_45 any

var A_arbace_core_reducers__init_A_const_46 *lang.Var

var A_arbace_core_reducers__init_A_const_47 any

var A_arbace_core_reducers__init_A_const_48 *lang.Var

var A_arbace_core_reducers__init_A_const_49 any

var A_arbace_core_reducers__init_A_const_50 *lang.Var

var A_arbace_core_reducers__init_A_const_51 any

var A_arbace_core_reducers__init_A_const_52 *lang.Var

var A_arbace_core_reducers__init_A_const_53 any

var A_arbace_core_reducers__init_A_const_54 *lang.Var

var A_arbace_core_reducers__init_A_const_55 any

var A_arbace_core_reducers__init_A_const_56 *lang.Var

var A_arbace_core_reducers__init_A_const_57 any

var A_arbace_core_reducers__init_A_const_58 *lang.Var

var A_arbace_core_reducers__init_A_const_59 any

var A_arbace_core_reducers__init_A_const_60 *lang.Var

var A_arbace_core_reducers__init_A_const_61 any

var A_arbace_core_reducers__init_A_const_62 *lang.Var

var A_arbace_core_reducers__init_A_const_63 any

var A_arbace_core_reducers__init_A_const_64 *lang.Var

var A_arbace_core_reducers__init_A_const_65 any

var A_arbace_core_reducers__init_A_const_66 *lang.Var

var A_arbace_core_reducers__init_A_const_67 any

var A_arbace_core_reducers__init_A_const_68 *lang.Var

var A_arbace_core_reducers__init_A_const_69 any

var A_arbace_core_reducers__init_A_const_70 *lang.Var

var A_arbace_core_reducers__init_A_const_71 any

var A_arbace_core_reducers__init_A_const_72 *lang.Var

var A_arbace_core_reducers__init_A_const_73 any

var A_arbace_core_reducers__init_A_const_74 *lang.Var

var A_arbace_core_reducers__init_A_const_75 any

var A_arbace_core_reducers__init_A_const_76 *jrt.Class

var A_arbace_core_reducers__init_A_const_77 *lang.Var

var A_arbace_core_reducers__init_A_const_78 any

var A_arbace_core_reducers__init_A_const_79 *lang.Var

var A_arbace_core_reducers__init_A_const_80 any

var A_arbace_core_reducers__init_A_const_81 *lang.Var

var A_arbace_core_reducers__init_A_const_82 any

var A_arbace_core_reducers__init_A_const_83 *lang.Var

var A_arbace_core_reducers__init_A_const_84 any

var A_arbace_core_reducers__init_A_const_85 *lang.Var

var A_arbace_core_reducers__init_A_const_86 any

var A_arbace_core_reducers__init_A_const_87 *lang.Var

var A_arbace_core_reducers__init_A_const_88 any

var A_arbace_core_reducers__init_A_const_89 *lang.Var

var A_arbace_core_reducers__init_A_const_90 *lang.Keyword

var A_arbace_core_reducers__init_A_const_91 *jrt.Class

var A_arbace_core_reducers__init_A_const_92 *jrt.Class

var A_arbace_core_reducers__init_A_const_93 *jrt.Class

var A_arbace_core_reducers__init_A_init jrt.ClassInit

func A_arbace_core_reducers__init_A_Init() { if !A_arbace_core_reducers__init_A_init.Done() { A_arbace_core_reducers__init_A_init.Run(A_arbace_core_reducers__init_A_clinit) } }

func A_arbace_core_reducers__init_A_clinit() { A_arbace_core_reducers__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_core_reducers__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_22, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24))); A_arbace_core_reducers__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_22, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24)); A_arbace_core_reducers__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_reducers__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_138); A_arbace_core_reducers__init_A_const_5 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_139).Ref(); A_arbace_core_reducers__init_A_const_6 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_reducers__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_140); A_arbace_core_reducers__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_20, Lit_27); A_arbace_core_reducers__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_20, Lit_26); A_arbace_core_reducers__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_148).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_20, Lit_63); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_core_reducers__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_20, Lit_64); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_core_reducers__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_150).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_20, Lit_65); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_core_reducers__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_150).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_20, Lit_4); A_arbace_core_reducers__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_153, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_20, Lit_154); A_arbace_core_reducers__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_23 = lang.RT_ClassForNameNonLoading_String__Class(Lit_32); A_arbace_core_reducers__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_155); A_arbace_core_reducers__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_156); A_arbace_core_reducers__init_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_21); A_arbace_core_reducers__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_157); A_arbace_core_reducers__init_A_const_28 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref())))))))))); A_arbace_core_reducers__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_161); A_arbace_core_reducers__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_162); A_arbace_core_reducers__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_164).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_32).Ref())); A_arbace_core_reducers__init_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_165); A_arbace_core_reducers__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), nil)))); A_arbace_core_reducers__init_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_167); A_arbace_core_reducers__init_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_168); A_arbace_core_reducers__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_33).Ref())); A_arbace_core_reducers__init_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_169); A_arbace_core_reducers__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_170); A_arbace_core_reducers__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_171); A_arbace_core_reducers__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_172); A_arbace_core_reducers__init_A_const_41 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))))))); A_arbace_core_reducers__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), nil)); A_arbace_core_reducers__init_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_173); A_arbace_core_reducers__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_174); A_arbace_core_reducers__init_A_const_45 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_154).Ref(); A_arbace_core_reducers__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_20, Lit_34); A_arbace_core_reducers__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref()), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_175, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(51).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_20, Lit_54); A_arbace_core_reducers__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_178).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_179, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(67).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_20, Lit_51); A_arbace_core_reducers__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_178).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_180, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(81).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_20, Lit_45); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_core_reducers__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_20, Lit_184); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_core_reducers__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_186, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(106).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_20, Lit_50); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_core_reducers__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_188).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(112).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_20, Lit_190); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_core_reducers__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_188).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_191, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(123).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_20, Lit_5); A_arbace_core_reducers__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_192, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_20, Lit_6); A_arbace_core_reducers__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_193, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(138).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_20, Lit_7); A_arbace_core_reducers__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_195, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(154).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_20, Lit_8); A_arbace_core_reducers__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_196, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(167).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_20, Lit_12); A_arbace_core_reducers__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_197, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(174).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_20, Lit_10); A_arbace_core_reducers__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_198, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(189).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_20, Lit_9); A_arbace_core_reducers__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_199, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(201).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_20, Lit_11); A_arbace_core_reducers__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_200, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(215).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_76 = lang.RT_ClassForNameNonLoading_String__Class(Lit_201); A_arbace_core_reducers__init_A_const_77 = lang.RT_Var_String_String__Var(Lit_20, Lit_202); A_arbace_core_reducers__init_A_const_78 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_203, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(230).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_79 = lang.RT_Var_String_String__Var(Lit_20, Lit_13); A_arbace_core_reducers__init_A_const_80 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_204).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_205, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(255).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_81 = lang.RT_Var_String_String__Var(Lit_20, Lit_59); A_arbace_core_reducers__init_A_const_82 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_206)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_207).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_208).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_209, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(275).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_83 = lang.RT_Var_String_String__Var(Lit_20, Lit_210); A_arbace_core_reducers__init_A_const_84 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_211, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(281).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_85 = lang.RT_Var_String_String__Var(Lit_20, Lit_212); A_arbace_core_reducers__init_A_const_86 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_213).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_204).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_214, lang.RT_Keyword_String_String__Keyword(nil, Lit_176).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(287).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_87 = lang.RT_Var_String_String__Var(Lit_20, Lit_62); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_core_reducers__init_A_const_88 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_145).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_215).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_141).Ref(), jrt.Integer_ValueOf_I__Integer(298).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), Lit_144)); A_arbace_core_reducers__init_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_216); A_arbace_core_reducers__init_A_const_90 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_core_reducers__init_A_const_91 = lang.RT_ClassForNameNonLoading_String__Class(Lit_217); A_arbace_core_reducers__init_A_const_92 = lang.RT_ClassForNameNonLoading_String__Class(Lit_218); A_arbace_core_reducers__init_A_const_93 = lang.RT_ClassForNameNonLoading_String__Class(Lit_219) }

func A_arbace_core_reducers__init_A_New() *A_arbace_core_reducers__init_A { A_arbace_core_reducers__init_A_Init(); t := &A_arbace_core_reducers__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers__init_A) Ctor() {}

func (t *A_arbace_core_reducers__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers__init_A_class }

func (t *A_arbace_core_reducers__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers__init_A); return ok }

func A_arbace_core_reducers__init_A_Cast(x any) *A_arbace_core_reducers__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers__init_A_class)) }; return v }
