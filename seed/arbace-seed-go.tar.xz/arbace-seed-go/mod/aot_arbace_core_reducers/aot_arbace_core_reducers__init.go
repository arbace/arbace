//line aot_arbace_core_reducers__init.ae:1
package aot_arbace_core_reducers

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_reducers__init_A_Load__O() any { A_arbace_core_reducers__init_A_Init(); A_arbace_core_reducers__init_A_Unit0__O(); A_arbace_core_reducers__init_A_Unit1__O(); A_arbace_core_reducers__init_A_Unit2__O(); A_arbace_core_reducers__init_A_Unit3__O(); A_arbace_core_reducers__init_A_Unit4__O(); A_arbace_core_reducers__init_A_Unit5__O(); A_arbace_core_reducers__init_A_Unit6__O(); A_arbace_core_reducers__init_A_Unit7__O(); A_arbace_core_reducers__init_A_Unit8__O(); A_arbace_core_reducers__init_A_Unit9__O(); A_arbace_core_reducers__init_A_Unit10__O(); A_arbace_core_reducers__init_A_Unit11__O(); A_arbace_core_reducers__init_A_Unit12__O(); A_arbace_core_reducers__init_A_Unit13__O(); A_arbace_core_reducers__init_A_Unit14__O(); A_arbace_core_reducers__init_A_Unit15__O(); A_arbace_core_reducers__init_A_Unit16__O(); A_arbace_core_reducers__init_A_Unit17__O(); A_arbace_core_reducers__init_A_Unit18__O(); A_arbace_core_reducers__init_A_Unit19__O(); A_arbace_core_reducers__init_A_Unit20__O(); A_arbace_core_reducers__init_A_Unit21__O(); A_arbace_core_reducers__init_A_Unit22__O(); A_arbace_core_reducers__init_A_Unit23__O(); A_arbace_core_reducers__init_A_Unit24__O(); A_arbace_core_reducers__init_A_Unit25__O(); A_arbace_core_reducers__init_A_Unit26__O(); A_arbace_core_reducers__init_A_Unit27__O(); A_arbace_core_reducers__init_A_Unit28__O(); A_arbace_core_reducers__init_A_Unit29__O(); A_arbace_core_reducers__init_A_Unit30__O(); A_arbace_core_reducers__init_A_Unit31__O(); A_arbace_core_reducers__init_A_Unit32__O(); A_arbace_core_reducers__init_A_Unit33__O(); A_arbace_core_reducers__init_A_Unit34__O(); A_arbace_core_reducers__init_A_Unit35__O(); A_arbace_core_reducers__init_A_Unit36__O(); A_arbace_core_reducers__init_A_Unit37__O(); A_arbace_core_reducers__init_A_Unit38__O(); A_arbace_core_reducers__init_A_Unit39__O(); A_arbace_core_reducers__init_A_Unit40__O(); A_arbace_core_reducers__init_A_Unit41__O(); A_arbace_core_reducers__init_A_Unit42__O(); A_arbace_core_reducers__init_A_Unit43__O(); A_arbace_core_reducers__init_A_Unit44__O(); A_arbace_core_reducers__init_A_Unit45__O(); A_arbace_core_reducers__init_A_Unit46__O(); A_arbace_core_reducers__init_A_Unit47__O(); return nil }



func A_arbace_core_reducers__init_A_Unit0__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(A_arbace_core_reducers__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers__init_A_const_1) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit1__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_2)) }
//line :9:1
func A_arbace_core_reducers__init_A_Unit2__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_core_reducers__init_A_Unit3__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_reducers__init_A_const_1)).Equals_O__Z(A_arbace_core_reducers__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_core_reducers_eval153000008_fn__153000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }







func A_arbace_core_reducers__init_A_Unit4__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(A_arbace_core_reducers__init_A_const_4.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_reducers__init_A_const_5, A_arbace_core_reducers__init_A_const_6) }
func A_arbace_core_reducers__init_A_Unit5__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_7; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }



func A_arbace_core_reducers__init_A_Unit6__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_8; var tmp2 any = A_arbace_core_reducers_fn__153000016_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_core_reducers_fn__153000016_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_core_reducers_fn__153000016_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_9)); return A_arbace_core_reducers__init_A_const_8 }

func A_arbace_core_reducers__init_A_Unit7__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_10; var tmp2 any = A_arbace_core_reducers_fjtask_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_core_reducers_fjtask_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_core_reducers_fjtask_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_11)); return A_arbace_core_reducers__init_A_const_10 }


func A_arbace_core_reducers__init_A_Unit8__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_12; var tmp2 any = A_arbace_core_reducers_fjinvoke_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_core_reducers_fjinvoke_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_core_reducers_fjinvoke_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_13)); return A_arbace_core_reducers__init_A_const_12 }




func A_arbace_core_reducers__init_A_Unit9__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_14; var tmp2 any = A_arbace_core_reducers_fjfork_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_core_reducers_fjfork_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_core_reducers_fjfork_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_15)); return A_arbace_core_reducers__init_A_const_14 }

func A_arbace_core_reducers__init_A_Unit10__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_16; var tmp2 any = A_arbace_core_reducers_fjjoin_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_core_reducers_fjjoin_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_core_reducers_fjjoin_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_17)); return A_arbace_core_reducers__init_A_const_16 }



func A_arbace_core_reducers__init_A_Unit11__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_18; var tmp2 any = A_arbace_core_reducers_reduce_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_core_reducers_reduce_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_core_reducers_reduce_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_19)); return A_arbace_core_reducers__init_A_const_18 }









func A_arbace_core_reducers__init_A_Unit12__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_21)); v__1927001498__auto____1 = A_arbace_core_reducers__init_A_const_20; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_20; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_22)); var tmp3 *lang.Var = A_arbace_core_reducers__init_A_const_20; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_core_reducers__init_A_const_20 } }
//line :48:1
func A_arbace_core_reducers__init_A_Unit13__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_core_reducers__init_A_const_23 }
//line :48:1
func A_arbace_core_reducers__init_A_Unit14__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_reducers__init_A_const_25.GetRawRoot__O(), A_arbace_core_reducers__init_A_const_26, nil) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit15__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_core_reducers__init_A_const_27.Invoke_O_O__O(A_arbace_core_reducers__init_A_const_20, A_arbace_core_reducers__init_A_const_28) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit16__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_29.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20; var tmp3 any = A_arbace_core_reducers__init_A_const_30.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_core_reducers__init_A_const_31; var tmp6 any = A_arbace_core_reducers__init_A_const_32; var tmp7 any = A_arbace_core_reducers__init_A_const_33; var tmp8 any = A_arbace_core_reducers__init_A_const_34; var tmp9 any = A_arbace_core_reducers__init_A_const_20; var tmp10 any = A_arbace_core_reducers__init_A_const_35; var tmp11 any = A_arbace_core_reducers__init_A_const_36; var tmp12 any = A_arbace_core_reducers__init_A_const_37; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_core_reducers__init_A_const_41; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_30.GetRawRoot__O()); var tmp16 any = A_arbace_core_reducers__init_A_const_42; var tmp17 any = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_38.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_reducers__init_A_const_39.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_reducers__init_A_const_43, A_arbace_core_reducers__init_A_const_20))))); var tmp18 any = A_arbace_core_reducers_eval153000031_fn__153000032_A_New(); var tmp19 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class = fncls__9d; tmp19 = fncls__9d } else { tmp19 = fncls__9 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit17__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return lang.IFn_Cast(A_arbace_core_reducers__init_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers__init_A_const_20.GetRawRoot__O()) }
//line :48:1
func A_arbace_core_reducers__init_A_Unit18__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_core_reducers__init_A_const_45 }


func A_arbace_core_reducers__init_A_Unit19__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_46; var tmp2 any = A_arbace_core_reducers_fold_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_core_reducers_fold_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_core_reducers_fold_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_47)); return A_arbace_core_reducers__init_A_const_46 }















func A_arbace_core_reducers__init_A_Unit20__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_48; var tmp2 any = A_arbace_core_reducers_reducer_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_core_reducers_reducer_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_core_reducers_reducer_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_49)); return A_arbace_core_reducers__init_A_const_48 }













func A_arbace_core_reducers__init_A_Unit21__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_50; var tmp2 any = A_arbace_core_reducers_folder_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_reducers_folder_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_core_reducers_folder_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_51)); return A_arbace_core_reducers__init_A_const_50 }

















func A_arbace_core_reducers__init_A_Unit22__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_52; var tmp2 any = A_arbace_core_reducers_do_curried_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_core_reducers_do_curried_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_core_reducers_do_curried_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_53)); return A_arbace_core_reducers__init_A_const_52 }






func A_arbace_core_reducers__init_A_Unit23__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_54; var tmp2 any = A_arbace_core_reducers_defcurried_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_core_reducers_defcurried_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, true); A_arbace_core_reducers_defcurried_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 6)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_55)); return A_arbace_core_reducers__init_A_const_54 }
//line :106:1
func A_arbace_core_reducers__init_A_Unit24__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); A_arbace_core_reducers__init_A_const_54.SetMacro__V(); return nil }
//line :106:1
func A_arbace_core_reducers__init_A_Unit25__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); return A_arbace_core_reducers__init_A_const_54 }





func A_arbace_core_reducers__init_A_Unit26__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(112, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_56; var tmp2 any = A_arbace_core_reducers_do_rfn_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_core_reducers_do_rfn_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_core_reducers_do_rfn_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_57)); return A_arbace_core_reducers__init_A_const_56 }










func A_arbace_core_reducers__init_A_Unit27__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_58; var tmp2 any = A_arbace_core_reducers_rfn_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_reducers_rfn_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_core_reducers_rfn_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_59)); return A_arbace_core_reducers__init_A_const_58 }
//line :123:1
func A_arbace_core_reducers__init_A_Unit28__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); A_arbace_core_reducers__init_A_const_58.SetMacro__V(); return nil }
//line :123:1
func A_arbace_core_reducers__init_A_Unit29__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); return A_arbace_core_reducers__init_A_const_58 }




func A_arbace_core_reducers__init_A_Unit30__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_60; var tmp2 any = A_arbace_core_reducers_map_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_core_reducers_map_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_core_reducers_map_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_61)); return A_arbace_core_reducers__init_A_const_60 }









func A_arbace_core_reducers__init_A_Unit31__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_62; var tmp2 any = A_arbace_core_reducers_mapcat_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_core_reducers_mapcat_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_core_reducers_mapcat_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_63)); return A_arbace_core_reducers__init_A_const_62 }















func A_arbace_core_reducers__init_A_Unit32__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_64; var tmp2 any = A_arbace_core_reducers_filter_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_core_reducers_filter_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_core_reducers_filter_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_65)); return A_arbace_core_reducers__init_A_const_64 }












func A_arbace_core_reducers__init_A_Unit33__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_66; var tmp2 any = A_arbace_core_reducers_remove_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_core_reducers_remove_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_core_reducers_remove_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_67)); return A_arbace_core_reducers__init_A_const_66 }






func A_arbace_core_reducers__init_A_Unit34__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(174, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_68; var tmp2 any = A_arbace_core_reducers_flatten_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_core_reducers_flatten_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_core_reducers_flatten_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_69)); return A_arbace_core_reducers__init_A_const_68 }














func A_arbace_core_reducers__init_A_Unit35__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(189, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_70; var tmp2 any = A_arbace_core_reducers_take_while_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_core_reducers_take_while_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_core_reducers_take_while_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_71)); return A_arbace_core_reducers__init_A_const_70 }











func A_arbace_core_reducers__init_A_Unit36__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_72; var tmp2 any = A_arbace_core_reducers_take_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_core_reducers_take_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_core_reducers_take_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_73)); return A_arbace_core_reducers__init_A_const_72 }













func A_arbace_core_reducers__init_A_Unit37__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(215, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_74; var tmp2 any = A_arbace_core_reducers_drop_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_core_reducers_drop_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_core_reducers_drop_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_75)); return A_arbace_core_reducers__init_A_const_74 }














func A_arbace_core_reducers__init_A_Unit38__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(230, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_64)); var tmp2 *lang.Var = A_arbace_core_reducers__init_A_const_77; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_78)); var tmp3 *lang.Var = A_arbace_core_reducers__init_A_const_77; var tmp4 any = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New(); var tmp5 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class = fncls__25d; tmp5 = fncls__25d } else { tmp5 = fncls__25 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_core_reducers__init_A_const_76 }
























func A_arbace_core_reducers__init_A_Unit39__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_79; var tmp2 any = A_arbace_core_reducers_cat_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_core_reducers_cat_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_core_reducers_cat_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_80)); return A_arbace_core_reducers__init_A_const_79 }



















func A_arbace_core_reducers__init_A_Unit40__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(275, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_81; var tmp2 any = A_arbace_core_reducers_append_BANG__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_core_reducers_append_BANG__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_core_reducers_append_BANG__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_82)); return A_arbace_core_reducers__init_A_const_81 }





func A_arbace_core_reducers__init_A_Unit41__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(281, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_83; var tmp2 any = A_arbace_core_reducers_foldcat_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_core_reducers_foldcat_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_core_reducers_foldcat_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_84)); return A_arbace_core_reducers__init_A_const_83 }





func A_arbace_core_reducers__init_A_Unit42__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_85; var tmp2 any = A_arbace_core_reducers_monoid_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_core_reducers_monoid_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_core_reducers_monoid_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_86)); return A_arbace_core_reducers__init_A_const_85 }










func A_arbace_core_reducers__init_A_Unit43__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(298, 1); var tmp1 *lang.Var = A_arbace_core_reducers__init_A_const_87; var tmp2 any = A_arbace_core_reducers_foldvec_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_core_reducers_foldvec_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_core_reducers_foldvec_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_reducers__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_reducers__init_A_const_88)); return A_arbace_core_reducers__init_A_const_87 }















func A_arbace_core_reducers__init_A_Unit44__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp3 any = A_arbace_core_reducers__init_A_const_90; var tmp4 any = A_arbace_core_reducers_eval153000157_fn__153000158_A_New(); var tmp5 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class = fncls__31d; tmp5 = fncls__31d } else { tmp5 = fncls__31 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit45__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_91; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 any = A_arbace_core_reducers_eval153000161_fn__153000162_A_New(); var tmp6 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class = fncls__32d; tmp6 = fncls__32d } else { tmp6 = fncls__32 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit46__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_92; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 any = A_arbace_core_reducers_eval153000165_fn__153000166_A_New(); var tmp6 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class = fncls__33d; tmp6 = fncls__33d } else { tmp6 = fncls__33 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :314:1
func A_arbace_core_reducers__init_A_Unit47__O() any { A_arbace_core_reducers__init_A_Init(); lang.Compiler_AOT_At_I_I__V(314, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers__init_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers__init_A_const_93; var tmp3 any = A_arbace_core_reducers__init_A_const_20.GetRawRoot__O(); var tmp4 any = A_arbace_core_reducers__init_A_const_90; var tmp5 any = A_arbace_core_reducers_eval153000169_fn__153000170_A_New(); var tmp6 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class = fncls__34d; tmp6 = fncls__34d } else { tmp6 = fncls__34 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }









type A_arbace_core_reducers__init_A struct{ jrt.Object }

var A_arbace_core_reducers__init_A_const_pool *jrt.RefArray

var A_arbace_core_reducers__init_A_const_0 *lang.Var

var A_arbace_core_reducers__init_A_const_1 any

var A_arbace_core_reducers__init_A_const_2 any

var A_arbace_core_reducers__init_A_const_3 any

var A_arbace_core_reducers__init_A_const_4 *lang.Var

var A_arbace_core_reducers__init_A_const_5 any

var A_arbace_core_reducers__init_A_const_6 any

var A_arbace_core_reducers__init_A_const_7 *lang.Var

var A_arbace_core_reducers__init_A_const_8 *lang.Var

var A_arbace_core_reducers__init_A_const_9 any

var A_arbace_core_reducers__init_A_const_10 *lang.Var

var A_arbace_core_reducers__init_A_const_11 any

var A_arbace_core_reducers__init_A_const_12 *lang.Var

var A_arbace_core_reducers__init_A_const_13 any

var A_arbace_core_reducers__init_A_const_14 *lang.Var

var A_arbace_core_reducers__init_A_const_15 any

var A_arbace_core_reducers__init_A_const_16 *lang.Var

var A_arbace_core_reducers__init_A_const_17 any

var A_arbace_core_reducers__init_A_const_18 *lang.Var

var A_arbace_core_reducers__init_A_const_19 any

var A_arbace_core_reducers__init_A_const_20 *lang.Var

var A_arbace_core_reducers__init_A_const_21 any

var A_arbace_core_reducers__init_A_const_22 any

var A_arbace_core_reducers__init_A_const_23 *jrt.Class

var A_arbace_core_reducers__init_A_const_24 *lang.Var

var A_arbace_core_reducers__init_A_const_25 *lang.Var

var A_arbace_core_reducers__init_A_const_26 *lang.Keyword

var A_arbace_core_reducers__init_A_const_27 *lang.Var

var A_arbace_core_reducers__init_A_const_28 any

var A_arbace_core_reducers__init_A_const_29 *lang.Var

var A_arbace_core_reducers__init_A_const_30 *lang.Var

var A_arbace_core_reducers__init_A_const_31 any

var A_arbace_core_reducers__init_A_const_32 *lang.Keyword

var A_arbace_core_reducers__init_A_const_33 any

var A_arbace_core_reducers__init_A_const_34 *lang.Keyword

var A_arbace_core_reducers__init_A_const_35 *lang.Keyword

var A_arbace_core_reducers__init_A_const_36 any

var A_arbace_core_reducers__init_A_const_37 *lang.Keyword

var A_arbace_core_reducers__init_A_const_38 *lang.Var

var A_arbace_core_reducers__init_A_const_39 *lang.Var

var A_arbace_core_reducers__init_A_const_40 *lang.Var

var A_arbace_core_reducers__init_A_const_41 any

var A_arbace_core_reducers__init_A_const_42 any

var A_arbace_core_reducers__init_A_const_43 *lang.Keyword

var A_arbace_core_reducers__init_A_const_44 *lang.Var

var A_arbace_core_reducers__init_A_const_45 any

var A_arbace_core_reducers__init_A_const_46 *lang.Var

var A_arbace_core_reducers__init_A_const_47 any

var A_arbace_core_reducers__init_A_const_48 *lang.Var

var A_arbace_core_reducers__init_A_const_49 any

var A_arbace_core_reducers__init_A_const_50 *lang.Var

var A_arbace_core_reducers__init_A_const_51 any

var A_arbace_core_reducers__init_A_const_52 *lang.Var

var A_arbace_core_reducers__init_A_const_53 any

var A_arbace_core_reducers__init_A_const_54 *lang.Var

var A_arbace_core_reducers__init_A_const_55 any

var A_arbace_core_reducers__init_A_const_56 *lang.Var

var A_arbace_core_reducers__init_A_const_57 any

var A_arbace_core_reducers__init_A_const_58 *lang.Var

var A_arbace_core_reducers__init_A_const_59 any

var A_arbace_core_reducers__init_A_const_60 *lang.Var

var A_arbace_core_reducers__init_A_const_61 any

var A_arbace_core_reducers__init_A_const_62 *lang.Var

var A_arbace_core_reducers__init_A_const_63 any

var A_arbace_core_reducers__init_A_const_64 *lang.Var

var A_arbace_core_reducers__init_A_const_65 any

var A_arbace_core_reducers__init_A_const_66 *lang.Var

var A_arbace_core_reducers__init_A_const_67 any

var A_arbace_core_reducers__init_A_const_68 *lang.Var

var A_arbace_core_reducers__init_A_const_69 any

var A_arbace_core_reducers__init_A_const_70 *lang.Var

var A_arbace_core_reducers__init_A_const_71 any

var A_arbace_core_reducers__init_A_const_72 *lang.Var

var A_arbace_core_reducers__init_A_const_73 any

var A_arbace_core_reducers__init_A_const_74 *lang.Var

var A_arbace_core_reducers__init_A_const_75 any

var A_arbace_core_reducers__init_A_const_76 *jrt.Class

var A_arbace_core_reducers__init_A_const_77 *lang.Var

var A_arbace_core_reducers__init_A_const_78 any

var A_arbace_core_reducers__init_A_const_79 *lang.Var

var A_arbace_core_reducers__init_A_const_80 any

var A_arbace_core_reducers__init_A_const_81 *lang.Var

var A_arbace_core_reducers__init_A_const_82 any

var A_arbace_core_reducers__init_A_const_83 *lang.Var

var A_arbace_core_reducers__init_A_const_84 any

var A_arbace_core_reducers__init_A_const_85 *lang.Var

var A_arbace_core_reducers__init_A_const_86 any

var A_arbace_core_reducers__init_A_const_87 *lang.Var

var A_arbace_core_reducers__init_A_const_88 any

var A_arbace_core_reducers__init_A_const_89 *lang.Var

var A_arbace_core_reducers__init_A_const_90 *lang.Keyword

var A_arbace_core_reducers__init_A_const_91 *jrt.Class

var A_arbace_core_reducers__init_A_const_92 *jrt.Class

var A_arbace_core_reducers__init_A_const_93 *jrt.Class

var A_arbace_core_reducers__init_A_init jrt.ClassInit

func A_arbace_core_reducers__init_A_Init() { if !A_arbace_core_reducers__init_A_init.Done() { A_arbace_core_reducers__init_A_init.Run(A_arbace_core_reducers__init_A_clinit) } }

func A_arbace_core_reducers__init_A_clinit() { A_arbace_core_reducers__init_A_clinit_p0(); A_arbace_core_reducers__init_A_clinit_p1(); A_arbace_core_reducers__init_A_clinit_p2(); A_arbace_core_reducers__init_A_clinit_p3(); A_arbace_core_reducers__init_A_clinit_p4(); A_arbace_core_reducers__init_A_clinit_p5(); A_arbace_core_reducers__init_A_clinit_p6(); A_arbace_core_reducers__init_A_clinit_p7() }

func A_arbace_core_reducers__init_A_clinit_p0() { A_arbace_core_reducers__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_39, 143); A_arbace_core_reducers__init_A_const_0 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[49]); A_arbace_core_reducers__init_A_const_1 = A_arbace_core_reducers__init_A_const_pool.A[50]; A_arbace_core_reducers__init_A_const_2 = A_arbace_core_reducers__init_A_const_pool.A[51]; A_arbace_core_reducers__init_A_const_3 = A_arbace_core_reducers__init_A_const_pool.A[52]; A_arbace_core_reducers__init_A_const_4 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[53]); A_arbace_core_reducers__init_A_const_5 = A_arbace_core_reducers__init_A_const_pool.A[54]; A_arbace_core_reducers__init_A_const_6 = A_arbace_core_reducers__init_A_const_pool.A[55]; A_arbace_core_reducers__init_A_const_7 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[56]); A_arbace_core_reducers__init_A_const_8 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[57]); A_arbace_core_reducers__init_A_const_9 = A_arbace_core_reducers__init_A_const_pool.A[58]; A_arbace_core_reducers__init_A_const_10 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[59]); A_arbace_core_reducers__init_A_const_11 = A_arbace_core_reducers__init_A_const_pool.A[60]; A_arbace_core_reducers__init_A_const_12 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[61]) }

func A_arbace_core_reducers__init_A_clinit_p1() { A_arbace_core_reducers__init_A_const_13 = A_arbace_core_reducers__init_A_const_pool.A[62]; A_arbace_core_reducers__init_A_const_14 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[63]); A_arbace_core_reducers__init_A_const_15 = A_arbace_core_reducers__init_A_const_pool.A[64]; A_arbace_core_reducers__init_A_const_16 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[65]); A_arbace_core_reducers__init_A_const_17 = A_arbace_core_reducers__init_A_const_pool.A[66]; A_arbace_core_reducers__init_A_const_18 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[67]); A_arbace_core_reducers__init_A_const_19 = A_arbace_core_reducers__init_A_const_pool.A[68]; A_arbace_core_reducers__init_A_const_20 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[69]); A_arbace_core_reducers__init_A_const_21 = A_arbace_core_reducers__init_A_const_pool.A[70]; A_arbace_core_reducers__init_A_const_22 = A_arbace_core_reducers__init_A_const_pool.A[71]; A_arbace_core_reducers__init_A_const_23 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[72]); A_arbace_core_reducers__init_A_const_24 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[73]); A_arbace_core_reducers__init_A_const_25 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[74]) }

func A_arbace_core_reducers__init_A_clinit_p2() { A_arbace_core_reducers__init_A_const_26 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[75]); A_arbace_core_reducers__init_A_const_27 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[76]); A_arbace_core_reducers__init_A_const_28 = A_arbace_core_reducers__init_A_const_pool.A[77]; A_arbace_core_reducers__init_A_const_29 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[78]); A_arbace_core_reducers__init_A_const_30 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[79]); A_arbace_core_reducers__init_A_const_31 = A_arbace_core_reducers__init_A_const_pool.A[80]; A_arbace_core_reducers__init_A_const_32 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[81]); A_arbace_core_reducers__init_A_const_33 = A_arbace_core_reducers__init_A_const_pool.A[82]; A_arbace_core_reducers__init_A_const_34 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[83]); A_arbace_core_reducers__init_A_const_35 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[84]); A_arbace_core_reducers__init_A_const_36 = A_arbace_core_reducers__init_A_const_pool.A[85]; A_arbace_core_reducers__init_A_const_37 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[86]); A_arbace_core_reducers__init_A_const_38 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[87]) }

func A_arbace_core_reducers__init_A_clinit_p3() { A_arbace_core_reducers__init_A_const_39 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[88]); A_arbace_core_reducers__init_A_const_40 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[89]); A_arbace_core_reducers__init_A_const_41 = A_arbace_core_reducers__init_A_const_pool.A[90]; A_arbace_core_reducers__init_A_const_42 = A_arbace_core_reducers__init_A_const_pool.A[91]; A_arbace_core_reducers__init_A_const_43 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[92]); A_arbace_core_reducers__init_A_const_44 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[93]); A_arbace_core_reducers__init_A_const_45 = A_arbace_core_reducers__init_A_const_pool.A[94]; A_arbace_core_reducers__init_A_const_46 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[95]); A_arbace_core_reducers__init_A_const_47 = A_arbace_core_reducers__init_A_const_pool.A[96]; A_arbace_core_reducers__init_A_const_48 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[97]); A_arbace_core_reducers__init_A_const_49 = A_arbace_core_reducers__init_A_const_pool.A[98]; A_arbace_core_reducers__init_A_const_50 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[99]); A_arbace_core_reducers__init_A_const_51 = A_arbace_core_reducers__init_A_const_pool.A[100] }

func A_arbace_core_reducers__init_A_clinit_p4() { A_arbace_core_reducers__init_A_const_52 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[101]); A_arbace_core_reducers__init_A_const_53 = A_arbace_core_reducers__init_A_const_pool.A[102]; A_arbace_core_reducers__init_A_const_54 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[103]); A_arbace_core_reducers__init_A_const_55 = A_arbace_core_reducers__init_A_const_pool.A[104]; A_arbace_core_reducers__init_A_const_56 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[105]); A_arbace_core_reducers__init_A_const_57 = A_arbace_core_reducers__init_A_const_pool.A[106]; A_arbace_core_reducers__init_A_const_58 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[107]); A_arbace_core_reducers__init_A_const_59 = A_arbace_core_reducers__init_A_const_pool.A[108]; A_arbace_core_reducers__init_A_const_60 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[109]); A_arbace_core_reducers__init_A_const_61 = A_arbace_core_reducers__init_A_const_pool.A[110]; A_arbace_core_reducers__init_A_const_62 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[111]); A_arbace_core_reducers__init_A_const_63 = A_arbace_core_reducers__init_A_const_pool.A[112]; A_arbace_core_reducers__init_A_const_64 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[113]) }

func A_arbace_core_reducers__init_A_clinit_p5() { A_arbace_core_reducers__init_A_const_65 = A_arbace_core_reducers__init_A_const_pool.A[114]; A_arbace_core_reducers__init_A_const_66 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[115]); A_arbace_core_reducers__init_A_const_67 = A_arbace_core_reducers__init_A_const_pool.A[116]; A_arbace_core_reducers__init_A_const_68 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[117]); A_arbace_core_reducers__init_A_const_69 = A_arbace_core_reducers__init_A_const_pool.A[118]; A_arbace_core_reducers__init_A_const_70 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[119]); A_arbace_core_reducers__init_A_const_71 = A_arbace_core_reducers__init_A_const_pool.A[120]; A_arbace_core_reducers__init_A_const_72 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[121]); A_arbace_core_reducers__init_A_const_73 = A_arbace_core_reducers__init_A_const_pool.A[122]; A_arbace_core_reducers__init_A_const_74 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[123]); A_arbace_core_reducers__init_A_const_75 = A_arbace_core_reducers__init_A_const_pool.A[124]; A_arbace_core_reducers__init_A_const_76 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[125]); A_arbace_core_reducers__init_A_const_77 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[126]) }

func A_arbace_core_reducers__init_A_clinit_p6() { A_arbace_core_reducers__init_A_const_78 = A_arbace_core_reducers__init_A_const_pool.A[127]; A_arbace_core_reducers__init_A_const_79 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[128]); A_arbace_core_reducers__init_A_const_80 = A_arbace_core_reducers__init_A_const_pool.A[129]; A_arbace_core_reducers__init_A_const_81 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[130]); A_arbace_core_reducers__init_A_const_82 = A_arbace_core_reducers__init_A_const_pool.A[131]; A_arbace_core_reducers__init_A_const_83 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[132]); A_arbace_core_reducers__init_A_const_84 = A_arbace_core_reducers__init_A_const_pool.A[133]; A_arbace_core_reducers__init_A_const_85 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[134]); A_arbace_core_reducers__init_A_const_86 = A_arbace_core_reducers__init_A_const_pool.A[135]; A_arbace_core_reducers__init_A_const_87 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[136]); A_arbace_core_reducers__init_A_const_88 = A_arbace_core_reducers__init_A_const_pool.A[137]; A_arbace_core_reducers__init_A_const_89 = lang.Var_Cast(A_arbace_core_reducers__init_A_const_pool.A[138]); A_arbace_core_reducers__init_A_const_90 = lang.Keyword_Cast(A_arbace_core_reducers__init_A_const_pool.A[139]) }

func A_arbace_core_reducers__init_A_clinit_p7() { A_arbace_core_reducers__init_A_const_91 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[140]); A_arbace_core_reducers__init_A_const_92 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[141]); A_arbace_core_reducers__init_A_const_93 = jrt.Class_Cast(A_arbace_core_reducers__init_A_const_pool.A[142]) }

func A_arbace_core_reducers__init_A_New() *A_arbace_core_reducers__init_A { A_arbace_core_reducers__init_A_Init(); t := &A_arbace_core_reducers__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers__init_A) Ctor() {}

func (t *A_arbace_core_reducers__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers__init_A_class }

func (t *A_arbace_core_reducers__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers__init_A); return ok }

func A_arbace_core_reducers__init_A_Cast(x any) *A_arbace_core_reducers__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers__init_A_class)) }; return v }
