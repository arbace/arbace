//line aot_arbace_core_reducers_Cat.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)






























































































































































































































func A_arbace_core_reducers_Cat_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_Cat_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Ctor_O_O_O(cnt, left, right any) { t.F_cnt = cnt; t.F_left = left; t.F_right = right }
//line :230:1
func A_arbace_core_reducers_Cat_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_core_reducers_Cat_A_Init(); return lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref()) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {

















	var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_0).GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(combinef__2, t.F_left, n__1, reducef__3, t.F_right); var tmp3 *jrt.Class; A_arbace_core_reducers_Cat_fn__153000133_A_Init(); tmp3 = A_arbace_core_reducers_Cat_fn__153000133_A_fn_class; return tmp1.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {










	var target_3 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_3); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_3) }; tmp1 = tmp2; if tmp1 { var tmp3 aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_3); var tmp4 any; var target_4 any = t.F_left; var tmp5 bool; var tmp6 bool

		tmp6 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_4); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp5 = tmp6; if tmp5 { tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_4).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp4 = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_5).GetRawRoot__O()).Invoke_O_O_O__O(target_4, f1__1, init__2) }
//line :241:1
		return tmp3.Coll_reduce_O_O__O(f1__1, tmp4) } else { var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_5).GetRawRoot__O()); var tmp8 any; var target_5 any = t.F_left; var tmp9 bool; var tmp10 bool

			tmp10 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_5); if tmp10 { tmp10 = !lang.Compiler_AOT_IsDyn_O__Z(target_5) }; tmp9 = tmp10; if tmp9 { tmp8 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_5).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp8 = lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_5).GetRawRoot__O()).Invoke_O_O_O__O(target_5, f1__1, init__2) }
//line :241:1
			return tmp7.Invoke_O_O_O__O(target_3, f1__1, tmp8) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O__O(f1__1 any) any {







	var target_6 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_6); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_6) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_6).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { return lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_5).GetRawRoot__O()).Invoke_O_O_O__O(target_6, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Seq__ISeq() lang.ISeq { return lang.ISeq_Cast(lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_6).GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_7).GetRawRoot__O()).Invoke_O__O(t.F_left), lang.IFn_Cast(jrt.NN(A_arbace_core_reducers_Cat_A_const_7).GetRawRoot__O()).Invoke_O__O(t.F_right))) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Count__I() int32 { return jrt.Number_Cast(t.F_cnt).IntValue__I() }


















func A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_core_reducers_Cat_fn__153000133_A { A_arbace_core_reducers_Cat_fn__153000133_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Ctor_O_O_O_O_O(c__combinef, c__left, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_left = c__left; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Invoke_O__O(self any) any { var rt__1 any; var tmp1 *lang.Var;
										A_arbace_core_reducers_Cat_A_Init(); tmp1 = A_arbace_core_reducers_Cat_A_const_1; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_reducers_Cat_A_Init(); tmp3 = A_arbace_core_reducers_Cat_A_const_2; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(t.F_combinef, t.F_n, t.F_reducef, t.F_right); var tmp6 *jrt.Class; A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_Init(); tmp6 = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class; rt__1 = tmp2.Invoke_O__O(tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))); var tmp7 lang.IFn =
										lang.IFn_Cast(t.F_combinef); var tmp8 any; var target_2 any = t.F_left; var tmp9 bool; var tmp10 bool; tmp10 =
										A_arbace_core_reducers_CollFold_A_InstanceOf(target_2); if tmp10 { tmp10 = !lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp9 = tmp10; if tmp9 { tmp8 = A_arbace_core_reducers_CollFold_A_Cast(target_2).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { var tmp11 *lang.Var; A_arbace_core_reducers_Cat_A_Init(); tmp11 = A_arbace_core_reducers_Cat_A_const_3; tmp8 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O_O_O__O(target_2, t.F_n, t.F_combinef, t.F_reducef) }; var tmp12 any = tmp8; var tmp13 /*line :251:1*/*lang.Var; A_arbace_core_reducers_Cat_A_Init(); tmp13 = A_arbace_core_reducers_Cat_A_const_4; return tmp7.Invoke_O_O__O(tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(rt__1)) }
//line :250:1
func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A { A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Ctor_O_O_O_O(c__combinef, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Invoke_O__O(self any) any { var target_1 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_1); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_1).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { var tmp3 *lang.Var; A_arbace_core_reducers_Cat_A_Init(); tmp3 = A_arbace_core_reducers_Cat_A_const_3; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(target_1, t.F_n, t.F_combinef, t.F_reducef) } }












type A_arbace_core_reducers_Cat_A struct{ jrt.Object; F_cnt, F_left, F_right any }

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Counted() {}

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Seqable() {}

func (t *A_arbace_core_reducers_Cat_A) Is_IType() {}

var A_arbace_core_reducers_Cat_A_const_0 *lang.Var

var A_arbace_core_reducers_Cat_A_const_1 *lang.Var

var A_arbace_core_reducers_Cat_A_const_2 *lang.Var

var A_arbace_core_reducers_Cat_A_const_3 *lang.Var

var A_arbace_core_reducers_Cat_A_const_4 *lang.Var

var A_arbace_core_reducers_Cat_A_const_5 *lang.Var

var A_arbace_core_reducers_Cat_A_const_6 *lang.Var

var A_arbace_core_reducers_Cat_A_const_7 *lang.Var

var A_arbace_core_reducers_Cat_A_init jrt.ClassInit

func A_arbace_core_reducers_Cat_A_Init() { if !A_arbace_core_reducers_Cat_A_init.Done() { A_arbace_core_reducers_Cat_A_init.Run(A_arbace_core_reducers_Cat_A_clinit) } }

func A_arbace_core_reducers_Cat_A_clinit() { A_arbace_core_reducers_Cat_A_const_0 = lang.RT_Var_String_String__Var(Lit_20, Lit_63); A_arbace_core_reducers_Cat_A_const_1 = lang.RT_Var_String_String__Var(Lit_20, Lit_64); A_arbace_core_reducers_Cat_A_const_2 = lang.RT_Var_String_String__Var(Lit_20, Lit_26); A_arbace_core_reducers_Cat_A_const_3 = lang.RT_Var_String_String__Var(Lit_20, Lit_33); A_arbace_core_reducers_Cat_A_const_4 = lang.RT_Var_String_String__Var(Lit_20, Lit_65); A_arbace_core_reducers_Cat_A_const_5 = lang.RT_Var_String_String__Var(Lit_28, Lit_30); A_arbace_core_reducers_Cat_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_core_reducers_Cat_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_36) }

func (t *A_arbace_core_reducers_Cat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_Cat_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_Cat_A_class }

func (t *A_arbace_core_reducers_Cat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_Cat_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_Cat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_Cat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_Cat_A); return ok }

func A_arbace_core_reducers_Cat_A_Cast(x any) *A_arbace_core_reducers_Cat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_Cat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_Cat_A_class)) }; return v }



type A_arbace_core_reducers_Cat_fn__153000133_A struct{ jrt.Object; F_combinef, F_left, F_n, F_reducef, F_right any }

func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_Cat_fn__153000133_A_fn_class *jrt.Class

var A_arbace_core_reducers_Cat_fn__153000133_A_init jrt.ClassInit

func A_arbace_core_reducers_Cat_fn__153000133_A_Init() { if !A_arbace_core_reducers_Cat_fn__153000133_A_init.Done() { A_arbace_core_reducers_Cat_fn__153000133_A_init.Run(A_arbace_core_reducers_Cat_fn__153000133_A_clinit) } }

func A_arbace_core_reducers_Cat_fn__153000133_A_clinit() { A_arbace_core_reducers_Cat_fn__153000133_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_Cat_fn__153000133_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_Cat_fn__153000133_A_class }

func (t *A_arbace_core_reducers_Cat_fn__153000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_Cat_fn__153000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_Cat_fn__153000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_Cat_fn__153000133_A); return ok }

func A_arbace_core_reducers_Cat_fn__153000133_A_Cast(x any) *A_arbace_core_reducers_Cat_fn__153000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_Cat_fn__153000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_Cat_fn__153000133_A_class)) }; return v }



type A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A struct{ jrt.Object; F_combinef, F_n, F_reducef, F_right any }

func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class *jrt.Class

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_init jrt.ClassInit

func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_Init() { if !A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_init.Done() { A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_init.Run(A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_clinit) } }

func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_clinit() { A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_class }

func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A); return ok }

func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_Cast(x any) *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_class)) }; return v }
