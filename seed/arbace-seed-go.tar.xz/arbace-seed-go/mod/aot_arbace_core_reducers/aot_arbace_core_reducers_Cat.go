//line aot_arbace_core_reducers_Cat.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)





























































































































































































































func A_arbace_core_reducers_Cat_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_Cat_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Ctor_O_O_O(cnt, left, right any) { t.F_cnt = cnt; t.F_left = left; t.F_right = right }
//line :230:1
func A_arbace_core_reducers_Cat_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_core_reducers_Cat_A_Init(); return lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref()) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {

















	var root_1 any = A_arbace_core_reducers_Cat_A_const_0.GetRawRoot__O(); var linked_2 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1, A_arbace_core_reducers_fjinvoke_A_fn_class); var ifn_3 lang.IFn; if linked_2 == nil { ifn_3 = lang.IFn_Cast(root_1) } else { ifn_3 = nil }; var arg_4 any; var tmp1 any = A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(combinef__2, t.F_left, n__1, reducef__3, t.F_right); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_core_reducers_Cat_fn__153000133_A_fn_class
	if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_core_reducers_Cat_fn__153000133_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; arg_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :248:1
	if linked_2 == nil { return ifn_3.Invoke_O__O(arg_4) } else { return linked_2.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(root_1, arg_4) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {










	var target_21 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_21); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_21) }; tmp1 = tmp2; if tmp1 { var tmp3 aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_21); var tmp4 any; var target_22 any = t.F_left; var tmp5 bool; var tmp6 bool

		tmp6 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_22); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_22) }; tmp5 = tmp6; if tmp5 { tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_22).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp4 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_22, f1__1, init__2) }
//line :241:1
		return tmp3.Coll_reduce_O_O__O(f1__1, tmp4) } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()); var tmp8 any; var target_23 any = t.F_left; var tmp9 bool; var tmp10 bool

			tmp10 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_23); if tmp10 { tmp10 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_23) }; tmp9 = tmp10; if tmp9 { tmp8 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_23).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp8 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_23, f1__1, init__2) }
//line :241:1
			return tmp7.Invoke_O_O_O__O(target_21, f1__1, tmp8) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O__O(f1__1 any) any {







	var target_24 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_24); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_24) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_24).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { return lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_24, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Seq__ISeq() lang.ISeq { var tmp1 any; var root_25 any = A_arbace_core_reducers_Cat_A_const_6.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_27 lang.IFn; if




	linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var root_30 any = A_arbace_core_reducers_Cat_A_const_7.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = t.F_left; if linked_31 == nil { arg_28 = ifn_32.Invoke_O__O(arg_33) } else { arg_28 = linked_31.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_30, arg_33) }; var arg_29 any; var root_34 any = A_arbace_core_reducers_Cat_A_const_7.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = t.F_right; if linked_35 == nil { arg_29 = ifn_36.Invoke_O__O(arg_37) } else { arg_29 = linked_35.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_34, arg_37) }; if linked_26 == nil { tmp1 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; return /*line :230:1*/ lang.ISeq_Cast(tmp1) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Count__I() int32 { return jrt.Number_Cast(t.F_cnt).IntValue__I() }


















func A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_core_reducers_Cat_fn__153000133_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Ctor_O_O_O_O_O(c__combinef, c__left, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_left = c__left; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Invoke_O__O(self any) any { var rt__1 any; var root_5 any = A_arbace_core_reducers_Cat_A_const_1.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, A_arbace_core_reducers_fjfork_A_fn_class); var ifn_7 lang.IFn; if
										linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any; var root_9 any = A_arbace_core_reducers_Cat_A_const_2.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, A_arbace_core_reducers_fjtask_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any; var tmp1 any = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(t.F_combinef, t.F_n, t.F_reducef, t.F_right); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; arg_12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_10 == nil { arg_8 = ifn_11.Invoke_O__O(arg_12) } else { arg_8 = linked_10.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(root_9, arg_12) }; if linked_6 == nil { rt__1 = ifn_7.Invoke_O__O(arg_8) } else { rt__1 = linked_6.(*A_arbace_core_reducers_fjfork_A).Invoke_O_O__O(root_5, arg_8) }; var tmp3 lang.IFn =
										lang.IFn_Cast(t.F_combinef); var tmp4 any; var target_15 any = t.F_left; var tmp5 bool; var tmp6 bool; tmp6 =
										A_arbace_core_reducers_CollFold_A_InstanceOf(target_15); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_15) }; tmp5 = tmp6; if tmp5 { tmp4 = A_arbace_core_reducers_CollFold_A_Cast(target_15).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { tmp4 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_3.GetRawRoot__O()).Invoke_O_O_O_O__O(target_15, t.F_n, t.F_combinef, t.F_reducef) }; var tmp7 any = tmp4; var tmp8 any; var root_16 any = /*line :251:1*/A_arbace_core_reducers_Cat_A_const_4.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, A_arbace_core_reducers_fjjoin_A_fn_class); var ifn_18 lang.IFn; if

	linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = rt__1; if linked_17 == nil { tmp8 = ifn_18.Invoke_O__O(arg_19) } else { tmp8 = linked_17.(*A_arbace_core_reducers_fjjoin_A).Invoke_O_O__O(root_16, arg_19) }; return /*line :251:1*/ tmp3.Invoke_O_O__O(tmp7, tmp8) }
//line :250:1
func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Ctor_O_O_O_O(c__combinef, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Invoke_O__O(self any) any { var target_13 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_13); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_13) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_13).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { return lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_3.GetRawRoot__O()).Invoke_O_O_O_O__O(target_13, t.F_n, t.F_combinef, t.F_reducef) } }












type A_arbace_core_reducers_Cat_A struct{ jrt.Object; F_cnt, F_left, F_right any }

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Counted() {}

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Seqable() {}

func (t *A_arbace_core_reducers_Cat_A) Is_IType() {}

var A_arbace_core_reducers_Cat_A_const_pool *jrt.RefArray

var A_arbace_core_reducers_Cat_A_const_0 *lang.Var

var A_arbace_core_reducers_Cat_A_const_1 *lang.Var

var A_arbace_core_reducers_Cat_A_const_2 *lang.Var

var A_arbace_core_reducers_Cat_A_const_3 *lang.Var

var A_arbace_core_reducers_Cat_A_const_4 *lang.Var

var A_arbace_core_reducers_Cat_A_const_5 *lang.Var

var A_arbace_core_reducers_Cat_A_const_6 *lang.Var

var A_arbace_core_reducers_Cat_A_const_7 *lang.Var

var A_arbace_core_reducers_Cat_A_init jrt.ClassInit

func A_arbace_core_reducers_Cat_A_Init() { if !A_arbace_core_reducers_Cat_A_init.Done() { A_arbace_core_reducers_Cat_A_init.Run(A_arbace_core_reducers_Cat_A_clinit) } }

func A_arbace_core_reducers_Cat_A_clinit() { jrt.StartCheck(); A_arbace_core_reducers_Cat_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_33, 8); A_arbace_core_reducers_Cat_A_const_0 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[0]); A_arbace_core_reducers_Cat_A_const_1 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[1]); A_arbace_core_reducers_Cat_A_const_2 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[2]); A_arbace_core_reducers_Cat_A_const_3 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[3]); A_arbace_core_reducers_Cat_A_const_4 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[4]); A_arbace_core_reducers_Cat_A_const_5 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[5]); A_arbace_core_reducers_Cat_A_const_6 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[6]); A_arbace_core_reducers_Cat_A_const_7 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[7]) }

func (t *A_arbace_core_reducers_Cat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_Cat_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_Cat_A_class }

func (t *A_arbace_core_reducers_Cat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_Cat_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_Cat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_Cat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_Cat_A); return ok }

func A_arbace_core_reducers_Cat_A_Cast(x any) *A_arbace_core_reducers_Cat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_Cat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_Cat_A_class)) }; return v }



type A_arbace_core_reducers_Cat_fn__153000133_A struct{ j2g_header uint64; F_combinef, F_left, F_n, F_reducef, F_right any }

var A_arbace_core_reducers_Cat_fn__153000133_A_fn_class *jrt.Class



type A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A struct{ j2g_header uint64; F_combinef, F_n, F_reducef, F_right any }

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class *jrt.Class
