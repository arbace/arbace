//line aot_arbace_core_reducers_Cat.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)





























































































































































































































func A_arbace_core_reducers_Cat_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_Cat_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Ctor_O_O_O(cnt, left, right any) { t.F_cnt = cnt; t.F_left = left; t.F_right = right }
//line :230:1
func A_arbace_core_reducers_Cat_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_core_reducers_Cat_A_Init(); return lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref()) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {

















	var root_17 any = A_arbace_core_reducers_Cat_A_const_0.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, A_arbace_core_reducers_fjinvoke_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; var tmp1 any = A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(combinef__2, t.F_left, n__1, reducef__3, t.F_right); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_reducers_Cat_fn__153000133_A_fn_class
	if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_core_reducers_Cat_fn__153000133_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; arg_20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :248:1
	if linked_18 == nil { return ifn_19.Invoke_O__O(arg_20) } else { return linked_18.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(root_17, arg_20) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {










	var target_21 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_21); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_21) }; tmp1 = tmp2; if tmp1 { var tmp3 aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_21); var tmp4 any; var target_22 any = t.F_left; var tmp5 bool; var tmp6 bool

		tmp6 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_22); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_22) }; tmp5 = tmp6; if tmp5 { tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_22).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp4 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_22, f1__1, init__2) }
//line :241:1
		return tmp3.Coll_reduce_O_O__O(f1__1, tmp4) } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()); var tmp8 any; var target_23 any = t.F_left; var tmp9 bool; var tmp10 bool

			tmp10 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_23); if tmp10 { tmp10 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_23) }; tmp9 = tmp10; if tmp9 { tmp8 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_23).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp8 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_23, f1__1, init__2) }
//line :241:1
			return tmp7.Invoke_O_O_O__O(target_21, f1__1, tmp8) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O__O(f1__1 any) any {







	var target_24 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_24); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_24) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_24).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { return lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_24, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Seq__ISeq() lang.ISeq { var tmp1 any; var root_33 any = A_arbace_core_reducers_Cat_A_const_6.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_35 lang.IFn; if




	linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any; var root_25 any = A_arbace_core_reducers_Cat_A_const_7.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = t.F_left; if linked_26 == nil { arg_36 = ifn_27.Invoke_O__O(arg_28) } else { arg_36 = linked_26.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_25, arg_28) }; var arg_37 any; var root_29 any = A_arbace_core_reducers_Cat_A_const_7.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = t.F_right; if linked_30 == nil { arg_37 = ifn_31.Invoke_O__O(arg_32) } else { arg_37 = linked_30.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_29, arg_32) }; if linked_34 == nil { tmp1 = ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { tmp1 = linked_34.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) }; return /*line :230:1*/ lang.ISeq_Cast(tmp1) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Count__I() int32 { return jrt.Number_Cast(t.F_cnt).IntValue__I() }


















func A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_core_reducers_Cat_fn__153000133_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Ctor_O_O_O_O_O(c__combinef, c__left, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_left = c__left; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Invoke_O__O(self any) any { var rt__1 any; var root_7 any = A_arbace_core_reducers_Cat_A_const_1.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, A_arbace_core_reducers_fjfork_A_fn_class); var ifn_9 lang.IFn; if
										linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any; var root_3 any = A_arbace_core_reducers_Cat_A_const_2.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3, A_arbace_core_reducers_fjtask_A_fn_class); var ifn_5 lang.IFn; if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any; var tmp1 any = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(t.F_combinef, t.F_n, t.F_reducef, t.F_right); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; arg_6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_4 == nil { arg_10 = ifn_5.Invoke_O__O(arg_6) } else { arg_10 = linked_4.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(root_3, arg_6) }; if linked_8 == nil { rt__1 = ifn_9.Invoke_O__O(arg_10) } else { rt__1 = linked_8.(*A_arbace_core_reducers_fjfork_A).Invoke_O_O__O(root_7, arg_10) }; var tmp3 lang.IFn =
										lang.IFn_Cast(t.F_combinef); var tmp4 any; var target_11 any = t.F_left; var tmp5 bool; var tmp6 bool; tmp6 =
										A_arbace_core_reducers_CollFold_A_InstanceOf(target_11); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_11) }; tmp5 = tmp6; if tmp5 { tmp4 = A_arbace_core_reducers_CollFold_A_Cast(target_11).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { tmp4 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_3.GetRawRoot__O()).Invoke_O_O_O_O__O(target_11, t.F_n, t.F_combinef, t.F_reducef) }; var tmp7 any = tmp4; var tmp8 any; var root_12 any = /*line :251:1*/A_arbace_core_reducers_Cat_A_const_4.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, A_arbace_core_reducers_fjjoin_A_fn_class); var ifn_14 lang.IFn; if

	linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = rt__1; if linked_13 == nil { tmp8 = ifn_14.Invoke_O__O(arg_15) } else { tmp8 = linked_13.(*A_arbace_core_reducers_fjjoin_A).Invoke_O_O__O(root_12, arg_15) }; return /*line :251:1*/ tmp3.Invoke_O_O__O(tmp7, tmp8) }
//line :250:1
func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Ctor_O_O_O_O(c__combinef, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Invoke_O__O(self any) any { var target_1 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_1); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_1).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { return lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_3.GetRawRoot__O()).Invoke_O_O_O_O__O(target_1, t.F_n, t.F_combinef, t.F_reducef) } }












type A_arbace_core_reducers_Cat_A struct{ jrt.Object; F_cnt, F_left, F_right any }

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Counted() {}

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Seqable() {}

func (t *A_arbace_core_reducers_Cat_A) Is_IType() {}

var A_arbace_core_reducers_Cat_A_const_pool *jrt.RefArray

var A_arbace_core_reducers_Cat_A_const_0 *lang.Var

var A_arbace_core_reducers_Cat_A_const_1 *lang.Var

var A_arbace_core_reducers_Cat_A_const_2 *lang.Var

var A_arbace_core_reducers_Cat_A_const_3 *lang.Var

var A_arbace_core_reducers_Cat_A_const_4 *lang.Var

var A_arbace_core_reducers_Cat_A_const_5 *lang.Var

var A_arbace_core_reducers_Cat_A_const_6 *lang.Var

var A_arbace_core_reducers_Cat_A_const_7 *lang.Var

var A_arbace_core_reducers_Cat_A_init jrt.ClassInit

func A_arbace_core_reducers_Cat_A_Init() { if !A_arbace_core_reducers_Cat_A_init.Done() { A_arbace_core_reducers_Cat_A_init.Run(A_arbace_core_reducers_Cat_A_clinit) } }

func A_arbace_core_reducers_Cat_A_clinit() { jrt.StartCheck(); A_arbace_core_reducers_Cat_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_33, 8); A_arbace_core_reducers_Cat_A_const_0 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[0]); A_arbace_core_reducers_Cat_A_const_1 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[1]); A_arbace_core_reducers_Cat_A_const_2 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[2]); A_arbace_core_reducers_Cat_A_const_3 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[3]); A_arbace_core_reducers_Cat_A_const_4 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[4]); A_arbace_core_reducers_Cat_A_const_5 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[5]); A_arbace_core_reducers_Cat_A_const_6 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[6]); A_arbace_core_reducers_Cat_A_const_7 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[7]) }

func (t *A_arbace_core_reducers_Cat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_Cat_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_Cat_A_class }

func (t *A_arbace_core_reducers_Cat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_Cat_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_Cat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_Cat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_Cat_A); return ok }

func A_arbace_core_reducers_Cat_A_Cast(x any) *A_arbace_core_reducers_Cat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_Cat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_Cat_A_class)) }; return v }



type A_arbace_core_reducers_Cat_fn__153000133_A struct{ j2g_header uint64; F_combinef, F_left, F_n, F_reducef, F_right any }

var A_arbace_core_reducers_Cat_fn__153000133_A_fn_class *jrt.Class



type A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A struct{ j2g_header uint64; F_combinef, F_n, F_reducef, F_right any }

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class *jrt.Class
