//line aot_arbace_core_reducers_Cat.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)





























































































































































































































func A_arbace_core_reducers_Cat_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_Cat_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Ctor_O_O_O(cnt, left, right any) { t.F_cnt = cnt; t.F_left = left; t.F_right = right }
//line :230:1
func A_arbace_core_reducers_Cat_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_core_reducers_Cat_A_Init(); return lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref()) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {

















	var root_1 any = A_arbace_core_reducers_Cat_A_const_0.GetRawRoot__O(); var linked_2 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1, A_arbace_core_reducers_fjinvoke_A_fn_class); var ifn_3 lang.IFn; if linked_2 == nil { ifn_3 = lang.IFn_Cast(root_1) } else { ifn_3 = nil }; var arg_4 any; var fnbody__22 any = A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(combinef__2, t.F_left, n__1, reducef__3, t.F_right); var tmp1 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_core_reducers_Cat_fn__153000133_A_fn_class
	if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__22); A_arbace_core_reducers_Cat_fn__153000133_A_fn_class = fncls__21d; tmp1 = fncls__21d } else { tmp1 = fncls__21 }; arg_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp1, nil)
//line :248:1
	if linked_2 == nil { return ifn_3.Invoke_O__O(arg_4) } else { return linked_2.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(root_1, arg_4) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {










	var target_23 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_23); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_23) }; tmp1 = tmp2; if tmp1 { var tmp3 aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_23); var tmp4 any; var target_24 any = t.F_left; var tmp5 bool; var tmp6 bool

		tmp6 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_24); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_24) }; tmp5 = tmp6; if tmp5 { tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_24).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp4 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_24, f1__1, init__2) }
//line :241:1
		return tmp3.Coll_reduce_O_O__O(f1__1, tmp4) } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()); var tmp8 any; var target_25 any = t.F_left; var tmp9 bool; var tmp10 bool

			tmp10 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_25); if tmp10 { tmp10 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_25) }; tmp9 = tmp10; if tmp9 { tmp8 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_25).Coll_reduce_O_O__O(f1__1, init__2) } else { tmp8 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_25, f1__1, init__2) }
//line :241:1
			return tmp7.Invoke_O_O_O__O(target_23, f1__1, tmp8) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Coll_reduce_O__O(f1__1 any) any {







	var target_26 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_26); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_26) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_26).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { return lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(target_26, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Seq__ISeq() lang.ISeq { var tmp1 any; var root_27 any = A_arbace_core_reducers_Cat_A_const_6.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_29 lang.IFn; if




	linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any; var root_32 any = A_arbace_core_reducers_Cat_A_const_7.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = t.F_left; if linked_33 == nil { arg_30 = ifn_34.Invoke_O__O(arg_35) } else { arg_30 = linked_33.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_32, arg_35) }; var arg_31 any; var root_36 any = A_arbace_core_reducers_Cat_A_const_7.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = t.F_right; if linked_37 == nil { arg_31 = ifn_38.Invoke_O__O(arg_39) } else { arg_31 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }; if linked_28 == nil { tmp1 = ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) }; return /*line :230:1*/ lang.ISeq_Cast(tmp1) }
//line :230:1
func (t *A_arbace_core_reducers_Cat_A) Count__I() int32 { return jrt.Number_Cast(t.F_cnt).IntValue__I() }


















func A_arbace_core_reducers_Cat_fn__153000133_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_core_reducers_Cat_fn__153000133_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Ctor_O_O_O_O_O(c__combinef, c__left, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_left = c__left; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :249:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_A) Invoke_O__O(self any) any { var rt__1 any; var root_5 any = A_arbace_core_reducers_Cat_A_const_1.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, A_arbace_core_reducers_fjfork_A_fn_class); var ifn_7 lang.IFn; if
										linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any; var root_9 any = A_arbace_core_reducers_Cat_A_const_2.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, A_arbace_core_reducers_fjtask_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any; var fnbody__15 any = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(t.F_combinef, t.F_n, t.F_reducef, t.F_right); var tmp1 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__15); A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class = fncls__14d; tmp1 = fncls__14d } else { tmp1 = fncls__14 }; arg_12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__15, tmp1, nil); if linked_10 == nil { arg_8 = ifn_11.Invoke_O__O(arg_12) } else { arg_8 = linked_10.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(root_9, arg_12) }; if linked_6 == nil { rt__1 = ifn_7.Invoke_O__O(arg_8) } else { rt__1 = linked_6.(*A_arbace_core_reducers_fjfork_A).Invoke_O_O__O(root_5, arg_8) }; var tmp2 lang.IFn =
										lang.IFn_Cast(t.F_combinef); var tmp3 any; var target_16 any = t.F_left; var tmp4 bool; var tmp5 bool; tmp5 =
										A_arbace_core_reducers_CollFold_A_InstanceOf(target_16); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_16) }; tmp4 = tmp5; if tmp4 { tmp3 = A_arbace_core_reducers_CollFold_A_Cast(target_16).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { tmp3 = lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_3.GetRawRoot__O()).Invoke_O_O_O_O__O(target_16, t.F_n, t.F_combinef, t.F_reducef) }; var tmp6 any = tmp3; var tmp7 any; var root_17 any = /*line :251:1*/A_arbace_core_reducers_Cat_A_const_4.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, A_arbace_core_reducers_fjjoin_A_fn_class); var ifn_19 lang.IFn; if

	linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = rt__1; if linked_18 == nil { tmp7 = ifn_19.Invoke_O__O(arg_20) } else { tmp7 = linked_18.(*A_arbace_core_reducers_fjjoin_A).Invoke_O_O__O(root_17, arg_20) }; return /*line :251:1*/ tmp2.Invoke_O_O__O(tmp6, tmp7) }
//line :250:1
func A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A { A_arbace_core_reducers_Cat_A_Init(); t := &A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Ctor_O_O_O_O(c__combinef, c__n, c__reducef, c__right any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef; t.F_right = c__right }
//line :250:1
func (t *A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A) Invoke_O__O(self any) any { var target_13 any = t.F_right; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_13); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_13) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_13).Coll_fold_O_O_O__O(t.F_n, t.F_combinef, t.F_reducef) } else { return lang.IFn_Cast(A_arbace_core_reducers_Cat_A_const_3.GetRawRoot__O()).Invoke_O_O_O_O__O(target_13, t.F_n, t.F_combinef, t.F_reducef) } }












type A_arbace_core_reducers_Cat_A struct{ jrt.Object; F_cnt, F_left, F_right any }

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Counted() {}

func (t *A_arbace_core_reducers_Cat_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_Cat_A) Is_Seqable() {}

func (t *A_arbace_core_reducers_Cat_A) Is_IType() {}

var A_arbace_core_reducers_Cat_A_const_pool *jrt.RefArray

var A_arbace_core_reducers_Cat_A_const_0 *lang.Var

var A_arbace_core_reducers_Cat_A_const_1 *lang.Var

var A_arbace_core_reducers_Cat_A_const_2 *lang.Var

var A_arbace_core_reducers_Cat_A_const_3 *lang.Var

var A_arbace_core_reducers_Cat_A_const_4 *lang.Var

var A_arbace_core_reducers_Cat_A_const_5 *lang.Var

var A_arbace_core_reducers_Cat_A_const_6 *lang.Var

var A_arbace_core_reducers_Cat_A_const_7 *lang.Var

var A_arbace_core_reducers_Cat_A_init jrt.ClassInit

func A_arbace_core_reducers_Cat_A_Init() { if !A_arbace_core_reducers_Cat_A_init.Done() { A_arbace_core_reducers_Cat_A_init.Run(A_arbace_core_reducers_Cat_A_clinit) } }

func A_arbace_core_reducers_Cat_A_clinit() { jrt.StartCheck(); A_arbace_core_reducers_Cat_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_33, 8); A_arbace_core_reducers_Cat_A_const_0 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[0]); A_arbace_core_reducers_Cat_A_const_1 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[1]); A_arbace_core_reducers_Cat_A_const_2 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[2]); A_arbace_core_reducers_Cat_A_const_3 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[3]); A_arbace_core_reducers_Cat_A_const_4 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[4]); A_arbace_core_reducers_Cat_A_const_5 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[5]); A_arbace_core_reducers_Cat_A_const_6 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[6]); A_arbace_core_reducers_Cat_A_const_7 = lang.Var_Cast(A_arbace_core_reducers_Cat_A_const_pool.A[7]) }

func (t *A_arbace_core_reducers_Cat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_Cat_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_Cat_A_class }

func (t *A_arbace_core_reducers_Cat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_Cat_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_Cat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_Cat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_Cat_A); return ok }

func A_arbace_core_reducers_Cat_A_Cast(x any) *A_arbace_core_reducers_Cat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_Cat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_Cat_A_class)) }; return v }



type A_arbace_core_reducers_Cat_fn__153000133_A struct{ j2g_header uint64; F_combinef, F_left, F_n, F_reducef, F_right any }

var A_arbace_core_reducers_Cat_fn__153000133_A_fn_class *jrt.Class



type A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A struct{ j2g_header uint64; F_combinef, F_n, F_reducef, F_right any }

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_fn_class *jrt.Class
