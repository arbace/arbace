//line j2g_classes.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_core_reducers_append_BANG__A_class, Name: "arbace.core.reducers$append_BANG_", Modifiers: 25, Simple: "append_BANG_", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_append_BANG__A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_cat_A_class, Name: "arbace.core.reducers$cat", Modifiers: 25, Simple: "cat", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_cat_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_cat_fn__153000141_A_class, Name: "arbace.core.reducers$cat$fn__153000141", Modifiers: 25, Simple: "fn__153000141", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_cat_fn__153000141_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_cat_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_defcurried_A_class, Name: "arbace.core.reducers$defcurried", Modifiers: 25, Simple: "defcurried", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_defcurried_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR6_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_do_curried_A_class, Name: "arbace.core.reducers$do_curried", Modifiers: 25, Simple: "do_curried", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_do_curried_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_do_rfn_A_class, Name: "arbace.core.reducers$do_rfn", Modifiers: 25, Simple: "do_rfn", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_do_rfn_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_do_rfn_fn__153000066_A_class, Name: "arbace.core.reducers$do_rfn$fn__153000066", Modifiers: 25, Simple: "fn__153000066", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_do_rfn_fn__153000066_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_do_rfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_drop_A_class, Name: "arbace.core.reducers$drop", Modifiers: 25, Simple: "drop", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_drop_fn__153000125_A_class, Name: "arbace.core.reducers$drop$fn__153000125", Modifiers: 25, Simple: "fn__153000125", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_fn__153000125_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_drop_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_drop_fn__153000127_A_class, Name: "arbace.core.reducers$drop$fn__153000127", Modifiers: 25, Simple: "fn__153000127", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_fn__153000127_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_drop_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_class, Name: "arbace.core.reducers$drop$fn__153000127$fn__153000128", Modifiers: 25, Simple: "fn__153000128", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_drop_fn__153000127_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_class, Name: "arbace.core.reducers$eval153000004$loading__1927001464__auto____153000005", Modifiers: 25, Simple: "loading__1927001464__auto____153000005", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000008_fn__153000009_A_class, Name: "arbace.core.reducers$eval153000008$fn__153000009", Modifiers: 25, Simple: "fn__153000009", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000008_fn__153000009_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000031_fn__153000032_A_class, Name: "arbace.core.reducers$eval153000031$fn__153000032", Modifiers: 25, Simple: "fn__153000032", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_fn__153000032_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000031_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_class, Name: "arbace.core.reducers$eval153000031$fn__153000032$G__153000023__153000043", Modifiers: 25, Simple: "G__153000023__153000043", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000031_fn__153000032_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_class, Name: "arbace.core.reducers$eval153000031$fn__153000032$G__153000024__153000037", Modifiers: 25, Simple: "G__153000024__153000037", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000031_fn__153000032_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_class, Name: "arbace.core.reducers$eval153000132$__GT_Cat__153000138", Modifiers: 25, Simple: "__GT_Cat__153000138", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000132_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000157_fn__153000158_A_class, Name: "arbace.core.reducers$eval153000157$fn__153000158", Modifiers: 25, Simple: "fn__153000158", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000157_fn__153000158_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000157_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000161_fn__153000162_A_class, Name: "arbace.core.reducers$eval153000161$fn__153000162", Modifiers: 25, Simple: "fn__153000162", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000161_fn__153000162_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000161_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000165_fn__153000166_A_class, Name: "arbace.core.reducers$eval153000165$fn__153000166", Modifiers: 25, Simple: "fn__153000166", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000165_fn__153000166_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000165_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_eval153000169_fn__153000170_A_class, Name: "arbace.core.reducers$eval153000169$fn__153000170", Modifiers: 25, Simple: "fn__153000170", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000169_fn__153000170_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_eval153000169_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_filter_A_class, Name: "arbace.core.reducers$filter", Modifiers: 25, Simple: "filter", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_filter_fn__153000094_A_class, Name: "arbace.core.reducers$filter$fn__153000094", Modifiers: 25, Simple: "fn__153000094", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_fn__153000094_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_filter_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_filter_fn__153000096_A_class, Name: "arbace.core.reducers$filter$fn__153000096", Modifiers: 25, Simple: "fn__153000096", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_fn__153000096_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_filter_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_class, Name: "arbace.core.reducers$filter$fn__153000096$fn__153000097", Modifiers: 25, Simple: "fn__153000097", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_filter_fn__153000096_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_fjfork_A_class, Name: "arbace.core.reducers$fjfork", Modifiers: 25, Simple: "fjfork", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjfork_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_fjinvoke_A_class, Name: "arbace.core.reducers$fjinvoke", Modifiers: 25, Simple: "fjinvoke", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjinvoke_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_fjjoin_A_class, Name: "arbace.core.reducers$fjjoin", Modifiers: 25, Simple: "fjjoin", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjjoin_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_fjtask_A_class, Name: "arbace.core.reducers$fjtask", Modifiers: 25, Simple: "fjtask", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fjtask_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_flatten_A_class, Name: "arbace.core.reducers$flatten", Modifiers: 25, Simple: "flatten", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_flatten_fn__153000104_A_class, Name: "arbace.core.reducers$flatten$fn__153000104", Modifiers: 25, Simple: "fn__153000104", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_fn__153000104_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_flatten_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_flatten_fn__153000106_A_class, Name: "arbace.core.reducers$flatten$fn__153000106", Modifiers: 25, Simple: "fn__153000106", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_fn__153000106_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_flatten_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_class, Name: "arbace.core.reducers$flatten$fn__153000106$fn__153000107", Modifiers: 25, Simple: "fn__153000107", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_flatten_fn__153000106_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_fn__153000016_A_class, Name: "arbace.core.reducers$fn__153000016", Modifiers: 25, Simple: "fn__153000016", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fn__153000016_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_fold_A_class, Name: "arbace.core.reducers$fold", Modifiers: 25, Simple: "fold", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_fold_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class, &lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_foldcat_A_class, Name: "arbace.core.reducers$foldcat", Modifiers: 25, Simple: "foldcat", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldcat_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_folder_A_class, Name: "arbace.core.reducers$folder", Modifiers: 25, Simple: "folder", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_folder_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_foldvec_A_class, Name: "arbace.core.reducers$foldvec", Modifiers: 25, Simple: "foldvec", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_foldvec_fc__153000150_A_class, Name: "arbace.core.reducers$foldvec$fc__153000150", Modifiers: 25, Simple: "fc__153000150", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_fc__153000150_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_foldvec_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_class, Name: "arbace.core.reducers$foldvec$fc__153000150$fn__153000151", Modifiers: 25, Simple: "fn__153000151", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_foldvec_fc__153000150_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_foldvec_fn__153000154_A_class, Name: "arbace.core.reducers$foldvec$fn__153000154", Modifiers: 25, Simple: "fn__153000154", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_foldvec_fn__153000154_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_foldvec_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_map_A_class, Name: "arbace.core.reducers$map", Modifiers: 25, Simple: "map", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_map_fn__153000078_A_class, Name: "arbace.core.reducers$map$fn__153000078", Modifiers: 25, Simple: "fn__153000078", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_fn__153000078_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_map_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_map_fn__153000080_A_class, Name: "arbace.core.reducers$map$fn__153000080", Modifiers: 25, Simple: "fn__153000080", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_fn__153000080_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_map_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_class, Name: "arbace.core.reducers$map$fn__153000080$fn__153000081", Modifiers: 25, Simple: "fn__153000081", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_map_fn__153000080_fn__153000081_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_map_fn__153000080_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_mapcat_A_class, Name: "arbace.core.reducers$mapcat", Modifiers: 25, Simple: "mapcat", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_mapcat_fn__153000085_A_class, Name: "arbace.core.reducers$mapcat$fn__153000085", Modifiers: 25, Simple: "fn__153000085", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000085_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_mapcat_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_mapcat_fn__153000087_A_class, Name: "arbace.core.reducers$mapcat$fn__153000087", Modifiers: 25, Simple: "fn__153000087", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000087_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_mapcat_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_class, Name: "arbace.core.reducers$mapcat$fn__153000087$f1__153000088", Modifiers: 25, Simple: "f1__153000088", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_mapcat_fn__153000087_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_class, Name: "arbace.core.reducers$mapcat$fn__153000087$fn__153000090", Modifiers: 25, Simple: "fn__153000090", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_mapcat_fn__153000087_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_monoid_A_class, Name: "arbace.core.reducers$monoid", Modifiers: 25, Simple: "monoid", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_monoid_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_monoid_m__153000147_A_class, Name: "arbace.core.reducers$monoid$m__153000147", Modifiers: 25, Simple: "m__153000147", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_monoid_m__153000147_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_monoid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_reduce_A_class, Name: "arbace.core.reducers$reduce", Modifiers: 25, Simple: "reduce", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_reduce_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_reducer_A_class, Name: "arbace.core.reducers$reducer", Modifiers: 25, Simple: "reducer", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_reducer_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_remove_A_class, Name: "arbace.core.reducers$remove", Modifiers: 25, Simple: "remove", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_remove_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_remove_fn__153000101_A_class, Name: "arbace.core.reducers$remove$fn__153000101", Modifiers: 25, Simple: "fn__153000101", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_remove_fn__153000101_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_remove_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_rfn_A_class, Name: "arbace.core.reducers$rfn", Modifiers: 25, Simple: "rfn", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_rfn_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_A_class, Name: "arbace.core.reducers$take", Modifiers: 25, Simple: "take", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_fn__153000118_A_class, Name: "arbace.core.reducers$take$fn__153000118", Modifiers: 25, Simple: "fn__153000118", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_fn__153000118_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_take_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_fn__153000120_A_class, Name: "arbace.core.reducers$take$fn__153000120", Modifiers: 25, Simple: "fn__153000120", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_fn__153000120_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_take_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_class, Name: "arbace.core.reducers$take$fn__153000120$fn__153000121", Modifiers: 25, Simple: "fn__153000121", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_fn__153000120_fn__153000121_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_take_fn__153000120_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_while_A_class, Name: "arbace.core.reducers$take_while", Modifiers: 25, Simple: "take_while", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_while_fn__153000111_A_class, Name: "arbace.core.reducers$take_while$fn__153000111", Modifiers: 25, Simple: "fn__153000111", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_fn__153000111_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_take_while_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_while_fn__153000113_A_class, Name: "arbace.core.reducers$take_while$fn__153000113", Modifiers: 25, Simple: "fn__153000113", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_fn__153000113_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_take_while_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_class, Name: "arbace.core.reducers$take_while$fn__153000113$fn__153000114", Modifiers: 25, Simple: "fn__153000114", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_take_while_fn__153000113_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_Cat_fn__153000133_A_class, Name: "arbace.core.reducers.Cat$fn__153000133", Modifiers: 25, Simple: "fn__153000133", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_Cat_fn__153000133_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_Cat_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_class, Name: "arbace.core.reducers.Cat$fn__153000133$fn__153000134", Modifiers: 25, Simple: "fn__153000134", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A", Source: "reducers.ae", Declaring: &A_arbace_core_reducers_Cat_fn__153000133_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_core_reducers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_A_New()}; return nil }

var A_arbace_core_reducers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_A_new}

var A_arbace_core_reducers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_A"})

func init() { i := A_arbace_core_reducers_A_class.Info(); i.IsInstance = A_arbace_core_reducers_A_InstanceOf; i.Init = A_arbace_core_reducers_A_Init; i.Table = A_arbace_core_reducers_A_members }

var A_arbace_core_reducers_append_BANG__A_class *jrt.Class

var A_arbace_core_reducers_cat_A_class *jrt.Class

var A_arbace_core_reducers_cat_fn__153000141_A_class *jrt.Class

var A_arbace_core_reducers_defcurried_A_class *jrt.Class

var A_arbace_core_reducers_do_curried_A_class *jrt.Class

var A_arbace_core_reducers_do_rfn_A_class *jrt.Class

var A_arbace_core_reducers_do_rfn_fn__153000066_A_class *jrt.Class

var A_arbace_core_reducers_drop_A_class *jrt.Class

var A_arbace_core_reducers_drop_fn__153000125_A_class *jrt.Class

var A_arbace_core_reducers_drop_fn__153000127_A_class *jrt.Class

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_class *jrt.Class

func A_arbace_core_reducers_eval153000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000004_A_New()}; return nil }

var A_arbace_core_reducers_eval153000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000004_A_new}

var A_arbace_core_reducers_eval153000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000004", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000004_A"})

func init() { i := A_arbace_core_reducers_eval153000004_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000004_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000004_A_members }

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_class *jrt.Class

func A_arbace_core_reducers_eval153000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000008_A_New()}; return nil }

var A_arbace_core_reducers_eval153000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000008_A_new}

var A_arbace_core_reducers_eval153000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000008", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000008_A"})

func init() { i := A_arbace_core_reducers_eval153000008_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000008_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000008_A_members }

var A_arbace_core_reducers_eval153000008_fn__153000009_A_class *jrt.Class

func A_arbace_core_reducers_eval153000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000031_A_New()}; return nil }

var A_arbace_core_reducers_eval153000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000031_A_new}

var A_arbace_core_reducers_eval153000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000031", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000031_A"})

func init() { i := A_arbace_core_reducers_eval153000031_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000031_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000031_A_members }

var A_arbace_core_reducers_eval153000031_fn__153000032_A_class *jrt.Class

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_class *jrt.Class

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_class *jrt.Class

func A_arbace_core_reducers_eval153000132_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000132_A_New()}; return nil }

var A_arbace_core_reducers_eval153000132_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000132_A_new}

var A_arbace_core_reducers_eval153000132_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000132", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000132", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000132_A"})

func init() { i := A_arbace_core_reducers_eval153000132_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000132_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000132_A_members }

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_class *jrt.Class

func A_arbace_core_reducers_eval153000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000157_A_New()}; return nil }

var A_arbace_core_reducers_eval153000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000157_A_new}

var A_arbace_core_reducers_eval153000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000157", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000157_A"})

func init() { i := A_arbace_core_reducers_eval153000157_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000157_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000157_A_members }

var A_arbace_core_reducers_eval153000157_fn__153000158_A_class *jrt.Class

func A_arbace_core_reducers_eval153000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000161_A_New()}; return nil }

var A_arbace_core_reducers_eval153000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000161_A_new}

var A_arbace_core_reducers_eval153000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000161", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000161_A"})

func init() { i := A_arbace_core_reducers_eval153000161_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000161_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000161_A_members }

var A_arbace_core_reducers_eval153000161_fn__153000162_A_class *jrt.Class

func A_arbace_core_reducers_eval153000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000165_A_New()}; return nil }

var A_arbace_core_reducers_eval153000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000165_A_new}

var A_arbace_core_reducers_eval153000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000165", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000165_A"})

func init() { i := A_arbace_core_reducers_eval153000165_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000165_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000165_A_members }

var A_arbace_core_reducers_eval153000165_fn__153000166_A_class *jrt.Class

func A_arbace_core_reducers_eval153000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_eval153000169_A_New()}; return nil }

var A_arbace_core_reducers_eval153000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_reducers_eval153000169_A_new}

var A_arbace_core_reducers_eval153000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$eval153000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_reducers_A_class, Simple: "eval153000169", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_eval153000169_A"})

func init() { i := A_arbace_core_reducers_eval153000169_A_class.Info(); i.IsInstance = A_arbace_core_reducers_eval153000169_A_InstanceOf; i.Table = A_arbace_core_reducers_eval153000169_A_members }

var A_arbace_core_reducers_eval153000169_fn__153000170_A_class *jrt.Class

var A_arbace_core_reducers_filter_A_class *jrt.Class

var A_arbace_core_reducers_filter_fn__153000094_A_class *jrt.Class

var A_arbace_core_reducers_filter_fn__153000096_A_class *jrt.Class

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_class *jrt.Class

var A_arbace_core_reducers_fjfork_A_class *jrt.Class

var A_arbace_core_reducers_fjinvoke_A_class *jrt.Class

var A_arbace_core_reducers_fjjoin_A_class *jrt.Class

var A_arbace_core_reducers_fjtask_A_class *jrt.Class

var A_arbace_core_reducers_flatten_A_class *jrt.Class

var A_arbace_core_reducers_flatten_fn__153000104_A_class *jrt.Class

var A_arbace_core_reducers_flatten_fn__153000106_A_class *jrt.Class

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_class *jrt.Class

var A_arbace_core_reducers_fn__153000016_A_class *jrt.Class

var A_arbace_core_reducers_fold_A_class *jrt.Class

var A_arbace_core_reducers_foldcat_A_class *jrt.Class

var A_arbace_core_reducers_folder_A_class *jrt.Class

func A_arbace_core_reducers_folder_reify__153000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Coll_fold_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Coll_reduce_O__O(args[0]); case 2: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Coll_reduce_O_O__O(args[0], args[1]); case 3: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).Meta__IPersistentMap(); case 4: return this.(*A_arbace_core_reducers_folder_reify__153000055_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_core_reducers_folder_reify__153000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2])}; return nil }

var A_arbace_core_reducers_folder_reify__153000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 coll_fold (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_core_reducers_folder_reify__153000055_A_invoke, New: A_arbace_core_reducers_folder_reify__153000055_A_new}

var A_arbace_core_reducers_folder_reify__153000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$folder$reify__153000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_class, A_arbace_core_reducers_CollFold_A_class, lang.IObj_class}, Declaring: A_arbace_core_reducers_folder_A_class, Simple: "reify__153000055", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_folder_reify__153000055_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_folder_reify__153000055_A_class.Info(); i.IsInstance = A_arbace_core_reducers_folder_reify__153000055_A_InstanceOf; i.Table = A_arbace_core_reducers_folder_reify__153000055_A_members }

var A_arbace_core_reducers_foldvec_A_class *jrt.Class

var A_arbace_core_reducers_foldvec_fc__153000150_A_class *jrt.Class

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_class *jrt.Class

var A_arbace_core_reducers_foldvec_fn__153000154_A_class *jrt.Class

var A_arbace_core_reducers_map_A_class *jrt.Class

var A_arbace_core_reducers_map_fn__153000078_A_class *jrt.Class

var A_arbace_core_reducers_map_fn__153000080_A_class *jrt.Class

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_class *jrt.Class

var A_arbace_core_reducers_mapcat_A_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000085_A_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000087_A_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_class *jrt.Class

var A_arbace_core_reducers_monoid_A_class *jrt.Class

var A_arbace_core_reducers_monoid_m__153000147_A_class *jrt.Class

var A_arbace_core_reducers_reduce_A_class *jrt.Class

var A_arbace_core_reducers_reducer_A_class *jrt.Class

func A_arbace_core_reducers_reducer_reify__153000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).Coll_reduce_O__O(args[0]); case 1: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).Coll_reduce_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).Meta__IPersistentMap(); case 3: return this.(*A_arbace_core_reducers_reducer_reify__153000052_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_core_reducers_reducer_reify__153000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2])}; return nil }

var A_arbace_core_reducers_reducer_reify__153000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_core_reducers_reducer_reify__153000052_A_invoke, New: A_arbace_core_reducers_reducer_reify__153000052_A_new}

var A_arbace_core_reducers_reducer_reify__153000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers$reducer$reify__153000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_class, lang.IObj_class}, Declaring: A_arbace_core_reducers_reducer_A_class, Simple: "reify__153000052", Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_reducer_reify__153000052_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_reducer_reify__153000052_A_class.Info(); i.IsInstance = A_arbace_core_reducers_reducer_reify__153000052_A_InstanceOf; i.Table = A_arbace_core_reducers_reducer_reify__153000052_A_members }

var A_arbace_core_reducers_remove_A_class *jrt.Class

var A_arbace_core_reducers_remove_fn__153000101_A_class *jrt.Class

var A_arbace_core_reducers_rfn_A_class *jrt.Class

var A_arbace_core_reducers_take_A_class *jrt.Class

var A_arbace_core_reducers_take_fn__153000118_A_class *jrt.Class

var A_arbace_core_reducers_take_fn__153000120_A_class *jrt.Class

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_class *jrt.Class

var A_arbace_core_reducers_take_while_A_class *jrt.Class

var A_arbace_core_reducers_take_while_fn__153000111_A_class *jrt.Class

var A_arbace_core_reducers_take_while_fn__153000113_A_class *jrt.Class

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_class *jrt.Class

func A_arbace_core_reducers_Cat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_reducers_Cat_A).Coll_fold_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_reducers_Cat_A).Coll_reduce_O__O(args[0]); case 2: return this.(*A_arbace_core_reducers_Cat_A).Coll_reduce_O_O__O(args[0], args[1]); case 3: return this.(*A_arbace_core_reducers_Cat_A).Count__I(); case 4: return A_arbace_core_reducers_Cat_A_GetBasis__IPersistentVector(); case 5: return this.(*A_arbace_core_reducers_Cat_A).Seq__ISeq()}; return nil }

func A_arbace_core_reducers_Cat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers_Cat_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_reducers_Cat_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_core_reducers_Cat_A).F_cnt; case 1: return o.(*A_arbace_core_reducers_Cat_A).F_left; case 2: return o.(*A_arbace_core_reducers_Cat_A).F_right}; return nil }

var A_arbace_core_reducers_Cat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 coll_fold (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 count ()I\nM9 getBasis ()Larbace.lang.IPersistentVector;\nM1 seq ()Larbace.lang.ISeq;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG17 cnt Ljava.lang.Object;\nG17 left Ljava.lang.Object;\nG17 right Ljava.lang.Object;", Invoke: A_arbace_core_reducers_Cat_A_invoke, New: A_arbace_core_reducers_Cat_A_new, Get: A_arbace_core_reducers_Cat_A_get}

var A_arbace_core_reducers_Cat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers.Cat", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_class, lang.Counted_class, A_arbace_core_reducers_CollFold_A_class, lang.Seqable_class, lang.IType_class}, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_Cat_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers_Cat_A_class.Info(); i.IsInstance = A_arbace_core_reducers_Cat_A_InstanceOf; i.Init = A_arbace_core_reducers_Cat_A_Init; i.Table = A_arbace_core_reducers_Cat_A_members }

var A_arbace_core_reducers_Cat_fn__153000133_A_class *jrt.Class

var A_arbace_core_reducers_Cat_fn__153000133_fn__153000134_A_class *jrt.Class

func A_arbace_core_reducers_CollFold_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_reducers_CollFold_A).Coll_fold_O_O_O__O(args[0], args[1], args[2])}; return nil }

var A_arbace_core_reducers_CollFold_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 coll_fold (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_reducers_CollFold_A_invoke}

var A_arbace_core_reducers_CollFold_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers.CollFold", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers_CollFold_A"})

func init() { i := A_arbace_core_reducers_CollFold_A_class.Info(); i.IsInstance = A_arbace_core_reducers_CollFold_A_InstanceOf; i.Table = A_arbace_core_reducers_CollFold_A_members }

func A_arbace_core_reducers__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_reducers__init_A_Load__O()}; return nil }

func A_arbace_core_reducers__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_reducers__init_A_New()}; return nil }

var A_arbace_core_reducers__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_reducers__init_A_invoke, New: A_arbace_core_reducers__init_A_new}

var A_arbace_core_reducers__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.reducers__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_reducers.A_arbace_core_reducers__init_A", Source: "reducers.ae"})

func init() { i := A_arbace_core_reducers__init_A_class.Info(); i.IsInstance = A_arbace_core_reducers__init_A_InstanceOf; i.Init = A_arbace_core_reducers__init_A_Init; i.Table = A_arbace_core_reducers__init_A_members }
