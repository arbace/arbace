//line aot_arbace_core_reducers.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_core_protocols"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)
//line :9:1
func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New() *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_core_reducers_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_reducers_A_const_3, A_arbace_core_reducers_A_const_4, A_arbace_core_reducers_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_core_reducers_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_reducers_eval153000008_fn__153000009_A_New() *A_arbace_core_reducers_eval153000008_fn__153000009_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000008_fn__153000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_core_reducers_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core_reducers_A_const_9.GetRawRoot__O(), A_arbace_core_reducers_A_const_10) }












func A_arbace_core_reducers_fn__153000016_A_New() *A_arbace_core_reducers_fn__153000016_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fn__153000016_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Ctor() {}
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Invoke_O__O(self any) any { return jrt.ForkJoinPool_New() }

func A_arbace_core_reducers_fjtask_A_New() *A_arbace_core_reducers_fjtask_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjtask_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Invoke_O_O__O(self, f__0 any) any {
	return jrt.ForkJoinTask_Adapt_Callable__ForkJoinTask(jrt.Callable_Cast(f__0))
}
func A_arbace_core_reducers_fjinvoke_A_New() *A_arbace_core_reducers_fjinvoke_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjinvoke_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Ctor() {}
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.ForkJoinTask_InForkJoinPool__Z() {
		return lang.IFn_Cast(f__0).Invoke__O() } else {
			var tmp1 any; var root_21 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_core_reducers_A_const_11.GetRawRoot__O(); if linked_22 == nil { tmp1 = ifn_23.Invoke_O__O(arg_24) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_21, arg_24) }; var tmp2 *jrt.ForkJoinPool = jrt.As[*jrt.ForkJoinPool](tmp1); var tmp3 any; var root_25 any = A_arbace_core_reducers_A_const_12.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, A_arbace_core_reducers_fjtask_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = f__0; if linked_26 == nil { tmp3 = ifn_27.Invoke_O__O(arg_28) } else { tmp3 = linked_26.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(root_25, arg_28) }; return jrt.NN(tmp2).Invoke_ForkJoinTask__O(jrt.ForkJoinTask_Cast(tmp3))
		} }
func A_arbace_core_reducers_fjfork_A_New() *A_arbace_core_reducers_fjfork_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjfork_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Ctor() {}
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Fork__ForkJoinTask() }

func A_arbace_core_reducers_fjjoin_A_New() *A_arbace_core_reducers_fjjoin_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjjoin_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Ctor() {}
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Join__O() }



func A_arbace_core_reducers_reduce_A_New() *A_arbace_core_reducers_reduce_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_reduce_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Ctor() {}
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O_O__O(self, f__0, init__1, coll__2 any) any {





	if jrt.Map_InstanceOf(coll__2) {
		var target_29 any = coll__2; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_InstanceOf(target_29); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_29) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_Cast(target_29).Kv_reduce_O_O__O(f__0, init__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(target_29, f__0, init__1) } } else {
			var target_30 any = coll__2; var tmp3 bool; var tmp4 bool; tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_30); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_30) }; tmp3 = tmp4; if tmp3 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_30).Coll_reduce_O_O__O(f__0, init__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(target_30, f__0, init__1) } } }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	var root_31 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, A_arbace_core_reducers_reduce_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = f__0; var arg_35 any = lang.IFn_Cast(f__0).Invoke__O(); var arg_36 any = coll__1; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36)
	}
}



func A_arbace_core_reducers_eval153000031_fn__153000032_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__153000024__2_ any; var fnbody__39 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New(); var tmp1 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class = fncls__38d; tmp1 = fncls__38d } else { tmp1 = fncls__38 }; G__153000024__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__39, tmp1, nil); var f__231000283__auto____3 any; var fnbody__48 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(G__153000024__2_); var tmp2 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__48); A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class = fncls__47d; tmp2 = fncls__47d } else { tmp2 = fncls__47 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(p0 any) *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Ctor_O(c__G__153000024 any) { t.F_G__153000024 = c__G__153000024 }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4 any) any { var cache__231000280__auto____5 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____6 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____5)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__153000039__1)); if jrt.J2g_Truth(f__231000281__auto____6) { return lang.IFn_Cast(f__231000281__auto____6).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } else { var tmp1 any; var root_40 any = A_arbace_core_reducers_A_const_16.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = self; var arg_44 any = gf__coll__153000039__1; var arg_45 any = A_arbace_core_reducers_A_const_17; var arg_46 any = t.F_G__153000024; if linked_41 == nil { tmp1 = ifn_42.Invoke_O_O_O_O__O(arg_43, arg_44, arg_45, arg_46) } else { tmp1 = linked_41.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_40, arg_43, arg_44, arg_45, arg_46) }; return lang.IFn_Cast(tmp1).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000033__1, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4 any) any { var target_37 any = gf__coll__153000033__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_37 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_37) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_37, Lit_8, jrt.RefArrayOf(jrt.Object_class, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4)) } else { return A_arbace_core_reducers_CollFold_A_Cast(target_37).Coll_fold_O_O_O__O(gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4) } }


func A_arbace_core_reducers_fold_A_New() *A_arbace_core_reducers_fold_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fold_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O_O__O(self, n__0, combinef__1, reducef__2, coll__3 any) any {













	var target_49 any = coll__3; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_49); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_49) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_49).Coll_fold_O_O_O__O(n__0, combinef__1, reducef__2) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_18.GetRawRoot__O()).Invoke_O_O_O_O__O(target_49, n__0, combinef__1, reducef__2) } }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O__O(self, combinef__0, reducef__1, coll__2 any) any {











	var root_50 any = A_arbace_core_reducers_A_const_19.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_core_reducers_fold_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = A_arbace_core_reducers_A_const_20; var arg_54 any = combinef__0; var arg_55 any = reducef__1; var arg_56 any = coll__2; if linked_51 == nil { return ifn_52.Invoke_O_O_O_O__O(arg_53, arg_54, arg_55, arg_56) } else { return linked_51.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O_O__O(root_50, arg_53, arg_54, arg_55, arg_56) } }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O__O(self, reducef__0, coll__1 any) any {










	var root_57 any = A_arbace_core_reducers_A_const_19.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_core_reducers_fold_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = reducef__0; var arg_61 any = reducef__0; var arg_62 any = coll__1; if linked_58 == nil { return ifn_59.Invoke_O_O_O__O(arg_60, arg_61, arg_62) } else { return linked_58.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O__O(root_57, arg_60, arg_61, arg_62)
	}
}


func A_arbace_core_reducers_reducer_A_New() *A_arbace_core_reducers_reducer_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_reducer_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :74:1
func A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_reducer_reify__153000052_A { t := &A_arbace_core_reducers_reducer_reify__153000052_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_63 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_63); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_63) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_63).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_63, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O__O(f1__1 any) any {


	var target_64 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_64); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_64) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_64).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_64, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }






func A_arbace_core_reducers_folder_A_New() *A_arbace_core_reducers_folder_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_folder_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Ctor() {}
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :88:1
func A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_folder_reify__153000055_A { t := &A_arbace_core_reducers_folder_reify__153000055_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {








	var target_65 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_65); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_65) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_65).Coll_fold_O_O_O__O(n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_18; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(target_65, n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_66 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_66); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_66) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_66).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_66, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O__O(f1__1 any) any {


	var target_67 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_67); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_67) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_67).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_67, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }










func A_arbace_core_reducers_do_curried_A_New() *A_arbace_core_reducers_do_curried_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_curried_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Ctor() {}
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Invoke_O_O_O_O_O_O__O(self, name__0, doc__1, meta__2, args__3, body__4 any) any { var cargs__6 any; var root_68 any = A_arbace_core_reducers_A_const_21.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_70 lang.IFn; if

	linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any; var root_72 any = A_arbace_core_reducers_A_const_22.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = args__3; if linked_73 == nil { arg_71 = ifn_74.Invoke_O__O(arg_75) } else { arg_71 = linked_73.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_72, arg_75) }; if linked_69 == nil { cargs__6 = ifn_70.Invoke_O__O(arg_71) } else { cargs__6 = linked_69.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_68, arg_71) }; var root_76 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_26); var tmp3 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(name__0); var tmp4 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(doc__1); var tmp5 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(meta__2); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp7 any; var root_89 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any; var root_93 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(cargs__6); var arg_97 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp9 any; var root_98 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_27); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp13 any; var root_108 any = A_arbace_core_reducers_A_const_28.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = A_arbace_core_reducers_A_const_29.GetRawRoot__O(); var arg_112 any; var root_113 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any; var root_117 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_30); if linked_118 == nil { arg_116 = ifn_119.Invoke_O__O(arg_120) } else { arg_116 = linked_118.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_117, arg_120) }; if linked_114 == nil { arg_112 = ifn_115.Invoke_O__O(arg_116) } else { arg_112 = linked_114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_113, arg_116) }; if linked_109 == nil { tmp13 = ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { tmp13 = linked_109.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_108, arg_111, arg_112) }; var tmp14 any = tmp12.Invoke_O__O(tmp13); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp16 any; var root_121 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(name__0), cargs__6, lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_30)); if linked_122 == nil { tmp16 = ifn_123.Invoke_O__O(arg_124) } else { tmp16 = linked_122.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_121, arg_124) }; arg_101 = tmp10.Invoke_O_O_O__O(tmp11, tmp14, tmp15.Invoke_O__O(tmp16)); if linked_99 == nil { tmp9 = ifn_100.Invoke_O__O(arg_101) } else { tmp9 = linked_99.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_98, arg_101) }; arg_97 = tmp8.Invoke_O__O(tmp9); if linked_94 == nil { arg_92 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { arg_92 = linked_94.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_93, arg_96, arg_97) }; if linked_90 == nil { tmp7 = ifn_91.Invoke_O__O(arg_92) } else { tmp7 = linked_90.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_89, arg_92) }; var tmp17 any = tmp6.Invoke_O__O(tmp7); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp19 any; var root_131 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var root_135 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(args__3); var arg_139 any = body__4; if linked_136 == nil { arg_134 = ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { arg_134 = linked_136.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) }; if linked_132 == nil { tmp19 = ifn_133.Invoke_O__O(arg_134) } else { tmp19 = linked_132.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_131, arg_134) }; arg_79 = tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp17, tmp18.Invoke_O__O(tmp19)); if linked_77 == nil { return ifn_78.Invoke_O__O(arg_79) } else { return linked_77.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_76, arg_79) } }




func A_arbace_core_reducers_defcurried_A_New() *A_arbace_core_reducers_defcurried_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_defcurried_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) Ctor() {}
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) DoInvoke_O_O_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, doc__3, meta__4, args__5, body__6 any) any {



	var root_140 any = A_arbace_core_reducers_A_const_31.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, A_arbace_core_reducers_do_curried_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = name__2; var arg_144 any = doc__3; var arg_145 any = meta__4; var arg_146 any = args__5; var arg_147 any = body__6; if linked_141 == nil { return ifn_142.Invoke_O_O_O_O_O__O(arg_143, arg_144, arg_145, arg_146, arg_147) } else { return linked_141.(*A_arbace_core_reducers_do_curried_A).Invoke_O_O_O_O_O_O__O(root_140, arg_143, arg_144, arg_145, arg_146, arg_147)
	} }
func A_arbace_core_reducers_do_rfn_A_New() *A_arbace_core_reducers_do_rfn_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_rfn_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Ctor() {}
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Invoke_O_O_O_O__O(self, f1__0, k__1, fkv__2 any) any { var root_148 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_32); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp4 any; var root_159 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_163 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp6 any; var root_168 any = A_arbace_core_reducers_A_const_28.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = A_arbace_core_reducers_A_const_29.GetRawRoot__O(); var arg_172 any; var root_173 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_177 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; if linked_178 == nil { arg_176 = ifn_179.Invoke__O() } else { arg_176 = linked_178.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_177) }; if linked_174 == nil { arg_172 = ifn_175.Invoke_O__O(arg_176) } else { arg_172 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if linked_169 == nil { tmp6 = ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { tmp6 = linked_169.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) }; arg_166 = tmp5.Invoke_O__O(tmp6); var arg_167 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp8 any; var root_180 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any; var root_184 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(f1__0); if linked_185 == nil { arg_183 = ifn_186.Invoke_O__O(arg_187) } else { arg_183 = linked_185.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_184, arg_187) }; if linked_181 == nil { tmp8 = ifn_182.Invoke_O__O(arg_183) } else { tmp8 = linked_181.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_180, arg_183) }; arg_167 = tmp7.Invoke_O__O(tmp8); if linked_164 == nil { arg_162 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { arg_162 = linked_164.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; if linked_160 == nil { tmp4 = ifn_161.Invoke_O__O(arg_162) } else { tmp4 = linked_160.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_159, arg_162) }; var tmp9 any = tmp3.Invoke_O__O(tmp4); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp11 any; var root_188 any = A_arbace_core_reducers_A_const_33.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_walk.A_arbace_walk_postwalk_A_fn_class); var ifn_190 lang.IFn; if


	linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var fnbody__207 any = A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(k__1); var tmp12 *jrt.Class; var fncls__206 *jrt.Class = A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class; if fncls__206 == nil { var fncls__206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__207); A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class = fncls__206d; tmp12 = fncls__206d } else { tmp12 = fncls__206 }; arg_191 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__207, tmp12, nil); var arg_192 any = fkv__2; if linked_189 == nil { tmp11 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { tmp11 = linked_189.(*aot_arbace_walk.A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; arg_151 = /*line :112:1*/tmp1.Invoke_O_O_O_O__O(tmp2, tmp9, tmp10.Invoke_O__O(tmp11), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(fkv__2)); if linked_149 == nil { return ifn_150.Invoke_O__O(arg_151) } else { return linked_149.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_148, arg_151) } }


func A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(p0 any) *A_arbace_core_reducers_do_rfn_fn__153000066_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_rfn_fn__153000066_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Invoke_O_O__O(self, p1__153000065_SHARP___1 any) any {
	var tmp1 any; var root_193 any = A_arbace_core_reducers_A_const_34.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = p1__153000065_SHARP___1; if linked_194 == nil { tmp1 = ifn_195.Invoke_O__O(arg_196) } else { tmp1 = linked_194.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_193, arg_196) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var tmp3 any; var root_197 any = A_arbace_core_reducers_A_const_35.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = p1__153000065_SHARP___1; if linked_198 == nil { tmp3 = ifn_199.Invoke_O__O(arg_200) } else { tmp3 = linked_198.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_197, arg_200) }; if jrt.J2g_Truth(tmp3) { tmp2 = A_arbace_core_reducers_A_const_21.GetRawRoot__O() } else { tmp2 = A_arbace_core_reducers_A_const_36.GetRawRoot__O() }; var tmp4 lang.IFn = lang.IFn_Cast(tmp2); var tmp5 any; var root_201 any = A_arbace_core_reducers_A_const_37.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_203 lang.IFn
		if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, t.F_k)); var arg_205 any = p1__153000065_SHARP___1; if linked_202 == nil { tmp5 = ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { tmp5 = linked_202.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_201, arg_204, arg_205) }
//line :117:1
		return tmp4.Invoke_O__O(tmp5) } else {
//line :116:1
			return p1__153000065_SHARP___1
		}
}




func A_arbace_core_reducers_rfn_A_New() *A_arbace_core_reducers_rfn_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_rfn_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Ctor() {}
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, p__153000069__2, fkv__3 any) any { var vec__153000070__5 any = p__153000069__2; var f1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__153000070__5, lang.RT_IntCast_J__I_NoInit(0), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__153000070__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_208 any = A_arbace_core_reducers_A_const_38.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_core_reducers_do_rfn_A_fn_class); var ifn_210 lang.IFn; if


	linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = f1__6; var arg_212 any = k__7; var arg_213 any = fkv__3; if linked_209 == nil { return ifn_210.Invoke_O_O_O__O(arg_211, arg_212, arg_213) } else { return linked_209.(*A_arbace_core_reducers_do_rfn_A).Invoke_O_O_O_O__O(root_208, arg_211, arg_212, arg_213) } }

func A_arbace_core_reducers_map_A_New() *A_arbace_core_reducers_map_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Ctor() {}
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	var root_214 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_core_reducers_folder_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = coll__1; var arg_218 any; var fnbody__222 any = A_arbace_core_reducers_map_fn__153000080_A_New_O(f__0); var tmp1 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_core_reducers_map_fn__153000080_A_fn_class
	if fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__222); A_arbace_core_reducers_map_fn__153000080_A_fn_class = fncls__221d; tmp1 = fncls__221d } else { tmp1 = fncls__221 }; arg_218 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__222, tmp1, nil)
//line :132:1
	if linked_215 == nil { return ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { return linked_215.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) } }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O__O(self, f__0 any) any { var fnbody__229 any = A_arbace_core_reducers_map_fn__153000078_A_New_O(f__0); var tmp1 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_core_reducers_map_fn__153000078_A_fn_class; if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__229); A_arbace_core_reducers_map_fn__153000078_A_fn_class = fncls__228d; tmp1 = fncls__228d } else { tmp1 = fncls__228 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__229, tmp1, nil) }
//line :128:1
func A_arbace_core_reducers_map_fn__153000078_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000078_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000078_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_223 any = A_arbace_core_reducers_A_const_40.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, A_arbace_core_reducers_map_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = t.F_f; var arg_227 any = x__153000058__auto____1; if linked_224 == nil { return ifn_225.Invoke_O_O__O(arg_226, arg_227) } else { return linked_224.(*A_arbace_core_reducers_map_A).Invoke_O_O_O__O(root_223, arg_226, arg_227) } }




func A_arbace_core_reducers_map_fn__153000080_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000080_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_A{}; t.Ctor_O(p0); return t }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Invoke_O_O__O(self, f1__1 any) any {
	var fnbody__220 any = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(t.F_f, f1__1); var tmp1 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__220); A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class = fncls__219d; tmp1 = fncls__219d } else { tmp1 = fncls__219 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__220, tmp1, nil) }
//line :134:1
func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_fn__153000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O__O(v__2)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_mapcat_A_New() *A_arbace_core_reducers_mapcat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Ctor() {}
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {




	var root_230 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, A_arbace_core_reducers_folder_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = coll__1; var arg_234 any; var fnbody__260 any = A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(f__0); var tmp1 *jrt.Class; var fncls__259 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class
	if fncls__259 == nil { var fncls__259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__260); A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class = fncls__259d; tmp1 = fncls__259d } else { tmp1 = fncls__259 }; arg_234 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__260, tmp1, nil)
//line :143:1
	if linked_231 == nil { return ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { return linked_231.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) } }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O__O(self, f__0 any) any { var fnbody__267 any = A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(f__0); var tmp1 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__267); A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class = fncls__266d; tmp1 = fncls__266d } else { tmp1 = fncls__266 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__267, tmp1, nil) }
//line :138:1
func A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000085_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000085_A{}; t.Ctor_O(p0); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_261 any = A_arbace_core_reducers_A_const_42.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_core_reducers_mapcat_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = t.F_f; var arg_265 any = x__153000058__auto____1; if linked_262 == nil { return ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { return linked_262.(*A_arbace_core_reducers_mapcat_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) } }





func A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Invoke_O_O__O(self, f1__1 any) any { var f1__2 any; var fnbody__244 any = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(f1__1); var tmp1 *jrt.Class; var fncls__243 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class; if
												fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__244); A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class = fncls__243d; tmp1 = fncls__243d } else { tmp1 = fncls__243 }; f1__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__244, tmp1, nil); var fnbody__258 any =




	A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(t.F_f, f1__2); var tmp2 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__258); A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class = fncls__257d; tmp2 = fncls__257d } else { tmp2 = fncls__257 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__258, tmp2, nil) }
//line :145:1
func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any { var x__4 any = lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3); if



	lang.RT_IsReduced_O__Z_NoInit(x__4) { var root_235 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = x__4; if linked_236 == nil { return ifn_237.Invoke_O__O(arg_238) } else { return linked_236.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_235, arg_238) } } else { return x__4 } }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var x__3 any = lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2); if

	lang.RT_IsReduced_O__Z_NoInit(x__3) { var root_239 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = x__3; if linked_240 == nil { return ifn_241.Invoke_O__O(arg_242) } else { return linked_240.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_239, arg_242) } } else { return x__3 } }


func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var root_245 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_core_reducers_reduce_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = t.F_f1; var arg_249 any = ret__1; var arg_250 any = lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3); if linked_246 == nil { return ifn_247.Invoke_O_O_O__O(arg_248, arg_249, arg_250) } else { return linked_246.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_245, arg_248, arg_249, arg_250) } }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var root_251 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, A_arbace_core_reducers_reduce_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = t.F_f1; var arg_255 any = ret__1; var arg_256 any = lang.IFn_Cast(t.F_f).Invoke_O__O(v__2); if linked_252 == nil { return ifn_253.Invoke_O_O_O__O(arg_254, arg_255, arg_256) } else { return linked_252.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_251, arg_254, arg_255, arg_256) } }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_filter_A_New() *A_arbace_core_reducers_filter_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Ctor() {}
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	var root_268 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, A_arbace_core_reducers_folder_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = coll__1; var arg_272 any; var fnbody__276 any = A_arbace_core_reducers_filter_fn__153000096_A_New_O(pred__0); var tmp1 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_core_reducers_filter_fn__153000096_A_fn_class
	if fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__276); A_arbace_core_reducers_filter_fn__153000096_A_fn_class = fncls__275d; tmp1 = fncls__275d } else { tmp1 = fncls__275 }; arg_272 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__276, tmp1, nil)
//line :159:1
	if linked_269 == nil { return ifn_270.Invoke_O_O__O(arg_271, arg_272) } else { return linked_269.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_268, arg_271, arg_272) } }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O__O(self, pred__0 any) any { var fnbody__283 any = A_arbace_core_reducers_filter_fn__153000094_A_New_O(pred__0); var tmp1 *jrt.Class; var fncls__282 *jrt.Class = A_arbace_core_reducers_filter_fn__153000094_A_fn_class; if fncls__282 == nil { var fncls__282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__283); A_arbace_core_reducers_filter_fn__153000094_A_fn_class = fncls__282d; tmp1 = fncls__282d } else { tmp1 = fncls__282 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__283, tmp1, nil) }
//line :154:1
func A_arbace_core_reducers_filter_fn__153000094_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000094_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000094_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_277 any = A_arbace_core_reducers_A_const_43.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_core_reducers_filter_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = t.F_pred; var arg_281 any = x__153000058__auto____1; if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*A_arbace_core_reducers_filter_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } }





func A_arbace_core_reducers_filter_fn__153000096_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000096_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Invoke_O_O__O(self, f1__1 any) any {
	var fnbody__274 any = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(t.F_pred, f1__1); var tmp1 *jrt.Class; var fncls__273 *jrt.Class = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class; if fncls__273 == nil { var fncls__273d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__274); A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class = fncls__273d; tmp1 = fncls__273d } else { tmp1 = fncls__273 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__274, tmp1, nil) }
//line :161:1
func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :163:1
			return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_remove_A_New() *A_arbace_core_reducers_remove_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_remove_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Ctor() {}
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	var root_284 any = A_arbace_core_reducers_A_const_43.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, A_arbace_core_reducers_filter_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any; var root_289 any = A_arbace_core_reducers_A_const_44.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = pred__0; if linked_290 == nil { arg_287 = ifn_291.Invoke_O__O(arg_292) } else { arg_287 = linked_290.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_289, arg_292) }; var arg_288 any = coll__1; if linked_285 == nil { return ifn_286.Invoke_O_O__O(arg_287, arg_288) } else { return linked_285.(*A_arbace_core_reducers_filter_A).Invoke_O_O_O__O(root_284, arg_287, arg_288) } }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O__O(self, pred__0 any) any { var fnbody__299 any = A_arbace_core_reducers_remove_fn__153000101_A_New_O(pred__0); var tmp1 *jrt.Class; var fncls__298 *jrt.Class = A_arbace_core_reducers_remove_fn__153000101_A_fn_class; if fncls__298 == nil { var fncls__298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__299); A_arbace_core_reducers_remove_fn__153000101_A_fn_class = fncls__298d; tmp1 = fncls__298d } else { tmp1 = fncls__298 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__299, tmp1, nil) }
//line :167:1
func A_arbace_core_reducers_remove_fn__153000101_A_New_O(p0 any) *A_arbace_core_reducers_remove_fn__153000101_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_remove_fn__153000101_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_293 any = A_arbace_core_reducers_A_const_45.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, A_arbace_core_reducers_remove_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = t.F_pred; var arg_297 any = x__153000058__auto____1; if linked_294 == nil { return ifn_295.Invoke_O_O__O(arg_296, arg_297) } else { return linked_294.(*A_arbace_core_reducers_remove_A).Invoke_O_O_O__O(root_293, arg_296, arg_297) } }






func A_arbace_core_reducers_flatten_A_New() *A_arbace_core_reducers_flatten_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O_O__O(self, coll__0 any) any {





	var root_300 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, A_arbace_core_reducers_folder_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = coll__0; var arg_304 any; var fnbody__317 any = A_arbace_core_reducers_flatten_fn__153000106_A_New(); var tmp1 *jrt.Class; var fncls__316 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000106_A_fn_class
	if fncls__316 == nil { var fncls__316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_core_reducers_flatten_fn__153000106_A_fn_class = fncls__316d; tmp1 = fncls__316d } else { tmp1 = fncls__316 }; arg_304 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__317, tmp1, nil)
//line :180:1
	if linked_301 == nil { return ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { return linked_301.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O__O(self any) any { var fnbody__323 any = A_arbace_core_reducers_flatten_fn__153000104_A_New(); var tmp1 *jrt.Class; var fncls__322 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000104_A_fn_class; if fncls__322 == nil { var fncls__322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_core_reducers_flatten_fn__153000104_A_fn_class = fncls__322d; tmp1 = fncls__322d } else { tmp1 = fncls__322 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__323, tmp1, nil) }
//line :174:1
func A_arbace_core_reducers_flatten_fn__153000104_A_New() *A_arbace_core_reducers_flatten_fn__153000104_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000104_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_318 any = A_arbace_core_reducers_A_const_46.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, A_arbace_core_reducers_flatten_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = x__153000058__auto____1; if linked_319 == nil { return ifn_320.Invoke_O__O(arg_321) } else { return linked_319.(*A_arbace_core_reducers_flatten_A).Invoke_O_O__O(root_318, arg_321) } }






func A_arbace_core_reducers_flatten_fn__153000106_A_New() *A_arbace_core_reducers_flatten_fn__153000106_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Ctor() {}
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Invoke_O_O__O(self, f1__1 any) any {
	var fnbody__315 any = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(f1__1); var tmp1 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class; if fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__315); A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class = fncls__314d; tmp1 = fncls__314d } else { tmp1 = fncls__314 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__315, tmp1, nil) }
//line :182:1
func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(p0 any) *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A{}; t.Ctor_O(p0); return t }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any {


	var tmp1 any; var root_305 any = A_arbace_core_reducers_A_const_34.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = v__2; if linked_306 == nil { tmp1 = ifn_307.Invoke_O__O(arg_308) } else { tmp1 = linked_306.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_305, arg_308) }; if jrt.J2g_Truth(tmp1) {
		var target_309 any; var root_310 any = A_arbace_core_reducers_A_const_46.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, A_arbace_core_reducers_flatten_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = v__2; if linked_311 == nil { target_309 = ifn_312.Invoke_O__O(arg_313) } else { target_309 = linked_311.(*A_arbace_core_reducers_flatten_A).Invoke_O_O__O(root_310, arg_313) }; var tmp2 bool; var tmp3 bool; tmp3 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_309); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_309) }; tmp2 = tmp3; if tmp2 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_309).Coll_reduce_O_O__O(t.F_f1, ret__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(target_309, t.F_f1, ret__1) } } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_f1).Invoke__O()
}




func A_arbace_core_reducers_take_while_A_New() *A_arbace_core_reducers_take_while_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Ctor() {}
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {



	var root_324 any = A_arbace_core_reducers_A_const_47.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_core_reducers_reducer_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = coll__1; var arg_328 any; var fnbody__340 any = A_arbace_core_reducers_take_while_fn__153000113_A_New_O(pred__0); var tmp1 *jrt.Class; var fncls__339 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000113_A_fn_class
	if fncls__339 == nil { var fncls__339d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__340); A_arbace_core_reducers_take_while_fn__153000113_A_fn_class = fncls__339d; tmp1 = fncls__339d } else { tmp1 = fncls__339 }; arg_328 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__340, tmp1, nil)
//line :193:1
	if linked_325 == nil { return ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { return linked_325.(*A_arbace_core_reducers_reducer_A).Invoke_O_O_O__O(root_324, arg_327, arg_328) } }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O__O(self, pred__0 any) any { var fnbody__347 any = A_arbace_core_reducers_take_while_fn__153000111_A_New_O(pred__0); var tmp1 *jrt.Class; var fncls__346 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000111_A_fn_class; if fncls__346 == nil { var fncls__346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__347); A_arbace_core_reducers_take_while_fn__153000111_A_fn_class = fncls__346d; tmp1 = fncls__346d } else { tmp1 = fncls__346 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__347, tmp1, nil) }
//line :189:1
func A_arbace_core_reducers_take_while_fn__153000111_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000111_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000111_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_341 any = A_arbace_core_reducers_A_const_48.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, A_arbace_core_reducers_take_while_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = t.F_pred; var arg_345 any = x__153000058__auto____1; if linked_342 == nil { return ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { return linked_342.(*A_arbace_core_reducers_take_while_A).Invoke_O_O_O__O(root_341, arg_344, arg_345) } }




func A_arbace_core_reducers_take_while_fn__153000113_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000113_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Invoke_O_O__O(self, f1__1 any) any {
	var fnbody__338 any = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(t.F_pred, f1__1); var tmp1 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class; if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__338); A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class = fncls__337d; tmp1 = fncls__337d } else { tmp1 = fncls__337 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__338, tmp1, nil) }
//line :195:1
func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
			var root_329 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = ret__1; if linked_330 == nil { return ifn_331.Invoke_O__O(arg_332) } else { return linked_330.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_329, arg_332) } } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { var root_333 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = ret__1; if linked_334 == nil { return ifn_335.Invoke_O__O(arg_336) } else { return linked_334.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_333, arg_336) } } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_take_A_New() *A_arbace_core_reducers_take_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Ctor() {}
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var root_348 any = A_arbace_core_reducers_A_const_47.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, A_arbace_core_reducers_reducer_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = coll__1; var arg_352 any; var fnbody__390 any = A_arbace_core_reducers_take_fn__153000120_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__389 *jrt.Class = A_arbace_core_reducers_take_fn__153000120_A_fn_class
	if fncls__389 == nil { var fncls__389d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__390); A_arbace_core_reducers_take_fn__153000120_A_fn_class = fncls__389d; tmp1 = fncls__389d } else { tmp1 = fncls__389 }; arg_352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__390, tmp1, nil)
//line :205:1
	if linked_349 == nil { return ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { return linked_349.(*A_arbace_core_reducers_reducer_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) } }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O__O(self, n__0 any) any { var fnbody__397 any = A_arbace_core_reducers_take_fn__153000118_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_core_reducers_take_fn__153000118_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__397); A_arbace_core_reducers_take_fn__153000118_A_fn_class = fncls__396d; tmp1 = fncls__396d } else { tmp1 = fncls__396 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__397, tmp1, nil) }
//line :201:1
func A_arbace_core_reducers_take_fn__153000118_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000118_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000118_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_391 any = A_arbace_core_reducers_A_const_52.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, A_arbace_core_reducers_take_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = t.F_n; var arg_395 any = x__153000058__auto____1; if linked_392 == nil { return ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { return linked_392.(*A_arbace_core_reducers_take_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) } }




func A_arbace_core_reducers_take_fn__153000120_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000120_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_A{}; t.Ctor_O(p0); return t }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any; var root_353 any = A_arbace_core_reducers_A_const_49.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_355 lang.IFn; if
												linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = t.F_n; if linked_354 == nil { cnt__2 = ifn_355.Invoke_O__O(arg_356) } else { cnt__2 = linked_354.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_353, arg_356) }; var fnbody__388 any =
												A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(cnt__2, f1__1); var tmp1 *jrt.Class; var fncls__387 *jrt.Class = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class; if fncls__387 == nil { var fncls__387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__388); A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class = fncls__387d; tmp1 = fncls__387d } else { tmp1 = fncls__387 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__388, tmp1, nil) }
//line :208:1
func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_fn__153000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var root_367 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = t.F_cnt; var arg_371 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_368 == nil { ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { linked_368.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_367, arg_370, arg_371) }
	var tmp1 bool; var na_357 any; var root_358 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = t.F_cnt; if linked_359 == nil { na_357 = ifn_360.Invoke_O__O(arg_361) } else { na_357 = linked_359.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_358, arg_361) }; if jrt.Long_InstanceOf(na_357) { var n0_362 int64 = jrt.NN(jrt.Long_Cast(na_357)).LongValue__J(); tmp1 = n0_362 < 0 } else { if jrt.Double_InstanceOf(na_357) { var n0_362_2 float64 = jrt.NN(jrt.Double_Cast(na_357)).DoubleValue__D(); tmp1 = n0_362_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_357) } }; if tmp1 {
		var root_363 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = ret__1; if linked_364 == nil { return ifn_365.Invoke_O__O(arg_366) } else { return linked_364.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_363, arg_366) } } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var root_382 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = t.F_cnt; var arg_386 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_383 == nil { ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { linked_383.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_382, arg_385, arg_386) }; var tmp1 bool; var na_372 any; var root_373 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = t.F_cnt; if linked_374 == nil { na_372 = ifn_375.Invoke_O__O(arg_376) } else { na_372 = linked_374.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_373, arg_376) }; if jrt.Long_InstanceOf(na_372) { var n0_377 int64 = jrt.NN(jrt.Long_Cast(na_372)).LongValue__J(); tmp1 = n0_377 < 0 } else { if jrt.Double_InstanceOf(na_372) { var n0_377_2 float64 = jrt.NN(jrt.Double_Cast(na_372)).DoubleValue__D(); tmp1 = n0_377_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_372) } }; if tmp1 { var root_378 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = ret__1; if linked_379 == nil { return ifn_380.Invoke_O__O(arg_381) } else { return linked_379.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_378, arg_381) } } else { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }






func A_arbace_core_reducers_drop_A_New() *A_arbace_core_reducers_drop_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Ctor() {}
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var root_398 any = A_arbace_core_reducers_A_const_47.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_core_reducers_reducer_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = coll__1; var arg_402 any; var fnbody__432 any = A_arbace_core_reducers_drop_fn__153000127_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__431 *jrt.Class = A_arbace_core_reducers_drop_fn__153000127_A_fn_class
	if fncls__431 == nil { var fncls__431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__432); A_arbace_core_reducers_drop_fn__153000127_A_fn_class = fncls__431d; tmp1 = fncls__431d } else { tmp1 = fncls__431 }; arg_402 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__432, tmp1, nil)
//line :219:1
	if linked_399 == nil { return ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { return linked_399.(*A_arbace_core_reducers_reducer_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) } }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O__O(self, n__0 any) any { var fnbody__439 any = A_arbace_core_reducers_drop_fn__153000125_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__438 *jrt.Class = A_arbace_core_reducers_drop_fn__153000125_A_fn_class; if fncls__438 == nil { var fncls__438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__439); A_arbace_core_reducers_drop_fn__153000125_A_fn_class = fncls__438d; tmp1 = fncls__438d } else { tmp1 = fncls__438 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__439, tmp1, nil) }
//line :215:1
func A_arbace_core_reducers_drop_fn__153000125_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000125_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000125_A{}; t.Ctor_O(p0); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_433 any = A_arbace_core_reducers_A_const_53.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_core_reducers_drop_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = t.F_n; var arg_437 any = x__153000058__auto____1; if linked_434 == nil { return ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { return linked_434.(*A_arbace_core_reducers_drop_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) } }




func A_arbace_core_reducers_drop_fn__153000127_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000127_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any; var root_403 any = A_arbace_core_reducers_A_const_49.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_405 lang.IFn; if
												linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = t.F_n; if linked_404 == nil { cnt__2 = ifn_405.Invoke_O__O(arg_406) } else { cnt__2 = linked_404.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_403, arg_406) }; var fnbody__430 any =
												A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(cnt__2, f1__1); var tmp1 *jrt.Class; var fncls__429 *jrt.Class = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class; if fncls__429 == nil { var fncls__429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__430); A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class = fncls__429d; tmp1 = fncls__429d } else { tmp1 = fncls__429 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__430, tmp1, nil) }
//line :222:1
func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var root_413 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = t.F_cnt; var arg_417 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_414 == nil { ifn_415.Invoke_O_O__O(arg_416, arg_417) } else { linked_414.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_413, arg_416, arg_417) }
	var tmp1 bool; var na_407 any; var root_408 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = t.F_cnt; if linked_409 == nil { na_407 = ifn_410.Invoke_O__O(arg_411) } else { na_407 = linked_409.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.Long_InstanceOf(na_407) { var n0_412 int64 = jrt.NN(jrt.Long_Cast(na_407)).LongValue__J(); tmp1 = n0_412 < 0 } else { if jrt.Double_InstanceOf(na_407) { var n0_412_2 float64 = jrt.NN(jrt.Double_Cast(na_407)).DoubleValue__D(); tmp1 = n0_412_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_407) } }; if tmp1 {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :225:1
			return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var root_424 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = t.F_cnt; var arg_428 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_425 == nil { ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { linked_425.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_424, arg_427, arg_428) }; var tmp1 bool; var na_418 any; var root_419 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = t.F_cnt; if linked_420 == nil { na_418 = ifn_421.Invoke_O__O(arg_422) } else { na_418 = linked_420.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_419, arg_422) }; if jrt.Long_InstanceOf(na_418) { var n0_423 int64 = jrt.NN(jrt.Long_Cast(na_418)).LongValue__J(); tmp1 = n0_423 < 0 } else { if jrt.Double_InstanceOf(na_418) { var n0_423_2 float64 = jrt.NN(jrt.Double_Cast(na_418)).DoubleValue__D(); tmp1 = n0_423_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_418) } }; if tmp1 { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }







func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New() *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Ctor() {}
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Invoke_O_O_O_O__O(self, cnt__1, left__2, right__3 any) any { return A_arbace_core_reducers_Cat_A_New_O_O_O(cnt__1, left__2, right__3) }
























func A_arbace_core_reducers_cat_A_New() *A_arbace_core_reducers_cat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_cat_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Ctor() {}
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O_O__O(self, left__0, right__1 any) any {













	if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(left__0))) { return right__1 } else { if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(right__1))) { return left__0 } else { if A_arbace_core_reducers_A_const_54 != nil { return A_arbace_core_reducers_Cat_A_New_O_O_O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(left__0)), int64(lang.RT_Count_O__I_NoInit(right__1)))).Ref(), left__0, right__1) } else { return nil } } } }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O__O(self, ctor__0 any) any {









	var fnbody__446 any = A_arbace_core_reducers_cat_fn__153000141_A_New_O(ctor__0); var tmp1 *jrt.Class; var fncls__445 *jrt.Class = A_arbace_core_reducers_cat_fn__153000141_A_fn_class; if fncls__445 == nil { var fncls__445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__446); A_arbace_core_reducers_cat_fn__153000141_A_fn_class = fncls__445d; tmp1 = fncls__445d } else { tmp1 = fncls__445 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__446, tmp1, nil) }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O__O(self any) any { return jrt.ArrayList_New() }









func A_arbace_core_reducers_cat_fn__153000141_A_New_O(p0 any) *A_arbace_core_reducers_cat_fn__153000141_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_cat_fn__153000141_A{}; t.Ctor_O(p0); return t }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Ctor_O(c__ctor any) { t.F_ctor = c__ctor }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O_O_O__O(self, left__1, right__2 any) any {

	var root_440 any = A_arbace_core_reducers_A_const_55.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, A_arbace_core_reducers_cat_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = left__1; var arg_444 any = right__2; if linked_441 == nil { return ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { return linked_441.(*A_arbace_core_reducers_cat_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) } }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}







func A_arbace_core_reducers_append_BANG__A_New() *A_arbace_core_reducers_append_BANG__A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_append_BANG__A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Ctor() {}
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Invoke_O_O_O__O(self, acc__0, x__1 any) any { var G__153000144__3_ any = acc__0;



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Collection_Cast(G__153000144__3_).Add_O__Z(x__1)); return G__153000144__3_ }

func A_arbace_core_reducers_foldcat_A_New() *A_arbace_core_reducers_foldcat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldcat_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Ctor() {}
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Invoke_O_O__O(self, coll__0 any) any {



	var root_447 any = A_arbace_core_reducers_A_const_19.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, A_arbace_core_reducers_fold_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = A_arbace_core_reducers_A_const_55.GetRawRoot__O(); var arg_451 any = A_arbace_core_reducers_A_const_56.GetRawRoot__O(); var arg_452 any = coll__0; if linked_448 == nil { return ifn_449.Invoke_O_O_O__O(arg_450, arg_451, arg_452) } else { return linked_448.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O__O(root_447, arg_450, arg_451, arg_452)
	} }
func A_arbace_core_reducers_monoid_A_New() *A_arbace_core_reducers_monoid_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_monoid_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Ctor() {}
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Invoke_O_O_O__O(self, op__0, ctor__1 any) any {





	var fnbody__454 any = A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(op__0, ctor__1); var tmp1 *jrt.Class; var fncls__453 *jrt.Class = A_arbace_core_reducers_monoid_m__153000147_A_fn_class; if fncls__453 == nil { var fncls__453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__454); A_arbace_core_reducers_monoid_m__153000147_A_fn_class = fncls__453d; tmp1 = fncls__453d } else { tmp1 = fncls__453 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__454, tmp1, nil) }
//line :293:1
func A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_monoid_m__153000147_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_monoid_m__153000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Ctor_O_O(c__op, c__ctor any) { t.F_op = c__op; t.F_ctor = c__ctor }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {

	return lang.IFn_Cast(t.F_op).Invoke_O_O__O(a__1, b__2) }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}


func A_arbace_core_reducers_foldvec_A_New() *A_arbace_core_reducers_foldvec_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Ctor() {}
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Invoke_O_O_O_O_O__O(self, v__0, n__1, combinef__2, reducef__3 any) any { if jrt.Long_InstanceOf(n__1) { return t.InvokeSpec_O_O_J_O_O_O__O(self, v__0, jrt.NN(jrt.Long_Cast(n__1)).LongValue__J(), n__1, combinef__2, reducef__3) } else {

	var tmp1 any; var root_455 any = A_arbace_core_reducers_A_const_57.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_457 lang.IFn
	if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = v__0; if linked_456 == nil { tmp1 = ifn_457.Invoke_O__O(arg_458) } else { tmp1 = linked_456.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_455, arg_458) }
//line :300:1
	if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(combinef__2).Invoke__O() } else {
//line :300:1
			var tmp2 bool; var na_459 int64 = int64(lang.RT_Count_O__I_NoInit(v__0))
			var na_460 any = n__1
			if jrt.Long_InstanceOf(na_460) { var n0_461 int64 = na_459; var n1_462 int64 = jrt.NN(jrt.Long_Cast(na_460)).LongValue__J(); tmp2 = n0_461 <= n1_462 } else { tmp2 = lang.Numbers_Lte_J_O__Z_NoInit(na_459, na_460) }
//line :300:1
			if tmp2 {

				var root_464 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, A_arbace_core_reducers_reduce_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = reducef__3; var arg_468 any = lang.IFn_Cast(combinef__2).Invoke__O(); var arg_469 any = v__0; if linked_465 == nil { return ifn_466.Invoke_O_O_O__O(arg_467, arg_468, arg_469) } else { return linked_465.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_464, arg_467, arg_468, arg_469) } } else {
//line :300:1
					if A_arbace_core_reducers_A_const_54 != nil { var split__5 int64 = lang.Numbers_Quotient_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(v__0)), 2); var v1__6 any; var root_470 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_472 lang.IFn




						if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = v__0; var arg_474 any = A_arbace_core_reducers_A_const_59; var arg_475 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); if linked_471 == nil { v1__6 = ifn_472.Invoke_O_O_O__O(arg_473, arg_474, arg_475) } else { v1__6 = linked_471.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_470, arg_473, arg_474, arg_475) }
//line :300:1
						var v2__7 any; var root_476 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_478 lang.IFn





						if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = v__0; var arg_480 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); var arg_481 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__0)).Ref(); if linked_477 == nil { v2__7 = ifn_478.Invoke_O_O_O__O(arg_479, arg_480, arg_481) } else { v2__7 = linked_477.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_476, arg_479, arg_480, arg_481) }
//line :300:1
						var fc__8 any; var fnbody__492 any = A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(combinef__2, n__1, reducef__3); var tmp3 *jrt.Class
						var fncls__491 /*line :300:1*/*jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class






						if fncls__491 == nil { var fncls__491d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__492); A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class = fncls__491d; tmp3 = fncls__491d } else { tmp3 = fncls__491 }; fc__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__492, tmp3, nil)
						var root_493 any = A_arbace_core_reducers_A_const_61.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, A_arbace_core_reducers_fjinvoke_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any; var fnbody__510 any = A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(combinef__2, fc__8, v1__6, v2__7); var tmp4 *jrt.Class; var fncls__509 *jrt.Class = A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class; if fncls__509 == nil { var fncls__509d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__510); A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class = fncls__509d; tmp4 = fncls__509d } else { tmp4 = fncls__509 }; arg_496 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__510, tmp4, nil); if linked_494 == nil { return ifn_495.Invoke_O__O(arg_496) } else { return linked_494.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(root_493, arg_496) } } else {
//line :300:1
							return nil } } } } }
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) InvokeSpec_O_O_J_O_O_O__O(self, v__0 any, n__1_l int64, n__1_b, combinef__2, reducef__3 any) any {

	var tmp1 any; var root_511 any = A_arbace_core_reducers_A_const_57.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_513 lang.IFn
	if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = v__0; if linked_512 == nil { tmp1 = ifn_513.Invoke_O__O(arg_514) } else { tmp1 = linked_512.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_511, arg_514) }
//line :300:1
	if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(combinef__2).Invoke__O() } else {
//line :300:1
			var tmp2 bool; var na_515 int64 = int64(lang.RT_Count_O__I_NoInit(v__0))
			var n0_516 int64 = na_515; var n1_517 int64 = n__1_l
			tmp2 = n0_516 <= n1_517
//line :300:1
			if tmp2 {

				var root_519 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, A_arbace_core_reducers_reduce_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = reducef__3; var arg_523 any = lang.IFn_Cast(combinef__2).Invoke__O(); var arg_524 any = v__0; if linked_520 == nil { return ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { return linked_520.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) } } else {
//line :300:1
					if A_arbace_core_reducers_A_const_54 != nil { var split__5 int64 = lang.Numbers_Quotient_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(v__0)), 2); var v1__6 any; var root_525 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_527 lang.IFn




						if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = v__0; var arg_529 any = A_arbace_core_reducers_A_const_59; var arg_530 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); if linked_526 == nil { v1__6 = ifn_527.Invoke_O_O_O__O(arg_528, arg_529, arg_530) } else { v1__6 = linked_526.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_525, arg_528, arg_529, arg_530) }
//line :300:1
						var v2__7 any; var root_531 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_533 lang.IFn





						if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = v__0; var arg_535 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); var arg_536 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__0)).Ref(); if linked_532 == nil { v2__7 = ifn_533.Invoke_O_O_O__O(arg_534, arg_535, arg_536) } else { v2__7 = linked_532.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_531, arg_534, arg_535, arg_536) }
//line :300:1
						var fc__8 any; var fnbody__538 any; var tmp3 any






						if n__1_b == nil { n__1_b = jrt.Long_ValueOf_J__Long_NoInit(n__1_l).Ref(); tmp3 = n__1_b } else { tmp3 = n__1_b }; fnbody__538 = A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(combinef__2, tmp3, reducef__3); var tmp4 *jrt.Class; var fncls__537 *jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class; if fncls__537 == nil { var fncls__537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__538); A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class = fncls__537d; tmp4 = fncls__537d } else { tmp4 = fncls__537 }; fc__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__538, tmp4, nil)
						var root_539 any = A_arbace_core_reducers_A_const_61.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_core_reducers_fjinvoke_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var fnbody__544 any = A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(combinef__2, fc__8, v1__6, v2__7); var tmp5 *jrt.Class; var fncls__543 *jrt.Class = A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class; if fncls__543 == nil { var fncls__543d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__544); A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class = fncls__543d; tmp5 = fncls__543d } else { tmp5 = fncls__543 }; arg_542 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__544, tmp5, nil); if linked_540 == nil { return ifn_541.Invoke_O__O(arg_542) } else { return linked_540.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(root_539, arg_542) } } else {
//line :300:1
							return nil
						}
				}
		}
}


func A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_foldvec_fc__153000150_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Ctor_O_O_O(c__combinef, c__n, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Invoke_O_O__O(self, child__1 any) any { var fnbody__490 any = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(t.F_combinef, t.F_n, child__1, t.F_reducef); var tmp1 *jrt.Class; var fncls__489 *jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class; if fncls__489 == nil { var fncls__489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__490); A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class = fncls__489d; tmp1 = fncls__489d } else { tmp1 = fncls__489 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__490, tmp1, nil) }
//line :307:1
func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Ctor_O_O_O_O(c__combinef, c__n, c__child, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_child = c__child; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Invoke_O__O(self any) any { var root_482 any = A_arbace_core_reducers_A_const_60.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_482, A_arbace_core_reducers_foldvec_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = t.F_child; var arg_486 any = t.F_n; var arg_487 any = t.F_combinef; var arg_488 any = t.F_reducef; if linked_483 == nil { return ifn_484.Invoke_O_O_O_O__O(arg_485, arg_486, arg_487, arg_488) } else { if jrt.Long_InstanceOf(arg_486) { return linked_483.(*A_arbace_core_reducers_foldvec_A).InvokeSpec_O_O_J_O_O_O__O(root_482, arg_485, jrt.NN(jrt.Long_Cast(arg_486)).LongValue__J(), arg_486, arg_487, arg_488) } else { return linked_483.(*A_arbace_core_reducers_foldvec_A).Invoke_O_O_O_O_O__O(root_482, arg_485, arg_486, arg_487, arg_488) } } }
func A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fn__153000154_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fn__153000154_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Ctor_O_O_O_O(c__combinef, c__fc, c__v1, c__v2 any) { t.F_combinef = c__combinef; t.F_fc = c__fc; t.F_v1 = c__v1; t.F_v2 = c__v2 }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Invoke_O__O(self any) any { var f1__1 any = lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v1); var t2__2 any; var root_497 any = A_arbace_core_reducers_A_const_12.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_core_reducers_fjtask_A_fn_class); var ifn_499 lang.IFn; if

	linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v2); if linked_498 == nil { t2__2 = ifn_499.Invoke_O__O(arg_500) } else { t2__2 = linked_498.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(root_497, arg_500) }; var root_501 any =
	A_arbace_core_reducers_A_const_62.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, A_arbace_core_reducers_fjfork_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = t2__2; if linked_502 == nil { ifn_503.Invoke_O__O(arg_504) } else { linked_502.(*A_arbace_core_reducers_fjfork_A).Invoke_O_O__O(root_501, arg_504) }; var tmp1 lang.IFn =
	lang.IFn_Cast(t.F_combinef); var tmp2 any = lang.IFn_Cast(f1__1).Invoke__O(); var tmp3 any; var root_505 any = A_arbace_core_reducers_A_const_63.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, A_arbace_core_reducers_fjjoin_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = t2__2; if linked_506 == nil { tmp3 = ifn_507.Invoke_O__O(arg_508) } else { tmp3 = linked_506.(*A_arbace_core_reducers_fjjoin_A).Invoke_O_O__O(root_505, arg_508) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_New() *A_arbace_core_reducers_eval153000157_fn__153000158_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000157_fn__153000158_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {



	return lang.IFn_Cast(combinef__3).Invoke__O() }
//line :314:1
func A_arbace_core_reducers_eval153000161_fn__153000162_A_New() *A_arbace_core_reducers_eval153000161_fn__153000162_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000161_fn__153000162_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {









	var root_545 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, A_arbace_core_reducers_reduce_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = reducef__4; var arg_549 any = lang.IFn_Cast(combinef__3).Invoke__O(); var arg_550 any = coll__1; if linked_546 == nil { return ifn_547.Invoke_O_O_O__O(arg_548, arg_549, arg_550) } else { return linked_546.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_545, arg_548, arg_549, arg_550) } }
//line :314:1
func A_arbace_core_reducers_eval153000165_fn__153000166_A_New() *A_arbace_core_reducers_eval153000165_fn__153000166_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000165_fn__153000166_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Invoke_O_O_O_O_O__O(self, v__1, n__2, combinef__3, reducef__4 any) any {














	var root_551 any = A_arbace_core_reducers_A_const_60.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_551, A_arbace_core_reducers_foldvec_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = v__1; var arg_555 any = n__2; var arg_556 any = combinef__3; var arg_557 any = reducef__4; if linked_552 == nil { return ifn_553.Invoke_O_O_O_O__O(arg_554, arg_555, arg_556, arg_557) } else { if jrt.Long_InstanceOf(arg_555) { return linked_552.(*A_arbace_core_reducers_foldvec_A).InvokeSpec_O_O_J_O_O_O__O(root_551, arg_554, jrt.NN(jrt.Long_Cast(arg_555)).LongValue__J(), arg_555, arg_556, arg_557) } else { return linked_552.(*A_arbace_core_reducers_foldvec_A).Invoke_O_O_O_O_O__O(root_551, arg_554, arg_555, arg_556, arg_557) } } }
//line :314:1
func A_arbace_core_reducers_eval153000169_fn__153000170_A_New() *A_arbace_core_reducers_eval153000169_fn__153000170_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000169_fn__153000170_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Invoke_O_O_O_O_O__O(self, m__1, n__2, combinef__3, reducef__4 any) any {



















	return jrt.NN(lang.PersistentHashMap_Cast(m__1)).Fold_J_IFn_IFn_IFn_IFn_IFn_IFn__O(lang.RT_LongCast_O__J_NoInit(n__2), lang.IFn_Cast(combinef__3), lang.IFn_Cast(reducef__4), lang.IFn_Cast(A_arbace_core_reducers_A_const_61.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_12.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_62.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_63.GetRawRoot__O()))
}
























































































































































type A_arbace_core_reducers_A struct{ jrt.Object }

var A_arbace_core_reducers_A_const_pool *jrt.RefArray

var A_arbace_core_reducers_A_const_0 *lang.Var

var A_arbace_core_reducers_A_const_1 any

var A_arbace_core_reducers_A_const_2 *lang.Var

var A_arbace_core_reducers_A_const_3 any

var A_arbace_core_reducers_A_const_4 *lang.Keyword

var A_arbace_core_reducers_A_const_5 any

var A_arbace_core_reducers_A_const_6 *lang.Var

var A_arbace_core_reducers_A_const_7 *lang.Var

var A_arbace_core_reducers_A_const_8 *lang.Var

var A_arbace_core_reducers_A_const_9 *lang.Var

var A_arbace_core_reducers_A_const_10 any

var A_arbace_core_reducers_A_const_11 *lang.Var

var A_arbace_core_reducers_A_const_12 *lang.Var

var A_arbace_core_reducers_A_const_13 *lang.Var

var A_arbace_core_reducers_A_const_14 *lang.Var

var A_arbace_core_reducers_A_const_15 *lang.Var

var A_arbace_core_reducers_A_const_16 *lang.Var

var A_arbace_core_reducers_A_const_17 *jrt.Class

var A_arbace_core_reducers_A_const_18 *lang.Var

var A_arbace_core_reducers_A_const_19 *lang.Var

var A_arbace_core_reducers_A_const_20 any

var A_arbace_core_reducers_A_const_21 *lang.Var

var A_arbace_core_reducers_A_const_22 *lang.Var

var A_arbace_core_reducers_A_const_23 *lang.Var

var A_arbace_core_reducers_A_const_24 *lang.Var

var A_arbace_core_reducers_A_const_25 *lang.Var

var A_arbace_core_reducers_A_const_26 any

var A_arbace_core_reducers_A_const_27 any

var A_arbace_core_reducers_A_const_28 *lang.Var

var A_arbace_core_reducers_A_const_29 *lang.Var

var A_arbace_core_reducers_A_const_30 any

var A_arbace_core_reducers_A_const_31 *lang.Var

var A_arbace_core_reducers_A_const_32 any

var A_arbace_core_reducers_A_const_33 *lang.Var

var A_arbace_core_reducers_A_const_34 *lang.Var

var A_arbace_core_reducers_A_const_35 *lang.Var

var A_arbace_core_reducers_A_const_36 *lang.Var

var A_arbace_core_reducers_A_const_37 *lang.Var

var A_arbace_core_reducers_A_const_38 *lang.Var

var A_arbace_core_reducers_A_const_39 *lang.Var

var A_arbace_core_reducers_A_const_40 *lang.Var

var A_arbace_core_reducers_A_const_41 *lang.Var

var A_arbace_core_reducers_A_const_42 *lang.Var

var A_arbace_core_reducers_A_const_43 *lang.Var

var A_arbace_core_reducers_A_const_44 *lang.Var

var A_arbace_core_reducers_A_const_45 *lang.Var

var A_arbace_core_reducers_A_const_46 *lang.Var

var A_arbace_core_reducers_A_const_47 *lang.Var

var A_arbace_core_reducers_A_const_48 *lang.Var

var A_arbace_core_reducers_A_const_49 *lang.Var

var A_arbace_core_reducers_A_const_50 *lang.Var

var A_arbace_core_reducers_A_const_51 *lang.Var

var A_arbace_core_reducers_A_const_52 *lang.Var

var A_arbace_core_reducers_A_const_53 *lang.Var

var A_arbace_core_reducers_A_const_54 *lang.Keyword

var A_arbace_core_reducers_A_const_55 *lang.Var

var A_arbace_core_reducers_A_const_56 *lang.Var

var A_arbace_core_reducers_A_const_57 *lang.Var

var A_arbace_core_reducers_A_const_58 *lang.Var

var A_arbace_core_reducers_A_const_59 any

var A_arbace_core_reducers_A_const_60 *lang.Var

var A_arbace_core_reducers_A_const_61 *lang.Var

var A_arbace_core_reducers_A_const_62 *lang.Var

var A_arbace_core_reducers_A_const_63 *lang.Var

var A_arbace_core_reducers_A_init jrt.ClassInit

func A_arbace_core_reducers_A_Init() { if !A_arbace_core_reducers_A_init.Done() { A_arbace_core_reducers_A_init.Run(A_arbace_core_reducers_A_clinit) } }

func A_arbace_core_reducers_A_clinit() { A_arbace_core_reducers_A_clinit_p0(); A_arbace_core_reducers_A_clinit_p1(); A_arbace_core_reducers_A_clinit_p2(); A_arbace_core_reducers_A_clinit_p3(); A_arbace_core_reducers_A_clinit_p4(); A_arbace_core_reducers_A_clinit_p5() }

func A_arbace_core_reducers_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_reducers_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 85); A_arbace_core_reducers_A_const_0 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[21]); A_arbace_core_reducers_A_const_1 = A_arbace_core_reducers_A_const_pool.A[22]; A_arbace_core_reducers_A_const_2 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[23]); A_arbace_core_reducers_A_const_3 = A_arbace_core_reducers_A_const_pool.A[24]; A_arbace_core_reducers_A_const_4 = lang.Keyword_Cast(A_arbace_core_reducers_A_const_pool.A[25]); A_arbace_core_reducers_A_const_5 = A_arbace_core_reducers_A_const_pool.A[26]; A_arbace_core_reducers_A_const_6 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[27]); A_arbace_core_reducers_A_const_7 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[28]); A_arbace_core_reducers_A_const_8 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[29]); A_arbace_core_reducers_A_const_9 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[30]); A_arbace_core_reducers_A_const_10 = A_arbace_core_reducers_A_const_pool.A[31]; A_arbace_core_reducers_A_const_11 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[32]) }

func A_arbace_core_reducers_A_clinit_p1() { A_arbace_core_reducers_A_const_12 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[33]); A_arbace_core_reducers_A_const_13 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[34]); A_arbace_core_reducers_A_const_14 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[35]); A_arbace_core_reducers_A_const_15 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[36]); A_arbace_core_reducers_A_const_16 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[37]); A_arbace_core_reducers_A_const_17 = jrt.Class_Cast(A_arbace_core_reducers_A_const_pool.A[38]); A_arbace_core_reducers_A_const_18 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[39]); A_arbace_core_reducers_A_const_19 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[40]); A_arbace_core_reducers_A_const_20 = A_arbace_core_reducers_A_const_pool.A[41]; A_arbace_core_reducers_A_const_21 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[42]); A_arbace_core_reducers_A_const_22 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[43]); A_arbace_core_reducers_A_const_23 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[44]) }

func A_arbace_core_reducers_A_clinit_p2() { A_arbace_core_reducers_A_const_24 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[45]); A_arbace_core_reducers_A_const_25 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[46]); A_arbace_core_reducers_A_const_26 = A_arbace_core_reducers_A_const_pool.A[47]; A_arbace_core_reducers_A_const_27 = A_arbace_core_reducers_A_const_pool.A[48]; A_arbace_core_reducers_A_const_28 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[49]); A_arbace_core_reducers_A_const_29 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[50]); A_arbace_core_reducers_A_const_30 = A_arbace_core_reducers_A_const_pool.A[51]; A_arbace_core_reducers_A_const_31 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[52]); A_arbace_core_reducers_A_const_32 = A_arbace_core_reducers_A_const_pool.A[53]; A_arbace_core_reducers_A_const_33 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[54]); A_arbace_core_reducers_A_const_34 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[55]); A_arbace_core_reducers_A_const_35 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[56]); A_arbace_core_reducers_A_const_36 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[57]) }

func A_arbace_core_reducers_A_clinit_p3() { A_arbace_core_reducers_A_const_37 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[58]); A_arbace_core_reducers_A_const_38 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[59]); A_arbace_core_reducers_A_const_39 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[60]); A_arbace_core_reducers_A_const_40 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[61]); A_arbace_core_reducers_A_const_41 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[62]); A_arbace_core_reducers_A_const_42 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[63]); A_arbace_core_reducers_A_const_43 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[64]); A_arbace_core_reducers_A_const_44 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[65]); A_arbace_core_reducers_A_const_45 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[66]); A_arbace_core_reducers_A_const_46 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[67]); A_arbace_core_reducers_A_const_47 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[68]); A_arbace_core_reducers_A_const_48 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[69]) }

func A_arbace_core_reducers_A_clinit_p4() { A_arbace_core_reducers_A_const_49 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[70]); A_arbace_core_reducers_A_const_50 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[71]); A_arbace_core_reducers_A_const_51 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[72]); A_arbace_core_reducers_A_const_52 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[73]); A_arbace_core_reducers_A_const_53 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[74]); A_arbace_core_reducers_A_const_54 = lang.Keyword_Cast(A_arbace_core_reducers_A_const_pool.A[75]); A_arbace_core_reducers_A_const_55 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[76]); A_arbace_core_reducers_A_const_56 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[77]); A_arbace_core_reducers_A_const_57 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[78]); A_arbace_core_reducers_A_const_58 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[79]); A_arbace_core_reducers_A_const_59 = A_arbace_core_reducers_A_const_pool.A[80]; A_arbace_core_reducers_A_const_60 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[81]) }

func A_arbace_core_reducers_A_clinit_p5() { A_arbace_core_reducers_A_const_61 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[82]); A_arbace_core_reducers_A_const_62 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[83]); A_arbace_core_reducers_A_const_63 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[84]) }

func A_arbace_core_reducers_A_New() *A_arbace_core_reducers_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_A) Ctor() {}

func (t *A_arbace_core_reducers_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_A_class }

func (t *A_arbace_core_reducers_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_A); return ok }

func A_arbace_core_reducers_A_Cast(x any) *A_arbace_core_reducers_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_A_class)) }; return v }



type A_arbace_core_reducers_append_BANG__A struct{ j2g_header uint64 }

var A_arbace_core_reducers_append_BANG__A_fn_class *jrt.Class



type A_arbace_core_reducers_cat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_cat_A_fn_class *jrt.Class



type A_arbace_core_reducers_cat_fn__153000141_A struct{ j2g_header uint64; F_ctor any }

var A_arbace_core_reducers_cat_fn__153000141_A_fn_class *jrt.Class



type A_arbace_core_reducers_defcurried_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_defcurried_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_curried_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_do_curried_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_rfn_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_do_rfn_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_rfn_fn__153000066_A struct{ j2g_header uint64; F_k any }

var A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_drop_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000125_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_drop_fn__153000125_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000127_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_drop_fn__153000127_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A struct{ j2g_header uint64; F_cnt, F_f1 any }

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000004_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000004_A_New() *A_arbace_core_reducers_eval153000004_A { t := &A_arbace_core_reducers_eval153000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000004_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000004_A_class }

func (t *A_arbace_core_reducers_eval153000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000004_A); return ok }

func A_arbace_core_reducers_eval153000004_A_Cast(x any) *A_arbace_core_reducers_eval153000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000004_A_class)) }; return v }



type A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000008_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000008_A_New() *A_arbace_core_reducers_eval153000008_A { t := &A_arbace_core_reducers_eval153000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000008_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000008_A_class }

func (t *A_arbace_core_reducers_eval153000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000008_A); return ok }

func A_arbace_core_reducers_eval153000008_A_Cast(x any) *A_arbace_core_reducers_eval153000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000008_A_class)) }; return v }



type A_arbace_core_reducers_eval153000008_fn__153000009_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000031_A_New() *A_arbace_core_reducers_eval153000031_A { t := &A_arbace_core_reducers_eval153000031_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000031_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000031_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000031_A_class }

func (t *A_arbace_core_reducers_eval153000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000031_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000031_A); return ok }

func A_arbace_core_reducers_eval153000031_A_Cast(x any) *A_arbace_core_reducers_eval153000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000031_A_class)) }; return v }



type A_arbace_core_reducers_eval153000031_fn__153000032_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A struct{ j2g_header uint64; F_G__153000024 any }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000132_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000132_A_New() *A_arbace_core_reducers_eval153000132_A { t := &A_arbace_core_reducers_eval153000132_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000132_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000132_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000132_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000132_A_class }

func (t *A_arbace_core_reducers_eval153000132_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000132_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000132_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000132_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000132_A); return ok }

func A_arbace_core_reducers_eval153000132_A_Cast(x any) *A_arbace_core_reducers_eval153000132_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000132_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000132_A_class)) }; return v }



type A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000157_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000157_A_New() *A_arbace_core_reducers_eval153000157_A { t := &A_arbace_core_reducers_eval153000157_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000157_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000157_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000157_A_class }

func (t *A_arbace_core_reducers_eval153000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000157_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000157_A); return ok }

func A_arbace_core_reducers_eval153000157_A_Cast(x any) *A_arbace_core_reducers_eval153000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000157_A_class)) }; return v }



type A_arbace_core_reducers_eval153000157_fn__153000158_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000161_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000161_A_New() *A_arbace_core_reducers_eval153000161_A { t := &A_arbace_core_reducers_eval153000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000161_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000161_A_class }

func (t *A_arbace_core_reducers_eval153000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000161_A); return ok }

func A_arbace_core_reducers_eval153000161_A_Cast(x any) *A_arbace_core_reducers_eval153000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000161_A_class)) }; return v }



type A_arbace_core_reducers_eval153000161_fn__153000162_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000165_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000165_A_New() *A_arbace_core_reducers_eval153000165_A { t := &A_arbace_core_reducers_eval153000165_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000165_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000165_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000165_A_class }

func (t *A_arbace_core_reducers_eval153000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000165_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000165_A); return ok }

func A_arbace_core_reducers_eval153000165_A_Cast(x any) *A_arbace_core_reducers_eval153000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000165_A_class)) }; return v }



type A_arbace_core_reducers_eval153000165_fn__153000166_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000169_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000169_A_New() *A_arbace_core_reducers_eval153000169_A { t := &A_arbace_core_reducers_eval153000169_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000169_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000169_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000169_A_class }

func (t *A_arbace_core_reducers_eval153000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000169_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000169_A); return ok }

func A_arbace_core_reducers_eval153000169_A_Cast(x any) *A_arbace_core_reducers_eval153000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000169_A_class)) }; return v }



type A_arbace_core_reducers_eval153000169_fn__153000170_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_filter_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000094_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_filter_fn__153000094_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000096_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_filter_fn__153000096_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A struct{ j2g_header uint64; F_pred, F_f1 any }

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjfork_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjfork_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjinvoke_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjinvoke_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjjoin_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjjoin_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjtask_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjtask_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000104_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_fn__153000104_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000106_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_fn__153000106_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A struct{ j2g_header uint64; F_f1 any }

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class *jrt.Class



type A_arbace_core_reducers_fn__153000016_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fn__153000016_A_fn_class *jrt.Class



type A_arbace_core_reducers_fold_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fold_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldcat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_foldcat_A_fn_class *jrt.Class



type A_arbace_core_reducers_folder_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_folder_A_fn_class *jrt.Class



type A_arbace_core_reducers_folder_reify__153000055_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IObj() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_folder_reify__153000055_A_class }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_folder_reify__153000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); return ok }

func A_arbace_core_reducers_folder_reify__153000055_A_Cast(x any) *A_arbace_core_reducers_folder_reify__153000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_folder_reify__153000055_A_class)) }; return v }



type A_arbace_core_reducers_foldvec_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_foldvec_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fc__153000150_A struct{ j2g_header uint64; F_combinef, F_n, F_reducef any }

var A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A struct{ j2g_header uint64; F_combinef, F_n, F_child, F_reducef any }

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fn__153000154_A struct{ j2g_header uint64; F_combinef, F_fc, F_v1, F_v2 any }

var A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_map_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000078_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_map_fn__153000078_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000080_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_map_fn__153000080_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000080_fn__153000081_A struct{ j2g_header uint64; F_f, F_f1 any }

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_mapcat_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000085_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A struct{ j2g_header uint64; F_f1 any }

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A struct{ j2g_header uint64; F_f, F_f1 any }

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class *jrt.Class



type A_arbace_core_reducers_monoid_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_monoid_A_fn_class *jrt.Class



type A_arbace_core_reducers_monoid_m__153000147_A struct{ j2g_header uint64; F_op, F_ctor any }

var A_arbace_core_reducers_monoid_m__153000147_A_fn_class *jrt.Class



type A_arbace_core_reducers_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_reduce_A_fn_class *jrt.Class



type A_arbace_core_reducers_reducer_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_reducer_A_fn_class *jrt.Class



type A_arbace_core_reducers_reducer_reify__153000052_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IObj() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_reducer_reify__153000052_A_class }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_reducer_reify__153000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); return ok }

func A_arbace_core_reducers_reducer_reify__153000052_A_Cast(x any) *A_arbace_core_reducers_reducer_reify__153000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_reducer_reify__153000052_A_class)) }; return v }



type A_arbace_core_reducers_remove_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_remove_A_fn_class *jrt.Class



type A_arbace_core_reducers_remove_fn__153000101_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_remove_fn__153000101_A_fn_class *jrt.Class



type A_arbace_core_reducers_rfn_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_rfn_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_take_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000118_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_take_fn__153000118_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000120_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_take_fn__153000120_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000120_fn__153000121_A struct{ j2g_header uint64; F_cnt, F_f1 any }

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_take_while_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000111_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_take_while_fn__153000111_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000113_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_take_while_fn__153000113_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A struct{ j2g_header uint64; F_pred, F_f1 any }

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class *jrt.Class
