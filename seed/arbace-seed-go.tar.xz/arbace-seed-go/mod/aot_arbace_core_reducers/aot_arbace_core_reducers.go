//line aot_arbace_core_reducers.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New() *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A { A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_Init(); t := &A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_core_reducers_A_Init(); tmp6 = A_arbace_core_reducers_A_const_2; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_core_reducers_A_Init(); tmp8 = A_arbace_core_reducers_A_const_3; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_core_reducers_A_Init(); tmp10 = A_arbace_core_reducers_A_const_4; tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10); var tmp11 *lang.Var; A_arbace_core_reducers_A_Init(); tmp11 = A_arbace_core_reducers_A_const_0; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_core_reducers_A_Init(); tmp13 = A_arbace_core_reducers_A_const_5; tmp3 = tmp12.Invoke_O__O(tmp13) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp14 != nil { panic(tmp14) }; return tmp3 }
//line :9:1
func A_arbace_core_reducers_eval153000008_fn__153000009_A_New() *A_arbace_core_reducers_eval153000008_fn__153000009_A { A_arbace_core_reducers_eval153000008_fn__153000009_A_Init(); t := &A_arbace_core_reducers_eval153000008_fn__153000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_7; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_10; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_core_reducers_A_Init(); tmp7 = A_arbace_core_reducers_A_const_8; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_core_reducers_A_Init(); tmp9 = A_arbace_core_reducers_A_const_9; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }












func A_arbace_core_reducers_fn__153000016_A_New() *A_arbace_core_reducers_fn__153000016_A { A_arbace_core_reducers_fn__153000016_A_Init(); t := &A_arbace_core_reducers_fn__153000016_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Ctor() {}
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Invoke_O__O(self any) any { return jrt.ForkJoinPool_New() }

func A_arbace_core_reducers_fjtask_A_New() *A_arbace_core_reducers_fjtask_A { A_arbace_core_reducers_fjtask_A_Init(); t := &A_arbace_core_reducers_fjtask_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Invoke_O_O__O(self, f__0 any) any {
	return jrt.ForkJoinTask_Adapt_Callable__ForkJoinTask(jrt.Callable_Cast(f__0))
}
func A_arbace_core_reducers_fjinvoke_A_New() *A_arbace_core_reducers_fjinvoke_A { A_arbace_core_reducers_fjinvoke_A_Init(); t := &A_arbace_core_reducers_fjinvoke_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Ctor() {}
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.ForkJoinTask_InForkJoinPool__Z() {
		return lang.IFn_Cast(f__0).Invoke__O() } else {
			var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_12; var tmp4 *jrt.ForkJoinPool = jrt.As[*jrt.ForkJoinPool](tmp2.Invoke_O__O(jrt.NN(tmp3).GetRawRoot__O())); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_11; return jrt.NN(tmp4).Invoke_ForkJoinTask__O(jrt.ForkJoinTask_Cast(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__0)))
		} }
func A_arbace_core_reducers_fjfork_A_New() *A_arbace_core_reducers_fjfork_A { A_arbace_core_reducers_fjfork_A_Init(); t := &A_arbace_core_reducers_fjfork_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Ctor() {}
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Fork__ForkJoinTask() }

func A_arbace_core_reducers_fjjoin_A_New() *A_arbace_core_reducers_fjjoin_A { A_arbace_core_reducers_fjjoin_A_Init(); t := &A_arbace_core_reducers_fjjoin_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Ctor() {}
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Join__O() }



func A_arbace_core_reducers_reduce_A_New() *A_arbace_core_reducers_reduce_A { A_arbace_core_reducers_reduce_A_Init(); t := &A_arbace_core_reducers_reduce_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Ctor() {}
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O_O__O(self, f__0, init__1, coll__2 any) any {





	if jrt.Map_InstanceOf(coll__2) {
		var target_1 any = coll__2; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_InstanceOf(target_1); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_Cast(target_1).Kv_reduce_O_O__O(f__0, init__1) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_13; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_1, f__0, init__1) } } else {
			var target_2 any = coll__2; var tmp4 bool; var tmp5 bool; tmp5 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_2); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp4 = tmp5; if tmp4 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_2).Coll_reduce_O_O__O(f__0, init__1) } else { var tmp6 *lang.Var; A_arbace_core_reducers_A_Init(); tmp6 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(target_2, f__0, init__1) } } }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(f__0, lang.IFn_Cast(f__0).Invoke__O(), coll__1)
}




func A_arbace_core_reducers_eval153000031_fn__153000032_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_A { A_arbace_core_reducers_eval153000031_fn__153000032_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__153000024__2_ any; var tmp1 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New(); var tmp2 *jrt.Class; A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_Init(); tmp2 = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class; G__153000024__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(G__153000024__2_); var tmp4 *jrt.Class; A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_Init(); tmp4 = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(p0 any) *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A { A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Ctor_O(c__G__153000024 any) { t.F_G__153000024 = c__G__153000024 }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4 any) any { var cache__231000236__auto____5 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____6 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____5)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__coll__153000039__1)); if jrt.A2g_Truth(f__231000237__auto____6) { return lang.IFn_Cast(f__231000237__auto____6).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } else { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_17; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__coll__153000039__1, tmp3.Ref(), t.F_G__153000024)).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A { A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000033__1, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4 any) any { var target_3 any = gf__coll__153000033__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_3 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_3) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_3, Lit_82, jrt.RefArrayOf(jrt.Object_class, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4)) } else { return A_arbace_core_reducers_CollFold_A_Cast(target_3).Coll_fold_O_O_O__O(gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4) } }


func A_arbace_core_reducers_fold_A_New() *A_arbace_core_reducers_fold_A { A_arbace_core_reducers_fold_A_Init(); t := &A_arbace_core_reducers_fold_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O_O__O(self, n__0, combinef__1, reducef__2, coll__3 any) any {













	var target_4 any = coll__3; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_4); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_4).Coll_fold_O_O_O__O(n__0, combinef__1, reducef__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_18; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(target_4, n__0, combinef__1, reducef__2) } }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O__O(self, combinef__0, reducef__1, coll__2 any) any {











	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_20; return tmp2.Invoke_O_O_O_O__O(tmp3, combinef__0, reducef__1, coll__2) }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O__O(self, reducef__0, coll__1 any) any {










	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_19; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(reducef__0, reducef__0, coll__1)
}



func A_arbace_core_reducers_reducer_A_New() *A_arbace_core_reducers_reducer_A { A_arbace_core_reducers_reducer_A_Init(); t := &A_arbace_core_reducers_reducer_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :74:1
func A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_reducer_reify__153000052_A { t := &A_arbace_core_reducers_reducer_reify__153000052_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_5 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_5); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_5) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_5).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_5, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O__O(f1__1 any) any {


	var target_6 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_6); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_6) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_6).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_6, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }






func A_arbace_core_reducers_folder_A_New() *A_arbace_core_reducers_folder_A { A_arbace_core_reducers_folder_A_Init(); t := &A_arbace_core_reducers_folder_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Ctor() {}
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :88:1
func A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_folder_reify__153000055_A { t := &A_arbace_core_reducers_folder_reify__153000055_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {








	var target_7 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_7); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_7) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_7).Coll_fold_O_O_O__O(n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_18; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(target_7, n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_8 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_8); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_8) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_8).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_8, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O__O(f1__1 any) any {


	var target_9 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_9); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_9) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_9).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_9, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }










func A_arbace_core_reducers_do_curried_A_New() *A_arbace_core_reducers_do_curried_A { A_arbace_core_reducers_do_curried_A_Init(); t := &A_arbace_core_reducers_do_curried_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Ctor() {}
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Invoke_O_O_O_O_O_O__O(self, name__0, doc__1, meta__2, args__3, body__4 any) any { var cargs__6 any; var tmp1 *lang.Var;

	A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_23; cargs__6 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(args__3)); var tmp4 *lang.Var; A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_22; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_core_reducers_A_Init(); tmp6 = A_arbace_core_reducers_A_const_24; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_core_reducers_A_Init(); tmp8 = A_arbace_core_reducers_A_const_25; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_core_reducers_A_Init(); tmp10 = A_arbace_core_reducers_A_const_26; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Var; A_arbace_core_reducers_A_Init(); tmp12 = A_arbace_core_reducers_A_const_25; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(name__0); var tmp14 *lang.Var; A_arbace_core_reducers_A_Init(); tmp14 = A_arbace_core_reducers_A_const_25; var tmp15 any = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(doc__1); var tmp16 *lang.Var; A_arbace_core_reducers_A_Init(); tmp16 = A_arbace_core_reducers_A_const_25; var tmp17 any = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(meta__2); var tmp18 *lang.Var; A_arbace_core_reducers_A_Init(); tmp18 = A_arbace_core_reducers_A_const_25; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_core_reducers_A_Init(); tmp20 = A_arbace_core_reducers_A_const_22; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_core_reducers_A_Init(); tmp22 = A_arbace_core_reducers_A_const_24; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_core_reducers_A_Init(); tmp24 = A_arbace_core_reducers_A_const_25; var tmp25 any = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(cargs__6); var tmp26 *lang.Var; A_arbace_core_reducers_A_Init(); tmp26 = A_arbace_core_reducers_A_const_25; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_core_reducers_A_Init(); tmp28 = A_arbace_core_reducers_A_const_22; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_core_reducers_A_Init(); tmp30 = A_arbace_core_reducers_A_const_24; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_core_reducers_A_Init(); tmp32 = A_arbace_core_reducers_A_const_25; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; A_arbace_core_reducers_A_Init(); tmp34 = A_arbace_core_reducers_A_const_27; var tmp35 any = tmp33.Invoke_O__O(tmp34); var tmp36 *lang.Var; A_arbace_core_reducers_A_Init(); tmp36 = A_arbace_core_reducers_A_const_25; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Var; A_arbace_core_reducers_A_Init(); tmp38 = A_arbace_core_reducers_A_const_28; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_core_reducers_A_Init(); tmp40 = A_arbace_core_reducers_A_const_29; var tmp41 any = jrt.NN(tmp40).GetRawRoot__O(); var tmp42 *lang.Var; A_arbace_core_reducers_A_Init(); tmp42 = A_arbace_core_reducers_A_const_22; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_core_reducers_A_Init(); tmp44 = A_arbace_core_reducers_A_const_24; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_core_reducers_A_Init(); tmp46 = A_arbace_core_reducers_A_const_25; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any; A_arbace_core_reducers_A_Init(); tmp48 = A_arbace_core_reducers_A_const_30; var tmp49 any = tmp37.Invoke_O__O(tmp39.Invoke_O_O__O(tmp41, tmp43.Invoke_O__O(tmp45.Invoke_O__O(tmp47.Invoke_O__O(tmp48))))); var tmp50 *lang.Var; A_arbace_core_reducers_A_Init(); tmp50 = A_arbace_core_reducers_A_const_25; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_core_reducers_A_Init(); tmp52 = A_arbace_core_reducers_A_const_22; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_core_reducers_A_Init(); tmp54 = A_arbace_core_reducers_A_const_24; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_core_reducers_A_Init(); tmp56 = A_arbace_core_reducers_A_const_25; var tmp57 any = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(name__0); var tmp58 *lang.Var; A_arbace_core_reducers_A_Init(); tmp58 = A_arbace_core_reducers_A_const_25; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any; A_arbace_core_reducers_A_Init(); tmp60 = A_arbace_core_reducers_A_const_30; var tmp61 any = tmp19.Invoke_O__O(tmp21.Invoke_O__O(tmp23.Invoke_O_O__O(tmp25, tmp27.Invoke_O__O(tmp29.Invoke_O__O(tmp31.Invoke_O_O_O__O(tmp35, tmp49, tmp51.Invoke_O__O(tmp53.Invoke_O__O(tmp55.Invoke_O_O_O__O(tmp57, cargs__6, tmp59.Invoke_O__O(tmp60)))))))))); var tmp62 *lang.Var; A_arbace_core_reducers_A_Init(); tmp62 = A_arbace_core_reducers_A_const_25; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_core_reducers_A_Init(); tmp64 = A_arbace_core_reducers_A_const_22; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 *lang.Var; A_arbace_core_reducers_A_Init(); tmp66 = A_arbace_core_reducers_A_const_24; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 *lang.Var; A_arbace_core_reducers_A_Init(); tmp68 = A_arbace_core_reducers_A_const_25; return tmp5.Invoke_O__O(tmp7.Invoke_O_O_O_O_O_O__O(tmp11, tmp13, tmp15, tmp17, tmp61, tmp63.Invoke_O__O(tmp65.Invoke_O__O(tmp67.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(args__3), body__4))))) }




func A_arbace_core_reducers_defcurried_A_New() *A_arbace_core_reducers_defcurried_A { A_arbace_core_reducers_defcurried_A_Init(); t := &A_arbace_core_reducers_defcurried_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) Ctor() {}
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) DoInvoke_O_O_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, doc__3, meta__4, args__5, body__6 any) any {



	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_31; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O__O(name__2, doc__3, meta__4, args__5, body__6)
}
func A_arbace_core_reducers_do_rfn_A_New() *A_arbace_core_reducers_do_rfn_A { A_arbace_core_reducers_do_rfn_A_Init(); t := &A_arbace_core_reducers_do_rfn_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Ctor() {}
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Invoke_O_O_O_O__O(self, f1__0, k__1, fkv__2 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_24; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_25; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_core_reducers_A_Init(); tmp7 = A_arbace_core_reducers_A_const_32; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_core_reducers_A_Init(); tmp9 = A_arbace_core_reducers_A_const_25; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_core_reducers_A_Init(); tmp11 = A_arbace_core_reducers_A_const_22; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_core_reducers_A_Init(); tmp13 = A_arbace_core_reducers_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_core_reducers_A_Init(); tmp15 = A_arbace_core_reducers_A_const_25; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_core_reducers_A_Init(); tmp17 = A_arbace_core_reducers_A_const_28; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_core_reducers_A_Init(); tmp19 = A_arbace_core_reducers_A_const_29; var tmp20 any = jrt.NN(tmp19).GetRawRoot__O(); var tmp21 *lang.Var; A_arbace_core_reducers_A_Init(); tmp21 = A_arbace_core_reducers_A_const_22; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_core_reducers_A_Init(); tmp23 = A_arbace_core_reducers_A_const_24; var tmp24 any = tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp20, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke__O()))); var tmp25 *lang.Var; A_arbace_core_reducers_A_Init(); tmp25 = A_arbace_core_reducers_A_const_25; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_core_reducers_A_Init(); tmp27 = A_arbace_core_reducers_A_const_22; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_core_reducers_A_Init(); tmp29 = A_arbace_core_reducers_A_const_24; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_core_reducers_A_Init(); tmp31 = A_arbace_core_reducers_A_const_25; var tmp32 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp24, tmp26.Invoke_O__O(tmp28.Invoke_O__O(tmp30.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(f1__0))))))); var tmp33 *lang.Var; A_arbace_core_reducers_A_Init(); tmp33 = A_arbace_core_reducers_A_const_25; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_core_reducers_A_Init(); tmp35 = A_arbace_core_reducers_A_const_33; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any = A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(k__1); var tmp38 *jrt.Class; A_arbace_core_reducers_do_rfn_fn__153000066_A_Init(); tmp38 = A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class; var tmp39 any = tmp34.Invoke_O__O(tmp36.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil), fkv__2)); var tmp40 *lang.Var; A_arbace_core_reducers_A_Init(); tmp40 = A_arbace_core_reducers_A_const_25; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(tmp8, tmp32, tmp39, lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(fkv__2))) }


func A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(p0 any) *A_arbace_core_reducers_do_rfn_fn__153000066_A { A_arbace_core_reducers_do_rfn_fn__153000066_A_Init(); t := &A_arbace_core_reducers_do_rfn_fn__153000066_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Invoke_O_O__O(self, p1__153000065_SHARP___1 any) any {
	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_34; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__153000065_SHARP___1)) {
		var tmp2 any; var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__153000065_SHARP___1)) { var tmp4 *lang.Var; A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_21; tmp2 = jrt.NN(tmp4).GetRawRoot__O() } else { var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_36; tmp2 = jrt.NN(tmp5).GetRawRoot__O() }; var tmp6 lang.IFn = lang.IFn_Cast(tmp2); var tmp7 *lang.Var; A_arbace_core_reducers_A_Init(); tmp7 = A_arbace_core_reducers_A_const_37; return tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, t.F_k)), p1__153000065_SHARP___1)) } else {
//line :116:1
			return p1__153000065_SHARP___1
		}
}




func A_arbace_core_reducers_rfn_A_New() *A_arbace_core_reducers_rfn_A { A_arbace_core_reducers_rfn_A_Init(); t := &A_arbace_core_reducers_rfn_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Ctor() {}
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, p__153000069__2, fkv__3 any) any { var vec__153000070__5 any = p__153000069__2; var f1__6 any = lang.RT_Nth_O_I_O__O(vec__153000070__5, lang.RT_IntCast_J__I(0), nil); var k__7 any = lang.RT_Nth_O_I_O__O(vec__153000070__5, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var;


	A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_38; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(f1__6, k__7, fkv__3) }

func A_arbace_core_reducers_map_A_New() *A_arbace_core_reducers_map_A { A_arbace_core_reducers_map_A_Init(); t := &A_arbace_core_reducers_map_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Ctor() {}
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_map_fn__153000080_A_New_O(f__0); var tmp4 *jrt.Class; A_arbace_core_reducers_map_fn__153000080_A_Init(); tmp4 = A_arbace_core_reducers_map_fn__153000080_A_fn_class; return tmp2.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any = A_arbace_core_reducers_map_fn__153000078_A_New_O(f__0); var tmp2 *jrt.Class; A_arbace_core_reducers_map_fn__153000078_A_Init(); tmp2 = A_arbace_core_reducers_map_fn__153000078_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :128:1
func A_arbace_core_reducers_map_fn__153000078_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000078_A { A_arbace_core_reducers_map_fn__153000078_A_Init(); t := &A_arbace_core_reducers_map_fn__153000078_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_40; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_f, x__153000058__auto____1) }




func A_arbace_core_reducers_map_fn__153000080_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000080_A { A_arbace_core_reducers_map_fn__153000080_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_A{}; t.Ctor_O(p0); return t }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(t.F_f, f1__1); var tmp2 *jrt.Class; A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_Init(); tmp2 = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :134:1
func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A { A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_fn__153000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O__O(v__2)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_mapcat_A_New() *A_arbace_core_reducers_mapcat_A { A_arbace_core_reducers_mapcat_A_Init(); t := &A_arbace_core_reducers_mapcat_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Ctor() {}
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {




	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(f__0); var tmp4 *jrt.Class; A_arbace_core_reducers_mapcat_fn__153000087_A_Init(); tmp4 = A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class; return tmp2.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any = A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(f__0); var tmp2 *jrt.Class; A_arbace_core_reducers_mapcat_fn__153000085_A_Init(); tmp2 = A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :138:1
func A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000085_A { A_arbace_core_reducers_mapcat_fn__153000085_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000085_A{}; t.Ctor_O(p0); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_42; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_f, x__153000058__auto____1) }





func A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_A { A_arbace_core_reducers_mapcat_fn__153000087_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Invoke_O_O__O(self, f1__1 any) any { var f1__2 any; var tmp1 any = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(f1__1); var tmp2 *jrt.Class;
												A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_Init(); tmp2 = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class; f1__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any =




	A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(t.F_f, f1__2); var tmp4 *jrt.Class; A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_Init(); tmp4 = A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }
//line :145:1
func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A { A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any { var x__4 any = lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3); if



	lang.RT_IsReduced_O__Z(x__4) { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_41; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__4) } else { return x__4 } }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var x__3 any = lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2); if

	lang.RT_IsReduced_O__Z(x__3) { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_41; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__3) } else { return x__3 } }


func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A { A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_f1; return tmp2.Invoke_O_O_O__O(tmp3, ret__1, lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3)) }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_f1; return tmp2.Invoke_O_O_O__O(tmp3, ret__1, lang.IFn_Cast(t.F_f).Invoke_O__O(v__2)) }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_filter_A_New() *A_arbace_core_reducers_filter_A { A_arbace_core_reducers_filter_A_Init(); t := &A_arbace_core_reducers_filter_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Ctor() {}
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_filter_fn__153000096_A_New_O(pred__0); var tmp4 *jrt.Class; A_arbace_core_reducers_filter_fn__153000096_A_Init(); tmp4 = A_arbace_core_reducers_filter_fn__153000096_A_fn_class; return tmp2.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_filter_fn__153000094_A_New_O(pred__0); var tmp2 *jrt.Class; A_arbace_core_reducers_filter_fn__153000094_A_Init(); tmp2 = A_arbace_core_reducers_filter_fn__153000094_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :154:1
func A_arbace_core_reducers_filter_fn__153000094_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000094_A { A_arbace_core_reducers_filter_fn__153000094_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000094_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_43; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_pred, x__153000058__auto____1) }





func A_arbace_core_reducers_filter_fn__153000096_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000096_A { A_arbace_core_reducers_filter_fn__153000096_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(t.F_pred, f1__1); var tmp2 *jrt.Class; A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_Init(); tmp2 = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :161:1
func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A { A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.A2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :163:1
			return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.A2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_remove_A_New() *A_arbace_core_reducers_remove_A { A_arbace_core_reducers_remove_A_Init(); t := &A_arbace_core_reducers_remove_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Ctor() {}
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_43; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_44; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(pred__0), coll__1) }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_remove_fn__153000101_A_New_O(pred__0); var tmp2 *jrt.Class; A_arbace_core_reducers_remove_fn__153000101_A_Init(); tmp2 = A_arbace_core_reducers_remove_fn__153000101_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :167:1
func A_arbace_core_reducers_remove_fn__153000101_A_New_O(p0 any) *A_arbace_core_reducers_remove_fn__153000101_A { A_arbace_core_reducers_remove_fn__153000101_A_Init(); t := &A_arbace_core_reducers_remove_fn__153000101_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_45; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_pred, x__153000058__auto____1) }






func A_arbace_core_reducers_flatten_A_New() *A_arbace_core_reducers_flatten_A { A_arbace_core_reducers_flatten_A_Init(); t := &A_arbace_core_reducers_flatten_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O_O__O(self, coll__0 any) any {





	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_flatten_fn__153000106_A_New(); var tmp4 *jrt.Class; A_arbace_core_reducers_flatten_fn__153000106_A_Init(); tmp4 = A_arbace_core_reducers_flatten_fn__153000106_A_fn_class; return tmp2.Invoke_O_O__O(coll__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_core_reducers_flatten_fn__153000104_A_New(); var tmp2 *jrt.Class; A_arbace_core_reducers_flatten_fn__153000104_A_Init(); tmp2 = A_arbace_core_reducers_flatten_fn__153000104_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :174:1
func A_arbace_core_reducers_flatten_fn__153000104_A_New() *A_arbace_core_reducers_flatten_fn__153000104_A { A_arbace_core_reducers_flatten_fn__153000104_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000104_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_46; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__153000058__auto____1) }






func A_arbace_core_reducers_flatten_fn__153000106_A_New() *A_arbace_core_reducers_flatten_fn__153000106_A { A_arbace_core_reducers_flatten_fn__153000106_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Ctor() {}
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(f1__1); var tmp2 *jrt.Class; A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_Init(); tmp2 = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :182:1
func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(p0 any) *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A { A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A{}; t.Ctor_O(p0); return t }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any {


	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_34; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__2)) {
		var target_10 any; var tmp2 *lang.Var; A_arbace_core_reducers_A_Init(); tmp2 = A_arbace_core_reducers_A_const_46; target_10 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(v__2); var tmp3 bool; var tmp4 bool; tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_10); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_10) }; tmp3 = tmp4; if tmp3 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_10).Coll_reduce_O_O__O(t.F_f1, ret__1) } else { var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O_O__O(target_10, t.F_f1, ret__1) } } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_f1).Invoke__O()
}




func A_arbace_core_reducers_take_while_A_New() *A_arbace_core_reducers_take_while_A { A_arbace_core_reducers_take_while_A_Init(); t := &A_arbace_core_reducers_take_while_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Ctor() {}
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {



	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_47; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_take_while_fn__153000113_A_New_O(pred__0); var tmp4 *jrt.Class; A_arbace_core_reducers_take_while_fn__153000113_A_Init(); tmp4 = A_arbace_core_reducers_take_while_fn__153000113_A_fn_class; return tmp2.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_take_while_fn__153000111_A_New_O(pred__0); var tmp2 *jrt.Class; A_arbace_core_reducers_take_while_fn__153000111_A_Init(); tmp2 = A_arbace_core_reducers_take_while_fn__153000111_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :189:1
func A_arbace_core_reducers_take_while_fn__153000111_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000111_A { A_arbace_core_reducers_take_while_fn__153000111_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000111_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_48; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_pred, x__153000058__auto____1) }




func A_arbace_core_reducers_take_while_fn__153000113_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000113_A { A_arbace_core_reducers_take_while_fn__153000113_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(t.F_pred, f1__1); var tmp2 *jrt.Class; A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_Init(); tmp2 = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :195:1
func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A { A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.A2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
			var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_41; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(ret__1) } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.A2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_41; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(ret__1) } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_take_A_New() *A_arbace_core_reducers_take_A { A_arbace_core_reducers_take_A_Init(); t := &A_arbace_core_reducers_take_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Ctor() {}
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_47; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_take_fn__153000120_A_New_O(n__0); var tmp4 *jrt.Class; A_arbace_core_reducers_take_fn__153000120_A_Init(); tmp4 = A_arbace_core_reducers_take_fn__153000120_A_fn_class; return tmp2.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_core_reducers_take_fn__153000118_A_New_O(n__0); var tmp2 *jrt.Class; A_arbace_core_reducers_take_fn__153000118_A_Init(); tmp2 = A_arbace_core_reducers_take_fn__153000118_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :201:1
func A_arbace_core_reducers_take_fn__153000118_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000118_A { A_arbace_core_reducers_take_fn__153000118_A_Init(); t := &A_arbace_core_reducers_take_fn__153000118_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_52; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_n, x__153000058__auto____1) }




func A_arbace_core_reducers_take_fn__153000120_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000120_A { A_arbace_core_reducers_take_fn__153000120_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_A{}; t.Ctor_O(p0); return t }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any; var tmp1 *lang.Var;
												A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_49; cnt__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_n); var tmp2 any =
												A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(cnt__2, f1__1); var tmp3 *jrt.Class; A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_Init(); tmp3 = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil) }
//line :208:1
func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A { A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_fn__153000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_cnt; var tmp4 *lang.Var; A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_51; tmp2.Invoke_O_O__O(tmp3, jrt.NN(tmp4).GetRawRoot__O())
	var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_7; if lang.Numbers_IsNeg_O__Z(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t.F_cnt)) {
		var tmp6 *lang.Var; A_arbace_core_reducers_A_Init(); tmp6 = A_arbace_core_reducers_A_const_41; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(ret__1) } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_cnt; var tmp4 *lang.Var; A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_51; tmp2.Invoke_O_O__O(tmp3, jrt.NN(tmp4).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_7; if lang.Numbers_IsNeg_O__Z(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t.F_cnt)) { var tmp6 *lang.Var; A_arbace_core_reducers_A_Init(); tmp6 = A_arbace_core_reducers_A_const_41; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(ret__1) } else { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }






func A_arbace_core_reducers_drop_A_New() *A_arbace_core_reducers_drop_A { A_arbace_core_reducers_drop_A_Init(); t := &A_arbace_core_reducers_drop_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Ctor() {}
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_47; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_drop_fn__153000127_A_New_O(n__0); var tmp4 *jrt.Class; A_arbace_core_reducers_drop_fn__153000127_A_Init(); tmp4 = A_arbace_core_reducers_drop_fn__153000127_A_fn_class; return tmp2.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_core_reducers_drop_fn__153000125_A_New_O(n__0); var tmp2 *jrt.Class; A_arbace_core_reducers_drop_fn__153000125_A_Init(); tmp2 = A_arbace_core_reducers_drop_fn__153000125_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :215:1
func A_arbace_core_reducers_drop_fn__153000125_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000125_A { A_arbace_core_reducers_drop_fn__153000125_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000125_A{}; t.Ctor_O(p0); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_53; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_n, x__153000058__auto____1) }




func A_arbace_core_reducers_drop_fn__153000127_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000127_A { A_arbace_core_reducers_drop_fn__153000127_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any; var tmp1 *lang.Var;
												A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_49; cnt__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_n); var tmp2 any =
												A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(cnt__2, f1__1); var tmp3 *jrt.Class; A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_Init(); tmp3 = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil) }
//line :222:1
func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A { A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_cnt; var tmp4 *lang.Var; A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_51; tmp2.Invoke_O_O__O(tmp3, jrt.NN(tmp4).GetRawRoot__O())
	var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_7; if lang.Numbers_IsNeg_O__Z(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t.F_cnt)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :225:1
			return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_cnt; var tmp4 *lang.Var; A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_51; tmp2.Invoke_O_O__O(tmp3, jrt.NN(tmp4).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_7; if lang.Numbers_IsNeg_O__Z(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t.F_cnt)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }







func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New() *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A { A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_Init(); t := &A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Ctor() {}
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Invoke_O_O_O_O__O(self, cnt__1, left__2, right__3 any) any { return A_arbace_core_reducers_Cat_A_New_O_O_O(cnt__1, left__2, right__3) }
























func A_arbace_core_reducers_cat_A_New() *A_arbace_core_reducers_cat_A { A_arbace_core_reducers_cat_A_Init(); t := &A_arbace_core_reducers_cat_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Ctor() {}
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O_O__O(self, left__0, right__1 any) any {













	if lang.Numbers_IsZero_J__Z(int64(lang.RT_Count_O__I(left__0))) { return right__1 } else { if lang.Numbers_IsZero_J__Z(int64(lang.RT_Count_O__I(right__1))) { return left__0 } else { var tmp1 *lang.Keyword; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_54; if tmp1 != nil { return A_arbace_core_reducers_Cat_A_New_O_O_O(jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(int64(lang.RT_Count_O__I(left__0)), int64(lang.RT_Count_O__I(right__1)))).Ref(), left__0, right__1) } else { return nil } } } }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O__O(self, ctor__0 any) any {









	var tmp1 any = A_arbace_core_reducers_cat_fn__153000141_A_New_O(ctor__0); var tmp2 *jrt.Class; A_arbace_core_reducers_cat_fn__153000141_A_Init(); tmp2 = A_arbace_core_reducers_cat_fn__153000141_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O__O(self any) any { return jrt.ArrayList_New() }









func A_arbace_core_reducers_cat_fn__153000141_A_New_O(p0 any) *A_arbace_core_reducers_cat_fn__153000141_A { A_arbace_core_reducers_cat_fn__153000141_A_Init(); t := &A_arbace_core_reducers_cat_fn__153000141_A{}; t.Ctor_O(p0); return t }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Ctor_O(c__ctor any) { t.F_ctor = c__ctor }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O_O_O__O(self, left__1, right__2 any) any {

	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_55; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(left__1, right__2) }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}







func A_arbace_core_reducers_append_BANG__A_New() *A_arbace_core_reducers_append_BANG__A { A_arbace_core_reducers_append_BANG__A_Init(); t := &A_arbace_core_reducers_append_BANG__A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Ctor() {}
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Invoke_O_O_O__O(self, acc__0, x__1 any) any { var G__153000144__3_ any = acc__0;



	jrt.Boolean_ValueOf_Z__Boolean(jrt.Collection_Cast(G__153000144__3_).Add_O__Z(x__1)); return G__153000144__3_ }

func A_arbace_core_reducers_foldcat_A_New() *A_arbace_core_reducers_foldcat_A { A_arbace_core_reducers_foldcat_A_Init(); t := &A_arbace_core_reducers_foldcat_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Ctor() {}
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Invoke_O_O__O(self, coll__0 any) any {



	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_55; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_56; return tmp2.Invoke_O_O_O__O(tmp4, jrt.NN(tmp5).GetRawRoot__O(), coll__0)
}
func A_arbace_core_reducers_monoid_A_New() *A_arbace_core_reducers_monoid_A { A_arbace_core_reducers_monoid_A_Init(); t := &A_arbace_core_reducers_monoid_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Ctor() {}
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Invoke_O_O_O__O(self, op__0, ctor__1 any) any {





	var tmp1 any = A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(op__0, ctor__1); var tmp2 *jrt.Class; A_arbace_core_reducers_monoid_m__153000147_A_Init(); tmp2 = A_arbace_core_reducers_monoid_m__153000147_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :293:1
func A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_monoid_m__153000147_A { A_arbace_core_reducers_monoid_m__153000147_A_Init(); t := &A_arbace_core_reducers_monoid_m__153000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Ctor_O_O(c__op, c__ctor any) { t.F_op = c__op; t.F_ctor = c__ctor }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {

	return lang.IFn_Cast(t.F_op).Invoke_O_O__O(a__1, b__2) }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}


func A_arbace_core_reducers_foldvec_A_New() *A_arbace_core_reducers_foldvec_A { A_arbace_core_reducers_foldvec_A_Init(); t := &A_arbace_core_reducers_foldvec_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Ctor() {}
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Invoke_O_O_O_O_O__O(self, v__0, n__1, combinef__2, reducef__3 any) any {

	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_57; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__0)) {
		return lang.IFn_Cast(combinef__2).Invoke__O() } else {
//line :300:1
			if lang.Numbers_Lte_J_O__Z(int64(lang.RT_Count_O__I(v__0)), n__1) {

				var tmp2 *lang.Var; A_arbace_core_reducers_A_Init(); tmp2 = A_arbace_core_reducers_A_const_15; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(reducef__3, lang.IFn_Cast(combinef__2).Invoke__O(), v__0) } else {
//line :300:1
					var tmp3 *lang.Keyword; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_54; if tmp3 != nil { var split__5 int64 = lang.Numbers_Quotient_J_J__J(int64(lang.RT_Count_O__I(v__0)), 2); var v1__6 any; var tmp4 *lang.Var




						A_arbace_core_reducers_A_Init(); tmp4 = A_arbace_core_reducers_A_const_58; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_core_reducers_A_Init(); tmp6 = A_arbace_core_reducers_A_const_61; var tmp7 any = tmp6; v1__6 = tmp5.Invoke_O_O_O__O(v__0, tmp7, jrt.Long_ValueOf_J__Long(split__5).Ref())
//line :300:1
						var v2__7 any; var tmp8 *lang.Var





						A_arbace_core_reducers_A_Init(); tmp8 = A_arbace_core_reducers_A_const_58; v2__7 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O_O__O(v__0, jrt.Long_ValueOf_J__Long(split__5).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(v__0)).Ref())
//line :300:1
						var fc__8 any; var tmp9 any = A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(combinef__2, n__1, reducef__3); var tmp10 *jrt.Class






						A_arbace_core_reducers_foldvec_fc__153000150_A_Init(); tmp10 = A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class; fc__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)
						var tmp11 *lang.Var; A_arbace_core_reducers_A_Init(); tmp11 = A_arbace_core_reducers_A_const_60; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(combinef__2, fc__8, v1__6, v2__7); var tmp14 *jrt.Class; A_arbace_core_reducers_foldvec_fn__153000154_A_Init(); tmp14 = A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class; return tmp12.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)) } else {
//line :300:1
							return nil
						}
				}
		}
}


func A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_foldvec_fc__153000150_A { A_arbace_core_reducers_foldvec_fc__153000150_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Ctor_O_O_O(c__combinef, c__n, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Invoke_O_O__O(self, child__1 any) any { var tmp1 any = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(t.F_combinef, t.F_n, child__1, t.F_reducef); var tmp2 *jrt.Class; A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_Init(); tmp2 = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :307:1
func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A { A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Ctor_O_O_O_O(c__combinef, c__n, c__child, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_child = c__child; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_59; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_child, t.F_n, t.F_combinef, t.F_reducef) }
func A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fn__153000154_A { A_arbace_core_reducers_foldvec_fn__153000154_A_Init(); t := &A_arbace_core_reducers_foldvec_fn__153000154_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Ctor_O_O_O_O(c__combinef, c__fc, c__v1, c__v2 any) { t.F_combinef = c__combinef; t.F_fc = c__fc; t.F_v1 = c__v1; t.F_v2 = c__v2 }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Invoke_O__O(self any) any { var f1__1 any = lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v1); var t2__2 any; var tmp1 *lang.Var;

	A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_11; t2__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v2)); var tmp2 /*line :311:1*/*lang.Var; A_arbace_core_reducers_A_Init(); tmp2 = A_arbace_core_reducers_A_const_62; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t2__2); var tmp3 lang.IFn =
	lang.IFn_Cast(t.F_combinef); var tmp4 any = lang.IFn_Cast(f1__1).Invoke__O(); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_63; return tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t2__2)) }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_New() *A_arbace_core_reducers_eval153000157_fn__153000158_A { A_arbace_core_reducers_eval153000157_fn__153000158_A_Init(); t := &A_arbace_core_reducers_eval153000157_fn__153000158_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {



	return lang.IFn_Cast(combinef__3).Invoke__O() }
//line :314:1
func A_arbace_core_reducers_eval153000161_fn__153000162_A_New() *A_arbace_core_reducers_eval153000161_fn__153000162_A { A_arbace_core_reducers_eval153000161_fn__153000162_A_Init(); t := &A_arbace_core_reducers_eval153000161_fn__153000162_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {









	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(reducef__4, lang.IFn_Cast(combinef__3).Invoke__O(), coll__1) }
//line :314:1
func A_arbace_core_reducers_eval153000165_fn__153000166_A_New() *A_arbace_core_reducers_eval153000165_fn__153000166_A { A_arbace_core_reducers_eval153000165_fn__153000166_A_Init(); t := &A_arbace_core_reducers_eval153000165_fn__153000166_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Invoke_O_O_O_O_O__O(self, v__1, n__2, combinef__3, reducef__4 any) any {














	var tmp1 *lang.Var; A_arbace_core_reducers_A_Init(); tmp1 = A_arbace_core_reducers_A_const_59; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O__O(v__1, n__2, combinef__3, reducef__4) }
//line :314:1
func A_arbace_core_reducers_eval153000169_fn__153000170_A_New() *A_arbace_core_reducers_eval153000169_fn__153000170_A { A_arbace_core_reducers_eval153000169_fn__153000170_A_Init(); t := &A_arbace_core_reducers_eval153000169_fn__153000170_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Invoke_O_O_O_O_O__O(self, m__1, n__2, combinef__3, reducef__4 any) any {



















	var tmp1 *lang.PersistentHashMap = lang.PersistentHashMap_Cast(m__1); var tmp2 int64 = lang.RT_LongCast_O__J(n__2); var tmp3 lang.IFn = lang.IFn_Cast(combinef__3); var tmp4 lang.IFn = lang.IFn_Cast(reducef__4); var tmp5 *lang.Var; A_arbace_core_reducers_A_Init(); tmp5 = A_arbace_core_reducers_A_const_60; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_core_reducers_A_Init(); tmp7 = A_arbace_core_reducers_A_const_11; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_core_reducers_A_Init(); tmp9 = A_arbace_core_reducers_A_const_62; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_core_reducers_A_Init(); tmp11 = A_arbace_core_reducers_A_const_63; return jrt.NN(tmp1).Fold_J_IFn_IFn_IFn_IFn_IFn_IFn__O(tmp2, tmp3, tmp4, tmp6, tmp8, tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()))
}






















































































































































type A_arbace_core_reducers_A struct{ jrt.Object }

var A_arbace_core_reducers_A_const_0 *lang.Var

var A_arbace_core_reducers_A_const_1 *lang.Var

var A_arbace_core_reducers_A_const_2 any

var A_arbace_core_reducers_A_const_3 *lang.Keyword

var A_arbace_core_reducers_A_const_4 any

var A_arbace_core_reducers_A_const_5 any

var A_arbace_core_reducers_A_const_6 *lang.Var

var A_arbace_core_reducers_A_const_7 *lang.Var

var A_arbace_core_reducers_A_const_8 *lang.Var

var A_arbace_core_reducers_A_const_9 any

var A_arbace_core_reducers_A_const_10 *lang.Var

var A_arbace_core_reducers_A_const_11 *lang.Var

var A_arbace_core_reducers_A_const_12 *lang.Var

var A_arbace_core_reducers_A_const_13 *lang.Var

var A_arbace_core_reducers_A_const_14 *lang.Var

var A_arbace_core_reducers_A_const_15 *lang.Var

var A_arbace_core_reducers_A_const_16 *lang.Var

var A_arbace_core_reducers_A_const_17 *jrt.Class

var A_arbace_core_reducers_A_const_18 *lang.Var

var A_arbace_core_reducers_A_const_19 *lang.Var

var A_arbace_core_reducers_A_const_20 any

var A_arbace_core_reducers_A_const_21 *lang.Var

var A_arbace_core_reducers_A_const_22 *lang.Var

var A_arbace_core_reducers_A_const_23 *lang.Var

var A_arbace_core_reducers_A_const_24 *lang.Var

var A_arbace_core_reducers_A_const_25 *lang.Var

var A_arbace_core_reducers_A_const_26 any

var A_arbace_core_reducers_A_const_27 any

var A_arbace_core_reducers_A_const_28 *lang.Var

var A_arbace_core_reducers_A_const_29 *lang.Var

var A_arbace_core_reducers_A_const_30 any

var A_arbace_core_reducers_A_const_31 *lang.Var

var A_arbace_core_reducers_A_const_32 any

var A_arbace_core_reducers_A_const_33 *lang.Var

var A_arbace_core_reducers_A_const_34 *lang.Var

var A_arbace_core_reducers_A_const_35 *lang.Var

var A_arbace_core_reducers_A_const_36 *lang.Var

var A_arbace_core_reducers_A_const_37 *lang.Var

var A_arbace_core_reducers_A_const_38 *lang.Var

var A_arbace_core_reducers_A_const_39 *lang.Var

var A_arbace_core_reducers_A_const_40 *lang.Var

var A_arbace_core_reducers_A_const_41 *lang.Var

var A_arbace_core_reducers_A_const_42 *lang.Var

var A_arbace_core_reducers_A_const_43 *lang.Var

var A_arbace_core_reducers_A_const_44 *lang.Var

var A_arbace_core_reducers_A_const_45 *lang.Var

var A_arbace_core_reducers_A_const_46 *lang.Var

var A_arbace_core_reducers_A_const_47 *lang.Var

var A_arbace_core_reducers_A_const_48 *lang.Var

var A_arbace_core_reducers_A_const_49 *lang.Var

var A_arbace_core_reducers_A_const_50 *lang.Var

var A_arbace_core_reducers_A_const_51 *lang.Var

var A_arbace_core_reducers_A_const_52 *lang.Var

var A_arbace_core_reducers_A_const_53 *lang.Var

var A_arbace_core_reducers_A_const_54 *lang.Keyword

var A_arbace_core_reducers_A_const_55 *lang.Var

var A_arbace_core_reducers_A_const_56 *lang.Var

var A_arbace_core_reducers_A_const_57 *lang.Var

var A_arbace_core_reducers_A_const_58 *lang.Var

var A_arbace_core_reducers_A_const_59 *lang.Var

var A_arbace_core_reducers_A_const_60 *lang.Var

var A_arbace_core_reducers_A_const_61 any

var A_arbace_core_reducers_A_const_62 *lang.Var

var A_arbace_core_reducers_A_const_63 *lang.Var

var A_arbace_core_reducers_A_init jrt.ClassInit

func A_arbace_core_reducers_A_Init() { if !A_arbace_core_reducers_A_init.Done() { A_arbace_core_reducers_A_init.Run(A_arbace_core_reducers_A_clinit) } }

func A_arbace_core_reducers_A_clinit() { A_arbace_core_reducers_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_reducers_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_reducers_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_reducers_A_const_3 = lang.RT_Keyword_String_String__Keyword(nil, Lit_3); A_arbace_core_reducers_A_const_4 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref())); A_arbace_core_reducers_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()); A_arbace_core_reducers_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_core_reducers_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_core_reducers_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_core_reducers_A_const_9 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), Lit_22, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24))); A_arbace_core_reducers_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_core_reducers_A_const_11 = lang.RT_Var_String_String__Var(Lit_20, Lit_26); A_arbace_core_reducers_A_const_12 = lang.RT_Var_String_String__Var(Lit_20, Lit_27); A_arbace_core_reducers_A_const_13 = lang.RT_Var_String_String__Var(Lit_28, Lit_29); A_arbace_core_reducers_A_const_14 = lang.RT_Var_String_String__Var(Lit_28, Lit_30); A_arbace_core_reducers_A_const_15 = lang.RT_Var_String_String__Var(Lit_20, Lit_4); A_arbace_core_reducers_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_core_reducers_A_const_17 = lang.RT_ClassForNameNonLoading_String__Class(Lit_32); A_arbace_core_reducers_A_const_18 = lang.RT_Var_String_String__Var(Lit_20, Lit_33); A_arbace_core_reducers_A_const_19 = lang.RT_Var_String_String__Var(Lit_20, Lit_34); A_arbace_core_reducers_A_const_20 = jrt.Long_ValueOf_J__Long(512).Ref(); A_arbace_core_reducers_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_core_reducers_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_core_reducers_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_core_reducers_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_core_reducers_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_core_reducers_A_const_26 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_40).Ref(); A_arbace_core_reducers_A_const_27 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_41).Ref(); A_arbace_core_reducers_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_core_reducers_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_core_reducers_A_const_30 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(); A_arbace_core_reducers_A_const_31 = lang.RT_Var_String_String__Var(Lit_20, Lit_45); A_arbace_core_reducers_A_const_32 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_41).Ref(); A_arbace_core_reducers_A_const_33 = lang.RT_Var_String_String__Var(Lit_14, Lit_46); A_arbace_core_reducers_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_core_reducers_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_core_reducers_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_core_reducers_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_core_reducers_A_const_38 = lang.RT_Var_String_String__Var(Lit_20, Lit_50); A_arbace_core_reducers_A_const_39 = lang.RT_Var_String_String__Var(Lit_20, Lit_51); A_arbace_core_reducers_A_const_40 = lang.RT_Var_String_String__Var(Lit_20, Lit_5); A_arbace_core_reducers_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_core_reducers_A_const_42 = lang.RT_Var_String_String__Var(Lit_20, Lit_6); A_arbace_core_reducers_A_const_43 = lang.RT_Var_String_String__Var(Lit_20, Lit_7); A_arbace_core_reducers_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_core_reducers_A_const_45 = lang.RT_Var_String_String__Var(Lit_20, Lit_8); A_arbace_core_reducers_A_const_46 = lang.RT_Var_String_String__Var(Lit_20, Lit_12); A_arbace_core_reducers_A_const_47 = lang.RT_Var_String_String__Var(Lit_20, Lit_54); A_arbace_core_reducers_A_const_48 = lang.RT_Var_String_String__Var(Lit_20, Lit_10); A_arbace_core_reducers_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_core_reducers_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_core_reducers_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_core_reducers_A_const_52 = lang.RT_Var_String_String__Var(Lit_20, Lit_9); A_arbace_core_reducers_A_const_53 = lang.RT_Var_String_String__Var(Lit_20, Lit_11); A_arbace_core_reducers_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_58); A_arbace_core_reducers_A_const_55 = lang.RT_Var_String_String__Var(Lit_20, Lit_13); A_arbace_core_reducers_A_const_56 = lang.RT_Var_String_String__Var(Lit_20, Lit_59); A_arbace_core_reducers_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_core_reducers_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_core_reducers_A_const_59 = lang.RT_Var_String_String__Var(Lit_20, Lit_62); A_arbace_core_reducers_A_const_60 = lang.RT_Var_String_String__Var(Lit_20, Lit_63); A_arbace_core_reducers_A_const_61 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_core_reducers_A_const_62 = lang.RT_Var_String_String__Var(Lit_20, Lit_64); A_arbace_core_reducers_A_const_63 = lang.RT_Var_String_String__Var(Lit_20, Lit_65) }

func A_arbace_core_reducers_A_New() *A_arbace_core_reducers_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_A) Ctor() {}

func (t *A_arbace_core_reducers_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_A_class }

func (t *A_arbace_core_reducers_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_A); return ok }

func A_arbace_core_reducers_A_Cast(x any) *A_arbace_core_reducers_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_A_class)) }; return v }



type A_arbace_core_reducers_append_BANG__A struct{ jrt.Object }

func (t *A_arbace_core_reducers_append_BANG__A) Is_Compiler_AOTF2() {}

var A_arbace_core_reducers_append_BANG__A_fn_class *jrt.Class

var A_arbace_core_reducers_append_BANG__A_init jrt.ClassInit

func A_arbace_core_reducers_append_BANG__A_Init() { if !A_arbace_core_reducers_append_BANG__A_init.Done() { A_arbace_core_reducers_append_BANG__A_init.Run(A_arbace_core_reducers_append_BANG__A_clinit) } }

func A_arbace_core_reducers_append_BANG__A_clinit() { A_arbace_core_reducers_append_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_append_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_append_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_append_BANG__A_class }

func (t *A_arbace_core_reducers_append_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_append_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_append_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_append_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_append_BANG__A); return ok }

func A_arbace_core_reducers_append_BANG__A_Cast(x any) *A_arbace_core_reducers_append_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_append_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_append_BANG__A_class)) }; return v }



type A_arbace_core_reducers_cat_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_cat_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_cat_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_core_reducers_cat_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_cat_A_fn_class *jrt.Class

var A_arbace_core_reducers_cat_A_init jrt.ClassInit

func A_arbace_core_reducers_cat_A_Init() { if !A_arbace_core_reducers_cat_A_init.Done() { A_arbace_core_reducers_cat_A_init.Run(A_arbace_core_reducers_cat_A_clinit) } }

func A_arbace_core_reducers_cat_A_clinit() { A_arbace_core_reducers_cat_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_cat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_cat_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_cat_A_class }

func (t *A_arbace_core_reducers_cat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_cat_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_cat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_cat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_cat_A); return ok }

func A_arbace_core_reducers_cat_A_Cast(x any) *A_arbace_core_reducers_cat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_cat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_cat_A_class)) }; return v }



type A_arbace_core_reducers_cat_fn__153000141_A struct{ jrt.Object; F_ctor any }

func (t *A_arbace_core_reducers_cat_fn__153000141_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_cat_fn__153000141_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_cat_fn__153000141_A_fn_class *jrt.Class

var A_arbace_core_reducers_cat_fn__153000141_A_init jrt.ClassInit

func A_arbace_core_reducers_cat_fn__153000141_A_Init() { if !A_arbace_core_reducers_cat_fn__153000141_A_init.Done() { A_arbace_core_reducers_cat_fn__153000141_A_init.Run(A_arbace_core_reducers_cat_fn__153000141_A_clinit) } }

func A_arbace_core_reducers_cat_fn__153000141_A_clinit() { A_arbace_core_reducers_cat_fn__153000141_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_cat_fn__153000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_cat_fn__153000141_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_cat_fn__153000141_A_class }

func (t *A_arbace_core_reducers_cat_fn__153000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_cat_fn__153000141_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_cat_fn__153000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_cat_fn__153000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_cat_fn__153000141_A); return ok }

func A_arbace_core_reducers_cat_fn__153000141_A_Cast(x any) *A_arbace_core_reducers_cat_fn__153000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_cat_fn__153000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_cat_fn__153000141_A_class)) }; return v }



type A_arbace_core_reducers_defcurried_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_defcurried_A) Is_Compiler_AOTR6() {}

var A_arbace_core_reducers_defcurried_A_fn_class *jrt.Class

var A_arbace_core_reducers_defcurried_A_init jrt.ClassInit

func A_arbace_core_reducers_defcurried_A_Init() { if !A_arbace_core_reducers_defcurried_A_init.Done() { A_arbace_core_reducers_defcurried_A_init.Run(A_arbace_core_reducers_defcurried_A_clinit) } }

func A_arbace_core_reducers_defcurried_A_clinit() { A_arbace_core_reducers_defcurried_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_core_reducers_defcurried_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_defcurried_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_defcurried_A_class }

func (t *A_arbace_core_reducers_defcurried_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_defcurried_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_defcurried_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_defcurried_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_defcurried_A); return ok }

func A_arbace_core_reducers_defcurried_A_Cast(x any) *A_arbace_core_reducers_defcurried_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_defcurried_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_defcurried_A_class)) }; return v }



type A_arbace_core_reducers_do_curried_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_do_curried_A) Is_Compiler_AOTF5() {}

var A_arbace_core_reducers_do_curried_A_fn_class *jrt.Class

var A_arbace_core_reducers_do_curried_A_init jrt.ClassInit

func A_arbace_core_reducers_do_curried_A_Init() { if !A_arbace_core_reducers_do_curried_A_init.Done() { A_arbace_core_reducers_do_curried_A_init.Run(A_arbace_core_reducers_do_curried_A_clinit) } }

func A_arbace_core_reducers_do_curried_A_clinit() { A_arbace_core_reducers_do_curried_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_do_curried_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_do_curried_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_do_curried_A_class }

func (t *A_arbace_core_reducers_do_curried_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_do_curried_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_do_curried_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_do_curried_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_do_curried_A); return ok }

func A_arbace_core_reducers_do_curried_A_Cast(x any) *A_arbace_core_reducers_do_curried_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_do_curried_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_do_curried_A_class)) }; return v }



type A_arbace_core_reducers_do_rfn_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_do_rfn_A) Is_Compiler_AOTF3() {}

var A_arbace_core_reducers_do_rfn_A_fn_class *jrt.Class

var A_arbace_core_reducers_do_rfn_A_init jrt.ClassInit

func A_arbace_core_reducers_do_rfn_A_Init() { if !A_arbace_core_reducers_do_rfn_A_init.Done() { A_arbace_core_reducers_do_rfn_A_init.Run(A_arbace_core_reducers_do_rfn_A_clinit) } }

func A_arbace_core_reducers_do_rfn_A_clinit() { A_arbace_core_reducers_do_rfn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_do_rfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_do_rfn_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_do_rfn_A_class }

func (t *A_arbace_core_reducers_do_rfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_do_rfn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_do_rfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_do_rfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_do_rfn_A); return ok }

func A_arbace_core_reducers_do_rfn_A_Cast(x any) *A_arbace_core_reducers_do_rfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_do_rfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_do_rfn_A_class)) }; return v }



type A_arbace_core_reducers_do_rfn_fn__153000066_A struct{ jrt.Object; F_k any }

func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class *jrt.Class

var A_arbace_core_reducers_do_rfn_fn__153000066_A_init jrt.ClassInit

func A_arbace_core_reducers_do_rfn_fn__153000066_A_Init() { if !A_arbace_core_reducers_do_rfn_fn__153000066_A_init.Done() { A_arbace_core_reducers_do_rfn_fn__153000066_A_init.Run(A_arbace_core_reducers_do_rfn_fn__153000066_A_clinit) } }

func A_arbace_core_reducers_do_rfn_fn__153000066_A_clinit() { A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_do_rfn_fn__153000066_A_class }

func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_do_rfn_fn__153000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_do_rfn_fn__153000066_A); return ok }

func A_arbace_core_reducers_do_rfn_fn__153000066_A_Cast(x any) *A_arbace_core_reducers_do_rfn_fn__153000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_do_rfn_fn__153000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_do_rfn_fn__153000066_A_class)) }; return v }



type A_arbace_core_reducers_drop_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_drop_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_drop_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_drop_A_fn_class *jrt.Class

var A_arbace_core_reducers_drop_A_init jrt.ClassInit

func A_arbace_core_reducers_drop_A_Init() { if !A_arbace_core_reducers_drop_A_init.Done() { A_arbace_core_reducers_drop_A_init.Run(A_arbace_core_reducers_drop_A_clinit) } }

func A_arbace_core_reducers_drop_A_clinit() { A_arbace_core_reducers_drop_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_drop_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_drop_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_drop_A_class }

func (t *A_arbace_core_reducers_drop_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_drop_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_drop_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_drop_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_drop_A); return ok }

func A_arbace_core_reducers_drop_A_Cast(x any) *A_arbace_core_reducers_drop_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_drop_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_drop_A_class)) }; return v }



type A_arbace_core_reducers_drop_fn__153000125_A struct{ jrt.Object; F_n any }

func (t *A_arbace_core_reducers_drop_fn__153000125_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_drop_fn__153000125_A_fn_class *jrt.Class

var A_arbace_core_reducers_drop_fn__153000125_A_init jrt.ClassInit

func A_arbace_core_reducers_drop_fn__153000125_A_Init() { if !A_arbace_core_reducers_drop_fn__153000125_A_init.Done() { A_arbace_core_reducers_drop_fn__153000125_A_init.Run(A_arbace_core_reducers_drop_fn__153000125_A_clinit) } }

func A_arbace_core_reducers_drop_fn__153000125_A_clinit() { A_arbace_core_reducers_drop_fn__153000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_drop_fn__153000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_drop_fn__153000125_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_drop_fn__153000125_A_class }

func (t *A_arbace_core_reducers_drop_fn__153000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_drop_fn__153000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_drop_fn__153000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_drop_fn__153000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_drop_fn__153000125_A); return ok }

func A_arbace_core_reducers_drop_fn__153000125_A_Cast(x any) *A_arbace_core_reducers_drop_fn__153000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_drop_fn__153000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_drop_fn__153000125_A_class)) }; return v }



type A_arbace_core_reducers_drop_fn__153000127_A struct{ jrt.Object; F_n any }

func (t *A_arbace_core_reducers_drop_fn__153000127_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_drop_fn__153000127_A_fn_class *jrt.Class

var A_arbace_core_reducers_drop_fn__153000127_A_init jrt.ClassInit

func A_arbace_core_reducers_drop_fn__153000127_A_Init() { if !A_arbace_core_reducers_drop_fn__153000127_A_init.Done() { A_arbace_core_reducers_drop_fn__153000127_A_init.Run(A_arbace_core_reducers_drop_fn__153000127_A_clinit) } }

func A_arbace_core_reducers_drop_fn__153000127_A_clinit() { A_arbace_core_reducers_drop_fn__153000127_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_drop_fn__153000127_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_drop_fn__153000127_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_drop_fn__153000127_A_class }

func (t *A_arbace_core_reducers_drop_fn__153000127_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_drop_fn__153000127_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_drop_fn__153000127_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_drop_fn__153000127_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_drop_fn__153000127_A); return ok }

func A_arbace_core_reducers_drop_fn__153000127_A_Cast(x any) *A_arbace_core_reducers_drop_fn__153000127_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_drop_fn__153000127_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_drop_fn__153000127_A_class)) }; return v }



type A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A struct{ jrt.Object; F_cnt, F_f1 any }

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class *jrt.Class

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_init jrt.ClassInit

func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_Init() { if !A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_init.Done() { A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_init.Run(A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_clinit) } }

func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_clinit() { A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_class }

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A); return ok }

func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_Cast(x any) *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_class)) }; return v }



type A_arbace_core_reducers_eval153000004_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000004_A_New() *A_arbace_core_reducers_eval153000004_A { t := &A_arbace_core_reducers_eval153000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000004_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000004_A_class }

func (t *A_arbace_core_reducers_eval153000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000004_A); return ok }

func A_arbace_core_reducers_eval153000004_A_Cast(x any) *A_arbace_core_reducers_eval153000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000004_A_class)) }; return v }



type A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_Init() { if !A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_init.Done() { A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_init.Run(A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_clinit) } }

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_clinit() { A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_class }

func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A); return ok }

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_Cast(x any) *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_class)) }; return v }



type A_arbace_core_reducers_eval153000008_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000008_A_New() *A_arbace_core_reducers_eval153000008_A { t := &A_arbace_core_reducers_eval153000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000008_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000008_A_class }

func (t *A_arbace_core_reducers_eval153000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000008_A); return ok }

func A_arbace_core_reducers_eval153000008_A_Cast(x any) *A_arbace_core_reducers_eval153000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000008_A_class)) }; return v }



type A_arbace_core_reducers_eval153000008_fn__153000009_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000008_fn__153000009_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000008_fn__153000009_A_Init() { if !A_arbace_core_reducers_eval153000008_fn__153000009_A_init.Done() { A_arbace_core_reducers_eval153000008_fn__153000009_A_init.Run(A_arbace_core_reducers_eval153000008_fn__153000009_A_clinit) } }

func A_arbace_core_reducers_eval153000008_fn__153000009_A_clinit() { A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000008_fn__153000009_A_class }

func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000008_fn__153000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000008_fn__153000009_A); return ok }

func A_arbace_core_reducers_eval153000008_fn__153000009_A_Cast(x any) *A_arbace_core_reducers_eval153000008_fn__153000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000008_fn__153000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000008_fn__153000009_A_class)) }; return v }



type A_arbace_core_reducers_eval153000031_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000031_A_New() *A_arbace_core_reducers_eval153000031_A { t := &A_arbace_core_reducers_eval153000031_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000031_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000031_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000031_A_class }

func (t *A_arbace_core_reducers_eval153000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000031_A); return ok }

func A_arbace_core_reducers_eval153000031_A_Cast(x any) *A_arbace_core_reducers_eval153000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000031_A_class)) }; return v }



type A_arbace_core_reducers_eval153000031_fn__153000032_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000031_fn__153000032_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000031_fn__153000032_A_Init() { if !A_arbace_core_reducers_eval153000031_fn__153000032_A_init.Done() { A_arbace_core_reducers_eval153000031_fn__153000032_A_init.Run(A_arbace_core_reducers_eval153000031_fn__153000032_A_clinit) } }

func A_arbace_core_reducers_eval153000031_fn__153000032_A_clinit() { A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000031_fn__153000032_A_class }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000031_fn__153000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000031_fn__153000032_A); return ok }

func A_arbace_core_reducers_eval153000031_fn__153000032_A_Cast(x any) *A_arbace_core_reducers_eval153000031_fn__153000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000031_fn__153000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000031_fn__153000032_A_class)) }; return v }



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A struct{ jrt.Object; F_G__153000024 any }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_Init() { if !A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_init.Done() { A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_init.Run(A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_clinit) } }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_clinit() { A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_class }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A); return ok }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_Cast(x any) *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_class)) }; return v }



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_Init() { if !A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_init.Done() { A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_init.Run(A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_clinit) } }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_clinit() { A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_class }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A); return ok }

func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_Cast(x any) *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_class)) }; return v }



type A_arbace_core_reducers_eval153000132_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000132_A_New() *A_arbace_core_reducers_eval153000132_A { t := &A_arbace_core_reducers_eval153000132_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000132_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000132_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000132_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000132_A_class }

func (t *A_arbace_core_reducers_eval153000132_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000132_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000132_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000132_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000132_A); return ok }

func A_arbace_core_reducers_eval153000132_A_Cast(x any) *A_arbace_core_reducers_eval153000132_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000132_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000132_A_class)) }; return v }



type A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Is_Compiler_AOTF3() {}

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_Init() { if !A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_init.Done() { A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_init.Run(A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_clinit) } }

func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_clinit() { A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_class }

func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A); return ok }

func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_Cast(x any) *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_class)) }; return v }



type A_arbace_core_reducers_eval153000157_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000157_A_New() *A_arbace_core_reducers_eval153000157_A { t := &A_arbace_core_reducers_eval153000157_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000157_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000157_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000157_A_class }

func (t *A_arbace_core_reducers_eval153000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000157_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000157_A); return ok }

func A_arbace_core_reducers_eval153000157_A_Cast(x any) *A_arbace_core_reducers_eval153000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000157_A_class)) }; return v }



type A_arbace_core_reducers_eval153000157_fn__153000158_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000157_fn__153000158_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000157_fn__153000158_A_Init() { if !A_arbace_core_reducers_eval153000157_fn__153000158_A_init.Done() { A_arbace_core_reducers_eval153000157_fn__153000158_A_init.Run(A_arbace_core_reducers_eval153000157_fn__153000158_A_clinit) } }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_clinit() { A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000157_fn__153000158_A_class }

func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000157_fn__153000158_A); return ok }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_Cast(x any) *A_arbace_core_reducers_eval153000157_fn__153000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000157_fn__153000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000157_fn__153000158_A_class)) }; return v }



type A_arbace_core_reducers_eval153000161_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000161_A_New() *A_arbace_core_reducers_eval153000161_A { t := &A_arbace_core_reducers_eval153000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000161_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000161_A_class }

func (t *A_arbace_core_reducers_eval153000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000161_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000161_A); return ok }

func A_arbace_core_reducers_eval153000161_A_Cast(x any) *A_arbace_core_reducers_eval153000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000161_A_class)) }; return v }



type A_arbace_core_reducers_eval153000161_fn__153000162_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000161_fn__153000162_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000161_fn__153000162_A_Init() { if !A_arbace_core_reducers_eval153000161_fn__153000162_A_init.Done() { A_arbace_core_reducers_eval153000161_fn__153000162_A_init.Run(A_arbace_core_reducers_eval153000161_fn__153000162_A_clinit) } }

func A_arbace_core_reducers_eval153000161_fn__153000162_A_clinit() { A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000161_fn__153000162_A_class }

func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000161_fn__153000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000161_fn__153000162_A); return ok }

func A_arbace_core_reducers_eval153000161_fn__153000162_A_Cast(x any) *A_arbace_core_reducers_eval153000161_fn__153000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000161_fn__153000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000161_fn__153000162_A_class)) }; return v }



type A_arbace_core_reducers_eval153000165_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000165_A_New() *A_arbace_core_reducers_eval153000165_A { t := &A_arbace_core_reducers_eval153000165_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000165_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000165_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000165_A_class }

func (t *A_arbace_core_reducers_eval153000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000165_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000165_A); return ok }

func A_arbace_core_reducers_eval153000165_A_Cast(x any) *A_arbace_core_reducers_eval153000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000165_A_class)) }; return v }



type A_arbace_core_reducers_eval153000165_fn__153000166_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000165_fn__153000166_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000165_fn__153000166_A_Init() { if !A_arbace_core_reducers_eval153000165_fn__153000166_A_init.Done() { A_arbace_core_reducers_eval153000165_fn__153000166_A_init.Run(A_arbace_core_reducers_eval153000165_fn__153000166_A_clinit) } }

func A_arbace_core_reducers_eval153000165_fn__153000166_A_clinit() { A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000165_fn__153000166_A_class }

func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000165_fn__153000166_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000165_fn__153000166_A); return ok }

func A_arbace_core_reducers_eval153000165_fn__153000166_A_Cast(x any) *A_arbace_core_reducers_eval153000165_fn__153000166_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000165_fn__153000166_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000165_fn__153000166_A_class)) }; return v }



type A_arbace_core_reducers_eval153000169_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000169_A_New() *A_arbace_core_reducers_eval153000169_A { t := &A_arbace_core_reducers_eval153000169_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000169_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000169_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000169_A_class }

func (t *A_arbace_core_reducers_eval153000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000169_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000169_A); return ok }

func A_arbace_core_reducers_eval153000169_A_Cast(x any) *A_arbace_core_reducers_eval153000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000169_A_class)) }; return v }



type A_arbace_core_reducers_eval153000169_fn__153000170_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class *jrt.Class

var A_arbace_core_reducers_eval153000169_fn__153000170_A_init jrt.ClassInit

func A_arbace_core_reducers_eval153000169_fn__153000170_A_Init() { if !A_arbace_core_reducers_eval153000169_fn__153000170_A_init.Done() { A_arbace_core_reducers_eval153000169_fn__153000170_A_init.Run(A_arbace_core_reducers_eval153000169_fn__153000170_A_clinit) } }

func A_arbace_core_reducers_eval153000169_fn__153000170_A_clinit() { A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000169_fn__153000170_A_class }

func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000169_fn__153000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000169_fn__153000170_A); return ok }

func A_arbace_core_reducers_eval153000169_fn__153000170_A_Cast(x any) *A_arbace_core_reducers_eval153000169_fn__153000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000169_fn__153000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000169_fn__153000170_A_class)) }; return v }



type A_arbace_core_reducers_filter_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_filter_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_filter_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_filter_A_fn_class *jrt.Class

var A_arbace_core_reducers_filter_A_init jrt.ClassInit

func A_arbace_core_reducers_filter_A_Init() { if !A_arbace_core_reducers_filter_A_init.Done() { A_arbace_core_reducers_filter_A_init.Run(A_arbace_core_reducers_filter_A_clinit) } }

func A_arbace_core_reducers_filter_A_clinit() { A_arbace_core_reducers_filter_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_filter_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_filter_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_filter_A_class }

func (t *A_arbace_core_reducers_filter_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_filter_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_filter_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_filter_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_filter_A); return ok }

func A_arbace_core_reducers_filter_A_Cast(x any) *A_arbace_core_reducers_filter_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_filter_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_filter_A_class)) }; return v }



type A_arbace_core_reducers_filter_fn__153000094_A struct{ jrt.Object; F_pred any }

func (t *A_arbace_core_reducers_filter_fn__153000094_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_filter_fn__153000094_A_fn_class *jrt.Class

var A_arbace_core_reducers_filter_fn__153000094_A_init jrt.ClassInit

func A_arbace_core_reducers_filter_fn__153000094_A_Init() { if !A_arbace_core_reducers_filter_fn__153000094_A_init.Done() { A_arbace_core_reducers_filter_fn__153000094_A_init.Run(A_arbace_core_reducers_filter_fn__153000094_A_clinit) } }

func A_arbace_core_reducers_filter_fn__153000094_A_clinit() { A_arbace_core_reducers_filter_fn__153000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_filter_fn__153000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_filter_fn__153000094_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_filter_fn__153000094_A_class }

func (t *A_arbace_core_reducers_filter_fn__153000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_filter_fn__153000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_filter_fn__153000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_filter_fn__153000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_filter_fn__153000094_A); return ok }

func A_arbace_core_reducers_filter_fn__153000094_A_Cast(x any) *A_arbace_core_reducers_filter_fn__153000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_filter_fn__153000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_filter_fn__153000094_A_class)) }; return v }



type A_arbace_core_reducers_filter_fn__153000096_A struct{ jrt.Object; F_pred any }

func (t *A_arbace_core_reducers_filter_fn__153000096_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_filter_fn__153000096_A_fn_class *jrt.Class

var A_arbace_core_reducers_filter_fn__153000096_A_init jrt.ClassInit

func A_arbace_core_reducers_filter_fn__153000096_A_Init() { if !A_arbace_core_reducers_filter_fn__153000096_A_init.Done() { A_arbace_core_reducers_filter_fn__153000096_A_init.Run(A_arbace_core_reducers_filter_fn__153000096_A_clinit) } }

func A_arbace_core_reducers_filter_fn__153000096_A_clinit() { A_arbace_core_reducers_filter_fn__153000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_filter_fn__153000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_filter_fn__153000096_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_filter_fn__153000096_A_class }

func (t *A_arbace_core_reducers_filter_fn__153000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_filter_fn__153000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_filter_fn__153000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_filter_fn__153000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_filter_fn__153000096_A); return ok }

func A_arbace_core_reducers_filter_fn__153000096_A_Cast(x any) *A_arbace_core_reducers_filter_fn__153000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_filter_fn__153000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_filter_fn__153000096_A_class)) }; return v }



type A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A struct{ jrt.Object; F_pred, F_f1 any }

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class *jrt.Class

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_init jrt.ClassInit

func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_Init() { if !A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_init.Done() { A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_init.Run(A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_clinit) } }

func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_clinit() { A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_class }

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A); return ok }

func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_Cast(x any) *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_class)) }; return v }



type A_arbace_core_reducers_fjfork_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_fjfork_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_fjfork_A_fn_class *jrt.Class

var A_arbace_core_reducers_fjfork_A_init jrt.ClassInit

func A_arbace_core_reducers_fjfork_A_Init() { if !A_arbace_core_reducers_fjfork_A_init.Done() { A_arbace_core_reducers_fjfork_A_init.Run(A_arbace_core_reducers_fjfork_A_clinit) } }

func A_arbace_core_reducers_fjfork_A_clinit() { A_arbace_core_reducers_fjfork_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_fjfork_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_fjfork_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_fjfork_A_class }

func (t *A_arbace_core_reducers_fjfork_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_fjfork_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_fjfork_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_fjfork_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_fjfork_A); return ok }

func A_arbace_core_reducers_fjfork_A_Cast(x any) *A_arbace_core_reducers_fjfork_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_fjfork_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_fjfork_A_class)) }; return v }



type A_arbace_core_reducers_fjinvoke_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_fjinvoke_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_fjinvoke_A_fn_class *jrt.Class

var A_arbace_core_reducers_fjinvoke_A_init jrt.ClassInit

func A_arbace_core_reducers_fjinvoke_A_Init() { if !A_arbace_core_reducers_fjinvoke_A_init.Done() { A_arbace_core_reducers_fjinvoke_A_init.Run(A_arbace_core_reducers_fjinvoke_A_clinit) } }

func A_arbace_core_reducers_fjinvoke_A_clinit() { A_arbace_core_reducers_fjinvoke_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_93, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_fjinvoke_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_fjinvoke_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_fjinvoke_A_class }

func (t *A_arbace_core_reducers_fjinvoke_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_fjinvoke_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_fjinvoke_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_fjinvoke_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_fjinvoke_A); return ok }

func A_arbace_core_reducers_fjinvoke_A_Cast(x any) *A_arbace_core_reducers_fjinvoke_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_fjinvoke_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_fjinvoke_A_class)) }; return v }



type A_arbace_core_reducers_fjjoin_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_fjjoin_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_fjjoin_A_fn_class *jrt.Class

var A_arbace_core_reducers_fjjoin_A_init jrt.ClassInit

func A_arbace_core_reducers_fjjoin_A_Init() { if !A_arbace_core_reducers_fjjoin_A_init.Done() { A_arbace_core_reducers_fjjoin_A_init.Run(A_arbace_core_reducers_fjjoin_A_clinit) } }

func A_arbace_core_reducers_fjjoin_A_clinit() { A_arbace_core_reducers_fjjoin_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_fjjoin_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_fjjoin_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_fjjoin_A_class }

func (t *A_arbace_core_reducers_fjjoin_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_fjjoin_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_fjjoin_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_fjjoin_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_fjjoin_A); return ok }

func A_arbace_core_reducers_fjjoin_A_Cast(x any) *A_arbace_core_reducers_fjjoin_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_fjjoin_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_fjjoin_A_class)) }; return v }



type A_arbace_core_reducers_fjtask_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_fjtask_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_fjtask_A_fn_class *jrt.Class

var A_arbace_core_reducers_fjtask_A_init jrt.ClassInit

func A_arbace_core_reducers_fjtask_A_Init() { if !A_arbace_core_reducers_fjtask_A_init.Done() { A_arbace_core_reducers_fjtask_A_init.Run(A_arbace_core_reducers_fjtask_A_clinit) } }

func A_arbace_core_reducers_fjtask_A_clinit() { A_arbace_core_reducers_fjtask_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_fjtask_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_fjtask_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_fjtask_A_class }

func (t *A_arbace_core_reducers_fjtask_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_fjtask_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_fjtask_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_fjtask_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_fjtask_A); return ok }

func A_arbace_core_reducers_fjtask_A_Cast(x any) *A_arbace_core_reducers_fjtask_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_fjtask_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_fjtask_A_class)) }; return v }



type A_arbace_core_reducers_flatten_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_flatten_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_core_reducers_flatten_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_flatten_A_fn_class *jrt.Class

var A_arbace_core_reducers_flatten_A_init jrt.ClassInit

func A_arbace_core_reducers_flatten_A_Init() { if !A_arbace_core_reducers_flatten_A_init.Done() { A_arbace_core_reducers_flatten_A_init.Run(A_arbace_core_reducers_flatten_A_clinit) } }

func A_arbace_core_reducers_flatten_A_clinit() { A_arbace_core_reducers_flatten_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_flatten_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_flatten_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_flatten_A_class }

func (t *A_arbace_core_reducers_flatten_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_flatten_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_flatten_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_flatten_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_flatten_A); return ok }

func A_arbace_core_reducers_flatten_A_Cast(x any) *A_arbace_core_reducers_flatten_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_flatten_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_flatten_A_class)) }; return v }



type A_arbace_core_reducers_flatten_fn__153000104_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_flatten_fn__153000104_A_fn_class *jrt.Class

var A_arbace_core_reducers_flatten_fn__153000104_A_init jrt.ClassInit

func A_arbace_core_reducers_flatten_fn__153000104_A_Init() { if !A_arbace_core_reducers_flatten_fn__153000104_A_init.Done() { A_arbace_core_reducers_flatten_fn__153000104_A_init.Run(A_arbace_core_reducers_flatten_fn__153000104_A_clinit) } }

func A_arbace_core_reducers_flatten_fn__153000104_A_clinit() { A_arbace_core_reducers_flatten_fn__153000104_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_flatten_fn__153000104_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_flatten_fn__153000104_A_class }

func (t *A_arbace_core_reducers_flatten_fn__153000104_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_flatten_fn__153000104_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_flatten_fn__153000104_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_flatten_fn__153000104_A); return ok }

func A_arbace_core_reducers_flatten_fn__153000104_A_Cast(x any) *A_arbace_core_reducers_flatten_fn__153000104_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_flatten_fn__153000104_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_flatten_fn__153000104_A_class)) }; return v }



type A_arbace_core_reducers_flatten_fn__153000106_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_flatten_fn__153000106_A_fn_class *jrt.Class

var A_arbace_core_reducers_flatten_fn__153000106_A_init jrt.ClassInit

func A_arbace_core_reducers_flatten_fn__153000106_A_Init() { if !A_arbace_core_reducers_flatten_fn__153000106_A_init.Done() { A_arbace_core_reducers_flatten_fn__153000106_A_init.Run(A_arbace_core_reducers_flatten_fn__153000106_A_clinit) } }

func A_arbace_core_reducers_flatten_fn__153000106_A_clinit() { A_arbace_core_reducers_flatten_fn__153000106_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_flatten_fn__153000106_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_flatten_fn__153000106_A_class }

func (t *A_arbace_core_reducers_flatten_fn__153000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_flatten_fn__153000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_flatten_fn__153000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_flatten_fn__153000106_A); return ok }

func A_arbace_core_reducers_flatten_fn__153000106_A_Cast(x any) *A_arbace_core_reducers_flatten_fn__153000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_flatten_fn__153000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_flatten_fn__153000106_A_class)) }; return v }



type A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A struct{ jrt.Object; F_f1 any }

func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class *jrt.Class

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_init jrt.ClassInit

func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_Init() { if !A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_init.Done() { A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_init.Run(A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_clinit) } }

func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_clinit() { A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_99, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_class }

func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A); return ok }

func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_Cast(x any) *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_class)) }; return v }



type A_arbace_core_reducers_fn__153000016_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_fn__153000016_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_fn__153000016_A_fn_class *jrt.Class

var A_arbace_core_reducers_fn__153000016_A_init jrt.ClassInit

func A_arbace_core_reducers_fn__153000016_A_Init() { if !A_arbace_core_reducers_fn__153000016_A_init.Done() { A_arbace_core_reducers_fn__153000016_A_init.Run(A_arbace_core_reducers_fn__153000016_A_clinit) } }

func A_arbace_core_reducers_fn__153000016_A_clinit() { A_arbace_core_reducers_fn__153000016_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_100, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_fn__153000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_fn__153000016_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_fn__153000016_A_class }

func (t *A_arbace_core_reducers_fn__153000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_fn__153000016_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_fn__153000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_fn__153000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_fn__153000016_A); return ok }

func A_arbace_core_reducers_fn__153000016_A_Cast(x any) *A_arbace_core_reducers_fn__153000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_fn__153000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_fn__153000016_A_class)) }; return v }



type A_arbace_core_reducers_fold_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_fold_A) Is_Compiler_AOTF4() {}

func (t *A_arbace_core_reducers_fold_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_fold_A) Is_Compiler_AOTF2() {}

var A_arbace_core_reducers_fold_A_fn_class *jrt.Class

var A_arbace_core_reducers_fold_A_init jrt.ClassInit

func A_arbace_core_reducers_fold_A_Init() { if !A_arbace_core_reducers_fold_A_init.Done() { A_arbace_core_reducers_fold_A_init.Run(A_arbace_core_reducers_fold_A_clinit) } }

func A_arbace_core_reducers_fold_A_clinit() { A_arbace_core_reducers_fold_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_101, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_fold_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_fold_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_fold_A_class }

func (t *A_arbace_core_reducers_fold_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_fold_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_fold_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_fold_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_fold_A); return ok }

func A_arbace_core_reducers_fold_A_Cast(x any) *A_arbace_core_reducers_fold_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_fold_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_fold_A_class)) }; return v }



type A_arbace_core_reducers_foldcat_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_foldcat_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_foldcat_A_fn_class *jrt.Class

var A_arbace_core_reducers_foldcat_A_init jrt.ClassInit

func A_arbace_core_reducers_foldcat_A_Init() { if !A_arbace_core_reducers_foldcat_A_init.Done() { A_arbace_core_reducers_foldcat_A_init.Run(A_arbace_core_reducers_foldcat_A_clinit) } }

func A_arbace_core_reducers_foldcat_A_clinit() { A_arbace_core_reducers_foldcat_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_foldcat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_foldcat_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_foldcat_A_class }

func (t *A_arbace_core_reducers_foldcat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_foldcat_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_foldcat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_foldcat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_foldcat_A); return ok }

func A_arbace_core_reducers_foldcat_A_Cast(x any) *A_arbace_core_reducers_foldcat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_foldcat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_foldcat_A_class)) }; return v }



type A_arbace_core_reducers_folder_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_folder_A) Is_Compiler_AOTF2() {}

var A_arbace_core_reducers_folder_A_fn_class *jrt.Class

var A_arbace_core_reducers_folder_A_init jrt.ClassInit

func A_arbace_core_reducers_folder_A_Init() { if !A_arbace_core_reducers_folder_A_init.Done() { A_arbace_core_reducers_folder_A_init.Run(A_arbace_core_reducers_folder_A_clinit) } }

func A_arbace_core_reducers_folder_A_clinit() { A_arbace_core_reducers_folder_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_folder_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_folder_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_folder_A_class }

func (t *A_arbace_core_reducers_folder_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_folder_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_folder_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_folder_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_folder_A); return ok }

func A_arbace_core_reducers_folder_A_Cast(x any) *A_arbace_core_reducers_folder_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_folder_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_folder_A_class)) }; return v }



type A_arbace_core_reducers_folder_reify__153000055_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IObj() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_folder_reify__153000055_A_class }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_folder_reify__153000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); return ok }

func A_arbace_core_reducers_folder_reify__153000055_A_Cast(x any) *A_arbace_core_reducers_folder_reify__153000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_folder_reify__153000055_A_class)) }; return v }



type A_arbace_core_reducers_foldvec_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_foldvec_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_foldvec_A_fn_class *jrt.Class

var A_arbace_core_reducers_foldvec_A_init jrt.ClassInit

func A_arbace_core_reducers_foldvec_A_Init() { if !A_arbace_core_reducers_foldvec_A_init.Done() { A_arbace_core_reducers_foldvec_A_init.Run(A_arbace_core_reducers_foldvec_A_clinit) } }

func A_arbace_core_reducers_foldvec_A_clinit() { A_arbace_core_reducers_foldvec_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_foldvec_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_foldvec_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_foldvec_A_class }

func (t *A_arbace_core_reducers_foldvec_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_foldvec_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_foldvec_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_foldvec_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_foldvec_A); return ok }

func A_arbace_core_reducers_foldvec_A_Cast(x any) *A_arbace_core_reducers_foldvec_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_foldvec_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_foldvec_A_class)) }; return v }



type A_arbace_core_reducers_foldvec_fc__153000150_A struct{ jrt.Object; F_combinef, F_n, F_reducef any }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class *jrt.Class

var A_arbace_core_reducers_foldvec_fc__153000150_A_init jrt.ClassInit

func A_arbace_core_reducers_foldvec_fc__153000150_A_Init() { if !A_arbace_core_reducers_foldvec_fc__153000150_A_init.Done() { A_arbace_core_reducers_foldvec_fc__153000150_A_init.Run(A_arbace_core_reducers_foldvec_fc__153000150_A_clinit) } }

func A_arbace_core_reducers_foldvec_fc__153000150_A_clinit() { A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_foldvec_fc__153000150_A_class }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_foldvec_fc__153000150_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_foldvec_fc__153000150_A); return ok }

func A_arbace_core_reducers_foldvec_fc__153000150_A_Cast(x any) *A_arbace_core_reducers_foldvec_fc__153000150_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_foldvec_fc__153000150_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_foldvec_fc__153000150_A_class)) }; return v }



type A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A struct{ jrt.Object; F_combinef, F_n, F_child, F_reducef any }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class *jrt.Class

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_init jrt.ClassInit

func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_Init() { if !A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_init.Done() { A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_init.Run(A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_clinit) } }

func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_clinit() { A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_class }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A); return ok }

func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_Cast(x any) *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_class)) }; return v }



type A_arbace_core_reducers_foldvec_fn__153000154_A struct{ jrt.Object; F_combinef, F_fc, F_v1, F_v2 any }

func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class *jrt.Class

var A_arbace_core_reducers_foldvec_fn__153000154_A_init jrt.ClassInit

func A_arbace_core_reducers_foldvec_fn__153000154_A_Init() { if !A_arbace_core_reducers_foldvec_fn__153000154_A_init.Done() { A_arbace_core_reducers_foldvec_fn__153000154_A_init.Run(A_arbace_core_reducers_foldvec_fn__153000154_A_clinit) } }

func A_arbace_core_reducers_foldvec_fn__153000154_A_clinit() { A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_foldvec_fn__153000154_A_class }

func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_foldvec_fn__153000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_foldvec_fn__153000154_A); return ok }

func A_arbace_core_reducers_foldvec_fn__153000154_A_Cast(x any) *A_arbace_core_reducers_foldvec_fn__153000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_foldvec_fn__153000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_foldvec_fn__153000154_A_class)) }; return v }



type A_arbace_core_reducers_map_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_map_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_map_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_map_A_fn_class *jrt.Class

var A_arbace_core_reducers_map_A_init jrt.ClassInit

func A_arbace_core_reducers_map_A_Init() { if !A_arbace_core_reducers_map_A_init.Done() { A_arbace_core_reducers_map_A_init.Run(A_arbace_core_reducers_map_A_clinit) } }

func A_arbace_core_reducers_map_A_clinit() { A_arbace_core_reducers_map_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_map_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_map_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_map_A_class }

func (t *A_arbace_core_reducers_map_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_map_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_map_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_map_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_map_A); return ok }

func A_arbace_core_reducers_map_A_Cast(x any) *A_arbace_core_reducers_map_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_map_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_map_A_class)) }; return v }



type A_arbace_core_reducers_map_fn__153000078_A struct{ jrt.Object; F_f any }

func (t *A_arbace_core_reducers_map_fn__153000078_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_map_fn__153000078_A_fn_class *jrt.Class

var A_arbace_core_reducers_map_fn__153000078_A_init jrt.ClassInit

func A_arbace_core_reducers_map_fn__153000078_A_Init() { if !A_arbace_core_reducers_map_fn__153000078_A_init.Done() { A_arbace_core_reducers_map_fn__153000078_A_init.Run(A_arbace_core_reducers_map_fn__153000078_A_clinit) } }

func A_arbace_core_reducers_map_fn__153000078_A_clinit() { A_arbace_core_reducers_map_fn__153000078_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_map_fn__153000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_map_fn__153000078_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_map_fn__153000078_A_class }

func (t *A_arbace_core_reducers_map_fn__153000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_map_fn__153000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_map_fn__153000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_map_fn__153000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_map_fn__153000078_A); return ok }

func A_arbace_core_reducers_map_fn__153000078_A_Cast(x any) *A_arbace_core_reducers_map_fn__153000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_map_fn__153000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_map_fn__153000078_A_class)) }; return v }



type A_arbace_core_reducers_map_fn__153000080_A struct{ jrt.Object; F_f any }

func (t *A_arbace_core_reducers_map_fn__153000080_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_map_fn__153000080_A_fn_class *jrt.Class

var A_arbace_core_reducers_map_fn__153000080_A_init jrt.ClassInit

func A_arbace_core_reducers_map_fn__153000080_A_Init() { if !A_arbace_core_reducers_map_fn__153000080_A_init.Done() { A_arbace_core_reducers_map_fn__153000080_A_init.Run(A_arbace_core_reducers_map_fn__153000080_A_clinit) } }

func A_arbace_core_reducers_map_fn__153000080_A_clinit() { A_arbace_core_reducers_map_fn__153000080_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_map_fn__153000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_map_fn__153000080_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_map_fn__153000080_A_class }

func (t *A_arbace_core_reducers_map_fn__153000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_map_fn__153000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_map_fn__153000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_map_fn__153000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_map_fn__153000080_A); return ok }

func A_arbace_core_reducers_map_fn__153000080_A_Cast(x any) *A_arbace_core_reducers_map_fn__153000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_map_fn__153000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_map_fn__153000080_A_class)) }; return v }



type A_arbace_core_reducers_map_fn__153000080_fn__153000081_A struct{ jrt.Object; F_f, F_f1 any }

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class *jrt.Class

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_init jrt.ClassInit

func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_Init() { if !A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_init.Done() { A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_init.Run(A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_clinit) } }

func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_clinit() { A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_class }

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_map_fn__153000080_fn__153000081_A); return ok }

func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_Cast(x any) *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_map_fn__153000080_fn__153000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_class)) }; return v }



type A_arbace_core_reducers_mapcat_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_mapcat_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_mapcat_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_mapcat_A_fn_class *jrt.Class

var A_arbace_core_reducers_mapcat_A_init jrt.ClassInit

func A_arbace_core_reducers_mapcat_A_Init() { if !A_arbace_core_reducers_mapcat_A_init.Done() { A_arbace_core_reducers_mapcat_A_init.Run(A_arbace_core_reducers_mapcat_A_clinit) } }

func A_arbace_core_reducers_mapcat_A_clinit() { A_arbace_core_reducers_mapcat_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_mapcat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_mapcat_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_mapcat_A_class }

func (t *A_arbace_core_reducers_mapcat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_mapcat_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_mapcat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_mapcat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_mapcat_A); return ok }

func A_arbace_core_reducers_mapcat_A_Cast(x any) *A_arbace_core_reducers_mapcat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_mapcat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_mapcat_A_class)) }; return v }



type A_arbace_core_reducers_mapcat_fn__153000085_A struct{ jrt.Object; F_f any }

func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000085_A_init jrt.ClassInit

func A_arbace_core_reducers_mapcat_fn__153000085_A_Init() { if !A_arbace_core_reducers_mapcat_fn__153000085_A_init.Done() { A_arbace_core_reducers_mapcat_fn__153000085_A_init.Run(A_arbace_core_reducers_mapcat_fn__153000085_A_clinit) } }

func A_arbace_core_reducers_mapcat_fn__153000085_A_clinit() { A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_mapcat_fn__153000085_A_class }

func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_mapcat_fn__153000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000085_A); return ok }

func A_arbace_core_reducers_mapcat_fn__153000085_A_Cast(x any) *A_arbace_core_reducers_mapcat_fn__153000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_mapcat_fn__153000085_A_class)) }; return v }



type A_arbace_core_reducers_mapcat_fn__153000087_A struct{ jrt.Object; F_f any }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000087_A_init jrt.ClassInit

func A_arbace_core_reducers_mapcat_fn__153000087_A_Init() { if !A_arbace_core_reducers_mapcat_fn__153000087_A_init.Done() { A_arbace_core_reducers_mapcat_fn__153000087_A_init.Run(A_arbace_core_reducers_mapcat_fn__153000087_A_clinit) } }

func A_arbace_core_reducers_mapcat_fn__153000087_A_clinit() { A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_mapcat_fn__153000087_A_class }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_mapcat_fn__153000087_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000087_A); return ok }

func A_arbace_core_reducers_mapcat_fn__153000087_A_Cast(x any) *A_arbace_core_reducers_mapcat_fn__153000087_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000087_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_mapcat_fn__153000087_A_class)) }; return v }



type A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A struct{ jrt.Object; F_f1 any }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Is_Compiler_AOTF2() {}

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_init jrt.ClassInit

func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_Init() { if !A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_init.Done() { A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_init.Run(A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_clinit) } }

func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_clinit() { A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_class }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A); return ok }

func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_Cast(x any) *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_class)) }; return v }



type A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A struct{ jrt.Object; F_f, F_f1 any }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class *jrt.Class

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_init jrt.ClassInit

func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_Init() { if !A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_init.Done() { A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_init.Run(A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_clinit) } }

func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_clinit() { A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_class }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A); return ok }

func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_Cast(x any) *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_class)) }; return v }



type A_arbace_core_reducers_monoid_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_monoid_A) Is_Compiler_AOTF2() {}

var A_arbace_core_reducers_monoid_A_fn_class *jrt.Class

var A_arbace_core_reducers_monoid_A_init jrt.ClassInit

func A_arbace_core_reducers_monoid_A_Init() { if !A_arbace_core_reducers_monoid_A_init.Done() { A_arbace_core_reducers_monoid_A_init.Run(A_arbace_core_reducers_monoid_A_clinit) } }

func A_arbace_core_reducers_monoid_A_clinit() { A_arbace_core_reducers_monoid_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_monoid_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_monoid_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_monoid_A_class }

func (t *A_arbace_core_reducers_monoid_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_monoid_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_monoid_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_monoid_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_monoid_A); return ok }

func A_arbace_core_reducers_monoid_A_Cast(x any) *A_arbace_core_reducers_monoid_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_monoid_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_monoid_A_class)) }; return v }



type A_arbace_core_reducers_monoid_m__153000147_A struct{ jrt.Object; F_op, F_ctor any }

func (t *A_arbace_core_reducers_monoid_m__153000147_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_monoid_m__153000147_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_monoid_m__153000147_A_fn_class *jrt.Class

var A_arbace_core_reducers_monoid_m__153000147_A_init jrt.ClassInit

func A_arbace_core_reducers_monoid_m__153000147_A_Init() { if !A_arbace_core_reducers_monoid_m__153000147_A_init.Done() { A_arbace_core_reducers_monoid_m__153000147_A_init.Run(A_arbace_core_reducers_monoid_m__153000147_A_clinit) } }

func A_arbace_core_reducers_monoid_m__153000147_A_clinit() { A_arbace_core_reducers_monoid_m__153000147_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_monoid_m__153000147_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_monoid_m__153000147_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_monoid_m__153000147_A_class }

func (t *A_arbace_core_reducers_monoid_m__153000147_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_monoid_m__153000147_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_monoid_m__153000147_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_monoid_m__153000147_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_monoid_m__153000147_A); return ok }

func A_arbace_core_reducers_monoid_m__153000147_A_Cast(x any) *A_arbace_core_reducers_monoid_m__153000147_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_monoid_m__153000147_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_monoid_m__153000147_A_class)) }; return v }



type A_arbace_core_reducers_reduce_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_reduce_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_reduce_A) Is_Compiler_AOTF2() {}

var A_arbace_core_reducers_reduce_A_fn_class *jrt.Class

var A_arbace_core_reducers_reduce_A_init jrt.ClassInit

func A_arbace_core_reducers_reduce_A_Init() { if !A_arbace_core_reducers_reduce_A_init.Done() { A_arbace_core_reducers_reduce_A_init.Run(A_arbace_core_reducers_reduce_A_clinit) } }

func A_arbace_core_reducers_reduce_A_clinit() { A_arbace_core_reducers_reduce_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_reduce_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_reduce_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_reduce_A_class }

func (t *A_arbace_core_reducers_reduce_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_reduce_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_reduce_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_reduce_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_reduce_A); return ok }

func A_arbace_core_reducers_reduce_A_Cast(x any) *A_arbace_core_reducers_reduce_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_reduce_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_reduce_A_class)) }; return v }



type A_arbace_core_reducers_reducer_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_reducer_A) Is_Compiler_AOTF2() {}

var A_arbace_core_reducers_reducer_A_fn_class *jrt.Class

var A_arbace_core_reducers_reducer_A_init jrt.ClassInit

func A_arbace_core_reducers_reducer_A_Init() { if !A_arbace_core_reducers_reducer_A_init.Done() { A_arbace_core_reducers_reducer_A_init.Run(A_arbace_core_reducers_reducer_A_clinit) } }

func A_arbace_core_reducers_reducer_A_clinit() { A_arbace_core_reducers_reducer_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_reducer_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_reducer_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_reducer_A_class }

func (t *A_arbace_core_reducers_reducer_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_reducer_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_reducer_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_reducer_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_reducer_A); return ok }

func A_arbace_core_reducers_reducer_A_Cast(x any) *A_arbace_core_reducers_reducer_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_reducer_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_reducer_A_class)) }; return v }



type A_arbace_core_reducers_reducer_reify__153000052_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IObj() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_reducer_reify__153000052_A_class }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_reducer_reify__153000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); return ok }

func A_arbace_core_reducers_reducer_reify__153000052_A_Cast(x any) *A_arbace_core_reducers_reducer_reify__153000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_reducer_reify__153000052_A_class)) }; return v }



type A_arbace_core_reducers_remove_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_remove_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_remove_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_remove_A_fn_class *jrt.Class

var A_arbace_core_reducers_remove_A_init jrt.ClassInit

func A_arbace_core_reducers_remove_A_Init() { if !A_arbace_core_reducers_remove_A_init.Done() { A_arbace_core_reducers_remove_A_init.Run(A_arbace_core_reducers_remove_A_clinit) } }

func A_arbace_core_reducers_remove_A_clinit() { A_arbace_core_reducers_remove_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_remove_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_remove_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_remove_A_class }

func (t *A_arbace_core_reducers_remove_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_remove_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_remove_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_remove_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_remove_A); return ok }

func A_arbace_core_reducers_remove_A_Cast(x any) *A_arbace_core_reducers_remove_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_remove_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_remove_A_class)) }; return v }



type A_arbace_core_reducers_remove_fn__153000101_A struct{ jrt.Object; F_pred any }

func (t *A_arbace_core_reducers_remove_fn__153000101_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_remove_fn__153000101_A_fn_class *jrt.Class

var A_arbace_core_reducers_remove_fn__153000101_A_init jrt.ClassInit

func A_arbace_core_reducers_remove_fn__153000101_A_Init() { if !A_arbace_core_reducers_remove_fn__153000101_A_init.Done() { A_arbace_core_reducers_remove_fn__153000101_A_init.Run(A_arbace_core_reducers_remove_fn__153000101_A_clinit) } }

func A_arbace_core_reducers_remove_fn__153000101_A_clinit() { A_arbace_core_reducers_remove_fn__153000101_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_remove_fn__153000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_remove_fn__153000101_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_remove_fn__153000101_A_class }

func (t *A_arbace_core_reducers_remove_fn__153000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_remove_fn__153000101_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_remove_fn__153000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_remove_fn__153000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_remove_fn__153000101_A); return ok }

func A_arbace_core_reducers_remove_fn__153000101_A_Cast(x any) *A_arbace_core_reducers_remove_fn__153000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_remove_fn__153000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_remove_fn__153000101_A_class)) }; return v }



type A_arbace_core_reducers_rfn_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_rfn_A) Is_Compiler_AOTF4() {}

var A_arbace_core_reducers_rfn_A_fn_class *jrt.Class

var A_arbace_core_reducers_rfn_A_init jrt.ClassInit

func A_arbace_core_reducers_rfn_A_Init() { if !A_arbace_core_reducers_rfn_A_init.Done() { A_arbace_core_reducers_rfn_A_init.Run(A_arbace_core_reducers_rfn_A_clinit) } }

func A_arbace_core_reducers_rfn_A_clinit() { A_arbace_core_reducers_rfn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_rfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_rfn_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_rfn_A_class }

func (t *A_arbace_core_reducers_rfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_rfn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_rfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_rfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_rfn_A); return ok }

func A_arbace_core_reducers_rfn_A_Cast(x any) *A_arbace_core_reducers_rfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_rfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_rfn_A_class)) }; return v }



type A_arbace_core_reducers_take_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_take_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_take_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_take_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_A_init jrt.ClassInit

func A_arbace_core_reducers_take_A_Init() { if !A_arbace_core_reducers_take_A_init.Done() { A_arbace_core_reducers_take_A_init.Run(A_arbace_core_reducers_take_A_clinit) } }

func A_arbace_core_reducers_take_A_clinit() { A_arbace_core_reducers_take_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_A_class }

func (t *A_arbace_core_reducers_take_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_A); return ok }

func A_arbace_core_reducers_take_A_Cast(x any) *A_arbace_core_reducers_take_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_A_class)) }; return v }



type A_arbace_core_reducers_take_fn__153000118_A struct{ jrt.Object; F_n any }

func (t *A_arbace_core_reducers_take_fn__153000118_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_take_fn__153000118_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_fn__153000118_A_init jrt.ClassInit

func A_arbace_core_reducers_take_fn__153000118_A_Init() { if !A_arbace_core_reducers_take_fn__153000118_A_init.Done() { A_arbace_core_reducers_take_fn__153000118_A_init.Run(A_arbace_core_reducers_take_fn__153000118_A_clinit) } }

func A_arbace_core_reducers_take_fn__153000118_A_clinit() { A_arbace_core_reducers_take_fn__153000118_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_fn__153000118_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_fn__153000118_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_fn__153000118_A_class }

func (t *A_arbace_core_reducers_take_fn__153000118_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_fn__153000118_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_fn__153000118_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_fn__153000118_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_fn__153000118_A); return ok }

func A_arbace_core_reducers_take_fn__153000118_A_Cast(x any) *A_arbace_core_reducers_take_fn__153000118_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_fn__153000118_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_fn__153000118_A_class)) }; return v }



type A_arbace_core_reducers_take_fn__153000120_A struct{ jrt.Object; F_n any }

func (t *A_arbace_core_reducers_take_fn__153000120_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_take_fn__153000120_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_fn__153000120_A_init jrt.ClassInit

func A_arbace_core_reducers_take_fn__153000120_A_Init() { if !A_arbace_core_reducers_take_fn__153000120_A_init.Done() { A_arbace_core_reducers_take_fn__153000120_A_init.Run(A_arbace_core_reducers_take_fn__153000120_A_clinit) } }

func A_arbace_core_reducers_take_fn__153000120_A_clinit() { A_arbace_core_reducers_take_fn__153000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_fn__153000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_fn__153000120_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_fn__153000120_A_class }

func (t *A_arbace_core_reducers_take_fn__153000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_fn__153000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_fn__153000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_fn__153000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_fn__153000120_A); return ok }

func A_arbace_core_reducers_take_fn__153000120_A_Cast(x any) *A_arbace_core_reducers_take_fn__153000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_fn__153000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_fn__153000120_A_class)) }; return v }



type A_arbace_core_reducers_take_fn__153000120_fn__153000121_A struct{ jrt.Object; F_cnt, F_f1 any }

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_init jrt.ClassInit

func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_Init() { if !A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_init.Done() { A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_init.Run(A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_clinit) } }

func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_clinit() { A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_class }

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_fn__153000120_fn__153000121_A); return ok }

func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_Cast(x any) *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_fn__153000120_fn__153000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_class)) }; return v }



type A_arbace_core_reducers_take_while_A struct{ jrt.Object }

func (t *A_arbace_core_reducers_take_while_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_take_while_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_take_while_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_while_A_init jrt.ClassInit

func A_arbace_core_reducers_take_while_A_Init() { if !A_arbace_core_reducers_take_while_A_init.Done() { A_arbace_core_reducers_take_while_A_init.Run(A_arbace_core_reducers_take_while_A_clinit) } }

func A_arbace_core_reducers_take_while_A_clinit() { A_arbace_core_reducers_take_while_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_while_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_while_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_while_A_class }

func (t *A_arbace_core_reducers_take_while_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_while_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_while_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_while_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_while_A); return ok }

func A_arbace_core_reducers_take_while_A_Cast(x any) *A_arbace_core_reducers_take_while_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_while_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_while_A_class)) }; return v }



type A_arbace_core_reducers_take_while_fn__153000111_A struct{ jrt.Object; F_pred any }

func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_take_while_fn__153000111_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_while_fn__153000111_A_init jrt.ClassInit

func A_arbace_core_reducers_take_while_fn__153000111_A_Init() { if !A_arbace_core_reducers_take_while_fn__153000111_A_init.Done() { A_arbace_core_reducers_take_while_fn__153000111_A_init.Run(A_arbace_core_reducers_take_while_fn__153000111_A_clinit) } }

func A_arbace_core_reducers_take_while_fn__153000111_A_clinit() { A_arbace_core_reducers_take_while_fn__153000111_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_while_fn__153000111_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_while_fn__153000111_A_class }

func (t *A_arbace_core_reducers_take_while_fn__153000111_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_while_fn__153000111_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_while_fn__153000111_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_while_fn__153000111_A); return ok }

func A_arbace_core_reducers_take_while_fn__153000111_A_Cast(x any) *A_arbace_core_reducers_take_while_fn__153000111_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_while_fn__153000111_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_while_fn__153000111_A_class)) }; return v }



type A_arbace_core_reducers_take_while_fn__153000113_A struct{ jrt.Object; F_pred any }

func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Is_Compiler_AOTF1() {}

var A_arbace_core_reducers_take_while_fn__153000113_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_while_fn__153000113_A_init jrt.ClassInit

func A_arbace_core_reducers_take_while_fn__153000113_A_Init() { if !A_arbace_core_reducers_take_while_fn__153000113_A_init.Done() { A_arbace_core_reducers_take_while_fn__153000113_A_init.Run(A_arbace_core_reducers_take_while_fn__153000113_A_clinit) } }

func A_arbace_core_reducers_take_while_fn__153000113_A_clinit() { A_arbace_core_reducers_take_while_fn__153000113_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_while_fn__153000113_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_while_fn__153000113_A_class }

func (t *A_arbace_core_reducers_take_while_fn__153000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_while_fn__153000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_while_fn__153000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_while_fn__153000113_A); return ok }

func A_arbace_core_reducers_take_while_fn__153000113_A_Cast(x any) *A_arbace_core_reducers_take_while_fn__153000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_while_fn__153000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_while_fn__153000113_A_class)) }; return v }



type A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A struct{ jrt.Object; F_pred, F_f1 any }

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Is_Compiler_AOTF0() {}

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class *jrt.Class

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_init jrt.ClassInit

func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_Init() { if !A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_init.Done() { A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_init.Run(A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_clinit) } }

func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_clinit() { A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_class }

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A); return ok }

func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_Cast(x any) *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_class)) }; return v }
