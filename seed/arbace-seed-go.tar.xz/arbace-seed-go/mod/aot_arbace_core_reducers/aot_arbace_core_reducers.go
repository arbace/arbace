//line aot_arbace_core_reducers.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_core_protocols"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)
//line :9:1
func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New() *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_core_reducers_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_reducers_A_const_3, A_arbace_core_reducers_A_const_4, A_arbace_core_reducers_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_core_reducers_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_reducers_eval153000008_fn__153000009_A_New() *A_arbace_core_reducers_eval153000008_fn__153000009_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000008_fn__153000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_core_reducers_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core_reducers_A_const_9.GetRawRoot__O(), A_arbace_core_reducers_A_const_10) }












func A_arbace_core_reducers_fn__153000016_A_New() *A_arbace_core_reducers_fn__153000016_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fn__153000016_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Ctor() {}
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Invoke_O__O(self any) any { return jrt.ForkJoinPool_New() }

func A_arbace_core_reducers_fjtask_A_New() *A_arbace_core_reducers_fjtask_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjtask_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Invoke_O_O__O(self, f__0 any) any {
	return jrt.ForkJoinTask_Adapt_Callable__ForkJoinTask(jrt.Callable_Cast(f__0))
}
func A_arbace_core_reducers_fjinvoke_A_New() *A_arbace_core_reducers_fjinvoke_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjinvoke_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Ctor() {}
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.ForkJoinTask_InForkJoinPool__Z() {
		return lang.IFn_Cast(f__0).Invoke__O() } else {
			var tmp1 any; var root_21 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_core_reducers_A_const_11.GetRawRoot__O(); if linked_22 == nil { tmp1 = ifn_23.Invoke_O__O(arg_24) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_21, arg_24) }; var tmp2 *jrt.ForkJoinPool = jrt.As[*jrt.ForkJoinPool](tmp1); var tmp3 any; var root_25 any = A_arbace_core_reducers_A_const_12.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, A_arbace_core_reducers_fjtask_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = f__0; if linked_26 == nil { tmp3 = ifn_27.Invoke_O__O(arg_28) } else { tmp3 = linked_26.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(root_25, arg_28) }; return jrt.NN(tmp2).Invoke_ForkJoinTask__O(jrt.ForkJoinTask_Cast(tmp3))
		} }
func A_arbace_core_reducers_fjfork_A_New() *A_arbace_core_reducers_fjfork_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjfork_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Ctor() {}
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Fork__ForkJoinTask() }

func A_arbace_core_reducers_fjjoin_A_New() *A_arbace_core_reducers_fjjoin_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjjoin_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Ctor() {}
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Join__O() }



func A_arbace_core_reducers_reduce_A_New() *A_arbace_core_reducers_reduce_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_reduce_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Ctor() {}
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O_O__O(self, f__0, init__1, coll__2 any) any {





	if jrt.Map_InstanceOf(coll__2) {
		var target_29 any = coll__2; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_InstanceOf(target_29); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_29) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_Cast(target_29).Kv_reduce_O_O__O(f__0, init__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(target_29, f__0, init__1) } } else {
			var target_30 any = coll__2; var tmp3 bool; var tmp4 bool; tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_30); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_30) }; tmp3 = tmp4; if tmp3 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_30).Coll_reduce_O_O__O(f__0, init__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(target_30, f__0, init__1) } } }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	var root_31 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, A_arbace_core_reducers_reduce_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = f__0; var arg_35 any = lang.IFn_Cast(f__0).Invoke__O(); var arg_36 any = coll__1; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36)
	}
}



func A_arbace_core_reducers_eval153000031_fn__153000032_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__153000024__2_ any; var tmp1 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New(); var tmp2 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; G__153000024__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(G__153000024__2_); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(p0 any) *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Ctor_O(c__G__153000024 any) { t.F_G__153000024 = c__G__153000024 }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4 any) any { var cache__231000236__auto____5 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____6 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____5)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__153000039__1)); if jrt.J2g_Truth(f__231000237__auto____6) { return lang.IFn_Cast(f__231000237__auto____6).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } else { var tmp1 any; var root_39 any = A_arbace_core_reducers_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = self; var arg_43 any = gf__coll__153000039__1; var arg_44 any = A_arbace_core_reducers_A_const_17; var arg_45 any = t.F_G__153000024; if linked_40 == nil { tmp1 = ifn_41.Invoke_O_O_O_O__O(arg_42, arg_43, arg_44, arg_45) } else { tmp1 = linked_40.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_39, arg_42, arg_43, arg_44, arg_45) }; return lang.IFn_Cast(tmp1).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000033__1, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4 any) any { var target_37 any = gf__coll__153000033__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_37 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_37) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_37, Lit_8, jrt.RefArrayOf(jrt.Object_class, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4)) } else { return A_arbace_core_reducers_CollFold_A_Cast(target_37).Coll_fold_O_O_O__O(gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4) } }


func A_arbace_core_reducers_fold_A_New() *A_arbace_core_reducers_fold_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fold_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O_O__O(self, n__0, combinef__1, reducef__2, coll__3 any) any {













	var target_47 any = coll__3; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_47); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_47) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_47).Coll_fold_O_O_O__O(n__0, combinef__1, reducef__2) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_18.GetRawRoot__O()).Invoke_O_O_O_O__O(target_47, n__0, combinef__1, reducef__2) } }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O__O(self, combinef__0, reducef__1, coll__2 any) any {











	var root_48 any = A_arbace_core_reducers_A_const_19.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, A_arbace_core_reducers_fold_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = A_arbace_core_reducers_A_const_20; var arg_52 any = combinef__0; var arg_53 any = reducef__1; var arg_54 any = coll__2; if linked_49 == nil { return ifn_50.Invoke_O_O_O_O__O(arg_51, arg_52, arg_53, arg_54) } else { return linked_49.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O_O__O(root_48, arg_51, arg_52, arg_53, arg_54) } }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O__O(self, reducef__0, coll__1 any) any {










	var root_55 any = A_arbace_core_reducers_A_const_19.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_core_reducers_fold_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = reducef__0; var arg_59 any = reducef__0; var arg_60 any = coll__1; if linked_56 == nil { return ifn_57.Invoke_O_O_O__O(arg_58, arg_59, arg_60) } else { return linked_56.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O__O(root_55, arg_58, arg_59, arg_60)
	}
}


func A_arbace_core_reducers_reducer_A_New() *A_arbace_core_reducers_reducer_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_reducer_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :74:1
func A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_reducer_reify__153000052_A { t := &A_arbace_core_reducers_reducer_reify__153000052_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_61 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_61); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_61) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_61).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_61, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O__O(f1__1 any) any {


	var target_62 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_62); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_62) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_62).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_62, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }






func A_arbace_core_reducers_folder_A_New() *A_arbace_core_reducers_folder_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_folder_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Ctor() {}
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :88:1
func A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_folder_reify__153000055_A { t := &A_arbace_core_reducers_folder_reify__153000055_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {








	var target_63 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_63); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_63) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_63).Coll_fold_O_O_O__O(n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_18; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(target_63, n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_64 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_64); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_64) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_64).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_64, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O__O(f1__1 any) any {


	var target_65 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_65); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_65) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_65).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_65, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }










func A_arbace_core_reducers_do_curried_A_New() *A_arbace_core_reducers_do_curried_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_curried_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Ctor() {}
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Invoke_O_O_O_O_O_O__O(self, name__0, doc__1, meta__2, args__3, body__4 any) any { var cargs__6 any; var root_66 any = A_arbace_core_reducers_A_const_21.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_68 lang.IFn; if

	linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_70 any = A_arbace_core_reducers_A_const_22.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = args__3; if linked_71 == nil { arg_69 = ifn_72.Invoke_O__O(arg_73) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_70, arg_73) }; if linked_67 == nil { cargs__6 = ifn_68.Invoke_O__O(arg_69) } else { cargs__6 = linked_67.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_66, arg_69) }; var root_74 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_26); var tmp3 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(name__0); var tmp4 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(doc__1); var tmp5 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(meta__2); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp7 any; var root_87 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var root_91 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(cargs__6); var arg_95 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp9 any; var root_96 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_27); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp13 any; var root_106 any = A_arbace_core_reducers_A_const_28.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = A_arbace_core_reducers_A_const_29.GetRawRoot__O(); var arg_110 any; var root_111 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var root_115 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_30); if linked_116 == nil { arg_114 = ifn_117.Invoke_O__O(arg_118) } else { arg_114 = linked_116.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_115, arg_118) }; if linked_112 == nil { arg_110 = ifn_113.Invoke_O__O(arg_114) } else { arg_110 = linked_112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_111, arg_114) }; if linked_107 == nil { tmp13 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp13 = linked_107.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; var tmp14 any = tmp12.Invoke_O__O(tmp13); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp16 any; var root_119 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(name__0), cargs__6, lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_30)); if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_119, arg_122) }; arg_99 = tmp10.Invoke_O_O_O__O(tmp11, tmp14, tmp15.Invoke_O__O(tmp16)); if linked_97 == nil { tmp9 = ifn_98.Invoke_O__O(arg_99) } else { tmp9 = linked_97.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_96, arg_99) }; arg_95 = tmp8.Invoke_O__O(tmp9); if linked_92 == nil { arg_90 = ifn_93.Invoke_O_O__O(arg_94, arg_95) } else { arg_90 = linked_92.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_91, arg_94, arg_95) }; if linked_88 == nil { tmp7 = ifn_89.Invoke_O__O(arg_90) } else { tmp7 = linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90) }; var tmp17 any = tmp6.Invoke_O__O(tmp7); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp19 any; var root_129 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var root_133 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(args__3); var arg_137 any = body__4; if linked_134 == nil { arg_132 = ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { arg_132 = linked_134.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) }; if linked_130 == nil { tmp19 = ifn_131.Invoke_O__O(arg_132) } else { tmp19 = linked_130.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_129, arg_132) }; arg_77 = tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp17, tmp18.Invoke_O__O(tmp19)); if linked_75 == nil { return ifn_76.Invoke_O__O(arg_77) } else { return linked_75.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_74, arg_77) } }




func A_arbace_core_reducers_defcurried_A_New() *A_arbace_core_reducers_defcurried_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_defcurried_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) Ctor() {}
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) DoInvoke_O_O_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, doc__3, meta__4, args__5, body__6 any) any {



	var root_138 any = A_arbace_core_reducers_A_const_31.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_core_reducers_do_curried_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = name__2; var arg_142 any = doc__3; var arg_143 any = meta__4; var arg_144 any = args__5; var arg_145 any = body__6; if linked_139 == nil { return ifn_140.Invoke_O_O_O_O_O__O(arg_141, arg_142, arg_143, arg_144, arg_145) } else { return linked_139.(*A_arbace_core_reducers_do_curried_A).Invoke_O_O_O_O_O_O__O(root_138, arg_141, arg_142, arg_143, arg_144, arg_145)
	} }
func A_arbace_core_reducers_do_rfn_A_New() *A_arbace_core_reducers_do_rfn_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_rfn_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Ctor() {}
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Invoke_O_O_O_O__O(self, f1__0, k__1, fkv__2 any) any { var root_146 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_32); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp4 any; var root_157 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_161 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp6 any; var root_166 any = A_arbace_core_reducers_A_const_28.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = A_arbace_core_reducers_A_const_29.GetRawRoot__O(); var arg_170 any; var root_171 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var root_175 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; if linked_176 == nil { arg_174 = ifn_177.Invoke__O() } else { arg_174 = linked_176.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_175) }; if linked_172 == nil { arg_170 = ifn_173.Invoke_O__O(arg_174) } else { arg_170 = linked_172.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_171, arg_174) }; if linked_167 == nil { tmp6 = ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { tmp6 = linked_167.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) }; arg_164 = tmp5.Invoke_O__O(tmp6); var arg_165 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp8 any; var root_178 any = A_arbace_core_reducers_A_const_23.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any; var root_182 any = A_arbace_core_reducers_A_const_24.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(f1__0); if linked_183 == nil { arg_181 = ifn_184.Invoke_O__O(arg_185) } else { arg_181 = linked_183.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_182, arg_185) }; if linked_179 == nil { tmp8 = ifn_180.Invoke_O__O(arg_181) } else { tmp8 = linked_179.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_178, arg_181) }; arg_165 = tmp7.Invoke_O__O(tmp8); if linked_162 == nil { arg_160 = ifn_163.Invoke_O_O__O(arg_164, arg_165) } else { arg_160 = linked_162.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_161, arg_164, arg_165) }; if linked_158 == nil { tmp4 = ifn_159.Invoke_O__O(arg_160) } else { tmp4 = linked_158.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_157, arg_160) }; var tmp9 any = tmp3.Invoke_O__O(tmp4); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp11 any; var root_186 any = A_arbace_core_reducers_A_const_33.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_walk.A_arbace_walk_postwalk_A_fn_class); var ifn_188 lang.IFn; if


	linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var tmp12 any = A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(k__1); var tmp13 *jrt.Class; var fncls__204 *jrt.Class = A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class; if fncls__204 == nil { var fncls__204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class = fncls__204d; tmp13 = fncls__204d } else { tmp13 = fncls__204 }; arg_189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_190 any = fkv__2; if linked_187 == nil { tmp11 = ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { tmp11 = linked_187.(*aot_arbace_walk.A_arbace_walk_postwalk_A).Invoke_O_O_O__O(root_186, arg_189, arg_190) }; arg_149 = /*line :112:1*/tmp1.Invoke_O_O_O_O__O(tmp2, tmp9, tmp10.Invoke_O__O(tmp11), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(fkv__2)); if linked_147 == nil { return ifn_148.Invoke_O__O(arg_149) } else { return linked_147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_146, arg_149) } }


func A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(p0 any) *A_arbace_core_reducers_do_rfn_fn__153000066_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_rfn_fn__153000066_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Invoke_O_O__O(self, p1__153000065_SHARP___1 any) any {
	var tmp1 any; var root_191 any = A_arbace_core_reducers_A_const_34.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = p1__153000065_SHARP___1; if linked_192 == nil { tmp1 = ifn_193.Invoke_O__O(arg_194) } else { tmp1 = linked_192.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_191, arg_194) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var tmp3 any; var root_195 any = A_arbace_core_reducers_A_const_35.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = p1__153000065_SHARP___1; if linked_196 == nil { tmp3 = ifn_197.Invoke_O__O(arg_198) } else { tmp3 = linked_196.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_195, arg_198) }; if jrt.J2g_Truth(tmp3) { tmp2 = A_arbace_core_reducers_A_const_21.GetRawRoot__O() } else { tmp2 = A_arbace_core_reducers_A_const_36.GetRawRoot__O() }; var tmp4 lang.IFn = lang.IFn_Cast(tmp2); var tmp5 any; var root_199 any = A_arbace_core_reducers_A_const_37.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_201 lang.IFn
		if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, t.F_k)); var arg_203 any = p1__153000065_SHARP___1; if linked_200 == nil { tmp5 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { tmp5 = linked_200.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }
//line :117:1
		return tmp4.Invoke_O__O(tmp5) } else {
//line :116:1
			return p1__153000065_SHARP___1
		}
}




func A_arbace_core_reducers_rfn_A_New() *A_arbace_core_reducers_rfn_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_rfn_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Ctor() {}
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, p__153000069__2, fkv__3 any) any { var vec__153000070__5 any = p__153000069__2; var f1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__153000070__5, lang.RT_IntCast_J__I_NoInit(0), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__153000070__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_205 any = A_arbace_core_reducers_A_const_38.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, A_arbace_core_reducers_do_rfn_A_fn_class); var ifn_207 lang.IFn; if


	linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = f1__6; var arg_209 any = k__7; var arg_210 any = fkv__3; if linked_206 == nil { return ifn_207.Invoke_O_O_O__O(arg_208, arg_209, arg_210) } else { return linked_206.(*A_arbace_core_reducers_do_rfn_A).Invoke_O_O_O_O__O(root_205, arg_208, arg_209, arg_210) } }

func A_arbace_core_reducers_map_A_New() *A_arbace_core_reducers_map_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Ctor() {}
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	var root_211 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, A_arbace_core_reducers_folder_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = coll__1; var arg_215 any; var tmp1 any = A_arbace_core_reducers_map_fn__153000080_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_core_reducers_map_fn__153000080_A_fn_class
	if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_core_reducers_map_fn__153000080_A_fn_class = fncls__217d; tmp2 = fncls__217d } else { tmp2 = fncls__217 }; arg_215 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :132:1
	if linked_212 == nil { return ifn_213.Invoke_O_O__O(arg_214, arg_215) } else { return linked_212.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_211, arg_214, arg_215) } }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any = A_arbace_core_reducers_map_fn__153000078_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_core_reducers_map_fn__153000078_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_core_reducers_map_fn__153000078_A_fn_class = fncls__223d; tmp2 = fncls__223d } else { tmp2 = fncls__223 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :128:1
func A_arbace_core_reducers_map_fn__153000078_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000078_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000078_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_218 any = A_arbace_core_reducers_A_const_40.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, A_arbace_core_reducers_map_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = t.F_f; var arg_222 any = x__153000058__auto____1; if linked_219 == nil { return ifn_220.Invoke_O_O__O(arg_221, arg_222) } else { return linked_219.(*A_arbace_core_reducers_map_A).Invoke_O_O_O__O(root_218, arg_221, arg_222) } }




func A_arbace_core_reducers_map_fn__153000080_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000080_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_A{}; t.Ctor_O(p0); return t }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(t.F_f, f1__1); var tmp2 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class = fncls__216d; tmp2 = fncls__216d } else { tmp2 = fncls__216 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :134:1
func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_fn__153000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O__O(v__2)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_mapcat_A_New() *A_arbace_core_reducers_mapcat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Ctor() {}
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {




	var root_224 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_core_reducers_folder_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = coll__1; var arg_228 any; var tmp1 any = A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class
	if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class = fncls__251d; tmp2 = fncls__251d } else { tmp2 = fncls__251 }; arg_228 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :143:1
	if linked_225 == nil { return ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { return linked_225.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_224, arg_227, arg_228) } }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any = A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class = fncls__257d; tmp2 = fncls__257d } else { tmp2 = fncls__257 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :138:1
func A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000085_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000085_A{}; t.Ctor_O(p0); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_252 any = A_arbace_core_reducers_A_const_42.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, A_arbace_core_reducers_mapcat_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = t.F_f; var arg_256 any = x__153000058__auto____1; if linked_253 == nil { return ifn_254.Invoke_O_O__O(arg_255, arg_256) } else { return linked_253.(*A_arbace_core_reducers_mapcat_A).Invoke_O_O_O__O(root_252, arg_255, arg_256) } }





func A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Invoke_O_O__O(self, f1__1 any) any { var f1__2 any; var tmp1 any = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(f1__1); var tmp2 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class; if
												fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class = fncls__237d; tmp2 = fncls__237d } else { tmp2 = fncls__237 }; f1__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any =




	A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(t.F_f, f1__2); var tmp4 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class; if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class = fncls__250d; tmp4 = fncls__250d } else { tmp4 = fncls__250 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }
//line :145:1
func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any { var x__4 any = lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3); if



	lang.RT_IsReduced_O__Z_NoInit(x__4) { var root_229 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = x__4; if linked_230 == nil { return ifn_231.Invoke_O__O(arg_232) } else { return linked_230.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_229, arg_232) } } else { return x__4 } }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var x__3 any = lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2); if

	lang.RT_IsReduced_O__Z_NoInit(x__3) { var root_233 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = x__3; if linked_234 == nil { return ifn_235.Invoke_O__O(arg_236) } else { return linked_234.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_233, arg_236) } } else { return x__3 } }


func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var root_238 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, A_arbace_core_reducers_reduce_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = t.F_f1; var arg_242 any = ret__1; var arg_243 any = lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3); if linked_239 == nil { return ifn_240.Invoke_O_O_O__O(arg_241, arg_242, arg_243) } else { return linked_239.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_238, arg_241, arg_242, arg_243) } }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var root_244 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, A_arbace_core_reducers_reduce_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = t.F_f1; var arg_248 any = ret__1; var arg_249 any = lang.IFn_Cast(t.F_f).Invoke_O__O(v__2); if linked_245 == nil { return ifn_246.Invoke_O_O_O__O(arg_247, arg_248, arg_249) } else { return linked_245.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_244, arg_247, arg_248, arg_249) } }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_filter_A_New() *A_arbace_core_reducers_filter_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Ctor() {}
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	var root_258 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_core_reducers_folder_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = coll__1; var arg_262 any; var tmp1 any = A_arbace_core_reducers_filter_fn__153000096_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_core_reducers_filter_fn__153000096_A_fn_class
	if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_core_reducers_filter_fn__153000096_A_fn_class = fncls__264d; tmp2 = fncls__264d } else { tmp2 = fncls__264 }; arg_262 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :159:1
	if linked_259 == nil { return ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { return linked_259.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_258, arg_261, arg_262) } }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_filter_fn__153000094_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__270 *jrt.Class = A_arbace_core_reducers_filter_fn__153000094_A_fn_class; if fncls__270 == nil { var fncls__270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_core_reducers_filter_fn__153000094_A_fn_class = fncls__270d; tmp2 = fncls__270d } else { tmp2 = fncls__270 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :154:1
func A_arbace_core_reducers_filter_fn__153000094_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000094_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000094_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_265 any = A_arbace_core_reducers_A_const_43.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, A_arbace_core_reducers_filter_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t.F_pred; var arg_269 any = x__153000058__auto____1; if linked_266 == nil { return ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { return linked_266.(*A_arbace_core_reducers_filter_A).Invoke_O_O_O__O(root_265, arg_268, arg_269) } }





func A_arbace_core_reducers_filter_fn__153000096_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000096_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(t.F_pred, f1__1); var tmp2 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class = fncls__263d; tmp2 = fncls__263d } else { tmp2 = fncls__263 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :161:1
func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :163:1
			return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_remove_A_New() *A_arbace_core_reducers_remove_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_remove_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Ctor() {}
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	var root_271 any = A_arbace_core_reducers_A_const_43.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_core_reducers_filter_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any; var root_276 any = A_arbace_core_reducers_A_const_44.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = pred__0; if linked_277 == nil { arg_274 = ifn_278.Invoke_O__O(arg_279) } else { arg_274 = linked_277.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_276, arg_279) }; var arg_275 any = coll__1; if linked_272 == nil { return ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { return linked_272.(*A_arbace_core_reducers_filter_A).Invoke_O_O_O__O(root_271, arg_274, arg_275) } }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_remove_fn__153000101_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__285 *jrt.Class = A_arbace_core_reducers_remove_fn__153000101_A_fn_class; if fncls__285 == nil { var fncls__285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_core_reducers_remove_fn__153000101_A_fn_class = fncls__285d; tmp2 = fncls__285d } else { tmp2 = fncls__285 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :167:1
func A_arbace_core_reducers_remove_fn__153000101_A_New_O(p0 any) *A_arbace_core_reducers_remove_fn__153000101_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_remove_fn__153000101_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_280 any = A_arbace_core_reducers_A_const_45.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, A_arbace_core_reducers_remove_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = t.F_pred; var arg_284 any = x__153000058__auto____1; if linked_281 == nil { return ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { return linked_281.(*A_arbace_core_reducers_remove_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) } }






func A_arbace_core_reducers_flatten_A_New() *A_arbace_core_reducers_flatten_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O_O__O(self, coll__0 any) any {





	var root_286 any = A_arbace_core_reducers_A_const_39.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_core_reducers_folder_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = coll__0; var arg_290 any; var tmp1 any = A_arbace_core_reducers_flatten_fn__153000106_A_New(); var tmp2 *jrt.Class; var fncls__301 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000106_A_fn_class
	if fncls__301 == nil { var fncls__301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_core_reducers_flatten_fn__153000106_A_fn_class = fncls__301d; tmp2 = fncls__301d } else { tmp2 = fncls__301 }; arg_290 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :180:1
	if linked_287 == nil { return ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { return linked_287.(*A_arbace_core_reducers_folder_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) } }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_core_reducers_flatten_fn__153000104_A_New(); var tmp2 *jrt.Class; var fncls__306 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000104_A_fn_class; if fncls__306 == nil { var fncls__306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_core_reducers_flatten_fn__153000104_A_fn_class = fncls__306d; tmp2 = fncls__306d } else { tmp2 = fncls__306 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :174:1
func A_arbace_core_reducers_flatten_fn__153000104_A_New() *A_arbace_core_reducers_flatten_fn__153000104_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000104_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_302 any = A_arbace_core_reducers_A_const_46.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, A_arbace_core_reducers_flatten_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = x__153000058__auto____1; if linked_303 == nil { return ifn_304.Invoke_O__O(arg_305) } else { return linked_303.(*A_arbace_core_reducers_flatten_A).Invoke_O_O__O(root_302, arg_305) } }






func A_arbace_core_reducers_flatten_fn__153000106_A_New() *A_arbace_core_reducers_flatten_fn__153000106_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Ctor() {}
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(f1__1); var tmp2 *jrt.Class; var fncls__300 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class; if fncls__300 == nil { var fncls__300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class = fncls__300d; tmp2 = fncls__300d } else { tmp2 = fncls__300 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :182:1
func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(p0 any) *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A{}; t.Ctor_O(p0); return t }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any {


	var tmp1 any; var root_291 any = A_arbace_core_reducers_A_const_34.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = v__2; if linked_292 == nil { tmp1 = ifn_293.Invoke_O__O(arg_294) } else { tmp1 = linked_292.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_291, arg_294) }; if jrt.J2g_Truth(tmp1) {
		var target_295 any; var root_296 any = A_arbace_core_reducers_A_const_46.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_core_reducers_flatten_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = v__2; if linked_297 == nil { target_295 = ifn_298.Invoke_O__O(arg_299) } else { target_295 = linked_297.(*A_arbace_core_reducers_flatten_A).Invoke_O_O__O(root_296, arg_299) }; var tmp2 bool; var tmp3 bool; tmp3 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_295); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_295) }; tmp2 = tmp3; if tmp2 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_295).Coll_reduce_O_O__O(t.F_f1, ret__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(target_295, t.F_f1, ret__1) } } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_f1).Invoke__O()
}




func A_arbace_core_reducers_take_while_A_New() *A_arbace_core_reducers_take_while_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Ctor() {}
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {



	var root_307 any = A_arbace_core_reducers_A_const_47.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, A_arbace_core_reducers_reducer_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = coll__1; var arg_311 any; var tmp1 any = A_arbace_core_reducers_take_while_fn__153000113_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__321 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000113_A_fn_class
	if fncls__321 == nil { var fncls__321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_core_reducers_take_while_fn__153000113_A_fn_class = fncls__321d; tmp2 = fncls__321d } else { tmp2 = fncls__321 }; arg_311 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :193:1
	if linked_308 == nil { return ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { return linked_308.(*A_arbace_core_reducers_reducer_A).Invoke_O_O_O__O(root_307, arg_310, arg_311) } }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_take_while_fn__153000111_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__327 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000111_A_fn_class; if fncls__327 == nil { var fncls__327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_core_reducers_take_while_fn__153000111_A_fn_class = fncls__327d; tmp2 = fncls__327d } else { tmp2 = fncls__327 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :189:1
func A_arbace_core_reducers_take_while_fn__153000111_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000111_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000111_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_322 any = A_arbace_core_reducers_A_const_48.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_core_reducers_take_while_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = t.F_pred; var arg_326 any = x__153000058__auto____1; if linked_323 == nil { return ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { return linked_323.(*A_arbace_core_reducers_take_while_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) } }




func A_arbace_core_reducers_take_while_fn__153000113_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000113_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(t.F_pred, f1__1); var tmp2 *jrt.Class; var fncls__320 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class; if fncls__320 == nil { var fncls__320d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class = fncls__320d; tmp2 = fncls__320d } else { tmp2 = fncls__320 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :195:1
func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
			var root_312 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = ret__1; if linked_313 == nil { return ifn_314.Invoke_O__O(arg_315) } else { return linked_313.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_312, arg_315) } } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { var root_316 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = ret__1; if linked_317 == nil { return ifn_318.Invoke_O__O(arg_319) } else { return linked_317.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_316, arg_319) } } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_take_A_New() *A_arbace_core_reducers_take_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Ctor() {}
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var root_328 any = A_arbace_core_reducers_A_const_47.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_core_reducers_reducer_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = coll__1; var arg_332 any; var tmp1 any = A_arbace_core_reducers_take_fn__153000120_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__368 *jrt.Class = A_arbace_core_reducers_take_fn__153000120_A_fn_class
	if fncls__368 == nil { var fncls__368d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_core_reducers_take_fn__153000120_A_fn_class = fncls__368d; tmp2 = fncls__368d } else { tmp2 = fncls__368 }; arg_332 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :205:1
	if linked_329 == nil { return ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { return linked_329.(*A_arbace_core_reducers_reducer_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) } }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_core_reducers_take_fn__153000118_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__374 *jrt.Class = A_arbace_core_reducers_take_fn__153000118_A_fn_class; if fncls__374 == nil { var fncls__374d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_core_reducers_take_fn__153000118_A_fn_class = fncls__374d; tmp2 = fncls__374d } else { tmp2 = fncls__374 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :201:1
func A_arbace_core_reducers_take_fn__153000118_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000118_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000118_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_369 any = A_arbace_core_reducers_A_const_52.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, A_arbace_core_reducers_take_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = t.F_n; var arg_373 any = x__153000058__auto____1; if linked_370 == nil { return ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { return linked_370.(*A_arbace_core_reducers_take_A).Invoke_O_O_O__O(root_369, arg_372, arg_373) } }




func A_arbace_core_reducers_take_fn__153000120_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000120_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_A{}; t.Ctor_O(p0); return t }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any; var root_333 any = A_arbace_core_reducers_A_const_49.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_335 lang.IFn; if
												linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = t.F_n; if linked_334 == nil { cnt__2 = ifn_335.Invoke_O__O(arg_336) } else { cnt__2 = linked_334.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_333, arg_336) }; var tmp1 any =
												A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(cnt__2, f1__1); var tmp2 *jrt.Class; var fncls__367 *jrt.Class = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class; if fncls__367 == nil { var fncls__367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class = fncls__367d; tmp2 = fncls__367d } else { tmp2 = fncls__367 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :208:1
func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_fn__153000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var root_347 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = t.F_cnt; var arg_351 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_348 == nil { ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { linked_348.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_347, arg_350, arg_351) }
	var tmp1 bool; var na_337 any; var root_338 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = t.F_cnt; if linked_339 == nil { na_337 = ifn_340.Invoke_O__O(arg_341) } else { na_337 = linked_339.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_338, arg_341) }; if jrt.Long_InstanceOf(na_337) { var n0_342 int64 = jrt.NN(jrt.Long_Cast(na_337)).LongValue__J(); tmp1 = n0_342 < 0 } else { if jrt.Double_InstanceOf(na_337) { var n0_342_2 float64 = jrt.NN(jrt.Double_Cast(na_337)).DoubleValue__D(); tmp1 = n0_342_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_337) } }; if tmp1 {
		var root_343 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = ret__1; if linked_344 == nil { return ifn_345.Invoke_O__O(arg_346) } else { return linked_344.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_343, arg_346) } } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var root_362 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = t.F_cnt; var arg_366 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_363 == nil { ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { linked_363.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_362, arg_365, arg_366) }; var tmp1 bool; var na_352 any; var root_353 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = t.F_cnt; if linked_354 == nil { na_352 = ifn_355.Invoke_O__O(arg_356) } else { na_352 = linked_354.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_353, arg_356) }; if jrt.Long_InstanceOf(na_352) { var n0_357 int64 = jrt.NN(jrt.Long_Cast(na_352)).LongValue__J(); tmp1 = n0_357 < 0 } else { if jrt.Double_InstanceOf(na_352) { var n0_357_2 float64 = jrt.NN(jrt.Double_Cast(na_352)).DoubleValue__D(); tmp1 = n0_357_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_352) } }; if tmp1 { var root_358 any = A_arbace_core_reducers_A_const_41.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = ret__1; if linked_359 == nil { return ifn_360.Invoke_O__O(arg_361) } else { return linked_359.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_358, arg_361) } } else { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }






func A_arbace_core_reducers_drop_A_New() *A_arbace_core_reducers_drop_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Ctor() {}
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var root_375 any = A_arbace_core_reducers_A_const_47.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_core_reducers_reducer_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = coll__1; var arg_379 any; var tmp1 any = A_arbace_core_reducers_drop_fn__153000127_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__407 *jrt.Class = A_arbace_core_reducers_drop_fn__153000127_A_fn_class
	if fncls__407 == nil { var fncls__407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_core_reducers_drop_fn__153000127_A_fn_class = fncls__407d; tmp2 = fncls__407d } else { tmp2 = fncls__407 }; arg_379 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :219:1
	if linked_376 == nil { return ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { return linked_376.(*A_arbace_core_reducers_reducer_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) } }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_core_reducers_drop_fn__153000125_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__413 *jrt.Class = A_arbace_core_reducers_drop_fn__153000125_A_fn_class; if fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_core_reducers_drop_fn__153000125_A_fn_class = fncls__413d; tmp2 = fncls__413d } else { tmp2 = fncls__413 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :215:1
func A_arbace_core_reducers_drop_fn__153000125_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000125_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000125_A{}; t.Ctor_O(p0); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { var root_408 any = A_arbace_core_reducers_A_const_53.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_core_reducers_drop_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = t.F_n; var arg_412 any = x__153000058__auto____1; if linked_409 == nil { return ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { return linked_409.(*A_arbace_core_reducers_drop_A).Invoke_O_O_O__O(root_408, arg_411, arg_412) } }




func A_arbace_core_reducers_drop_fn__153000127_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000127_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any; var root_380 any = A_arbace_core_reducers_A_const_49.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_382 lang.IFn; if
												linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = t.F_n; if linked_381 == nil { cnt__2 = ifn_382.Invoke_O__O(arg_383) } else { cnt__2 = linked_381.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_380, arg_383) }; var tmp1 any =
												A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(cnt__2, f1__1); var tmp2 *jrt.Class; var fncls__406 *jrt.Class = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class; if fncls__406 == nil { var fncls__406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class = fncls__406d; tmp2 = fncls__406d } else { tmp2 = fncls__406 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :222:1
func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var root_390 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = t.F_cnt; var arg_394 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_391 == nil { ifn_392.Invoke_O_O__O(arg_393, arg_394) } else { linked_391.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_390, arg_393, arg_394) }
	var tmp1 bool; var na_384 any; var root_385 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = t.F_cnt; if linked_386 == nil { na_384 = ifn_387.Invoke_O__O(arg_388) } else { na_384 = linked_386.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_385, arg_388) }; if jrt.Long_InstanceOf(na_384) { var n0_389 int64 = jrt.NN(jrt.Long_Cast(na_384)).LongValue__J(); tmp1 = n0_389 < 0 } else { if jrt.Double_InstanceOf(na_384) { var n0_389_2 float64 = jrt.NN(jrt.Double_Cast(na_384)).DoubleValue__D(); tmp1 = n0_389_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_384) } }; if tmp1 {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :225:1
			return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var root_401 any = A_arbace_core_reducers_A_const_50.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = t.F_cnt; var arg_405 any = A_arbace_core_reducers_A_const_51.GetRawRoot__O(); if linked_402 == nil { ifn_403.Invoke_O_O__O(arg_404, arg_405) } else { linked_402.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_401, arg_404, arg_405) }; var tmp1 bool; var na_395 any; var root_396 any = A_arbace_core_reducers_A_const_7.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = t.F_cnt; if linked_397 == nil { na_395 = ifn_398.Invoke_O__O(arg_399) } else { na_395 = linked_397.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_396, arg_399) }; if jrt.Long_InstanceOf(na_395) { var n0_400 int64 = jrt.NN(jrt.Long_Cast(na_395)).LongValue__J(); tmp1 = n0_400 < 0 } else { if jrt.Double_InstanceOf(na_395) { var n0_400_2 float64 = jrt.NN(jrt.Double_Cast(na_395)).DoubleValue__D(); tmp1 = n0_400_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_395) } }; if tmp1 { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }







func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New() *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Ctor() {}
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Invoke_O_O_O_O__O(self, cnt__1, left__2, right__3 any) any { return A_arbace_core_reducers_Cat_A_New_O_O_O(cnt__1, left__2, right__3) }
























func A_arbace_core_reducers_cat_A_New() *A_arbace_core_reducers_cat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_cat_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Ctor() {}
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O_O__O(self, left__0, right__1 any) any {













	if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(left__0))) { return right__1 } else { if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(right__1))) { return left__0 } else { if A_arbace_core_reducers_A_const_54 != nil { return A_arbace_core_reducers_Cat_A_New_O_O_O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(left__0)), int64(lang.RT_Count_O__I_NoInit(right__1)))).Ref(), left__0, right__1) } else { return nil } } } }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O__O(self, ctor__0 any) any {









	var tmp1 any = A_arbace_core_reducers_cat_fn__153000141_A_New_O(ctor__0); var tmp2 *jrt.Class; var fncls__419 *jrt.Class = A_arbace_core_reducers_cat_fn__153000141_A_fn_class; if fncls__419 == nil { var fncls__419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_core_reducers_cat_fn__153000141_A_fn_class = fncls__419d; tmp2 = fncls__419d } else { tmp2 = fncls__419 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O__O(self any) any { return jrt.ArrayList_New() }









func A_arbace_core_reducers_cat_fn__153000141_A_New_O(p0 any) *A_arbace_core_reducers_cat_fn__153000141_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_cat_fn__153000141_A{}; t.Ctor_O(p0); return t }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Ctor_O(c__ctor any) { t.F_ctor = c__ctor }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O_O_O__O(self, left__1, right__2 any) any {

	var root_414 any = A_arbace_core_reducers_A_const_55.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, A_arbace_core_reducers_cat_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = left__1; var arg_418 any = right__2; if linked_415 == nil { return ifn_416.Invoke_O_O__O(arg_417, arg_418) } else { return linked_415.(*A_arbace_core_reducers_cat_A).Invoke_O_O_O__O(root_414, arg_417, arg_418) } }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}







func A_arbace_core_reducers_append_BANG__A_New() *A_arbace_core_reducers_append_BANG__A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_append_BANG__A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Ctor() {}
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Invoke_O_O_O__O(self, acc__0, x__1 any) any { var G__153000144__3_ any = acc__0;



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Collection_Cast(G__153000144__3_).Add_O__Z(x__1)); return G__153000144__3_ }

func A_arbace_core_reducers_foldcat_A_New() *A_arbace_core_reducers_foldcat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldcat_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Ctor() {}
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Invoke_O_O__O(self, coll__0 any) any {



	var root_420 any = A_arbace_core_reducers_A_const_19.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, A_arbace_core_reducers_fold_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_core_reducers_A_const_55.GetRawRoot__O(); var arg_424 any = A_arbace_core_reducers_A_const_56.GetRawRoot__O(); var arg_425 any = coll__0; if linked_421 == nil { return ifn_422.Invoke_O_O_O__O(arg_423, arg_424, arg_425) } else { return linked_421.(*A_arbace_core_reducers_fold_A).Invoke_O_O_O_O__O(root_420, arg_423, arg_424, arg_425)
	} }
func A_arbace_core_reducers_monoid_A_New() *A_arbace_core_reducers_monoid_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_monoid_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Ctor() {}
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Invoke_O_O_O__O(self, op__0, ctor__1 any) any {





	var tmp1 any = A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(op__0, ctor__1); var tmp2 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_core_reducers_monoid_m__153000147_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_core_reducers_monoid_m__153000147_A_fn_class = fncls__426d; tmp2 = fncls__426d } else { tmp2 = fncls__426 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :293:1
func A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_monoid_m__153000147_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_monoid_m__153000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Ctor_O_O(c__op, c__ctor any) { t.F_op = c__op; t.F_ctor = c__ctor }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {

	return lang.IFn_Cast(t.F_op).Invoke_O_O__O(a__1, b__2) }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}


func A_arbace_core_reducers_foldvec_A_New() *A_arbace_core_reducers_foldvec_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Ctor() {}
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Invoke_O_O_O_O_O__O(self, v__0, n__1, combinef__2, reducef__3 any) any { if jrt.Long_InstanceOf(n__1) { return t.InvokeSpec_O_O_J_O_O_O__O(self, v__0, jrt.NN(jrt.Long_Cast(n__1)).LongValue__J(), n__1, combinef__2, reducef__3) } else {

	var tmp1 any; var root_427 any = A_arbace_core_reducers_A_const_57.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_429 lang.IFn
	if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = v__0; if linked_428 == nil { tmp1 = ifn_429.Invoke_O__O(arg_430) } else { tmp1 = linked_428.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_427, arg_430) }
//line :300:1
	if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(combinef__2).Invoke__O() } else {
//line :300:1
			var tmp2 bool; var na_431 int64 = int64(lang.RT_Count_O__I_NoInit(v__0))
			var na_432 any = n__1
			if jrt.Long_InstanceOf(na_432) { var n0_433 int64 = na_431; var n1_434 int64 = jrt.NN(jrt.Long_Cast(na_432)).LongValue__J(); tmp2 = n0_433 <= n1_434 } else { tmp2 = lang.Numbers_Lte_J_O__Z_NoInit(na_431, na_432) }
//line :300:1
			if tmp2 {

				var root_436 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_core_reducers_reduce_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = reducef__3; var arg_440 any = lang.IFn_Cast(combinef__2).Invoke__O(); var arg_441 any = v__0; if linked_437 == nil { return ifn_438.Invoke_O_O_O__O(arg_439, arg_440, arg_441) } else { return linked_437.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_436, arg_439, arg_440, arg_441) } } else {
//line :300:1
					if A_arbace_core_reducers_A_const_54 != nil { var split__5 int64 = lang.Numbers_Quotient_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(v__0)), 2); var v1__6 any; var root_442 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_444 lang.IFn




						if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = v__0; var arg_446 any = A_arbace_core_reducers_A_const_59; var arg_447 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); if linked_443 == nil { v1__6 = ifn_444.Invoke_O_O_O__O(arg_445, arg_446, arg_447) } else { v1__6 = linked_443.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_442, arg_445, arg_446, arg_447) }
//line :300:1
						var v2__7 any; var root_448 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_450 lang.IFn





						if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = v__0; var arg_452 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); var arg_453 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__0)).Ref(); if linked_449 == nil { v2__7 = ifn_450.Invoke_O_O_O__O(arg_451, arg_452, arg_453) } else { v2__7 = linked_449.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_448, arg_451, arg_452, arg_453) }
//line :300:1
						var fc__8 any; var tmp3 any = A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(combinef__2, n__1, reducef__3); var tmp4 *jrt.Class
						var fncls__462 /*line :300:1*/*jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class






						if fncls__462 == nil { var fncls__462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class = fncls__462d; tmp4 = fncls__462d } else { tmp4 = fncls__462 }; fc__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
						var root_463 any = A_arbace_core_reducers_A_const_61.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, A_arbace_core_reducers_fjinvoke_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var tmp5 any = A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(combinef__2, fc__8, v1__6, v2__7); var tmp6 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class; if fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class = fncls__479d; tmp6 = fncls__479d } else { tmp6 = fncls__479 }; arg_466 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_464 == nil { return ifn_465.Invoke_O__O(arg_466) } else { return linked_464.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(root_463, arg_466) } } else {
//line :300:1
							return nil } } } } }
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) InvokeSpec_O_O_J_O_O_O__O(self, v__0 any, n__1_l int64, n__1_b, combinef__2, reducef__3 any) any {

	var tmp1 any; var root_480 any = A_arbace_core_reducers_A_const_57.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_482 lang.IFn
	if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = v__0; if linked_481 == nil { tmp1 = ifn_482.Invoke_O__O(arg_483) } else { tmp1 = linked_481.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_480, arg_483) }
//line :300:1
	if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(combinef__2).Invoke__O() } else {
//line :300:1
			var tmp2 bool; var na_484 int64 = int64(lang.RT_Count_O__I_NoInit(v__0))
			var n0_485 int64 = na_484; var n1_486 int64 = n__1_l
			tmp2 = n0_485 <= n1_486
//line :300:1
			if tmp2 {

				var root_488 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, A_arbace_core_reducers_reduce_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = reducef__3; var arg_492 any = lang.IFn_Cast(combinef__2).Invoke__O(); var arg_493 any = v__0; if linked_489 == nil { return ifn_490.Invoke_O_O_O__O(arg_491, arg_492, arg_493) } else { return linked_489.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_488, arg_491, arg_492, arg_493) } } else {
//line :300:1
					if A_arbace_core_reducers_A_const_54 != nil { var split__5 int64 = lang.Numbers_Quotient_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(v__0)), 2); var v1__6 any; var root_494 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_496 lang.IFn




						if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = v__0; var arg_498 any = A_arbace_core_reducers_A_const_59; var arg_499 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); if linked_495 == nil { v1__6 = ifn_496.Invoke_O_O_O__O(arg_497, arg_498, arg_499) } else { v1__6 = linked_495.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_494, arg_497, arg_498, arg_499) }
//line :300:1
						var v2__7 any; var root_500 any = A_arbace_core_reducers_A_const_58.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_502 lang.IFn





						if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = v__0; var arg_504 any = jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(); var arg_505 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__0)).Ref(); if linked_501 == nil { v2__7 = ifn_502.Invoke_O_O_O__O(arg_503, arg_504, arg_505) } else { v2__7 = linked_501.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_500, arg_503, arg_504, arg_505) }
//line :300:1
						var fc__8 any; var tmp3 any






						if n__1_b == nil { n__1_b = jrt.Long_ValueOf_J__Long_NoInit(n__1_l).Ref(); tmp3 = n__1_b } else { tmp3 = n__1_b }; var tmp4 any = A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(combinef__2, tmp3, reducef__3); var tmp5 *jrt.Class; var fncls__506 *jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class; if fncls__506 == nil { var fncls__506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class = fncls__506d; tmp5 = fncls__506d } else { tmp5 = fncls__506 }; fc__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
						var root_507 any = A_arbace_core_reducers_A_const_61.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, A_arbace_core_reducers_fjinvoke_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any; var tmp6 any = A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(combinef__2, fc__8, v1__6, v2__7); var tmp7 *jrt.Class; var fncls__511 *jrt.Class = A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class; if fncls__511 == nil { var fncls__511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class = fncls__511d; tmp7 = fncls__511d } else { tmp7 = fncls__511 }; arg_510 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_508 == nil { return ifn_509.Invoke_O__O(arg_510) } else { return linked_508.(*A_arbace_core_reducers_fjinvoke_A).Invoke_O_O__O(root_507, arg_510) } } else {
//line :300:1
							return nil
						}
				}
		}
}


func A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_foldvec_fc__153000150_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Ctor_O_O_O(c__combinef, c__n, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Invoke_O_O__O(self, child__1 any) any { var tmp1 any = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(t.F_combinef, t.F_n, child__1, t.F_reducef); var tmp2 *jrt.Class; var fncls__461 *jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class; if fncls__461 == nil { var fncls__461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class = fncls__461d; tmp2 = fncls__461d } else { tmp2 = fncls__461 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :307:1
func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Ctor_O_O_O_O(c__combinef, c__n, c__child, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_child = c__child; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Invoke_O__O(self any) any { var root_454 any = A_arbace_core_reducers_A_const_60.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_454, A_arbace_core_reducers_foldvec_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = t.F_child; var arg_458 any = t.F_n; var arg_459 any = t.F_combinef; var arg_460 any = t.F_reducef; if linked_455 == nil { return ifn_456.Invoke_O_O_O_O__O(arg_457, arg_458, arg_459, arg_460) } else { if jrt.Long_InstanceOf(arg_458) { return linked_455.(*A_arbace_core_reducers_foldvec_A).InvokeSpec_O_O_J_O_O_O__O(root_454, arg_457, jrt.NN(jrt.Long_Cast(arg_458)).LongValue__J(), arg_458, arg_459, arg_460) } else { return linked_455.(*A_arbace_core_reducers_foldvec_A).Invoke_O_O_O_O_O__O(root_454, arg_457, arg_458, arg_459, arg_460) } } }
func A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fn__153000154_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fn__153000154_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Ctor_O_O_O_O(c__combinef, c__fc, c__v1, c__v2 any) { t.F_combinef = c__combinef; t.F_fc = c__fc; t.F_v1 = c__v1; t.F_v2 = c__v2 }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Invoke_O__O(self any) any { var f1__1 any = lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v1); var t2__2 any; var root_467 any = A_arbace_core_reducers_A_const_12.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, A_arbace_core_reducers_fjtask_A_fn_class); var ifn_469 lang.IFn; if

	linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v2); if linked_468 == nil { t2__2 = ifn_469.Invoke_O__O(arg_470) } else { t2__2 = linked_468.(*A_arbace_core_reducers_fjtask_A).Invoke_O_O__O(root_467, arg_470) }; var root_471 any =
	A_arbace_core_reducers_A_const_62.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_core_reducers_fjfork_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = t2__2; if linked_472 == nil { ifn_473.Invoke_O__O(arg_474) } else { linked_472.(*A_arbace_core_reducers_fjfork_A).Invoke_O_O__O(root_471, arg_474) }; var tmp1 lang.IFn =
	lang.IFn_Cast(t.F_combinef); var tmp2 any = lang.IFn_Cast(f1__1).Invoke__O(); var tmp3 any; var root_475 any = A_arbace_core_reducers_A_const_63.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_core_reducers_fjjoin_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = t2__2; if linked_476 == nil { tmp3 = ifn_477.Invoke_O__O(arg_478) } else { tmp3 = linked_476.(*A_arbace_core_reducers_fjjoin_A).Invoke_O_O__O(root_475, arg_478) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_New() *A_arbace_core_reducers_eval153000157_fn__153000158_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000157_fn__153000158_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {



	return lang.IFn_Cast(combinef__3).Invoke__O() }
//line :314:1
func A_arbace_core_reducers_eval153000161_fn__153000162_A_New() *A_arbace_core_reducers_eval153000161_fn__153000162_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000161_fn__153000162_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {









	var root_512 any = A_arbace_core_reducers_A_const_15.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_core_reducers_reduce_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = reducef__4; var arg_516 any = lang.IFn_Cast(combinef__3).Invoke__O(); var arg_517 any = coll__1; if linked_513 == nil { return ifn_514.Invoke_O_O_O__O(arg_515, arg_516, arg_517) } else { return linked_513.(*A_arbace_core_reducers_reduce_A).Invoke_O_O_O_O__O(root_512, arg_515, arg_516, arg_517) } }
//line :314:1
func A_arbace_core_reducers_eval153000165_fn__153000166_A_New() *A_arbace_core_reducers_eval153000165_fn__153000166_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000165_fn__153000166_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Invoke_O_O_O_O_O__O(self, v__1, n__2, combinef__3, reducef__4 any) any {














	var root_518 any = A_arbace_core_reducers_A_const_60.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_518, A_arbace_core_reducers_foldvec_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = v__1; var arg_522 any = n__2; var arg_523 any = combinef__3; var arg_524 any = reducef__4; if linked_519 == nil { return ifn_520.Invoke_O_O_O_O__O(arg_521, arg_522, arg_523, arg_524) } else { if jrt.Long_InstanceOf(arg_522) { return linked_519.(*A_arbace_core_reducers_foldvec_A).InvokeSpec_O_O_J_O_O_O__O(root_518, arg_521, jrt.NN(jrt.Long_Cast(arg_522)).LongValue__J(), arg_522, arg_523, arg_524) } else { return linked_519.(*A_arbace_core_reducers_foldvec_A).Invoke_O_O_O_O_O__O(root_518, arg_521, arg_522, arg_523, arg_524) } } }
//line :314:1
func A_arbace_core_reducers_eval153000169_fn__153000170_A_New() *A_arbace_core_reducers_eval153000169_fn__153000170_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000169_fn__153000170_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Invoke_O_O_O_O_O__O(self, m__1, n__2, combinef__3, reducef__4 any) any {



















	return jrt.NN(lang.PersistentHashMap_Cast(m__1)).Fold_J_IFn_IFn_IFn_IFn_IFn_IFn__O(lang.RT_LongCast_O__J_NoInit(n__2), lang.IFn_Cast(combinef__3), lang.IFn_Cast(reducef__4), lang.IFn_Cast(A_arbace_core_reducers_A_const_61.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_12.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_62.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_63.GetRawRoot__O()))
}
























































































































































type A_arbace_core_reducers_A struct{ jrt.Object }

var A_arbace_core_reducers_A_const_pool *jrt.RefArray

var A_arbace_core_reducers_A_const_0 *lang.Var

var A_arbace_core_reducers_A_const_1 any

var A_arbace_core_reducers_A_const_2 *lang.Var

var A_arbace_core_reducers_A_const_3 any

var A_arbace_core_reducers_A_const_4 *lang.Keyword

var A_arbace_core_reducers_A_const_5 any

var A_arbace_core_reducers_A_const_6 *lang.Var

var A_arbace_core_reducers_A_const_7 *lang.Var

var A_arbace_core_reducers_A_const_8 *lang.Var

var A_arbace_core_reducers_A_const_9 *lang.Var

var A_arbace_core_reducers_A_const_10 any

var A_arbace_core_reducers_A_const_11 *lang.Var

var A_arbace_core_reducers_A_const_12 *lang.Var

var A_arbace_core_reducers_A_const_13 *lang.Var

var A_arbace_core_reducers_A_const_14 *lang.Var

var A_arbace_core_reducers_A_const_15 *lang.Var

var A_arbace_core_reducers_A_const_16 *lang.Var

var A_arbace_core_reducers_A_const_17 *jrt.Class

var A_arbace_core_reducers_A_const_18 *lang.Var

var A_arbace_core_reducers_A_const_19 *lang.Var

var A_arbace_core_reducers_A_const_20 any

var A_arbace_core_reducers_A_const_21 *lang.Var

var A_arbace_core_reducers_A_const_22 *lang.Var

var A_arbace_core_reducers_A_const_23 *lang.Var

var A_arbace_core_reducers_A_const_24 *lang.Var

var A_arbace_core_reducers_A_const_25 *lang.Var

var A_arbace_core_reducers_A_const_26 any

var A_arbace_core_reducers_A_const_27 any

var A_arbace_core_reducers_A_const_28 *lang.Var

var A_arbace_core_reducers_A_const_29 *lang.Var

var A_arbace_core_reducers_A_const_30 any

var A_arbace_core_reducers_A_const_31 *lang.Var

var A_arbace_core_reducers_A_const_32 any

var A_arbace_core_reducers_A_const_33 *lang.Var

var A_arbace_core_reducers_A_const_34 *lang.Var

var A_arbace_core_reducers_A_const_35 *lang.Var

var A_arbace_core_reducers_A_const_36 *lang.Var

var A_arbace_core_reducers_A_const_37 *lang.Var

var A_arbace_core_reducers_A_const_38 *lang.Var

var A_arbace_core_reducers_A_const_39 *lang.Var

var A_arbace_core_reducers_A_const_40 *lang.Var

var A_arbace_core_reducers_A_const_41 *lang.Var

var A_arbace_core_reducers_A_const_42 *lang.Var

var A_arbace_core_reducers_A_const_43 *lang.Var

var A_arbace_core_reducers_A_const_44 *lang.Var

var A_arbace_core_reducers_A_const_45 *lang.Var

var A_arbace_core_reducers_A_const_46 *lang.Var

var A_arbace_core_reducers_A_const_47 *lang.Var

var A_arbace_core_reducers_A_const_48 *lang.Var

var A_arbace_core_reducers_A_const_49 *lang.Var

var A_arbace_core_reducers_A_const_50 *lang.Var

var A_arbace_core_reducers_A_const_51 *lang.Var

var A_arbace_core_reducers_A_const_52 *lang.Var

var A_arbace_core_reducers_A_const_53 *lang.Var

var A_arbace_core_reducers_A_const_54 *lang.Keyword

var A_arbace_core_reducers_A_const_55 *lang.Var

var A_arbace_core_reducers_A_const_56 *lang.Var

var A_arbace_core_reducers_A_const_57 *lang.Var

var A_arbace_core_reducers_A_const_58 *lang.Var

var A_arbace_core_reducers_A_const_59 any

var A_arbace_core_reducers_A_const_60 *lang.Var

var A_arbace_core_reducers_A_const_61 *lang.Var

var A_arbace_core_reducers_A_const_62 *lang.Var

var A_arbace_core_reducers_A_const_63 *lang.Var

var A_arbace_core_reducers_A_init jrt.ClassInit

func A_arbace_core_reducers_A_Init() { if !A_arbace_core_reducers_A_init.Done() { A_arbace_core_reducers_A_init.Run(A_arbace_core_reducers_A_clinit) } }

func A_arbace_core_reducers_A_clinit() { A_arbace_core_reducers_A_clinit_p0(); A_arbace_core_reducers_A_clinit_p1(); A_arbace_core_reducers_A_clinit_p2(); A_arbace_core_reducers_A_clinit_p3(); A_arbace_core_reducers_A_clinit_p4(); A_arbace_core_reducers_A_clinit_p5() }

func A_arbace_core_reducers_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_reducers_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 85); A_arbace_core_reducers_A_const_0 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[21]); A_arbace_core_reducers_A_const_1 = A_arbace_core_reducers_A_const_pool.A[22]; A_arbace_core_reducers_A_const_2 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[23]); A_arbace_core_reducers_A_const_3 = A_arbace_core_reducers_A_const_pool.A[24]; A_arbace_core_reducers_A_const_4 = lang.Keyword_Cast(A_arbace_core_reducers_A_const_pool.A[25]); A_arbace_core_reducers_A_const_5 = A_arbace_core_reducers_A_const_pool.A[26]; A_arbace_core_reducers_A_const_6 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[27]); A_arbace_core_reducers_A_const_7 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[28]); A_arbace_core_reducers_A_const_8 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[29]); A_arbace_core_reducers_A_const_9 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[30]); A_arbace_core_reducers_A_const_10 = A_arbace_core_reducers_A_const_pool.A[31]; A_arbace_core_reducers_A_const_11 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[32]) }

func A_arbace_core_reducers_A_clinit_p1() { A_arbace_core_reducers_A_const_12 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[33]); A_arbace_core_reducers_A_const_13 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[34]); A_arbace_core_reducers_A_const_14 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[35]); A_arbace_core_reducers_A_const_15 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[36]); A_arbace_core_reducers_A_const_16 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[37]); A_arbace_core_reducers_A_const_17 = jrt.Class_Cast(A_arbace_core_reducers_A_const_pool.A[38]); A_arbace_core_reducers_A_const_18 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[39]); A_arbace_core_reducers_A_const_19 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[40]); A_arbace_core_reducers_A_const_20 = A_arbace_core_reducers_A_const_pool.A[41]; A_arbace_core_reducers_A_const_21 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[42]); A_arbace_core_reducers_A_const_22 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[43]); A_arbace_core_reducers_A_const_23 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[44]) }

func A_arbace_core_reducers_A_clinit_p2() { A_arbace_core_reducers_A_const_24 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[45]); A_arbace_core_reducers_A_const_25 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[46]); A_arbace_core_reducers_A_const_26 = A_arbace_core_reducers_A_const_pool.A[47]; A_arbace_core_reducers_A_const_27 = A_arbace_core_reducers_A_const_pool.A[48]; A_arbace_core_reducers_A_const_28 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[49]); A_arbace_core_reducers_A_const_29 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[50]); A_arbace_core_reducers_A_const_30 = A_arbace_core_reducers_A_const_pool.A[51]; A_arbace_core_reducers_A_const_31 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[52]); A_arbace_core_reducers_A_const_32 = A_arbace_core_reducers_A_const_pool.A[53]; A_arbace_core_reducers_A_const_33 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[54]); A_arbace_core_reducers_A_const_34 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[55]); A_arbace_core_reducers_A_const_35 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[56]); A_arbace_core_reducers_A_const_36 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[57]) }

func A_arbace_core_reducers_A_clinit_p3() { A_arbace_core_reducers_A_const_37 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[58]); A_arbace_core_reducers_A_const_38 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[59]); A_arbace_core_reducers_A_const_39 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[60]); A_arbace_core_reducers_A_const_40 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[61]); A_arbace_core_reducers_A_const_41 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[62]); A_arbace_core_reducers_A_const_42 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[63]); A_arbace_core_reducers_A_const_43 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[64]); A_arbace_core_reducers_A_const_44 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[65]); A_arbace_core_reducers_A_const_45 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[66]); A_arbace_core_reducers_A_const_46 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[67]); A_arbace_core_reducers_A_const_47 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[68]); A_arbace_core_reducers_A_const_48 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[69]) }

func A_arbace_core_reducers_A_clinit_p4() { A_arbace_core_reducers_A_const_49 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[70]); A_arbace_core_reducers_A_const_50 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[71]); A_arbace_core_reducers_A_const_51 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[72]); A_arbace_core_reducers_A_const_52 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[73]); A_arbace_core_reducers_A_const_53 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[74]); A_arbace_core_reducers_A_const_54 = lang.Keyword_Cast(A_arbace_core_reducers_A_const_pool.A[75]); A_arbace_core_reducers_A_const_55 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[76]); A_arbace_core_reducers_A_const_56 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[77]); A_arbace_core_reducers_A_const_57 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[78]); A_arbace_core_reducers_A_const_58 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[79]); A_arbace_core_reducers_A_const_59 = A_arbace_core_reducers_A_const_pool.A[80]; A_arbace_core_reducers_A_const_60 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[81]) }

func A_arbace_core_reducers_A_clinit_p5() { A_arbace_core_reducers_A_const_61 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[82]); A_arbace_core_reducers_A_const_62 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[83]); A_arbace_core_reducers_A_const_63 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[84]) }

func A_arbace_core_reducers_A_New() *A_arbace_core_reducers_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_A) Ctor() {}

func (t *A_arbace_core_reducers_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_A_class }

func (t *A_arbace_core_reducers_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_A); return ok }

func A_arbace_core_reducers_A_Cast(x any) *A_arbace_core_reducers_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_A_class)) }; return v }



type A_arbace_core_reducers_append_BANG__A struct{ j2g_header uint64 }

var A_arbace_core_reducers_append_BANG__A_fn_class *jrt.Class



type A_arbace_core_reducers_cat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_cat_A_fn_class *jrt.Class



type A_arbace_core_reducers_cat_fn__153000141_A struct{ j2g_header uint64; F_ctor any }

var A_arbace_core_reducers_cat_fn__153000141_A_fn_class *jrt.Class



type A_arbace_core_reducers_defcurried_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_defcurried_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_curried_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_do_curried_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_rfn_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_do_rfn_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_rfn_fn__153000066_A struct{ j2g_header uint64; F_k any }

var A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_drop_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000125_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_drop_fn__153000125_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000127_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_drop_fn__153000127_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A struct{ j2g_header uint64; F_cnt, F_f1 any }

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000004_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000004_A_New() *A_arbace_core_reducers_eval153000004_A { t := &A_arbace_core_reducers_eval153000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000004_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000004_A_class }

func (t *A_arbace_core_reducers_eval153000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000004_A); return ok }

func A_arbace_core_reducers_eval153000004_A_Cast(x any) *A_arbace_core_reducers_eval153000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000004_A_class)) }; return v }



type A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000008_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000008_A_New() *A_arbace_core_reducers_eval153000008_A { t := &A_arbace_core_reducers_eval153000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000008_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000008_A_class }

func (t *A_arbace_core_reducers_eval153000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000008_A); return ok }

func A_arbace_core_reducers_eval153000008_A_Cast(x any) *A_arbace_core_reducers_eval153000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000008_A_class)) }; return v }



type A_arbace_core_reducers_eval153000008_fn__153000009_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000031_A_New() *A_arbace_core_reducers_eval153000031_A { t := &A_arbace_core_reducers_eval153000031_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000031_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000031_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000031_A_class }

func (t *A_arbace_core_reducers_eval153000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000031_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000031_A); return ok }

func A_arbace_core_reducers_eval153000031_A_Cast(x any) *A_arbace_core_reducers_eval153000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000031_A_class)) }; return v }



type A_arbace_core_reducers_eval153000031_fn__153000032_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A struct{ j2g_header uint64; F_G__153000024 any }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000132_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000132_A_New() *A_arbace_core_reducers_eval153000132_A { t := &A_arbace_core_reducers_eval153000132_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000132_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000132_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000132_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000132_A_class }

func (t *A_arbace_core_reducers_eval153000132_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000132_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000132_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000132_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000132_A); return ok }

func A_arbace_core_reducers_eval153000132_A_Cast(x any) *A_arbace_core_reducers_eval153000132_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000132_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000132_A_class)) }; return v }



type A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000157_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000157_A_New() *A_arbace_core_reducers_eval153000157_A { t := &A_arbace_core_reducers_eval153000157_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000157_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000157_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000157_A_class }

func (t *A_arbace_core_reducers_eval153000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000157_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000157_A); return ok }

func A_arbace_core_reducers_eval153000157_A_Cast(x any) *A_arbace_core_reducers_eval153000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000157_A_class)) }; return v }



type A_arbace_core_reducers_eval153000157_fn__153000158_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000161_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000161_A_New() *A_arbace_core_reducers_eval153000161_A { t := &A_arbace_core_reducers_eval153000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000161_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000161_A_class }

func (t *A_arbace_core_reducers_eval153000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000161_A); return ok }

func A_arbace_core_reducers_eval153000161_A_Cast(x any) *A_arbace_core_reducers_eval153000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000161_A_class)) }; return v }



type A_arbace_core_reducers_eval153000161_fn__153000162_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000165_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000165_A_New() *A_arbace_core_reducers_eval153000165_A { t := &A_arbace_core_reducers_eval153000165_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000165_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000165_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000165_A_class }

func (t *A_arbace_core_reducers_eval153000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000165_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000165_A); return ok }

func A_arbace_core_reducers_eval153000165_A_Cast(x any) *A_arbace_core_reducers_eval153000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000165_A_class)) }; return v }



type A_arbace_core_reducers_eval153000165_fn__153000166_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000169_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000169_A_New() *A_arbace_core_reducers_eval153000169_A { t := &A_arbace_core_reducers_eval153000169_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000169_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000169_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000169_A_class }

func (t *A_arbace_core_reducers_eval153000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000169_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000169_A); return ok }

func A_arbace_core_reducers_eval153000169_A_Cast(x any) *A_arbace_core_reducers_eval153000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000169_A_class)) }; return v }



type A_arbace_core_reducers_eval153000169_fn__153000170_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_filter_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000094_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_filter_fn__153000094_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000096_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_filter_fn__153000096_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A struct{ j2g_header uint64; F_pred, F_f1 any }

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjfork_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjfork_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjinvoke_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjinvoke_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjjoin_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjjoin_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjtask_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjtask_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000104_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_fn__153000104_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000106_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_fn__153000106_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A struct{ j2g_header uint64; F_f1 any }

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class *jrt.Class



type A_arbace_core_reducers_fn__153000016_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fn__153000016_A_fn_class *jrt.Class



type A_arbace_core_reducers_fold_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fold_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldcat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_foldcat_A_fn_class *jrt.Class



type A_arbace_core_reducers_folder_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_folder_A_fn_class *jrt.Class



type A_arbace_core_reducers_folder_reify__153000055_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IObj() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_folder_reify__153000055_A_class }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_folder_reify__153000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); return ok }

func A_arbace_core_reducers_folder_reify__153000055_A_Cast(x any) *A_arbace_core_reducers_folder_reify__153000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_folder_reify__153000055_A_class)) }; return v }



type A_arbace_core_reducers_foldvec_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_foldvec_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fc__153000150_A struct{ j2g_header uint64; F_combinef, F_n, F_reducef any }

var A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A struct{ j2g_header uint64; F_combinef, F_n, F_child, F_reducef any }

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fn__153000154_A struct{ j2g_header uint64; F_combinef, F_fc, F_v1, F_v2 any }

var A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_map_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000078_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_map_fn__153000078_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000080_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_map_fn__153000080_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000080_fn__153000081_A struct{ j2g_header uint64; F_f, F_f1 any }

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_mapcat_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000085_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A struct{ j2g_header uint64; F_f1 any }

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A struct{ j2g_header uint64; F_f, F_f1 any }

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class *jrt.Class



type A_arbace_core_reducers_monoid_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_monoid_A_fn_class *jrt.Class



type A_arbace_core_reducers_monoid_m__153000147_A struct{ j2g_header uint64; F_op, F_ctor any }

var A_arbace_core_reducers_monoid_m__153000147_A_fn_class *jrt.Class



type A_arbace_core_reducers_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_reduce_A_fn_class *jrt.Class



type A_arbace_core_reducers_reducer_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_reducer_A_fn_class *jrt.Class



type A_arbace_core_reducers_reducer_reify__153000052_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IObj() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_reducer_reify__153000052_A_class }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_reducer_reify__153000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); return ok }

func A_arbace_core_reducers_reducer_reify__153000052_A_Cast(x any) *A_arbace_core_reducers_reducer_reify__153000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_reducer_reify__153000052_A_class)) }; return v }



type A_arbace_core_reducers_remove_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_remove_A_fn_class *jrt.Class



type A_arbace_core_reducers_remove_fn__153000101_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_remove_fn__153000101_A_fn_class *jrt.Class



type A_arbace_core_reducers_rfn_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_rfn_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_take_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000118_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_take_fn__153000118_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000120_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_take_fn__153000120_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000120_fn__153000121_A struct{ j2g_header uint64; F_cnt, F_f1 any }

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_take_while_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000111_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_take_while_fn__153000111_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000113_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_take_while_fn__153000113_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A struct{ j2g_header uint64; F_pred, F_f1 any }

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class *jrt.Class
