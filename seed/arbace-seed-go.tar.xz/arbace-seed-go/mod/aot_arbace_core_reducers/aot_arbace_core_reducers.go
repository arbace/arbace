//line aot_arbace_core_reducers.ae:1
package aot_arbace_core_reducers

import (
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_New() *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_core_reducers_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_reducers_A_const_2, A_arbace_core_reducers_A_const_3, A_arbace_core_reducers_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_core_reducers_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_reducers_eval153000008_fn__153000009_A_New() *A_arbace_core_reducers_eval153000008_fn__153000009_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000008_fn__153000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_reducers_eval153000008_fn__153000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_10), A_arbace_core_reducers_A_const_8.GetRawRoot__O(), A_arbace_core_reducers_A_const_9) }












func A_arbace_core_reducers_fn__153000016_A_New() *A_arbace_core_reducers_fn__153000016_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fn__153000016_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Ctor() {}
//line :22:1
func (t *A_arbace_core_reducers_fn__153000016_A) Invoke_O__O(self any) any { return jrt.ForkJoinPool_New() }

func A_arbace_core_reducers_fjtask_A_New() *A_arbace_core_reducers_fjtask_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjtask_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_reducers_fjtask_A) Invoke_O_O__O(self, f__0 any) any {
	return jrt.ForkJoinTask_Adapt_Callable__ForkJoinTask(jrt.Callable_Cast(f__0))
}
func A_arbace_core_reducers_fjinvoke_A_New() *A_arbace_core_reducers_fjinvoke_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjinvoke_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Ctor() {}
//line :27:1
func (t *A_arbace_core_reducers_fjinvoke_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.ForkJoinTask_InForkJoinPool__Z() {
		return lang.IFn_Cast(f__0).Invoke__O() } else {
			return jrt.NN(jrt.As[*jrt.ForkJoinPool](lang.IFn_Cast(A_arbace_core_reducers_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_12.GetRawRoot__O()))).Invoke_ForkJoinTask__O(jrt.ForkJoinTask_Cast(lang.IFn_Cast(A_arbace_core_reducers_A_const_11.GetRawRoot__O()).Invoke_O__O(f__0)))
		} }
func A_arbace_core_reducers_fjfork_A_New() *A_arbace_core_reducers_fjfork_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjfork_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Ctor() {}
//line :32:1
func (t *A_arbace_core_reducers_fjfork_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Fork__ForkJoinTask() }

func A_arbace_core_reducers_fjjoin_A_New() *A_arbace_core_reducers_fjjoin_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fjjoin_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Ctor() {}
//line :34:1
func (t *A_arbace_core_reducers_fjjoin_A) Invoke_O_O__O(self, task__0 any) any { return jrt.ForkJoinTask_Cast(task__0).Join__O() }



func A_arbace_core_reducers_reduce_A_New() *A_arbace_core_reducers_reduce_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_reduce_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Ctor() {}
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O_O__O(self, f__0, init__1, coll__2 any) any {





	if jrt.Map_InstanceOf(coll__2) {
		var target_1 any = coll__2; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_InstanceOf(target_1); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_Cast(target_1).Kv_reduce_O_O__O(f__0, init__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(target_1, f__0, init__1) } } else {
			var target_2 any = coll__2; var tmp3 bool; var tmp4 bool; tmp4 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_2); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_2) }; tmp3 = tmp4; if tmp3 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_2).Coll_reduce_O_O__O(f__0, init__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(target_2, f__0, init__1) } } }
//line :38:1
func (t *A_arbace_core_reducers_reduce_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	return lang.IFn_Cast(A_arbace_core_reducers_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(f__0, lang.IFn_Cast(f__0).Invoke__O(), coll__1)
}




func A_arbace_core_reducers_eval153000031_fn__153000032_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__153000024__2_ any; var tmp1 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New(); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; G__153000024__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(G__153000024__2_); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_New_O(p0 any) *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Ctor_O(c__G__153000024 any) { t.F_G__153000024 = c__G__153000024 }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4 any) any { var cache__231000236__auto____5 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____6 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____5)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__153000039__1)); if jrt.J2g_Truth(f__231000237__auto____6) { return lang.IFn_Cast(f__231000237__auto____6).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_reducers_A_const_16.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__153000039__1, A_arbace_core_reducers_A_const_17, t.F_G__153000024)).Invoke_O_O_O_O__O(gf__coll__153000039__1, gf__n__153000040__2, gf__combinef__153000041__3, gf__reducef__153000042__4) } }
//line :48:1
func A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_New() *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A) Invoke_O_O_O_O_O__O(self, gf__coll__153000033__1, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4 any) any { var target_3 any = gf__coll__153000033__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_3 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_3) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_3, Lit_8, jrt.RefArrayOf(jrt.Object_class, gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4)) } else { return A_arbace_core_reducers_CollFold_A_Cast(target_3).Coll_fold_O_O_O__O(gf__n__153000034__2, gf__combinef__153000035__3, gf__reducef__153000036__4) } }


func A_arbace_core_reducers_fold_A_New() *A_arbace_core_reducers_fold_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_fold_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O_O__O(self, n__0, combinef__1, reducef__2, coll__3 any) any {













	var target_6 any = coll__3; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_6); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_6) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_6).Coll_fold_O_O_O__O(n__0, combinef__1, reducef__2) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_18.GetRawRoot__O()).Invoke_O_O_O_O__O(target_6, n__0, combinef__1, reducef__2) } }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O_O__O(self, combinef__0, reducef__1, coll__2 any) any {











	return lang.IFn_Cast(A_arbace_core_reducers_A_const_19.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_core_reducers_A_const_20, combinef__0, reducef__1, coll__2) }
//line :51:1
func (t *A_arbace_core_reducers_fold_A) Invoke_O_O_O__O(self, reducef__0, coll__1 any) any {










	return lang.IFn_Cast(A_arbace_core_reducers_A_const_19.GetRawRoot__O()).Invoke_O_O_O__O(reducef__0, reducef__0, coll__1)
}



func A_arbace_core_reducers_reducer_A_New() *A_arbace_core_reducers_reducer_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_reducer_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_reducers_reducer_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :74:1
func A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_reducer_reify__153000052_A { t := &A_arbace_core_reducers_reducer_reify__153000052_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_7 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_7); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_7) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_7).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_7, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Coll_reduce_O__O(f1__1 any) any {


	var target_8 any = t; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_8); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_8) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_8).Coll_reduce_O_O__O(f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_8, f1__1, lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :74:1
func (t *A_arbace_core_reducers_reducer_reify__153000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_reducer_reify__153000052_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }






func A_arbace_core_reducers_folder_A_New() *A_arbace_core_reducers_folder_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_folder_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Ctor() {}
//line :81:1
func (t *A_arbace_core_reducers_folder_A) Invoke_O_O_O__O(self, coll__0, xf__1 any) any {






	return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(nil, coll__0, xf__1) }
//line :88:1
func A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_core_reducers_folder_reify__153000055_A { t := &A_arbace_core_reducers_folder_reify__153000055_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__coll, c__xf any) { t.F___meta = meta__; t.F_coll = c__coll; t.F_xf = c__xf }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_fold_O_O_O__O(n__1, combinef__2, reducef__3 any) any {








	var target_9 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_core_reducers_CollFold_A_InstanceOf(target_9); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_9) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_reducers_CollFold_A_Cast(target_9).Coll_fold_O_O_O__O(n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_18; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(target_9, n__1, combinef__2, lang.IFn_Cast(t.F_xf).Invoke_O__O(reducef__3)) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O_O__O(f1__1, init__2 any) any {




	var target_10 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_10); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_10) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_10).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_10, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), init__2) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Coll_reduce_O__O(f1__1 any) any {


	var target_11 any = t.F_coll; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_11); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_11) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_11).Coll_reduce_O_O__O(lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } else { var tmp3 *lang.Var; A_arbace_core_reducers_A_Init(); tmp3 = A_arbace_core_reducers_A_const_14; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_11, lang.IFn_Cast(t.F_xf).Invoke_O__O(f1__1), lang.IFn_Cast(f1__1).Invoke__O()) } }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :88:1
func (t *A_arbace_core_reducers_folder_reify__153000055_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_core_reducers_folder_reify__153000055_A_New_IPersistentMap_O_O(m, t.F_coll, t.F_xf) }










func A_arbace_core_reducers_do_curried_A_New() *A_arbace_core_reducers_do_curried_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_curried_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Ctor() {}
//line :99:1
func (t *A_arbace_core_reducers_do_curried_A) Invoke_O_O_O_O_O_O__O(self, name__0, doc__1, meta__2, args__3, body__4 any) any { var cargs__6 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_23.GetRawRoot__O()).Invoke_O__O(args__3)); return /*line :101:1*/ lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_26), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(name__0), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(doc__1), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(meta__2), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(cargs__6), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_27), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_reducers_A_const_29.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_30))))), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(name__0), cargs__6, lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_30)))))))))), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(args__3), body__4))))) }




func A_arbace_core_reducers_defcurried_A_New() *A_arbace_core_reducers_defcurried_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_defcurried_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) Ctor() {}
//line :106:1
func (t *A_arbace_core_reducers_defcurried_A) DoInvoke_O_O_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, doc__3, meta__4, args__5, body__6 any) any {



	return lang.IFn_Cast(A_arbace_core_reducers_A_const_31.GetRawRoot__O()).Invoke_O_O_O_O_O__O(name__2, doc__3, meta__4, args__5, body__6)
}
func A_arbace_core_reducers_do_rfn_A_New() *A_arbace_core_reducers_do_rfn_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_rfn_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Ctor() {}
//line :112:1
func (t *A_arbace_core_reducers_do_rfn_A) Invoke_O_O_O_O__O(self, f1__0, k__1, fkv__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_core_reducers_A_const_32); var tmp4 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_reducers_A_const_29.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(f1__0))))))); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_33.GetRawRoot__O()); var tmp7 any = A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(k__1); var tmp8 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class; if


	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class = fncls__12d; tmp8 = fncls__12d } else { tmp8 = fncls__12 }; return /*line :112:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), fkv__2)), lang.IFn_Cast(A_arbace_core_reducers_A_const_25.GetRawRoot__O()).Invoke_O__O(fkv__2))) }


func A_arbace_core_reducers_do_rfn_fn__153000066_A_New_O(p0 any) *A_arbace_core_reducers_do_rfn_fn__153000066_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_do_rfn_fn__153000066_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :115:1
func (t *A_arbace_core_reducers_do_rfn_fn__153000066_A) Invoke_O_O__O(self, p1__153000065_SHARP___1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_reducers_A_const_34.GetRawRoot__O()).Invoke_O__O(p1__153000065_SHARP___1)) {
		var tmp1 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_reducers_A_const_35.GetRawRoot__O()).Invoke_O__O(p1__153000065_SHARP___1)) { tmp1 = A_arbace_core_reducers_A_const_21.GetRawRoot__O() } else { tmp1 = A_arbace_core_reducers_A_const_36.GetRawRoot__O() }; return lang.IFn_Cast(tmp1).Invoke_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_37.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, t.F_k)), p1__153000065_SHARP___1)) } else {
//line :116:1
			return p1__153000065_SHARP___1
		}
}




func A_arbace_core_reducers_rfn_A_New() *A_arbace_core_reducers_rfn_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_rfn_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Ctor() {}
//line :123:1
func (t *A_arbace_core_reducers_rfn_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, p__153000069__2, fkv__3 any) any { var vec__153000070__5 any = p__153000069__2; var f1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__153000070__5, lang.RT_IntCast_J__I_NoInit(0), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__153000070__5, lang.RT_IntCast_J__I_NoInit(1), nil); return /*line :126:1*/ lang.IFn_Cast(A_arbace_core_reducers_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(f1__6, k__7, fkv__3) }

func A_arbace_core_reducers_map_A_New() *A_arbace_core_reducers_map_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Ctor() {}
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_map_fn__153000080_A_New_O(f__0); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_core_reducers_map_fn__153000080_A_fn_class
	if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_core_reducers_map_fn__153000080_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }
//line :132:1
	return tmp1.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :128:1
func (t *A_arbace_core_reducers_map_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any = A_arbace_core_reducers_map_fn__153000078_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_core_reducers_map_fn__153000078_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_core_reducers_map_fn__153000078_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :128:1
func A_arbace_core_reducers_map_fn__153000078_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000078_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000078_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :128:1
func (t *A_arbace_core_reducers_map_fn__153000078_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_40.GetRawRoot__O()).Invoke_O_O__O(t.F_f, x__153000058__auto____1) }




func A_arbace_core_reducers_map_fn__153000080_A_New_O(p0 any) *A_arbace_core_reducers_map_fn__153000080_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_A{}; t.Ctor_O(p0); return t }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :133:1
func (t *A_arbace_core_reducers_map_fn__153000080_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(t.F_f, f1__1); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :134:1
func A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_map_fn__153000080_fn__153000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); return tmp1.Invoke_O_O__O(ret__1, lang.IFn_Cast(t.F_f).Invoke_O__O(v__2)) }
//line :134:1
func (t *A_arbace_core_reducers_map_fn__153000080_fn__153000081_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_mapcat_A_New() *A_arbace_core_reducers_mapcat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Ctor() {}
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O_O__O(self, f__0, coll__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(f__0); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class
	if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }
//line :143:1
	return tmp1.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any = A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :138:1
func A_arbace_core_reducers_mapcat_fn__153000085_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000085_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000085_A{}; t.Ctor_O(p0); return t }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :138:1
func (t *A_arbace_core_reducers_mapcat_fn__153000085_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_42.GetRawRoot__O()).Invoke_O_O__O(t.F_f, x__153000058__auto____1) }





func A_arbace_core_reducers_mapcat_fn__153000087_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :144:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_A) Invoke_O_O__O(self, f1__1 any) any { var f1__2 any; var tmp1 any = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(f1__1); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class; if
												fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; f1__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any =




	A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(t.F_f, f1__2); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }
//line :145:1
func A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_New_O(p0 any) *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any { var x__4 any = lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3); if



	lang.RT_IsReduced_O__Z_NoInit(x__4) { return lang.IFn_Cast(A_arbace_core_reducers_A_const_41.GetRawRoot__O()).Invoke_O__O(x__4) } else { return x__4 } }
//line :145:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var x__3 any = lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2); if

	lang.RT_IsReduced_O__Z_NoInit(x__3) { return lang.IFn_Cast(A_arbace_core_reducers_A_const_41.GetRawRoot__O()).Invoke_O__O(x__3) } else { return x__3 } }


func A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Ctor_O_O(c__f, c__f1 any) { t.F_f = c__f; t.F_f1 = c__f1 }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_15.GetRawRoot__O()); var tmp2 any = t.F_f1; return tmp1.Invoke_O_O_O__O(tmp2, ret__1, lang.IFn_Cast(t.F_f).Invoke_O_O__O(k__2, v__3)) }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_15.GetRawRoot__O()); var tmp2 any = t.F_f1; return tmp1.Invoke_O_O_O__O(tmp2, ret__1, lang.IFn_Cast(t.F_f).Invoke_O__O(v__2)) }
//line :150:1
func (t *A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }



func A_arbace_core_reducers_filter_A_New() *A_arbace_core_reducers_filter_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Ctor() {}
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_filter_fn__153000096_A_New_O(pred__0); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_core_reducers_filter_fn__153000096_A_fn_class
	if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_core_reducers_filter_fn__153000096_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }
//line :159:1
	return tmp1.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :154:1
func (t *A_arbace_core_reducers_filter_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_filter_fn__153000094_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_core_reducers_filter_fn__153000094_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_core_reducers_filter_fn__153000094_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :154:1
func A_arbace_core_reducers_filter_fn__153000094_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000094_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000094_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :154:1
func (t *A_arbace_core_reducers_filter_fn__153000094_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_43.GetRawRoot__O()).Invoke_O_O__O(t.F_pred, x__153000058__auto____1) }





func A_arbace_core_reducers_filter_fn__153000096_A_New_O(p0 any) *A_arbace_core_reducers_filter_fn__153000096_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :160:1
func (t *A_arbace_core_reducers_filter_fn__153000096_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(t.F_pred, f1__1); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :161:1
func A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :163:1
			return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :161:1
func (t *A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_remove_A_New() *A_arbace_core_reducers_remove_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_remove_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Ctor() {}
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {




	return lang.IFn_Cast(A_arbace_core_reducers_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_reducers_A_const_44.GetRawRoot__O()).Invoke_O__O(pred__0), coll__1) }
//line :167:1
func (t *A_arbace_core_reducers_remove_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_remove_fn__153000101_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_core_reducers_remove_fn__153000101_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_core_reducers_remove_fn__153000101_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :167:1
func A_arbace_core_reducers_remove_fn__153000101_A_New_O(p0 any) *A_arbace_core_reducers_remove_fn__153000101_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_remove_fn__153000101_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :167:1
func (t *A_arbace_core_reducers_remove_fn__153000101_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_45.GetRawRoot__O()).Invoke_O_O__O(t.F_pred, x__153000058__auto____1) }






func A_arbace_core_reducers_flatten_A_New() *A_arbace_core_reducers_flatten_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O_O__O(self, coll__0 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_flatten_fn__153000106_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000106_A_fn_class
	if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_core_reducers_flatten_fn__153000106_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }
//line :180:1
	return tmp1.Invoke_O_O__O(coll__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :174:1
func (t *A_arbace_core_reducers_flatten_A) Invoke_O__O(self any) any { var tmp1 any = A_arbace_core_reducers_flatten_fn__153000104_A_New(); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000104_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_core_reducers_flatten_fn__153000104_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :174:1
func A_arbace_core_reducers_flatten_fn__153000104_A_New() *A_arbace_core_reducers_flatten_fn__153000104_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000104_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Ctor() {}
//line :174:1
func (t *A_arbace_core_reducers_flatten_fn__153000104_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_46.GetRawRoot__O()).Invoke_O__O(x__153000058__auto____1) }






func A_arbace_core_reducers_flatten_fn__153000106_A_New() *A_arbace_core_reducers_flatten_fn__153000106_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Ctor() {}
//line :181:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(f1__1); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :182:1
func A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_New_O(p0 any) *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A{}; t.Ctor_O(p0); return t }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Ctor_O(c__f1 any) { t.F_f1 = c__f1 }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_reducers_A_const_34.GetRawRoot__O()).Invoke_O__O(v__2)) {
		var target_24 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_46.GetRawRoot__O()).Invoke_O__O(v__2); var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_InstanceOf(target_24); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_24) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Cast(target_24).Coll_reduce_O_O__O(t.F_f1, ret__1) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(target_24, t.F_f1, ret__1) } } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :182:1
func (t *A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_f1).Invoke__O()
}




func A_arbace_core_reducers_take_while_A_New() *A_arbace_core_reducers_take_while_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Ctor() {}
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O_O__O(self, pred__0, coll__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_47.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_take_while_fn__153000113_A_New_O(pred__0); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000113_A_fn_class
	if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_core_reducers_take_while_fn__153000113_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }
//line :193:1
	return tmp1.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :189:1
func (t *A_arbace_core_reducers_take_while_A) Invoke_O_O__O(self, pred__0 any) any { var tmp1 any = A_arbace_core_reducers_take_while_fn__153000111_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000111_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_core_reducers_take_while_fn__153000111_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :189:1
func A_arbace_core_reducers_take_while_fn__153000111_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000111_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000111_A{}; t.Ctor_O(p0); return t }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :189:1
func (t *A_arbace_core_reducers_take_while_fn__153000111_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_48.GetRawRoot__O()).Invoke_O_O__O(t.F_pred, x__153000058__auto____1) }




func A_arbace_core_reducers_take_while_fn__153000113_A_New_O(p0 any) *A_arbace_core_reducers_take_while_fn__153000113_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :194:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_A) Invoke_O_O__O(self, f1__1 any) any {
	var tmp1 any = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(t.F_pred, f1__1); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :195:1
func A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Ctor_O_O(c__pred, c__f1 any) { t.F_pred = c__pred; t.F_f1 = c__f1 }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O_O__O(k__2, v__3)) {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
			return lang.IFn_Cast(A_arbace_core_reducers_A_const_41.GetRawRoot__O()).Invoke_O__O(ret__1) } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(v__2)) { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return lang.IFn_Cast(A_arbace_core_reducers_A_const_41.GetRawRoot__O()).Invoke_O__O(ret__1) } }
//line :195:1
func (t *A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }





func A_arbace_core_reducers_take_A_New() *A_arbace_core_reducers_take_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Ctor() {}
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_47.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_take_fn__153000120_A_New_O(n__0); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_core_reducers_take_fn__153000120_A_fn_class
	if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_core_reducers_take_fn__153000120_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }
//line :205:1
	return tmp1.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :201:1
func (t *A_arbace_core_reducers_take_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_core_reducers_take_fn__153000118_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_core_reducers_take_fn__153000118_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_core_reducers_take_fn__153000118_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :201:1
func A_arbace_core_reducers_take_fn__153000118_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000118_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000118_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :201:1
func (t *A_arbace_core_reducers_take_fn__153000118_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_52.GetRawRoot__O()).Invoke_O_O__O(t.F_n, x__153000058__auto____1) }




func A_arbace_core_reducers_take_fn__153000120_A_New_O(p0 any) *A_arbace_core_reducers_take_fn__153000120_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_A{}; t.Ctor_O(p0); return t }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :206:1
func (t *A_arbace_core_reducers_take_fn__153000120_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_49.GetRawRoot__O()).Invoke_O__O(t.F_n); var tmp1 any = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(cnt__2, f1__1); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class; if

	fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :208:1
func A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_take_fn__153000120_fn__153000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_50.GetRawRoot__O()); var tmp2 any = t.F_cnt; tmp1.Invoke_O_O__O(tmp2, A_arbace_core_reducers_A_const_51.GetRawRoot__O())
	var tmp3 bool; var na_31 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_cnt); if jrt.Long_InstanceOf(na_31) { var n0_32 int64 = jrt.NN(jrt.Long_Cast(na_31)).LongValue__J(); tmp3 = n0_32 < 0 } else { if jrt.Double_InstanceOf(na_31) { var n0_32_2 float64 = jrt.NN(jrt.Double_Cast(na_31)).DoubleValue__D(); tmp3 = n0_32_2 < 0.0 } else { tmp3 = lang.Numbers_IsNeg_O__Z_NoInit(na_31) } }; if tmp3 {
		return lang.IFn_Cast(A_arbace_core_reducers_A_const_41.GetRawRoot__O()).Invoke_O__O(ret__1) } else {
			return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_50.GetRawRoot__O()); var tmp2 any = t.F_cnt; tmp1.Invoke_O_O__O(tmp2, A_arbace_core_reducers_A_const_51.GetRawRoot__O()); var tmp3 bool; var na_33 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_cnt); if jrt.Long_InstanceOf(na_33) { var n0_34 int64 = jrt.NN(jrt.Long_Cast(na_33)).LongValue__J(); tmp3 = n0_34 < 0 } else { if jrt.Double_InstanceOf(na_33) { var n0_34_2 float64 = jrt.NN(jrt.Double_Cast(na_33)).DoubleValue__D(); tmp3 = n0_34_2 < 0.0 } else { tmp3 = lang.Numbers_IsNeg_O__Z_NoInit(na_33) } }; if tmp3 { return lang.IFn_Cast(A_arbace_core_reducers_A_const_41.GetRawRoot__O()).Invoke_O__O(ret__1) } else { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } }
//line :208:1
func (t *A_arbace_core_reducers_take_fn__153000120_fn__153000121_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }






func A_arbace_core_reducers_drop_A_New() *A_arbace_core_reducers_drop_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Ctor() {}
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O_O__O(self, n__0, coll__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_47.GetRawRoot__O()); var tmp2 any = A_arbace_core_reducers_drop_fn__153000127_A_New_O(n__0); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_core_reducers_drop_fn__153000127_A_fn_class
	if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_core_reducers_drop_fn__153000127_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }
//line :219:1
	return tmp1.Invoke_O_O__O(coll__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :215:1
func (t *A_arbace_core_reducers_drop_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any = A_arbace_core_reducers_drop_fn__153000125_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_core_reducers_drop_fn__153000125_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_core_reducers_drop_fn__153000125_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :215:1
func A_arbace_core_reducers_drop_fn__153000125_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000125_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000125_A{}; t.Ctor_O(p0); return t }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :215:1
func (t *A_arbace_core_reducers_drop_fn__153000125_A) Invoke_O_O__O(self, x__153000058__auto____1 any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_53.GetRawRoot__O()).Invoke_O_O__O(t.F_n, x__153000058__auto____1) }




func A_arbace_core_reducers_drop_fn__153000127_A_New_O(p0 any) *A_arbace_core_reducers_drop_fn__153000127_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_core_reducers_drop_fn__153000127_A) Invoke_O_O__O(self, f1__1 any) any { var cnt__2 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_49.GetRawRoot__O()).Invoke_O__O(t.F_n); var tmp1 any = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(cnt__2, f1__1); var tmp2 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class; if

	fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class = fncls__42d; tmp2 = fncls__42d } else { tmp2 = fncls__42 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :222:1
func A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Ctor_O_O(c__cnt, c__f1 any) { t.F_cnt = c__cnt; t.F_f1 = c__f1 }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O_O__O(self, ret__1, k__2, v__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_50.GetRawRoot__O()); var tmp2 any = t.F_cnt; tmp1.Invoke_O_O__O(tmp2, A_arbace_core_reducers_A_const_51.GetRawRoot__O())
	var tmp3 bool; var na_38 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_cnt); if jrt.Long_InstanceOf(na_38) { var n0_39 int64 = jrt.NN(jrt.Long_Cast(na_38)).LongValue__J(); tmp3 = n0_39 < 0 } else { if jrt.Double_InstanceOf(na_38) { var n0_39_2 float64 = jrt.NN(jrt.Double_Cast(na_38)).DoubleValue__D(); tmp3 = n0_39_2 < 0.0 } else { tmp3 = lang.Numbers_IsNeg_O__Z_NoInit(na_38) } }; if tmp3 {
		return lang.IFn_Cast(t.F_f1).Invoke_O_O_O__O(ret__1, k__2, v__3) } else {
//line :225:1
			return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O_O_O__O(self, ret__1, v__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_50.GetRawRoot__O()); var tmp2 any = t.F_cnt; tmp1.Invoke_O_O__O(tmp2, A_arbace_core_reducers_A_const_51.GetRawRoot__O()); var tmp3 bool; var na_40 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_cnt); if jrt.Long_InstanceOf(na_40) { var n0_41 int64 = jrt.NN(jrt.Long_Cast(na_40)).LongValue__J(); tmp3 = n0_41 < 0 } else { if jrt.Double_InstanceOf(na_40) { var n0_41_2 float64 = jrt.NN(jrt.Double_Cast(na_40)).DoubleValue__D(); tmp3 = n0_41_2 < 0.0 } else { tmp3 = lang.Numbers_IsNeg_O__Z_NoInit(na_40) } }; if tmp3 { return lang.IFn_Cast(t.F_f1).Invoke_O_O__O(ret__1, v__2) } else { return ret__1 } }
//line :222:1
func (t *A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f1).Invoke__O() }







func A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_New() *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Ctor() {}
//line :230:1
func (t *A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A) Invoke_O_O_O_O__O(self, cnt__1, left__2, right__3 any) any { return A_arbace_core_reducers_Cat_A_New_O_O_O(cnt__1, left__2, right__3) }
























func A_arbace_core_reducers_cat_A_New() *A_arbace_core_reducers_cat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_cat_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Ctor() {}
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O_O__O(self, left__0, right__1 any) any {













	if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(left__0))) { return right__1 } else { if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(right__1))) { return left__0 } else { if A_arbace_core_reducers_A_const_54 != nil { return A_arbace_core_reducers_Cat_A_New_O_O_O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(left__0)), int64(lang.RT_Count_O__I_NoInit(right__1)))).Ref(), left__0, right__1) } else { return nil } } } }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O_O__O(self, ctor__0 any) any {









	var tmp1 any = A_arbace_core_reducers_cat_fn__153000141_A_New_O(ctor__0); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_core_reducers_cat_fn__153000141_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_core_reducers_cat_fn__153000141_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :255:1
func (t *A_arbace_core_reducers_cat_A) Invoke_O__O(self any) any { return jrt.ArrayList_New() }









func A_arbace_core_reducers_cat_fn__153000141_A_New_O(p0 any) *A_arbace_core_reducers_cat_fn__153000141_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_cat_fn__153000141_A{}; t.Ctor_O(p0); return t }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Ctor_O(c__ctor any) { t.F_ctor = c__ctor }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O_O_O__O(self, left__1, right__2 any) any {

	return lang.IFn_Cast(A_arbace_core_reducers_A_const_55.GetRawRoot__O()).Invoke_O_O__O(left__1, right__2) }
//line :265:1
func (t *A_arbace_core_reducers_cat_fn__153000141_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}







func A_arbace_core_reducers_append_BANG__A_New() *A_arbace_core_reducers_append_BANG__A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_append_BANG__A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Ctor() {}
//line :275:1
func (t *A_arbace_core_reducers_append_BANG__A) Invoke_O_O_O__O(self, acc__0, x__1 any) any { var G__153000144__3_ any = acc__0;



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Collection_Cast(G__153000144__3_).Add_O__Z(x__1)); return G__153000144__3_ }

func A_arbace_core_reducers_foldcat_A_New() *A_arbace_core_reducers_foldcat_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldcat_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Ctor() {}
//line :281:1
func (t *A_arbace_core_reducers_foldcat_A) Invoke_O_O__O(self, coll__0 any) any {



	return lang.IFn_Cast(A_arbace_core_reducers_A_const_19.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_reducers_A_const_55.GetRawRoot__O(), A_arbace_core_reducers_A_const_56.GetRawRoot__O(), coll__0)
}
func A_arbace_core_reducers_monoid_A_New() *A_arbace_core_reducers_monoid_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_monoid_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Ctor() {}
//line :287:1
func (t *A_arbace_core_reducers_monoid_A) Invoke_O_O_O__O(self, op__0, ctor__1 any) any {





	var tmp1 any = A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(op__0, ctor__1); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_core_reducers_monoid_m__153000147_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_core_reducers_monoid_m__153000147_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :293:1
func A_arbace_core_reducers_monoid_m__153000147_A_New_O_O(p0, p1 any) *A_arbace_core_reducers_monoid_m__153000147_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_monoid_m__153000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Ctor_O_O(c__op, c__ctor any) { t.F_op = c__op; t.F_ctor = c__ctor }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O_O_O__O(self, a__1, b__2 any) any {

	return lang.IFn_Cast(t.F_op).Invoke_O_O__O(a__1, b__2) }
//line :293:1
func (t *A_arbace_core_reducers_monoid_m__153000147_A) Invoke_O__O(self any) any {
	return lang.IFn_Cast(t.F_ctor).Invoke__O()
}


func A_arbace_core_reducers_foldvec_A_New() *A_arbace_core_reducers_foldvec_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Ctor() {}
//line :298:1
func (t *A_arbace_core_reducers_foldvec_A) Invoke_O_O_O_O_O__O(self, v__0, n__1, combinef__2, reducef__3 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_reducers_A_const_57.GetRawRoot__O()).Invoke_O__O(v__0)) {
		return lang.IFn_Cast(combinef__2).Invoke__O() } else {
//line :300:1
			var tmp1 bool; var na_47 int64 = int64(lang.RT_Count_O__I_NoInit(v__0))
			var na_48 any = n__1
			if jrt.Long_InstanceOf(na_48) { var n0_49 int64 = na_47; var n1_50 int64 = jrt.NN(jrt.Long_Cast(na_48)).LongValue__J(); tmp1 = n0_49 <= n1_50 } else { tmp1 = lang.Numbers_Lte_J_O__Z_NoInit(na_47, na_48) }
//line :300:1
			if tmp1 {

				return lang.IFn_Cast(A_arbace_core_reducers_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(reducef__3, lang.IFn_Cast(combinef__2).Invoke__O(), v__0) } else {
//line :300:1
					if A_arbace_core_reducers_A_const_54 != nil { var split__5 int64 = lang.Numbers_Quotient_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(v__0)), 2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_58.GetRawRoot__O()); var tmp3 any = A_arbace_core_reducers_A_const_61; var v1__6 any = tmp2.Invoke_O_O_O__O(v__0, tmp3, jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref()); var v2__7 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(v__0, jrt.Long_ValueOf_J__Long_NoInit(split__5).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__0)).Ref()); var fc__8 any; var tmp4 any = A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(combinef__2, n__1, reducef__3); var tmp5 *jrt.Class
						var fncls__53 /*line :300:1*/*jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class






						if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class = fncls__53d; tmp5 = fncls__53d } else { tmp5 = fncls__53 }; fc__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_core_reducers_A_const_60.GetRawRoot__O()); var tmp7 any = A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(combinef__2, fc__8, v1__6, v2__7); var tmp8 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class = fncls__54d; tmp8 = fncls__54d } else { tmp8 = fncls__54 }; return tmp6.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {
//line :300:1
							return nil
						}
				}
		}
}


func A_arbace_core_reducers_foldvec_fc__153000150_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_reducers_foldvec_fc__153000150_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Ctor_O_O_O(c__combinef, c__n, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_A) Invoke_O_O__O(self, child__1 any) any { var tmp1 any = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(t.F_combinef, t.F_n, child__1, t.F_reducef); var tmp2 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :307:1
func A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Ctor_O_O_O_O(c__combinef, c__n, c__child, c__reducef any) { t.F_combinef = c__combinef; t.F_n = c__n; t.F_child = c__child; t.F_reducef = c__reducef }
//line :307:1
func (t *A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_core_reducers_A_const_59.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_child, t.F_n, t.F_combinef, t.F_reducef) }
func A_arbace_core_reducers_foldvec_fn__153000154_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_core_reducers_foldvec_fn__153000154_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_foldvec_fn__153000154_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Ctor_O_O_O_O(c__combinef, c__fc, c__v1, c__v2 any) { t.F_combinef = c__combinef; t.F_fc = c__fc; t.F_v1 = c__v1; t.F_v2 = c__v2 }
//line :308:1
func (t *A_arbace_core_reducers_foldvec_fn__153000154_A) Invoke_O__O(self any) any { var f1__1 any = lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v1); var t2__2 any = lang.IFn_Cast(A_arbace_core_reducers_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_fc).Invoke_O__O(t.F_v2));


	lang.IFn_Cast(A_arbace_core_reducers_A_const_62.GetRawRoot__O()).Invoke_O__O(t2__2); var tmp1 lang.IFn =
	lang.IFn_Cast(t.F_combinef); return tmp1.Invoke_O_O__O(lang.IFn_Cast(f1__1).Invoke__O(), lang.IFn_Cast(A_arbace_core_reducers_A_const_63.GetRawRoot__O()).Invoke_O__O(t2__2)) }

func A_arbace_core_reducers_eval153000157_fn__153000158_A_New() *A_arbace_core_reducers_eval153000157_fn__153000158_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000157_fn__153000158_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000157_fn__153000158_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {



	return lang.IFn_Cast(combinef__3).Invoke__O() }
//line :314:1
func A_arbace_core_reducers_eval153000161_fn__153000162_A_New() *A_arbace_core_reducers_eval153000161_fn__153000162_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000161_fn__153000162_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000161_fn__153000162_A) Invoke_O_O_O_O_O__O(self, coll__1, n__2, combinef__3, reducef__4 any) any {









	return lang.IFn_Cast(A_arbace_core_reducers_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(reducef__4, lang.IFn_Cast(combinef__3).Invoke__O(), coll__1) }
//line :314:1
func A_arbace_core_reducers_eval153000165_fn__153000166_A_New() *A_arbace_core_reducers_eval153000165_fn__153000166_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000165_fn__153000166_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000165_fn__153000166_A) Invoke_O_O_O_O_O__O(self, v__1, n__2, combinef__3, reducef__4 any) any {














	return lang.IFn_Cast(A_arbace_core_reducers_A_const_59.GetRawRoot__O()).Invoke_O_O_O_O__O(v__1, n__2, combinef__3, reducef__4) }
//line :314:1
func A_arbace_core_reducers_eval153000169_fn__153000170_A_New() *A_arbace_core_reducers_eval153000169_fn__153000170_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_eval153000169_fn__153000170_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Ctor() {}
//line :314:1
func (t *A_arbace_core_reducers_eval153000169_fn__153000170_A) Invoke_O_O_O_O_O__O(self, m__1, n__2, combinef__3, reducef__4 any) any {



















	return jrt.NN(lang.PersistentHashMap_Cast(m__1)).Fold_J_IFn_IFn_IFn_IFn_IFn_IFn__O(lang.RT_LongCast_O__J_NoInit(n__2), lang.IFn_Cast(combinef__3), lang.IFn_Cast(reducef__4), lang.IFn_Cast(A_arbace_core_reducers_A_const_60.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_11.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_62.GetRawRoot__O()), lang.IFn_Cast(A_arbace_core_reducers_A_const_63.GetRawRoot__O()))
}






















































































































































type A_arbace_core_reducers_A struct{ jrt.Object }

var A_arbace_core_reducers_A_const_pool *jrt.RefArray

var A_arbace_core_reducers_A_const_0 *lang.Var

var A_arbace_core_reducers_A_const_1 *lang.Var

var A_arbace_core_reducers_A_const_2 any

var A_arbace_core_reducers_A_const_3 *lang.Keyword

var A_arbace_core_reducers_A_const_4 any

var A_arbace_core_reducers_A_const_5 any

var A_arbace_core_reducers_A_const_6 *lang.Var

var A_arbace_core_reducers_A_const_7 *lang.Var

var A_arbace_core_reducers_A_const_8 *lang.Var

var A_arbace_core_reducers_A_const_9 any

var A_arbace_core_reducers_A_const_10 *lang.Var

var A_arbace_core_reducers_A_const_11 *lang.Var

var A_arbace_core_reducers_A_const_12 *lang.Var

var A_arbace_core_reducers_A_const_13 *lang.Var

var A_arbace_core_reducers_A_const_14 *lang.Var

var A_arbace_core_reducers_A_const_15 *lang.Var

var A_arbace_core_reducers_A_const_16 *lang.Var

var A_arbace_core_reducers_A_const_17 *jrt.Class

var A_arbace_core_reducers_A_const_18 *lang.Var

var A_arbace_core_reducers_A_const_19 *lang.Var

var A_arbace_core_reducers_A_const_20 any

var A_arbace_core_reducers_A_const_21 *lang.Var

var A_arbace_core_reducers_A_const_22 *lang.Var

var A_arbace_core_reducers_A_const_23 *lang.Var

var A_arbace_core_reducers_A_const_24 *lang.Var

var A_arbace_core_reducers_A_const_25 *lang.Var

var A_arbace_core_reducers_A_const_26 any

var A_arbace_core_reducers_A_const_27 any

var A_arbace_core_reducers_A_const_28 *lang.Var

var A_arbace_core_reducers_A_const_29 *lang.Var

var A_arbace_core_reducers_A_const_30 any

var A_arbace_core_reducers_A_const_31 *lang.Var

var A_arbace_core_reducers_A_const_32 any

var A_arbace_core_reducers_A_const_33 *lang.Var

var A_arbace_core_reducers_A_const_34 *lang.Var

var A_arbace_core_reducers_A_const_35 *lang.Var

var A_arbace_core_reducers_A_const_36 *lang.Var

var A_arbace_core_reducers_A_const_37 *lang.Var

var A_arbace_core_reducers_A_const_38 *lang.Var

var A_arbace_core_reducers_A_const_39 *lang.Var

var A_arbace_core_reducers_A_const_40 *lang.Var

var A_arbace_core_reducers_A_const_41 *lang.Var

var A_arbace_core_reducers_A_const_42 *lang.Var

var A_arbace_core_reducers_A_const_43 *lang.Var

var A_arbace_core_reducers_A_const_44 *lang.Var

var A_arbace_core_reducers_A_const_45 *lang.Var

var A_arbace_core_reducers_A_const_46 *lang.Var

var A_arbace_core_reducers_A_const_47 *lang.Var

var A_arbace_core_reducers_A_const_48 *lang.Var

var A_arbace_core_reducers_A_const_49 *lang.Var

var A_arbace_core_reducers_A_const_50 *lang.Var

var A_arbace_core_reducers_A_const_51 *lang.Var

var A_arbace_core_reducers_A_const_52 *lang.Var

var A_arbace_core_reducers_A_const_53 *lang.Var

var A_arbace_core_reducers_A_const_54 *lang.Keyword

var A_arbace_core_reducers_A_const_55 *lang.Var

var A_arbace_core_reducers_A_const_56 *lang.Var

var A_arbace_core_reducers_A_const_57 *lang.Var

var A_arbace_core_reducers_A_const_58 *lang.Var

var A_arbace_core_reducers_A_const_59 *lang.Var

var A_arbace_core_reducers_A_const_60 *lang.Var

var A_arbace_core_reducers_A_const_61 any

var A_arbace_core_reducers_A_const_62 *lang.Var

var A_arbace_core_reducers_A_const_63 *lang.Var

var A_arbace_core_reducers_A_init jrt.ClassInit

func A_arbace_core_reducers_A_Init() { if !A_arbace_core_reducers_A_init.Done() { A_arbace_core_reducers_A_init.Run(A_arbace_core_reducers_A_clinit) } }

func A_arbace_core_reducers_A_clinit() { A_arbace_core_reducers_A_clinit_p0(); A_arbace_core_reducers_A_clinit_p1(); A_arbace_core_reducers_A_clinit_p2(); A_arbace_core_reducers_A_clinit_p3(); A_arbace_core_reducers_A_clinit_p4(); A_arbace_core_reducers_A_clinit_p5() }

func A_arbace_core_reducers_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_reducers_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 85); A_arbace_core_reducers_A_const_0 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[21]); A_arbace_core_reducers_A_const_1 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[22]); A_arbace_core_reducers_A_const_2 = A_arbace_core_reducers_A_const_pool.A[23]; A_arbace_core_reducers_A_const_3 = lang.Keyword_Cast(A_arbace_core_reducers_A_const_pool.A[24]); A_arbace_core_reducers_A_const_4 = A_arbace_core_reducers_A_const_pool.A[25]; A_arbace_core_reducers_A_const_5 = A_arbace_core_reducers_A_const_pool.A[26]; A_arbace_core_reducers_A_const_6 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[27]); A_arbace_core_reducers_A_const_7 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[28]); A_arbace_core_reducers_A_const_8 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[29]); A_arbace_core_reducers_A_const_9 = A_arbace_core_reducers_A_const_pool.A[30]; A_arbace_core_reducers_A_const_10 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[31]); A_arbace_core_reducers_A_const_11 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[32]) }

func A_arbace_core_reducers_A_clinit_p1() { A_arbace_core_reducers_A_const_12 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[33]); A_arbace_core_reducers_A_const_13 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[34]); A_arbace_core_reducers_A_const_14 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[35]); A_arbace_core_reducers_A_const_15 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[36]); A_arbace_core_reducers_A_const_16 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[37]); A_arbace_core_reducers_A_const_17 = jrt.Class_Cast(A_arbace_core_reducers_A_const_pool.A[38]); A_arbace_core_reducers_A_const_18 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[39]); A_arbace_core_reducers_A_const_19 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[40]); A_arbace_core_reducers_A_const_20 = A_arbace_core_reducers_A_const_pool.A[41]; A_arbace_core_reducers_A_const_21 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[42]); A_arbace_core_reducers_A_const_22 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[43]); A_arbace_core_reducers_A_const_23 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[44]) }

func A_arbace_core_reducers_A_clinit_p2() { A_arbace_core_reducers_A_const_24 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[45]); A_arbace_core_reducers_A_const_25 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[46]); A_arbace_core_reducers_A_const_26 = A_arbace_core_reducers_A_const_pool.A[47]; A_arbace_core_reducers_A_const_27 = A_arbace_core_reducers_A_const_pool.A[48]; A_arbace_core_reducers_A_const_28 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[49]); A_arbace_core_reducers_A_const_29 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[50]); A_arbace_core_reducers_A_const_30 = A_arbace_core_reducers_A_const_pool.A[51]; A_arbace_core_reducers_A_const_31 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[52]); A_arbace_core_reducers_A_const_32 = A_arbace_core_reducers_A_const_pool.A[53]; A_arbace_core_reducers_A_const_33 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[54]); A_arbace_core_reducers_A_const_34 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[55]); A_arbace_core_reducers_A_const_35 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[56]); A_arbace_core_reducers_A_const_36 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[57]) }

func A_arbace_core_reducers_A_clinit_p3() { A_arbace_core_reducers_A_const_37 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[58]); A_arbace_core_reducers_A_const_38 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[59]); A_arbace_core_reducers_A_const_39 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[60]); A_arbace_core_reducers_A_const_40 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[61]); A_arbace_core_reducers_A_const_41 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[62]); A_arbace_core_reducers_A_const_42 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[63]); A_arbace_core_reducers_A_const_43 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[64]); A_arbace_core_reducers_A_const_44 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[65]); A_arbace_core_reducers_A_const_45 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[66]); A_arbace_core_reducers_A_const_46 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[67]); A_arbace_core_reducers_A_const_47 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[68]); A_arbace_core_reducers_A_const_48 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[69]) }

func A_arbace_core_reducers_A_clinit_p4() { A_arbace_core_reducers_A_const_49 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[70]); A_arbace_core_reducers_A_const_50 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[71]); A_arbace_core_reducers_A_const_51 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[72]); A_arbace_core_reducers_A_const_52 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[73]); A_arbace_core_reducers_A_const_53 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[74]); A_arbace_core_reducers_A_const_54 = lang.Keyword_Cast(A_arbace_core_reducers_A_const_pool.A[75]); A_arbace_core_reducers_A_const_55 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[76]); A_arbace_core_reducers_A_const_56 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[77]); A_arbace_core_reducers_A_const_57 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[78]); A_arbace_core_reducers_A_const_58 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[79]); A_arbace_core_reducers_A_const_59 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[80]); A_arbace_core_reducers_A_const_60 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[81]) }

func A_arbace_core_reducers_A_clinit_p5() { A_arbace_core_reducers_A_const_61 = A_arbace_core_reducers_A_const_pool.A[82]; A_arbace_core_reducers_A_const_62 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[83]); A_arbace_core_reducers_A_const_63 = lang.Var_Cast(A_arbace_core_reducers_A_const_pool.A[84]) }

func A_arbace_core_reducers_A_New() *A_arbace_core_reducers_A { A_arbace_core_reducers_A_Init(); t := &A_arbace_core_reducers_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_A) Ctor() {}

func (t *A_arbace_core_reducers_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_A_class }

func (t *A_arbace_core_reducers_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_A); return ok }

func A_arbace_core_reducers_A_Cast(x any) *A_arbace_core_reducers_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_A_class)) }; return v }



type A_arbace_core_reducers_append_BANG__A struct{ j2g_header uint64 }

var A_arbace_core_reducers_append_BANG__A_fn_class *jrt.Class



type A_arbace_core_reducers_cat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_cat_A_fn_class *jrt.Class



type A_arbace_core_reducers_cat_fn__153000141_A struct{ j2g_header uint64; F_ctor any }

var A_arbace_core_reducers_cat_fn__153000141_A_fn_class *jrt.Class



type A_arbace_core_reducers_defcurried_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_defcurried_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_curried_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_do_curried_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_rfn_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_do_rfn_A_fn_class *jrt.Class



type A_arbace_core_reducers_do_rfn_fn__153000066_A struct{ j2g_header uint64; F_k any }

var A_arbace_core_reducers_do_rfn_fn__153000066_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_drop_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000125_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_drop_fn__153000125_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000127_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_drop_fn__153000127_A_fn_class *jrt.Class



type A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A struct{ j2g_header uint64; F_cnt, F_f1 any }

var A_arbace_core_reducers_drop_fn__153000127_fn__153000128_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000004_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000004_A_New() *A_arbace_core_reducers_eval153000004_A { t := &A_arbace_core_reducers_eval153000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000004_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000004_A_class }

func (t *A_arbace_core_reducers_eval153000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000004_A); return ok }

func A_arbace_core_reducers_eval153000004_A_Cast(x any) *A_arbace_core_reducers_eval153000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000004_A_class)) }; return v }



type A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000004_loading__1927001464__auto____153000005_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000008_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000008_A_New() *A_arbace_core_reducers_eval153000008_A { t := &A_arbace_core_reducers_eval153000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000008_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000008_A_class }

func (t *A_arbace_core_reducers_eval153000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000008_A); return ok }

func A_arbace_core_reducers_eval153000008_A_Cast(x any) *A_arbace_core_reducers_eval153000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000008_A_class)) }; return v }



type A_arbace_core_reducers_eval153000008_fn__153000009_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000008_fn__153000009_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000031_A_New() *A_arbace_core_reducers_eval153000031_A { t := &A_arbace_core_reducers_eval153000031_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000031_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000031_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000031_A_class }

func (t *A_arbace_core_reducers_eval153000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000031_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000031_A); return ok }

func A_arbace_core_reducers_eval153000031_A_Cast(x any) *A_arbace_core_reducers_eval153000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000031_A_class)) }; return v }



type A_arbace_core_reducers_eval153000031_fn__153000032_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000031_fn__153000032_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A struct{ j2g_header uint64; F_G__153000024 any }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000023__153000043_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000031_fn__153000032_G__153000024__153000037_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000132_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000132_A_New() *A_arbace_core_reducers_eval153000132_A { t := &A_arbace_core_reducers_eval153000132_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000132_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000132_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000132_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000132_A_class }

func (t *A_arbace_core_reducers_eval153000132_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000132_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000132_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000132_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000132_A); return ok }

func A_arbace_core_reducers_eval153000132_A_Cast(x any) *A_arbace_core_reducers_eval153000132_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000132_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000132_A_class)) }; return v }



type A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000132___GT_Cat__153000138_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000157_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000157_A_New() *A_arbace_core_reducers_eval153000157_A { t := &A_arbace_core_reducers_eval153000157_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000157_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000157_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000157_A_class }

func (t *A_arbace_core_reducers_eval153000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000157_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000157_A); return ok }

func A_arbace_core_reducers_eval153000157_A_Cast(x any) *A_arbace_core_reducers_eval153000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000157_A_class)) }; return v }



type A_arbace_core_reducers_eval153000157_fn__153000158_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000157_fn__153000158_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000161_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000161_A_New() *A_arbace_core_reducers_eval153000161_A { t := &A_arbace_core_reducers_eval153000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000161_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000161_A_class }

func (t *A_arbace_core_reducers_eval153000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000161_A); return ok }

func A_arbace_core_reducers_eval153000161_A_Cast(x any) *A_arbace_core_reducers_eval153000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000161_A_class)) }; return v }



type A_arbace_core_reducers_eval153000161_fn__153000162_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000161_fn__153000162_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000165_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000165_A_New() *A_arbace_core_reducers_eval153000165_A { t := &A_arbace_core_reducers_eval153000165_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000165_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000165_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000165_A_class }

func (t *A_arbace_core_reducers_eval153000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000165_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000165_A); return ok }

func A_arbace_core_reducers_eval153000165_A_Cast(x any) *A_arbace_core_reducers_eval153000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000165_A_class)) }; return v }



type A_arbace_core_reducers_eval153000165_fn__153000166_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000165_fn__153000166_A_fn_class *jrt.Class



type A_arbace_core_reducers_eval153000169_A struct{ jrt.Object }

func A_arbace_core_reducers_eval153000169_A_New() *A_arbace_core_reducers_eval153000169_A { t := &A_arbace_core_reducers_eval153000169_A{}; t.Ctor(); return t }

func (t *A_arbace_core_reducers_eval153000169_A) Ctor() {}

func (t *A_arbace_core_reducers_eval153000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_eval153000169_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_eval153000169_A_class }

func (t *A_arbace_core_reducers_eval153000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_eval153000169_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_eval153000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_eval153000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_eval153000169_A); return ok }

func A_arbace_core_reducers_eval153000169_A_Cast(x any) *A_arbace_core_reducers_eval153000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_eval153000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_eval153000169_A_class)) }; return v }



type A_arbace_core_reducers_eval153000169_fn__153000170_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_eval153000169_fn__153000170_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_filter_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000094_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_filter_fn__153000094_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000096_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_filter_fn__153000096_A_fn_class *jrt.Class



type A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A struct{ j2g_header uint64; F_pred, F_f1 any }

var A_arbace_core_reducers_filter_fn__153000096_fn__153000097_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjfork_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjfork_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjinvoke_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjinvoke_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjjoin_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjjoin_A_fn_class *jrt.Class



type A_arbace_core_reducers_fjtask_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fjtask_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000104_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_fn__153000104_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000106_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_flatten_fn__153000106_A_fn_class *jrt.Class



type A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A struct{ j2g_header uint64; F_f1 any }

var A_arbace_core_reducers_flatten_fn__153000106_fn__153000107_A_fn_class *jrt.Class



type A_arbace_core_reducers_fn__153000016_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fn__153000016_A_fn_class *jrt.Class



type A_arbace_core_reducers_fold_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_fold_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldcat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_foldcat_A_fn_class *jrt.Class



type A_arbace_core_reducers_folder_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_folder_A_fn_class *jrt.Class



type A_arbace_core_reducers_folder_reify__153000055_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_A_arbace_core_reducers_CollFold_A() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IObj() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_folder_reify__153000055_A_class }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_folder_reify__153000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_folder_reify__153000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); return ok }

func A_arbace_core_reducers_folder_reify__153000055_A_Cast(x any) *A_arbace_core_reducers_folder_reify__153000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_folder_reify__153000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_folder_reify__153000055_A_class)) }; return v }



type A_arbace_core_reducers_foldvec_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_foldvec_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fc__153000150_A struct{ j2g_header uint64; F_combinef, F_n, F_reducef any }

var A_arbace_core_reducers_foldvec_fc__153000150_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A struct{ j2g_header uint64; F_combinef, F_n, F_child, F_reducef any }

var A_arbace_core_reducers_foldvec_fc__153000150_fn__153000151_A_fn_class *jrt.Class



type A_arbace_core_reducers_foldvec_fn__153000154_A struct{ j2g_header uint64; F_combinef, F_fc, F_v1, F_v2 any }

var A_arbace_core_reducers_foldvec_fn__153000154_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_map_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000078_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_map_fn__153000078_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000080_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_map_fn__153000080_A_fn_class *jrt.Class



type A_arbace_core_reducers_map_fn__153000080_fn__153000081_A struct{ j2g_header uint64; F_f, F_f1 any }

var A_arbace_core_reducers_map_fn__153000080_fn__153000081_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_mapcat_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000085_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_mapcat_fn__153000085_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_A struct{ j2g_header uint64; F_f any }

var A_arbace_core_reducers_mapcat_fn__153000087_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A struct{ j2g_header uint64; F_f1 any }

var A_arbace_core_reducers_mapcat_fn__153000087_f1__153000088_A_fn_class *jrt.Class



type A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A struct{ j2g_header uint64; F_f, F_f1 any }

var A_arbace_core_reducers_mapcat_fn__153000087_fn__153000090_A_fn_class *jrt.Class



type A_arbace_core_reducers_monoid_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_monoid_A_fn_class *jrt.Class



type A_arbace_core_reducers_monoid_m__153000147_A struct{ j2g_header uint64; F_op, F_ctor any }

var A_arbace_core_reducers_monoid_m__153000147_A_fn_class *jrt.Class



type A_arbace_core_reducers_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_reduce_A_fn_class *jrt.Class



type A_arbace_core_reducers_reducer_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_reducer_A_fn_class *jrt.Class



type A_arbace_core_reducers_reducer_reify__153000052_A struct{ jrt.Object; F_coll, F_xf any; F___meta lang.IPersistentMap }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_A_arbace_core_protocols_CollReduce_A() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IObj() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Is_IMeta() {}

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) GetClass__Class() *jrt.Class { return A_arbace_core_reducers_reducer_reify__153000052_A_class }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_reducers_reducer_reify__153000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_reducers_reducer_reify__153000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); return ok }

func A_arbace_core_reducers_reducer_reify__153000052_A_Cast(x any) *A_arbace_core_reducers_reducer_reify__153000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_reducers_reducer_reify__153000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_reducers_reducer_reify__153000052_A_class)) }; return v }



type A_arbace_core_reducers_remove_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_remove_A_fn_class *jrt.Class



type A_arbace_core_reducers_remove_fn__153000101_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_remove_fn__153000101_A_fn_class *jrt.Class



type A_arbace_core_reducers_rfn_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_rfn_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_take_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000118_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_take_fn__153000118_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000120_A struct{ j2g_header uint64; F_n any }

var A_arbace_core_reducers_take_fn__153000120_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_fn__153000120_fn__153000121_A struct{ j2g_header uint64; F_cnt, F_f1 any }

var A_arbace_core_reducers_take_fn__153000120_fn__153000121_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_A struct{ j2g_header uint64 }

var A_arbace_core_reducers_take_while_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000111_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_take_while_fn__153000111_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000113_A struct{ j2g_header uint64; F_pred any }

var A_arbace_core_reducers_take_while_fn__153000113_A_fn_class *jrt.Class



type A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A struct{ j2g_header uint64; F_pred, F_f1 any }

var A_arbace_core_reducers_take_while_fn__153000113_fn__153000114_A_fn_class *jrt.Class
