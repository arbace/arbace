//line a2g_strings.ae:1
package aot_arbace_c2a_rename

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2a.rename")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("The clojure -> arbace renaming of agenda step 4 (doc/VENDOR-NOTES.md, \"What is renamed\"),\n  as a textual rewrite of source text: c2a's rule :rename (arbace.c2a.rules, doc/C2A.md), which\n  bin/clojure-tests applies to Clojure's test suite and its test libraries. As\n  arbace.j2c.rename it derived arbace/ from the frozen clojure/ once (bin/vendor-arbace and\n  bin/vendor-spec, on the branch arbace-for-java-26).\n\n  Renamed: names that belong to the vendored Clojure, written dotted or as paths:\n  - the Java packages clojure.lang, clojure.asm (with commons, signature), clojure.java.api,\n    whatever follows them (class names, members, descriptors \"Lclojure/lang/Var;\", array\n    names \"[Lclojure.lang.Var;\");\n  - the vendored namespaces (exactly: clojure.core, clojure.core.protocols, ..., see\n    `namespaces`), as symbols, qualified symbols and keywords, strings and resource paths\n    (clojure/core, clojure/pprint/cl_format, clojure/core__init);\n  - the keyword namespace clojure.error;\n  - the system properties Clojure reads: clojure.compile.*, clojure.compiler.*,\n    clojure.server.*, clojure.read.eval, clojure.main.report, clojure.basis;\n  - clojure.jar in usage texts;\n  - spec, vendored later (doc/VENDOR-NOTES.md, \"Spec\"): clojure.spec with whatever follows\n    (clojure.spec.alpha, .gen.alpha, .test.alpha, :clojure.spec.alpha/problems, the\n    clojure.spec.* system properties, clojure/spec/alpha) and clojure.core.specs.alpha.\n  Left alone: other libraries' names (clojure.test.check, clojure.tools.namespace, clojure.tools.deps, clojure.data.generators,\n  clojure.java.classpath, ...; and the suite's own clojure.test-clojure.*), identifiers that\n  merely contain the word (clojure-version, *clojure-version*, refer-clojure, CLOJURE_NS,\n  __clojureFnMap, thread names clojure-agent-*; some were renamed by hand after vendoring, see\n  doc/VENDOR-NOTES.md), prose and URLs (clojure.org).")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("join")

var Lit_14 *jrt.String = jrt.Intern("map")

var Lit_15 *jrt.String = jrt.Intern("split")

var Lit_16 *jrt.String = jrt.Intern("\\.")

var Lit_17 *jrt.String = jrt.Intern("sort-by")

var Lit_18 *jrt.String = jrt.Intern("comp")

var Lit_19 *jrt.String = jrt.Intern("-")

var Lit_20 *jrt.String = jrt.Intern("count")

var Lit_21 *jrt.String = jrt.Intern("replace")

var Lit_22 *jrt.String = jrt.Intern("reduce")

var Lit_23 *jrt.String = jrt.Intern("source-file")

var Lit_24 *jrt.String = jrt.Intern("patterns")

var Lit_25 *jrt.String = jrt.Intern("arbace.c2a.rename$alt")

var Lit_26 *jrt.String = jrt.Intern("|")

var Lit_27 *jrt.String = jrt.Intern("arbace.c2a.rename$alt$fn__1963000013")

var Lit_28 *jrt.String = jrt.Intern("arbace.c2a.rename$alt$fn__1963000013$fn__1963000014")

var Lit_29 *jrt.String = jrt.Intern("arbace.c2a.rename$eval1963000004$loading__1927001464__auto____1963000005")

var Lit_30 *jrt.String = jrt.Intern("arbace.c2a.rename$eval1963000008$fn__1963000009")

var Lit_31 *jrt.String = jrt.Intern("arbace.c2a.rename$rename")

var Lit_32 *jrt.String = jrt.Intern("$1.ae")

var Lit_33 *jrt.String = jrt.Intern("arbace.c2a.rename$rename$fn__1963000018")

var Lit_34 *jrt.String = jrt.Intern("arbace")

var Lit_35 *jrt.String = jrt.Intern("in-ns")

var Lit_36 *jrt.String = jrt.Intern("namespaces")

var Lit_37 *jrt.String = jrt.Intern("line")

var Lit_38 *jrt.String = jrt.Intern("column")

var Lit_39 *jrt.String = jrt.Intern("file")

var Lit_40 *jrt.String = jrt.Intern("arbace/c2a/rename.ae")

var Lit_41 *jrt.String = jrt.Intern("The namespaces of the vendored Clojure (clojure/**/*.clj), plus the files loaded into them,\n  without the clojure. prefix.")

var Lit_42 *jrt.String = jrt.Intern("prefixes")

var Lit_43 *jrt.String = jrt.Intern("Renamed together with whatever follows them.")

var Lit_44 *jrt.String = jrt.Intern("alt")

var Lit_45 *jrt.String = jrt.Intern("private")

var Lit_46 *jrt.String = jrt.Intern("arglists")

var Lit_47 *jrt.String = jrt.Intern("names")

var Lit_48 *jrt.String = jrt.Intern("sep")

var Lit_49 *jrt.String = jrt.Intern("A regex alternation of the names (longest first), their dots matched by regex sep.")

var Lit_50 *jrt.String = jrt.Intern("before")

var Lit_51 *jrt.String = jrt.Intern("dot")

var Lit_52 *jrt.String = jrt.Intern("any")

var Lit_53 *jrt.String = jrt.Intern("re-pattern")

var Lit_54 *jrt.String = jrt.Intern("A vendored namespace's source file as a path, once renamed: arbace/core.clj, whose Arbace\n  name is arbace/core.ae (Arbace's sources are .ae, doc/VENDOR-NOTES.md, hand change 19).")

var Lit_55 *jrt.String = jrt.Intern("rename")

var Lit_56 *jrt.String = jrt.Intern("s")

var Lit_57 *jrt.String = jrt.Intern("Renames the vendored Clojure's names in text s.")

var Lit_58 *jrt.String = jrt.Intern("(?:(?<=-D)|(?<![\\w.$-]))")

var Lit_59 *jrt.String = jrt.Intern("\\\\?\\.")

var Lit_60 *jrt.String = jrt.Intern("(?:")

var Lit_61 *jrt.String = jrt.Intern("|/)")

var Lit_62 *jrt.String = jrt.Intern("clojure(?=")

var Lit_63 *jrt.String = jrt.Intern(")(?![\\w-]))")

var Lit_64 *jrt.String = jrt.Intern("(?<=(?:^|[^\\w])L)clojure(?=")

var Lit_65 *jrt.String = jrt.Intern("(?:lang|asm|java")

var Lit_66 *jrt.String = jrt.Intern("api)")

var Lit_67 *jrt.String = jrt.Intern(")")

var Lit_68 *jrt.String = jrt.Intern(")(?!(?!__)[\\w*+!?-]|")

var Lit_69 *jrt.String = jrt.Intern("[a-z]))")

var Lit_70 *jrt.String = jrt.Intern("clojure(?=/(?:")

var Lit_71 *jrt.String = jrt.Intern("/")

var Lit_72 *jrt.String = jrt.Intern(")(?!(?!__)[\\w-]|/\\w))")

var Lit_73 *jrt.String = jrt.Intern("(?<![\\w.$-])(arbace/(?:")

var Lit_74 *jrt.String = jrt.Intern("))\\.clj(?![\\w])")
