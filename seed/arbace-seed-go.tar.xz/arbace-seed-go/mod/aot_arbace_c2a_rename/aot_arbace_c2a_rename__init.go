//line aot_arbace_c2a_rename__init.ae:1
package aot_arbace_c2a_rename

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_rename__init_A_Unit0__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_rename__init_A_const_1) }
//line :1:1
func A_arbace_c2a_rename__init_A_Unit1__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_c2a_rename__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_2)) }
//line :1:1
func A_arbace_c2a_rename__init_A_Unit2__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_c2a_rename__init_A_Unit3__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2a_rename__init_A_const_1)).Equals_O__Z(A_arbace_c2a_rename__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_c2a_rename__init_A_Load__O() any { A_arbace_c2a_rename__init_A_Init(); A_arbace_c2a_rename__init_A_Unit0__O(); A_arbace_c2a_rename__init_A_Unit1__O(); A_arbace_c2a_rename__init_A_Unit2__O(); A_arbace_c2a_rename__init_A_Unit3__O(); A_arbace_c2a_rename__init_A_Unit4__O(); A_arbace_c2a_rename__init_A_Unit5__O(); A_arbace_c2a_rename__init_A_Unit6__O(); A_arbace_c2a_rename__init_A_Unit7__O(); A_arbace_c2a_rename__init_A_Unit8__O(); A_arbace_c2a_rename__init_A_Unit9__O(); A_arbace_c2a_rename__init_A_Unit10__O(); A_arbace_c2a_rename__init_A_Unit11__O(); A_arbace_c2a_rename__init_A_Unit12__O(); return nil }























func A_arbace_c2a_rename__init_A_Unit4__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); A_arbace_c2a_rename__init_A_const_4.BindRoot_O__V(A_arbace_c2a_rename__init_A_const_5); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_6)); return A_arbace_c2a_rename__init_A_const_4 }














func A_arbace_c2a_rename__init_A_Unit5__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); A_arbace_c2a_rename__init_A_const_7.BindRoot_O__V(A_arbace_c2a_rename__init_A_const_8); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_9)); return A_arbace_c2a_rename__init_A_const_7 }



func A_arbace_c2a_rename__init_A_Unit6__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_10; var tmp2 any = A_arbace_c2a_rename_alt_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c2a_rename_alt_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_c2a_rename_alt_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rename__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_11)); return A_arbace_c2a_rename__init_A_const_10 }







func A_arbace_c2a_rename__init_A_Unit7__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); A_arbace_c2a_rename__init_A_const_12.BindRoot_O__V(Lit_11); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_13)); return A_arbace_c2a_rename__init_A_const_12 }


func A_arbace_c2a_rename__init_A_Unit8__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); A_arbace_c2a_rename__init_A_const_14.BindRoot_O__V(Lit_12); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_15)); return A_arbace_c2a_rename__init_A_const_14 }
func A_arbace_c2a_rename__init_A_Unit9__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_16; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(Lit_13, A_arbace_c2a_rename__init_A_const_14.GetRawRoot__O(), Lit_14)); var tmp2 *lang.Var = A_arbace_c2a_rename__init_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_18)); return A_arbace_c2a_rename__init_A_const_16 }

func A_arbace_c2a_rename__init_A_Unit10__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_19; tmp1.BindRoot_O__V(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_c2a_rename__init_A_const_12.GetRawRoot__O(), Lit_15, A_arbace_c2a_rename__init_A_const_16.GetRawRoot__O(), Lit_13, lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2a_rename__init_A_const_7.GetRawRoot__O(), A_arbace_c2a_rename__init_A_const_16.GetRawRoot__O()), Lit_16)), lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(Lit_17, A_arbace_c2a_rename__init_A_const_16.GetRawRoot__O(), Lit_18, A_arbace_c2a_rename__init_A_const_16.GetRawRoot__O(), Lit_19, A_arbace_c2a_rename__init_A_const_16.GetRawRoot__O(), Lit_20)), lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_c2a_rename__init_A_const_12.GetRawRoot__O(), Lit_15, A_arbace_c2a_rename__init_A_const_14.GetRawRoot__O(), Lit_13, lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2a_rename__init_A_const_4.GetRawRoot__O(), A_arbace_c2a_rename__init_A_const_14.GetRawRoot__O()), Lit_21, A_arbace_c2a_rename__init_A_const_14.GetRawRoot__O(), Lit_22)), lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c2a_rename__init_A_const_12.GetRawRoot__O(), Lit_23, lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2a_rename__init_A_const_4.GetRawRoot__O(), Lit_24), Lit_25)))); var tmp2 *lang.Var = A_arbace_c2a_rename__init_A_const_19; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_20)); return A_arbace_c2a_rename__init_A_const_19 }












func A_arbace_c2a_rename__init_A_Unit11__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_22; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(Lit_26, lang.IFn_Cast(A_arbace_c2a_rename__init_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2a_rename__init_A_const_4.GetRawRoot__O(), Lit_24), Lit_27))); var tmp2 *lang.Var = A_arbace_c2a_rename__init_A_const_22; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_23)); return A_arbace_c2a_rename__init_A_const_22 }




func A_arbace_c2a_rename__init_A_Unit12__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_24; var tmp2 any = A_arbace_c2a_rename_rename_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_c2a_rename_rename_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_c2a_rename_rename_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rename__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_25)); return A_arbace_c2a_rename__init_A_const_24 }



type A_arbace_c2a_rename__init_A struct{ jrt.Object }

var A_arbace_c2a_rename__init_A_const_pool *jrt.RefArray

var A_arbace_c2a_rename__init_A_const_0 *lang.Var

var A_arbace_c2a_rename__init_A_const_1 any

var A_arbace_c2a_rename__init_A_const_2 any

var A_arbace_c2a_rename__init_A_const_3 any

var A_arbace_c2a_rename__init_A_const_4 *lang.Var

var A_arbace_c2a_rename__init_A_const_5 any

var A_arbace_c2a_rename__init_A_const_6 any

var A_arbace_c2a_rename__init_A_const_7 *lang.Var

var A_arbace_c2a_rename__init_A_const_8 any

var A_arbace_c2a_rename__init_A_const_9 any

var A_arbace_c2a_rename__init_A_const_10 *lang.Var

var A_arbace_c2a_rename__init_A_const_11 any

var A_arbace_c2a_rename__init_A_const_12 *lang.Var

var A_arbace_c2a_rename__init_A_const_13 any

var A_arbace_c2a_rename__init_A_const_14 *lang.Var

var A_arbace_c2a_rename__init_A_const_15 any

var A_arbace_c2a_rename__init_A_const_16 *lang.Var

var A_arbace_c2a_rename__init_A_const_17 *lang.Var

var A_arbace_c2a_rename__init_A_const_18 any

var A_arbace_c2a_rename__init_A_const_19 *lang.Var

var A_arbace_c2a_rename__init_A_const_20 any

var A_arbace_c2a_rename__init_A_const_21 *lang.Var

var A_arbace_c2a_rename__init_A_const_22 *lang.Var

var A_arbace_c2a_rename__init_A_const_23 any

var A_arbace_c2a_rename__init_A_const_24 *lang.Var

var A_arbace_c2a_rename__init_A_const_25 any

var A_arbace_c2a_rename__init_A_init jrt.ClassInit

func A_arbace_c2a_rename__init_A_Init() { if !A_arbace_c2a_rename__init_A_init.Done() { A_arbace_c2a_rename__init_A_init.Run(A_arbace_c2a_rename__init_A_clinit) } }

func A_arbace_c2a_rename__init_A_clinit() { A_arbace_c2a_rename__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_7, 36); A_arbace_c2a_rename__init_A_const_0 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[10]); A_arbace_c2a_rename__init_A_const_1 = A_arbace_c2a_rename__init_A_const_pool.A[11]; A_arbace_c2a_rename__init_A_const_2 = A_arbace_c2a_rename__init_A_const_pool.A[12]; A_arbace_c2a_rename__init_A_const_3 = A_arbace_c2a_rename__init_A_const_pool.A[13]; A_arbace_c2a_rename__init_A_const_4 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[14]); A_arbace_c2a_rename__init_A_const_5 = A_arbace_c2a_rename__init_A_const_pool.A[15]; A_arbace_c2a_rename__init_A_const_6 = A_arbace_c2a_rename__init_A_const_pool.A[16]; A_arbace_c2a_rename__init_A_const_7 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[17]); A_arbace_c2a_rename__init_A_const_8 = A_arbace_c2a_rename__init_A_const_pool.A[18]; A_arbace_c2a_rename__init_A_const_9 = A_arbace_c2a_rename__init_A_const_pool.A[19]; A_arbace_c2a_rename__init_A_const_10 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[20]); A_arbace_c2a_rename__init_A_const_11 = A_arbace_c2a_rename__init_A_const_pool.A[21]; A_arbace_c2a_rename__init_A_const_12 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[22]); A_arbace_c2a_rename__init_A_const_13 = A_arbace_c2a_rename__init_A_const_pool.A[23]; A_arbace_c2a_rename__init_A_const_14 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[24]); A_arbace_c2a_rename__init_A_const_15 = A_arbace_c2a_rename__init_A_const_pool.A[25]; A_arbace_c2a_rename__init_A_const_16 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[26]); A_arbace_c2a_rename__init_A_const_17 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[27]); A_arbace_c2a_rename__init_A_const_18 = A_arbace_c2a_rename__init_A_const_pool.A[28]; A_arbace_c2a_rename__init_A_const_19 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[29]); A_arbace_c2a_rename__init_A_const_20 = A_arbace_c2a_rename__init_A_const_pool.A[30]; A_arbace_c2a_rename__init_A_const_21 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[31]); A_arbace_c2a_rename__init_A_const_22 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[32]); A_arbace_c2a_rename__init_A_const_23 = A_arbace_c2a_rename__init_A_const_pool.A[33]; A_arbace_c2a_rename__init_A_const_24 = lang.Var_Cast(A_arbace_c2a_rename__init_A_const_pool.A[34]); A_arbace_c2a_rename__init_A_const_25 = A_arbace_c2a_rename__init_A_const_pool.A[35] }

func A_arbace_c2a_rename__init_A_New() *A_arbace_c2a_rename__init_A { A_arbace_c2a_rename__init_A_Init(); t := &A_arbace_c2a_rename__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rename__init_A) Ctor() {}

func (t *A_arbace_c2a_rename__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename__init_A_class }

func (t *A_arbace_c2a_rename__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename__init_A); return ok }

func A_arbace_c2a_rename__init_A_Cast(x any) *A_arbace_c2a_rename__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename__init_A_class)) }; return v }
