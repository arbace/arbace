//line aot_arbace_c2a_rename__init.ae:1
package aot_arbace_c2a_rename

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_rename__init_A_Unit0__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_rename__init_A_const_1) }
//line :1:1
func A_arbace_c2a_rename__init_A_Unit1__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_c2a_rename__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_2)) }
//line :1:1
func A_arbace_c2a_rename__init_A_Unit2__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_Init(); tmp2 = A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_c2a_rename__init_A_Unit3__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2a_rename__init_A_const_1)).Equals_O__Z(A_arbace_c2a_rename__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_Init(); tmp2 = A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_c2a_rename__init_A_Load__O() any { A_arbace_c2a_rename__init_A_Init(); A_arbace_c2a_rename__init_A_Unit0__O(); A_arbace_c2a_rename__init_A_Unit1__O(); A_arbace_c2a_rename__init_A_Unit2__O(); A_arbace_c2a_rename__init_A_Unit3__O(); A_arbace_c2a_rename__init_A_Unit4__O(); A_arbace_c2a_rename__init_A_Unit5__O(); A_arbace_c2a_rename__init_A_Unit6__O(); A_arbace_c2a_rename__init_A_Unit7__O(); A_arbace_c2a_rename__init_A_Unit8__O(); A_arbace_c2a_rename__init_A_Unit9__O(); A_arbace_c2a_rename__init_A_Unit10__O(); A_arbace_c2a_rename__init_A_Unit11__O(); A_arbace_c2a_rename__init_A_Unit12__O(); return nil }























func A_arbace_c2a_rename__init_A_Unit4__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); jrt.NN(A_arbace_c2a_rename__init_A_const_4).BindRoot_O__V(A_arbace_c2a_rename__init_A_const_5); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_6)); return A_arbace_c2a_rename__init_A_const_4.Ref() }














func A_arbace_c2a_rename__init_A_Unit5__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); jrt.NN(A_arbace_c2a_rename__init_A_const_7).BindRoot_O__V(A_arbace_c2a_rename__init_A_const_8); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_7; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_9)); return A_arbace_c2a_rename__init_A_const_7.Ref() }



func A_arbace_c2a_rename__init_A_Unit6__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_10; var tmp2 any = A_arbace_c2a_rename_alt_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rename_alt_A_Init(); tmp3 = A_arbace_c2a_rename_alt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rename__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_11)); return A_arbace_c2a_rename__init_A_const_10.Ref() }







func A_arbace_c2a_rename__init_A_Unit7__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); jrt.NN(A_arbace_c2a_rename__init_A_const_12).BindRoot_O__V(Lit_58); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_12; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_13)); return A_arbace_c2a_rename__init_A_const_12.Ref() }


func A_arbace_c2a_rename__init_A_Unit8__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); jrt.NN(A_arbace_c2a_rename__init_A_const_14).BindRoot_O__V(Lit_59); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_14; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_15)); return A_arbace_c2a_rename__init_A_const_14.Ref() }
func A_arbace_c2a_rename__init_A_Unit9__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_16; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_17).GetRawRoot__O()).Invoke_O_O_O__O(Lit_60, jrt.NN(A_arbace_c2a_rename__init_A_const_14).GetRawRoot__O(), Lit_61)); var tmp2 *lang.Var = A_arbace_c2a_rename__init_A_const_16; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_18)); return A_arbace_c2a_rename__init_A_const_16.Ref() }

func A_arbace_c2a_rename__init_A_Unit10__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_19; jrt.NN(tmp1).BindRoot_O__V(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_21).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_17).GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(jrt.NN(A_arbace_c2a_rename__init_A_const_12).GetRawRoot__O(), Lit_62, jrt.NN(A_arbace_c2a_rename__init_A_const_16).GetRawRoot__O(), Lit_60, lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_10).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_c2a_rename__init_A_const_7).GetRawRoot__O(), jrt.NN(A_arbace_c2a_rename__init_A_const_16).GetRawRoot__O()), Lit_63)), lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_21).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_17).GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(Lit_64, jrt.NN(A_arbace_c2a_rename__init_A_const_16).GetRawRoot__O(), Lit_65, jrt.NN(A_arbace_c2a_rename__init_A_const_16).GetRawRoot__O(), Lit_66, jrt.NN(A_arbace_c2a_rename__init_A_const_16).GetRawRoot__O(), Lit_67)), lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_21).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_17).GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(jrt.NN(A_arbace_c2a_rename__init_A_const_12).GetRawRoot__O(), Lit_62, jrt.NN(A_arbace_c2a_rename__init_A_const_14).GetRawRoot__O(), Lit_60, lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_10).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_c2a_rename__init_A_const_4).GetRawRoot__O(), jrt.NN(A_arbace_c2a_rename__init_A_const_14).GetRawRoot__O()), Lit_68, jrt.NN(A_arbace_c2a_rename__init_A_const_14).GetRawRoot__O(), Lit_69)), lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_21).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_17).GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(A_arbace_c2a_rename__init_A_const_12).GetRawRoot__O(), Lit_70, lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_10).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_c2a_rename__init_A_const_4).GetRawRoot__O(), Lit_71), Lit_72)))); var tmp2 *lang.Var = A_arbace_c2a_rename__init_A_const_19; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_20)); return A_arbace_c2a_rename__init_A_const_19.Ref() }












func A_arbace_c2a_rename__init_A_Unit11__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_22; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_21).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_17).GetRawRoot__O()).Invoke_O_O_O__O(Lit_73, lang.IFn_Cast(jrt.NN(A_arbace_c2a_rename__init_A_const_10).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_c2a_rename__init_A_const_4).GetRawRoot__O(), Lit_71), Lit_74))); var tmp2 *lang.Var = A_arbace_c2a_rename__init_A_const_22; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_23)); return A_arbace_c2a_rename__init_A_const_22.Ref() }




func A_arbace_c2a_rename__init_A_Unit12__O() any { A_arbace_c2a_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_c2a_rename__init_A_const_24; var tmp2 any = A_arbace_c2a_rename_rename_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rename_rename_A_Init(); tmp3 = A_arbace_c2a_rename_rename_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rename__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rename__init_A_const_25)); return A_arbace_c2a_rename__init_A_const_24.Ref() }



type A_arbace_c2a_rename__init_A struct{ jrt.Object }

var A_arbace_c2a_rename__init_A_const_0 *lang.Var

var A_arbace_c2a_rename__init_A_const_1 any

var A_arbace_c2a_rename__init_A_const_2 any

var A_arbace_c2a_rename__init_A_const_3 any

var A_arbace_c2a_rename__init_A_const_4 *lang.Var

var A_arbace_c2a_rename__init_A_const_5 any

var A_arbace_c2a_rename__init_A_const_6 any

var A_arbace_c2a_rename__init_A_const_7 *lang.Var

var A_arbace_c2a_rename__init_A_const_8 any

var A_arbace_c2a_rename__init_A_const_9 any

var A_arbace_c2a_rename__init_A_const_10 *lang.Var

var A_arbace_c2a_rename__init_A_const_11 any

var A_arbace_c2a_rename__init_A_const_12 *lang.Var

var A_arbace_c2a_rename__init_A_const_13 any

var A_arbace_c2a_rename__init_A_const_14 *lang.Var

var A_arbace_c2a_rename__init_A_const_15 any

var A_arbace_c2a_rename__init_A_const_16 *lang.Var

var A_arbace_c2a_rename__init_A_const_17 *lang.Var

var A_arbace_c2a_rename__init_A_const_18 any

var A_arbace_c2a_rename__init_A_const_19 *lang.Var

var A_arbace_c2a_rename__init_A_const_20 any

var A_arbace_c2a_rename__init_A_const_21 *lang.Var

var A_arbace_c2a_rename__init_A_const_22 *lang.Var

var A_arbace_c2a_rename__init_A_const_23 any

var A_arbace_c2a_rename__init_A_const_24 *lang.Var

var A_arbace_c2a_rename__init_A_const_25 any

var A_arbace_c2a_rename__init_A_init jrt.ClassInit

func A_arbace_c2a_rename__init_A_Init() { if !A_arbace_c2a_rename__init_A_init.Done() { A_arbace_c2a_rename__init_A_init.Run(A_arbace_c2a_rename__init_A_clinit) } }

func A_arbace_c2a_rename__init_A_clinit() { A_arbace_c2a_rename__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_c2a_rename__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_c2a_rename__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11)); A_arbace_c2a_rename__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_rename__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_9, Lit_36); A_arbace_c2a_rename__init_A_const_5 = lang.RT_Vector_O1__IPersistentVector(jrt.ConstRefArray("[0,54,s4:cores14:core.protocolss13:core.reducerss11:core.servers12:core_deftypes10:core_prints10:core_proxys8:genclasss4:gvecs4:datas6:datafys3:edns9:inspectors7:instants10:java.basiss15:java.basis.impls11:java.browses14:java.browse-uis14:java.browse_uis7:java.ios12:java.javadocs12:java.processs10:java.shells4:mains4:maths6:pprints16:pprint.cl_formats20:pprint.column_writers15:pprint.dispatchs18:pprint.pprint_bases20:pprint.pretty_writers18:pprint.print_tables16:pprint.utilitiess7:reflects12:reflect.javas4:repls9:repl.depss3:sets10:stacktraces6:strings8:templates4:tests10:test.junits8:test.taps18:tools.deps.interops4:uuids4:walks3:xmls3:zips16:core.specs.alphas9:read.evals11:main.reports5:basiss3:jar", []*jrt.Class{jrt.Object_class})); A_arbace_c2a_rename__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_41)); A_arbace_c2a_rename__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_9, Lit_42); A_arbace_c2a_rename__init_A_const_8 = lang.RT_Vector_O1__IPersistentVector(jrt.ConstRefArray("[0,8,s4:langs3:asms8:java.apis7:compiles8:compilers6:servers5:errors4:spec", []*jrt.Class{jrt.Object_class})); A_arbace_c2a_rename__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_43)); A_arbace_c2a_rename__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_44); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_c2a_rename__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_46).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_48).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_49, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40)); A_arbace_c2a_rename__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_9, Lit_50); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_c2a_rename__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(56).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40)); A_arbace_c2a_rename__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_9, Lit_51); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_c2a_rename__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40)); A_arbace_c2a_rename__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_9, Lit_52); A_arbace_c2a_rename__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_c2a_rename__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40)); A_arbace_c2a_rename__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_9, Lit_24); A_arbace_c2a_rename__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40)); A_arbace_c2a_rename__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_c2a_rename__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_9, Lit_23); A_arbace_c2a_rename__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_54)); A_arbace_c2a_rename__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_9, Lit_55); A_arbace_c2a_rename__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_46).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_57, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), Lit_40)) }

func A_arbace_c2a_rename__init_A_New() *A_arbace_c2a_rename__init_A { A_arbace_c2a_rename__init_A_Init(); t := &A_arbace_c2a_rename__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rename__init_A) Ctor() {}

func (t *A_arbace_c2a_rename__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename__init_A_class }

func (t *A_arbace_c2a_rename__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename__init_A); return ok }

func A_arbace_c2a_rename__init_A_Cast(x any) *A_arbace_c2a_rename__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename__init_A_class)) }; return v }
