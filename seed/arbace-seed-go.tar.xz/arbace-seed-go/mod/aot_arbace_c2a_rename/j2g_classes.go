//line j2g_classes.ae:1
package aot_arbace_c2a_rename

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c2a_rename_alt_A_class, Name: "arbace.c2a.rename$alt", Modifiers: 25, Simple: "alt", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_alt_A", Source: "rename.ae", Declaring: &A_arbace_c2a_rename_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rename_alt_fn__1963000013_A_class, Name: "arbace.c2a.rename$alt$fn__1963000013", Modifiers: 25, Simple: "fn__1963000013", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_alt_fn__1963000013_A", Source: "rename.ae", Declaring: &A_arbace_c2a_rename_alt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_class, Name: "arbace.c2a.rename$alt$fn__1963000013$fn__1963000014", Modifiers: 25, Simple: "fn__1963000014", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A", Source: "rename.ae", Declaring: &A_arbace_c2a_rename_alt_fn__1963000013_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_class, Name: "arbace.c2a.rename$eval1963000004$loading__1927001464__auto____1963000005", Modifiers: 25, Simple: "loading__1927001464__auto____1963000005", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A", Source: "rename.ae", Declaring: &A_arbace_c2a_rename_eval1963000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_class, Name: "arbace.c2a.rename$eval1963000008$fn__1963000009", Modifiers: 25, Simple: "fn__1963000009", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000008_fn__1963000009_A", Source: "rename.ae", Declaring: &A_arbace_c2a_rename_eval1963000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rename_rename_A_class, Name: "arbace.c2a.rename$rename", Modifiers: 25, Simple: "rename", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_rename_A", Source: "rename.ae", Declaring: &A_arbace_c2a_rename_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rename_rename_fn__1963000018_A_class, Name: "arbace.c2a.rename$rename$fn__1963000018", Modifiers: 25, Simple: "fn__1963000018", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_rename_fn__1963000018_A", Source: "rename.ae", Declaring: &A_arbace_c2a_rename_rename_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c2a_rename_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_A_New()}; return nil }

var A_arbace_c2a_rename_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rename_A_new}

var A_arbace_c2a_rename_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_A"})

func init() { i := A_arbace_c2a_rename_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_A_InstanceOf; i.Init = A_arbace_c2a_rename_A_Init; i.Table = A_arbace_c2a_rename_A_members }

var A_arbace_c2a_rename_alt_A_class *jrt.Class

var A_arbace_c2a_rename_alt_fn__1963000013_A_class *jrt.Class

var A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_class *jrt.Class

func A_arbace_c2a_rename_eval1963000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_eval1963000004_A_New()}; return nil }

var A_arbace_c2a_rename_eval1963000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rename_eval1963000004_A_new}

var A_arbace_c2a_rename_eval1963000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$eval1963000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rename_A_class, Simple: "eval1963000004", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000004_A"})

func init() { i := A_arbace_c2a_rename_eval1963000004_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_eval1963000004_A_InstanceOf; i.Table = A_arbace_c2a_rename_eval1963000004_A_members }

var A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_class *jrt.Class

func A_arbace_c2a_rename_eval1963000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_eval1963000008_A_New()}; return nil }

var A_arbace_c2a_rename_eval1963000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rename_eval1963000008_A_new}

var A_arbace_c2a_rename_eval1963000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$eval1963000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rename_A_class, Simple: "eval1963000008", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000008_A"})

func init() { i := A_arbace_c2a_rename_eval1963000008_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_eval1963000008_A_InstanceOf; i.Table = A_arbace_c2a_rename_eval1963000008_A_members }

var A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_class *jrt.Class

var A_arbace_c2a_rename_rename_A_class *jrt.Class

var A_arbace_c2a_rename_rename_fn__1963000018_A_class *jrt.Class

func A_arbace_c2a_rename__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_rename__init_A_Load__O()}; return nil }

func A_arbace_c2a_rename__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename__init_A_New()}; return nil }

var A_arbace_c2a_rename__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_rename__init_A_invoke, New: A_arbace_c2a_rename__init_A_new}

var A_arbace_c2a_rename__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename__init_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename__init_A_class.Info(); i.IsInstance = A_arbace_c2a_rename__init_A_InstanceOf; i.Init = A_arbace_c2a_rename__init_A_Init; i.Table = A_arbace_c2a_rename__init_A_members }
