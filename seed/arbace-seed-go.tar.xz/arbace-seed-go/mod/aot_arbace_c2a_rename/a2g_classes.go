//line a2g_classes.ae:1
package aot_arbace_c2a_rename

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_c2a_rename_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_A_New()}; return nil }

var A_arbace_c2a_rename_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rename_A_new}

var A_arbace_c2a_rename_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_A"})

func init() { i := A_arbace_c2a_rename_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_A_InstanceOf; i.Init = A_arbace_c2a_rename_A_Init; i.Table = A_arbace_c2a_rename_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_A_class, reflect.TypeFor[A_arbace_c2a_rename_A]()) }

func A_arbace_c2a_rename_alt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rename_alt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rename_alt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_alt_A_New()}; return nil }

func A_arbace_c2a_rename_alt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rename_alt_A_fn_class)}; return nil }

var A_arbace_c2a_rename_alt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rename_alt_A_invoke, New: A_arbace_c2a_rename_alt_A_new, Get: A_arbace_c2a_rename_alt_A_get}

var A_arbace_c2a_rename_alt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$alt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rename_A_class, Simple: "alt", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_alt_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename_alt_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_alt_A_InstanceOf; i.Init = A_arbace_c2a_rename_alt_A_Init; i.Table = A_arbace_c2a_rename_alt_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_alt_A_class, reflect.TypeFor[A_arbace_c2a_rename_alt_A]()) }

func A_arbace_c2a_rename_alt_fn__1963000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rename_alt_fn__1963000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rename_alt_fn__1963000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_alt_fn__1963000013_A_New_O(args[0])}; return nil }

func A_arbace_c2a_rename_alt_fn__1963000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rename_alt_fn__1963000013_A_fn_class)}; return nil }

var A_arbace_c2a_rename_alt_fn__1963000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rename_alt_fn__1963000013_A_invoke, New: A_arbace_c2a_rename_alt_fn__1963000013_A_new, Get: A_arbace_c2a_rename_alt_fn__1963000013_A_get}

var A_arbace_c2a_rename_alt_fn__1963000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$alt$fn__1963000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rename_alt_A_class, Simple: "fn__1963000013", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_alt_fn__1963000013_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename_alt_fn__1963000013_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_alt_fn__1963000013_A_InstanceOf; i.Init = A_arbace_c2a_rename_alt_fn__1963000013_A_Init; i.Table = A_arbace_c2a_rename_alt_fn__1963000013_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_alt_fn__1963000013_A_class, reflect.TypeFor[A_arbace_c2a_rename_alt_fn__1963000013_A]()) }

func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_New()}; return nil }

func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_fn_class)}; return nil }

var A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_invoke, New: A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_new, Get: A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_get}

var A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$alt$fn__1963000013$fn__1963000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rename_alt_fn__1963000013_A_class, Simple: "fn__1963000014", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_InstanceOf; i.Init = A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_Init; i.Table = A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_class, reflect.TypeFor[A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A]()) }

func A_arbace_c2a_rename_eval1963000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_eval1963000004_A_New()}; return nil }

var A_arbace_c2a_rename_eval1963000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rename_eval1963000004_A_new}

var A_arbace_c2a_rename_eval1963000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$eval1963000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rename_A_class, Simple: "eval1963000004", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000004_A"})

func init() { i := A_arbace_c2a_rename_eval1963000004_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_eval1963000004_A_InstanceOf; i.Table = A_arbace_c2a_rename_eval1963000004_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_eval1963000004_A_class, reflect.TypeFor[A_arbace_c2a_rename_eval1963000004_A]()) }

func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_New()}; return nil }

func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_fn_class)}; return nil }

var A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_invoke, New: A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_new, Get: A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_get}

var A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$eval1963000004$loading__1927001464__auto____1963000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rename_eval1963000004_A_class, Simple: "loading__1927001464__auto____1963000005", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_InstanceOf; i.Init = A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_Init; i.Table = A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_class, reflect.TypeFor[A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A]()) }

func A_arbace_c2a_rename_eval1963000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_eval1963000008_A_New()}; return nil }

var A_arbace_c2a_rename_eval1963000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rename_eval1963000008_A_new}

var A_arbace_c2a_rename_eval1963000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$eval1963000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rename_A_class, Simple: "eval1963000008", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000008_A"})

func init() { i := A_arbace_c2a_rename_eval1963000008_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_eval1963000008_A_InstanceOf; i.Table = A_arbace_c2a_rename_eval1963000008_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_eval1963000008_A_class, reflect.TypeFor[A_arbace_c2a_rename_eval1963000008_A]()) }

func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rename_eval1963000008_fn__1963000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_New()}; return nil }

func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_fn_class)}; return nil }

var A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_invoke, New: A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_new, Get: A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_get}

var A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$eval1963000008$fn__1963000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rename_eval1963000008_A_class, Simple: "fn__1963000009", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_eval1963000008_fn__1963000009_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_InstanceOf; i.Init = A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_Init; i.Table = A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_class, reflect.TypeFor[A_arbace_c2a_rename_eval1963000008_fn__1963000009_A]()) }

func A_arbace_c2a_rename_rename_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rename_rename_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rename_rename_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_rename_A_New()}; return nil }

func A_arbace_c2a_rename_rename_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rename_rename_A_fn_class)}; return nil }

var A_arbace_c2a_rename_rename_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rename_rename_A_invoke, New: A_arbace_c2a_rename_rename_A_new, Get: A_arbace_c2a_rename_rename_A_get}

var A_arbace_c2a_rename_rename_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$rename", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rename_A_class, Simple: "rename", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_rename_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename_rename_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_rename_A_InstanceOf; i.Init = A_arbace_c2a_rename_rename_A_Init; i.Table = A_arbace_c2a_rename_rename_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_rename_A_class, reflect.TypeFor[A_arbace_c2a_rename_rename_A]()) }

func A_arbace_c2a_rename_rename_fn__1963000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rename_rename_fn__1963000018_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rename_rename_fn__1963000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename_rename_fn__1963000018_A_New()}; return nil }

func A_arbace_c2a_rename_rename_fn__1963000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rename_rename_fn__1963000018_A_fn_class)}; return nil }

var A_arbace_c2a_rename_rename_fn__1963000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rename_rename_fn__1963000018_A_invoke, New: A_arbace_c2a_rename_rename_fn__1963000018_A_new, Get: A_arbace_c2a_rename_rename_fn__1963000018_A_get}

var A_arbace_c2a_rename_rename_fn__1963000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename$rename$fn__1963000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rename_rename_A_class, Simple: "fn__1963000018", Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename_rename_fn__1963000018_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename_rename_fn__1963000018_A_class.Info(); i.IsInstance = A_arbace_c2a_rename_rename_fn__1963000018_A_InstanceOf; i.Init = A_arbace_c2a_rename_rename_fn__1963000018_A_Init; i.Table = A_arbace_c2a_rename_rename_fn__1963000018_A_members; jrt.RegisterGoType(A_arbace_c2a_rename_rename_fn__1963000018_A_class, reflect.TypeFor[A_arbace_c2a_rename_rename_fn__1963000018_A]()) }

func A_arbace_c2a_rename__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_rename__init_A_Load__O(); case 1: return A_arbace_c2a_rename__init_A_Unit0__O(); case 2: return A_arbace_c2a_rename__init_A_Unit1__O(); case 3: return A_arbace_c2a_rename__init_A_Unit10__O(); case 4: return A_arbace_c2a_rename__init_A_Unit11__O(); case 5: return A_arbace_c2a_rename__init_A_Unit12__O(); case 6: return A_arbace_c2a_rename__init_A_Unit2__O(); case 7: return A_arbace_c2a_rename__init_A_Unit3__O(); case 8: return A_arbace_c2a_rename__init_A_Unit4__O(); case 9: return A_arbace_c2a_rename__init_A_Unit5__O(); case 10: return A_arbace_c2a_rename__init_A_Unit6__O(); case 11: return A_arbace_c2a_rename__init_A_Unit7__O(); case 12: return A_arbace_c2a_rename__init_A_Unit8__O(); case 13: return A_arbace_c2a_rename__init_A_Unit9__O()}; return nil }

func A_arbace_c2a_rename__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rename__init_A_New()}; return nil }

var A_arbace_c2a_rename__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_rename__init_A_invoke, New: A_arbace_c2a_rename__init_A_new}

var A_arbace_c2a_rename__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rename__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rename.A_arbace_c2a_rename__init_A", Source: "rename.ae"})

func init() { i := A_arbace_c2a_rename__init_A_class.Info(); i.IsInstance = A_arbace_c2a_rename__init_A_InstanceOf; i.Init = A_arbace_c2a_rename__init_A_Init; i.Table = A_arbace_c2a_rename__init_A_members; jrt.RegisterGoType(A_arbace_c2a_rename__init_A_class, reflect.TypeFor[A_arbace_c2a_rename__init_A]()) }
