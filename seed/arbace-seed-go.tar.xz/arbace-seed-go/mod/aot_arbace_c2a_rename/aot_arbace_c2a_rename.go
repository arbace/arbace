//line aot_arbace_c2a_rename.ae:1
package aot_arbace_c2a_rename

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_New() *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A { A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_Init(); t := &A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp4 = A_arbace_c2a_rename_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_c2a_rename_A_Init(); tmp6 = A_arbace_c2a_rename_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp7 = A_arbace_c2a_rename_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_c2a_rename_A_Init(); tmp9 = A_arbace_c2a_rename_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :1:1
func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_New() *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A { A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_Init(); t := &A_arbace_c2a_rename_eval1963000008_fn__1963000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp1 = A_arbace_c2a_rename_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp3 = A_arbace_c2a_rename_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp5 = A_arbace_c2a_rename_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp7 = A_arbace_c2a_rename_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_c2a_rename_A_Init(); tmp9 = A_arbace_c2a_rename_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }














































func A_arbace_c2a_rename_alt_A_New() *A_arbace_c2a_rename_alt_A { A_arbace_c2a_rename_alt_A_Init(); t := &A_arbace_c2a_rename_alt_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_c2a_rename_alt_A) Ctor() {}
//line :48:1
func (t *A_arbace_c2a_rename_alt_A) Invoke_O_O_O__O(self, names__0, sep__1 any) any {





	var tmp1 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp1 = A_arbace_c2a_rename_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp3 = A_arbace_c2a_rename_A_const_10; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_c2a_rename_alt_fn__1963000013_A_New_O(sep__1); var tmp6 *jrt.Class; A_arbace_c2a_rename_alt_fn__1963000013_A_Init(); tmp6 = A_arbace_c2a_rename_alt_fn__1963000013_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp8 = A_arbace_c2a_rename_A_const_13; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp10 = A_arbace_c2a_rename_A_const_14; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp12 = A_arbace_c2a_rename_A_const_15; var tmp13 any = jrt.NN(tmp12).GetRawRoot__O(); var tmp14 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp14 = A_arbace_c2a_rename_A_const_16; return tmp2.Invoke_O_O__O(Lit_26, tmp4.Invoke_O_O__O(tmp7, tmp9.Invoke_O_O__O(tmp11.Invoke_O_O__O(tmp13, jrt.NN(tmp14).GetRawRoot__O()), names__0))) }
//line :53:1
func A_arbace_c2a_rename_alt_fn__1963000013_A_New_O(p0 any) *A_arbace_c2a_rename_alt_fn__1963000013_A { A_arbace_c2a_rename_alt_fn__1963000013_A_Init(); t := &A_arbace_c2a_rename_alt_fn__1963000013_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) Ctor_O(c__sep any) { t.F_sep = c__sep }
//line :53:1
func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp1 = A_arbace_c2a_rename_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_sep; var tmp4 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp4 = A_arbace_c2a_rename_A_const_10; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_New(); var tmp7 *jrt.Class; A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_Init(); tmp7 = A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_fn_class; var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp9 = A_arbace_c2a_rename_A_const_11; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_c2a_rename_A_Init(); tmp11 = A_arbace_c2a_rename_A_const_12; return tmp2.Invoke_O_O__O(tmp3, tmp5.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(n__1, tmp11))) }
//line :53:1
func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_New() *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A { A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_Init(); t := &A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) Ctor() {}
//line :53:1
func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) Invoke_O_O__O(self, p1__1963000012_SHARP___1 any) any { return jrt.Pattern_Quote_String__String(jrt.String_Cast(p1__1963000012_SHARP___1)).Ref() }


























func A_arbace_c2a_rename_rename_A_New() *A_arbace_c2a_rename_rename_A { A_arbace_c2a_rename_rename_A_Init(); t := &A_arbace_c2a_rename_rename_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_c2a_rename_rename_A) Ctor() {}
//line :80:1
func (t *A_arbace_c2a_rename_rename_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp1 = A_arbace_c2a_rename_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp3 = A_arbace_c2a_rename_A_const_18; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_c2a_rename_rename_fn__1963000018_A_New(); var tmp6 *jrt.Class; A_arbace_c2a_rename_rename_fn__1963000018_A_Init(); tmp6 = A_arbace_c2a_rename_rename_fn__1963000018_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp8 = A_arbace_c2a_rename_A_const_20; var tmp9 any = tmp4.Invoke_O_O_O__O(tmp7, s__0, jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp10 = A_arbace_c2a_rename_A_const_19; return tmp2.Invoke_O_O_O__O(tmp9, jrt.NN(tmp10).GetRawRoot__O(), Lit_32) }
//line :83:1
func A_arbace_c2a_rename_rename_fn__1963000018_A_New() *A_arbace_c2a_rename_rename_fn__1963000018_A { A_arbace_c2a_rename_rename_fn__1963000018_A_Init(); t := &A_arbace_c2a_rename_rename_fn__1963000018_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) Ctor() {}
//line :83:1
func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) Invoke_O_O_O__O(self, s__1, p__2 any) any { var tmp1 *lang.Var; A_arbace_c2a_rename_A_Init(); tmp1 = A_arbace_c2a_rename_A_const_17; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(s__1, p__2, Lit_34) }










type A_arbace_c2a_rename_A struct{ jrt.Object }

var A_arbace_c2a_rename_A_const_0 *lang.Var

var A_arbace_c2a_rename_A_const_1 *lang.Var

var A_arbace_c2a_rename_A_const_2 any

var A_arbace_c2a_rename_A_const_3 any

var A_arbace_c2a_rename_A_const_4 *lang.Var

var A_arbace_c2a_rename_A_const_5 *lang.Var

var A_arbace_c2a_rename_A_const_6 *lang.Var

var A_arbace_c2a_rename_A_const_7 any

var A_arbace_c2a_rename_A_const_8 *lang.Var

var A_arbace_c2a_rename_A_const_9 *lang.Var

var A_arbace_c2a_rename_A_const_10 *lang.Var

var A_arbace_c2a_rename_A_const_11 *lang.Var

var A_arbace_c2a_rename_A_const_12 any

var A_arbace_c2a_rename_A_const_13 *lang.Var

var A_arbace_c2a_rename_A_const_14 *lang.Var

var A_arbace_c2a_rename_A_const_15 *lang.Var

var A_arbace_c2a_rename_A_const_16 *lang.Var

var A_arbace_c2a_rename_A_const_17 *lang.Var

var A_arbace_c2a_rename_A_const_18 *lang.Var

var A_arbace_c2a_rename_A_const_19 *lang.Var

var A_arbace_c2a_rename_A_const_20 *lang.Var

var A_arbace_c2a_rename_A_init jrt.ClassInit

func A_arbace_c2a_rename_A_Init() { if !A_arbace_c2a_rename_A_init.Done() { A_arbace_c2a_rename_A_init.Run(A_arbace_c2a_rename_A_clinit) } }

func A_arbace_c2a_rename_A_clinit() { A_arbace_c2a_rename_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_c2a_rename_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_c2a_rename_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_rename_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_c2a_rename_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_c2a_rename_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_c2a_rename_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_c2a_rename_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_c2a_rename_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_c2a_rename_A_const_9 = lang.RT_Var_String_String__Var(Lit_3, Lit_13); A_arbace_c2a_rename_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_c2a_rename_A_const_11 = lang.RT_Var_String_String__Var(Lit_3, Lit_15); A_arbace_c2a_rename_A_const_12 = jrt.Pattern_Compile_String__Pattern(Lit_16).Ref(); A_arbace_c2a_rename_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_c2a_rename_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_c2a_rename_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_c2a_rename_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_c2a_rename_A_const_17 = lang.RT_Var_String_String__Var(Lit_3, Lit_21); A_arbace_c2a_rename_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_c2a_rename_A_const_19 = lang.RT_Var_String_String__Var(Lit_9, Lit_23); A_arbace_c2a_rename_A_const_20 = lang.RT_Var_String_String__Var(Lit_9, Lit_24) }

func A_arbace_c2a_rename_A_New() *A_arbace_c2a_rename_A { A_arbace_c2a_rename_A_Init(); t := &A_arbace_c2a_rename_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rename_A) Ctor() {}

func (t *A_arbace_c2a_rename_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_A_class }

func (t *A_arbace_c2a_rename_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_A); return ok }

func A_arbace_c2a_rename_A_Cast(x any) *A_arbace_c2a_rename_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_A_class)) }; return v }



type A_arbace_c2a_rename_alt_A struct{ jrt.Object }

func (t *A_arbace_c2a_rename_alt_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rename_alt_A_fn_class *jrt.Class

var A_arbace_c2a_rename_alt_A_init jrt.ClassInit

func A_arbace_c2a_rename_alt_A_Init() { if !A_arbace_c2a_rename_alt_A_init.Done() { A_arbace_c2a_rename_alt_A_init.Run(A_arbace_c2a_rename_alt_A_clinit) } }

func A_arbace_c2a_rename_alt_A_clinit() { A_arbace_c2a_rename_alt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_25, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rename_alt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_alt_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_alt_A_class }

func (t *A_arbace_c2a_rename_alt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_alt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_alt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_alt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_alt_A); return ok }

func A_arbace_c2a_rename_alt_A_Cast(x any) *A_arbace_c2a_rename_alt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_alt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_alt_A_class)) }; return v }



type A_arbace_c2a_rename_alt_fn__1963000013_A struct{ jrt.Object; F_sep any }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rename_alt_fn__1963000013_A_fn_class *jrt.Class

var A_arbace_c2a_rename_alt_fn__1963000013_A_init jrt.ClassInit

func A_arbace_c2a_rename_alt_fn__1963000013_A_Init() { if !A_arbace_c2a_rename_alt_fn__1963000013_A_init.Done() { A_arbace_c2a_rename_alt_fn__1963000013_A_init.Run(A_arbace_c2a_rename_alt_fn__1963000013_A_clinit) } }

func A_arbace_c2a_rename_alt_fn__1963000013_A_clinit() { A_arbace_c2a_rename_alt_fn__1963000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_27, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_alt_fn__1963000013_A_class }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_alt_fn__1963000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_alt_fn__1963000013_A); return ok }

func A_arbace_c2a_rename_alt_fn__1963000013_A_Cast(x any) *A_arbace_c2a_rename_alt_fn__1963000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_alt_fn__1963000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_alt_fn__1963000013_A_class)) }; return v }



type A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A struct{ jrt.Object }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_fn_class *jrt.Class

var A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_init jrt.ClassInit

func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_Init() { if !A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_init.Done() { A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_init.Run(A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_clinit) } }

func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_clinit() { A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_28, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_class }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A); return ok }

func A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_Cast(x any) *A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_alt_fn__1963000013_fn__1963000014_A_class)) }; return v }



type A_arbace_c2a_rename_eval1963000004_A struct{ jrt.Object }

func A_arbace_c2a_rename_eval1963000004_A_New() *A_arbace_c2a_rename_eval1963000004_A { t := &A_arbace_c2a_rename_eval1963000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rename_eval1963000004_A) Ctor() {}

func (t *A_arbace_c2a_rename_eval1963000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_eval1963000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_eval1963000004_A_class }

func (t *A_arbace_c2a_rename_eval1963000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_eval1963000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_eval1963000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_eval1963000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_eval1963000004_A); return ok }

func A_arbace_c2a_rename_eval1963000004_A_Cast(x any) *A_arbace_c2a_rename_eval1963000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_eval1963000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_eval1963000004_A_class)) }; return v }



type A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A struct{ jrt.Object }

func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_fn_class *jrt.Class

var A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_init jrt.ClassInit

func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_Init() { if !A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_init.Done() { A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_init.Run(A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_clinit) } }

func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_clinit() { A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_29, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_class }

func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A); return ok }

func A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_Cast(x any) *A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_eval1963000004_loading__1927001464__auto____1963000005_A_class)) }; return v }



type A_arbace_c2a_rename_eval1963000008_A struct{ jrt.Object }

func A_arbace_c2a_rename_eval1963000008_A_New() *A_arbace_c2a_rename_eval1963000008_A { t := &A_arbace_c2a_rename_eval1963000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rename_eval1963000008_A) Ctor() {}

func (t *A_arbace_c2a_rename_eval1963000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_eval1963000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_eval1963000008_A_class }

func (t *A_arbace_c2a_rename_eval1963000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_eval1963000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_eval1963000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_eval1963000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_eval1963000008_A); return ok }

func A_arbace_c2a_rename_eval1963000008_A_Cast(x any) *A_arbace_c2a_rename_eval1963000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_eval1963000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_eval1963000008_A_class)) }; return v }



type A_arbace_c2a_rename_eval1963000008_fn__1963000009_A struct{ jrt.Object }

func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_fn_class *jrt.Class

var A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_init jrt.ClassInit

func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_Init() { if !A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_init.Done() { A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_init.Run(A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_clinit) } }

func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_clinit() { A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_30, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_class }

func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_eval1963000008_fn__1963000009_A); return ok }

func A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_Cast(x any) *A_arbace_c2a_rename_eval1963000008_fn__1963000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_eval1963000008_fn__1963000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_eval1963000008_fn__1963000009_A_class)) }; return v }



type A_arbace_c2a_rename_rename_A struct{ jrt.Object }

func (t *A_arbace_c2a_rename_rename_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rename_rename_A_fn_class *jrt.Class

var A_arbace_c2a_rename_rename_A_init jrt.ClassInit

func A_arbace_c2a_rename_rename_A_Init() { if !A_arbace_c2a_rename_rename_A_init.Done() { A_arbace_c2a_rename_rename_A_init.Run(A_arbace_c2a_rename_rename_A_clinit) } }

func A_arbace_c2a_rename_rename_A_clinit() { A_arbace_c2a_rename_rename_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_31, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rename_rename_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_rename_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_rename_A_class }

func (t *A_arbace_c2a_rename_rename_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_rename_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_rename_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_rename_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_rename_A); return ok }

func A_arbace_c2a_rename_rename_A_Cast(x any) *A_arbace_c2a_rename_rename_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_rename_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_rename_A_class)) }; return v }



type A_arbace_c2a_rename_rename_fn__1963000018_A struct{ jrt.Object }

func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rename_rename_fn__1963000018_A_fn_class *jrt.Class

var A_arbace_c2a_rename_rename_fn__1963000018_A_init jrt.ClassInit

func A_arbace_c2a_rename_rename_fn__1963000018_A_Init() { if !A_arbace_c2a_rename_rename_fn__1963000018_A_init.Done() { A_arbace_c2a_rename_rename_fn__1963000018_A_init.Run(A_arbace_c2a_rename_rename_fn__1963000018_A_clinit) } }

func A_arbace_c2a_rename_rename_fn__1963000018_A_clinit() { A_arbace_c2a_rename_rename_fn__1963000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_33, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rename_rename_fn__1963000018_A_class }

func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rename_rename_fn__1963000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rename_rename_fn__1963000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rename_rename_fn__1963000018_A); return ok }

func A_arbace_c2a_rename_rename_fn__1963000018_A_Cast(x any) *A_arbace_c2a_rename_rename_fn__1963000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rename_rename_fn__1963000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rename_rename_fn__1963000018_A_class)) }; return v }
