//line j2g_strings.ae:1
package aot_arbace_repr_go_print

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn25,arbace.repr.go.print-codekn2,asyn4,codeyn25,arbace.repr.go.print-emityn1,eyn13,arbace.stringyn3,strkn3,dockn7,requireyn9,arbace.gokn4,elsekn7,aliaseskn7,packagekn4,namekn5,fileskn4,filekn4,optskn5,declskn3,srckn4,formkn4,pathyn2,nskn5,aliaskn6,lparenkn6,rparenks2,go3,poskn7,tok-poskn3,sepkn8,name-posks2,go3,endkn7,resultskn6,externkn6,lines?kn4,linekn10,cur-indentkn3,bolkn16,line-directives?kn7,importskn4,fullkn8,commentsks2,go8,commentskn5,spaceks2,go5,spacekn5,semisks2,go5,semiskn6,trailsks2,go6,trailskn4,tailks2,go4,tailkn6,layoutkn9,line-filekn5,lineskn5,gofmtkn5,buildkn10,directiveskn11,other-fileskn11,embed-fileskn3,cgokn4,gooskn6,goarchkn7,goamd64kn7,goarm64kn12,goexperimentkn6,configkn4,tagskn9,positionsv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn20,arbace.repr.go.printm2,R8,s1794,repr/go's printer: Go forms (doc/go/SPEC.md) to Go source, milestone G2\n  (doc/go/PRINTER-NOTES.md).\n\n  bin/repr-go print [OPTIONS] FORMS.ae OUTDIR\n    Reads the package file FORMS.ae (its ns, go/package and load forms, and the files it\n    loads; or one file holding go/file forms and declarations) with *read-eval* false and\n    writes one Go file per go/file into OUTDIR.\n    --layout lines|gofmt|full\n                          lines (default when the forms carry lines): each form on its\n                          recorded line (§10.1, §12.3); gofmt: gofmt's layout, lines ignored;\n                          full (default for a package of :positions :full): every token at\n                          its recorded line and column, with the file's comments and white\n                          space: the original text (§10.2, §12.3)\n    --no-line-directives  never write //line or /*line*/ directives for lines layout cannot\n                          reach\n    --src DIR             the original package directory: copies :other-files and\n                          :embed-files (hashes checked) into OUTDIR, and writes\n                          OUTDIR/overlay.json mapping DIR's Go files to the printed ones\n    --build               then compiles the package as §12.4 says: the toolchain of\n                          $ARBACE_GOROOT (default /root/tamago-go), the :config's environment,\n                          -trimpath, go build -overlay, in DIR\n    --gofmt               run each printed file through $ARBACE_GOROOT/bin/gofmt\n    --line-file           (layout lines) start each file with //line FORMS-FILE:1, so that\n                          gc's positions name the forms file and its lines (§12.3)\n\n  The library: print-package, print-forms (forms in memory to {name text}), print-file.v11,arbace.core13,*loaded-libs*v11,arbace.core3,strv11,arbace.core4,readv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core4,intoS2,s9,arbace.gos2,gov11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,seq?R9,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core7,vector?R10,v11,arbace.core5,applyR2,v11,arbace.core4,restv11,arbace.core12,chunk-appendv11,arbace.core4,namev11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core6,concatv25,arbace.repr.go.print-code2,opv11,arbace.core6,updatev11,arbace.core4,nextv11,arbace.core5,assocv13,arbace.string12,starts-with?v11,arbace.core6,empty?v11,arbace.core7,ex-infoR11,v25,arbace.repr.go.print-code7,*go-ns*R12,v20,arbace.repr.go.print13,go-ns-aliasesR13,R14,R15,R16,R17,R18,R19,v20,arbace.repr.go.print5,*src*v11,arbace.core6,pr-strR20,v11,arbace.core3,popv11,arbace.core4,peekv11,arbace.core9,volatile!S2,s9,arbace.gos2,gov20,arbace.repr.go.print17,new-package-statev11,arbace.core6,dissocv20,arbace.repr.go.print8,add-formR21,v11,arbace.core4,subsl1,R22,v11,arbace.core6,re-seqv11,arbace.core7,vreset!p2,\\.v11,arbace.core6,secondv11,arbace.core7,iteratev20,arbace.repr.go.print7,collectv20,arbace.repr.go.print10,read-formsR23,S2,s1,_s1,.v25,arbace.repr.go.print-emit3,tokv25,arbace.repr.go.print-emit2,spv25,arbace.repr.go.print-text9,go-stringv25,arbace.repr.go.print-emit2,nlv20,arbace.repr.go.print11,import-specl0,v11,arbace.core10,split-withv25,arbace.repr.go.print-emit12,comment-linev11,arbace.core10,complementv20,arbace.repr.go.print17,write-import-declv11,arbace.core3,vecR24,v25,arbace.repr.go.print-code5,ptok*R25,R26,v25,arbace.repr.go.print-code5,expr0R27,v25,arbace.repr.go.print-emit4,softS2,s1,_s1,.R28,R29,S2,s1,_s1,.S2,s9,go/methods7,go/funcR30,v25,arbace.repr.go.print-code15,parse-decl-headR31,v11,arbace.core5,nnextv11,arbace.core3,notR32,v25,arbace.repr.go.print-code23,decl-doc-and-directivesv25,arbace.repr.go.print-code9,pre-linesv11,arbace.core4,someR33,v25,arbace.repr.go.print-emit3,*p*R34,v11,arbace.core8,integer?v20,arbace.repr.go.print8,decl-prev11,arbace.core6,subvecv20,arbace.repr.go.print14,one-line-func?R35,R36,v25,arbace.repr.go.print-code8,top-declv25,arbace.repr.go.print-emit6,*next*v20,arbace.repr.go.print11,next-targetv20,arbace.repr.go.print9,decl-sep!v25,arbace.repr.go.print-code9,write-prev11,arbace.core4,not=R37,v25,arbace.repr.go.print-emit18,line-directive-ownv20,arbace.repr.go.print9,chunk-minv11,arbace.core4,compv11,arbace.core5,rangev11,arbace.core3,mapv11,arbace.core6,removev11,arbace.core8,distinctv11,arbace.core6,filterv11,arbace.core4,nil?v11,arbace.core4,mapvv25,arbace.repr.go.print-code9,wrap-fullv25,arbace.repr.go.print-emit6,resultR38,v25,arbace.repr.go.print-emit9,new-statev25,arbace.repr.go.print-code17,*explicit-groups*v25,arbace.repr.go.print-code13,uses-grouped?R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,v20,arbace.repr.go.print18,write-imports-fullv11,arbace.core8,to-arrayR50,R51,v20,arbace.repr.go.print15,print-file-fullR52,R53,v25,arbace.repr.go.print-emit9,set-line!v25,arbace.repr.go.print-code9,write-docv20,arbace.repr.go.print13,write-importsv20,arbace.repr.go.print12,chunk-startsv11,arbace.core4,pmapR54,R55,R8,v20,arbace.repr.go.print11,print-decl!v11,arbace.core6,vectorv25,arbace.repr.go.print-emit11,chunk-statev25,arbace.repr.go.print-emit9,start-at!v25,arbace.repr.go.print-emit5,join!v11,arbace.core10,sorted-mapv20,arbace.repr.go.print10,print-filev11,arbace.core6,formatv11,arbace.core10,into-arrayC24,java.nio.file.CopyOptionv13,arbace.string7,replacev11,arbace.core4,spitR56,v20,arbace.repr.go.print9,copy-fileR57,v20,arbace.repr.go.print6,sha256v13,arbace.string4,joinv20,arbace.repr.go.print11,json-stringR58,R59,R60,R61,R62,v11,arbace.core5,some?R63,v11,arbace.core5,slurpR64,R65,v20,arbace.repr.go.print3,runV1,s1,.v20,arbace.repr.go.print9,build-envv20,arbace.repr.go.print11,print-formsv11,arbace.core4,keysR66,v20,arbace.repr.go.print13,print-packagev11,arbace.core15,shutdown-agentsv11,arbace.core7,keywordv11,arbace.core7,printlnv20,arbace.repr.go.print5,buildv20,arbace.repr.go.print10,gofmt-filev20,arbace.repr.go.print10,copy-filesv11,arbace.core5,printv11,arbace.core5,flush")

var Lit_1 *jrt.String = jrt.Intern("ARBACE_GOROOT")

var Lit_2 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_3 *jrt.String = jrt.Intern("--layout")

var Lit_4 *jrt.String = jrt.Intern("--src")

var Lit_5 *jrt.String = jrt.Intern("--build")

var Lit_6 *jrt.String = jrt.Intern("--gofmt")

var Lit_7 *jrt.String = jrt.Intern("--line-file")

var Lit_8 *jrt.String = jrt.Intern("--no-line-directives")

var Lit_9 *jrt.String = jrt.Intern("usage: bin/repr-go print [--layout lines|gofmt|full] [--no-line-directives] [--line-file] [--src DIR [--build]] [--gofmt] FORMS.ae OUTDIR")

var Lit_10 *jrt.String = jrt.Intern("/")

var Lit_11 *jrt.String = jrt.Intern("ns")

var Lit_12 *jrt.String = jrt.Intern("in-ns")

var Lit_13 *jrt.String = jrt.Intern("load")

var Lit_14 *jrt.String = jrt.Intern("go/package")

var Lit_15 *jrt.String = jrt.Intern("go/file")

var Lit_16 *jrt.String = jrt.Intern("go/")

var Lit_17 *jrt.String = jrt.Intern("a declaration before any go/file: ")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.print$add_form$fn__1344000040")

var Lit_19 *jrt.String = jrt.Intern("not a Go forms top-level form: ")

var Lit_20 *jrt.String = jrt.Intern("/bin/go")

var Lit_21 *jrt.String = jrt.Intern("build")

var Lit_22 *jrt.String = jrt.Intern("-trimpath")

var Lit_23 *jrt.String = jrt.Intern("-overlay")

var Lit_24 *jrt.String = jrt.Intern("overlay.json")

var Lit_25 *jrt.String = jrt.Intern("-tags")

var Lit_26 *jrt.String = jrt.Intern(",")

var Lit_27 *jrt.String = jrt.Intern("GOROOT")

var Lit_28 *jrt.String = jrt.Intern("GOTOOLCHAIN")

var Lit_29 *jrt.String = jrt.Intern("local")

var Lit_30 *jrt.String = jrt.Intern("GOFLAGS")

var Lit_31 *jrt.String = jrt.Intern("")

var Lit_32 *jrt.String = jrt.Intern("GOWORK")

var Lit_33 *jrt.String = jrt.Intern("off")

var Lit_34 *jrt.String = jrt.Intern("CGO_ENABLED")

var Lit_35 *jrt.String = jrt.Intern("1")

var Lit_36 *jrt.String = jrt.Intern("0")

var Lit_37 *jrt.String = jrt.Intern("GOOS")

var Lit_38 *jrt.String = jrt.Intern("GOARCH")

var Lit_39 *jrt.String = jrt.Intern("GOAMD64")

var Lit_40 *jrt.String = jrt.Intern("GOARM64")

var Lit_41 *jrt.String = jrt.Intern("GOEXPERIMENT")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.print$chunk_starts$fn__1344000130")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.print$chunk_starts$fn__1344000130$fn__1344000131")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054$fn__1344000059")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054$fn__1344000061")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054$fn__1344000063")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054$fn__1344000067")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054$fn__1344000069")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054$fn__1344000063$fn__1344000064")

var Lit_51 *jrt.String = jrt.Intern(".ae")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.print$collect$walk__1344000054$fn__1344000069$fn__1344000070")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.print$collect_forms$fn__1344000048")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.print$collect_forms$fn__1344000050")

var Lit_55 *jrt.String = jrt.Intern("load in forms in memory: ")

var Lit_56 *jrt.String = jrt.Intern("embedded file ")

var Lit_57 *jrt.String = jrt.Intern(": sha256 ")

var Lit_58 *jrt.String = jrt.Intern(", the forms say ")

var Lit_59 *jrt.String = jrt.Intern("{\"Replace\": {\n")

var Lit_60 *jrt.String = jrt.Intern("\n}}\n")

var Lit_61 *jrt.String = jrt.Intern(",\n")

var Lit_62 *jrt.String = jrt.Intern("arbace.repr.go.print$copy_files$iter__1344000215__1344000219")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.print$copy_files$iter__1344000215__1344000219$fn__1344000220")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.print$copy_files$iter__1344000215__1344000219$fn__1344000220$fn__1344000221")

var Lit_65 *jrt.String = jrt.Intern("  ")

var Lit_66 *jrt.String = jrt.Intern(": ")

var Lit_67 *jrt.String = jrt.Intern("go/directive")

var Lit_68 *jrt.String = jrt.Intern("java.io.File")

var Lit_69 *jrt.String = jrt.Intern("java.io.FileInputStream")

var Lit_70 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_71 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_72 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_73 *jrt.String = jrt.Intern("java.nio.file.CopyOption")

var Lit_74 *jrt.String = jrt.Intern("java.nio.file.StandardCopyOption")

var Lit_75 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_76 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020$iter__1344000015__1344000021")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020$iter__1344000015__1344000021$fn__1344000022")

var Lit_81 *jrt.String = jrt.Intern("arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020$iter__1344000015__1344000021$fn__1344000022$fn__1344000023")

var Lit_82 *jrt.String = jrt.Intern("/bin/gofmt")

var Lit_83 *jrt.String = jrt.Intern("-w")

var Lit_84 *jrt.String = jrt.Intern("gofmt ")

var Lit_85 *jrt.String = jrt.Intern("\"")

var Lit_86 *jrt.String = jrt.Intern("\\")

var Lit_87 *jrt.String = jrt.Intern("\\\\")

var Lit_88 *jrt.String = jrt.Intern("\\\"")

var Lit_89 *jrt.String = jrt.Intern("arbace.repr.go.print$next_target$fn__1344000121")

var Lit_90 *jrt.String = jrt.Intern("//line ")

var Lit_91 *jrt.String = jrt.Intern(":1")

var Lit_92 *jrt.String = jrt.Intern("package")

var Lit_93 *jrt.String = jrt.Intern("arbace.repr.go.print$print_file$first_line__1344000155")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.go.print$print_file$fn__1344000158")

var Lit_95 *jrt.String = jrt.Intern(";")

var Lit_96 *jrt.String = jrt.Intern("arbace.repr.go.print$print_forms$fn__1344000192")

var Lit_97 *jrt.String = jrt.Intern("SHA-256")

var Lit_98 *jrt.String = jrt.Intern("arbace.repr.go.print$sha256$fn__1344000196")

var Lit_99 *jrt.String = jrt.Intern("%02x")

var Lit_100 *jrt.String = jrt.Intern("import")

var Lit_101 *jrt.String = jrt.Intern("(")

var Lit_102 *jrt.String = jrt.Intern(")")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.print$write_imports$directive_QMARK___1344000091")

var Lit_104 *jrt.String = jrt.Intern("arbace.repr.go.print$write_imports_full$close_BANG___1344000097")

var Lit_105 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn4,pathkn4,linekn6,columnkn4,filekn7,privateyn7,ns-formkn7,dynamicyn5,stateyn1,fyn7,load-fnyn5,formsyn7,read-fnyn1,vyn5,specsyn7,importsyn6,lines?yn1,tyn5,declsyn1,iyn3,preyn5,poptsyn4,sep?yn4,fileyn4,optsyn8,pkg-namekn4,keysyn3,srcyn6,layoutyn16,line-directives?yn9,line-filekn2,asyn3,pkgkn3,tagyn4,Fileyn1,syn7,writtenyn6,configyn6,gorootyn3,cmdyn3,envyn7,out-diryn1,&yn4,argvv11,arbace.core5,in-nsMyn20,arbace.repr.go.printm2,R0,s1794,repr/go's printer: Go forms (doc/go/SPEC.md) to Go source, milestone G2\n  (doc/go/PRINTER-NOTES.md).\n\n  bin/repr-go print [OPTIONS] FORMS.ae OUTDIR\n    Reads the package file FORMS.ae (its ns, go/package and load forms, and the files it\n    loads; or one file holding go/file forms and declarations) with *read-eval* false and\n    writes one Go file per go/file into OUTDIR.\n    --layout lines|gofmt|full\n                          lines (default when the forms carry lines): each form on its\n                          recorded line (§10.1, §12.3); gofmt: gofmt's layout, lines ignored;\n                          full (default for a package of :positions :full): every token at\n                          its recorded line and column, with the file's comments and white\n                          space: the original text (§10.2, §12.3)\n    --no-line-directives  never write //line or /*line*/ directives for lines layout cannot\n                          reach\n    --src DIR             the original package directory: copies :other-files and\n                          :embed-files (hashes checked) into OUTDIR, and writes\n                          OUTDIR/overlay.json mapping DIR's Go files to the printed ones\n    --build               then compiles the package as §12.4 says: the toolchain of\n                          $ARBACE_GOROOT (default /root/tamago-go), the :config's environment,\n                          -trimpath, go build -overlay, in DIR\n    --gofmt               run each printed file through $ARBACE_GOROOT/bin/gofmt\n    --line-file           (layout lines) start each file with //line FORMS-FILE:1, so that\n                          gc's positions name the forms file and its lines (§12.3)\n\n  The library: print-package, print-forms (forms in memory to {name text}), print-file.m2,R0,s1794,repr/go's printer: Go forms (doc/go/SPEC.md) to Go source, milestone G2\n  (doc/go/PRINTER-NOTES.md).\n\n  bin/repr-go print [OPTIONS] FORMS.ae OUTDIR\n    Reads the package file FORMS.ae (its ns, go/package and load forms, and the files it\n    loads; or one file holding go/file forms and declarations) with *read-eval* false and\n    writes one Go file per go/file into OUTDIR.\n    --layout lines|gofmt|full\n                          lines (default when the forms carry lines): each form on its\n                          recorded line (§10.1, §12.3); gofmt: gofmt's layout, lines ignored;\n                          full (default for a package of :positions :full): every token at\n                          its recorded line and column, with the file's comments and white\n                          space: the original text (§10.2, §12.3)\n    --no-line-directives  never write //line or /*line*/ directives for lines layout cannot\n                          reach\n    --src DIR             the original package directory: copies :other-files and\n                          :embed-files (hashes checked) into OUTDIR, and writes\n                          OUTDIR/overlay.json mapping DIR's Go files to the printed ones\n    --build               then compiles the package as §12.4 says: the toolchain of\n                          $ARBACE_GOROOT (default /root/tamago-go), the :config's environment,\n                          -trimpath, go build -overlay, in DIR\n    --gofmt               run each printed file through $ARBACE_GOROOT/bin/gofmt\n    --line-file           (layout lines) start each file with //line FORMS-FILE:1, so that\n                          gc's positions name the forms file and its lines (§12.3)\n\n  The library: print-package, print-forms (forms in memory to {name text}), print-file.R1,v20,arbace.repr.go.print10,read-formsm10,R2,L1,V1,R3,R0,s66,The forms of a file, read with line numbers and *read-eval* false.R4,i40,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print13,go-ns-aliasesm12,R7,TR2,L1,V1,R8,R0,s57,The qualifiers naming arbace.go in an ns form's :require.R4,i51,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print5,*src*m12,R9,TR7,TR4,i63,R5,i1,R6,s23,arbace/repr/go/print.aeR0,s31,The forms file being collected.v20,arbace.repr.go.print8,add-formm12,R7,TR2,L1,V3,R10,R11,R12,R0,s83,Adds one top-level form to the collected package state; load-fn handles load forms.R4,i65,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print17,new-package-statem10,R7,TR2,L1,V0,R4,i88,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print13,collect-formsm10,R2,L1,V1,R13,R0,s145,The package of top-level forms in memory (the converter's output: ns, go/package, go/file\n  and declaration forms, no load), as collect gives it.R4,i91,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print7,collectm10,R2,L2,V1,R3,V2,R3,R14,R0,s422,The package of a forms file: {:package {opts} :name sym :files [{:name :file :opts\n  :decls}]}, following load forms (relative to the loading file's directory, which is\n  Clojure's rule for the package file's namespace, or with a leading / to the root the ns\n  name implies). read-fn (default read-forms) gives a file's forms: a cache of files read\n  beforehand (arbace.build.go reads a program's files once, in parallel).R4,i100,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print11,import-specm10,R7,TR2,L1,V1,R15,R4,i128,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print17,write-import-declm10,R7,TR2,L1,V1,R16,R4,i134,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print13,write-importsm12,R7,TR2,L1,V1,R17,R0,s152,The imports: [name path] specs, and (go/directive \"...\") forms among them (C4), in\n  order; the specs between two directives are one import declaration.R4,i150,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print18,write-imports-fullm12,R7,TR2,L1,V1,R17,R0,s247,Mode :full: the imports at their positions: specs (vectors, their literal paths wrapped by\n  wrap-full), each import declaration's keyword and parentheses on its first spec; the\n  directives among them are comments, which the file's comments hold.R4,i166,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print14,one-line-func?m12,R7,TR2,L1,V3,R11,R18,R19,R0,s144,Whether a declaration is a function printed on one line: its closing brace on its first\n  line (mode :lines), or an empty body (gofmt's layout).R4,i188,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print8,decl-prem12,R7,TR2,L1,V1,R11,R0,s65,[directive? doc directives pre-lines] of a top-level declaration.R4,i201,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print11,next-targetm12,R7,TR2,L1,V2,R20,R21,R0,s84,The line the declaration after decls' i-th is placed on (its doc first), when known.R4,i208,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print9,decl-sep!m12,R7,TR2,L1,V4,R11,R19,R22,R18,R0,s310,The separation of a declaration (recorded line t, pre comment lines before it) from what\n  precedes it: a new alignment section (form feed) unless a one-line function follows a line\n  at the left margin (go/printer's declList: one-line functions in a row align their\n  bodies); in mode :lines down to its line.R4,i215,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print11,print-decl!m12,R7,TR2,L1,V5,R20,R21,R18,R23,R24,R0,s137,Prints decls' i-th declaration, after its separation from what precedes it unless\n  sep? is false (a chunk's first: start-at! placed it).R4,i228,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print9,chunk-minl48,m10,R7,TR4,i247,R5,i1,R6,s23,arbace/repr/go/print.aeR0,s88,The fewest declarations of a chunk: a file of fewer than twice as many is printed whole.v20,arbace.repr.go.print12,chunk-startsm12,R7,TR2,L1,V1,R20,R0,s178,The first declarations of decls' chunks (mode :lines): about two chunks per processor,\n  each starting at a declaration with a recorded line; none for a file of few declarations.R4,i251,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print15,print-file-fullm12,R7,TR2,L1,V4,R25,R26,R20,R27,R0,s193,Mode :full (SPEC §10.2, §12.3): the Go text of one file, every token at its recorded line\n  and column, with the file's comments and white space (go/file's :go/comments, :go/space,\n  :go/tail).R4,i265,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print10,print-filem10,R2,L1,V3,m2,R28,V4,R26,R20,R25,R29,R27,m4,R28,V3,R30,R31,R32,R33,R23,R0,s274,The Go text of one file: {:name :opts :decls} as collect gives it. pkg-name is the\n  package clause's name unless the file's :package says otherwise. In mode :lines a file of\n  many declarations is printed in chunks, in parallel (print-emit's join!); the text is the\n  same.R4,i287,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print11,print-formsm10,R2,L1,V2,R34,R26,R0,s133,The Go files of a collected package: {name text}, printed in parallel (each file's\n  printing is independent: its own emitter state).R4,i341,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print6,sha256m10,R7,TR2,L1,V1,Myn1,fm2,R35,R36,R4,i352,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print9,copy-filem10,R7,TR2,L1,V2,Myn4,fromm2,R35,R36,Myn2,tom2,R35,R36,R4,i357,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print11,json-stringm10,R7,TR2,L1,V1,R37,R4,i362,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print10,copy-filesm10,R2,L1,V4,R34,Myn3,srcm2,R35,R36,Myn3,outm2,R35,R36,R38,R0,s164,Copies the package's :other-files and :embed-files (checking the hashes) from src to\n  out; writes out/overlay.json for go build -overlay (src's Go files to out's).R4,i365,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print9,build-envm10,R2,L1,V2,R39,R40,R0,s61,The environment of the package's configuration (§4.2, §12.4).R4,i385,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print3,runm10,R7,TR2,L1,V3,R41,Myn3,dirm2,R35,R36,R42,R4,i396,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print5,buildm10,R2,L1,V4,R34,Myn3,srcm2,R35,R36,Myn3,outm2,R35,R36,R40,R0,s87,go build -trimpath -overlay out/overlay.json in src, under the package's configuration.R4,i406,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print13,print-packagem10,R2,L1,V3,R3,R43,R26,R0,s82,Prints the package of the forms file at path into out-dir; returns the file names.R4,i417,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print10,gofmt-filem10,R7,TR2,L1,V2,R40,Myn1,fm2,R35,R36,R4,i429,R5,i1,R6,s23,arbace/repr/go/print.aev20,arbace.repr.go.print5,-mainm8,R2,L1,V2,R44,R45,R4,i434,R5,i1,R6,s23,arbace/repr/go/print.ae")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.go.print$eval1344000004$loading__1927001464__auto____1344000005")

var Lit_107 *jrt.String = jrt.Intern("arbace.repr.go.print$eval1344000008$fn__1344000009")

var Lit_108 *jrt.String = jrt.Intern("arbace.repr.go.print$read_forms")

var Lit_109 *jrt.String = jrt.Intern("arbace.repr.go.print$go_ns_aliases")

var Lit_110 *jrt.String = jrt.Intern("arbace.repr.go.print$add_form")

var Lit_111 *jrt.String = jrt.Intern("arbace.repr.go.print$new_package_state")

var Lit_112 *jrt.String = jrt.Intern("arbace.repr.go.print$collect_forms")

var Lit_113 *jrt.String = jrt.Intern("arbace.repr.go.print$collect")

var Lit_114 *jrt.String = jrt.Intern("arbace.repr.go.print$import_spec")

var Lit_115 *jrt.String = jrt.Intern("arbace.repr.go.print$write_import_decl")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go.print$write_imports")

var Lit_117 *jrt.String = jrt.Intern("arbace.repr.go.print$write_imports_full")

var Lit_118 *jrt.String = jrt.Intern("arbace.repr.go.print$one_line_func_QMARK_")

var Lit_119 *jrt.String = jrt.Intern("arbace.repr.go.print$decl_pre")

var Lit_120 *jrt.String = jrt.Intern("arbace.repr.go.print$next_target")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go.print$decl_sep_BANG_")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go.print$print_decl_BANG_")

var Lit_123 *jrt.String = jrt.Intern("arbace.repr.go.print$chunk_starts")

var Lit_124 *jrt.String = jrt.Intern("arbace.repr.go.print$print_file_full")

var Lit_125 *jrt.String = jrt.Intern("arbace.repr.go.print$print_file")

var Lit_126 *jrt.String = jrt.Intern("arbace.repr.go.print$print_forms")

var Lit_127 *jrt.String = jrt.Intern("arbace.repr.go.print$sha256")

var Lit_128 *jrt.String = jrt.Intern("arbace.repr.go.print$copy_file")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.go.print$json_string")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.go.print$copy_files")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.go.print$build_env")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go.print$run")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go.print$build")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.go.print$print_package")

var Lit_135 *jrt.String = jrt.Intern("arbace.repr.go.print$gofmt_file")

var Lit_136 *jrt.String = jrt.Intern("arbace.repr.go.print$_main")
