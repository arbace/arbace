//line aot_arbace_repr_go_print.ae:1
package aot_arbace_repr_go_print

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print_code"
	"arbace/aot_arbace_repr_go_print_emit"
	"arbace/aot_arbace_repr_go_print_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_New() *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_1); lang.IFn_Cast(A_arbace_repr_go_print_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_A_const_3, A_arbace_repr_go_print_A_const_4, A_arbace_repr_go_print_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_68)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_69)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_70)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_71)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_72)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_73)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_74)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_75)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_76)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_New() *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_eval1344000008_fn__1344000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_6.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_repr_go_print_A_const_8; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_print_A_const_9.GetRawRoot__O(), A_arbace_repr_go_print_A_const_10) }






































func A_arbace_repr_go_print_read_forms_A_New() *A_arbace_repr_go_print_read_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_read_forms_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_repr_go_print_read_forms_A) Ctor() {}
//line :40:1
func (t *A_arbace_repr_go_print_read_forms_A) Invoke_O_O__O(self, path__0 any) any { var r__2 any; var tmp1 any; var root_21 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_23 lang.IFn; if



	linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = path__0; if linked_22 == nil { tmp1 = ifn_23.Invoke_O__O(arg_24) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_21, arg_24) }; r__2 = /*line :40:1*/lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream_Charset(jrt.FileInputStream_New_String(jrt.String_Cast(tmp1)), jrt.StandardCharsets_UTF_8)); var tmp2 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var root_39 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_16, jrt.Boolean_FALSE.Ref()); if linked_40 == nil { ifn_41.Invoke_O__O(arg_42) } else { linked_40.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_39, arg_42) }; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :40:1
			{ var eof__7 any = jrt.Object_New(); var acc__8 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__9 any; var root_25 any = A_arbace_repr_go_print_A_const_12.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_27 lang.IFn







				if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = r__2; var arg_29 any = jrt.Boolean_FALSE.Ref(); var arg_30 any = eof__7; if linked_26 == nil { f__9 = ifn_27.Invoke_O_O_O__O(arg_28, arg_29, arg_30) } else { f__9 = linked_26.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_25, arg_28, arg_29, arg_30) }
				if lang.Util_Identical_O_O__Z_NoInit(f__9, eof__7) { tmp2 = acc__8 } else { var tmp3 any; var root_43 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = acc__8; var arg_47 any = f__9; if linked_44 == nil { tmp3 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp3 = linked_44.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; acc__8 = tmp3; continue L1 }
//line :40:1
				break L1
			}
			}


			return nil }(); var root_31 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; if linked_32 == nil { ifn_33.Invoke__O() } else { linked_32.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_31) }
//line :40:1
			if tmp4 != nil { panic(tmp4) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :40:1*/ tmp5 != nil { panic(tmp5) }; return tmp2 }










func A_arbace_repr_go_print_go_ns_aliases_A_New() *A_arbace_repr_go_print_go_ns_aliases_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_go_print_go_ns_aliases_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_go_print_go_ns_aliases_A) Invoke_O_O__O(self, ns_form__0 any) any {


	var root_204 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = A_arbace_repr_go_print_A_const_18; var arg_208 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_New(); var tmp2 *jrt.Class; var fncls__199 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class
	if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class = fncls__199d; tmp2 = fncls__199d } else { tmp2 = fncls__199 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_200 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = ns_form__0; if linked_201 == nil { tmp4 = ifn_202.Invoke_O__O(arg_203) } else { tmp4 = linked_201.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_200, arg_203) }; arg_208 = tmp3.Invoke_O__O(tmp4)
//line :54:1
	if linked_205 == nil { return ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { return linked_205.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } }
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_New() *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A) Invoke_O_O__O(self, s__1344000014__1 any) any { var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_New_O_O(s__1344000014__1, self); var tmp2 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class = fncls__198d; tmp2 = fncls__198d } else { tmp2 = fncls__198 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A) Ctor_O_O(c__s__1344000014, c__iter__1344000013 any) { t.F_s__1344000014 = c__s__1344000014; t.F_iter__1344000013 = c__iter__1344000013 }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A) Invoke_O__O(self any) any { { var s__1344000014__1 any; var t_ any = t.F_s__1344000014; t.F_s__1344000014 = nil; s__1344000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_48 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = s__1344000014__1; if linked_49 == nil { temp__1927000414__auto____2 = ifn_50.Invoke_O__O(arg_51) } else { temp__1927000414__auto____2 = linked_49.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_48, arg_51) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var clause__4 any; var root_52 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = xs__1927001018__auto____3; if linked_53 == nil { clause__4 = ifn_54.Invoke_O__O(arg_55) } else { clause__4 = linked_53.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_52, arg_55) }; var tmp1 any; var and__1927000168__auto____5 any; var root_56 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_58 lang.IFn
															if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = clause__4; if linked_57 == nil { and__1927000168__auto____5 = ifn_58.Invoke_O__O(arg_59) } else { and__1927000168__auto____5 = linked_57.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_56, arg_59) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 any = A_arbace_repr_go_print_A_const_22; var tmp3 any; var root_60 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = clause__4; if linked_61 == nil { tmp3 = ifn_62.Invoke_O__O(arg_63) } else { tmp3 = linked_61.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_60, arg_63) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____5 }
//line :55:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_New(); var tmp5 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class = fncls__172d; tmp5 = fncls__172d } else { tmp5 = fncls__172 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____6 any; var root_177 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp7 any; var root_173 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_175 lang.IFn

		if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = clause__4; if linked_174 == nil { tmp7 = ifn_175.Invoke_O__O(arg_176) } else { tmp7 = linked_174.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_173, arg_176) }
//line :55:1
		arg_180 = tmp6.Invoke_O__O(tmp7); if linked_178 == nil { fs__1927001036__auto____6 = ifn_179.Invoke_O__O(arg_180) } else { fs__1927001036__auto____6 = linked_178.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_185 any = A_arbace_repr_go_print_A_const_37.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = fs__1927001036__auto____6; var arg_189 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1344000013); var tmp9 any; var root_181 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = s__1344000014__1; if linked_182 == nil { tmp9 = ifn_183.Invoke_O__O(arg_184) } else { tmp9 = linked_182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_181, arg_184) }; arg_189 = tmp8.Invoke_O__O(tmp9); if linked_186 == nil { return ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { return linked_186.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) } } else { var tmp10 any; var root_190 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__1344000014__1; if linked_191 == nil { tmp10 = ifn_192.Invoke_O__O(arg_193) } else { tmp10 = linked_191.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_190, arg_193) }; s__1344000014__1 = tmp10; continue L1 } } else { var tmp11 any; var root_194 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = s__1344000014__1; if linked_195 == nil { tmp11 = ifn_196.Invoke_O__O(arg_197) } else { tmp11 = linked_195.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_194, arg_197) }; s__1344000014__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_New() *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A) Invoke_O_O__O(self, s__1344000016__1 any) any { var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_New_O_O(s__1344000016__1, self); var tmp2 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class = fncls__171d; tmp2 = fncls__171d } else { tmp2 = fncls__171 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A) Ctor_O_O(c__s__1344000016, c__iter__1344000015 any) { t.F_s__1344000016 = c__s__1344000016; t.F_iter__1344000015 = c__iter__1344000015 }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A) Invoke_O__O(self any) any { { var s__1344000016__1 any; var t_ any = t.F_s__1344000016; t.F_s__1344000016 = nil; s__1344000016__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_64 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = s__1344000016__1; if linked_65 == nil { temp__1927000414__auto____2 = ifn_66.Invoke_O__O(arg_67) } else { temp__1927000414__auto____2 = linked_65.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_64, arg_67) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1344000016__3 any = temp__1927000414__auto____2; var tmp1 any; var root_68 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = s__1344000016__3; if linked_69 == nil { tmp1 = ifn_70.Invoke_O__O(arg_71) } else { tmp1 = linked_69.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_72 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = s__1344000016__3; if linked_73 == nil { c__1927001037__auto____4 = ifn_74.Invoke_O__O(arg_75) } else { c__1927001037__auto____4 = linked_73.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_72, arg_75) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1344000018__6 any; var root_76 any = A_arbace_repr_go_print_A_const_25.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_77 == nil { b__1344000018__6 = ifn_78.Invoke_O__O(arg_79) } else { b__1344000018__6 = linked_77.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_76, arg_79) }; var tmp2 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_New_O_I_O(b__1344000018__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_115 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any; var root_107 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = b__1344000018__6; if linked_108 == nil { arg_118 = ifn_109.Invoke_O__O(arg_110) } else { arg_118 = linked_108.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_107, arg_110) }; var arg_119 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1344000015); var tmp5 any; var root_111 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = s__1344000016__3; if linked_112 == nil { tmp5 = ifn_113.Invoke_O__O(arg_114) } else { tmp5 = linked_112.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_111, arg_114) }; arg_119 = tmp4.Invoke_O__O(tmp5); if linked_116 == nil { return ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { return linked_116.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_115, arg_118, arg_119) } } else { var root_124 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_120 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = b__1344000018__6; if linked_121 == nil { arg_127 = ifn_122.Invoke_O__O(arg_123) } else { arg_127 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_120, arg_123) }; var arg_128 any; if linked_125 == nil { return ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { return linked_125.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } } } else { var spec__4 any; var root_129 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = s__1344000016__3; if linked_130 == nil { spec__4 = ifn_131.Invoke_O__O(arg_132) } else { spec__4 = linked_130.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_129, arg_132) }; var tmp6 any; var and__1927000168__auto____5 any; var root_133 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_135 lang.IFn


	if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = spec__4; if linked_134 == nil { and__1927000168__auto____5 = ifn_135.Invoke_O__O(arg_136) } else { and__1927000168__auto____5 = linked_134.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 any = A_arbace_repr_go_print_A_const_27; var tmp8 any; var root_137 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = spec__4; if linked_138 == nil { tmp8 = ifn_139.Invoke_O__O(arg_140) } else { tmp8 = linked_138.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_137, arg_140) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp6 = and__1927000168__auto____5 }
//line :55:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_145 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_147 lang.IFn



		if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_149 any; var root_141 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = spec__4; if linked_142 == nil { arg_149 = ifn_143.Invoke_O__O(arg_144) } else { arg_149 = linked_142.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_141, arg_144) }; if linked_146 == nil { m__5 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { m__5 = linked_146.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }
//line :55:1
		if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__5)) { var root_158 any = A_arbace_repr_go_print_A_const_36.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var root_150 any = A_arbace_repr_go_print_A_const_32.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_152 lang.IFn





			if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__5); if linked_151 == nil { arg_161 = ifn_152.Invoke_O__O(arg_153) } else { arg_161 = linked_151.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_150, arg_153) }
//line :55:1
			var arg_162 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1344000015); var tmp10 any; var root_154 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__1344000016__3; if linked_155 == nil { tmp10 = ifn_156.Invoke_O__O(arg_157) } else { tmp10 = linked_155.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_154, arg_157) }; arg_162 = tmp9.Invoke_O__O(tmp10); if linked_159 == nil { return ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { return linked_159.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_158, arg_161, arg_162) } } else { var tmp11 any; var root_163 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = s__1344000016__3; if linked_164 == nil { tmp11 = ifn_165.Invoke_O__O(arg_166) } else { tmp11 = linked_164.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_163, arg_166) }; s__1344000016__1 = tmp11; continue L1 } } else { var tmp12 any; var root_167 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = s__1344000016__3; if linked_168 == nil { tmp12 = ifn_169.Invoke_O__O(arg_170) } else { tmp12 = linked_168.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_167, arg_170) }; s__1344000016__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A) Ctor_O_I_O(c__b__1344000018 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1344000018 = c__b__1344000018; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A) Invoke_O__O(self any) any { { var i__1344000017__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1344000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1344000017__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_80 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_82 lang.IFn


	if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = spec__2; if linked_81 == nil { and__1927000168__auto____3 = ifn_82.Invoke_O__O(arg_83) } else { and__1927000168__auto____3 = linked_81.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_80, arg_83) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_repr_go_print_A_const_27; var tmp4 any; var root_84 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = spec__2; if linked_85 == nil { tmp4 = ifn_86.Invoke_O__O(arg_87) } else { tmp4 = linked_85.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_84, arg_87) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :55:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_92 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_94 lang.IFn



		if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_96 any; var root_88 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = spec__2; if linked_89 == nil { arg_96 = ifn_90.Invoke_O__O(arg_91) } else { arg_96 = linked_89.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_88, arg_91) }; if linked_93 == nil { m__3 = ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { m__3 = linked_93.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) }
//line :55:1
		if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__3)) { var root_101 any = A_arbace_repr_go_print_A_const_31.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = t.F_b__1344000018; var arg_105 any; var root_97 any = A_arbace_repr_go_print_A_const_32.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_99 lang.IFn





			if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__3); if linked_98 == nil { arg_105 = ifn_99.Invoke_O__O(arg_100) } else { arg_105 = linked_98.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_97, arg_100) }
//line :55:1
			if linked_102 == nil { ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { linked_102.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_101, arg_104, arg_105) }; i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000017__1); continue L1 } else { i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000017__1); continue L1 } } else { i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000017__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_repr_go_print_add_form_A_New() *A_arbace_repr_go_print_add_form_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_add_form_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_repr_go_print_add_form_A) Ctor() {}
//line :65:1
func (t *A_arbace_repr_go_print_add_form_A) Invoke_O_O_O_O__O(self, state__0, f__1, load_fn__2 any) any {


	var root_395 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_60; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_40; var tmp4 any; var root_386 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = state__0; if linked_387 == nil { tmp4 = ifn_388.Invoke_O__O(arg_389) } else { tmp4 = linked_387.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_386, arg_389) }; arg_398 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4)); if linked_396 == nil { ifn_397.Invoke_O__O(arg_398) } else { linked_396.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_395, arg_398) }
//line :65:1
	var tmp5 any; tmp41 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var o__6 any; var tmp6 any; var root_209 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_211 lang.IFn



		if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = f__1; if linked_210 == nil { tmp6 = ifn_211.Invoke_O__O(arg_212) } else { tmp6 = linked_210.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_209, arg_212) }; if jrt.J2g_Truth(tmp6) { var root_213 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = f__1; if linked_214 == nil { o__6 = ifn_215.Invoke_O__O(arg_216) } else { o__6 = linked_214.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_213, arg_216) } } else { o__6 = nil }
		if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_11) {
			var tmp7 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp8 any; var root_221 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var arg_225 any = A_arbace_repr_go_print_A_const_40; var arg_226 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var arg_227 any; var root_217 any = A_arbace_repr_go_print_A_const_41.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, A_arbace_repr_go_print_go_ns_aliases_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = f__1; if linked_218 == nil { arg_227 = ifn_219.Invoke_O__O(arg_220) } else { arg_227 = linked_218.(*A_arbace_repr_go_print_go_ns_aliases_A).Invoke_O_O__O(root_217, arg_220) }; if linked_222 == nil { tmp8 = ifn_223.Invoke_O_O_O_O__O(arg_224, arg_225, arg_226, arg_227) } else { tmp8 = linked_222.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_221, arg_224, arg_225, arg_226, arg_227) }; tmp5 = jrt.NN(tmp7).Reset_O__O(tmp8) } else {
//line :70:1
				if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_12) { tmp5 = nil } else { if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_13) { var seq_1344000030__7 any; var root_232 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_234 lang.IFn


					if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any; var root_228 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = f__1; if linked_229 == nil { arg_235 = ifn_230.Invoke_O__O(arg_231) } else { arg_235 = linked_229.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_228, arg_231) }; if linked_233 == nil { seq_1344000030__7 = ifn_234.Invoke_O__O(arg_235) } else { seq_1344000030__7 = linked_233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_232, arg_235) }
//line :70:1
					var chunk_1344000031__8 any; var count_1344000032__9 int64 = 0; var i_1344000033__10 int64 = 0; L1: for {


						if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000033__10, count_1344000032__9) { var p__11 any = lang.Indexed_Cast(chunk_1344000031__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000033__10)); var tmp9 lang.IFn = lang.IFn_Cast(load_fn__2); var tmp10 any; var root_399 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = p__11; if linked_400 == nil { tmp10 = ifn_401.Invoke_O__O(arg_402) } else { tmp10 = linked_400.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_399, arg_402) }; tmp9.Invoke_O__O(tmp10); seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000033__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_236 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = seq_1344000030__7; if linked_237 == nil { temp__1927000414__auto____11 = ifn_238.Invoke_O__O(arg_239) } else { temp__1927000414__auto____11 = linked_237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_236, arg_239) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1344000030__12 any = temp__1927000414__auto____11; var tmp11 any; var root_240 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = seq_1344000030__12; if linked_241 == nil { tmp11 = ifn_242.Invoke_O__O(arg_243) } else { tmp11 = linked_241.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_240, arg_243) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_244 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = seq_1344000030__12; if linked_245 == nil { c__1927000678__auto____13 = ifn_246.Invoke_O__O(arg_247) } else { c__1927000678__auto____13 = linked_245.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_244, arg_247) }; var tmp12 any; var root_403 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = seq_1344000030__12; if linked_404 == nil { tmp12 = ifn_405.Invoke_O__O(arg_406) } else { tmp12 = linked_404.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_403, arg_406) }; seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__13 any; var root_248 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = seq_1344000030__12; if linked_249 == nil { p__13 = ifn_250.Invoke_O__O(arg_251) } else { p__13 = linked_249.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_248, arg_251) }; var tmp13 lang.IFn = lang.IFn_Cast(load_fn__2); var tmp14 any; var root_407 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = p__13; if linked_408 == nil { tmp14 = ifn_409.Invoke_O__O(arg_410) } else { tmp14 = linked_408.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_407, arg_410) }; tmp13.Invoke_O__O(tmp14); var tmp15 any; var root_411 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = seq_1344000030__12; if linked_412 == nil { tmp15 = ifn_413.Invoke_O__O(arg_414) } else { tmp15 = linked_412.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_411, arg_414) }; seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = tmp15, nil, 0, 0; continue L1 } } else { tmp5 = nil } }
//line :70:1
						break L1 } } else { if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_14) { var vec__1344000034__7 any = f__1; var seq__1344000035__8 any; var root_252 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_254 lang.IFn




							if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = vec__1344000034__7; if linked_253 == nil { seq__1344000035__8 = ifn_254.Invoke_O__O(arg_255) } else { seq__1344000035__8 = linked_253.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_252, arg_255) }
//line :70:1
							var first__1344000036__9 any; var root_256 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_258 lang.IFn




							if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = seq__1344000035__8; if linked_257 == nil { first__1344000036__9 = ifn_258.Invoke_O__O(arg_259) } else { first__1344000036__9 = linked_257.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_256, arg_259) }
//line :70:1
							var seq__1344000035__10 any; var root_260 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_262 lang.IFn




							if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = seq__1344000035__8; if linked_261 == nil { seq__1344000035__10 = ifn_262.Invoke_O__O(arg_263) } else { seq__1344000035__10 = linked_261.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_260, arg_263) }
//line :70:1
							var ___11 any = first__1344000036__9; var first__1344000036__12 any; var root_264 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_266 lang.IFn; _ = ___11




							if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = seq__1344000035__10; if linked_265 == nil { first__1344000036__12 = ifn_266.Invoke_O__O(arg_267) } else { first__1344000036__12 = linked_265.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_264, arg_267) }
//line :70:1
							var seq__1344000035__13 any; var root_268 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_270 lang.IFn




							if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = seq__1344000035__10; if linked_269 == nil { seq__1344000035__13 = ifn_270.Invoke_O__O(arg_271) } else { seq__1344000035__13 = linked_269.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_268, arg_271) }
//line :70:1
							var nm__14 any = first__1344000036__12; var opts__15 any = seq__1344000035__13; var tmp16 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_43.GetRawRoot__O()); var tmp18 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp19 any = A_arbace_repr_go_print_A_const_44; var tmp20 any; var root_272 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_274 lang.IFn





							if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_276 any = opts__15; if linked_273 == nil { tmp20 = ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { tmp20 = linked_273.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_272, arg_275, arg_276) }; tmp5 = jrt.NN(tmp16).Reset_O__O(tmp17.Invoke_O_O_O_O_O__O(tmp18, tmp19, tmp20, A_arbace_repr_go_print_A_const_45, nm__14)) } else {
//line :70:1
								if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_15) { var vec__1344000037__7 any = f__1; var seq__1344000038__8 any; var root_285 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_287 lang.IFn







									if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = vec__1344000037__7; if linked_286 == nil { seq__1344000038__8 = ifn_287.Invoke_O__O(arg_288) } else { seq__1344000038__8 = linked_286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_285, arg_288) }
//line :70:1
									var first__1344000039__9 any; var root_289 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_291 lang.IFn







									if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = seq__1344000038__8; if linked_290 == nil { first__1344000039__9 = ifn_291.Invoke_O__O(arg_292) } else { first__1344000039__9 = linked_290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_289, arg_292) }
//line :70:1
									var seq__1344000038__10 any; var root_293 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_295 lang.IFn







									if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = seq__1344000038__8; if linked_294 == nil { seq__1344000038__10 = ifn_295.Invoke_O__O(arg_296) } else { seq__1344000038__10 = linked_294.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_293, arg_296) }
//line :70:1
									var ___11_2 any = first__1344000039__9; var first__1344000039__12 any; var root_297 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_299 lang.IFn; _ = ___11_2







									if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = seq__1344000038__10; if linked_298 == nil { first__1344000039__12 = ifn_299.Invoke_O__O(arg_300) } else { first__1344000039__12 = linked_298.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_297, arg_300) }
//line :70:1
									var seq__1344000038__13 any; var root_301 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_303 lang.IFn







									if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = seq__1344000038__10; if linked_302 == nil { seq__1344000038__13 = ifn_303.Invoke_O__O(arg_304) } else { seq__1344000038__13 = linked_302.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_301, arg_304) }
//line :70:1
									var nm__14_2 any = first__1344000039__12; var opts__15_2 any = seq__1344000038__13; var tmp21 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp22 any; var root_310 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_312 lang.IFn








									if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var arg_314 any = A_arbace_repr_go_print_A_const_46; var arg_315 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var arg_316 any; var tmp23 any = A_arbace_repr_go_print_A_const_45; var tmp24 any = A_arbace_repr_go_print_A_const_47; var tmp25 any = A_arbace_repr_go_print_A_const_48; var tmp26 any; var root_305 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_309 any = opts__15_2; if linked_306 == nil { tmp26 = ifn_307.Invoke_O_O__O(arg_308, arg_309) } else { tmp26 = linked_306.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_305, arg_308, arg_309) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_repr_go_print_A_const_49; var tmp29 any = lang.PersistentVector_EMPTY.Ref(); var tmp30 any = A_arbace_repr_go_print_A_const_50; arg_316 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, nm__14_2, tmp24, f__1, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_repr_go_print_A_const_51.Get__O())); if linked_311 == nil { tmp22 = ifn_312.Invoke_O_O_O_O__O(arg_313, arg_314, arg_315, arg_316) } else { tmp22 = linked_311.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_310, arg_313, arg_314, arg_315, arg_316) }; tmp5 = jrt.NN(tmp21).Reset_O__O(tmp22) } else {
//line :70:1
										var tmp31 any; var and__1927000168__auto____7 any; var root_317 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_319 lang.IFn










										if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = f__1; if linked_318 == nil { and__1927000168__auto____7 = ifn_319.Invoke_O__O(arg_320) } else { and__1927000168__auto____7 = linked_318.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_317, arg_320) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var root_325 any = A_arbace_repr_go_print_A_const_52.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any; var root_321 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = o__6; if linked_322 == nil { arg_328 = ifn_323.Invoke_O__O(arg_324) } else { arg_328 = linked_322.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_321, arg_324) }; var arg_329 any = Lit_16; if linked_326 == nil { tmp31 = ifn_327.Invoke_O_O__O(arg_328, arg_329) } else { tmp31 = linked_326.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_325, arg_328, arg_329) } } else { tmp31 = and__1927000168__auto____7 }
//line :70:1
										if jrt.J2g_Truth(tmp31) {











											var tmp32 any; var root_334 any = A_arbace_repr_go_print_A_const_53.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any; var tmp33 *lang.Keyword = A_arbace_repr_go_print_A_const_46; var tmp34 any; var root_330 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = state__0; if linked_331 == nil { tmp34 = ifn_332.Invoke_O__O(arg_333) } else { tmp34 = linked_331.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_330, arg_333) }; arg_337 = tmp33.Invoke_O__O(tmp34); if linked_335 == nil { tmp32 = ifn_336.Invoke_O__O(arg_337) } else { tmp32 = linked_335.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(tmp32) { var tmp35 any; var root_342 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_344 lang.IFn
												if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_55.GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var arg_346 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_56, f__1)); if linked_343 == nil { tmp35 = ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { tmp35 = linked_343.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) }
//line :82:1
												panic(jrt.Thrown(jrt.Throwable_Cast(tmp35))) } else {

													var tmp36 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp37 any; var root_368 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var arg_372 any = A_arbace_repr_go_print_A_const_46; var arg_373 any; var tmp38 any = A_arbace_repr_go_print_add_form_fn__1344000040_A_New_O(f__1); var tmp39 *jrt.Class; var fncls__367 *jrt.Class = A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class; if fncls__367 == nil { var fncls__367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class = fncls__367d; tmp39 = fncls__367d } else { tmp39 = fncls__367 }; arg_373 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); if linked_369 == nil { tmp37 = ifn_370.Invoke_O_O_O__O(arg_371, arg_372, arg_373) } else { tmp37 = linked_369.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_368, arg_371, arg_372, arg_373) }; tmp5 = jrt.NN(tmp36).Reset_O__O(tmp37) } } else {
//line :70:1
														if lang.Util_Identical_O_O__Z_NoInit(f__1, nil) { tmp5 = nil } else { if A_arbace_repr_go_print_A_const_59 != nil { var tmp40 any; var root_378 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_380 lang.IFn















															if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_55.GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var arg_382 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_56, f__1)); if linked_379 == nil { tmp40 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp40 = linked_379.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }
//line :70:1
															panic(jrt.Thrown(jrt.Throwable_Cast(tmp40))) } else { tmp5 = nil } } } } } } } } }; return nil }()
//line :65:1
	var root_383 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_385 lang.IFn


	if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; if linked_384 == nil { ifn_385.Invoke__O() } else { linked_384.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_383) }
//line :65:1
	if tmp41 != nil { panic(tmp41) }; return tmp5
}

















func A_arbace_repr_go_print_add_form_fn__1344000040_A_New_O(p0 any) *A_arbace_repr_go_print_add_form_fn__1344000040_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_add_form_fn__1344000040_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_repr_go_print_add_form_fn__1344000040_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :84:1
func (t *A_arbace_repr_go_print_add_form_fn__1344000040_A) Invoke_O_O__O(self, fs__1 any) any { var root_362 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var root_347 any = A_arbace_repr_go_print_A_const_57.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = fs__1; if linked_348 == nil { arg_365 = ifn_349.Invoke_O__O(arg_350) } else { arg_365 = linked_348.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_347, arg_350) }; var arg_366 any; var root_355 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any; var root_351 any = A_arbace_repr_go_print_A_const_58.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = fs__1; if linked_352 == nil { arg_358 = ifn_353.Invoke_O__O(arg_354) } else { arg_358 = linked_352.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_351, arg_354) }; var arg_359 any = A_arbace_repr_go_print_A_const_49; var arg_360 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var arg_361 any = t.F_f; if linked_356 == nil { arg_366 = ifn_357.Invoke_O_O_O_O__O(arg_358, arg_359, arg_360, arg_361) } else { arg_366 = linked_356.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_355, arg_358, arg_359, arg_360, arg_361) }; if linked_363 == nil { return ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { return linked_363.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) } }



func A_arbace_repr_go_print_new_package_state_A_New() *A_arbace_repr_go_print_new_package_state_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_new_package_state_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_repr_go_print_new_package_state_A) Ctor() {}
//line :88:1
func (t *A_arbace_repr_go_print_new_package_state_A) Invoke_O__O(self any) any {
	var root_415 any = A_arbace_repr_go_print_A_const_61.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_44, nil, A_arbace_repr_go_print_A_const_45, nil, A_arbace_repr_go_print_A_const_46, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_go_print_A_const_40, A_arbace_repr_go_print_A_const_62)); if linked_416 == nil { return ifn_417.Invoke_O__O(arg_418) } else { return linked_416.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_415, arg_418)
	} }
func A_arbace_repr_go_print_collect_forms_A_New() *A_arbace_repr_go_print_collect_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_repr_go_print_collect_forms_A) Ctor() {}
//line :91:1
func (t *A_arbace_repr_go_print_collect_forms_A) Invoke_O_O__O(self, forms__0 any) any { var state__2 any; var root_419 any = A_arbace_repr_go_print_A_const_63.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, A_arbace_repr_go_print_new_package_state_A_fn_class); var ifn_421 lang.IFn; if



	linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; if linked_420 == nil { state__2 = ifn_421.Invoke__O() } else { state__2 = linked_420.(*A_arbace_repr_go_print_new_package_state_A).Invoke_O__O(root_419) }; var seq_1344000044__3 any; var root_431 any = /*line :91:1*/A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_433 lang.IFn; if




	linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = forms__0; if linked_432 == nil { seq_1344000044__3 = ifn_433.Invoke_O__O(arg_434) } else { seq_1344000044__3 = linked_432.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_431, arg_434) }; var chunk_1344000045__4 any; var count_1344000046__5 int64 = 0; var i_1344000047__6 int64 = 0; L1:
//line :91:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000047__6, count_1344000046__5) { var f__7 any = lang.Indexed_Cast(chunk_1344000045__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000047__6)); var root_457 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_459 lang.IFn
			if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = state__2; var arg_461 any = f__7; var arg_462 any; var tmp1 any = A_arbace_repr_go_print_collect_forms_fn__1344000048_A_New(); var tmp2 *jrt.Class; var fncls__456 *jrt.Class = A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class; if fncls__456 == nil { var fncls__456d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class = fncls__456d; tmp2 = fncls__456d } else { tmp2 = fncls__456 }; arg_462 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_458 == nil { ifn_459.Invoke_O_O_O__O(arg_460, arg_461, arg_462) } else { linked_458.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_457, arg_460, arg_461, arg_462) }
//line :96:1
			seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000047__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_435 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = seq_1344000044__3; if linked_436 == nil { temp__1927000414__auto____7 = ifn_437.Invoke_O__O(arg_438) } else { temp__1927000414__auto____7 = linked_436.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_435, arg_438) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1344000044__8 any = temp__1927000414__auto____7; var tmp3 any; var root_439 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = seq_1344000044__8; if linked_440 == nil { tmp3 = ifn_441.Invoke_O__O(arg_442) } else { tmp3 = linked_440.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_439, arg_442) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____9 any; var root_443 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_1344000044__8; if linked_444 == nil { c__1927000678__auto____9 = ifn_445.Invoke_O__O(arg_446) } else { c__1927000678__auto____9 = linked_444.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_443, arg_446) }; var tmp4 any; var root_463 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = seq_1344000044__8; if linked_464 == nil { tmp4 = ifn_465.Invoke_O__O(arg_466) } else { tmp4 = linked_464.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_463, arg_466) }; seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = tmp4, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__9 any; var root_447 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_1344000044__8; if linked_448 == nil { f__9 = ifn_449.Invoke_O__O(arg_450) } else { f__9 = linked_448.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_447, arg_450) }
				var root_473 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = state__2; var arg_477 any = f__9; var arg_478 any; var tmp5 any = A_arbace_repr_go_print_collect_forms_fn__1344000050_A_New(); var tmp6 *jrt.Class; var fncls__472 *jrt.Class = A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class; if fncls__472 == nil { var fncls__472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class = fncls__472d; tmp6 = fncls__472d } else { tmp6 = fncls__472 }; arg_478 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_474 == nil { ifn_475.Invoke_O_O_O__O(arg_476, arg_477, arg_478) } else { linked_474.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_473, arg_476, arg_477, arg_478) }
//line :96:1
				var tmp7 any; var root_479 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1344000044__8; if linked_480 == nil { tmp7 = ifn_481.Invoke_O__O(arg_482) } else { tmp7 = linked_480.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_479, arg_482) }; seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = tmp7, nil, 0, 0; continue L1 } } }
//line :91:1
		break L1 }; var root_426 any =






	A_arbace_repr_go_print_A_const_64.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var root_422 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = state__2; if linked_423 == nil { arg_429 = ifn_424.Invoke_O__O(arg_425) } else { arg_429 = linked_423.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_422, arg_425) }; var arg_430 any = A_arbace_repr_go_print_A_const_40; if linked_427 == nil { return ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { return linked_427.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_426, arg_429, arg_430) } }
//line :97:1
func A_arbace_repr_go_print_collect_forms_fn__1344000048_A_New() *A_arbace_repr_go_print_collect_forms_fn__1344000048_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_fn__1344000048_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000048_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000048_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 any; var root_451 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(); var arg_455 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_66, p__1)); if linked_452 == nil { tmp1 = ifn_453.Invoke_O_O__O(arg_454, arg_455) } else { tmp1 = linked_452.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_451, arg_454, arg_455) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }
//line :97:1
func A_arbace_repr_go_print_collect_forms_fn__1344000050_A_New() *A_arbace_repr_go_print_collect_forms_fn__1344000050_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_fn__1344000050_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000050_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000050_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 any; var root_467 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(); var arg_471 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_66, p__1)); if linked_468 == nil { tmp1 = ifn_469.Invoke_O_O__O(arg_470, arg_471) } else { tmp1 = linked_468.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_467, arg_470, arg_471) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_repr_go_print_collect_A_New() *A_arbace_repr_go_print_collect_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Ctor() {}
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Invoke_O_O_O__O(self, path__0, read_fn__1 any) any { var state__3 any; var root_483 any = A_arbace_repr_go_print_A_const_63.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, A_arbace_repr_go_print_new_package_state_A_fn_class); var ifn_485 lang.IFn; if







	linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; if linked_484 == nil { state__3 = ifn_485.Invoke__O() } else { state__3 = linked_484.(*A_arbace_repr_go_print_new_package_state_A).Invoke_O__O(root_483) }; var root__4 any; var root_486 any = /*line :100:1*/A_arbace_repr_go_print_A_const_61.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_488 lang.IFn; if








	linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any; if linked_487 == nil { root__4 = ifn_488.Invoke_O__O(arg_489) } else { root__4 = linked_487.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_486, arg_489) }; var body_walk__5 /*line :100:1*/*A_arbace_repr_go_print_collect_walk__1344000054_A = A_arbace_repr_go_print_collect_walk__1344000054_A_New_O_O_O(state__3, read_fn__1, root__4); var walk__5 any; var tmp1 *jrt.Class; var fncls__671 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class; if fncls__671 == nil { var fncls__671d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class = fncls__671d; tmp1 = fncls__671d } else { tmp1 = fncls__671 }; walk__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__5), tmp1, nil); var tmp2 lang.IFn =





















	lang.IFn_Cast(walk__5); var tmp3 any; var root_681 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = path__0; if linked_682 == nil { tmp3 = ifn_683.Invoke_O__O(arg_684) } else { tmp3 = linked_682.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_681, arg_684) }; tmp2.Invoke_O__O(jrt.File_New_String(jrt.String_Cast(tmp3))); var root_676 any =
	A_arbace_repr_go_print_A_const_64.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any; var root_672 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = state__3; if linked_673 == nil { arg_679 = ifn_674.Invoke_O__O(arg_675) } else { arg_679 = linked_673.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_672, arg_675) }; var arg_680 any = A_arbace_repr_go_print_A_const_40; if linked_677 == nil { return ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { return linked_677.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_676, arg_679, arg_680) } }
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Invoke_O_O__O(self, path__0 any) any {





	var root_685 any = A_arbace_repr_go_print_A_const_75.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, A_arbace_repr_go_print_collect_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = path__0; var arg_689 any = A_arbace_repr_go_print_A_const_76.GetRawRoot__O(); if linked_686 == nil { return ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { return linked_686.(*A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_685, arg_688, arg_689)
	}
}

func A_arbace_repr_go_print_collect_walk__1344000054_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :110:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_A) Ctor_O_O_O(c__state, c__read_fn, c__root any) { t.F_state = c__state; t.F_read_fn = c__read_fn; t.F_root = c__root }
//line :110:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_A) Invoke_O_O__O(self, file__1 any) any { { var seq_1344000055__2 any; var root_503 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn
													if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_499 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_51; var arg_502 any = tmp1.Invoke_O_O__O(tmp2, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref()); if linked_500 == nil { ifn_501.Invoke_O__O(arg_502) } else { linked_500.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_499, arg_502) }; var tmp3 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_New_O_O(t.F_read_fn, file__1); var tmp4 *jrt.Class; var fncls__493 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class; if fncls__493 == nil { var fncls__493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class = fncls__493d; tmp4 = fncls__493d } else { tmp4 = fncls__493 }; arg_506 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); if linked_504 == nil { seq_1344000055__2 = ifn_505.Invoke_O__O(arg_506) } else { seq_1344000055__2 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }
//line :110:1
	var chunk_1344000056__3 any; var count_1344000057__4 int64 = 0; var i_1344000058__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000058__5, count_1344000057__4) { var f__6 any = lang.Indexed_Cast(chunk_1344000056__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000058__5)); var tmp5 any; var and__1927000168__auto____7 bool; var tmp6 any; var root_548 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_550 lang.IFn
			if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = t.F_root; if linked_549 == nil { tmp6 = ifn_550.Invoke_O__O(arg_551) } else { tmp6 = linked_549.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_548, arg_551) }; and__1927000168__auto____7 = lang.Util_Identical_O_O__Z_NoInit(tmp6, nil); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_552 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = f__6; if linked_553 == nil { and__1927000168__auto____8 = ifn_554.Invoke_O__O(arg_555) } else { and__1927000168__auto____8 = linked_553.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_552, arg_555) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp7 any = A_arbace_repr_go_print_A_const_69; var tmp8 any; var root_556 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = f__6; if linked_557 == nil { tmp8 = ifn_558.Invoke_O__O(arg_559) } else { tmp8 = linked_557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_556, arg_559) }; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp5 = and__1927000168__auto____8 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp5) { var depth__7 int32; var tmp9 any; var root_568 any = A_arbace_repr_go_print_A_const_70.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_570 lang.IFn
				if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = A_arbace_repr_go_print_A_const_71; var arg_572 any; var root_564 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any; var root_560 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = f__6; if linked_561 == nil { arg_567 = ifn_562.Invoke_O__O(arg_563) } else { arg_567 = linked_561.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_560, arg_563) }; if linked_565 == nil { arg_572 = ifn_566.Invoke_O__O(arg_567) } else { arg_572 = linked_565.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_564, arg_567) }; if linked_569 == nil { tmp9 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { tmp9 = linked_569.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; depth__7 = lang.RT_Count_O__I_NoInit(tmp9)
				var root_579 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = t.F_root; var arg_583 any; var tmp10 any; var root_574 any = A_arbace_repr_go_print_A_const_74.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any; var tmp11 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_New(); var tmp12 *jrt.Class; var fncls__573 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class; if fncls__573 == nil { var fncls__573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class = fncls__573d; tmp12 = fncls__573d } else { tmp12 = fncls__573 }; arg_577 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_578 any = jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref(); if linked_575 == nil { tmp10 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { tmp10 = linked_575.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }; arg_583 = lang.RT_Nth_O_I__O_NoInit(tmp10, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(depth__7)))); if linked_580 == nil { ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { linked_580.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_579, arg_582, arg_583)
				} }
			var root_589 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_print_A_const_51; var arg_592 any = tmp13.Invoke_O_O__O(tmp14, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref()); if linked_590 == nil { ifn_591.Invoke_O__O(arg_592) } else { linked_590.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_589, arg_592) }; var tmp15 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_New_O_O_O_O_O(f__6, self, t.F_state, file__1, t.F_root); var tmp16 *jrt.Class; var fncls__547 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class; if fncls__547 == nil { var fncls__547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class = fncls__547d; tmp16 = fncls__547d } else { tmp16 = fncls__547 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :111:1
			seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000058__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_507 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_1344000055__2; if linked_508 == nil { temp__1927000414__auto____6 = ifn_509.Invoke_O__O(arg_510) } else { temp__1927000414__auto____6 = linked_508.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_507, arg_510) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1344000055__7 any = temp__1927000414__auto____6; var tmp17 any; var root_511 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1344000055__7; if linked_512 == nil { tmp17 = ifn_513.Invoke_O__O(arg_514) } else { tmp17 = linked_512.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_511, arg_514) }; if jrt.J2g_Truth(tmp17) { var c__1927000678__auto____8 any; var root_515 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = seq_1344000055__7; if linked_516 == nil { c__1927000678__auto____8 = ifn_517.Invoke_O__O(arg_518) } else { c__1927000678__auto____8 = linked_516.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_515, arg_518) }; var tmp18 any; var root_593 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = seq_1344000055__7; if linked_594 == nil { tmp18 = ifn_595.Invoke_O__O(arg_596) } else { tmp18 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_593, arg_596) }; seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = tmp18, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__8 any; var root_519 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = seq_1344000055__7; if linked_520 == nil { f__8 = ifn_521.Invoke_O__O(arg_522) } else { f__8 = linked_520.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_519, arg_522) }
				var tmp19 any; var and__1927000168__auto____9 bool; var tmp20 any; var root_622 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = t.F_root; if linked_623 == nil { tmp20 = ifn_624.Invoke_O__O(arg_625) } else { tmp20 = linked_623.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_622, arg_625) }; and__1927000168__auto____9 = lang.Util_Identical_O_O__Z_NoInit(tmp20, nil); if and__1927000168__auto____9 { var and__1927000168__auto____10 any; var root_626 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = f__8; if linked_627 == nil { and__1927000168__auto____10 = ifn_628.Invoke_O__O(arg_629) } else { and__1927000168__auto____10 = linked_627.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_626, arg_629) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp21 any = A_arbace_repr_go_print_A_const_69; var tmp22 any; var root_630 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = f__8; if linked_631 == nil { tmp22 = ifn_632.Invoke_O__O(arg_633) } else { tmp22 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; tmp19 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp21, tmp22)).Ref() } else { tmp19 = and__1927000168__auto____10 } } else { tmp19 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp19) { var depth__9 int32; var tmp23 any; var root_642 any = A_arbace_repr_go_print_A_const_70.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_644 lang.IFn
					if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = A_arbace_repr_go_print_A_const_71; var arg_646 any; var root_638 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any; var root_634 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = f__8; if linked_635 == nil { arg_641 = ifn_636.Invoke_O__O(arg_637) } else { arg_641 = linked_635.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_634, arg_637) }; if linked_639 == nil { arg_646 = ifn_640.Invoke_O__O(arg_641) } else { arg_646 = linked_639.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_638, arg_641) }; if linked_643 == nil { tmp23 = ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { tmp23 = linked_643.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) }; depth__9 = lang.RT_Count_O__I_NoInit(tmp23)
					var root_653 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = t.F_root; var arg_657 any; var tmp24 any; var root_648 any = A_arbace_repr_go_print_A_const_74.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var tmp25 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_New(); var tmp26 *jrt.Class; var fncls__647 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class; if fncls__647 == nil { var fncls__647d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class = fncls__647d; tmp26 = fncls__647d } else { tmp26 = fncls__647 }; arg_651 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_652 any = jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref(); if linked_649 == nil { tmp24 = ifn_650.Invoke_O_O__O(arg_651, arg_652) } else { tmp24 = linked_649.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_648, arg_651, arg_652) }; arg_657 = lang.RT_Nth_O_I__O_NoInit(tmp24, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(depth__9)))); if linked_654 == nil { ifn_655.Invoke_O_O__O(arg_656, arg_657) } else { linked_654.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_653, arg_656, arg_657)
					} }
				var root_663 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp28 any = A_arbace_repr_go_print_A_const_51; var arg_666 any = tmp27.Invoke_O_O__O(tmp28, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref()); if linked_664 == nil { ifn_665.Invoke_O__O(arg_666) } else { linked_664.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_663, arg_666) }; var tmp29 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_New_O_O_O_O_O(self, t.F_state, file__1, f__8, t.F_root); var tmp30 *jrt.Class; var fncls__621 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class; if fncls__621 == nil { var fncls__621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class = fncls__621d; tmp30 = fncls__621d } else { tmp30 = fncls__621 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil).Invoke__O()
//line :111:1
				var tmp31 any; var root_667 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq_1344000055__7; if linked_668 == nil { tmp31 = ifn_669.Invoke_O__O(arg_670) } else { tmp31 = linked_668.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_667, arg_670) }; seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = tmp31, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :110:1*/panic("j2g: unreachable") }
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :111:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A) Ctor_O_O(c__read_fn, c__file any) { t.F_read_fn = c__read_fn; t.F_file = c__file }
//line :111:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_read_fn; t.F_read_fn = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_file; t.F_file = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var root_490 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; if linked_491 == nil { ifn_492.Invoke__O() } else { linked_491.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_490) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_New() *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A) Ctor() {}
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A) Invoke_O_O__O(self, p1__1344000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1344000053_SHARP___1)).GetParentFile__File().Ref() }
//line :114:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_New() *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A) Ctor() {}
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A) Invoke_O_O__O(self, p1__1344000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1344000053_SHARP___1)).GetParentFile__File().Ref() }

func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A) Ctor_O_O_O_O_O(c__f, c__walk, c__state, c__file, c__root any) { t.F_f = c__f; t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_root = c__root }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_538 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var t_ any = t.F_state; t.F_state = nil; arg_541 = t_; var arg_542 any; var t__2 any = t.F_f; t.F_f = nil; arg_542 = t__2; var arg_543 any; var tmp2 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp3 *jrt.Class; var fncls__537 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class
														if fncls__537 == nil { var fncls__537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class = fncls__537d; tmp3 = fncls__537d } else { tmp3 = fncls__537 }; arg_543 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :117:1
		if linked_539 == nil { tmp1 = ifn_540.Invoke_O_O_O__O(arg_541, arg_542, arg_543) } else { tmp1 = linked_539.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_538, arg_541, arg_542, arg_543) } }
//line :116:1
	return nil }(); var root_544 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; if linked_545 == nil { ifn_546.Invoke__O() } else { linked_545.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_544) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :116:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A) Ctor_O_O_O_O_O(c__walk, c__state, c__file, c__f, c__root any) { t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_f = c__f; t.F_root = c__root }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_612 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var t_ any = t.F_state; t.F_state = nil; arg_615 = t_; var arg_616 any; var t__2 any = t.F_f; t.F_f = nil; arg_616 = t__2; var arg_617 any; var tmp2 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp3 *jrt.Class; var fncls__611 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class
														if fncls__611 == nil { var fncls__611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class = fncls__611d; tmp3 = fncls__611d } else { tmp3 = fncls__611 }; arg_617 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :117:1
		if linked_613 == nil { tmp1 = ifn_614.Invoke_O_O_O__O(arg_615, arg_616, arg_617) } else { tmp1 = linked_613.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_612, arg_615, arg_616, arg_617) } }
//line :116:1
	return nil }(); var root_618 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; if linked_619 == nil { ifn_620.Invoke__O() } else { linked_619.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_618) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; var tmp3 any; var root_523 any = A_arbace_repr_go_print_A_const_52.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = p__1; var arg_527 any = Lit_10; if linked_524 == nil { tmp3 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp3 = linked_524.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_528 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_530 lang.IFn
		if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = t.F_root; if linked_529 == nil { tmp4 = ifn_530.Invoke_O__O(arg_531) } else { tmp4 = linked_529.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_528, arg_531) }
//line :119:1
		var tmp5 *jrt.File = jrt.File_Cast(tmp4); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp7 any; var root_532 any = A_arbace_repr_go_print_A_const_67.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_534 lang.IFn
		if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = p__1; var arg_536 any = A_arbace_repr_go_print_A_const_68; if linked_533 == nil { tmp7 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { tmp7 = linked_533.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }
//line :119:1
		tmp2 = jrt.File_New_File_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref()) }
//line :118:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; var tmp3 any; var root_597 any = A_arbace_repr_go_print_A_const_52.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = p__1; var arg_601 any = Lit_10; if linked_598 == nil { tmp3 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { tmp3 = linked_598.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_602 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_604 lang.IFn
		if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = t.F_root; if linked_603 == nil { tmp4 = ifn_604.Invoke_O__O(arg_605) } else { tmp4 = linked_603.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_602, arg_605) }
//line :119:1
		var tmp5 *jrt.File = jrt.File_Cast(tmp4); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp7 any; var root_606 any = A_arbace_repr_go_print_A_const_67.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_608 lang.IFn
		if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = p__1; var arg_610 any = A_arbace_repr_go_print_A_const_68; if linked_607 == nil { tmp7 = ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { tmp7 = linked_607.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) }
//line :119:1
		tmp2 = jrt.File_New_File_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref())
}







func A_arbace_repr_go_print_name_text_A_New() *A_arbace_repr_go_print_name_text_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_name_text_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_repr_go_print_name_text_A) Ctor() {}
//line :128:1
func (t *A_arbace_repr_go_print_name_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_690 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = x__0; if linked_691 == nil { and__1927000168__auto____2 = ifn_692.Invoke_O__O(arg_693) } else { and__1927000168__auto____2 = linked_691.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_690, arg_693) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_repr_go_print_A_const_77; var tmp3 any; var root_694 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = x__0; if linked_695 == nil { tmp3 = ifn_696.Invoke_O__O(arg_697) } else { tmp3 = linked_695.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_694, arg_697) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_702 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var root_698 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = x__0; if linked_699 == nil { arg_705 = ifn_700.Invoke_O__O(arg_701) } else { arg_705 = linked_699.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_698, arg_701) }; if linked_703 == nil { return ifn_704.Invoke_O__O(arg_705) } else { return linked_703.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_702, arg_705) } } else { var root_706 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = x__0; if linked_707 == nil { return ifn_708.Invoke_O__O(arg_709) } else { return linked_707.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_706, arg_709)
	} } }
func A_arbace_repr_go_print_import_spec_A_New() *A_arbace_repr_go_print_import_spec_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_import_spec_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_repr_go_print_import_spec_A) Ctor() {}
//line :133:1
func (t *A_arbace_repr_go_print_import_spec_A) Invoke_O_O__O(self, v__0 any) any { var vec__1344000076__2 any = v__0; var nm__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000076__2, lang.RT_IntCast_J__I_NoInit(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000076__2, lang.RT_IntCast_J__I_NoInit(1), nil); var explicit_QMARK___5 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_78; var or__1927000174__auto____5 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)); if

	jrt.J2g_Truth(or__1927000174__auto____5) { explicit_QMARK___5 = or__1927000174__auto____5 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_79); var tmp3 any; var root_718 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = nm__3; if linked_719 == nil { tmp3 = ifn_720.Invoke_O__O(arg_721) } else { tmp3 = linked_719.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_718, arg_721) }; explicit_QMARK___5 = tmp2.Invoke_O__O(tmp3) }; if
	jrt.J2g_Truth(explicit_QMARK___5) { var root_729 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any; var root_725 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = nm__3; if linked_726 == nil { arg_732 = ifn_727.Invoke_O__O(arg_728) } else { arg_732 = linked_726.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_725, arg_728) }; if linked_730 == nil { ifn_731.Invoke_O__O(arg_732) } else { linked_730.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_729, arg_732) }; var root_722 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; if linked_723 == nil { ifn_724.Invoke__O() } else { linked_723.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_722) } }; var root_714 any =
	A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any; var root_710 any = A_arbace_repr_go_print_A_const_81.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_go_string_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = path__4; if linked_711 == nil { arg_717 = ifn_712.Invoke_O__O(arg_713) } else { arg_717 = linked_711.(*aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_go_string_A).Invoke_O_O__O(root_710, arg_713) }; if linked_715 == nil { return ifn_716.Invoke_O__O(arg_717) } else { return linked_715.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_714, arg_717) } }

func A_arbace_repr_go_print_write_import_decl_A_New() *A_arbace_repr_go_print_write_import_decl_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_import_decl_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_repr_go_print_write_import_decl_A) Ctor() {}
//line :139:1
func (t *A_arbace_repr_go_print_write_import_decl_A) Invoke_O_O__O(self, specs__0 any) any {
	if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(specs__0))) {
		var root_741 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = Lit_100; if linked_742 == nil { ifn_743.Invoke_O__O(arg_744) } else { linked_742.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_741, arg_744) }; var root_745 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; if linked_746 == nil { ifn_747.Invoke__O() } else { linked_746.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_745) }; var root_752 any = A_arbace_repr_go_print_A_const_86.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, A_arbace_repr_go_print_import_spec_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_748 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = specs__0; if linked_749 == nil { arg_755 = ifn_750.Invoke_O__O(arg_751) } else { arg_755 = linked_749.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_748, arg_751) }; if linked_753 == nil { ifn_754.Invoke_O__O(arg_755) } else { linked_753.(*A_arbace_repr_go_print_import_spec_A).Invoke_O_O__O(root_752, arg_755) }; var root_733 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = A_arbace_repr_go_print_A_const_85; if linked_734 == nil { return ifn_735.Invoke_O__O(arg_736) } else { return linked_734.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_733, arg_736) } } else {
			var root_756 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = Lit_100; if linked_757 == nil { ifn_758.Invoke_O__O(arg_759) } else { linked_757.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_756, arg_759) }; var root_760 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; if linked_761 == nil { ifn_762.Invoke__O() } else { linked_761.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_760) }; var root_763 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = Lit_101; if linked_764 == nil { ifn_765.Invoke_O__O(arg_766) } else { linked_764.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_763, arg_766) }
			var root_767 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = A_arbace_repr_go_print_A_const_68; if linked_768 == nil { ifn_769.Invoke_O__O(arg_770) } else { linked_768.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_767, arg_770) }
//line :140:1
			var G__1344000083__2_ any = specs__0; var vec__1344000084__3 any = G__1344000083__2_; var seq__1344000085__4 any; var root_771 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_773 lang.IFn



			if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = vec__1344000084__3; if linked_772 == nil { seq__1344000085__4 = ifn_773.Invoke_O__O(arg_774) } else { seq__1344000085__4 = linked_772.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_771, arg_774) }
//line :140:1
			var first__1344000086__5 any; var root_775 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_777 lang.IFn



			if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = seq__1344000085__4; if linked_776 == nil { first__1344000086__5 = ifn_777.Invoke_O__O(arg_778) } else { first__1344000086__5 = linked_776.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_775, arg_778) }
//line :140:1
			var seq__1344000085__6 any; var root_779 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_781 lang.IFn



			if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = seq__1344000085__4; if linked_780 == nil { seq__1344000085__6 = ifn_781.Invoke_O__O(arg_782) } else { seq__1344000085__6 = linked_780.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_779, arg_782) }
//line :140:1
			var v__7 any = first__1344000086__5; var more__8 any = seq__1344000085__6; var prev__9 any; var G__1344000083__10_ any = G__1344000083__2_; var prev__11 any = prev__9; _ = v__7; _ = more__8; L1: for { var vec__1344000087__12 any = G__1344000083__10_; var seq__1344000088__13 any; var root_783 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_785 lang.IFn



				if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = vec__1344000087__12; if linked_784 == nil { seq__1344000088__13 = ifn_785.Invoke_O__O(arg_786) } else { seq__1344000088__13 = linked_784.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_783, arg_786) }
//line :140:1
				var first__1344000089__14 any; var root_787 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_789 lang.IFn



				if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = seq__1344000088__13; if linked_788 == nil { first__1344000089__14 = ifn_789.Invoke_O__O(arg_790) } else { first__1344000089__14 = linked_788.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_787, arg_790) }
//line :140:1
				var seq__1344000088__15 any; var root_791 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_793 lang.IFn



				if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = seq__1344000088__13; if linked_792 == nil { seq__1344000088__15 = ifn_793.Invoke_O__O(arg_794) } else { seq__1344000088__15 = linked_792.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_791, arg_794) }
//line :140:1
				var v__16 any = first__1344000089__14
				var more__17 any = seq__1344000088__15
				var prev__18 any = prev__11


				if jrt.J2g_Truth(v__16) {


					var tmp1 any; var and__1927000168__auto____19 any = prev__18; if jrt.J2g_Truth(and__1927000168__auto____19) { var tmp2 any; var root_803 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any; var root_799 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = v__16; if linked_800 == nil { arg_806 = ifn_801.Invoke_O__O(arg_802) } else { arg_806 = linked_800.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_799, arg_802) }; if linked_804 == nil { tmp2 = ifn_805.Invoke_O__O(arg_806) } else { tmp2 = linked_804.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_803, arg_806) }; var tmp3 any = tmp2; var tmp4 any; var root_811 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any; var root_807 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = prev__18; if linked_808 == nil { arg_814 = ifn_809.Invoke_O__O(arg_810) } else { arg_814 = linked_808.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_807, arg_810) }; if linked_812 == nil { tmp4 = ifn_813.Invoke_O__O(arg_814) } else { tmp4 = linked_812.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_811, arg_814) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(tmp3, tmp4)))).Ref() } else { tmp1 = and__1927000168__auto____19 }; if jrt.J2g_Truth(tmp1) {
						var root_815 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = A_arbace_repr_go_print_A_const_68; if linked_816 == nil { ifn_817.Invoke_O__O(arg_818) } else { linked_816.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_815, arg_818) } }
					var root_819 any = A_arbace_repr_go_print_A_const_86.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, A_arbace_repr_go_print_import_spec_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = v__16; if linked_820 == nil { ifn_821.Invoke_O__O(arg_822) } else { linked_820.(*A_arbace_repr_go_print_import_spec_A).Invoke_O_O__O(root_819, arg_822) }
					var root_823 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; if jrt.J2g_Truth(more__17) { arg_826 = A_arbace_repr_go_print_A_const_68 } else { arg_826 = A_arbace_repr_go_print_A_const_85 }; if linked_824 == nil { ifn_825.Invoke_O__O(arg_826) } else { linked_824.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_823, arg_826) }
					G__1344000083__10_, prev__11 = more__17, v__16; continue L1 }
//line :140:1
				break L1
			}











			var root_795 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = Lit_102; if linked_796 == nil { ifn_797.Invoke_O__O(arg_798) } else { linked_796.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_795, arg_798) }; var root_737 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = A_arbace_repr_go_print_A_const_85; if linked_738 == nil { return ifn_739.Invoke_O__O(arg_740) } else { return linked_738.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_737, arg_740)
			} } }
func A_arbace_repr_go_print_write_imports_A_New() *A_arbace_repr_go_print_write_imports_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_repr_go_print_write_imports_A) Ctor() {}
//line :155:1
func (t *A_arbace_repr_go_print_write_imports_A) Invoke_O_O__O(self, imports__0 any) any {



	{ var tmp1 any; var root_827 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = imports__0; if linked_828 == nil { tmp1 = ifn_829.Invoke_O__O(arg_830) } else { tmp1 = linked_828.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_827, arg_830) }; if jrt.J2g_Truth(tmp1) {
		var root_853 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = A_arbace_repr_go_print_A_const_85; if linked_854 == nil { ifn_855.Invoke_O__O(arg_856) } else { linked_854.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_853, arg_856) }
//line :159:1
		var directive_QMARK___2 any; var tmp2 any = A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_New(); var tmp3 *jrt.Class
		var fncls__839 /*line :159:1*/*jrt.Class = A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_fn_class

		if fncls__839 == nil { var fncls__839d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_fn_class = fncls__839d; tmp3 = fncls__839d } else { tmp3 = fncls__839 }; directive_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :159:1
		var xs__3 any; var root_840 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_842 lang.IFn


		if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = imports__0; if linked_841 == nil { xs__3 = ifn_842.Invoke_O__O(arg_843) } else { xs__3 = linked_841.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_840, arg_843) }
//line :159:1
	L1: for {



		if jrt.J2g_Truth(xs__3) {
			var tmp4 lang.IFn = lang.IFn_Cast(directive_QMARK___2); var tmp5 any; var root_857 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = xs__3; if linked_858 == nil { tmp5 = ifn_859.Invoke_O__O(arg_860) } else { tmp5 = linked_858.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_857, arg_860) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) {
				var root_873 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any; var root_869 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any; var root_865 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any; var root_861 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = xs__3; if linked_862 == nil { arg_868 = ifn_863.Invoke_O__O(arg_864) } else { arg_868 = linked_862.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_861, arg_864) }; if linked_866 == nil { arg_872 = ifn_867.Invoke_O__O(arg_868) } else { arg_872 = linked_866.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_865, arg_868) }; if linked_870 == nil { arg_876 = ifn_871.Invoke_O__O(arg_872) } else { arg_876 = linked_870.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_869, arg_872) }; var arg_877 any = A_arbace_repr_go_print_A_const_85; if linked_874 == nil { ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { linked_874.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) }
				var tmp6 any; var root_878 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = xs__3; if linked_879 == nil { tmp6 = ifn_880.Invoke_O__O(arg_881) } else { tmp6 = linked_879.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_878, arg_881) }; xs__3 = tmp6; continue L1 } else {
//line :164:1
					var vec__1344000094__4 any; var root_848 any = A_arbace_repr_go_print_A_const_87.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_850 lang.IFn


					if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var root_844 any = A_arbace_repr_go_print_A_const_88.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = directive_QMARK___2; if linked_845 == nil { arg_851 = ifn_846.Invoke_O__O(arg_847) } else { arg_851 = linked_845.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_844, arg_847) }; var arg_852 any = xs__3; if linked_849 == nil { vec__1344000094__4 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { vec__1344000094__4 = linked_849.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) }
//line :164:1
					var specs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000094__4, lang.RT_IntCast_J__I_NoInit(0), nil); var more__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000094__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_886 any = A_arbace_repr_go_print_A_const_90.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_repr_go_print_write_import_decl_A_fn_class); var ifn_888 lang.IFn



					if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any; var root_882 any = A_arbace_repr_go_print_A_const_91.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = specs__5; if linked_883 == nil { arg_889 = ifn_884.Invoke_O__O(arg_885) } else { arg_889 = linked_883.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_882, arg_885) }; if linked_887 == nil { ifn_888.Invoke_O__O(arg_889) } else { linked_887.(*A_arbace_repr_go_print_write_import_decl_A).Invoke_O_O__O(root_886, arg_889) }
					var tmp7 any; var root_890 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = more__6; if linked_891 == nil { tmp7 = ifn_892.Invoke_O__O(arg_893) } else { tmp7 = linked_891.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_890, arg_893) }; xs__3 = tmp7; continue L1 } } else {
//line :163:1
						return nil } } } else {
//line :159:1
							return nil } }
//line :155:1
	panic("j2g: unreachable")
}




func A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_New() *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A) Invoke_O_O__O(self, p1__1344000091_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_831 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = p1__1344000091_SHARP___1; if linked_832 == nil { and__1927000168__auto____2 = ifn_833.Invoke_O__O(arg_834) } else { and__1927000168__auto____2 = linked_832.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_831, arg_834) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any; var root_835 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = p1__1344000091_SHARP___1; if linked_836 == nil { tmp1 = ifn_837.Invoke_O__O(arg_838) } else { tmp1 = linked_836.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_835, arg_838) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, Lit_67)).Ref() } else { return and__1927000168__auto____2 } }









func A_arbace_repr_go_print_write_imports_full_A_New() *A_arbace_repr_go_print_write_imports_full_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_full_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_repr_go_print_write_imports_full_A) Ctor() {}
//line :171:1
func (t *A_arbace_repr_go_print_write_imports_full_A) Invoke_O_O__O(self, imports__0 any) any { var open__2 any; var root_894 any = A_arbace_repr_go_print_A_const_61.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_896 lang.IFn; if




	linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any; if linked_895 == nil { open__2 = ifn_896.Invoke_O__O(arg_897) } else { open__2 = linked_895.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_894, arg_897) }; var close_BANG___3 any; var tmp1 any = /*line :171:1*/A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_New_O(open__2); var tmp2 *jrt.Class; var fncls__912 *jrt.Class = A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_fn_class; if





	fncls__912 == nil { var fncls__912d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_fn_class = fncls__912d; tmp2 = fncls__912d } else { tmp2 = fncls__912 }; close_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var seq_1344000100__4 any; var root_913 any = /*line :171:1*/A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_915 lang.IFn; if






	linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = imports__0; if linked_914 == nil { seq_1344000100__4 = ifn_915.Invoke_O__O(arg_916) } else { seq_1344000100__4 = linked_914.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_913, arg_916) }; var chunk_1344000101__5 any; var count_1344000102__6 int64 = 0; var i_1344000103__7 int64 = 0; L1:
//line :171:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000103__7, count_1344000102__6) { var v__8 any = lang.Indexed_Cast(chunk_1344000101__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000103__7)); var tmp3 any; var root_917 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = v__8; if linked_918 == nil { tmp3 = ifn_919.Invoke_O__O(arg_920) } else { tmp3 = linked_918.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_917, arg_920) }; if jrt.J2g_Truth(tmp3) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var p__9 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__8)); var vec__1344000104__10 any = v__8; var nm__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000104__10, lang.RT_IntCast_J__I_NoInit(0), nil); var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000104__10, lang.RT_IntCast_J__I_NoInit(1), nil)


			if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__9)) {
				lang.IFn_Cast(close_BANG___3).Invoke__O()
				var root_962 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = Lit_100; var arg_966 any = A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__9); if linked_963 == nil { ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { linked_963.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_962, arg_965, arg_966) }; var root_967 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; if linked_968 == nil { ifn_969.Invoke__O() } else { linked_968.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_967) }
				if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__9)) { var root_970 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = Lit_101; var arg_974 any = A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__9); if linked_971 == nil { ifn_972.Invoke_O_O__O(arg_973, arg_974) } else { linked_971.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_970, arg_973, arg_974) } }
				var root_946 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = open__2; var arg_950 any = p__9; if linked_947 == nil { ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { linked_947.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } else {
					var root_951 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = A_arbace_repr_go_print_A_const_99; var arg_955 any = Lit_95; if linked_952 == nil { ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { linked_952.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) } }
			var tmp5 any; var tmp6 *lang.Keyword = A_arbace_repr_go_print_A_const_78; var or__1927000174__auto____13 any = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__8)); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp5 = or__1927000174__auto____13 } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_100); var tmp8 any; var root_975 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = nm__11; if linked_976 == nil { tmp8 = ifn_977.Invoke_O__O(arg_978) } else { tmp8 = linked_976.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_975, arg_978) }; tmp5 = tmp7.Invoke_O__O(tmp8) }; if jrt.J2g_Truth(tmp5) {
				var root_983 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any; var root_979 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = nm__11; if linked_980 == nil { arg_986 = ifn_981.Invoke_O__O(arg_982) } else { arg_986 = linked_980.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_979, arg_982) }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_A_const_101; var tmp10 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var arg_987 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__11))); if linked_984 == nil { ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { linked_984.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_983, arg_986, arg_987) }; var root_956 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; if linked_957 == nil { ifn_958.Invoke__O() } else { linked_957.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_956) } }
			var root_959 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; if linked_960 == nil { ifn_961.Invoke__O() } else { linked_960.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_959) }
			var root_941 any = A_arbace_repr_go_print_A_const_96.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = path__12; var arg_945 any = A_arbace_repr_go_print_A_const_68; if linked_942 == nil { ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { linked_942.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) }
//line :178:1
			seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000103__7); continue L1 } else { seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000103__7); continue L1 } } else { var temp__1927000414__auto____8 any; var root_921 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = seq_1344000100__4; if linked_922 == nil { temp__1927000414__auto____8 = ifn_923.Invoke_O__O(arg_924) } else { temp__1927000414__auto____8 = linked_922.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_921, arg_924) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1344000100__9 any = temp__1927000414__auto____8; var tmp11 any; var root_925 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = seq_1344000100__9; if linked_926 == nil { tmp11 = ifn_927.Invoke_O__O(arg_928) } else { tmp11 = linked_926.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_925, arg_928) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____10 any; var root_929 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = seq_1344000100__9; if linked_930 == nil { c__1927000678__auto____10 = ifn_931.Invoke_O__O(arg_932) } else { c__1927000678__auto____10 = linked_930.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_929, arg_932) }; var tmp12 any; var root_988 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = seq_1344000100__9; if linked_989 == nil { tmp12 = ifn_990.Invoke_O__O(arg_991) } else { tmp12 = linked_989.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_988, arg_991) }; seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = tmp12, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var v__10 any; var root_933 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = seq_1344000100__9; if linked_934 == nil { v__10 = ifn_935.Invoke_O__O(arg_936) } else { v__10 = linked_934.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_933, arg_936) }; var tmp13 any; var root_937 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = v__10; if linked_938 == nil { tmp13 = ifn_939.Invoke_O__O(arg_940) } else { tmp13 = linked_938.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_937, arg_940) }; if jrt.J2g_Truth(tmp13) { var tmp14 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var p__11 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__10)); var vec__1344000107__12 any = v__10; var nm__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000107__12, lang.RT_IntCast_J__I_NoInit(0), nil); var path__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000107__12, lang.RT_IntCast_J__I_NoInit(1), nil)


				if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__11)) {
					lang.IFn_Cast(close_BANG___3).Invoke__O()
					var root_1013 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = Lit_100; var arg_1017 any = A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__11); if linked_1014 == nil { ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { linked_1014.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) }; var root_1018 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; if linked_1019 == nil { ifn_1020.Invoke__O() } else { linked_1019.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1018) }
					if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__11)) { var root_1021 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = Lit_101; var arg_1025 any = A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__11); if linked_1022 == nil { ifn_1023.Invoke_O_O__O(arg_1024, arg_1025) } else { linked_1022.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1021, arg_1024, arg_1025) } }
					var root_997 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = open__2; var arg_1001 any = p__11; if linked_998 == nil { ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { linked_998.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) } } else {
						var root_1002 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = A_arbace_repr_go_print_A_const_99; var arg_1006 any = Lit_95; if linked_1003 == nil { ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { linked_1003.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) } }
				var tmp15 any; var tmp16 *lang.Keyword = A_arbace_repr_go_print_A_const_78; var or__1927000174__auto____15 any = tmp16.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__10)); if jrt.J2g_Truth(or__1927000174__auto____15) { tmp15 = or__1927000174__auto____15 } else { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_102); var tmp18 any; var root_1026 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = nm__13; if linked_1027 == nil { tmp18 = ifn_1028.Invoke_O__O(arg_1029) } else { tmp18 = linked_1027.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1026, arg_1029) }; tmp15 = tmp17.Invoke_O__O(tmp18) }; if jrt.J2g_Truth(tmp15) {
					var root_1034 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any; var root_1030 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = nm__13; if linked_1031 == nil { arg_1037 = ifn_1032.Invoke_O__O(arg_1033) } else { arg_1037 = linked_1031.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1030, arg_1033) }; var tmp19 *lang.Keyword = A_arbace_repr_go_print_A_const_101; var tmp20 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var arg_1038 any = tmp19.Invoke_O__O(tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__13))); if linked_1035 == nil { ifn_1036.Invoke_O_O__O(arg_1037, arg_1038) } else { linked_1035.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1034, arg_1037, arg_1038) }; var root_1007 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; if linked_1008 == nil { ifn_1009.Invoke__O() } else { linked_1008.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1007) } }
				var root_1010 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; if linked_1011 == nil { ifn_1012.Invoke__O() } else { linked_1011.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1010) }
				var root_992 any = A_arbace_repr_go_print_A_const_96.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = path__14; var arg_996 any = A_arbace_repr_go_print_A_const_68; if linked_993 == nil { ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { linked_993.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) }
//line :178:1
				var tmp21 any; var root_1039 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = seq_1344000100__9; if linked_1040 == nil { tmp21 = ifn_1041.Invoke_O__O(arg_1042) } else { tmp21 = linked_1040.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1039, arg_1042) }; seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = tmp21, nil, 0, 0; continue L1 } else { var tmp22 any; var root_1043 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = seq_1344000100__9; if linked_1044 == nil { tmp22 = ifn_1045.Invoke_O__O(arg_1046) } else { tmp22 = linked_1044.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1043, arg_1046) }; seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = tmp22, nil, 0, 0; continue L1 } } } }
//line :171:1
		break L1 }; return /*line :191:1*/ lang.IFn_Cast(close_BANG___3).Invoke__O() }
//line :177:1
func A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_New_O(p0 any) *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A) Ctor_O(c__open any) { t.F_open = c__open }
//line :177:1
func (t *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var root_903 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = t.F_open; if linked_904 == nil { temp__1927000414__auto____1 = ifn_905.Invoke_O__O(arg_906) } else { temp__1927000414__auto____1 = linked_904.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_903, arg_906) }; if jrt.J2g_Truth(temp__1927000414__auto____1) { var d__2 any = temp__1927000414__auto____1; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_92.Invoke_O__O(d__2)) { var root_907 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = Lit_102; var arg_911 any = A_arbace_repr_go_print_A_const_94.Invoke_O__O(d__2); if linked_908 == nil { ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { linked_908.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_907, arg_910, arg_911) } } }; var root_898 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = t.F_open; var arg_902 any; if linked_899 == nil { return ifn_900.Invoke_O_O__O(arg_901, arg_902) } else { return linked_899.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_898, arg_901, arg_902) } }















func A_arbace_repr_go_print_one_line_func_QMARK__A_New() *A_arbace_repr_go_print_one_line_func_QMARK__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_one_line_func_QMARK__A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_repr_go_print_one_line_func_QMARK__A) Ctor() {}
//line :193:1
func (t *A_arbace_repr_go_print_one_line_func_QMARK__A) Invoke_O_O_O_O__O(self, f__0, lines_QMARK___1, t__2 any) any { var and__1927000168__auto____4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_103); var tmp2 any; var root_1091 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1093 lang.IFn; if



	linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = f__0; if linked_1092 == nil { tmp2 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp2 = linked_1092.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1091, arg_1094) }; and__1927000168__auto____4 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(and__1927000168__auto____4) {
		if jrt.J2g_Truth(lines_QMARK___1) { var and__1927000168__auto____5 any = t__2
			if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_104; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)), t__2)).Ref() } else { return and__1927000168__auto____5 } } else {
//line :198:1
				var vec__1344000111__5 any = f__0; var seq__1344000112__6 any; var root_1047 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1049 lang.IFn

				if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = vec__1344000111__5; if linked_1048 == nil { seq__1344000112__6 = ifn_1049.Invoke_O__O(arg_1050) } else { seq__1344000112__6 = linked_1048.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1047, arg_1050) }
//line :198:1
				var first__1344000113__7 any; var root_1051 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1053 lang.IFn

				if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = seq__1344000112__6; if linked_1052 == nil { first__1344000113__7 = ifn_1053.Invoke_O__O(arg_1054) } else { first__1344000113__7 = linked_1052.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1051, arg_1054) }
//line :198:1
				var seq__1344000112__8 any; var root_1055 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1057 lang.IFn

				if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = seq__1344000112__6; if linked_1056 == nil { seq__1344000112__8 = ifn_1057.Invoke_O__O(arg_1058) } else { seq__1344000112__8 = linked_1056.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1055, arg_1058) }
//line :198:1
				var ___9 any = first__1344000113__7; var first__1344000113__10 any; var root_1059 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1061 lang.IFn; _ = ___9

				if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = seq__1344000112__8; if linked_1060 == nil { first__1344000113__10 = ifn_1061.Invoke_O__O(arg_1062) } else { first__1344000113__10 = linked_1060.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1059, arg_1062) }
//line :198:1
				var seq__1344000112__11 any; var root_1063 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1065 lang.IFn

				if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = seq__1344000112__8; if linked_1064 == nil { seq__1344000112__11 = ifn_1065.Invoke_O__O(arg_1066) } else { seq__1344000112__11 = linked_1064.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1063, arg_1066) }
//line :198:1
				var nm__12 any = first__1344000113__10; var xs__13 any = seq__1344000112__11; var vec__1344000114__14 any; var root_1067 any = A_arbace_repr_go_print_A_const_105.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_parse_decl_head_A_fn_class); var ifn_1069 lang.IFn


				if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = xs__13; if linked_1068 == nil { vec__1344000114__14 = ifn_1069.Invoke_O__O(arg_1070) } else { vec__1344000114__14 = linked_1068.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_parse_decl_head_A).Invoke_O_O__O(root_1067, arg_1070) }
//line :198:1
				var ___15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000114__14, lang.RT_IntCast_J__I_NoInit(0), nil); var ___16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000114__14, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000114__14, lang.RT_IntCast_J__I_NoInit(2), nil); var body__18 any; var root_1071 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1073 lang.IFn; _ = ___15; _ = ___16



				if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = xs__17; if linked_1072 == nil { body__18 = ifn_1073.Invoke_O__O(arg_1074) } else { body__18 = linked_1072.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1071, arg_1074) }
//line :198:1
				var body__19 any; var tmp4 any; var root_1075 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1077 lang.IFn




				if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = body__18; if linked_1076 == nil { tmp4 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp4 = linked_1076.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1075, arg_1078) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_repr_go_print_A_const_106) { var root_1079 any = A_arbace_repr_go_print_A_const_107.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = body__18; if linked_1080 == nil { body__19 = ifn_1081.Invoke_O__O(arg_1082) } else { body__19 = linked_1080.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_1079, arg_1082) } } else { body__19 = body__18 }
//line :198:1
				var and__1927000168__auto____20 any; var root_1083 any = A_arbace_repr_go_print_A_const_53.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1085 lang.IFn





				if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = body__19; if linked_1084 == nil { and__1927000168__auto____20 = ifn_1085.Invoke_O__O(arg_1086) } else { and__1927000168__auto____20 = linked_1084.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1083, arg_1086) }; if jrt.J2g_Truth(and__1927000168__auto____20) { var root_1087 any = A_arbace_repr_go_print_A_const_108.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_A_const_109; var arg_1090 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__12)); if linked_1088 == nil { return ifn_1089.Invoke_O__O(arg_1090) } else { return linked_1088.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1087, arg_1090) } } else { return and__1927000168__auto____20 } } } else {
//line :197:1
					return and__1927000168__auto____4 } }








func A_arbace_repr_go_print_decl_pre_A_New() *A_arbace_repr_go_print_decl_pre_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_decl_pre_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_repr_go_print_decl_pre_A) Ctor() {}
//line :206:1
func (t *A_arbace_repr_go_print_decl_pre_A) Invoke_O_O__O(self, f__0 any) any { var directive_QMARK___2 bool; var tmp1 any; var root_1095 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1097 lang.IFn; if


	linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = f__0; if linked_1096 == nil { tmp1 = ifn_1097.Invoke_O__O(arg_1098) } else { tmp1 = linked_1096.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1095, arg_1098) }; directive_QMARK___2 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, Lit_67); var vec__1344000118__3 any; if directive_QMARK___2 {
		vec__1344000118__3 = lang.Tuple_Create_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref()) } else { var root_1099 any = A_arbace_repr_go_print_A_const_110.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_decl_doc_and_directives_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = f__0; if linked_1100 == nil { vec__1344000118__3 = ifn_1101.Invoke_O__O(arg_1102) } else { vec__1344000118__3 = linked_1100.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_decl_doc_and_directives_A).Invoke_O_O__O(root_1099, arg_1102) } }; var doc__4 any = /*line :206:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1344000118__3, lang.RT_IntCast_J__I_NoInit(0), nil); var dirs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000118__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(directive_QMARK___2).Ref(); var tmp3 any; var root_1103 any = A_arbace_repr_go_print_A_const_111.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_pre_lines_A_fn_class); var ifn_1105 lang.IFn; if




	linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = doc__4; var arg_1107 any = dirs__5; if linked_1104 == nil { tmp3 = ifn_1105.Invoke_O_O__O(arg_1106, arg_1107) } else { tmp3 = linked_1104.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_pre_lines_A).Invoke_O_O_O__O(root_1103, arg_1106, arg_1107) }; return /*line :206:1*/ lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, doc__4, dirs__5, tmp3) }






func A_arbace_repr_go_print_next_target_A_New() *A_arbace_repr_go_print_next_target_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_next_target_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_repr_go_print_next_target_A) Ctor() {}
//line :213:1
func (t *A_arbace_repr_go_print_next_target_A) Invoke_O_O_O__O(self, decls__0, i__1 any) any {


	var root_1124 any = A_arbace_repr_go_print_A_const_112.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any; var tmp1 any = A_arbace_repr_go_print_next_target_fn__1344000122_A_New(); var tmp2 *jrt.Class; var fncls__1116 *jrt.Class = A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class; if fncls__1116 == nil { var fncls__1116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class = fncls__1116d; tmp2 = fncls__1116d } else { tmp2 = fncls__1116 }; arg_1127 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1128 any; var root_1119 any = A_arbace_repr_go_print_A_const_118.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1121 lang.IFn

	if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = decls__0; var arg_1123 any; var na_1117 any = i__1; if jrt.Long_InstanceOf(na_1117) { var n0_1118 int64 = jrt.NN(jrt.Long_Cast(na_1117)).LongValue__J(); if n0_1118 == 9223372036854775807 { arg_1123 = lang.Numbers_Inc_O__Number_NoInit(na_1117) } else { arg_1123 = jrt.Long_ValueOf_J__Long_NoInit(n0_1118 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1117) { var n0_1118_2 float64 = jrt.NN(jrt.Double_Cast(na_1117)).DoubleValue__D(); arg_1123 = jrt.Double_ValueOf_D__Double_NoInit(n0_1118_2 + 1.0).Ref() } else { arg_1123 = lang.Numbers_Inc_O__Number_NoInit(na_1117) } }; if linked_1120 == nil { arg_1128 = ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { arg_1128 = linked_1120.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) }
//line :216:1
	if linked_1125 == nil { return ifn_1126.Invoke_O_O__O(arg_1127, arg_1128) } else { return linked_1125.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1124, arg_1127, arg_1128) } }
//line :216:1
func A_arbace_repr_go_print_next_target_fn__1344000122_A_New() *A_arbace_repr_go_print_next_target_fn__1344000122_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_next_target_fn__1344000122_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_repr_go_print_next_target_fn__1344000122_A) Ctor() {}
//line :216:1
func (t *A_arbace_repr_go_print_next_target_fn__1344000122_A) Invoke_O_O__O(self, d__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(d__1)); var tmp3 any; var root_1108 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = l__308000057__auto____2; if linked_1109 == nil { tmp3 = ifn_1110.Invoke_O__O(arg_1111) } else { tmp3 = linked_1109.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1108, arg_1111) }; if jrt.J2g_Truth(tmp3) { temp__1927000414__auto____2 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____2)).Ref() } else { temp__1927000414__auto____2 = nil } } else { temp__1927000414__auto____2 = nil }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var tmp4 int64 = lang.RT_LongCast_O__J_NoInit(t__3); var tmp5 any; var root_1112 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1114 lang.IFn
												if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = d__1; if linked_1113 == nil { tmp5 = ifn_1114.Invoke_O__O(arg_1115) } else { tmp5 = linked_1113.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1112, arg_1115) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(tmp4, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(3))))).Ref() } else {
//line :216:1
		return nil } }



func A_arbace_repr_go_print_decl_sep_BANG__A_New() *A_arbace_repr_go_print_decl_sep_BANG__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_decl_sep_BANG__A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_go_print_decl_sep_BANG__A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_go_print_decl_sep_BANG__A) Invoke_O_O_O_O_O__O(self, f__0, t__1, pre__2, lines_QMARK___3 any) any { { var ff__5 any; var or__1927000174__auto____5 any; var root_1135 any = A_arbace_repr_go_print_A_const_108.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1137 lang.IFn





	if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any; var root_1129 any = A_arbace_repr_go_print_A_const_119.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, A_arbace_repr_go_print_one_line_func_QMARK__A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = f__0; var arg_1133 any = lines_QMARK___3; var arg_1134 any = t__1; if linked_1130 == nil { arg_1138 = ifn_1131.Invoke_O_O_O__O(arg_1132, arg_1133, arg_1134) } else { arg_1138 = linked_1130.(*A_arbace_repr_go_print_one_line_func_QMARK__A).Invoke_O_O_O_O__O(root_1129, arg_1132, arg_1133, arg_1134) }; if linked_1136 == nil { or__1927000174__auto____5 = ifn_1137.Invoke_O__O(arg_1138) } else { or__1927000174__auto____5 = linked_1136.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1135, arg_1138) }; if jrt.J2g_Truth(or__1927000174__auto____5) { ff__5 = or__1927000174__auto____5 } else { var tmp1 bool; var na_1139 any; var root_1140 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_120; var arg_1143 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1141 == nil { na_1139 = ifn_1142.Invoke_O__O(arg_1143) } else { na_1139 = linked_1141.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1140, arg_1143) }; if jrt.Long_InstanceOf(na_1139) { var n0_1144 int64 = jrt.NN(jrt.Long_Cast(na_1139)).LongValue__J(); tmp1 = n0_1144 > 0 } else { if jrt.Double_InstanceOf(na_1139) { var n0_1144_2 float64 = jrt.NN(jrt.Double_Cast(na_1139)).DoubleValue__D(); tmp1 = n0_1144_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_1139) } }; ff__5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() }
	var tmp3 any; var or__1927000174__auto____6 any; var root_1145 any = A_arbace_repr_go_print_A_const_108.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1147 lang.IFn
	if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = lines_QMARK___3; if linked_1146 == nil { or__1927000174__auto____6 = ifn_1147.Invoke_O__O(arg_1148) } else { or__1927000174__auto____6 = linked_1146.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1145, arg_1148) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp3 = or__1927000174__auto____6 } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t__1, nil)).Ref() }
//line :227:1
	if jrt.J2g_Truth(tmp3) {
		var tmp4 any; var root_1163 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_A_const_121; var arg_1166 any = tmp5.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1164 == nil { tmp4 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp4 = linked_1164.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1163, arg_1166) }; if jrt.J2g_Truth(tmp4) { } else { var root_1167 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = A_arbace_repr_go_print_A_const_85; var arg_1171 any = ff__5; if linked_1168 == nil { ifn_1169.Invoke_O_O__O(arg_1170, arg_1171) } else { linked_1168.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1167, arg_1170, arg_1171) } }; var root_1149 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = A_arbace_repr_go_print_A_const_85; var arg_1153 any = ff__5; if linked_1150 == nil { return ifn_1151.Invoke_O_O__O(arg_1152, arg_1153) } else { return linked_1150.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1149, arg_1152, arg_1153) } } else {
//line :227:1
			if A_arbace_repr_go_print_A_const_59 != nil { var want__6 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(t__1), lang.RT_LongCast_O__J_NoInit(pre__2)); var tmp6 any; var root_1172 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1174 lang.IFn


				if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var tmp7 *lang.Keyword = A_arbace_repr_go_print_A_const_121; var arg_1175 any = tmp7.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1173 == nil { tmp6 = ifn_1174.Invoke_O__O(arg_1175) } else { tmp6 = linked_1173.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1172, arg_1175) }; if jrt.J2g_Truth(tmp6) { } else { var root_1176 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = A_arbace_repr_go_print_A_const_85; var arg_1180 any = ff__5; if linked_1177 == nil { ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { linked_1177.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } }
//line :227:1
			L1: for {



				var tmp8 bool; var na_1154 any; var root_1156 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1159 any = tmp9.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1157 == nil { na_1154 = ifn_1158.Invoke_O__O(arg_1159) } else { na_1154 = linked_1157.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1156, arg_1159) }; var na_1155 int64 = want__6; if jrt.Long_InstanceOf(na_1154) { var n0_1160 int64 = jrt.NN(jrt.Long_Cast(na_1154)).LongValue__J(); var n1_1161 int64 = na_1155; tmp8 = n0_1160 < n1_1161 } else { tmp8 = lang.Numbers_Lt_O_J__Z_NoInit(na_1154, na_1155) }; if tmp8 { var root_1181 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = A_arbace_repr_go_print_A_const_85; var arg_1185 any = ff__5; if linked_1182 == nil { ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { linked_1182.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) }; continue L1 } else { return nil } } } else {
//line :227:1
					return nil } } }; /*line :220:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_print_decl_BANG__A_New() *A_arbace_repr_go_print_print_decl_BANG__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_decl_BANG__A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_repr_go_print_print_decl_BANG__A) Ctor() {}
//line :233:1
func (t *A_arbace_repr_go_print_print_decl_BANG__A) Invoke_O_O_O_O_O_O__O(self, decls__0, i__1, lines_QMARK___2, popts__3, sep_QMARK___4 any) any { var f__6 any = lang.RT_Nth_O_I__O_NoInit(decls__0, lang.RT_IntCast_O__I_NoInit(i__1)); var t__7 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if




	jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____7 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__6)); var tmp3 any; var root_1186 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = l__308000057__auto____7; if linked_1187 == nil { tmp3 = ifn_1188.Invoke_O__O(arg_1189) } else { tmp3 = linked_1187.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1186, arg_1189) }; if jrt.J2g_Truth(tmp3) { t__7 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____7)).Ref() } else { t__7 = nil } } else { t__7 = nil }; var vec__1344000126__8 any; var root_1190 any = /*line :233:1*/A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1192 lang.IFn; if





	linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = f__6; if linked_1191 == nil { vec__1344000126__8 = ifn_1192.Invoke_O__O(arg_1193) } else { vec__1344000126__8 = linked_1191.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1190, arg_1193) }; var directive_QMARK___9 any = /*line :233:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(0), nil); var doc__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(1), nil); var dirs__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(2), nil); var pre__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(3), nil); var root_1224 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1226 lang.IFn; if






	linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_A_const_123; var tmp6 any; var root_1214 any = A_arbace_repr_go_print_A_const_124.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, A_arbace_repr_go_print_next_target_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = decls__0; var arg_1218 any = i__1; if linked_1215 == nil { tmp6 = ifn_1216.Invoke_O_O__O(arg_1217, arg_1218) } else { tmp6 = linked_1215.(*A_arbace_repr_go_print_next_target_A).Invoke_O_O_O__O(root_1214, arg_1217, arg_1218) }; arg_1227 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_1225 == nil { ifn_1226.Invoke_O__O(arg_1227) } else { linked_1225.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1224, arg_1227) }; var tmp7 any; tmp16 := /*line :233:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		if jrt.J2g_Truth(sep_QMARK___4) { var root_1228 any = A_arbace_repr_go_print_A_const_125.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, A_arbace_repr_go_print_decl_sep_BANG__A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = f__6; var arg_1232 any = t__7; var arg_1233 any = pre__12; var arg_1234 any = lines_QMARK___2; if linked_1229 == nil { ifn_1230.Invoke_O_O_O_O__O(arg_1231, arg_1232, arg_1233, arg_1234) } else { linked_1229.(*A_arbace_repr_go_print_decl_sep_BANG__A).Invoke_O_O_O_O_O__O(root_1228, arg_1231, arg_1232, arg_1233, arg_1234) } }
		if jrt.J2g_Truth(directive_QMARK___9) {
			var root_1202 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any; var root_1198 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any; var root_1194 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = f__6; if linked_1195 == nil { arg_1201 = ifn_1196.Invoke_O__O(arg_1197) } else { arg_1201 = linked_1195.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1194, arg_1197) }; if linked_1199 == nil { arg_1205 = ifn_1200.Invoke_O__O(arg_1201) } else { arg_1205 = linked_1199.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1198, arg_1201) }; var arg_1206 any = A_arbace_repr_go_print_A_const_85; if linked_1203 == nil { tmp7 = ifn_1204.Invoke_O_O__O(arg_1205, arg_1206) } else { tmp7 = linked_1203.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1202, arg_1205, arg_1206) } } else {

				var root_1235 any = A_arbace_repr_go_print_A_const_126.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_pre_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = doc__10; var arg_1239 any = dirs__11; var arg_1240 any = A_arbace_repr_go_print_A_const_85; if linked_1236 == nil { ifn_1237.Invoke_O_O_O__O(arg_1238, arg_1239, arg_1240) } else { linked_1236.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_pre_A).Invoke_O_O_O_O__O(root_1235, arg_1238, arg_1239, arg_1240) }
				var tmp8 any; var and__1927000168__auto____15 any = lines_QMARK___2; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any = t__7; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var root_1245 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(t__7)).Ref(); var arg_1249 any; var root_1241 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1244 any = tmp9.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1242 == nil { arg_1249 = ifn_1243.Invoke_O__O(arg_1244) } else { arg_1249 = linked_1242.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1241, arg_1244) }; if linked_1246 == nil { and__1927000168__auto____17 = ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { and__1927000168__auto____17 = linked_1246.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) }; if jrt.J2g_Truth(and__1927000168__auto____17) { var tmp10 lang.IFn = A_arbace_repr_go_print_A_const_128; var tmp11 any; var or__1927000174__auto____18 any = popts__3; if jrt.J2g_Truth(or__1927000174__auto____18) { tmp11 = or__1927000174__auto____18 } else { tmp11 = lang.PersistentArrayMap_EMPTY.Ref() }; tmp8 = tmp10.Invoke_O_O__O(tmp11, jrt.Boolean_TRUE.Ref()) } else { tmp8 = and__1927000168__auto____17 } } else { tmp8 = and__1927000168__auto____16 } } else { tmp8 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp8) {
					var tmp12 bool; var na_1250 int64 = lang.RT_LongCast_O__J_NoInit(t__7); var na_1251 any; var root_1252 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1254 lang.IFn
					if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var tmp13 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1255 any = tmp13.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1253 == nil { na_1251 = ifn_1254.Invoke_O__O(arg_1255) } else { na_1251 = linked_1253.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1252, arg_1255) }; if jrt.Long_InstanceOf(na_1251) { var n0_1256 int64 = na_1250; var n1_1257 int64 = jrt.NN(jrt.Long_Cast(na_1251)).LongValue__J(); tmp12 = n0_1256 > n1_1257 } else { tmp12 = lang.Numbers_Gt_J_O__Z_NoInit(na_1250, na_1251) }
//line :247:1
					if tmp12 { L1: for {
						var tmp14 bool; var na_1259 any; var root_1261 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var tmp15 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1264 any = tmp15.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1262 == nil { na_1259 = ifn_1263.Invoke_O__O(arg_1264) } else { na_1259 = linked_1262.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1261, arg_1264) }; var na_1260 int64 = lang.RT_LongCast_O__J_NoInit(t__7); if jrt.Long_InstanceOf(na_1259) { var n0_1265 int64 = jrt.NN(jrt.Long_Cast(na_1259)).LongValue__J(); var n1_1266 int64 = na_1260; tmp14 = n0_1265 < n1_1266 } else { tmp14 = lang.Numbers_Lt_O_J__Z_NoInit(na_1259, na_1260) }; if tmp14 { var root_1272 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = A_arbace_repr_go_print_A_const_85; if linked_1273 == nil { ifn_1274.Invoke_O__O(arg_1275) } else { linked_1273.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1272, arg_1275) }; continue L1 }
//line :247:1
						break L1 } } else { if A_arbace_repr_go_print_A_const_59 != nil {

							var root_1268 any = A_arbace_repr_go_print_A_const_129.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_directive_own_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = t__7; if linked_1269 == nil { ifn_1270.Invoke_O__O(arg_1271) } else { linked_1269.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_directive_own_A).Invoke_O_O__O(root_1268, arg_1271) } } } }
				var root_1207 any = A_arbace_repr_go_print_A_const_122.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = f__6; if linked_1208 == nil { tmp7 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp7 = linked_1208.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A).Invoke_O_O__O(root_1207, arg_1210) } }
//line :233:1
		return nil }(); var root_1211 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1213 lang.IFn; if






	linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; if linked_1212 == nil { ifn_1213.Invoke__O() } else { linked_1212.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1211) }; if /*line :233:1*/ tmp16 != nil { panic(tmp16) }; return tmp7 }






















func A_arbace_repr_go_print_chunk_starts_A_New() *A_arbace_repr_go_print_chunk_starts_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_go_print_chunk_starts_A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_go_print_chunk_starts_A) Invoke_O_O__O(self, decls__0 any) any { var n__2 int32 = lang.RT_Count_O__I_NoInit(decls__0); var k__3 any; var tmp1 int64 = lang.Numbers_Multiply_J_J__J_NoInit(2, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var tmp2 jrt.Number_I; var na_1276 int64 = int64(n__2); var na_1277 any = A_arbace_repr_go_print_A_const_130.GetRawRoot__O(); if




	jrt.Long_InstanceOf(na_1277) { var n0_1278 int64 = na_1276; var n1_1279 int64 = jrt.NN(jrt.Long_Cast(na_1277)).LongValue__J(); if n1_1279 == 0 { tmp2 = lang.Numbers_Quotient_J_O__Number_NoInit(na_1276, na_1277) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1278 / n1_1279)) } } else { tmp2 = lang.Numbers_Quotient_J_O__Number_NoInit(na_1276, na_1277) }; k__3 = lang.Numbers_Min_J_O__O_NoInit(tmp1, tmp2); var tmp3 bool; var na_1281 any = k__3; var na_1282 int64 = 2; if
	jrt.Long_InstanceOf(na_1281) { var n0_1283 int64 = jrt.NN(jrt.Long_Cast(na_1281)).LongValue__J(); var n1_1284 int64 = na_1282; tmp3 = n0_1283 >= n1_1284 } else { tmp3 = lang.Numbers_Gte_O_J__Z_NoInit(na_1281, na_1282) }; if tmp3 { var size__4 any; var na_1286 any; var na_1288 int64 = int64(n__2); var na_1289 any; var na_1290 any = k__3
		if jrt.Long_InstanceOf(na_1290) { var n0_1291 int64 = jrt.NN(jrt.Long_Cast(na_1290)).LongValue__J(); if n0_1291 == -9223372036854775808 { na_1289 = lang.Numbers_Dec_O__Number_NoInit(na_1290) } else { na_1289 = jrt.Long_ValueOf_J__Long_NoInit(n0_1291 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_1290) { var n0_1291_2 float64 = jrt.NN(jrt.Double_Cast(na_1290)).DoubleValue__D(); na_1289 = jrt.Double_ValueOf_D__Double_NoInit(n0_1291_2 - 1.0).Ref() } else { na_1289 = lang.Numbers_Dec_O__Number_NoInit(na_1290) } }; if jrt.Long_InstanceOf(na_1289) { var n0_1292 int64 = na_1288; var n1_1293 int64 = jrt.NN(jrt.Long_Cast(na_1289)).LongValue__J(); var nr_1294 int64 = n0_1292 + n1_1293; if (n0_1292^nr_1294)&(n1_1293^nr_1294) >= 0 { na_1286 = jrt.Long_ValueOf_J__Long_NoInit(nr_1294).Ref() } else { na_1286 = lang.Numbers_Add_J_O__Number_NoInit(na_1288, na_1289) } } else { na_1286 = lang.Numbers_Add_J_O__Number_NoInit(na_1288, na_1289) }; var na_1287 any = k__3; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_1286); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1287) }; tmp4 = tmp5; if tmp4 { var n0_1295 int64 = jrt.NN(jrt.Long_Cast(na_1286)).LongValue__J(); var n1_1296 int64 = jrt.NN(jrt.Long_Cast(na_1287)).LongValue__J(); if n1_1296 == 0 { size__4 = lang.Numbers_Quotient_O_O__Number_NoInit(na_1286, na_1287) } else { size__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_1295 / n1_1296).Ref() } } else { size__4 = lang.Numbers_Quotient_O_O__Number_NoInit(na_1286, na_1287) }
		var root_1341 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = lang.PersistentVector_EMPTY.Ref(); var arg_1345 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_131.GetRawRoot__O()); var tmp7 any; var root_1318 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1320 lang.IFn
		if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any; var tmp8 any = A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_New_O_I(decls__0, n__2); var tmp9 *jrt.Class; var fncls__1317 *jrt.Class = A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_fn_class; if fncls__1317 == nil { var fncls__1317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_fn_class = fncls__1317d; tmp9 = fncls__1317d } else { tmp9 = fncls__1317 }; arg_1321 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); if linked_1319 == nil { tmp7 = ifn_1320.Invoke_O__O(arg_1321) } else { tmp7 = linked_1319.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1318, arg_1321) }; var tmp10 any = tmp7; var tmp11 any; var root_1322 any = A_arbace_repr_go_print_A_const_135.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1324 lang.IFn
		if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = A_arbace_repr_go_print_A_const_136.GetRawRoot__O(); if linked_1323 == nil { tmp11 = ifn_1324.Invoke_O__O(arg_1325) } else { tmp11 = linked_1323.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_1322, arg_1325) }
//line :265:1
		var tmp12 any = tmp11; var tmp13 any; var root_1326 any = A_arbace_repr_go_print_A_const_137.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1328 lang.IFn

		if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; if linked_1327 == nil { tmp13 = ifn_1328.Invoke__O() } else { tmp13 = linked_1327.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O__O(root_1326) }
//line :265:1
		arg_1345 = tmp6.Invoke_O_O_O__O(tmp10, tmp12, tmp13)
//line :264:1
		var arg_1346 any; var root_1335 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1337 lang.IFn



		if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = A_arbace_repr_go_print_A_const_85; var arg_1339 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref(); var arg_1340 any = size__4; if linked_1336 == nil { arg_1346 = ifn_1337.Invoke_O_O_O__O(arg_1338, arg_1339, arg_1340) } else { arg_1346 = linked_1336.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O_O__O(root_1335, arg_1338, arg_1339, arg_1340) }
//line :264:1
		if linked_1342 == nil { return ifn_1343.Invoke_O_O_O__O(arg_1344, arg_1345, arg_1346) } else { return linked_1342.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1341, arg_1344, arg_1345, arg_1346) } } else {
//line :262:1
			return nil } }


func A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_New_O_I(p0 any, p1 int32) *A_arbace_repr_go_print_chunk_starts_fn__1344000131_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_fn__1344000131_A{}; t.Ctor_O_I(p0, p1); return t }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_A) Ctor_O_I(c__decls any, c__n int32) { t.F_decls = c__decls; t.F_n = c__n }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_A) Invoke_O_O__O(self, a__1 any) any { var root_1313 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var root_1308 any = A_arbace_repr_go_print_A_const_133.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any; var tmp1 any = A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_New_O(t.F_decls); var tmp2 *jrt.Class; var fncls__1302 *jrt.Class = A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_fn_class; if fncls__1302 == nil { var fncls__1302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_fn_class = fncls__1302d; tmp2 = fncls__1302d } else { tmp2 = fncls__1302 }; arg_1311 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1312 any; var root_1303 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = a__1; var arg_1307 any = jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n).Ref(); if linked_1304 == nil { arg_1312 = ifn_1305.Invoke_O_O__O(arg_1306, arg_1307) } else { arg_1312 = linked_1304.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1303, arg_1306, arg_1307) }; if linked_1309 == nil { arg_1316 = ifn_1310.Invoke_O_O__O(arg_1311, arg_1312) } else { arg_1316 = linked_1309.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1308, arg_1311, arg_1312) }; if linked_1314 == nil { return ifn_1315.Invoke_O__O(arg_1316) } else { return linked_1314.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1313, arg_1316) } }
//line :265:1
func A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_New_O(p0 any) *A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A{}; t.Ctor_O(p0); return t }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A) Invoke_O_O__O(self, p1__1344000130_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var tmp3 any = t.F_decls; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(p1__1344000130_SHARP___1)))); var tmp4 any; var root_1298 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = l__308000057__auto____2; if linked_1299 == nil { tmp4 = ifn_1300.Invoke_O__O(arg_1301) } else { tmp4 = linked_1299.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1298, arg_1301) }; if jrt.J2g_Truth(tmp4) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____2)).Ref() } else { return nil } } else { return nil } }




func A_arbace_repr_go_print_print_file_full_A_New() *A_arbace_repr_go_print_print_file_full_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_full_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_repr_go_print_print_file_full_A) Ctor() {}
//line :270:1
func (t *A_arbace_repr_go_print_print_file_full_A) Invoke_O_O_O_O_O__O(self, file__0, opts__1, decls__2, pkg_name__3 any) any { var m__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(file__0); var decls__6 any; var root_1347 any = A_arbace_repr_go_print_A_const_138.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1349 lang.IFn; if





	linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = A_arbace_repr_go_print_A_const_139.GetRawRoot__O(); var arg_1351 any = decls__2; if linked_1348 == nil { decls__6 = ifn_1349.Invoke_O_O__O(arg_1350, arg_1351) } else { decls__6 = linked_1348.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1347, arg_1350, arg_1351) }; var imports__7 any; var root_1352 any = /*line :270:1*/A_arbace_repr_go_print_A_const_139.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_wrap_full_A_fn_class); var ifn_1354 lang.IFn; if






	linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = A_arbace_repr_go_print_A_const_140.Invoke_O__O(opts__1); if linked_1353 == nil { imports__7 = ifn_1354.Invoke_O__O(arg_1355) } else { imports__7 = linked_1353.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_wrap_full_A).Invoke_O_O__O(root_1352, arg_1355) }; var p__8 any = /*line :270:1*/A_arbace_repr_go_print_A_const_95.Invoke_O__O(m__5); var root_1379 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1381 lang.IFn; if








	linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_114; var tmp3 any; var root_1362 any = A_arbace_repr_go_print_A_const_142.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var tmp4 any = A_arbace_repr_go_print_A_const_113; var tmp5 any = jrt.Boolean_FALSE.Ref(); var tmp6 any = A_arbace_repr_go_print_A_const_128; var tmp7 any = jrt.Boolean_FALSE.Ref(); var tmp8 any = A_arbace_repr_go_print_A_const_143; var tmp9 any = A_arbace_repr_go_print_A_const_144; var tmp10 any = A_arbace_repr_go_print_A_const_145.Invoke_O__O(m__5); var tmp11 any = A_arbace_repr_go_print_A_const_146; var tmp12 any = A_arbace_repr_go_print_A_const_147.Invoke_O__O(m__5); var tmp13 any = A_arbace_repr_go_print_A_const_148; var tmp14 any = A_arbace_repr_go_print_A_const_149.Invoke_O__O(m__5); var tmp15 any = A_arbace_repr_go_print_A_const_150; var tmp16 any = A_arbace_repr_go_print_A_const_151.Invoke_O__O(m__5); var tmp17 any = A_arbace_repr_go_print_A_const_152; var arg_1365 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, A_arbace_repr_go_print_A_const_153.Invoke_O__O(m__5))))); if linked_1363 == nil { tmp3 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp3 = linked_1363.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A).Invoke_O_O__O(root_1362, arg_1365) }; var tmp18 any = tmp3; var tmp19 any = A_arbace_repr_go_print_A_const_123; var tmp20 any = A_arbace_repr_go_print_A_const_154; var tmp21 any; var root_1366 any = A_arbace_repr_go_print_A_const_155.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A_fn_class); var ifn_1368 lang.IFn; if



	linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = decls__6; if linked_1367 == nil { tmp21 = ifn_1368.Invoke_O__O(arg_1369) } else { tmp21 = linked_1367.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A).Invoke_O_O__O(root_1366, arg_1369) }; arg_1382 = /*line :279:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp18, tmp19, nil, tmp20, tmp21); if linked_1380 == nil { ifn_1381.Invoke_O__O(arg_1382) } else { linked_1380.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1379, arg_1382) }; var tmp22 any; tmp29 := /*line :270:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)













		{ var root_1383 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = Lit_92; var arg_1387 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(p__8); if linked_1384 == nil { ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { linked_1384.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }; var root_1388 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; if linked_1389 == nil { ifn_1390.Invoke__O() } else { linked_1389.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1388) }
			var root_1395 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any; var root_1391 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any; var or__1927000174__auto____11 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(opts__1); if jrt.J2g_Truth(or__1927000174__auto____11) { arg_1394 = or__1927000174__auto____11 } else { arg_1394 = pkg_name__3 }; if linked_1392 == nil { arg_1398 = ifn_1393.Invoke_O__O(arg_1394) } else { arg_1398 = linked_1392.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1391, arg_1394) }; var arg_1399 any = A_arbace_repr_go_print_A_const_45.Invoke_O__O(p__8); if linked_1396 == nil { ifn_1397.Invoke_O_O__O(arg_1398, arg_1399) } else { linked_1396.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1395, arg_1398, arg_1399) }
			var root_1400 any = A_arbace_repr_go_print_A_const_156.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, A_arbace_repr_go_print_write_imports_full_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = imports__7; if linked_1401 == nil { ifn_1402.Invoke_O__O(arg_1403) } else { linked_1401.(*A_arbace_repr_go_print_write_imports_full_A).Invoke_O_O__O(root_1400, arg_1403) }
//line :270:1
			var seq_1344000136__11 any; var root_1404 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1406 lang.IFn
















			if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = decls__6; if linked_1405 == nil { seq_1344000136__11 = ifn_1406.Invoke_O__O(arg_1407) } else { seq_1344000136__11 = linked_1405.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1404, arg_1407) }
//line :270:1
			var chunk_1344000137__12 any; var count_1344000138__13 int64 = 0; var i_1344000139__14 int64 = 0; L1: for {
















				if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000139__14, count_1344000138__13) { var f__15 any = lang.Indexed_Cast(chunk_1344000137__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000139__14)); var tmp23 any; var root_1412 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any; var root_1408 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = f__15; if linked_1409 == nil { arg_1415 = ifn_1410.Invoke_O__O(arg_1411) } else { arg_1415 = linked_1409.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1408, arg_1411) }; var arg_1416 any = Lit_67; if linked_1413 == nil { tmp23 = ifn_1414.Invoke_O_O__O(arg_1415, arg_1416) } else { tmp23 = linked_1413.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1412, arg_1415, arg_1416) }; if jrt.J2g_Truth(tmp23) {
					var root_1446 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = A_arbace_repr_go_print_A_const_99; var arg_1450 any = Lit_95; if linked_1447 == nil { ifn_1448.Invoke_O_O__O(arg_1449, arg_1450) } else { linked_1447.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_1446, arg_1449, arg_1450) }
					var root_1442 any = A_arbace_repr_go_print_A_const_122.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = f__15; if linked_1443 == nil { ifn_1444.Invoke_O__O(arg_1445) } else { linked_1443.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A).Invoke_O_O__O(root_1442, arg_1445) }
//line :287:1
					seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000139__14); continue L1 } else { seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000139__14); continue L1 } } else { var temp__1927000414__auto____15 any; var root_1417 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = seq_1344000136__11; if linked_1418 == nil { temp__1927000414__auto____15 = ifn_1419.Invoke_O__O(arg_1420) } else { temp__1927000414__auto____15 = linked_1418.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1417, arg_1420) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1344000136__16 any = temp__1927000414__auto____15; var tmp24 any; var root_1421 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = seq_1344000136__16; if linked_1422 == nil { tmp24 = ifn_1423.Invoke_O__O(arg_1424) } else { tmp24 = linked_1422.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1421, arg_1424) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____17 any; var root_1425 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = seq_1344000136__16; if linked_1426 == nil { c__1927000678__auto____17 = ifn_1427.Invoke_O__O(arg_1428) } else { c__1927000678__auto____17 = linked_1426.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1425, arg_1428) }; var tmp25 any; var root_1451 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = seq_1344000136__16; if linked_1452 == nil { tmp25 = ifn_1453.Invoke_O__O(arg_1454) } else { tmp25 = linked_1452.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1451, arg_1454) }; seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = tmp25, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__17 any; var root_1429 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = seq_1344000136__16; if linked_1430 == nil { f__17 = ifn_1431.Invoke_O__O(arg_1432) } else { f__17 = linked_1430.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1429, arg_1432) }; var tmp26 any; var root_1437 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any; var root_1433 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = f__17; if linked_1434 == nil { arg_1440 = ifn_1435.Invoke_O__O(arg_1436) } else { arg_1440 = linked_1434.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1433, arg_1436) }; var arg_1441 any = Lit_67; if linked_1438 == nil { tmp26 = ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { tmp26 = linked_1438.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) }; if jrt.J2g_Truth(tmp26) {
						var root_1459 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = A_arbace_repr_go_print_A_const_99; var arg_1463 any = Lit_95; if linked_1460 == nil { ifn_1461.Invoke_O_O__O(arg_1462, arg_1463) } else { linked_1460.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_1459, arg_1462, arg_1463) }
						var root_1455 any = A_arbace_repr_go_print_A_const_122.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = f__17; if linked_1456 == nil { ifn_1457.Invoke_O__O(arg_1458) } else { linked_1456.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A).Invoke_O_O__O(root_1455, arg_1458) }
//line :287:1
						var tmp27 any; var root_1464 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = seq_1344000136__16; if linked_1465 == nil { tmp27 = ifn_1466.Invoke_O__O(arg_1467) } else { tmp27 = linked_1465.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1464, arg_1467) }; seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = tmp27, nil, 0, 0; continue L1 } else { var tmp28 any; var root_1468 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = seq_1344000136__16; if linked_1469 == nil { tmp28 = ifn_1470.Invoke_O__O(arg_1471) } else { tmp28 = linked_1469.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1468, arg_1471) }; seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = tmp28, nil, 0, 0; continue L1 } } } }
//line :270:1
				break L1
			}


















			var root_1356 any = A_arbace_repr_go_print_A_const_141.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; if linked_1357 == nil { tmp22 = ifn_1358.Invoke__O() } else { tmp22 = linked_1357.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A).Invoke_O__O(root_1356) } }
//line :270:1
		return nil }(); var root_1359 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1361 lang.IFn; if








	linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; if linked_1360 == nil { ifn_1361.Invoke__O() } else { linked_1360.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1359) }; if /*line :270:1*/ tmp29 != nil { panic(tmp29) }; return tmp22 }





















func A_arbace_repr_go_print_print_file_A_New() *A_arbace_repr_go_print_print_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_repr_go_print_print_file_A) Ctor() {}
//line :292:1
func (t *A_arbace_repr_go_print_print_file_A) Invoke_O_O_O_O__O(self, p__1344000141__0, pkg_name__1, p__1344000142__2 any) any { var map__1344000143__4 any = p__1344000141__0; var map__1344000143__5 any; if lang.ISeq_InstanceOf(map__1344000143__4) { var tmp1 any; var root_1472 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = map__1344000143__4; if linked_1473 == nil { tmp1 = ifn_1474.Invoke_O__O(arg_1475) } else { tmp1 = linked_1473.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1472, arg_1475) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1476 any = A_arbace_repr_go_print_A_const_157.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = map__1344000143__4; if linked_1477 == nil { tmp2 = ifn_1478.Invoke_O__O(arg_1479) } else { tmp2 = linked_1477.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1476, arg_1479) }; map__1344000143__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1480 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = map__1344000143__4; if linked_1481 == nil { tmp3 = ifn_1482.Invoke_O__O(arg_1483) } else { tmp3 = linked_1481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1480, arg_1483) }; if jrt.J2g_Truth(tmp3) { var root_1484 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = map__1344000143__4; if linked_1485 == nil { map__1344000143__5 = ifn_1486.Invoke_O__O(arg_1487) } else { map__1344000143__5 = linked_1485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1484, arg_1487) } } else { map__1344000143__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000143__5 = map__1344000143__4 }; var opts__6 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_48); var decls__7 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_49); var file__8 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_47); var src__9 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_50); var map__1344000145__10 any = p__1344000142__2; var map__1344000145__11 any; if lang.ISeq_InstanceOf(map__1344000145__10) { var tmp4 any; var root_1488 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = map__1344000145__10; if linked_1489 == nil { tmp4 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp4 = linked_1489.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1488, arg_1491) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1492 any = A_arbace_repr_go_print_A_const_157.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = map__1344000145__10; if linked_1493 == nil { tmp5 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp5 = linked_1493.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1492, arg_1495) }; map__1344000145__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp5, jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 any; var root_1496 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = map__1344000145__10; if linked_1497 == nil { tmp6 = ifn_1498.Invoke_O__O(arg_1499) } else { tmp6 = linked_1497.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1496, arg_1499) }; if jrt.J2g_Truth(tmp6) { var root_1500 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = map__1344000145__10; if linked_1501 == nil { map__1344000145__11 = ifn_1502.Invoke_O__O(arg_1503) } else { map__1344000145__11 = linked_1501.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1500, arg_1503) } } else { map__1344000145__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000145__11 = map__1344000145__10 }; var popts__12 any = map__1344000145__11; var layout__13 any = lang.RT_Get_O_O__O_NoInit(map__1344000145__11, A_arbace_repr_go_print_A_const_158); var line_directives_QMARK___14 any = lang.RT_Get_O_O__O_NoInit(map__1344000145__11, A_arbace_repr_go_print_A_const_128); var line_file__15 any = lang.RT_Get_O_O__O_NoInit(map__1344000145__11, A_arbace_repr_go_print_A_const_159); if





	lang.Util_Equiv_O_O__Z_NoInit(layout__13, A_arbace_repr_go_print_A_const_143) {
		var root_1504 any = A_arbace_repr_go_print_A_const_160.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, A_arbace_repr_go_print_print_file_full_A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = file__8; var arg_1508 any = opts__6; var arg_1509 any = decls__7; var arg_1510 any = pkg_name__1; if linked_1505 == nil { return ifn_1506.Invoke_O_O_O_O__O(arg_1507, arg_1508, arg_1509, arg_1510) } else { return linked_1505.(*A_arbace_repr_go_print_print_file_full_A).Invoke_O_O_O_O_O__O(root_1504, arg_1507, arg_1508, arg_1509, arg_1510) } } else {
//line :298:1
			var lines_QMARK___16 any
			var G__1344000147__16_ any = layout__13
		L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1344000147__16_) >> 6 & 1 { case 0: if any(G__1344000147__16_) == any(A_arbace_repr_go_print_A_const_161) { lines_QMARK___16 = jrt.Boolean_TRUE.Ref(); break L1 }; case 1: if any(G__1344000147__16_) == any(A_arbace_repr_go_print_A_const_162) { lines_QMARK___16 = jrt.Boolean_FALSE.Ref(); break L1 }; default:}
			var tmp7 *lang.Keyword = A_arbace_repr_go_print_A_const_115; lines_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(file__8)))).Ref()}
//line :298:1
			var state_opts__17 any; var tmp8 any = A_arbace_repr_go_print_A_const_113; var tmp9 any = A_arbace_repr_go_print_A_const_128; var tmp10 any



			if lang.Util_Identical_O_O__Z_NoInit(line_directives_QMARK___14, nil) { tmp10 = jrt.Boolean_TRUE.Ref() } else { tmp10 = line_directives_QMARK___14 }
//line :298:1
			state_opts__17 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, lines_QMARK___16, tmp9, tmp10))




			var root_1535 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp12 any = A_arbace_repr_go_print_A_const_114; var tmp13 any; var root_1518 any = A_arbace_repr_go_print_A_const_142.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = state_opts__17; if linked_1519 == nil { tmp13 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp13 = linked_1519.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A).Invoke_O_O__O(root_1518, arg_1521) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_repr_go_print_A_const_123; var tmp16 any = A_arbace_repr_go_print_A_const_154; var tmp17 any; var root_1522 any = A_arbace_repr_go_print_A_const_155.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A_fn_class); var ifn_1524 lang.IFn

			if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = decls__7; if linked_1523 == nil { tmp17 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp17 = linked_1523.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A).Invoke_O_O__O(root_1522, arg_1525) }
//line :303:1
			arg_1538 = tmp11.Invoke_O_O_O_O_O_O__O(tmp12, tmp14, tmp15, nil, tmp16, tmp17); if linked_1536 == nil { ifn_1537.Invoke_O__O(arg_1538) } else { linked_1536.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1535, arg_1538) }
//line :298:1
			var tmp18 any; tmp55 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








				{ var tmp19 any; var and__1927000168__auto____20 any = lines_QMARK___16; if jrt.J2g_Truth(and__1927000168__auto____20) { var and__1927000168__auto____21 any = line_file__15; if jrt.J2g_Truth(and__1927000168__auto____21) { tmp19 = src__9 } else { tmp19 = and__1927000168__auto____21 } } else { tmp19 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp19) {
					var root_1786 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_90, nil, Lit_91), jrt.RefArrayOf(jrt.Object_class, nil, src__9, nil)).Ref(); var arg_1790 any = A_arbace_repr_go_print_A_const_85; if linked_1787 == nil { ifn_1788.Invoke_O_O__O(arg_1789, arg_1790) } else { linked_1787.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1786, arg_1789, arg_1790) }
					var root_1539 any = A_arbace_repr_go_print_A_const_163.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = A_arbace_repr_go_print_A_const_68; if linked_1540 == nil { ifn_1541.Invoke_O__O(arg_1542) } else { linked_1540.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_set_line_BANG__A).Invoke_O_O__O(root_1539, arg_1542) } }
//line :298:1
					var seq_1344000148__20 any; var root_1543 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1545 lang.IFn











					if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = A_arbace_repr_go_print_A_const_164.Invoke_O__O(opts__6); if linked_1544 == nil { seq_1344000148__20 = ifn_1545.Invoke_O__O(arg_1546) } else { seq_1344000148__20 = linked_1544.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1543, arg_1546) }
//line :298:1
					var chunk_1344000149__21 any; var count_1344000150__22 int64 = 0; var i_1344000151__23 int64 = 0; L2: for {











						if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000151__23, count_1344000150__22) { var b__24 any = lang.Indexed_Cast(chunk_1344000149__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000151__23)); var root_1795 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any; var root_1791 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = b__24; if linked_1792 == nil { arg_1798 = ifn_1793.Invoke_O__O(arg_1794) } else { arg_1798 = linked_1792.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1791, arg_1794) }; var arg_1799 any = A_arbace_repr_go_print_A_const_85; if linked_1796 == nil { ifn_1797.Invoke_O_O__O(arg_1798, arg_1799) } else { linked_1796.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1795, arg_1798, arg_1799) }; seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, i_1344000151__23 = seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000151__23); continue L2 } else { var temp__1927000414__auto____24 any; var root_1547 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = seq_1344000148__20; if linked_1548 == nil { temp__1927000414__auto____24 = ifn_1549.Invoke_O__O(arg_1550) } else { temp__1927000414__auto____24 = linked_1548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1547, arg_1550) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1344000148__25 any = temp__1927000414__auto____24; var tmp20 any; var root_1551 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = seq_1344000148__25; if linked_1552 == nil { tmp20 = ifn_1553.Invoke_O__O(arg_1554) } else { tmp20 = linked_1552.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1551, arg_1554) }; if jrt.J2g_Truth(tmp20) { var c__1927000678__auto____26 any; var root_1555 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = seq_1344000148__25; if linked_1556 == nil { c__1927000678__auto____26 = ifn_1557.Invoke_O__O(arg_1558) } else { c__1927000678__auto____26 = linked_1556.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1555, arg_1558) }; var tmp21 any; var root_1800 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = seq_1344000148__25; if linked_1801 == nil { tmp21 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp21 = linked_1801.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1800, arg_1803) }; seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, i_1344000151__23 = tmp21, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var b__26 any; var root_1559 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = seq_1344000148__25; if linked_1560 == nil { b__26 = ifn_1561.Invoke_O__O(arg_1562) } else { b__26 = linked_1560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1559, arg_1562) }; var root_1808 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1810 lang.IFn; if linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any; var root_1804 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any = b__26; if linked_1805 == nil { arg_1811 = ifn_1806.Invoke_O__O(arg_1807) } else { arg_1811 = linked_1805.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1804, arg_1807) }; var arg_1812 any = A_arbace_repr_go_print_A_const_85; if linked_1809 == nil { ifn_1810.Invoke_O_O__O(arg_1811, arg_1812) } else { linked_1809.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1808, arg_1811, arg_1812) }; var tmp22 any; var root_1813 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = seq_1344000148__25; if linked_1814 == nil { tmp22 = ifn_1815.Invoke_O__O(arg_1816) } else { tmp22 = linked_1814.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1813, arg_1816) }; seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, i_1344000151__23 = tmp22, nil, 0, 0; continue L2 } } }
//line :298:1
						break L2
					}











					var tmp23 any; var root_1563 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = A_arbace_repr_go_print_A_const_164.Invoke_O__O(opts__6); if linked_1564 == nil { tmp23 = ifn_1565.Invoke_O__O(arg_1566) } else { tmp23 = linked_1564.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1563, arg_1566) }; if jrt.J2g_Truth(tmp23) { var root_1567 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = A_arbace_repr_go_print_A_const_85; if linked_1568 == nil { ifn_1569.Invoke_O__O(arg_1570) } else { linked_1568.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1567, arg_1570) } }
//line :298:1
					var seq_1344000152__20 any; var root_1571 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1573 lang.IFn













					if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = A_arbace_repr_go_print_A_const_165.Invoke_O__O(opts__6); if linked_1572 == nil { seq_1344000152__20 = ifn_1573.Invoke_O__O(arg_1574) } else { seq_1344000152__20 = linked_1572.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1571, arg_1574) }
//line :298:1
					var chunk_1344000153__21 any; var count_1344000154__22 int64 = 0; var i_1344000155__23 int64 = 0; L3: for {













						if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000155__23, count_1344000154__22) { var d__24 any = lang.Indexed_Cast(chunk_1344000153__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000155__23)); var root_1821 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any; var root_1817 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = d__24; if linked_1818 == nil { arg_1824 = ifn_1819.Invoke_O__O(arg_1820) } else { arg_1824 = linked_1818.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1817, arg_1820) }; var arg_1825 any = A_arbace_repr_go_print_A_const_85; if linked_1822 == nil { ifn_1823.Invoke_O_O__O(arg_1824, arg_1825) } else { linked_1822.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1821, arg_1824, arg_1825) }; seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, i_1344000155__23 = seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000155__23); continue L3 } else { var temp__1927000414__auto____24_2 any; var root_1575 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = seq_1344000152__20; if linked_1576 == nil { temp__1927000414__auto____24_2 = ifn_1577.Invoke_O__O(arg_1578) } else { temp__1927000414__auto____24_2 = linked_1576.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1575, arg_1578) }; if jrt.J2g_Truth(temp__1927000414__auto____24_2) { var seq_1344000152__25 any = temp__1927000414__auto____24_2; var tmp24 any; var root_1579 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = seq_1344000152__25; if linked_1580 == nil { tmp24 = ifn_1581.Invoke_O__O(arg_1582) } else { tmp24 = linked_1580.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1579, arg_1582) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____26_2 any; var root_1583 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = seq_1344000152__25; if linked_1584 == nil { c__1927000678__auto____26_2 = ifn_1585.Invoke_O__O(arg_1586) } else { c__1927000678__auto____26_2 = linked_1584.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1583, arg_1586) }; var tmp25 any; var root_1826 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = seq_1344000152__25; if linked_1827 == nil { tmp25 = ifn_1828.Invoke_O__O(arg_1829) } else { tmp25 = linked_1827.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1826, arg_1829) }; seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, i_1344000155__23 = tmp25, c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var d__26 any; var root_1587 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = seq_1344000152__25; if linked_1588 == nil { d__26 = ifn_1589.Invoke_O__O(arg_1590) } else { d__26 = linked_1588.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1587, arg_1590) }; var root_1834 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any; var root_1830 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = d__26; if linked_1831 == nil { arg_1837 = ifn_1832.Invoke_O__O(arg_1833) } else { arg_1837 = linked_1831.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1830, arg_1833) }; var arg_1838 any = A_arbace_repr_go_print_A_const_85; if linked_1835 == nil { ifn_1836.Invoke_O_O__O(arg_1837, arg_1838) } else { linked_1835.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1834, arg_1837, arg_1838) }; var tmp26 any; var root_1839 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1839, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1841 lang.IFn; if linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any = seq_1344000152__25; if linked_1840 == nil { tmp26 = ifn_1841.Invoke_O__O(arg_1842) } else { tmp26 = linked_1840.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1839, arg_1842) }; seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, i_1344000155__23 = tmp26, nil, 0, 0; continue L3 } } }
//line :298:1
						break L3
					}













					var tmp27 any; var root_1591 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = A_arbace_repr_go_print_A_const_165.Invoke_O__O(opts__6); if linked_1592 == nil { tmp27 = ifn_1593.Invoke_O__O(arg_1594) } else { tmp27 = linked_1592.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1591, arg_1594) }; if jrt.J2g_Truth(tmp27) { var root_1595 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = A_arbace_repr_go_print_A_const_85; if linked_1596 == nil { ifn_1597.Invoke_O__O(arg_1598) } else { linked_1596.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1595, arg_1598) } }
					var root_1599 any = A_arbace_repr_go_print_A_const_166.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_doc_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = A_arbace_repr_go_print_A_const_167.Invoke_O__O(opts__6); var arg_1603 any = A_arbace_repr_go_print_A_const_85; if linked_1600 == nil { ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { linked_1600.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_doc_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) }
					var root_1604 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = Lit_92; if linked_1605 == nil { ifn_1606.Invoke_O__O(arg_1607) } else { linked_1605.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_1604, arg_1607) }; var root_1608 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; if linked_1609 == nil { ifn_1610.Invoke__O() } else { linked_1609.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1608) }; var root_1615 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any; var root_1611 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any; var or__1927000174__auto____20 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____20) { arg_1614 = or__1927000174__auto____20 } else { arg_1614 = pkg_name__1 }; if linked_1612 == nil { arg_1618 = ifn_1613.Invoke_O__O(arg_1614) } else { arg_1618 = linked_1612.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1611, arg_1614) }; if linked_1616 == nil { ifn_1617.Invoke_O__O(arg_1618) } else { linked_1616.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_1615, arg_1618) }
					var root_1619 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = A_arbace_repr_go_print_A_const_85; if linked_1620 == nil { ifn_1621.Invoke_O__O(arg_1622) } else { linked_1620.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1619, arg_1622) }
					var root_1623 any = A_arbace_repr_go_print_A_const_168.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, A_arbace_repr_go_print_write_imports_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = A_arbace_repr_go_print_A_const_140.Invoke_O__O(opts__6); if linked_1624 == nil { ifn_1625.Invoke_O__O(arg_1626) } else { linked_1624.(*A_arbace_repr_go_print_write_imports_A).Invoke_O_O__O(root_1623, arg_1626) }
//line :298:1
					var decls__20 any; var root_1627 any = A_arbace_repr_go_print_A_const_91.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1629 lang.IFn



















					if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = decls__7; if linked_1628 == nil { decls__20 = ifn_1629.Invoke_O__O(arg_1630) } else { decls__20 = linked_1628.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1627, arg_1630) }
//line :298:1
					var n__21 int32 = lang.RT_Count_O__I_NoInit(decls__20); var starts__22 any





















					if jrt.J2g_Truth(lines_QMARK___16) { var root_1631 any = A_arbace_repr_go_print_A_const_169.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, A_arbace_repr_go_print_chunk_starts_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = decls__20; if linked_1632 == nil { starts__22 = ifn_1633.Invoke_O__O(arg_1634) } else { starts__22 = linked_1632.(*A_arbace_repr_go_print_chunk_starts_A).Invoke_O_O__O(root_1631, arg_1634) } } else { starts__22 = nil }
					var tmp28 any; var root_1635 any = A_arbace_repr_go_print_A_const_53.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = starts__22; if linked_1636 == nil { tmp28 = ifn_1637.Invoke_O__O(arg_1638) } else { tmp28 = linked_1636.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1635, arg_1638) }; if jrt.J2g_Truth(tmp28) { var n__1927000701__auto____23 int64 = lang.RT_LongCast_I__J_NoInit(n__21); var i__24 int64 = 0; L4: for {
						if lang.Numbers_Lt_J_J__Z_NoInit(i__24, n__1927000701__auto____23) { var root_1843 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1843, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1845 lang.IFn; if linked_1844 == nil { ifn_1845 = lang.IFn_Cast(root_1843) } else { ifn_1845 = nil }; var arg_1846 any = decls__20; var arg_1847 any = jrt.Long_ValueOf_J__Long_NoInit(i__24).Ref(); var arg_1848 any = lines_QMARK___16; var arg_1849 any = popts__12; var arg_1850 any = jrt.Boolean_TRUE.Ref(); if linked_1844 == nil { ifn_1845.Invoke_O_O_O_O_O__O(arg_1846, arg_1847, arg_1848, arg_1849, arg_1850) } else { linked_1844.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1843, arg_1846, arg_1847, arg_1848, arg_1849, arg_1850) }; i__24 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__24); continue L4 }
//line :321:1
						break L4 } } else { var chunks__23 any; var root_1649 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1651 lang.IFn

							if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = A_arbace_repr_go_print_A_const_170.GetRawRoot__O(); var arg_1653 any = starts__22; var arg_1654 any; var root_1644 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any; var root_1639 any = A_arbace_repr_go_print_A_const_118.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = starts__22; var arg_1643 any = A_arbace_repr_go_print_A_const_68; if linked_1640 == nil { arg_1647 = ifn_1641.Invoke_O_O__O(arg_1642, arg_1643) } else { arg_1647 = linked_1640.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_1639, arg_1642, arg_1643) }; var arg_1648 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__21).Ref(); if linked_1645 == nil { arg_1654 = ifn_1646.Invoke_O_O__O(arg_1647, arg_1648) } else { arg_1654 = linked_1645.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1644, arg_1647, arg_1648) }; if linked_1650 == nil { chunks__23 = ifn_1651.Invoke_O_O_O__O(arg_1652, arg_1653, arg_1654) } else { chunks__23 = linked_1650.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1649, arg_1652, arg_1653, arg_1654) }
//line :321:1
							var first_line__24 any; var tmp29 any = A_arbace_repr_go_print_print_file_first_line__1344000156_A_New_O(decls__20); var tmp30 *jrt.Class
							var fncls__1663 /*line :321:1*/*jrt.Class = A_arbace_repr_go_print_print_file_first_line__1344000156_A_fn_class



							if fncls__1663 == nil { var fncls__1663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_repr_go_print_print_file_first_line__1344000156_A_fn_class = fncls__1663d; tmp30 = fncls__1663d } else { tmp30 = fncls__1663 }; first_line__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil)
//line :321:1
							var printed__25 any; var root_1747 any = A_arbace_repr_go_print_A_const_171.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_1749 lang.IFn





							if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any; var tmp31 any = A_arbace_repr_go_print_print_file_fn__1344000159_A_New_O_O_O_O_O(popts__12, first_line__24, lines_QMARK___16, decls__20, state_opts__17); var tmp32 *jrt.Class; var fncls__1746 *jrt.Class = A_arbace_repr_go_print_print_file_fn__1344000159_A_fn_class; if fncls__1746 == nil { var fncls__1746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_repr_go_print_print_file_fn__1344000159_A_fn_class = fncls__1746d; tmp32 = fncls__1746d } else { tmp32 = fncls__1746 }; arg_1750 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var arg_1751 any = chunks__23; if linked_1748 == nil { printed__25 = ifn_1749.Invoke_O_O__O(arg_1750, arg_1751) } else { printed__25 = linked_1748.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_1747, arg_1750, arg_1751) }
//line :321:1
							var n__1927000701__auto____26 int64; var tmp33 any; var root_1851 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1853 lang.IFn













							if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = starts__22; if linked_1852 == nil { tmp33 = ifn_1853.Invoke_O__O(arg_1854) } else { tmp33 = linked_1852.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1851, arg_1854) }; n__1927000701__auto____26 = lang.RT_LongCast_O__J_NoInit(tmp33)
//line :321:1
							var i__27 int64 = 0; L5: for {













								if lang.Numbers_Lt_J_J__Z_NoInit(i__27, n__1927000701__auto____26) { var root_1855 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any = decls__20; var arg_1859 any = jrt.Long_ValueOf_J__Long_NoInit(i__27).Ref(); var arg_1860 any = lines_QMARK___16; var arg_1861 any = popts__12; var arg_1862 any = jrt.Boolean_TRUE.Ref(); if linked_1856 == nil { ifn_1857.Invoke_O_O_O_O_O__O(arg_1858, arg_1859, arg_1860, arg_1861, arg_1862) } else { linked_1856.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1855, arg_1858, arg_1859, arg_1860, arg_1861, arg_1862) }; i__27 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__27); continue L5 }
//line :321:1
								break L5 }; var seq_1344000168__26 any; var root_1758 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1760 lang.IFn















							if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any; var root_1752 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1752, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = A_arbace_repr_go_print_A_const_170.GetRawRoot__O(); var arg_1756 any = chunks__23; var arg_1757 any = printed__25; if linked_1753 == nil { arg_1761 = ifn_1754.Invoke_O_O_O__O(arg_1755, arg_1756, arg_1757) } else { arg_1761 = linked_1753.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1752, arg_1755, arg_1756, arg_1757) }; if linked_1759 == nil { seq_1344000168__26 = ifn_1760.Invoke_O__O(arg_1761) } else { seq_1344000168__26 = linked_1759.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1758, arg_1761) }
//line :321:1
							var chunk_1344000169__27 any; var count_1344000170__28 int64 = 0; var i_1344000171__29 int64 = 0; L6: for {















								if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000171__29, count_1344000170__28) { var vec__1344000172__30 any = lang.Indexed_Cast(chunk_1344000169__27).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000171__29)); var vec__1344000175__31 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000172__30, lang.RT_IntCast_J__I_NoInit(0), nil); var a__32 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000175__31, lang.RT_IntCast_J__I_NoInit(0), nil); var b__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000175__31, lang.RT_IntCast_J__I_NoInit(1), nil); var c__34 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000172__30, lang.RT_IntCast_J__I_NoInit(1), nil); var f__35 any = lang.RT_Nth_O_I__O_NoInit(decls__20, lang.RT_IntCast_O__I_NoInit(a__32)); var root_1903 any = A_arbace_repr_go_print_A_const_125.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, A_arbace_repr_go_print_decl_sep_BANG__A_fn_class); var ifn_1905 lang.IFn

									if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = f__35; var arg_1907 any; var tmp34 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp34.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp35 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____36 any = tmp35.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__35)); var tmp36 any; var root_1895 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = l__308000057__auto____36; if linked_1896 == nil { tmp36 = ifn_1897.Invoke_O__O(arg_1898) } else { tmp36 = linked_1896.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1895, arg_1898) }; if jrt.J2g_Truth(tmp36) { arg_1907 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____36)).Ref() } else { arg_1907 = nil } } else { arg_1907 = nil }; var arg_1908 any; var tmp37 any; var root_1899 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = f__35; if linked_1900 == nil { tmp37 = ifn_1901.Invoke_O__O(arg_1902) } else { tmp37 = linked_1900.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1899, arg_1902) }; arg_1908 = lang.RT_Nth_O_I__O_NoInit(tmp37, lang.RT_IntCast_J__I_NoInit(3)); var arg_1909 any = lines_QMARK___16; if linked_1904 == nil { ifn_1905.Invoke_O_O_O_O__O(arg_1906, arg_1907, arg_1908, arg_1909) } else { linked_1904.(*A_arbace_repr_go_print_decl_sep_BANG__A).Invoke_O_O_O_O_O__O(root_1903, arg_1906, arg_1907, arg_1908, arg_1909) }
									var tmp38 any; var root_1863 any = A_arbace_repr_go_print_A_const_175.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A_fn_class); var ifn_1865 lang.IFn; if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = c__34; var arg_1867 any = lang.IFn_Cast(first_line__24).Invoke_O__O(a__32); if linked_1864 == nil { tmp38 = ifn_1865.Invoke_O_O__O(arg_1866, arg_1867) } else { tmp38 = linked_1864.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A).Invoke_O_O_O__O(root_1863, arg_1866, arg_1867) }; if jrt.J2g_Truth(tmp38) { } else {
										var root_1910 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = decls__20; var arg_1914 any = a__32; var arg_1915 any = lines_QMARK___16; var arg_1916 any = popts__12; var arg_1917 any = jrt.Boolean_FALSE.Ref(); if linked_1911 == nil { ifn_1912.Invoke_O_O_O_O_O__O(arg_1913, arg_1914, arg_1915, arg_1916, arg_1917) } else { linked_1911.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1910, arg_1913, arg_1914, arg_1915, arg_1916, arg_1917) }
//line :340:1
										var seq_1344000178__35 any; var root_1875 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1877 lang.IFn

										if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any; var root_1870 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any; var na_1868 any = a__32; if jrt.Long_InstanceOf(na_1868) { var n0_1869 int64 = jrt.NN(jrt.Long_Cast(na_1868)).LongValue__J(); if n0_1869 == 9223372036854775807 { arg_1873 = lang.Numbers_Inc_O__Number_NoInit(na_1868) } else { arg_1873 = jrt.Long_ValueOf_J__Long_NoInit(n0_1869 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1868) { var n0_1869_2 float64 = jrt.NN(jrt.Double_Cast(na_1868)).DoubleValue__D(); arg_1873 = jrt.Double_ValueOf_D__Double_NoInit(n0_1869_2 + 1.0).Ref() } else { arg_1873 = lang.Numbers_Inc_O__Number_NoInit(na_1868) } }; var arg_1874 any = b__33; if linked_1871 == nil { arg_1878 = ifn_1872.Invoke_O_O__O(arg_1873, arg_1874) } else { arg_1878 = linked_1871.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1870, arg_1873, arg_1874) }; if linked_1876 == nil { seq_1344000178__35 = ifn_1877.Invoke_O__O(arg_1878) } else { seq_1344000178__35 = linked_1876.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1875, arg_1878) }
//line :340:1
										var chunk_1344000179__36 any; var count_1344000180__37 int64 = 0; var i_1344000181__38 int64 = 0; L7: for {

											if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000181__38, count_1344000180__37) { var i__39 any = lang.Indexed_Cast(chunk_1344000179__36).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000181__38)); var root_1918 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = decls__20; var arg_1922 any = i__39; var arg_1923 any = lines_QMARK___16; var arg_1924 any = popts__12; var arg_1925 any = jrt.Boolean_TRUE.Ref(); if linked_1919 == nil { ifn_1920.Invoke_O_O_O_O_O__O(arg_1921, arg_1922, arg_1923, arg_1924, arg_1925) } else { linked_1919.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1918, arg_1921, arg_1922, arg_1923, arg_1924, arg_1925) }; seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, i_1344000181__38 = seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000181__38); continue L7 } else { var temp__1927000414__auto____39 any; var root_1879 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = seq_1344000178__35; if linked_1880 == nil { temp__1927000414__auto____39 = ifn_1881.Invoke_O__O(arg_1882) } else { temp__1927000414__auto____39 = linked_1880.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1879, arg_1882) }; if jrt.J2g_Truth(temp__1927000414__auto____39) { var seq_1344000178__40 any = temp__1927000414__auto____39; var tmp39 any; var root_1883 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = seq_1344000178__40; if linked_1884 == nil { tmp39 = ifn_1885.Invoke_O__O(arg_1886) } else { tmp39 = linked_1884.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1883, arg_1886) }; if jrt.J2g_Truth(tmp39) { var c__1927000678__auto____41 any; var root_1887 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = seq_1344000178__40; if linked_1888 == nil { c__1927000678__auto____41 = ifn_1889.Invoke_O__O(arg_1890) } else { c__1927000678__auto____41 = linked_1888.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1887, arg_1890) }; var tmp40 any; var root_1926 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = seq_1344000178__40; if linked_1927 == nil { tmp40 = ifn_1928.Invoke_O__O(arg_1929) } else { tmp40 = linked_1927.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1926, arg_1929) }; seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, i_1344000181__38 = tmp40, c__1927000678__auto____41, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var i__41 any; var root_1891 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = seq_1344000178__40; if linked_1892 == nil { i__41 = ifn_1893.Invoke_O__O(arg_1894) } else { i__41 = linked_1892.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1891, arg_1894) }; var root_1930 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = decls__20; var arg_1934 any = i__41; var arg_1935 any = lines_QMARK___16; var arg_1936 any = popts__12; var arg_1937 any = jrt.Boolean_TRUE.Ref(); if linked_1931 == nil { ifn_1932.Invoke_O_O_O_O_O__O(arg_1933, arg_1934, arg_1935, arg_1936, arg_1937) } else { linked_1931.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1930, arg_1933, arg_1934, arg_1935, arg_1936, arg_1937) }; var tmp41 any; var root_1938 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = seq_1344000178__40; if linked_1939 == nil { tmp41 = ifn_1940.Invoke_O__O(arg_1941) } else { tmp41 = linked_1939.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1938, arg_1941) }; seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, i_1344000181__38 = tmp41, nil, 0, 0; continue L7 } } }
//line :340:1
											break L7 } }
//line :337:1
									seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, i_1344000171__29 = seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000171__29); continue L6 } else { var temp__1927000414__auto____30 any; var root_1762 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = seq_1344000168__26; if linked_1763 == nil { temp__1927000414__auto____30 = ifn_1764.Invoke_O__O(arg_1765) } else { temp__1927000414__auto____30 = linked_1763.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1762, arg_1765) }; if jrt.J2g_Truth(temp__1927000414__auto____30) { var seq_1344000168__31 any = temp__1927000414__auto____30; var tmp42 any; var root_1766 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = seq_1344000168__31; if linked_1767 == nil { tmp42 = ifn_1768.Invoke_O__O(arg_1769) } else { tmp42 = linked_1767.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1766, arg_1769) }; if jrt.J2g_Truth(tmp42) { var c__1927000678__auto____32 any; var root_1770 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = seq_1344000168__31; if linked_1771 == nil { c__1927000678__auto____32 = ifn_1772.Invoke_O__O(arg_1773) } else { c__1927000678__auto____32 = linked_1771.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1770, arg_1773) }; var tmp43 any; var root_1942 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = seq_1344000168__31; if linked_1943 == nil { tmp43 = ifn_1944.Invoke_O__O(arg_1945) } else { tmp43 = linked_1943.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1942, arg_1945) }; seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, i_1344000171__29 = tmp43, c__1927000678__auto____32, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____32))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var vec__1344000182__32 any; var root_1774 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = seq_1344000168__31; if linked_1775 == nil { vec__1344000182__32 = ifn_1776.Invoke_O__O(arg_1777) } else { vec__1344000182__32 = linked_1775.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1774, arg_1777) }; var vec__1344000185__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000182__32, lang.RT_IntCast_J__I_NoInit(0), nil); var a__34 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000185__33, lang.RT_IntCast_J__I_NoInit(0), nil); var b__35 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000185__33, lang.RT_IntCast_J__I_NoInit(1), nil); var c__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000182__32, lang.RT_IntCast_J__I_NoInit(1), nil); var f__37 any = lang.RT_Nth_O_I__O_NoInit(decls__20, lang.RT_IntCast_O__I_NoInit(a__34)); var root_1986 any = A_arbace_repr_go_print_A_const_125.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, A_arbace_repr_go_print_decl_sep_BANG__A_fn_class); var ifn_1988 lang.IFn

										if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = f__37; var arg_1990 any; var tmp44 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp44.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp45 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____38 any = tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__37)); var tmp46 any; var root_1978 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = l__308000057__auto____38; if linked_1979 == nil { tmp46 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp46 = linked_1979.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1978, arg_1981) }; if jrt.J2g_Truth(tmp46) { arg_1990 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____38)).Ref() } else { arg_1990 = nil } } else { arg_1990 = nil }; var arg_1991 any; var tmp47 any; var root_1982 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = f__37; if linked_1983 == nil { tmp47 = ifn_1984.Invoke_O__O(arg_1985) } else { tmp47 = linked_1983.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1982, arg_1985) }; arg_1991 = lang.RT_Nth_O_I__O_NoInit(tmp47, lang.RT_IntCast_J__I_NoInit(3)); var arg_1992 any = lines_QMARK___16; if linked_1987 == nil { ifn_1988.Invoke_O_O_O_O__O(arg_1989, arg_1990, arg_1991, arg_1992) } else { linked_1987.(*A_arbace_repr_go_print_decl_sep_BANG__A).Invoke_O_O_O_O_O__O(root_1986, arg_1989, arg_1990, arg_1991, arg_1992) }
										var tmp48 any; var root_1946 any = A_arbace_repr_go_print_A_const_175.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = c__36; var arg_1950 any = lang.IFn_Cast(first_line__24).Invoke_O__O(a__34); if linked_1947 == nil { tmp48 = ifn_1948.Invoke_O_O__O(arg_1949, arg_1950) } else { tmp48 = linked_1947.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A).Invoke_O_O_O__O(root_1946, arg_1949, arg_1950) }; if jrt.J2g_Truth(tmp48) { } else {
											var root_1993 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = decls__20; var arg_1997 any = a__34; var arg_1998 any = lines_QMARK___16; var arg_1999 any = popts__12; var arg_2000 any = jrt.Boolean_FALSE.Ref(); if linked_1994 == nil { ifn_1995.Invoke_O_O_O_O_O__O(arg_1996, arg_1997, arg_1998, arg_1999, arg_2000) } else { linked_1994.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1993, arg_1996, arg_1997, arg_1998, arg_1999, arg_2000) }
//line :340:1
											var seq_1344000188__37 any; var root_1958 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1960 lang.IFn

											if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any; var root_1953 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1955 lang.IFn; if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any; var na_1951 any = a__34; if jrt.Long_InstanceOf(na_1951) { var n0_1952 int64 = jrt.NN(jrt.Long_Cast(na_1951)).LongValue__J(); if n0_1952 == 9223372036854775807 { arg_1956 = lang.Numbers_Inc_O__Number_NoInit(na_1951) } else { arg_1956 = jrt.Long_ValueOf_J__Long_NoInit(n0_1952 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1951) { var n0_1952_2 float64 = jrt.NN(jrt.Double_Cast(na_1951)).DoubleValue__D(); arg_1956 = jrt.Double_ValueOf_D__Double_NoInit(n0_1952_2 + 1.0).Ref() } else { arg_1956 = lang.Numbers_Inc_O__Number_NoInit(na_1951) } }; var arg_1957 any = b__35; if linked_1954 == nil { arg_1961 = ifn_1955.Invoke_O_O__O(arg_1956, arg_1957) } else { arg_1961 = linked_1954.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1953, arg_1956, arg_1957) }; if linked_1959 == nil { seq_1344000188__37 = ifn_1960.Invoke_O__O(arg_1961) } else { seq_1344000188__37 = linked_1959.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1958, arg_1961) }
//line :340:1
											var chunk_1344000189__38 any; var count_1344000190__39 int64 = 0; var i_1344000191__40 int64 = 0; L8: for {

												if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000191__40, count_1344000190__39) { var i__41_2 any = lang.Indexed_Cast(chunk_1344000189__38).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000191__40)); var root_2001 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2001, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = decls__20; var arg_2005 any = i__41_2; var arg_2006 any = lines_QMARK___16; var arg_2007 any = popts__12; var arg_2008 any = jrt.Boolean_TRUE.Ref(); if linked_2002 == nil { ifn_2003.Invoke_O_O_O_O_O__O(arg_2004, arg_2005, arg_2006, arg_2007, arg_2008) } else { linked_2002.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_2001, arg_2004, arg_2005, arg_2006, arg_2007, arg_2008) }; seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, i_1344000191__40 = seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000191__40); continue L8 } else { var temp__1927000414__auto____41 any; var root_1962 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = seq_1344000188__37; if linked_1963 == nil { temp__1927000414__auto____41 = ifn_1964.Invoke_O__O(arg_1965) } else { temp__1927000414__auto____41 = linked_1963.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1962, arg_1965) }; if jrt.J2g_Truth(temp__1927000414__auto____41) { var seq_1344000188__42 any = temp__1927000414__auto____41; var tmp49 any; var root_1966 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = seq_1344000188__42; if linked_1967 == nil { tmp49 = ifn_1968.Invoke_O__O(arg_1969) } else { tmp49 = linked_1967.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1966, arg_1969) }; if jrt.J2g_Truth(tmp49) { var c__1927000678__auto____43 any; var root_1970 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = seq_1344000188__42; if linked_1971 == nil { c__1927000678__auto____43 = ifn_1972.Invoke_O__O(arg_1973) } else { c__1927000678__auto____43 = linked_1971.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1970, arg_1973) }; var tmp50 any; var root_2009 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = seq_1344000188__42; if linked_2010 == nil { tmp50 = ifn_2011.Invoke_O__O(arg_2012) } else { tmp50 = linked_2010.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2009, arg_2012) }; seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, i_1344000191__40 = tmp50, c__1927000678__auto____43, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____43))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var i__43 any; var root_1974 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = seq_1344000188__42; if linked_1975 == nil { i__43 = ifn_1976.Invoke_O__O(arg_1977) } else { i__43 = linked_1975.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1974, arg_1977) }; var root_2013 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = decls__20; var arg_2017 any = i__43; var arg_2018 any = lines_QMARK___16; var arg_2019 any = popts__12; var arg_2020 any = jrt.Boolean_TRUE.Ref(); if linked_2014 == nil { ifn_2015.Invoke_O_O_O_O_O__O(arg_2016, arg_2017, arg_2018, arg_2019, arg_2020) } else { linked_2014.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_2013, arg_2016, arg_2017, arg_2018, arg_2019, arg_2020) }; var tmp51 any; var root_2021 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = seq_1344000188__42; if linked_2022 == nil { tmp51 = ifn_2023.Invoke_O__O(arg_2024) } else { tmp51 = linked_2022.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2021, arg_2024) }; seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, i_1344000191__40 = tmp51, nil, 0, 0; continue L8 } } }
//line :340:1
												break L8 } }
//line :337:1
										var tmp52 any; var root_2025 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = seq_1344000168__31; if linked_2026 == nil { tmp52 = ifn_2027.Invoke_O__O(arg_2028) } else { tmp52 = linked_2026.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2025, arg_2028) }; seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, i_1344000171__29 = tmp52, nil, 0, 0; continue L6 } } }
//line :321:1
								break L6
							}
						}



















					var tmp53 any; var root_1778 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var tmp54 *lang.Keyword = A_arbace_repr_go_print_A_const_121; var arg_1781 any = tmp54.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1779 == nil { tmp53 = ifn_1780.Invoke_O__O(arg_1781) } else { tmp53 = linked_1779.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1778, arg_1781) }; if jrt.J2g_Truth(tmp53) { } else { var root_1782 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = A_arbace_repr_go_print_A_const_85; if linked_1783 == nil { ifn_1784.Invoke_O__O(arg_1785) } else { linked_1783.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1782, arg_1785) } }
					var root_1512 any = A_arbace_repr_go_print_A_const_141.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; if linked_1513 == nil { tmp18 = ifn_1514.Invoke__O() } else { tmp18 = linked_1513.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A).Invoke_O__O(root_1512) } }
//line :298:1
				return nil }(); var root_1515 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1517 lang.IFn




			if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; if linked_1516 == nil { ifn_1517.Invoke__O() } else { linked_1516.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1515) }
//line :298:1
			if tmp55 != nil { panic(tmp55) }; return tmp18 } }


























func A_arbace_repr_go_print_print_file_first_line__1344000156_A_New_O(p0 any) *A_arbace_repr_go_print_print_file_first_line__1344000156_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_first_line__1344000156_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_repr_go_print_print_file_first_line__1344000156_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :325:1
func (t *A_arbace_repr_go_print_print_file_first_line__1344000156_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 any = t.F_decls; var f__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(a__1)); var tmp2 *jrt.Long; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if
													jrt.J2g_Truth(tmp3.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____3 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__2)); var tmp5 any; var root_1655 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any = l__308000057__auto____3; if linked_1656 == nil { tmp5 = ifn_1657.Invoke_O__O(arg_1658) } else { tmp5 = linked_1656.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1655, arg_1658) }; if jrt.J2g_Truth(tmp5) { tmp2 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____3)) } else { tmp2 = nil } } else { tmp2 = nil }; var tmp6 int64 = lang.RT_LongCast_O__J_NoInit(tmp2.Ref()); var tmp7 any; var root_1659 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1659, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1661 lang.IFn; if linked_1660 == nil { ifn_1661 = lang.IFn_Cast(root_1659) } else { ifn_1661 = nil }; var arg_1662 any = f__2; if linked_1660 == nil { tmp7 = ifn_1661.Invoke_O__O(arg_1662) } else { tmp7 = linked_1660.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1659, arg_1662) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(tmp6, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp7, lang.RT_IntCast_J__I_NoInit(3))))).Ref() }
func A_arbace_repr_go_print_print_file_fn__1344000159_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_print_file_fn__1344000159_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_fn__1344000159_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :327:1
func (t *A_arbace_repr_go_print_print_file_fn__1344000159_A) Ctor_O_O_O_O_O(c__popts, c__first_line, c__lines_QMARK_, c__decls, c__state_opts any) { t.F_popts = c__popts; t.F_first_line = c__first_line; t.F_lines_QMARK_ = c__lines_QMARK_; t.F_decls = c__decls; t.F_state_opts = c__state_opts }
//line :327:1
func (t *A_arbace_repr_go_print_print_file_fn__1344000159_A) Invoke_O_O__O(self, p__1344000158__1 any) any { var vec__1344000160__2 any = p__1344000158__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000160__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000160__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1679 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1681 lang.IFn; if
														linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_114; var tmp3 any; var root_1670 any = A_arbace_repr_go_print_A_const_142.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A_fn_class); var ifn_1672 lang.IFn; if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = t.F_state_opts; if linked_1671 == nil { tmp3 = ifn_1672.Invoke_O__O(arg_1673) } else { tmp3 = linked_1671.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A).Invoke_O_O__O(root_1670, arg_1673) }; arg_1682 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_1680 == nil { ifn_1681.Invoke_O__O(arg_1682) } else { linked_1680.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1679, arg_1682) }; var tmp4 any; tmp8 := /*line :327:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_1683 any = A_arbace_repr_go_print_A_const_173.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_start_at_BANG__A_fn_class); var ifn_1685 lang.IFn; if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = lang.IFn_Cast(t.F_first_line).Invoke_O__O(a__3); if linked_1684 == nil { ifn_1685.Invoke_O__O(arg_1686) } else { linked_1684.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_start_at_BANG__A).Invoke_O_O__O(root_1683, arg_1686) }
			var root_1687 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any = t.F_decls; var arg_1691 any = a__3; var arg_1692 any = t.F_lines_QMARK_; var arg_1693 any = t.F_popts; var arg_1694 any = jrt.Boolean_FALSE.Ref(); if linked_1688 == nil { ifn_1689.Invoke_O_O_O_O_O__O(arg_1690, arg_1691, arg_1692, arg_1693, arg_1694) } else { linked_1688.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1687, arg_1690, arg_1691, arg_1692, arg_1693, arg_1694) }
//line :327:1
			var seq_1344000163__7 any; var root_1702 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1704 lang.IFn



			if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any; var root_1697 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any; var na_1695 any = a__3; if jrt.Long_InstanceOf(na_1695) { var n0_1696 int64 = jrt.NN(jrt.Long_Cast(na_1695)).LongValue__J(); if n0_1696 == 9223372036854775807 { arg_1700 = lang.Numbers_Inc_O__Number_NoInit(na_1695) } else { arg_1700 = jrt.Long_ValueOf_J__Long_NoInit(n0_1696 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1695) { var n0_1696_2 float64 = jrt.NN(jrt.Double_Cast(na_1695)).DoubleValue__D(); arg_1700 = jrt.Double_ValueOf_D__Double_NoInit(n0_1696_2 + 1.0).Ref() } else { arg_1700 = lang.Numbers_Inc_O__Number_NoInit(na_1695) } }; var arg_1701 any = b__4; if linked_1698 == nil { arg_1705 = ifn_1699.Invoke_O_O__O(arg_1700, arg_1701) } else { arg_1705 = linked_1698.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1697, arg_1700, arg_1701) }; if linked_1703 == nil { seq_1344000163__7 = ifn_1704.Invoke_O__O(arg_1705) } else { seq_1344000163__7 = linked_1703.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1702, arg_1705) }
//line :327:1
			var chunk_1344000164__8 any; var count_1344000165__9 int64 = 0; var i_1344000166__10 int64 = 0; L1: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000166__10, count_1344000165__9) { var i__11 any = lang.Indexed_Cast(chunk_1344000164__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000166__10)); var root_1722 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1724 lang.IFn; if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = t.F_decls; var arg_1726 any = i__11; var arg_1727 any = t.F_lines_QMARK_; var arg_1728 any = t.F_popts; var arg_1729 any = jrt.Boolean_TRUE.Ref(); if linked_1723 == nil { ifn_1724.Invoke_O_O_O_O_O__O(arg_1725, arg_1726, arg_1727, arg_1728, arg_1729) } else { linked_1723.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1722, arg_1725, arg_1726, arg_1727, arg_1728, arg_1729) }; seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, i_1344000166__10 = seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000166__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1706 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = seq_1344000163__7; if linked_1707 == nil { temp__1927000414__auto____11 = ifn_1708.Invoke_O__O(arg_1709) } else { temp__1927000414__auto____11 = linked_1707.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1706, arg_1709) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1344000163__12 any = temp__1927000414__auto____11; var tmp5 any; var root_1710 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = seq_1344000163__12; if linked_1711 == nil { tmp5 = ifn_1712.Invoke_O__O(arg_1713) } else { tmp5 = linked_1711.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1710, arg_1713) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____13 any; var root_1714 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = seq_1344000163__12; if linked_1715 == nil { c__1927000678__auto____13 = ifn_1716.Invoke_O__O(arg_1717) } else { c__1927000678__auto____13 = linked_1715.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1714, arg_1717) }; var tmp6 any; var root_1730 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = seq_1344000163__12; if linked_1731 == nil { tmp6 = ifn_1732.Invoke_O__O(arg_1733) } else { tmp6 = linked_1731.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1730, arg_1733) }; seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, i_1344000166__10 = tmp6, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var i__13 any; var root_1718 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = seq_1344000163__12; if linked_1719 == nil { i__13 = ifn_1720.Invoke_O__O(arg_1721) } else { i__13 = linked_1719.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1718, arg_1721) }; var root_1734 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = t.F_decls; var arg_1738 any = i__13; var arg_1739 any = t.F_lines_QMARK_; var arg_1740 any = t.F_popts; var arg_1741 any = jrt.Boolean_TRUE.Ref(); if linked_1735 == nil { ifn_1736.Invoke_O_O_O_O_O__O(arg_1737, arg_1738, arg_1739, arg_1740, arg_1741) } else { linked_1735.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1734, arg_1737, arg_1738, arg_1739, arg_1740, arg_1741) }; var tmp7 any; var root_1742 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = seq_1344000163__12; if linked_1743 == nil { tmp7 = ifn_1744.Invoke_O__O(arg_1745) } else { tmp7 = linked_1743.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1742, arg_1745) }; seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, i_1344000166__10 = tmp7, nil, 0, 0; continue L1 } } }
//line :327:1
				break L1
			}



			var root_1664 any = A_arbace_repr_go_print_A_const_172.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_chunk_state_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; if linked_1665 == nil { tmp4 = ifn_1666.Invoke__O() } else { tmp4 = linked_1665.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_chunk_state_A).Invoke_O__O(root_1664) } }
//line :327:1
		return nil }(); var root_1667 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1669 lang.IFn; if
	linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; if linked_1668 == nil { ifn_1669.Invoke__O() } else { linked_1668.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1667) }; if /*line :327:1*/ tmp8 != nil { panic(tmp8) }; return tmp4 }


















func A_arbace_repr_go_print_print_forms_A_New() *A_arbace_repr_go_print_print_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_forms_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_repr_go_print_print_forms_A) Ctor() {}
//line :346:1
func (t *A_arbace_repr_go_print_print_forms_A) Invoke_O_O_O__O(self, pkg__0, opts__1 any) any {



	var root_2048 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_176.GetRawRoot__O()).Invoke__O(); var arg_2052 any; var root_2043 any = A_arbace_repr_go_print_A_const_171.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_2045 lang.IFn
	if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any; var tmp1 any = A_arbace_repr_go_print_print_forms_fn__1344000193_A_New_O_O(pkg__0, opts__1); var tmp2 *jrt.Class; var fncls__2042 *jrt.Class = A_arbace_repr_go_print_print_forms_fn__1344000193_A_fn_class; if fncls__2042 == nil { var fncls__2042d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_repr_go_print_print_forms_fn__1344000193_A_fn_class = fncls__2042d; tmp2 = fncls__2042d } else { tmp2 = fncls__2042 }; arg_2046 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2047 any = A_arbace_repr_go_print_A_const_46.Invoke_O__O(pkg__0); if linked_2044 == nil { arg_2052 = ifn_2045.Invoke_O_O__O(arg_2046, arg_2047) } else { arg_2052 = linked_2044.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_2043, arg_2046, arg_2047) }
//line :350:1
	if linked_2049 == nil { return ifn_2050.Invoke_O_O__O(arg_2051, arg_2052) } else { return linked_2049.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2048, arg_2051, arg_2052) } }
func A_arbace_repr_go_print_print_forms_fn__1344000193_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_print_forms_fn__1344000193_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_forms_fn__1344000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_repr_go_print_print_forms_fn__1344000193_A) Ctor_O_O(c__pkg, c__opts any) { t.F_pkg = c__pkg; t.F_opts = c__opts }
//line :351:1
func (t *A_arbace_repr_go_print_print_forms_fn__1344000193_A) Invoke_O_O__O(self, fl__1 any) any { var tmp1 any; var root_2032 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = A_arbace_repr_go_print_A_const_45.Invoke_O__O(fl__1); if linked_2033 == nil { tmp1 = ifn_2034.Invoke_O__O(arg_2035) } else { tmp1 = linked_2033.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2032, arg_2035) }; var tmp2 any = tmp1; var tmp3 any; var root_2036 any = A_arbace_repr_go_print_A_const_177.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, A_arbace_repr_go_print_print_file_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = fl__1; var arg_2040 any = A_arbace_repr_go_print_A_const_45.Invoke_O__O(t.F_pkg); var arg_2041 any = t.F_opts; if linked_2037 == nil { tmp3 = ifn_2038.Invoke_O_O_O__O(arg_2039, arg_2040, arg_2041) } else { tmp3 = linked_2037.(*A_arbace_repr_go_print_print_file_A).Invoke_O_O_O_O__O(root_2036, arg_2039, arg_2040, arg_2041) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }





func A_arbace_repr_go_print_sha256_A_New() *A_arbace_repr_go_print_sha256_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_sha256_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_repr_go_print_sha256_A) Ctor() {}
//line :357:1
func (t *A_arbace_repr_go_print_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_97); var bs__3 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path()).Ref(); var root_2069 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2071 lang.IFn; if


	linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var arg_2073 any; var root_2064 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2064, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any; var tmp1 any = A_arbace_repr_go_print_sha256_fn__1344000197_A_New(); var tmp2 *jrt.Class; var fncls__2063 *jrt.Class = A_arbace_repr_go_print_sha256_fn__1344000197_A_fn_class; if fncls__2063 == nil { var fncls__2063d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_repr_go_print_sha256_fn__1344000197_A_fn_class = fncls__2063d; tmp2 = fncls__2063d } else { tmp2 = fncls__2063 }; arg_2067 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2068 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.J2g_CastArray[*jrt.ByteArray](bs__3, jrt.Prim_byte.ArrayClass())).Ref(); if linked_2065 == nil { arg_2073 = ifn_2066.Invoke_O_O__O(arg_2067, arg_2068) } else { arg_2073 = linked_2065.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2064, arg_2067, arg_2068) }; if linked_2070 == nil { return ifn_2071.Invoke_O_O__O(arg_2072, arg_2073) } else { return linked_2070.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2069, arg_2072, arg_2073) } }
//line :360:1
func A_arbace_repr_go_print_sha256_fn__1344000197_A_New() *A_arbace_repr_go_print_sha256_fn__1344000197_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_sha256_fn__1344000197_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_repr_go_print_sha256_fn__1344000197_A) Ctor() {}
//line :360:1
func (t *A_arbace_repr_go_print_sha256_fn__1344000197_A) Invoke_O_O__O(self, p1__1344000196_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_178.GetRawRoot__O()); var tmp2 int64; var na_2053 any = p1__1344000196_SHARP___1; var na_2054 int64 = 255; if jrt.Long_InstanceOf(na_2053) { var n0_2055 int64 = jrt.NN(jrt.Long_Cast(na_2053)).LongValue__J(); var n1_2056 int64 = na_2054; tmp2 = n0_2055 & n1_2056 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_2053, na_2054) }; return tmp1.Invoke_O_O__O(Lit_99, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_repr_go_print_copy_file_A_New() *A_arbace_repr_go_print_copy_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_file_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_go_print_copy_file_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_go_print_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 any; var root_2074 any = A_arbace_repr_go_print_A_const_179.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_2076 lang.IFn
	if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = A_arbace_repr_go_print_A_const_180; var arg_2078 any; var tmp4 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp4 = jrt.StandardCopyOption_REPLACE_EXISTING; arg_2078 = lang.Tuple_Create_O__IPersistentVector(tmp4.Ref()); if linked_2075 == nil { tmp3 = ifn_2076.Invoke_O_O__O(arg_2077, arg_2078) } else { tmp3 = linked_2075.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_2074, arg_2077, arg_2078) }
//line :364:1
	return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_repr_go_print_json_string_A_New() *A_arbace_repr_go_print_json_string_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_json_string_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_repr_go_print_json_string_A) Ctor() {}
//line :367:1
func (t *A_arbace_repr_go_print_json_string_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_85); var tmp2 any; var root_2089 any = A_arbace_repr_go_print_A_const_181.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any; var root_2083 any = A_arbace_repr_go_print_A_const_181.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any; var root_2079 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = s__0; if linked_2080 == nil { arg_2086 = ifn_2081.Invoke_O__O(arg_2082) } else { arg_2086 = linked_2080.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2079, arg_2082) }; var arg_2087 any = Lit_86; var arg_2088 any = Lit_87; if linked_2084 == nil { arg_2092 = ifn_2085.Invoke_O_O_O__O(arg_2086, arg_2087, arg_2088) } else { arg_2092 = linked_2084.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2083, arg_2086, arg_2087, arg_2088) }; var arg_2093 any = Lit_85; var arg_2094 any = Lit_88; if linked_2090 == nil { tmp2 = ifn_2091.Invoke_O_O_O__O(arg_2092, arg_2093, arg_2094) } else { tmp2 = linked_2090.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2089, arg_2092, arg_2093, arg_2094) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref()
}
func A_arbace_repr_go_print_copy_files_A_New() *A_arbace_repr_go_print_copy_files_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_repr_go_print_copy_files_A) Ctor() {}
//line :370:1
func (t *A_arbace_repr_go_print_copy_files_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, written__3 any) any { var opts__5 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(pkg__0); var seq_1344000202__6 any; var root_2196 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2198 lang.IFn; if




	linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = A_arbace_repr_go_print_A_const_185.Invoke_O__O(opts__5); if linked_2197 == nil { seq_1344000202__6 = ifn_2198.Invoke_O__O(arg_2199) } else { seq_1344000202__6 = linked_2197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2196, arg_2199) }; var chunk_1344000203__7 any; var count_1344000204__8 int64 = 0; var i_1344000205__9 int64 = 0; L1:
//line :370:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000205__9, count_1344000204__8) { var f__10 any = lang.Indexed_Cast(chunk_1344000203__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000205__9)); var root_2244 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2244, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2246 lang.IFn
			if linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any; var tmp1 *jrt.File = jrt.File_Cast(src__1); var tmp2 any; var root_2236 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any = f__10; if linked_2237 == nil { tmp2 = ifn_2238.Invoke_O__O(arg_2239) } else { tmp2 = linked_2237.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2236, arg_2239) }; arg_2247 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2)); var arg_2248 any; var tmp3 *jrt.File = jrt.File_Cast(out__2); var tmp4 any; var root_2240 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2240, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2242 lang.IFn; if linked_2241 == nil { ifn_2242 = lang.IFn_Cast(root_2240) } else { ifn_2242 = nil }; var arg_2243 any = f__10; if linked_2241 == nil { tmp4 = ifn_2242.Invoke_O__O(arg_2243) } else { tmp4 = linked_2241.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2240, arg_2243) }; arg_2248 = jrt.File_New_File_String(tmp3, jrt.String_Cast(tmp4)); if linked_2245 == nil { ifn_2246.Invoke_O_O__O(arg_2247, arg_2248) } else { linked_2245.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2244, arg_2247, arg_2248) }
//line :375:1
			seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, i_1344000205__9 = seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000205__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_2200 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = seq_1344000202__6; if linked_2201 == nil { temp__1927000414__auto____10 = ifn_2202.Invoke_O__O(arg_2203) } else { temp__1927000414__auto____10 = linked_2201.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2200, arg_2203) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1344000202__11 any = temp__1927000414__auto____10; var tmp5 any; var root_2204 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2204, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2206 lang.IFn; if linked_2205 == nil { ifn_2206 = lang.IFn_Cast(root_2204) } else { ifn_2206 = nil }; var arg_2207 any = seq_1344000202__11; if linked_2205 == nil { tmp5 = ifn_2206.Invoke_O__O(arg_2207) } else { tmp5 = linked_2205.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2204, arg_2207) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_2208 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = seq_1344000202__11; if linked_2209 == nil { c__1927000678__auto____12 = ifn_2210.Invoke_O__O(arg_2211) } else { c__1927000678__auto____12 = linked_2209.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2208, arg_2211) }; var tmp6 any; var root_2249 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = seq_1344000202__11; if linked_2250 == nil { tmp6 = ifn_2251.Invoke_O__O(arg_2252) } else { tmp6 = linked_2250.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2249, arg_2252) }; seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, i_1344000205__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__12 any; var root_2212 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = seq_1344000202__11; if linked_2213 == nil { f__12 = ifn_2214.Invoke_O__O(arg_2215) } else { f__12 = linked_2213.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2212, arg_2215) }
				var root_2261 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any; var tmp7 *jrt.File = jrt.File_Cast(src__1); var tmp8 any; var root_2253 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = f__12; if linked_2254 == nil { tmp8 = ifn_2255.Invoke_O__O(arg_2256) } else { tmp8 = linked_2254.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2253, arg_2256) }; arg_2264 = jrt.File_New_File_String(tmp7, jrt.String_Cast(tmp8)); var arg_2265 any; var tmp9 *jrt.File = jrt.File_Cast(out__2); var tmp10 any; var root_2257 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = f__12; if linked_2258 == nil { tmp10 = ifn_2259.Invoke_O__O(arg_2260) } else { tmp10 = linked_2258.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2257, arg_2260) }; arg_2265 = jrt.File_New_File_String(tmp9, jrt.String_Cast(tmp10)); if linked_2262 == nil { ifn_2263.Invoke_O_O__O(arg_2264, arg_2265) } else { linked_2262.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2261, arg_2264, arg_2265) }
//line :375:1
				var tmp11 any; var root_2266 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = seq_1344000202__11; if linked_2267 == nil { tmp11 = ifn_2268.Invoke_O__O(arg_2269) } else { tmp11 = linked_2267.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2266, arg_2269) }; seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, i_1344000205__9 = tmp11, nil, 0, 0; continue L1 } } }
//line :370:1
		break L1 }; var seq_1344000206__6 any; var root_2216 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2218 lang.IFn; if






	linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = A_arbace_repr_go_print_A_const_186.Invoke_O__O(opts__5); if linked_2217 == nil { seq_1344000206__6 = ifn_2218.Invoke_O__O(arg_2219) } else { seq_1344000206__6 = linked_2217.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2216, arg_2219) }; var chunk_1344000207__7 any; var count_1344000208__8 int64 = 0; var i_1344000209__9 int64 = 0; L2:
//line :370:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000209__9, count_1344000208__8) { var vec__1344000210__10 any = lang.Indexed_Cast(chunk_1344000207__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000209__9)); var f__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000210__10, lang.RT_IntCast_J__I_NoInit(0), nil); var h__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000210__10, lang.RT_IntCast_J__I_NoInit(1), nil); var from__13 any; var tmp12 *jrt.File = jrt.File_Cast(src__1); var tmp13 any; var root_2270 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2270, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2272 lang.IFn
			if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = f__11; if linked_2271 == nil { tmp13 = ifn_2272.Invoke_O__O(arg_2273) } else { tmp13 = linked_2271.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2270, arg_2273) }
//line :377:1
			from__13 = jrt.File_New_File_String(tmp12, jrt.String_Cast(tmp13)); var got__14 any; var root_2274 any = A_arbace_repr_go_print_A_const_188.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2274, A_arbace_repr_go_print_sha256_A_fn_class); var ifn_2276 lang.IFn

			if linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any = from__13; if linked_2275 == nil { got__14 = ifn_2276.Invoke_O__O(arg_2277) } else { got__14 = linked_2275.(*A_arbace_repr_go_print_sha256_A).Invoke_O_O__O(root_2274, arg_2277) }
			var tmp14 any; var and__1927000168__auto____15 any = h__12; if jrt.J2g_Truth(and__1927000168__auto____15) { var root_2291 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2293 lang.IFn; if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any = got__14; var arg_2295 any; var root_2287 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2288 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2287, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2289 lang.IFn; if linked_2288 == nil { ifn_2289 = lang.IFn_Cast(root_2287) } else { ifn_2289 = nil }; var arg_2290 any = h__12; if linked_2288 == nil { arg_2295 = ifn_2289.Invoke_O__O(arg_2290) } else { arg_2295 = linked_2288.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2287, arg_2290) }; if linked_2292 == nil { tmp14 = ifn_2293.Invoke_O_O__O(arg_2294, arg_2295) } else { tmp14 = linked_2292.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2291, arg_2294, arg_2295) } } else { tmp14 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp14) { var tmp15 any; var root_2296 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2298 lang.IFn
				if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil, Lit_57, nil, Lit_58, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__11, nil, got__14, nil, h__12)).Ref(); var arg_2300 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_47, f__11)); if linked_2297 == nil { tmp15 = ifn_2298.Invoke_O_O__O(arg_2299, arg_2300) } else { tmp15 = linked_2297.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2296, arg_2299, arg_2300) }
//line :380:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp15)))
			}
			var root_2282 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2284 lang.IFn; if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = from__13; var arg_2286 any; var tmp16 *jrt.File = jrt.File_Cast(out__2); var tmp17 any; var root_2278 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = f__11; if linked_2279 == nil { tmp17 = ifn_2280.Invoke_O__O(arg_2281) } else { tmp17 = linked_2279.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2278, arg_2281) }; arg_2286 = jrt.File_New_File_String(tmp16, jrt.String_Cast(tmp17)); if linked_2283 == nil { ifn_2284.Invoke_O_O__O(arg_2285, arg_2286) } else { linked_2283.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2282, arg_2285, arg_2286) }
//line :377:1
			seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, i_1344000209__9 = seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000209__9); continue L2 } else { var temp__1927000414__auto____10_2 any; var root_2220 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = seq_1344000206__6; if linked_2221 == nil { temp__1927000414__auto____10_2 = ifn_2222.Invoke_O__O(arg_2223) } else { temp__1927000414__auto____10_2 = linked_2221.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2220, arg_2223) }; if jrt.J2g_Truth(temp__1927000414__auto____10_2) { var seq_1344000206__11 any = temp__1927000414__auto____10_2; var tmp18 any; var root_2224 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = seq_1344000206__11; if linked_2225 == nil { tmp18 = ifn_2226.Invoke_O__O(arg_2227) } else { tmp18 = linked_2225.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2224, arg_2227) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____12_2 any; var root_2228 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2230 lang.IFn; if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any = seq_1344000206__11; if linked_2229 == nil { c__1927000678__auto____12_2 = ifn_2230.Invoke_O__O(arg_2231) } else { c__1927000678__auto____12_2 = linked_2229.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2228, arg_2231) }; var tmp19 any; var root_2301 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = seq_1344000206__11; if linked_2302 == nil { tmp19 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp19 = linked_2302.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2301, arg_2304) }; seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, i_1344000209__9 = tmp19, c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1344000213__12 any; var root_2232 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2232, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2234 lang.IFn; if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any = seq_1344000206__11; if linked_2233 == nil { vec__1344000213__12 = ifn_2234.Invoke_O__O(arg_2235) } else { vec__1344000213__12 = linked_2233.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2232, arg_2235) }; var f__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000213__12, lang.RT_IntCast_J__I_NoInit(0), nil); var h__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000213__12, lang.RT_IntCast_J__I_NoInit(1), nil); var from__15 any; var tmp20 *jrt.File = jrt.File_Cast(src__1); var tmp21 any; var root_2305 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2305, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2307 lang.IFn
				if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = f__13; if linked_2306 == nil { tmp21 = ifn_2307.Invoke_O__O(arg_2308) } else { tmp21 = linked_2306.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2305, arg_2308) }
//line :377:1
				from__15 = jrt.File_New_File_String(tmp20, jrt.String_Cast(tmp21)); var got__16 any; var root_2309 any = A_arbace_repr_go_print_A_const_188.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, A_arbace_repr_go_print_sha256_A_fn_class); var ifn_2311 lang.IFn

				if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any = from__15; if linked_2310 == nil { got__16 = ifn_2311.Invoke_O__O(arg_2312) } else { got__16 = linked_2310.(*A_arbace_repr_go_print_sha256_A).Invoke_O_O__O(root_2309, arg_2312) }
				var tmp22 any; var and__1927000168__auto____17 any = h__14; if jrt.J2g_Truth(and__1927000168__auto____17) { var root_2326 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = got__16; var arg_2330 any; var root_2322 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2324 lang.IFn; if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any = h__14; if linked_2323 == nil { arg_2330 = ifn_2324.Invoke_O__O(arg_2325) } else { arg_2330 = linked_2323.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2322, arg_2325) }; if linked_2327 == nil { tmp22 = ifn_2328.Invoke_O_O__O(arg_2329, arg_2330) } else { tmp22 = linked_2327.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2326, arg_2329, arg_2330) } } else { tmp22 = and__1927000168__auto____17 }; if jrt.J2g_Truth(tmp22) { var tmp23 any; var root_2331 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2333 lang.IFn
					if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil, Lit_57, nil, Lit_58, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__13, nil, got__16, nil, h__14)).Ref(); var arg_2335 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_47, f__13)); if linked_2332 == nil { tmp23 = ifn_2333.Invoke_O_O__O(arg_2334, arg_2335) } else { tmp23 = linked_2332.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2331, arg_2334, arg_2335) }
//line :380:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp23)))
				}
				var root_2317 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2317, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2319 lang.IFn; if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var arg_2320 any = from__15; var arg_2321 any; var tmp24 *jrt.File = jrt.File_Cast(out__2); var tmp25 any; var root_2313 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2313, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = f__13; if linked_2314 == nil { tmp25 = ifn_2315.Invoke_O__O(arg_2316) } else { tmp25 = linked_2314.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2313, arg_2316) }; arg_2321 = jrt.File_New_File_String(tmp24, jrt.String_Cast(tmp25)); if linked_2318 == nil { ifn_2319.Invoke_O_O__O(arg_2320, arg_2321) } else { linked_2318.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2317, arg_2320, arg_2321) }
//line :377:1
				var tmp26 any; var root_2336 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2338 lang.IFn; if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any = seq_1344000206__11; if linked_2337 == nil { tmp26 = ifn_2338.Invoke_O__O(arg_2339) } else { tmp26 = linked_2337.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2336, arg_2339) }; seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, i_1344000209__9 = tmp26, nil, 0, 0; continue L2 } } }
//line :370:1
		break L2 }; var tmp27 lang.IFn =












	lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()); var tmp28 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_24); var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60); var tmp30 any; var root_2186 any = A_arbace_repr_go_print_A_const_183.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2188 lang.IFn; if

	linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = Lit_61; var arg_2190 any; var iter__1927001039__auto____9 any; var tmp31 any = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_New_O_O(src__1, out__2); var tmp32 *jrt.Class; var fncls__2185 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_fn_class; if fncls__2185 == nil { var fncls__2185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_fn_class = fncls__2185d; tmp32 = fncls__2185d } else { tmp32 = fncls__2185 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); arg_2190 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(written__3); if linked_2187 == nil { tmp30 = ifn_2188.Invoke_O_O__O(arg_2189, arg_2190) } else { tmp30 = linked_2187.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2186, arg_2189, arg_2190) }; return /*line :383:1*/ tmp27.Invoke_O_O__O(tmp28, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, nil, tmp30, nil)).Ref()) }

func A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A{}; t.Ctor_O_O(p0, p1); return t }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A) Ctor_O_O(c__src, c__out any) { t.F_src = c__src; t.F_out = c__out }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A) Invoke_O_O__O(self, s__1344000217__1 any) any { var tmp1 any = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_New_O_O_O_O(self, t.F_src, t.F_out, s__1344000217__1); var tmp2 *jrt.Class; var fncls__2184 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_fn_class; if fncls__2184 == nil { var fncls__2184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_fn_class = fncls__2184d; tmp2 = fncls__2184d } else { tmp2 = fncls__2184 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :385:1
func A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A) Ctor_O_O_O_O(c__iter__1344000216, c__src, c__out, c__s__1344000217 any) { t.F_iter__1344000216 = c__iter__1344000216; t.F_src = c__src; t.F_out = c__out; t.F_s__1344000217 = c__s__1344000217 }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A) Invoke_O__O(self any) any { { var s__1344000217__1 any; var t_ any = t.F_s__1344000217; t.F_s__1344000217 = nil; s__1344000217__1 = t_; for { var temp__1927000414__auto____2 any; var root_2095 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = s__1344000217__1; if linked_2096 == nil { temp__1927000414__auto____2 = ifn_2097.Invoke_O__O(arg_2098) } else { temp__1927000414__auto____2 = linked_2096.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2095, arg_2098) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1344000217__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2099 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = s__1344000217__3; if linked_2100 == nil { tmp1 = ifn_2101.Invoke_O__O(arg_2102) } else { tmp1 = linked_2100.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2099, arg_2102) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2103 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = s__1344000217__3; if linked_2104 == nil { c__1927001037__auto____4 = ifn_2105.Invoke_O__O(arg_2106) } else { c__1927001037__auto____4 = linked_2104.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2103, arg_2106) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1344000219__6 any; var root_2107 any = A_arbace_repr_go_print_A_const_25.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2109 lang.IFn; if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2108 == nil { b__1344000219__6 = ifn_2109.Invoke_O__O(arg_2110) } else { b__1344000219__6 = linked_2108.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2107, arg_2110) }; var tmp2 any = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_New_O_O_O_I_O(t.F_src, b__1344000219__6, t.F_out, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2132 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_fn_class; if fncls__2132 == nil { var fncls__2132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_fn_class = fncls__2132d; tmp3 = fncls__2132d } else { tmp3 = fncls__2132 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2141 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_2142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2141, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2143 lang.IFn; if linked_2142 == nil { ifn_2143 = lang.IFn_Cast(root_2141) } else { ifn_2143 = nil }; var arg_2144 any; var root_2133 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_2134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2133, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2135 lang.IFn; if linked_2134 == nil { ifn_2135 = lang.IFn_Cast(root_2133) } else { ifn_2135 = nil }; var arg_2136 any = b__1344000219__6; if linked_2134 == nil { arg_2144 = ifn_2135.Invoke_O__O(arg_2136) } else { arg_2144 = linked_2134.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2133, arg_2136) }; var arg_2145 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1344000216); var tmp5 any; var root_2137 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2137, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2139 lang.IFn; if linked_2138 == nil { ifn_2139 = lang.IFn_Cast(root_2137) } else { ifn_2139 = nil }; var arg_2140 any = s__1344000217__3; if linked_2138 == nil { tmp5 = ifn_2139.Invoke_O__O(arg_2140) } else { tmp5 = linked_2138.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2137, arg_2140) }; arg_2145 = tmp4.Invoke_O__O(tmp5); if linked_2142 == nil { return ifn_2143.Invoke_O_O__O(arg_2144, arg_2145) } else { return linked_2142.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2141, arg_2144, arg_2145) } } else { var root_2150 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any; var root_2146 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = b__1344000219__6; if linked_2147 == nil { arg_2153 = ifn_2148.Invoke_O__O(arg_2149) } else { arg_2153 = linked_2147.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2146, arg_2149) }; var arg_2154 any; if linked_2151 == nil { return ifn_2152.Invoke_O_O__O(arg_2153, arg_2154) } else { return linked_2151.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2150, arg_2153, arg_2154) } } } else { var n__4 any; var root_2155 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any = s__1344000217__3; if linked_2156 == nil { n__4 = ifn_2157.Invoke_O__O(arg_2158) } else { n__4 = linked_2156.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2155, arg_2158) }; var root_2179 any = A_arbace_repr_go_print_A_const_36.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66, nil); var tmp7 any; var root_2163 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2165 lang.IFn
															if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any; var tmp8 *jrt.File = jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(); var tmp9 any; var root_2159 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = n__4; if linked_2160 == nil { tmp9 = ifn_2161.Invoke_O__O(arg_2162) } else { tmp9 = linked_2160.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2159, arg_2162) }; arg_2166 = jrt.File_New_File_String(tmp8, jrt.String_Cast(tmp9)).GetPath__String().Ref(); if linked_2164 == nil { tmp7 = ifn_2165.Invoke_O__O(arg_2166) } else { tmp7 = linked_2164.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2163, arg_2166) }; var tmp10 any = tmp7; var tmp11 any; var root_2171 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2173 lang.IFn
															if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any; var tmp12 *jrt.File = jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(); var tmp13 any; var root_2167 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = n__4; if linked_2168 == nil { tmp13 = ifn_2169.Invoke_O__O(arg_2170) } else { tmp13 = linked_2168.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2167, arg_2170) }; arg_2174 = jrt.File_New_File_String(tmp12, jrt.String_Cast(tmp13)).GetPath__String().Ref(); if linked_2172 == nil { tmp11 = ifn_2173.Invoke_O__O(arg_2174) } else { tmp11 = linked_2172.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2171, arg_2174) }
//line :386:1
	arg_2182 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp11)).Ref()
//line :385:1
	var arg_2183 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1344000216); var tmp15 any; var root_2175 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = s__1344000217__3; if linked_2176 == nil { tmp15 = ifn_2177.Invoke_O__O(arg_2178) } else { tmp15 = linked_2176.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2175, arg_2178) }; arg_2183 = tmp14.Invoke_O__O(tmp15); if linked_2180 == nil { return ifn_2181.Invoke_O_O__O(arg_2182, arg_2183) } else { return linked_2180.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2179, arg_2182, arg_2183) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :385:1
func A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A) Ctor_O_O_O_I_O(c__src, c__b__1344000219, c__out any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_src = c__src; t.F_b__1344000219 = c__b__1344000219; t.F_out = c__out; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A) Invoke_O__O(self any) any { { var i__1344000218__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1344000218__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1344000218__1)); var root_2127 any = A_arbace_repr_go_print_A_const_31.GetRawRoot__O(); var linked_2128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2127, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2129 lang.IFn; if linked_2128 == nil { ifn_2129 = lang.IFn_Cast(root_2127) } else { ifn_2129 = nil }; var arg_2130 any = t.F_b__1344000219; var arg_2131 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66, nil); var tmp3 any; var root_2115 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2117 lang.IFn
																	if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any; var tmp4 *jrt.File = jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(); var tmp5 any; var root_2111 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = n__2; if linked_2112 == nil { tmp5 = ifn_2113.Invoke_O__O(arg_2114) } else { tmp5 = linked_2112.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2111, arg_2114) }; arg_2118 = jrt.File_New_File_String(tmp4, jrt.String_Cast(tmp5)).GetPath__String().Ref(); if linked_2116 == nil { tmp3 = ifn_2117.Invoke_O__O(arg_2118) } else { tmp3 = linked_2116.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2115, arg_2118) }; var tmp6 any = tmp3; var tmp7 any; var root_2123 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2125 lang.IFn
																	if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any; var tmp8 *jrt.File = jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(); var tmp9 any; var root_2119 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2121 lang.IFn; if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any = n__2; if linked_2120 == nil { tmp9 = ifn_2121.Invoke_O__O(arg_2122) } else { tmp9 = linked_2120.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2119, arg_2122) }; arg_2126 = jrt.File_New_File_String(tmp8, jrt.String_Cast(tmp9)).GetPath__String().Ref(); if linked_2124 == nil { tmp7 = ifn_2125.Invoke_O__O(arg_2126) } else { tmp7 = linked_2124.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2123, arg_2126) }
//line :386:1
	arg_2131 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref()
//line :385:1
	if linked_2128 == nil { ifn_2129.Invoke_O_O__O(arg_2130, arg_2131) } else { linked_2128.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2127, arg_2130, arg_2131) }; i__1344000218__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000218__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_print_build_env_A_New() *A_arbace_repr_go_print_build_env_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_build_env_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_repr_go_print_build_env_A) Ctor() {}
//line :390:1
func (t *A_arbace_repr_go_print_build_env_A) Invoke_O_O_O__O(self, config__0, goroot__1 any) any { var G__1344000227__3_ any; var tmp1 *jrt.String; if



	jrt.J2g_Truth(A_arbace_repr_go_print_A_const_189.Invoke_O__O(config__0)) { tmp1 = Lit_35 } else { tmp1 = Lit_36 }; G__1344000227__3_ = /*line :390:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_27, goroot__1, Lit_28, Lit_29, Lit_30, Lit_31, Lit_32, Lit_33, Lit_34, tmp1.Ref())); var G__1344000227__4_ any; if


	jrt.J2g_Truth(A_arbace_repr_go_print_A_const_190.Invoke_O__O(config__0)) {

		var root_2340 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2341 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2340, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2342 lang.IFn; if linked_2341 == nil { ifn_2342 = lang.IFn_Cast(root_2340) } else { ifn_2342 = nil }; var arg_2343 any = G__1344000227__3_; var arg_2344 any = Lit_37; var arg_2345 any = A_arbace_repr_go_print_A_const_190.Invoke_O__O(config__0); if linked_2341 == nil { G__1344000227__4_ = ifn_2342.Invoke_O_O_O__O(arg_2343, arg_2344, arg_2345) } else { G__1344000227__4_ = linked_2341.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2340, arg_2343, arg_2344, arg_2345) } } else {
//line :393:1
			G__1344000227__4_ = G__1344000227__3_ }; var G__1344000227__5_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_191.Invoke_O__O(config__0)) {


				var root_2346 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2346, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2348 lang.IFn; if linked_2347 == nil { ifn_2348 = lang.IFn_Cast(root_2346) } else { ifn_2348 = nil }; var arg_2349 any = G__1344000227__4_; var arg_2350 any = Lit_38; var arg_2351 any = A_arbace_repr_go_print_A_const_191.Invoke_O__O(config__0); if linked_2347 == nil { G__1344000227__5_ = ifn_2348.Invoke_O_O_O__O(arg_2349, arg_2350, arg_2351) } else { G__1344000227__5_ = linked_2347.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2346, arg_2349, arg_2350, arg_2351) } } else {
//line :393:1
					G__1344000227__5_ = G__1344000227__4_ }; var G__1344000227__6_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_192.Invoke_O__O(config__0)) {



						var root_2352 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = G__1344000227__5_; var arg_2356 any = Lit_39; var arg_2357 any = A_arbace_repr_go_print_A_const_192.Invoke_O__O(config__0); if linked_2353 == nil { G__1344000227__6_ = ifn_2354.Invoke_O_O_O__O(arg_2355, arg_2356, arg_2357) } else { G__1344000227__6_ = linked_2353.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2352, arg_2355, arg_2356, arg_2357) } } else {
//line :393:1
							G__1344000227__6_ = G__1344000227__5_ }; var G__1344000227__7_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_193.Invoke_O__O(config__0)) {




								var root_2358 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2358, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2360 lang.IFn; if linked_2359 == nil { ifn_2360 = lang.IFn_Cast(root_2358) } else { ifn_2360 = nil }; var arg_2361 any = G__1344000227__6_; var arg_2362 any = Lit_40; var arg_2363 any = A_arbace_repr_go_print_A_const_193.Invoke_O__O(config__0); if linked_2359 == nil { G__1344000227__7_ = ifn_2360.Invoke_O_O_O__O(arg_2361, arg_2362, arg_2363) } else { G__1344000227__7_ = linked_2359.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2358, arg_2361, arg_2362, arg_2363) } } else {
//line :393:1
									G__1344000227__7_ = G__1344000227__6_ }; var tmp2 any; var root_2364 any = A_arbace_repr_go_print_A_const_194.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2364, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2366 lang.IFn; if





	linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = A_arbace_repr_go_print_A_const_195.Invoke_O__O(config__0); if linked_2365 == nil { tmp2 = ifn_2366.Invoke_O__O(arg_2367) } else { tmp2 = linked_2365.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2364, arg_2367) }; if /*line :393:1*/ jrt.J2g_Truth(tmp2) {





		var root_2368 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = G__1344000227__7_; var arg_2372 any = Lit_41; var arg_2373 any = A_arbace_repr_go_print_A_const_195.Invoke_O__O(config__0); if linked_2369 == nil { return ifn_2370.Invoke_O_O_O__O(arg_2371, arg_2372, arg_2373) } else { return linked_2369.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2368, arg_2371, arg_2372, arg_2373) } } else {
//line :393:1
			return G__1344000227__7_ } }







func A_arbace_repr_go_print_run_A_New() *A_arbace_repr_go_print_run_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_run_A{}; t.Ctor(); return t }
//line :401:1
func (t *A_arbace_repr_go_print_run_A) Ctor() {}
//line :401:1
func (t *A_arbace_repr_go_print_run_A) Invoke_O_O_O_O__O(self, cmd__0, dir__1, env__2 any) any { var pb__4 any; var tmp1 any; var root_2374 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2374, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2376 lang.IFn; if
												linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var arg_2378 any = cmd__0; if linked_2375 == nil { tmp1 = ifn_2376.Invoke_O_O__O(arg_2377, arg_2378) } else { tmp1 = linked_2375.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2374, arg_2377, arg_2378) }; pb__4 = /*line :401:1*/jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp1));

	jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__5 any = /*line :401:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Environment__Map(); var seq_1344000229__6 any; var root_2383 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2385 lang.IFn; if



	linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any = env__2; if linked_2384 == nil { seq_1344000229__6 = ifn_2385.Invoke_O__O(arg_2386) } else { seq_1344000229__6 = linked_2384.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2383, arg_2386) }; var chunk_1344000230__7 any; var count_1344000231__8 int64 = 0; var i_1344000232__9 int64 = 0; L1:
//line :401:1
	for {



		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000232__9, count_1344000231__8) { var vec__1344000233__10 any = lang.Indexed_Cast(chunk_1344000230__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000232__9)); var k__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000233__10, lang.RT_IntCast_J__I_NoInit(0), nil); var v__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000233__10, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__11, v__12); seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, i_1344000232__9 = seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000232__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_2387 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = seq_1344000229__6; if linked_2388 == nil { temp__1927000414__auto____10 = ifn_2389.Invoke_O__O(arg_2390) } else { temp__1927000414__auto____10 = linked_2388.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2387, arg_2390) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1344000229__11 any = temp__1927000414__auto____10; var tmp2 any; var root_2391 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = seq_1344000229__11; if linked_2392 == nil { tmp2 = ifn_2393.Invoke_O__O(arg_2394) } else { tmp2 = linked_2392.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2391, arg_2394) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____12 any; var root_2395 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2395, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2397 lang.IFn; if linked_2396 == nil { ifn_2397 = lang.IFn_Cast(root_2395) } else { ifn_2397 = nil }; var arg_2398 any = seq_1344000229__11; if linked_2396 == nil { c__1927000678__auto____12 = ifn_2397.Invoke_O__O(arg_2398) } else { c__1927000678__auto____12 = linked_2396.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2395, arg_2398) }; var tmp3 any; var root_2403 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = seq_1344000229__11; if linked_2404 == nil { tmp3 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp3 = linked_2404.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2403, arg_2406) }; seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, i_1344000232__9 = tmp3, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1344000236__12 any; var root_2399 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = seq_1344000229__11; if linked_2400 == nil { vec__1344000236__12 = ifn_2401.Invoke_O__O(arg_2402) } else { vec__1344000236__12 = linked_2400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2399, arg_2402) }; var k__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000236__12, lang.RT_IntCast_J__I_NoInit(0), nil); var v__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000236__12, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__13, v__14); var tmp4 any; var root_2407 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = seq_1344000229__11; if linked_2408 == nil { tmp4 = ifn_2409.Invoke_O__O(arg_2410) } else { tmp4 = linked_2408.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2407, arg_2410) }; seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, i_1344000232__9 = tmp4, nil, 0, 0; continue L1 } } }
//line :401:1
		break L1 };




	jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()); var p__5 any = /*line :401:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Start__Process(); var out__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_196.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(p__5).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Process_Cast(p__5).WaitFor__I()).Ref(), out__6) }









func A_arbace_repr_go_print_build_A_New() *A_arbace_repr_go_print_build_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_build_A{}; t.Ctor(); return t }
//line :411:1
func (t *A_arbace_repr_go_print_build_A) Ctor() {}
//line :411:1
func (t *A_arbace_repr_go_print_build_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, goroot__3 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_197; var config__5 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_44.Invoke_O__O(pkg__0)); var tags__6 any = A_arbace_repr_go_print_A_const_198.Invoke_O__O(config__5); var cmd__7 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_37.GetRawRoot__O()); var tmp3 any = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, goroot__3, nil)).Ref(), Lit_21, Lit_22, Lit_23, jrt.File_New_File_String(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File(), Lit_24).GetPath__String().Ref()); var tmp4 lang.IPersistentVector; var tmp5 any; var root_2411 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2413 lang.IFn; if






	linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = tags__6; if linked_2412 == nil { tmp5 = ifn_2413.Invoke_O__O(arg_2414) } else { tmp5 = linked_2412.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2411, arg_2414) }; if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_2415 any = A_arbace_repr_go_print_A_const_183.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = Lit_26; var arg_2419 any = tags__6; if linked_2416 == nil { tmp6 = ifn_2417.Invoke_O_O__O(arg_2418, arg_2419) } else { tmp6 = linked_2416.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2415, arg_2418, arg_2419) }; tmp4 = lang.Tuple_Create_O_O__IPersistentVector(Lit_25, tmp6) } else { tmp4 = nil }; cmd__7 = /*line :416:1*/tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_repr_go_print_A_const_199); var root_2431 any =



	A_arbace_repr_go_print_A_const_200.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, A_arbace_repr_go_print_run_A_fn_class); var ifn_2433 lang.IFn; if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = cmd__7; var arg_2435 any = src__1; var arg_2436 any; var root_2426 any = A_arbace_repr_go_print_A_const_201.GetRawRoot__O(); var linked_2427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2426, A_arbace_repr_go_print_build_env_A_fn_class); var ifn_2428 lang.IFn; if linked_2427 == nil { ifn_2428 = lang.IFn_Cast(root_2426) } else { ifn_2428 = nil }; var arg_2429 any = config__5; var arg_2430 any = goroot__3; if linked_2427 == nil { arg_2436 = ifn_2428.Invoke_O_O__O(arg_2429, arg_2430) } else { arg_2436 = linked_2427.(*A_arbace_repr_go_print_build_env_A).Invoke_O_O_O__O(root_2426, arg_2429, arg_2430) }; if linked_2432 == nil { return ifn_2433.Invoke_O_O_O__O(arg_2434, arg_2435, arg_2436) } else { return linked_2432.(*A_arbace_repr_go_print_run_A).Invoke_O_O_O_O__O(root_2431, arg_2434, arg_2435, arg_2436) } }

func A_arbace_repr_go_print_print_package_A_New() *A_arbace_repr_go_print_print_package_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_package_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_repr_go_print_print_package_A) Ctor() {}
//line :422:1
func (t *A_arbace_repr_go_print_print_package_A) Invoke_O_O_O_O__O(self, path__0, out_dir__1, opts__2 any) any { var pkg__4 any; var root_2437 any = A_arbace_repr_go_print_A_const_75.GetRawRoot__O(); var linked_2438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2437, A_arbace_repr_go_print_collect_A_fn_class); var ifn_2439 lang.IFn; if


	linked_2438 == nil { ifn_2439 = lang.IFn_Cast(root_2437) } else { ifn_2439 = nil }; var arg_2440 any = path__0; if linked_2438 == nil { pkg__4 = ifn_2439.Invoke_O__O(arg_2440) } else { pkg__4 = linked_2438.(*A_arbace_repr_go_print_collect_A).Invoke_O_O__O(root_2437, arg_2440) }; var out__5 any; var tmp1 any; var root_2441 any = /*line :422:1*/A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2443 lang.IFn; if



	linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = out_dir__1; if linked_2442 == nil { tmp1 = ifn_2443.Invoke_O__O(arg_2444) } else { tmp1 = linked_2442.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2441, arg_2444) }; out__5 = /*line :422:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); var layout__6 any = A_arbace_repr_go_print_A_const_158.Invoke_O__O(opts__2); var files__7 any; var root_2451 any = A_arbace_repr_go_print_A_const_202.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, A_arbace_repr_go_print_print_forms_A_fn_class); var ifn_2453 lang.IFn; if





	linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = pkg__4; var arg_2455 any; var root_2445 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = opts__2; var arg_2449 any = A_arbace_repr_go_print_A_const_158; var arg_2450 any; var or__1927000174__auto____7 any = layout__6; if jrt.J2g_Truth(or__1927000174__auto____7) { arg_2450 = or__1927000174__auto____7 } else { var tmp2 any = A_arbace_repr_go_print_A_const_143; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_203; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3.Invoke_O__O(A_arbace_repr_go_print_A_const_44.Invoke_O__O(pkg__4))) { arg_2450 = A_arbace_repr_go_print_A_const_143 } else { arg_2450 = nil } }; if linked_2446 == nil { arg_2455 = ifn_2447.Invoke_O_O_O__O(arg_2448, arg_2449, arg_2450) } else { arg_2455 = linked_2446.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2445, arg_2448, arg_2449, arg_2450) }; if linked_2452 == nil { files__7 = ifn_2453.Invoke_O_O__O(arg_2454, arg_2455) } else { files__7 = linked_2452.(*A_arbace_repr_go_print_print_forms_A).Invoke_O_O_O__O(root_2451, arg_2454, arg_2455) };
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(out__5)).Mkdirs__Z()); var seq_1344000241__8 any; var root_2460 any = /*line :422:1*/A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2460, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2462 lang.IFn; if







	linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = files__7; if linked_2461 == nil { seq_1344000241__8 = ifn_2462.Invoke_O__O(arg_2463) } else { seq_1344000241__8 = linked_2461.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2460, arg_2463) }; var chunk_1344000242__9 any; var count_1344000243__10 int64 = 0; var i_1344000244__11 int64 = 0; L1:
//line :422:1
	for {







		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000244__11, count_1344000243__10) { var vec__1344000245__12 any = lang.Indexed_Cast(chunk_1344000242__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000244__11)); var n__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000245__12, lang.RT_IntCast_J__I_NoInit(0), nil); var text__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000245__12, lang.RT_IntCast_J__I_NoInit(1), nil)
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__13)), text__14)
//line :430:1
			seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, i_1344000244__11 = seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000244__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_2464 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2466 lang.IFn; if linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any = seq_1344000241__8; if linked_2465 == nil { temp__1927000414__auto____12 = ifn_2466.Invoke_O__O(arg_2467) } else { temp__1927000414__auto____12 = linked_2465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2464, arg_2467) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1344000241__13 any = temp__1927000414__auto____12; var tmp4 any; var root_2468 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2470 lang.IFn; if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = seq_1344000241__13; if linked_2469 == nil { tmp4 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp4 = linked_2469.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2468, arg_2471) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_2472 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = seq_1344000241__13; if linked_2473 == nil { c__1927000678__auto____14 = ifn_2474.Invoke_O__O(arg_2475) } else { c__1927000678__auto____14 = linked_2473.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2472, arg_2475) }; var tmp5 any; var root_2485 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = seq_1344000241__13; if linked_2486 == nil { tmp5 = ifn_2487.Invoke_O__O(arg_2488) } else { tmp5 = linked_2486.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2485, arg_2488) }; seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, i_1344000244__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1344000248__14 any; var root_2476 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = seq_1344000241__13; if linked_2477 == nil { vec__1344000248__14 = ifn_2478.Invoke_O__O(arg_2479) } else { vec__1344000248__14 = linked_2477.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2476, arg_2479) }; var n__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000248__14, lang.RT_IntCast_J__I_NoInit(0), nil); var text__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000248__14, lang.RT_IntCast_J__I_NoInit(1), nil)
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__15)), text__16)
//line :430:1
				var tmp6 any; var root_2494 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2496 lang.IFn; if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = seq_1344000241__13; if linked_2495 == nil { tmp6 = ifn_2496.Invoke_O__O(arg_2497) } else { tmp6 = linked_2495.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2494, arg_2497) }; seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, i_1344000244__11 = tmp6, nil, 0, 0; continue L1 } } }
//line :422:1
		break L1 }; var tmp7 any = A_arbace_repr_go_print_A_const_44; var tmp8 any = A_arbace_repr_go_print_A_const_46; var tmp9 any; var root_2456 any = A_arbace_repr_go_print_A_const_204.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2456, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2458 lang.IFn; if









	linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any = files__7; if linked_2457 == nil { tmp9 = ifn_2458.Invoke_O__O(arg_2459) } else { tmp9 = linked_2457.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2456, arg_2459) }; return /*line :422:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, pkg__4, tmp8, tmp9)) }











func A_arbace_repr_go_print_gofmt_file_A_New() *A_arbace_repr_go_print_gofmt_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_gofmt_file_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_repr_go_print_gofmt_file_A) Ctor() {}
//line :434:1
func (t *A_arbace_repr_go_print_gofmt_file_A) Invoke_O_O_O__O(self, goroot__0, f__1 any) any { var vec__1344000252__3 any; var root_2498 any = A_arbace_repr_go_print_A_const_200.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, A_arbace_repr_go_print_run_A_fn_class); var ifn_2500 lang.IFn; if
												linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_82), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_83, jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetPath__String().Ref()); var arg_2502 any = jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetParentFile__File().Ref(); var arg_2503 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2499 == nil { vec__1344000252__3 = ifn_2500.Invoke_O_O_O__O(arg_2501, arg_2502, arg_2503) } else { vec__1344000252__3 = linked_2499.(*A_arbace_repr_go_print_run_A).Invoke_O_O_O_O__O(root_2498, arg_2501, arg_2502, arg_2503) }; var status__4 any = /*line :434:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1344000252__3, lang.RT_IntCast_J__I_NoInit(0), nil); var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000252__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_2504 any = status__4; if

	jrt.Long_InstanceOf(na_2504) { var n0_2505 int64 = jrt.NN(jrt.Long_Cast(na_2504)).LongValue__J(); tmp1 = n0_2505 == 0 } else { if jrt.Double_InstanceOf(na_2504) { var n0_2505_2 float64 = jrt.NN(jrt.Double_Cast(na_2504)).DoubleValue__D(); tmp1 = n0_2505_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_2504) } }; if tmp1 { return nil } else { var tmp2 any; var root_2506 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2508 lang.IFn
		if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1, nil, out__5)).Ref(); var arg_2510 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_47, f__1)); if linked_2507 == nil { tmp2 = ifn_2508.Invoke_O_O__O(arg_2509, arg_2510) } else { tmp2 = linked_2507.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2506, arg_2509, arg_2510) }
//line :436:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) } }


func A_arbace_repr_go_print__main_A_New() *A_arbace_repr_go_print__main_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print__main_A{}; t.Ctor(); return t }
//line :439:1
func (t *A_arbace_repr_go_print__main_A) Ctor() {}
//line :439:1
func (t *A_arbace_repr_go_print__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :439:1
	var as__3 any = argv__0; var opts__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var G__1344000256__5_ any; var root_2511 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2511, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2513 lang.IFn


		if linked_2512 == nil { ifn_2513 = lang.IFn_Cast(root_2511) } else { ifn_2513 = nil }; var arg_2514 any = as__3; if linked_2512 == nil { G__1344000256__5_ = ifn_2513.Invoke_O__O(arg_2514) } else { G__1344000256__5_ = linked_2512.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2511, arg_2514) }; switch lang.Util_Hash_O__I_NoInit(G__1344000256__5_) >> 7 & 15 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_3) {
			var tmp1 any; var root_2541 any = A_arbace_repr_go_print_A_const_107.GetRawRoot__O(); var linked_2542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2541, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2543 lang.IFn; if linked_2542 == nil { ifn_2543 = lang.IFn_Cast(root_2541) } else { ifn_2543 = nil }; var arg_2544 any = as__3; if linked_2542 == nil { tmp1 = ifn_2543.Invoke_O__O(arg_2544) } else { tmp1 = linked_2542.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2541, arg_2544) }; var tmp2 any = tmp1; var tmp3 any; var root_2553 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2553, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2555 lang.IFn; if linked_2554 == nil { ifn_2555 = lang.IFn_Cast(root_2553) } else { ifn_2555 = nil }; var arg_2556 any = opts__4; var arg_2557 any = A_arbace_repr_go_print_A_const_158; var arg_2558 any; var root_2549 any = A_arbace_repr_go_print_A_const_207.GetRawRoot__O(); var linked_2550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2549, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2551 lang.IFn; if linked_2550 == nil { ifn_2551 = lang.IFn_Cast(root_2549) } else { ifn_2551 = nil }; var arg_2552 any; var root_2545 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any = as__3; if linked_2546 == nil { arg_2552 = ifn_2547.Invoke_O__O(arg_2548) } else { arg_2552 = linked_2546.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2545, arg_2548) }; if linked_2550 == nil { arg_2558 = ifn_2551.Invoke_O__O(arg_2552) } else { arg_2558 = linked_2550.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2549, arg_2552) }; if linked_2554 == nil { tmp3 = ifn_2555.Invoke_O_O_O__O(arg_2556, arg_2557, arg_2558) } else { tmp3 = linked_2554.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2553, arg_2556, arg_2557, arg_2558) }; as__3, opts__4 = tmp2, tmp3; continue L1 }
//line :442:1
		case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_4) {


			var tmp4 any; var root_2559 any = A_arbace_repr_go_print_A_const_107.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = as__3; if linked_2560 == nil { tmp4 = ifn_2561.Invoke_O__O(arg_2562) } else { tmp4 = linked_2560.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2559, arg_2562) }; var tmp5 any = tmp4; var tmp6 any; var root_2567 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2567, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2569 lang.IFn; if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any = opts__4; var arg_2571 any = A_arbace_repr_go_print_A_const_50; var arg_2572 any; var root_2563 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any = as__3; if linked_2564 == nil { arg_2572 = ifn_2565.Invoke_O__O(arg_2566) } else { arg_2572 = linked_2564.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2563, arg_2566) }; if linked_2568 == nil { tmp6 = ifn_2569.Invoke_O_O_O__O(arg_2570, arg_2571, arg_2572) } else { tmp6 = linked_2568.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2567, arg_2570, arg_2571, arg_2572) }; as__3, opts__4 = tmp5, tmp6; continue L1 }
//line :442:1
		case 9: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_5) {



			var tmp7 any; var root_2573 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2573, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2575 lang.IFn; if linked_2574 == nil { ifn_2575 = lang.IFn_Cast(root_2573) } else { ifn_2575 = nil }; var arg_2576 any = as__3; if linked_2574 == nil { tmp7 = ifn_2575.Invoke_O__O(arg_2576) } else { tmp7 = linked_2574.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2573, arg_2576) }; var tmp8 any = tmp7; var tmp9 any; var root_2577 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2577, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2579 lang.IFn; if linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any = opts__4; var arg_2581 any = A_arbace_repr_go_print_A_const_164; var arg_2582 any = jrt.Boolean_TRUE.Ref(); if linked_2578 == nil { tmp9 = ifn_2579.Invoke_O_O_O__O(arg_2580, arg_2581, arg_2582) } else { tmp9 = linked_2578.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2577, arg_2580, arg_2581, arg_2582) }; as__3, opts__4 = tmp8, tmp9; continue L1 }
//line :442:1
		case 10: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_6) {




			var tmp10 any; var root_2583 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2583, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2585 lang.IFn; if linked_2584 == nil { ifn_2585 = lang.IFn_Cast(root_2583) } else { ifn_2585 = nil }; var arg_2586 any = as__3; if linked_2584 == nil { tmp10 = ifn_2585.Invoke_O__O(arg_2586) } else { tmp10 = linked_2584.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2583, arg_2586) }; var tmp11 any = tmp10; var tmp12 any; var root_2587 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2587, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2589 lang.IFn; if linked_2588 == nil { ifn_2589 = lang.IFn_Cast(root_2587) } else { ifn_2589 = nil }; var arg_2590 any = opts__4; var arg_2591 any = A_arbace_repr_go_print_A_const_162; var arg_2592 any = jrt.Boolean_TRUE.Ref(); if linked_2588 == nil { tmp12 = ifn_2589.Invoke_O_O_O__O(arg_2590, arg_2591, arg_2592) } else { tmp12 = linked_2588.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2587, arg_2590, arg_2591, arg_2592) }; as__3, opts__4 = tmp11, tmp12; continue L1 }
//line :442:1
		case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_7) {





			var tmp13 any; var root_2593 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2593, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2595 lang.IFn; if linked_2594 == nil { ifn_2595 = lang.IFn_Cast(root_2593) } else { ifn_2595 = nil }; var arg_2596 any = as__3; if linked_2594 == nil { tmp13 = ifn_2595.Invoke_O__O(arg_2596) } else { tmp13 = linked_2594.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2593, arg_2596) }; var tmp14 any = tmp13; var tmp15 any; var root_2597 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2597, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2599 lang.IFn; if linked_2598 == nil { ifn_2599 = lang.IFn_Cast(root_2597) } else { ifn_2599 = nil }; var arg_2600 any = opts__4; var arg_2601 any = A_arbace_repr_go_print_A_const_159; var arg_2602 any = jrt.Boolean_TRUE.Ref(); if linked_2598 == nil { tmp15 = ifn_2599.Invoke_O_O_O__O(arg_2600, arg_2601, arg_2602) } else { tmp15 = linked_2598.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2597, arg_2600, arg_2601, arg_2602) }; as__3, opts__4 = tmp14, tmp15; continue L1 }
//line :442:1
		case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_8) {

			var tmp16 any; var root_2603 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2605 lang.IFn; if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any = as__3; if linked_2604 == nil { tmp16 = ifn_2605.Invoke_O__O(arg_2606) } else { tmp16 = linked_2604.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2603, arg_2606) }; var tmp17 any = tmp16; var tmp18 any; var root_2607 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2607, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2609 lang.IFn; if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = opts__4; var arg_2611 any = A_arbace_repr_go_print_A_const_128; var arg_2612 any = jrt.Boolean_FALSE.Ref(); if linked_2608 == nil { tmp18 = ifn_2609.Invoke_O_O_O__O(arg_2610, arg_2611, arg_2612) } else { tmp18 = linked_2608.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2607, arg_2610, arg_2611, arg_2612) }; as__3, opts__4 = tmp17, tmp18; continue L1 }
//line :442:1
		default:}; var vec__1344000257__6 any = as__3; var forms__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000257__6, lang.RT_IntCast_J__I_NoInit(0), nil); var out__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000257__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp19 any
		var and__1927000168__auto____9 any = forms__7






		if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = out__8; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp19 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(as__3)))).Ref() } else { tmp19 = and__1927000168__auto____10 } } else { tmp19 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp19) { } else {
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O__O(Lit_9)
			jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :442:1
		var map__1344000260__9 any; var root_2516 any = A_arbace_repr_go_print_A_const_205.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, A_arbace_repr_go_print_print_package_A_fn_class); var ifn_2518 lang.IFn










		if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = forms__7; var arg_2520 any = out__8; var arg_2521 any = opts__4; if linked_2517 == nil { map__1344000260__9 = ifn_2518.Invoke_O_O_O__O(arg_2519, arg_2520, arg_2521) } else { map__1344000260__9 = linked_2517.(*A_arbace_repr_go_print_print_package_A).Invoke_O_O_O_O__O(root_2516, arg_2519, arg_2520, arg_2521) }
//line :442:1
		var map__1344000260__10 any










		if lang.ISeq_InstanceOf(map__1344000260__9) { var tmp20 any; var root_2522 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2522, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2524 lang.IFn; if linked_2523 == nil { ifn_2524 = lang.IFn_Cast(root_2522) } else { ifn_2524 = nil }; var arg_2525 any = map__1344000260__9; if linked_2523 == nil { tmp20 = ifn_2524.Invoke_O__O(arg_2525) } else { tmp20 = linked_2523.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2522, arg_2525) }; if jrt.J2g_Truth(tmp20) { var tmp21 any; var root_2526 any = A_arbace_repr_go_print_A_const_157.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2528 lang.IFn; if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any = map__1344000260__9; if linked_2527 == nil { tmp21 = ifn_2528.Invoke_O__O(arg_2529) } else { tmp21 = linked_2527.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2526, arg_2529) }; map__1344000260__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp21, jrt.Object_class.ArrayClass())).Ref() } else { var tmp22 any; var root_2530 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = map__1344000260__9; if linked_2531 == nil { tmp22 = ifn_2532.Invoke_O__O(arg_2533) } else { tmp22 = linked_2531.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2530, arg_2533) }; if jrt.J2g_Truth(tmp22) { var root_2534 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any = map__1344000260__9; if linked_2535 == nil { map__1344000260__10 = ifn_2536.Invoke_O__O(arg_2537) } else { map__1344000260__10 = linked_2535.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2534, arg_2537) } } else { map__1344000260__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000260__10 = map__1344000260__9 }
//line :442:1
		var package__11 any = lang.RT_Get_O_O__O_NoInit(map__1344000260__10, A_arbace_repr_go_print_A_const_44); var files__12 any = lang.RT_Get_O_O__O_NoInit(map__1344000260__10, A_arbace_repr_go_print_A_const_46); var outf__13 any = jrt.File_New_String(jrt.String_Cast(out__8)); var seq_1344000262__14 any; var root_2617 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2619 lang.IFn












		if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any = files__12; if linked_2618 == nil { seq_1344000262__14 = ifn_2619.Invoke_O__O(arg_2620) } else { seq_1344000262__14 = linked_2618.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2617, arg_2620) }
//line :442:1
		var chunk_1344000263__15 any; var count_1344000264__16 int64 = 0; var i_1344000265__17 int64 = 0; L3: for {












			if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000265__17, count_1344000264__16) { var f__18 any = lang.Indexed_Cast(chunk_1344000263__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000265__17)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__18)).Ref()); seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, i_1344000265__17 = seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000265__17); continue L3 } else { var temp__1927000414__auto____18 any; var root_2621 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = seq_1344000262__14; if linked_2622 == nil { temp__1927000414__auto____18 = ifn_2623.Invoke_O__O(arg_2624) } else { temp__1927000414__auto____18 = linked_2622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2621, arg_2624) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1344000262__19 any = temp__1927000414__auto____18; var tmp23 any; var root_2625 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = seq_1344000262__19; if linked_2626 == nil { tmp23 = ifn_2627.Invoke_O__O(arg_2628) } else { tmp23 = linked_2626.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2625, arg_2628) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____20 any; var root_2629 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = seq_1344000262__19; if linked_2630 == nil { c__1927000678__auto____20 = ifn_2631.Invoke_O__O(arg_2632) } else { c__1927000678__auto____20 = linked_2630.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2629, arg_2632) }; var tmp24 any; var root_2670 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = seq_1344000262__19; if linked_2671 == nil { tmp24 = ifn_2672.Invoke_O__O(arg_2673) } else { tmp24 = linked_2671.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2670, arg_2673) }; seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, i_1344000265__17 = tmp24, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var f__20 any; var root_2633 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = seq_1344000262__19; if linked_2634 == nil { f__20 = ifn_2635.Invoke_O__O(arg_2636) } else { f__20 = linked_2634.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2633, arg_2636) }; lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__20)).Ref()); var tmp25 any; var root_2678 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = seq_1344000262__19; if linked_2679 == nil { tmp25 = ifn_2680.Invoke_O__O(arg_2681) } else { tmp25 = linked_2679.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2678, arg_2681) }; seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, i_1344000265__17 = tmp25, nil, 0, 0; continue L3 } } }
//line :442:1
			break L3
		}












		if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_162.Invoke_O__O(opts__4)) { var seq_1344000266__14 any; var root_2637 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2639 lang.IFn
			if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any = files__12; if linked_2638 == nil { seq_1344000266__14 = ifn_2639.Invoke_O__O(arg_2640) } else { seq_1344000266__14 = linked_2638.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2637, arg_2640) }
//line :456:1
			var chunk_1344000267__15 any; var count_1344000268__16 int64 = 0; var i_1344000269__17 int64 = 0; L4: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000269__17, count_1344000268__16) { var f__18_2 any = lang.Indexed_Cast(chunk_1344000267__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000269__17)); var root_2682 any = A_arbace_repr_go_print_A_const_210.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, A_arbace_repr_go_print_gofmt_file_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any = goroot__2; var arg_2686 any = jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__18_2)); if linked_2683 == nil { ifn_2684.Invoke_O_O__O(arg_2685, arg_2686) } else { linked_2683.(*A_arbace_repr_go_print_gofmt_file_A).Invoke_O_O_O__O(root_2682, arg_2685, arg_2686) }; seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, i_1344000269__17 = seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000269__17); continue L4 } else { var temp__1927000414__auto____18_2 any; var root_2641 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2643 lang.IFn; if linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = seq_1344000266__14; if linked_2642 == nil { temp__1927000414__auto____18_2 = ifn_2643.Invoke_O__O(arg_2644) } else { temp__1927000414__auto____18_2 = linked_2642.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2641, arg_2644) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1344000266__19 any = temp__1927000414__auto____18_2; var tmp26 any; var root_2645 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2645, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2647 lang.IFn; if linked_2646 == nil { ifn_2647 = lang.IFn_Cast(root_2645) } else { ifn_2647 = nil }; var arg_2648 any = seq_1344000266__19; if linked_2646 == nil { tmp26 = ifn_2647.Invoke_O__O(arg_2648) } else { tmp26 = linked_2646.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2645, arg_2648) }; if jrt.J2g_Truth(tmp26) { var c__1927000678__auto____20_2 any; var root_2649 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2651 lang.IFn; if linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any = seq_1344000266__19; if linked_2650 == nil { c__1927000678__auto____20_2 = ifn_2651.Invoke_O__O(arg_2652) } else { c__1927000678__auto____20_2 = linked_2650.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2649, arg_2652) }; var tmp27 any; var root_2687 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = seq_1344000266__19; if linked_2688 == nil { tmp27 = ifn_2689.Invoke_O__O(arg_2690) } else { tmp27 = linked_2688.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2687, arg_2690) }; seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, i_1344000269__17 = tmp27, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var f__20_2 any; var root_2653 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = seq_1344000266__19; if linked_2654 == nil { f__20_2 = ifn_2655.Invoke_O__O(arg_2656) } else { f__20_2 = linked_2654.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2653, arg_2656) }; var root_2691 any = A_arbace_repr_go_print_A_const_210.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, A_arbace_repr_go_print_gofmt_file_A_fn_class); var ifn_2693 lang.IFn; if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = goroot__2; var arg_2695 any = jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__20_2)); if linked_2692 == nil { ifn_2693.Invoke_O_O__O(arg_2694, arg_2695) } else { linked_2692.(*A_arbace_repr_go_print_gofmt_file_A).Invoke_O_O_O__O(root_2691, arg_2694, arg_2695) }; var tmp28 any; var root_2696 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2696, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2698 lang.IFn; if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any = seq_1344000266__19; if linked_2697 == nil { tmp28 = ifn_2698.Invoke_O__O(arg_2699) } else { tmp28 = linked_2697.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2696, arg_2699) }; seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, i_1344000269__17 = tmp28, nil, 0, 0; continue L4 } } }
//line :456:1
				break L4 } }
//line :442:1
		var temp__1927000414__auto____14 any = A_arbace_repr_go_print_A_const_50.Invoke_O__O(opts__4)















		if jrt.J2g_Truth(temp__1927000414__auto____14) { var src__15 any = temp__1927000414__auto____14; var root_2700 any = A_arbace_repr_go_print_A_const_211.GetRawRoot__O(); var linked_2701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2700, A_arbace_repr_go_print_copy_files_A_fn_class); var ifn_2702 lang.IFn
			if linked_2701 == nil { ifn_2702 = lang.IFn_Cast(root_2700) } else { ifn_2702 = nil }; var arg_2703 any = package__11; var arg_2704 any = jrt.File_New_String(jrt.String_Cast(src__15)); var arg_2705 any = outf__13; var arg_2706 any = files__12; if linked_2701 == nil { ifn_2702.Invoke_O_O_O_O__O(arg_2703, arg_2704, arg_2705, arg_2706) } else { linked_2701.(*A_arbace_repr_go_print_copy_files_A).Invoke_O_O_O_O_O__O(root_2700, arg_2703, arg_2704, arg_2705, arg_2706) }
			if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_164.Invoke_O__O(opts__4)) { var vec__1344000270__16 any; var root_2657 any = A_arbace_repr_go_print_A_const_209.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, A_arbace_repr_go_print_build_A_fn_class); var ifn_2659 lang.IFn
				if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = package__11; var arg_2661 any = jrt.File_New_String(jrt.String_Cast(src__15)); var arg_2662 any = outf__13; var arg_2663 any = goroot__2; if linked_2658 == nil { vec__1344000270__16 = ifn_2659.Invoke_O_O_O_O__O(arg_2660, arg_2661, arg_2662, arg_2663) } else { vec__1344000270__16 = linked_2658.(*A_arbace_repr_go_print_build_A).Invoke_O_O_O_O_O__O(root_2657, arg_2660, arg_2661, arg_2662, arg_2663) }
//line :460:1
				var status__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000270__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000270__16, lang.RT_IntCast_J__I_NoInit(1), nil)

				lang.IFn_Cast(A_arbace_repr_go_print_A_const_212.GetRawRoot__O()).Invoke_O__O(text__18)
				var root_2711 any = A_arbace_repr_go_print_A_const_213.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; if linked_2712 == nil { ifn_2713.Invoke__O() } else { linked_2712.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_2711) }
				var tmp29 bool; var na_2664 any = status__17; if jrt.Long_InstanceOf(na_2664) { var n0_2665 int64 = jrt.NN(jrt.Long_Cast(na_2664)).LongValue__J(); tmp29 = n0_2665 == 0 } else { if jrt.Double_InstanceOf(na_2664) { var n0_2665_2 float64 = jrt.NN(jrt.Double_Cast(na_2664)).DoubleValue__D(); tmp29 = n0_2665_2 == 0.0 } else { tmp29 = lang.Numbers_IsZero_O__Z_NoInit(na_2664) } }; if tmp29 { } else { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)) } } }
		var root_2538 any = A_arbace_repr_go_print_A_const_206.GetRawRoot__O(); var linked_2539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2538, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_2540 lang.IFn; if linked_2539 == nil { ifn_2540 = lang.IFn_Cast(root_2538) } else { ifn_2540 = nil }; if linked_2539 == nil { return ifn_2540.Invoke__O() } else { return linked_2539.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_2538) } } }; /*line :439:1*/panic("j2g: unreachable") }







type A_arbace_repr_go_print_A struct{ jrt.Object }

var A_arbace_repr_go_print_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_A_const_0 *lang.Var

var A_arbace_repr_go_print_A_const_1 any

var A_arbace_repr_go_print_A_const_2 *lang.Var

var A_arbace_repr_go_print_A_const_3 any

var A_arbace_repr_go_print_A_const_4 any

var A_arbace_repr_go_print_A_const_5 any

var A_arbace_repr_go_print_A_const_6 *lang.Var

var A_arbace_repr_go_print_A_const_7 *lang.Var

var A_arbace_repr_go_print_A_const_8 *lang.Var

var A_arbace_repr_go_print_A_const_9 *lang.Var

var A_arbace_repr_go_print_A_const_10 any

var A_arbace_repr_go_print_A_const_11 *lang.Var

var A_arbace_repr_go_print_A_const_12 *lang.Var

var A_arbace_repr_go_print_A_const_13 *lang.Var

var A_arbace_repr_go_print_A_const_14 *lang.Var

var A_arbace_repr_go_print_A_const_15 *lang.Var

var A_arbace_repr_go_print_A_const_16 *lang.Var

var A_arbace_repr_go_print_A_const_17 *lang.Var

var A_arbace_repr_go_print_A_const_18 any

var A_arbace_repr_go_print_A_const_19 *lang.Var

var A_arbace_repr_go_print_A_const_20 *lang.Var

var A_arbace_repr_go_print_A_const_21 *lang.Var

var A_arbace_repr_go_print_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_A_const_23 *lang.Var

var A_arbace_repr_go_print_A_const_24 *lang.Var

var A_arbace_repr_go_print_A_const_25 *lang.Var

var A_arbace_repr_go_print_A_const_26 *lang.Var

var A_arbace_repr_go_print_A_const_27 any

var A_arbace_repr_go_print_A_const_28 *lang.Var

var A_arbace_repr_go_print_A_const_29 *lang.Var

var A_arbace_repr_go_print_A_const_30 *lang.Keyword

var A_arbace_repr_go_print_A_const_31 *lang.Var

var A_arbace_repr_go_print_A_const_32 *lang.Var

var A_arbace_repr_go_print_A_const_33 *lang.Var

var A_arbace_repr_go_print_A_const_34 *lang.Var

var A_arbace_repr_go_print_A_const_35 *lang.Var

var A_arbace_repr_go_print_A_const_36 *lang.Var

var A_arbace_repr_go_print_A_const_37 *lang.Var

var A_arbace_repr_go_print_A_const_38 *lang.Var

var A_arbace_repr_go_print_A_const_39 *lang.Var

var A_arbace_repr_go_print_A_const_40 *lang.Keyword

var A_arbace_repr_go_print_A_const_41 *lang.Var

var A_arbace_repr_go_print_A_const_42 *lang.Var

var A_arbace_repr_go_print_A_const_43 *lang.Var

var A_arbace_repr_go_print_A_const_44 *lang.Keyword

var A_arbace_repr_go_print_A_const_45 *lang.Keyword

var A_arbace_repr_go_print_A_const_46 *lang.Keyword

var A_arbace_repr_go_print_A_const_47 *lang.Keyword

var A_arbace_repr_go_print_A_const_48 *lang.Keyword

var A_arbace_repr_go_print_A_const_49 *lang.Keyword

var A_arbace_repr_go_print_A_const_50 *lang.Keyword

var A_arbace_repr_go_print_A_const_51 *lang.Var

var A_arbace_repr_go_print_A_const_52 *lang.Var

var A_arbace_repr_go_print_A_const_53 *lang.Var

var A_arbace_repr_go_print_A_const_54 *lang.Var

var A_arbace_repr_go_print_A_const_55 *lang.Var

var A_arbace_repr_go_print_A_const_56 *lang.Keyword

var A_arbace_repr_go_print_A_const_57 *lang.Var

var A_arbace_repr_go_print_A_const_58 *lang.Var

var A_arbace_repr_go_print_A_const_59 *lang.Keyword

var A_arbace_repr_go_print_A_const_60 *lang.Var

var A_arbace_repr_go_print_A_const_61 *lang.Var

var A_arbace_repr_go_print_A_const_62 any

var A_arbace_repr_go_print_A_const_63 *lang.Var

var A_arbace_repr_go_print_A_const_64 *lang.Var

var A_arbace_repr_go_print_A_const_65 *lang.Var

var A_arbace_repr_go_print_A_const_66 *lang.Keyword

var A_arbace_repr_go_print_A_const_67 *lang.Var

var A_arbace_repr_go_print_A_const_68 any

var A_arbace_repr_go_print_A_const_69 any

var A_arbace_repr_go_print_A_const_70 *lang.Var

var A_arbace_repr_go_print_A_const_71 any

var A_arbace_repr_go_print_A_const_72 *lang.Var

var A_arbace_repr_go_print_A_const_73 *lang.Var

var A_arbace_repr_go_print_A_const_74 *lang.Var

var A_arbace_repr_go_print_A_const_75 *lang.Var

var A_arbace_repr_go_print_A_const_76 *lang.Var

var A_arbace_repr_go_print_A_const_77 any

var A_arbace_repr_go_print_A_const_78 *lang.Keyword

var A_arbace_repr_go_print_A_const_79 any

var A_arbace_repr_go_print_A_const_80 *lang.Var

var A_arbace_repr_go_print_A_const_81 *lang.Var

var A_arbace_repr_go_print_A_const_82 *lang.Var

var A_arbace_repr_go_print_A_const_83 *lang.Var

var A_arbace_repr_go_print_A_const_84 *lang.Var

var A_arbace_repr_go_print_A_const_85 any

var A_arbace_repr_go_print_A_const_86 *lang.Var

var A_arbace_repr_go_print_A_const_87 *lang.Var

var A_arbace_repr_go_print_A_const_88 *lang.Var

var A_arbace_repr_go_print_A_const_89 *lang.Var

var A_arbace_repr_go_print_A_const_90 *lang.Var

var A_arbace_repr_go_print_A_const_91 *lang.Var

var A_arbace_repr_go_print_A_const_92 *lang.Keyword

var A_arbace_repr_go_print_A_const_93 *lang.Var

var A_arbace_repr_go_print_A_const_94 *lang.Keyword

var A_arbace_repr_go_print_A_const_95 *lang.Keyword

var A_arbace_repr_go_print_A_const_96 *lang.Var

var A_arbace_repr_go_print_A_const_97 *lang.Keyword

var A_arbace_repr_go_print_A_const_98 *lang.Var

var A_arbace_repr_go_print_A_const_99 *lang.Keyword

var A_arbace_repr_go_print_A_const_100 any

var A_arbace_repr_go_print_A_const_101 *lang.Keyword

var A_arbace_repr_go_print_A_const_102 any

var A_arbace_repr_go_print_A_const_103 any

var A_arbace_repr_go_print_A_const_104 *lang.Keyword

var A_arbace_repr_go_print_A_const_105 *lang.Var

var A_arbace_repr_go_print_A_const_106 *lang.Keyword

var A_arbace_repr_go_print_A_const_107 *lang.Var

var A_arbace_repr_go_print_A_const_108 *lang.Var

var A_arbace_repr_go_print_A_const_109 *lang.Keyword

var A_arbace_repr_go_print_A_const_110 *lang.Var

var A_arbace_repr_go_print_A_const_111 *lang.Var

var A_arbace_repr_go_print_A_const_112 *lang.Var

var A_arbace_repr_go_print_A_const_113 *lang.Keyword

var A_arbace_repr_go_print_A_const_114 *lang.Var

var A_arbace_repr_go_print_A_const_115 *lang.Keyword

var A_arbace_repr_go_print_A_const_116 *lang.Var

var A_arbace_repr_go_print_A_const_117 *lang.Var

var A_arbace_repr_go_print_A_const_118 *lang.Var

var A_arbace_repr_go_print_A_const_119 *lang.Var

var A_arbace_repr_go_print_A_const_120 *lang.Keyword

var A_arbace_repr_go_print_A_const_121 *lang.Keyword

var A_arbace_repr_go_print_A_const_122 *lang.Var

var A_arbace_repr_go_print_A_const_123 *lang.Var

var A_arbace_repr_go_print_A_const_124 *lang.Var

var A_arbace_repr_go_print_A_const_125 *lang.Var

var A_arbace_repr_go_print_A_const_126 *lang.Var

var A_arbace_repr_go_print_A_const_127 *lang.Var

var A_arbace_repr_go_print_A_const_128 *lang.Keyword

var A_arbace_repr_go_print_A_const_129 *lang.Var

var A_arbace_repr_go_print_A_const_130 *lang.Var

var A_arbace_repr_go_print_A_const_131 *lang.Var

var A_arbace_repr_go_print_A_const_132 *lang.Var

var A_arbace_repr_go_print_A_const_133 *lang.Var

var A_arbace_repr_go_print_A_const_134 *lang.Var

var A_arbace_repr_go_print_A_const_135 *lang.Var

var A_arbace_repr_go_print_A_const_136 *lang.Var

var A_arbace_repr_go_print_A_const_137 *lang.Var

var A_arbace_repr_go_print_A_const_138 *lang.Var

var A_arbace_repr_go_print_A_const_139 *lang.Var

var A_arbace_repr_go_print_A_const_140 *lang.Keyword

var A_arbace_repr_go_print_A_const_141 *lang.Var

var A_arbace_repr_go_print_A_const_142 *lang.Var

var A_arbace_repr_go_print_A_const_143 *lang.Keyword

var A_arbace_repr_go_print_A_const_144 *lang.Keyword

var A_arbace_repr_go_print_A_const_145 *lang.Keyword

var A_arbace_repr_go_print_A_const_146 *lang.Keyword

var A_arbace_repr_go_print_A_const_147 *lang.Keyword

var A_arbace_repr_go_print_A_const_148 *lang.Keyword

var A_arbace_repr_go_print_A_const_149 *lang.Keyword

var A_arbace_repr_go_print_A_const_150 *lang.Keyword

var A_arbace_repr_go_print_A_const_151 *lang.Keyword

var A_arbace_repr_go_print_A_const_152 *lang.Keyword

var A_arbace_repr_go_print_A_const_153 *lang.Keyword

var A_arbace_repr_go_print_A_const_154 *lang.Var

var A_arbace_repr_go_print_A_const_155 *lang.Var

var A_arbace_repr_go_print_A_const_156 *lang.Var

var A_arbace_repr_go_print_A_const_157 *lang.Var

var A_arbace_repr_go_print_A_const_158 *lang.Keyword

var A_arbace_repr_go_print_A_const_159 *lang.Keyword

var A_arbace_repr_go_print_A_const_160 *lang.Var

var A_arbace_repr_go_print_A_const_161 *lang.Keyword

var A_arbace_repr_go_print_A_const_162 *lang.Keyword

var A_arbace_repr_go_print_A_const_163 *lang.Var

var A_arbace_repr_go_print_A_const_164 *lang.Keyword

var A_arbace_repr_go_print_A_const_165 *lang.Keyword

var A_arbace_repr_go_print_A_const_166 *lang.Var

var A_arbace_repr_go_print_A_const_167 *lang.Keyword

var A_arbace_repr_go_print_A_const_168 *lang.Var

var A_arbace_repr_go_print_A_const_169 *lang.Var

var A_arbace_repr_go_print_A_const_170 *lang.Var

var A_arbace_repr_go_print_A_const_171 *lang.Var

var A_arbace_repr_go_print_A_const_172 *lang.Var

var A_arbace_repr_go_print_A_const_173 *lang.Var

var A_arbace_repr_go_print_A_const_174 *lang.Var

var A_arbace_repr_go_print_A_const_175 *lang.Var

var A_arbace_repr_go_print_A_const_176 *lang.Var

var A_arbace_repr_go_print_A_const_177 *lang.Var

var A_arbace_repr_go_print_A_const_178 *lang.Var

var A_arbace_repr_go_print_A_const_179 *lang.Var

var A_arbace_repr_go_print_A_const_180 *jrt.Class

var A_arbace_repr_go_print_A_const_181 *lang.Var

var A_arbace_repr_go_print_A_const_182 *lang.Var

var A_arbace_repr_go_print_A_const_183 *lang.Var

var A_arbace_repr_go_print_A_const_184 *lang.Var

var A_arbace_repr_go_print_A_const_185 *lang.Keyword

var A_arbace_repr_go_print_A_const_186 *lang.Keyword

var A_arbace_repr_go_print_A_const_187 *lang.Var

var A_arbace_repr_go_print_A_const_188 *lang.Var

var A_arbace_repr_go_print_A_const_189 *lang.Keyword

var A_arbace_repr_go_print_A_const_190 *lang.Keyword

var A_arbace_repr_go_print_A_const_191 *lang.Keyword

var A_arbace_repr_go_print_A_const_192 *lang.Keyword

var A_arbace_repr_go_print_A_const_193 *lang.Keyword

var A_arbace_repr_go_print_A_const_194 *lang.Var

var A_arbace_repr_go_print_A_const_195 *lang.Keyword

var A_arbace_repr_go_print_A_const_196 *lang.Var

var A_arbace_repr_go_print_A_const_197 *lang.Keyword

var A_arbace_repr_go_print_A_const_198 *lang.Keyword

var A_arbace_repr_go_print_A_const_199 any

var A_arbace_repr_go_print_A_const_200 *lang.Var

var A_arbace_repr_go_print_A_const_201 *lang.Var

var A_arbace_repr_go_print_A_const_202 *lang.Var

var A_arbace_repr_go_print_A_const_203 *lang.Keyword

var A_arbace_repr_go_print_A_const_204 *lang.Var

var A_arbace_repr_go_print_A_const_205 *lang.Var

var A_arbace_repr_go_print_A_const_206 *lang.Var

var A_arbace_repr_go_print_A_const_207 *lang.Var

var A_arbace_repr_go_print_A_const_208 *lang.Var

var A_arbace_repr_go_print_A_const_209 *lang.Var

var A_arbace_repr_go_print_A_const_210 *lang.Var

var A_arbace_repr_go_print_A_const_211 *lang.Var

var A_arbace_repr_go_print_A_const_212 *lang.Var

var A_arbace_repr_go_print_A_const_213 *lang.Var

var A_arbace_repr_go_print_A_init jrt.ClassInit

func A_arbace_repr_go_print_A_Init() { if !A_arbace_repr_go_print_A_init.Done() { A_arbace_repr_go_print_A_init.Run(A_arbace_repr_go_print_A_clinit) } }

func A_arbace_repr_go_print_A_clinit() { A_arbace_repr_go_print_A_clinit_p0(); A_arbace_repr_go_print_A_clinit_p1(); A_arbace_repr_go_print_A_clinit_p2(); A_arbace_repr_go_print_A_clinit_p3(); A_arbace_repr_go_print_A_clinit_p4(); A_arbace_repr_go_print_A_clinit_p5(); A_arbace_repr_go_print_A_clinit_p6(); A_arbace_repr_go_print_A_clinit_p7(); A_arbace_repr_go_print_A_clinit_p8(); A_arbace_repr_go_print_A_clinit_p9(); A_arbace_repr_go_print_A_clinit_p10(); A_arbace_repr_go_print_A_clinit_p11(); A_arbace_repr_go_print_A_clinit_p12(); A_arbace_repr_go_print_A_clinit_p13(); A_arbace_repr_go_print_A_clinit_p14(); A_arbace_repr_go_print_A_clinit_p15(); A_arbace_repr_go_print_A_clinit_p16(); A_arbace_repr_go_print_A_clinit_p17() }

func A_arbace_repr_go_print_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 282); A_arbace_repr_go_print_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[68]); A_arbace_repr_go_print_A_const_1 = A_arbace_repr_go_print_A_const_pool.A[69]; A_arbace_repr_go_print_A_const_2 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[70]); A_arbace_repr_go_print_A_const_3 = A_arbace_repr_go_print_A_const_pool.A[71]; A_arbace_repr_go_print_A_const_4 = A_arbace_repr_go_print_A_const_pool.A[72]; A_arbace_repr_go_print_A_const_5 = A_arbace_repr_go_print_A_const_pool.A[73]; A_arbace_repr_go_print_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[74]); A_arbace_repr_go_print_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[75]); A_arbace_repr_go_print_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[76]); A_arbace_repr_go_print_A_const_9 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[77]); A_arbace_repr_go_print_A_const_10 = A_arbace_repr_go_print_A_const_pool.A[78]; A_arbace_repr_go_print_A_const_11 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[79]) }

func A_arbace_repr_go_print_A_clinit_p1() { A_arbace_repr_go_print_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[80]); A_arbace_repr_go_print_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[81]); A_arbace_repr_go_print_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[82]); A_arbace_repr_go_print_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[83]); A_arbace_repr_go_print_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[84]); A_arbace_repr_go_print_A_const_17 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[85]); A_arbace_repr_go_print_A_const_18 = A_arbace_repr_go_print_A_const_pool.A[86]; A_arbace_repr_go_print_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[87]); A_arbace_repr_go_print_A_const_20 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[88]); A_arbace_repr_go_print_A_const_21 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[89]); A_arbace_repr_go_print_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[90]); A_arbace_repr_go_print_A_const_23 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[91]) }

func A_arbace_repr_go_print_A_clinit_p2() { A_arbace_repr_go_print_A_const_24 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[92]); A_arbace_repr_go_print_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[93]); A_arbace_repr_go_print_A_const_26 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[94]); A_arbace_repr_go_print_A_const_27 = A_arbace_repr_go_print_A_const_pool.A[95]; A_arbace_repr_go_print_A_const_28 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[96]); A_arbace_repr_go_print_A_const_29 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[97]); A_arbace_repr_go_print_A_const_30 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[98]); A_arbace_repr_go_print_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[99]); A_arbace_repr_go_print_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[100]); A_arbace_repr_go_print_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[101]); A_arbace_repr_go_print_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[102]); A_arbace_repr_go_print_A_const_35 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[103]) }

func A_arbace_repr_go_print_A_clinit_p3() { A_arbace_repr_go_print_A_const_36 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[104]); A_arbace_repr_go_print_A_const_37 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[105]); A_arbace_repr_go_print_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[106]); A_arbace_repr_go_print_A_const_39 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[107]); A_arbace_repr_go_print_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[108]); A_arbace_repr_go_print_A_const_41 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[109]); A_arbace_repr_go_print_A_const_42 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[110]); A_arbace_repr_go_print_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[111]); A_arbace_repr_go_print_A_const_44 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[112]); A_arbace_repr_go_print_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[113]); A_arbace_repr_go_print_A_const_46 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[114]); A_arbace_repr_go_print_A_const_47 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[115]) }

func A_arbace_repr_go_print_A_clinit_p4() { A_arbace_repr_go_print_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[116]); A_arbace_repr_go_print_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[117]); A_arbace_repr_go_print_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[118]); A_arbace_repr_go_print_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[119]); A_arbace_repr_go_print_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[120]); A_arbace_repr_go_print_A_const_53 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[121]); A_arbace_repr_go_print_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[122]); A_arbace_repr_go_print_A_const_55 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[123]); A_arbace_repr_go_print_A_const_56 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[124]); A_arbace_repr_go_print_A_const_57 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[125]); A_arbace_repr_go_print_A_const_58 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[126]); A_arbace_repr_go_print_A_const_59 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[127]) }

func A_arbace_repr_go_print_A_clinit_p5() { A_arbace_repr_go_print_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[128]); A_arbace_repr_go_print_A_const_61 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[129]); A_arbace_repr_go_print_A_const_62 = A_arbace_repr_go_print_A_const_pool.A[130]; A_arbace_repr_go_print_A_const_63 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[131]); A_arbace_repr_go_print_A_const_64 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[132]); A_arbace_repr_go_print_A_const_65 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[133]); A_arbace_repr_go_print_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[134]); A_arbace_repr_go_print_A_const_67 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[135]); A_arbace_repr_go_print_A_const_68 = A_arbace_repr_go_print_A_const_pool.A[136]; A_arbace_repr_go_print_A_const_69 = A_arbace_repr_go_print_A_const_pool.A[137]; A_arbace_repr_go_print_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[138]); A_arbace_repr_go_print_A_const_71 = A_arbace_repr_go_print_A_const_pool.A[139]; A_arbace_repr_go_print_A_const_72 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[140]) }

func A_arbace_repr_go_print_A_clinit_p6() { A_arbace_repr_go_print_A_const_73 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[141]); A_arbace_repr_go_print_A_const_74 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[142]); A_arbace_repr_go_print_A_const_75 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[143]); A_arbace_repr_go_print_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[144]); A_arbace_repr_go_print_A_const_77 = A_arbace_repr_go_print_A_const_pool.A[145]; A_arbace_repr_go_print_A_const_78 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[146]); A_arbace_repr_go_print_A_const_79 = A_arbace_repr_go_print_A_const_pool.A[147]; A_arbace_repr_go_print_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[148]); A_arbace_repr_go_print_A_const_81 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[149]); A_arbace_repr_go_print_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[150]); A_arbace_repr_go_print_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[151]); A_arbace_repr_go_print_A_const_84 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[152]) }

func A_arbace_repr_go_print_A_clinit_p7() { A_arbace_repr_go_print_A_const_85 = A_arbace_repr_go_print_A_const_pool.A[153]; A_arbace_repr_go_print_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[154]); A_arbace_repr_go_print_A_const_87 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[155]); A_arbace_repr_go_print_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[156]); A_arbace_repr_go_print_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[157]); A_arbace_repr_go_print_A_const_90 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[158]); A_arbace_repr_go_print_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[159]); A_arbace_repr_go_print_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[160]); A_arbace_repr_go_print_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[161]); A_arbace_repr_go_print_A_const_94 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[162]); A_arbace_repr_go_print_A_const_95 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[163]); A_arbace_repr_go_print_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[164]) }

func A_arbace_repr_go_print_A_clinit_p8() { A_arbace_repr_go_print_A_const_97 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[165]); A_arbace_repr_go_print_A_const_98 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[166]); A_arbace_repr_go_print_A_const_99 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[167]); A_arbace_repr_go_print_A_const_100 = A_arbace_repr_go_print_A_const_pool.A[168]; A_arbace_repr_go_print_A_const_101 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[169]); A_arbace_repr_go_print_A_const_102 = A_arbace_repr_go_print_A_const_pool.A[170]; A_arbace_repr_go_print_A_const_103 = A_arbace_repr_go_print_A_const_pool.A[171]; A_arbace_repr_go_print_A_const_104 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[172]); A_arbace_repr_go_print_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[173]); A_arbace_repr_go_print_A_const_106 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[174]); A_arbace_repr_go_print_A_const_107 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[175]); A_arbace_repr_go_print_A_const_108 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[176]) }

func A_arbace_repr_go_print_A_clinit_p9() { A_arbace_repr_go_print_A_const_109 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[177]); A_arbace_repr_go_print_A_const_110 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[178]); A_arbace_repr_go_print_A_const_111 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[179]); A_arbace_repr_go_print_A_const_112 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[180]); A_arbace_repr_go_print_A_const_113 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[181]); A_arbace_repr_go_print_A_const_114 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[182]); A_arbace_repr_go_print_A_const_115 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[183]); A_arbace_repr_go_print_A_const_116 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[184]); A_arbace_repr_go_print_A_const_117 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[185]); A_arbace_repr_go_print_A_const_118 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[186]); A_arbace_repr_go_print_A_const_119 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[187]); A_arbace_repr_go_print_A_const_120 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[188]) }

func A_arbace_repr_go_print_A_clinit_p10() { A_arbace_repr_go_print_A_const_121 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[189]); A_arbace_repr_go_print_A_const_122 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[190]); A_arbace_repr_go_print_A_const_123 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[191]); A_arbace_repr_go_print_A_const_124 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[192]); A_arbace_repr_go_print_A_const_125 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[193]); A_arbace_repr_go_print_A_const_126 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[194]); A_arbace_repr_go_print_A_const_127 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[195]); A_arbace_repr_go_print_A_const_128 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[196]); A_arbace_repr_go_print_A_const_129 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[197]); A_arbace_repr_go_print_A_const_130 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[198]); A_arbace_repr_go_print_A_const_131 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[199]); A_arbace_repr_go_print_A_const_132 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[200]) }

func A_arbace_repr_go_print_A_clinit_p11() { A_arbace_repr_go_print_A_const_133 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[201]); A_arbace_repr_go_print_A_const_134 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[202]); A_arbace_repr_go_print_A_const_135 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[203]); A_arbace_repr_go_print_A_const_136 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[204]); A_arbace_repr_go_print_A_const_137 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[205]); A_arbace_repr_go_print_A_const_138 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[206]); A_arbace_repr_go_print_A_const_139 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[207]); A_arbace_repr_go_print_A_const_140 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[208]); A_arbace_repr_go_print_A_const_141 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[209]); A_arbace_repr_go_print_A_const_142 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[210]); A_arbace_repr_go_print_A_const_143 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[211]); A_arbace_repr_go_print_A_const_144 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[212]) }

func A_arbace_repr_go_print_A_clinit_p12() { A_arbace_repr_go_print_A_const_145 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[213]); A_arbace_repr_go_print_A_const_146 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[214]); A_arbace_repr_go_print_A_const_147 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[215]); A_arbace_repr_go_print_A_const_148 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[216]); A_arbace_repr_go_print_A_const_149 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[217]); A_arbace_repr_go_print_A_const_150 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[218]); A_arbace_repr_go_print_A_const_151 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[219]); A_arbace_repr_go_print_A_const_152 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[220]); A_arbace_repr_go_print_A_const_153 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[221]); A_arbace_repr_go_print_A_const_154 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[222]); A_arbace_repr_go_print_A_const_155 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[223]); A_arbace_repr_go_print_A_const_156 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[224]) }

func A_arbace_repr_go_print_A_clinit_p13() { A_arbace_repr_go_print_A_const_157 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[225]); A_arbace_repr_go_print_A_const_158 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[226]); A_arbace_repr_go_print_A_const_159 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[227]); A_arbace_repr_go_print_A_const_160 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[228]); A_arbace_repr_go_print_A_const_161 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[229]); A_arbace_repr_go_print_A_const_162 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[230]); A_arbace_repr_go_print_A_const_163 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[231]); A_arbace_repr_go_print_A_const_164 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[232]); A_arbace_repr_go_print_A_const_165 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[233]); A_arbace_repr_go_print_A_const_166 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[234]); A_arbace_repr_go_print_A_const_167 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[235]); A_arbace_repr_go_print_A_const_168 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[236]) }

func A_arbace_repr_go_print_A_clinit_p14() { A_arbace_repr_go_print_A_const_169 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[237]); A_arbace_repr_go_print_A_const_170 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[238]); A_arbace_repr_go_print_A_const_171 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[239]); A_arbace_repr_go_print_A_const_172 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[240]); A_arbace_repr_go_print_A_const_173 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[241]); A_arbace_repr_go_print_A_const_174 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[242]); A_arbace_repr_go_print_A_const_175 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[243]); A_arbace_repr_go_print_A_const_176 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[244]); A_arbace_repr_go_print_A_const_177 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[245]); A_arbace_repr_go_print_A_const_178 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[246]); A_arbace_repr_go_print_A_const_179 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[247]); A_arbace_repr_go_print_A_const_180 = jrt.Class_Cast(A_arbace_repr_go_print_A_const_pool.A[248]) }

func A_arbace_repr_go_print_A_clinit_p15() { A_arbace_repr_go_print_A_const_181 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[249]); A_arbace_repr_go_print_A_const_182 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[250]); A_arbace_repr_go_print_A_const_183 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[251]); A_arbace_repr_go_print_A_const_184 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[252]); A_arbace_repr_go_print_A_const_185 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[253]); A_arbace_repr_go_print_A_const_186 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[254]); A_arbace_repr_go_print_A_const_187 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[255]); A_arbace_repr_go_print_A_const_188 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[256]); A_arbace_repr_go_print_A_const_189 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[257]); A_arbace_repr_go_print_A_const_190 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[258]); A_arbace_repr_go_print_A_const_191 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[259]); A_arbace_repr_go_print_A_const_192 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[260]) }

func A_arbace_repr_go_print_A_clinit_p16() { A_arbace_repr_go_print_A_const_193 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[261]); A_arbace_repr_go_print_A_const_194 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[262]); A_arbace_repr_go_print_A_const_195 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[263]); A_arbace_repr_go_print_A_const_196 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[264]); A_arbace_repr_go_print_A_const_197 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[265]); A_arbace_repr_go_print_A_const_198 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[266]); A_arbace_repr_go_print_A_const_199 = A_arbace_repr_go_print_A_const_pool.A[267]; A_arbace_repr_go_print_A_const_200 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[268]); A_arbace_repr_go_print_A_const_201 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[269]); A_arbace_repr_go_print_A_const_202 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[270]); A_arbace_repr_go_print_A_const_203 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[271]); A_arbace_repr_go_print_A_const_204 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[272]) }

func A_arbace_repr_go_print_A_clinit_p17() { A_arbace_repr_go_print_A_const_205 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[273]); A_arbace_repr_go_print_A_const_206 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[274]); A_arbace_repr_go_print_A_const_207 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[275]); A_arbace_repr_go_print_A_const_208 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[276]); A_arbace_repr_go_print_A_const_209 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[277]); A_arbace_repr_go_print_A_const_210 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[278]); A_arbace_repr_go_print_A_const_211 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[279]); A_arbace_repr_go_print_A_const_212 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[280]); A_arbace_repr_go_print_A_const_213 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[281]) }

func A_arbace_repr_go_print_A_New() *A_arbace_repr_go_print_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_A) Ctor() {}

func (t *A_arbace_repr_go_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_A_class }

func (t *A_arbace_repr_go_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_A); return ok }

func A_arbace_repr_go_print_A_Cast(x any) *A_arbace_repr_go_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_A_class)) }; return v }



type A_arbace_repr_go_print__main_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print__main_A_fn_class *jrt.Class



type A_arbace_repr_go_print_add_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_add_form_A_fn_class *jrt.Class



type A_arbace_repr_go_print_add_form_fn__1344000040_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class *jrt.Class



type A_arbace_repr_go_print_build_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_build_A_fn_class *jrt.Class



type A_arbace_repr_go_print_build_env_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_build_env_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_chunk_starts_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_fn__1344000131_A struct{ j2g_header uint64; F_decls any; F_n int32 }

var A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A struct{ j2g_header uint64; F_decls any }

var A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_A struct{ j2g_header uint64; F_state, F_read_fn, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A struct{ j2g_header uint64; F_read_fn, F_file any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A struct{ j2g_header uint64; F_f, F_walk, F_state, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A struct{ j2g_header uint64; F_walk, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A struct{ j2g_header uint64; F_walk, F_state, F_file, F_f, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A struct{ j2g_header uint64; F_walk, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_fn__1344000048_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_fn__1344000050_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_copy_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_copy_files_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A struct{ j2g_header uint64; F_src, F_out any }

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A struct{ j2g_header uint64; F_iter__1344000216, F_src, F_out, F_s__1344000217 any }

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A struct{ j2g_header uint64; F_src, F_b__1344000219, F_out any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_fn_class *jrt.Class



type A_arbace_repr_go_print_decl_pre_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_decl_pre_A_fn_class *jrt.Class



type A_arbace_repr_go_print_decl_sep_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_decl_sep_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_eval1344000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_eval1344000004_A_New() *A_arbace_repr_go_print_eval1344000004_A { t := &A_arbace_repr_go_print_eval1344000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_eval1344000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_eval1344000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_eval1344000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_eval1344000004_A_class }

func (t *A_arbace_repr_go_print_eval1344000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_eval1344000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_eval1344000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_eval1344000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_eval1344000004_A); return ok }

func A_arbace_repr_go_print_eval1344000004_A_Cast(x any) *A_arbace_repr_go_print_eval1344000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_eval1344000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_eval1344000004_A_class)) }; return v }



type A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_eval1344000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_eval1344000008_A_New() *A_arbace_repr_go_print_eval1344000008_A { t := &A_arbace_repr_go_print_eval1344000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_eval1344000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_eval1344000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_eval1344000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_eval1344000008_A_class }

func (t *A_arbace_repr_go_print_eval1344000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_eval1344000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_eval1344000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_eval1344000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_eval1344000008_A); return ok }

func A_arbace_repr_go_print_eval1344000008_A_Cast(x any) *A_arbace_repr_go_print_eval1344000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_eval1344000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_eval1344000008_A_class)) }; return v }



type A_arbace_repr_go_print_eval1344000008_fn__1344000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A struct{ j2g_header uint64; F_s__1344000014, F_iter__1344000013 any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A struct{ j2g_header uint64; F_s__1344000016, F_iter__1344000015 any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A struct{ j2g_header uint64; F_b__1344000018 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class *jrt.Class



type A_arbace_repr_go_print_gofmt_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_gofmt_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_import_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_import_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_json_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_json_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_name_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_name_text_A_fn_class *jrt.Class



type A_arbace_repr_go_print_new_package_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_new_package_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_next_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_next_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_next_target_fn__1344000122_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class *jrt.Class



type A_arbace_repr_go_print_one_line_func_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_one_line_func_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_decl_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_decl_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_first_line__1344000156_A struct{ j2g_header uint64; F_decls any }

var A_arbace_repr_go_print_print_file_first_line__1344000156_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_fn__1344000159_A struct{ j2g_header uint64; F_popts, F_first_line, F_lines_QMARK_, F_decls, F_state_opts any }

var A_arbace_repr_go_print_print_file_fn__1344000159_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_full_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_file_full_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_forms_fn__1344000193_A struct{ j2g_header uint64; F_pkg, F_opts any }

var A_arbace_repr_go_print_print_forms_fn__1344000193_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_package_A_fn_class *jrt.Class



type A_arbace_repr_go_print_read_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_read_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_run_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_run_A_fn_class *jrt.Class



type A_arbace_repr_go_print_sha256_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_sha256_A_fn_class *jrt.Class



type A_arbace_repr_go_print_sha256_fn__1344000197_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_sha256_fn__1344000197_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_import_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_import_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_full_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_full_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A struct{ j2g_header uint64; F_open any }

var A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_fn_class *jrt.Class
