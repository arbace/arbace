//line aot_arbace_repr_go_print.ae:1
package aot_arbace_repr_go_print

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print_code"
	"arbace/aot_arbace_repr_go_print_emit"
	"arbace/aot_arbace_repr_go_print_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_New() *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_1); lang.IFn_Cast(A_arbace_repr_go_print_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_A_const_3, A_arbace_repr_go_print_A_const_4, A_arbace_repr_go_print_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_68)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_69)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_70)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_71)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_72)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_73)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_74)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_75)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_76)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_New() *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_eval1344000008_fn__1344000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_repr_go_print_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_print_A_const_9.GetRawRoot__O(), A_arbace_repr_go_print_A_const_10) }






































func A_arbace_repr_go_print_read_forms_A_New() *A_arbace_repr_go_print_read_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_read_forms_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_repr_go_print_read_forms_A) Ctor() {}
//line :40:1
func (t *A_arbace_repr_go_print_read_forms_A) Invoke_O_O__O(self, path__0 any) any { var r__2 any; var tmp1 any; var root_21 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_23 lang.IFn; if



	linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = path__0; if linked_22 == nil { tmp1 = ifn_23.Invoke_O__O(arg_24) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_21, arg_24) }; r__2 = /*line :40:1*/lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream_Charset(jrt.FileInputStream_New_String(jrt.String_Cast(tmp1)), jrt.StandardCharsets_UTF_8)); var tmp2 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var root_34 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_16, jrt.Boolean_FALSE.Ref()); if linked_35 == nil { ifn_36.Invoke_O__O(arg_37) } else { linked_35.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_34, arg_37) }; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :40:1
			{ var eof__7 any = jrt.Object_New(); var acc__8 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__9 any; var root_25 any = A_arbace_repr_go_print_A_const_12.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_27 lang.IFn







				if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = r__2; var arg_29 any = jrt.Boolean_FALSE.Ref(); var arg_30 any = eof__7; if linked_26 == nil { f__9 = ifn_27.Invoke_O_O_O__O(arg_28, arg_29, arg_30) } else { f__9 = linked_26.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_25, arg_28, arg_29, arg_30) }
				if lang.Util_Identical_O_O__Z_NoInit(f__9, eof__7) { tmp2 = acc__8 } else { var tmp3 any; var root_43 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = acc__8; var arg_47 any = f__9; if linked_44 == nil { tmp3 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp3 = linked_44.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; acc__8 = tmp3; continue L1 }
//line :40:1
				break L1
			}
			}


			return nil }(); var root_31 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; if linked_32 == nil { ifn_33.Invoke__O() } else { linked_32.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_31) }
//line :40:1
			if tmp4 != nil { panic(tmp4) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :40:1*/ tmp5 != nil { panic(tmp5) }; return tmp2 }










func A_arbace_repr_go_print_go_ns_aliases_A_New() *A_arbace_repr_go_print_go_ns_aliases_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_go_print_go_ns_aliases_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_go_print_go_ns_aliases_A) Invoke_O_O__O(self, ns_form__0 any) any {


	var root_48 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = A_arbace_repr_go_print_A_const_18; var arg_52 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_New(); var tmp2 *jrt.Class; var fncls__204 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class
	if fncls__204 == nil { var fncls__204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class = fncls__204d; tmp2 = fncls__204d } else { tmp2 = fncls__204 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_205 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = ns_form__0; if linked_206 == nil { tmp4 = ifn_207.Invoke_O__O(arg_208) } else { tmp4 = linked_206.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_205, arg_208) }; arg_52 = tmp3.Invoke_O__O(tmp4)
//line :54:1
	if linked_49 == nil { return ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { return linked_49.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) } }
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_New() *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A) Invoke_O_O__O(self, s__1344000014__1 any) any { var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_New_O_O(s__1344000014__1, self); var tmp2 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class = fncls__203d; tmp2 = fncls__203d } else { tmp2 = fncls__203 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A) Ctor_O_O(c__s__1344000014, c__iter__1344000013 any) { t.F_s__1344000014 = c__s__1344000014; t.F_iter__1344000013 = c__iter__1344000013 }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A) Invoke_O__O(self any) any { { var s__1344000014__1 any; var t_ any = t.F_s__1344000014; t.F_s__1344000014 = nil; s__1344000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_53 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = s__1344000014__1; if linked_54 == nil { temp__1927000414__auto____2 = ifn_55.Invoke_O__O(arg_56) } else { temp__1927000414__auto____2 = linked_54.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var clause__4 any; var root_57 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = xs__1927001018__auto____3; if linked_58 == nil { clause__4 = ifn_59.Invoke_O__O(arg_60) } else { clause__4 = linked_58.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_57, arg_60) }; var tmp1 any; var and__1927000168__auto____5 any; var root_61 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_63 lang.IFn
															if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = clause__4; if linked_62 == nil { and__1927000168__auto____5 = ifn_63.Invoke_O__O(arg_64) } else { and__1927000168__auto____5 = linked_62.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_61, arg_64) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 any = A_arbace_repr_go_print_A_const_22; var tmp3 any; var root_65 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = clause__4; if linked_66 == nil { tmp3 = ifn_67.Invoke_O__O(arg_68) } else { tmp3 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____5 }
//line :55:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_New(); var tmp5 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class = fncls__177d; tmp5 = fncls__177d } else { tmp5 = fncls__177 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____6 any; var root_178 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp7 any; var root_182 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_184 lang.IFn

		if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = clause__4; if linked_183 == nil { tmp7 = ifn_184.Invoke_O__O(arg_185) } else { tmp7 = linked_183.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_182, arg_185) }
//line :55:1
		arg_181 = tmp6.Invoke_O__O(tmp7); if linked_179 == nil { fs__1927001036__auto____6 = ifn_180.Invoke_O__O(arg_181) } else { fs__1927001036__auto____6 = linked_179.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_178, arg_181) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_186 any = A_arbace_repr_go_print_A_const_37.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = fs__1927001036__auto____6; var arg_190 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1344000013); var tmp9 any; var root_191 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = s__1344000014__1; if linked_192 == nil { tmp9 = ifn_193.Invoke_O__O(arg_194) } else { tmp9 = linked_192.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_191, arg_194) }; arg_190 = tmp8.Invoke_O__O(tmp9); if linked_187 == nil { return ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { return linked_187.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_186, arg_189, arg_190) } } else { var tmp10 any; var root_195 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = s__1344000014__1; if linked_196 == nil { tmp10 = ifn_197.Invoke_O__O(arg_198) } else { tmp10 = linked_196.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_195, arg_198) }; s__1344000014__1 = tmp10; continue L1 } } else { var tmp11 any; var root_199 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__1344000014__1; if linked_200 == nil { tmp11 = ifn_201.Invoke_O__O(arg_202) } else { tmp11 = linked_200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_199, arg_202) }; s__1344000014__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_New() *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A) Invoke_O_O__O(self, s__1344000016__1 any) any { var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_New_O_O(s__1344000016__1, self); var tmp2 *jrt.Class; var fncls__176 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class = fncls__176d; tmp2 = fncls__176d } else { tmp2 = fncls__176 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A) Ctor_O_O(c__s__1344000016, c__iter__1344000015 any) { t.F_s__1344000016 = c__s__1344000016; t.F_iter__1344000015 = c__iter__1344000015 }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A) Invoke_O__O(self any) any { { var s__1344000016__1 any; var t_ any = t.F_s__1344000016; t.F_s__1344000016 = nil; s__1344000016__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_69 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = s__1344000016__1; if linked_70 == nil { temp__1927000414__auto____2 = ifn_71.Invoke_O__O(arg_72) } else { temp__1927000414__auto____2 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1344000016__3 any = temp__1927000414__auto____2; var tmp1 any; var root_73 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = s__1344000016__3; if linked_74 == nil { tmp1 = ifn_75.Invoke_O__O(arg_76) } else { tmp1 = linked_74.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_77 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = s__1344000016__3; if linked_78 == nil { c__1927001037__auto____4 = ifn_79.Invoke_O__O(arg_80) } else { c__1927001037__auto____4 = linked_78.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_77, arg_80) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1344000018__6 any; var root_81 any = A_arbace_repr_go_print_A_const_25.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_82 == nil { b__1344000018__6 = ifn_83.Invoke_O__O(arg_84) } else { b__1344000018__6 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_81, arg_84) }; var tmp2 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_New_O_I_O(b__1344000018__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_112 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any; var root_117 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = b__1344000018__6; if linked_118 == nil { arg_115 = ifn_119.Invoke_O__O(arg_120) } else { arg_115 = linked_118.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_117, arg_120) }; var arg_116 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1344000015); var tmp5 any; var root_121 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = s__1344000016__3; if linked_122 == nil { tmp5 = ifn_123.Invoke_O__O(arg_124) } else { tmp5 = linked_122.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_121, arg_124) }; arg_116 = tmp4.Invoke_O__O(tmp5); if linked_113 == nil { return ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { return linked_113.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) } } else { var root_125 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any; var root_130 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = b__1344000018__6; if linked_131 == nil { arg_128 = ifn_132.Invoke_O__O(arg_133) } else { arg_128 = linked_131.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_130, arg_133) }; var arg_129 any; if linked_126 == nil { return ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { return linked_126.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) } } } else { var spec__4 any; var root_134 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1344000016__3; if linked_135 == nil { spec__4 = ifn_136.Invoke_O__O(arg_137) } else { spec__4 = linked_135.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_134, arg_137) }; var tmp6 any; var and__1927000168__auto____5 any; var root_138 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_140 lang.IFn


	if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = spec__4; if linked_139 == nil { and__1927000168__auto____5 = ifn_140.Invoke_O__O(arg_141) } else { and__1927000168__auto____5 = linked_139.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp7 any = A_arbace_repr_go_print_A_const_27; var tmp8 any; var root_142 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = spec__4; if linked_143 == nil { tmp8 = ifn_144.Invoke_O__O(arg_145) } else { tmp8 = linked_143.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_142, arg_145) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp6 = and__1927000168__auto____5 }
//line :55:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_146 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_148 lang.IFn



		if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_150 any; var root_151 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = spec__4; if linked_152 == nil { arg_150 = ifn_153.Invoke_O__O(arg_154) } else { arg_150 = linked_152.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_151, arg_154) }; if linked_147 == nil { m__5 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { m__5 = linked_147.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }
//line :55:1
		if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__5)) { var root_155 any = A_arbace_repr_go_print_A_const_36.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_160 any = A_arbace_repr_go_print_A_const_32.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_162 lang.IFn





			if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__5); if linked_161 == nil { arg_158 = ifn_162.Invoke_O__O(arg_163) } else { arg_158 = linked_161.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_160, arg_163) }
//line :55:1
			var arg_159 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1344000015); var tmp10 any; var root_164 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__1344000016__3; if linked_165 == nil { tmp10 = ifn_166.Invoke_O__O(arg_167) } else { tmp10 = linked_165.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_164, arg_167) }; arg_159 = tmp9.Invoke_O__O(tmp10); if linked_156 == nil { return ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { return linked_156.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) } } else { var tmp11 any; var root_168 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = s__1344000016__3; if linked_169 == nil { tmp11 = ifn_170.Invoke_O__O(arg_171) } else { tmp11 = linked_169.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_168, arg_171) }; s__1344000016__1 = tmp11; continue L1 } } else { var tmp12 any; var root_172 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = s__1344000016__3; if linked_173 == nil { tmp12 = ifn_174.Invoke_O__O(arg_175) } else { tmp12 = linked_173.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_172, arg_175) }; s__1344000016__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A) Ctor_O_I_O(c__b__1344000018 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1344000018 = c__b__1344000018; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A) Invoke_O__O(self any) any { { var i__1344000017__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1344000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1344000017__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_85 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_87 lang.IFn


	if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = spec__2; if linked_86 == nil { and__1927000168__auto____3 = ifn_87.Invoke_O__O(arg_88) } else { and__1927000168__auto____3 = linked_86.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_85, arg_88) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_repr_go_print_A_const_27; var tmp4 any; var root_89 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = spec__2; if linked_90 == nil { tmp4 = ifn_91.Invoke_O__O(arg_92) } else { tmp4 = linked_90.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_89, arg_92) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :55:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_93 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_95 lang.IFn



		if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_97 any; var root_98 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = spec__2; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { m__3 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { m__3 = linked_94.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_93, arg_96, arg_97) }
//line :55:1
		if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__3)) { var root_102 any = A_arbace_repr_go_print_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = t.F_b__1344000018; var arg_106 any; var root_107 any = A_arbace_repr_go_print_A_const_32.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_109 lang.IFn





			if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_repr_go_print_A_const_30.Invoke_O__O(m__3); if linked_108 == nil { arg_106 = ifn_109.Invoke_O__O(arg_110) } else { arg_106 = linked_108.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_107, arg_110) }
//line :55:1
			if linked_103 == nil { ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { linked_103.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }; i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000017__1); continue L1 } else { i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000017__1); continue L1 } } else { i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000017__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_repr_go_print_add_form_A_New() *A_arbace_repr_go_print_add_form_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_add_form_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_repr_go_print_add_form_A) Ctor() {}
//line :65:1
func (t *A_arbace_repr_go_print_add_form_A) Invoke_O_O_O_O__O(self, state__0, f__1, load_fn__2 any) any {


	var root_386 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_60; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_40; var tmp4 any; var root_395 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = state__0; if linked_396 == nil { tmp4 = ifn_397.Invoke_O__O(arg_398) } else { tmp4 = linked_396.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_395, arg_398) }; arg_389 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4)); if linked_387 == nil { ifn_388.Invoke_O__O(arg_389) } else { linked_387.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_386, arg_389) }
//line :65:1
	var tmp5 any; tmp41 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var o__6 any; var tmp6 any; var root_209 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_211 lang.IFn



		if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = f__1; if linked_210 == nil { tmp6 = ifn_211.Invoke_O__O(arg_212) } else { tmp6 = linked_210.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_209, arg_212) }; if jrt.J2g_Truth(tmp6) { var root_213 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = f__1; if linked_214 == nil { o__6 = ifn_215.Invoke_O__O(arg_216) } else { o__6 = linked_214.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_213, arg_216) } } else { o__6 = nil }
		if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_11) {
			var tmp7 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp8 any; var root_217 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var arg_221 any = A_arbace_repr_go_print_A_const_40; var arg_222 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var arg_223 any; var root_224 any = A_arbace_repr_go_print_A_const_41.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_repr_go_print_go_ns_aliases_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = f__1; if linked_225 == nil { arg_223 = ifn_226.Invoke_O__O(arg_227) } else { arg_223 = linked_225.(*A_arbace_repr_go_print_go_ns_aliases_A).Invoke_O_O__O(root_224, arg_227) }; if linked_218 == nil { tmp8 = ifn_219.Invoke_O_O_O_O__O(arg_220, arg_221, arg_222, arg_223) } else { tmp8 = linked_218.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_217, arg_220, arg_221, arg_222, arg_223) }; tmp5 = jrt.NN(tmp7).Reset_O__O(tmp8) } else {
//line :70:1
				if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_12) { tmp5 = nil } else { if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_13) { var seq_1344000030__7 any; var root_228 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_230 lang.IFn


					if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any; var root_232 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = f__1; if linked_233 == nil { arg_231 = ifn_234.Invoke_O__O(arg_235) } else { arg_231 = linked_233.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_232, arg_235) }; if linked_229 == nil { seq_1344000030__7 = ifn_230.Invoke_O__O(arg_231) } else { seq_1344000030__7 = linked_229.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_228, arg_231) }
//line :70:1
					var chunk_1344000031__8 any; var count_1344000032__9 int64 = 0; var i_1344000033__10 int64 = 0; L1: for {


						if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000033__10, count_1344000032__9) { var p__11 any = lang.Indexed_Cast(chunk_1344000031__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000033__10)); var tmp9 lang.IFn = lang.IFn_Cast(load_fn__2); var tmp10 any; var root_399 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = p__11; if linked_400 == nil { tmp10 = ifn_401.Invoke_O__O(arg_402) } else { tmp10 = linked_400.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_399, arg_402) }; tmp9.Invoke_O__O(tmp10); seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000033__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_236 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = seq_1344000030__7; if linked_237 == nil { temp__1927000414__auto____11 = ifn_238.Invoke_O__O(arg_239) } else { temp__1927000414__auto____11 = linked_237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_236, arg_239) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1344000030__12 any = temp__1927000414__auto____11; var tmp11 any; var root_240 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = seq_1344000030__12; if linked_241 == nil { tmp11 = ifn_242.Invoke_O__O(arg_243) } else { tmp11 = linked_241.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_240, arg_243) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_244 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = seq_1344000030__12; if linked_245 == nil { c__1927000678__auto____13 = ifn_246.Invoke_O__O(arg_247) } else { c__1927000678__auto____13 = linked_245.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_244, arg_247) }; var tmp12 any; var root_403 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = seq_1344000030__12; if linked_404 == nil { tmp12 = ifn_405.Invoke_O__O(arg_406) } else { tmp12 = linked_404.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_403, arg_406) }; seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__13 any; var root_248 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = seq_1344000030__12; if linked_249 == nil { p__13 = ifn_250.Invoke_O__O(arg_251) } else { p__13 = linked_249.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_248, arg_251) }; var tmp13 lang.IFn = lang.IFn_Cast(load_fn__2); var tmp14 any; var root_407 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = p__13; if linked_408 == nil { tmp14 = ifn_409.Invoke_O__O(arg_410) } else { tmp14 = linked_408.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_407, arg_410) }; tmp13.Invoke_O__O(tmp14); var tmp15 any; var root_411 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = seq_1344000030__12; if linked_412 == nil { tmp15 = ifn_413.Invoke_O__O(arg_414) } else { tmp15 = linked_412.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_411, arg_414) }; seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = tmp15, nil, 0, 0; continue L1 } } else { tmp5 = nil } }
//line :70:1
						break L1 } } else { if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_14) { var vec__1344000034__7 any = f__1; var seq__1344000035__8 any; var root_252 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_254 lang.IFn




							if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = vec__1344000034__7; if linked_253 == nil { seq__1344000035__8 = ifn_254.Invoke_O__O(arg_255) } else { seq__1344000035__8 = linked_253.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_252, arg_255) }
//line :70:1
							var first__1344000036__9 any; var root_256 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_258 lang.IFn




							if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = seq__1344000035__8; if linked_257 == nil { first__1344000036__9 = ifn_258.Invoke_O__O(arg_259) } else { first__1344000036__9 = linked_257.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_256, arg_259) }
//line :70:1
							var seq__1344000035__10 any; var root_260 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_262 lang.IFn




							if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = seq__1344000035__8; if linked_261 == nil { seq__1344000035__10 = ifn_262.Invoke_O__O(arg_263) } else { seq__1344000035__10 = linked_261.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_260, arg_263) }
//line :70:1
							var ___11 any = first__1344000036__9; var first__1344000036__12 any; var root_264 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_266 lang.IFn; _ = ___11




							if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = seq__1344000035__10; if linked_265 == nil { first__1344000036__12 = ifn_266.Invoke_O__O(arg_267) } else { first__1344000036__12 = linked_265.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_264, arg_267) }
//line :70:1
							var seq__1344000035__13 any; var root_268 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_270 lang.IFn




							if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = seq__1344000035__10; if linked_269 == nil { seq__1344000035__13 = ifn_270.Invoke_O__O(arg_271) } else { seq__1344000035__13 = linked_269.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_268, arg_271) }
//line :70:1
							var nm__14 any = first__1344000036__12; var opts__15 any = seq__1344000035__13; var tmp16 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_43.GetRawRoot__O()); var tmp18 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp19 any = A_arbace_repr_go_print_A_const_44; var tmp20 any; var root_280 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_282 lang.IFn





							if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_284 any = opts__15; if linked_281 == nil { tmp20 = ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { tmp20 = linked_281.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }; tmp5 = jrt.NN(tmp16).Reset_O__O(tmp17.Invoke_O_O_O_O_O__O(tmp18, tmp19, tmp20, A_arbace_repr_go_print_A_const_45, nm__14)) } else {
//line :70:1
								if lang.Util_Equiv_O_O__Z_NoInit(o__6, Lit_15) { var vec__1344000037__7 any = f__1; var seq__1344000038__8 any; var root_285 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_287 lang.IFn







									if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = vec__1344000037__7; if linked_286 == nil { seq__1344000038__8 = ifn_287.Invoke_O__O(arg_288) } else { seq__1344000038__8 = linked_286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_285, arg_288) }
//line :70:1
									var first__1344000039__9 any; var root_289 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_291 lang.IFn







									if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = seq__1344000038__8; if linked_290 == nil { first__1344000039__9 = ifn_291.Invoke_O__O(arg_292) } else { first__1344000039__9 = linked_290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_289, arg_292) }
//line :70:1
									var seq__1344000038__10 any; var root_293 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_295 lang.IFn







									if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = seq__1344000038__8; if linked_294 == nil { seq__1344000038__10 = ifn_295.Invoke_O__O(arg_296) } else { seq__1344000038__10 = linked_294.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_293, arg_296) }
//line :70:1
									var ___11_2 any = first__1344000039__9; var first__1344000039__12 any; var root_297 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_299 lang.IFn; _ = ___11_2







									if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = seq__1344000038__10; if linked_298 == nil { first__1344000039__12 = ifn_299.Invoke_O__O(arg_300) } else { first__1344000039__12 = linked_298.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_297, arg_300) }
//line :70:1
									var seq__1344000038__13 any; var root_301 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_303 lang.IFn







									if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = seq__1344000038__10; if linked_302 == nil { seq__1344000038__13 = ifn_303.Invoke_O__O(arg_304) } else { seq__1344000038__13 = linked_302.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_301, arg_304) }
//line :70:1
									var nm__14_2 any = first__1344000039__12; var opts__15_2 any = seq__1344000038__13; var tmp21 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp22 any; var root_305 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_307 lang.IFn








									if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var arg_309 any = A_arbace_repr_go_print_A_const_46; var arg_310 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var arg_311 any; var tmp23 any = A_arbace_repr_go_print_A_const_45; var tmp24 any = A_arbace_repr_go_print_A_const_47; var tmp25 any = A_arbace_repr_go_print_A_const_48; var tmp26 any; var root_312 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_repr_go_print_A_const_15.GetRawRoot__O(); var arg_316 any = opts__15_2; if linked_313 == nil { tmp26 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp26 = linked_313.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_repr_go_print_A_const_49; var tmp29 any = lang.PersistentVector_EMPTY.Ref(); var tmp30 any = A_arbace_repr_go_print_A_const_50; arg_311 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, nm__14_2, tmp24, f__1, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_repr_go_print_A_const_51.Get__O())); if linked_306 == nil { tmp22 = ifn_307.Invoke_O_O_O_O__O(arg_308, arg_309, arg_310, arg_311) } else { tmp22 = linked_306.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_305, arg_308, arg_309, arg_310, arg_311) }; tmp5 = jrt.NN(tmp21).Reset_O__O(tmp22) } else {
//line :70:1
										var tmp31 any; var and__1927000168__auto____7 any; var root_317 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_319 lang.IFn










										if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = f__1; if linked_318 == nil { and__1927000168__auto____7 = ifn_319.Invoke_O__O(arg_320) } else { and__1927000168__auto____7 = linked_318.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_317, arg_320) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var root_321 any = A_arbace_repr_go_print_A_const_52.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any; var root_326 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = o__6; if linked_327 == nil { arg_324 = ifn_328.Invoke_O__O(arg_329) } else { arg_324 = linked_327.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_326, arg_329) }; var arg_325 any = Lit_16; if linked_322 == nil { tmp31 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { tmp31 = linked_322.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_321, arg_324, arg_325) } } else { tmp31 = and__1927000168__auto____7 }
//line :70:1
										if jrt.J2g_Truth(tmp31) {











											var tmp32 any; var root_330 any = A_arbace_repr_go_print_A_const_53.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any; var tmp33 *lang.Keyword = A_arbace_repr_go_print_A_const_46; var tmp34 any; var root_334 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = state__0; if linked_335 == nil { tmp34 = ifn_336.Invoke_O__O(arg_337) } else { tmp34 = linked_335.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_334, arg_337) }; arg_333 = tmp33.Invoke_O__O(tmp34); if linked_331 == nil { tmp32 = ifn_332.Invoke_O__O(arg_333) } else { tmp32 = linked_331.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_330, arg_333) }; if jrt.J2g_Truth(tmp32) { var tmp35 any; var root_338 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_340 lang.IFn
												if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_55.GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var arg_342 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_56, f__1)); if linked_339 == nil { tmp35 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { tmp35 = linked_339.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }
//line :82:1
												panic(jrt.Thrown(jrt.Throwable_Cast(tmp35))) } else {

													var tmp36 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp37 any; var root_347 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var arg_351 any = A_arbace_repr_go_print_A_const_46; var arg_352 any; var tmp38 any = A_arbace_repr_go_print_add_form_fn__1344000040_A_New_O(f__1); var tmp39 *jrt.Class; var fncls__373 *jrt.Class = A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class; if fncls__373 == nil { var fncls__373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class = fncls__373d; tmp39 = fncls__373d } else { tmp39 = fncls__373 }; arg_352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); if linked_348 == nil { tmp37 = ifn_349.Invoke_O_O_O__O(arg_350, arg_351, arg_352) } else { tmp37 = linked_348.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_347, arg_350, arg_351, arg_352) }; tmp5 = jrt.NN(tmp36).Reset_O__O(tmp37) } } else {
//line :70:1
														if lang.Util_Identical_O_O__Z_NoInit(f__1, nil) { tmp5 = nil } else { if A_arbace_repr_go_print_A_const_59 != nil { var tmp40 any; var root_374 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_376 lang.IFn















															if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_55.GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var arg_378 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_56, f__1)); if linked_375 == nil { tmp40 = ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { tmp40 = linked_375.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) }
//line :70:1
															panic(jrt.Thrown(jrt.Throwable_Cast(tmp40))) } else { tmp5 = nil } } } } } } } } }; return nil }()
//line :65:1
	var root_383 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_385 lang.IFn


	if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; if linked_384 == nil { ifn_385.Invoke__O() } else { linked_384.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_383) }
//line :65:1
	if tmp41 != nil { panic(tmp41) }; return tmp5
}

















func A_arbace_repr_go_print_add_form_fn__1344000040_A_New_O(p0 any) *A_arbace_repr_go_print_add_form_fn__1344000040_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_add_form_fn__1344000040_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_repr_go_print_add_form_fn__1344000040_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :84:1
func (t *A_arbace_repr_go_print_add_form_fn__1344000040_A) Invoke_O_O__O(self, fs__1 any) any { var root_353 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any; var root_358 any = A_arbace_repr_go_print_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = fs__1; if linked_359 == nil { arg_356 = ifn_360.Invoke_O__O(arg_361) } else { arg_356 = linked_359.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_358, arg_361) }; var arg_357 any; var root_362 any = A_arbace_repr_go_print_A_const_39.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var root_369 any = A_arbace_repr_go_print_A_const_58.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = fs__1; if linked_370 == nil { arg_365 = ifn_371.Invoke_O__O(arg_372) } else { arg_365 = linked_370.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_369, arg_372) }; var arg_366 any = A_arbace_repr_go_print_A_const_49; var arg_367 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var arg_368 any = t.F_f; if linked_363 == nil { arg_357 = ifn_364.Invoke_O_O_O_O__O(arg_365, arg_366, arg_367, arg_368) } else { arg_357 = linked_363.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_362, arg_365, arg_366, arg_367, arg_368) }; if linked_354 == nil { return ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { return linked_354.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } }



func A_arbace_repr_go_print_new_package_state_A_New() *A_arbace_repr_go_print_new_package_state_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_new_package_state_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_repr_go_print_new_package_state_A) Ctor() {}
//line :88:1
func (t *A_arbace_repr_go_print_new_package_state_A) Invoke_O__O(self any) any {
	var root_415 any = A_arbace_repr_go_print_A_const_61.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_44, nil, A_arbace_repr_go_print_A_const_45, nil, A_arbace_repr_go_print_A_const_46, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_go_print_A_const_40, A_arbace_repr_go_print_A_const_62)); if linked_416 == nil { return ifn_417.Invoke_O__O(arg_418) } else { return linked_416.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_415, arg_418)
	} }
func A_arbace_repr_go_print_collect_forms_A_New() *A_arbace_repr_go_print_collect_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_repr_go_print_collect_forms_A) Ctor() {}
//line :91:1
func (t *A_arbace_repr_go_print_collect_forms_A) Invoke_O_O__O(self, forms__0 any) any { var state__2 any; var root_419 any = A_arbace_repr_go_print_A_const_63.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, A_arbace_repr_go_print_new_package_state_A_fn_class); var ifn_421 lang.IFn; if



	linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; if linked_420 == nil { state__2 = ifn_421.Invoke__O() } else { state__2 = linked_420.(*A_arbace_repr_go_print_new_package_state_A).Invoke_O__O(root_419) }; var seq_1344000044__3 any; var root_431 any = /*line :91:1*/A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_433 lang.IFn; if




	linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = forms__0; if linked_432 == nil { seq_1344000044__3 = ifn_433.Invoke_O__O(arg_434) } else { seq_1344000044__3 = linked_432.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_431, arg_434) }; var chunk_1344000045__4 any; var count_1344000046__5 int64 = 0; var i_1344000047__6 int64 = 0; L1:
//line :91:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000047__6, count_1344000046__5) { var f__7 any = lang.Indexed_Cast(chunk_1344000045__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000047__6)); var root_451 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_453 lang.IFn
			if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = state__2; var arg_455 any = f__7; var arg_456 any; var tmp1 any = A_arbace_repr_go_print_collect_forms_fn__1344000048_A_New(); var tmp2 *jrt.Class; var fncls__462 *jrt.Class = A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class; if fncls__462 == nil { var fncls__462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class = fncls__462d; tmp2 = fncls__462d } else { tmp2 = fncls__462 }; arg_456 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_452 == nil { ifn_453.Invoke_O_O_O__O(arg_454, arg_455, arg_456) } else { linked_452.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_451, arg_454, arg_455, arg_456) }
//line :96:1
			seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000047__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_435 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = seq_1344000044__3; if linked_436 == nil { temp__1927000414__auto____7 = ifn_437.Invoke_O__O(arg_438) } else { temp__1927000414__auto____7 = linked_436.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_435, arg_438) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1344000044__8 any = temp__1927000414__auto____7; var tmp3 any; var root_439 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = seq_1344000044__8; if linked_440 == nil { tmp3 = ifn_441.Invoke_O__O(arg_442) } else { tmp3 = linked_440.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_439, arg_442) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____9 any; var root_443 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_1344000044__8; if linked_444 == nil { c__1927000678__auto____9 = ifn_445.Invoke_O__O(arg_446) } else { c__1927000678__auto____9 = linked_444.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_443, arg_446) }; var tmp4 any; var root_463 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = seq_1344000044__8; if linked_464 == nil { tmp4 = ifn_465.Invoke_O__O(arg_466) } else { tmp4 = linked_464.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_463, arg_466) }; seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = tmp4, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__9 any; var root_447 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_1344000044__8; if linked_448 == nil { f__9 = ifn_449.Invoke_O__O(arg_450) } else { f__9 = linked_448.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_447, arg_450) }
				var root_467 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = state__2; var arg_471 any = f__9; var arg_472 any; var tmp5 any = A_arbace_repr_go_print_collect_forms_fn__1344000050_A_New(); var tmp6 *jrt.Class; var fncls__478 *jrt.Class = A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class; if fncls__478 == nil { var fncls__478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class = fncls__478d; tmp6 = fncls__478d } else { tmp6 = fncls__478 }; arg_472 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_468 == nil { ifn_469.Invoke_O_O_O__O(arg_470, arg_471, arg_472) } else { linked_468.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_467, arg_470, arg_471, arg_472) }
//line :96:1
				var tmp7 any; var root_479 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1344000044__8; if linked_480 == nil { tmp7 = ifn_481.Invoke_O__O(arg_482) } else { tmp7 = linked_480.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_479, arg_482) }; seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = tmp7, nil, 0, 0; continue L1 } } }
//line :91:1
		break L1 }; var root_422 any =






	A_arbace_repr_go_print_A_const_64.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any; var root_427 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = state__2; if linked_428 == nil { arg_425 = ifn_429.Invoke_O__O(arg_430) } else { arg_425 = linked_428.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_427, arg_430) }; var arg_426 any = A_arbace_repr_go_print_A_const_40; if linked_423 == nil { return ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { return linked_423.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) } }
//line :97:1
func A_arbace_repr_go_print_collect_forms_fn__1344000048_A_New() *A_arbace_repr_go_print_collect_forms_fn__1344000048_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_fn__1344000048_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000048_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000048_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 any; var root_457 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(); var arg_461 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_66, p__1)); if linked_458 == nil { tmp1 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { tmp1 = linked_458.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }
//line :97:1
func A_arbace_repr_go_print_collect_forms_fn__1344000050_A_New() *A_arbace_repr_go_print_collect_forms_fn__1344000050_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_fn__1344000050_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000050_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000050_A) Invoke_O_O__O(self, p__1 any) any { var tmp1 any; var root_473 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(); var arg_477 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_66, p__1)); if linked_474 == nil { tmp1 = ifn_475.Invoke_O_O__O(arg_476, arg_477) } else { tmp1 = linked_474.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_473, arg_476, arg_477) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_repr_go_print_collect_A_New() *A_arbace_repr_go_print_collect_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Ctor() {}
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Invoke_O_O_O__O(self, path__0, read_fn__1 any) any { var state__3 any; var root_483 any = A_arbace_repr_go_print_A_const_63.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, A_arbace_repr_go_print_new_package_state_A_fn_class); var ifn_485 lang.IFn; if







	linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; if linked_484 == nil { state__3 = ifn_485.Invoke__O() } else { state__3 = linked_484.(*A_arbace_repr_go_print_new_package_state_A).Invoke_O__O(root_483) }; var root__4 any; var root_486 any = /*line :100:1*/A_arbace_repr_go_print_A_const_61.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_488 lang.IFn; if








	linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any; if linked_487 == nil { root__4 = ifn_488.Invoke_O__O(arg_489) } else { root__4 = linked_487.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_486, arg_489) }; var body_walk__5 /*line :100:1*/*A_arbace_repr_go_print_collect_walk__1344000054_A = A_arbace_repr_go_print_collect_walk__1344000054_A_New_O_O_O(state__3, read_fn__1, root__4); var walk__5 any; var tmp1 *jrt.Class; var fncls__671 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class; if fncls__671 == nil { var fncls__671d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class = fncls__671d; tmp1 = fncls__671d } else { tmp1 = fncls__671 }; walk__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__5), tmp1, nil); var tmp2 lang.IFn =





















	lang.IFn_Cast(walk__5); var tmp3 any; var root_681 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = path__0; if linked_682 == nil { tmp3 = ifn_683.Invoke_O__O(arg_684) } else { tmp3 = linked_682.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_681, arg_684) }; tmp2.Invoke_O__O(jrt.File_New_String(jrt.String_Cast(tmp3))); var root_672 any =
	A_arbace_repr_go_print_A_const_64.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any; var root_677 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = state__3; if linked_678 == nil { arg_675 = ifn_679.Invoke_O__O(arg_680) } else { arg_675 = linked_678.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_677, arg_680) }; var arg_676 any = A_arbace_repr_go_print_A_const_40; if linked_673 == nil { return ifn_674.Invoke_O_O__O(arg_675, arg_676) } else { return linked_673.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_672, arg_675, arg_676) } }
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Invoke_O_O__O(self, path__0 any) any {





	var root_685 any = A_arbace_repr_go_print_A_const_75.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, A_arbace_repr_go_print_collect_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = path__0; var arg_689 any = A_arbace_repr_go_print_A_const_76.GetRawRoot__O(); if linked_686 == nil { return ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { return linked_686.(*A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_685, arg_688, arg_689)
	}
}

func A_arbace_repr_go_print_collect_walk__1344000054_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :110:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_A) Ctor_O_O_O(c__state, c__read_fn, c__root any) { t.F_state = c__state; t.F_read_fn = c__read_fn; t.F_root = c__root }
//line :110:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_A) Invoke_O_O__O(self, file__1 any) any { { var seq_1344000055__2 any; var root_490 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_492 lang.IFn
													if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any; var root_498 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_51; var arg_501 any = tmp1.Invoke_O_O__O(tmp2, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref()); if linked_499 == nil { ifn_500.Invoke_O__O(arg_501) } else { linked_499.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_498, arg_501) }; var tmp3 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_New_O_O(t.F_read_fn, file__1); var tmp4 *jrt.Class; var fncls__497 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class; if fncls__497 == nil { var fncls__497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class = fncls__497d; tmp4 = fncls__497d } else { tmp4 = fncls__497 }; arg_493 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); if linked_491 == nil { seq_1344000055__2 = ifn_492.Invoke_O__O(arg_493) } else { seq_1344000055__2 = linked_491.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_490, arg_493) }
//line :110:1
	var chunk_1344000056__3 any; var count_1344000057__4 int64 = 0; var i_1344000058__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000058__5, count_1344000057__4) { var f__6 any = lang.Indexed_Cast(chunk_1344000056__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000058__5)); var tmp5 any; var and__1927000168__auto____7 bool; var tmp6 any; var root_548 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_550 lang.IFn
			if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = t.F_root; if linked_549 == nil { tmp6 = ifn_550.Invoke_O__O(arg_551) } else { tmp6 = linked_549.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_548, arg_551) }; and__1927000168__auto____7 = lang.Util_Identical_O_O__Z_NoInit(tmp6, nil); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_552 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = f__6; if linked_553 == nil { and__1927000168__auto____8 = ifn_554.Invoke_O__O(arg_555) } else { and__1927000168__auto____8 = linked_553.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_552, arg_555) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp7 any = A_arbace_repr_go_print_A_const_69; var tmp8 any; var root_556 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = f__6; if linked_557 == nil { tmp8 = ifn_558.Invoke_O__O(arg_559) } else { tmp8 = linked_557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_556, arg_559) }; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp5 = and__1927000168__auto____8 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp5) { var depth__7 int32; var tmp9 any; var root_560 any = A_arbace_repr_go_print_A_const_70.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_562 lang.IFn
				if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = A_arbace_repr_go_print_A_const_71; var arg_564 any; var root_565 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any; var root_569 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = f__6; if linked_570 == nil { arg_568 = ifn_571.Invoke_O__O(arg_572) } else { arg_568 = linked_570.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_569, arg_572) }; if linked_566 == nil { arg_564 = ifn_567.Invoke_O__O(arg_568) } else { arg_564 = linked_566.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_565, arg_568) }; if linked_561 == nil { tmp9 = ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { tmp9 = linked_561.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) }; depth__7 = lang.RT_Count_O__I_NoInit(tmp9)
				var root_573 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = t.F_root; var arg_577 any; var tmp10 any; var root_578 any = A_arbace_repr_go_print_A_const_74.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var tmp11 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_New(); var tmp12 *jrt.Class; var fncls__583 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class; if fncls__583 == nil { var fncls__583d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class = fncls__583d; tmp12 = fncls__583d } else { tmp12 = fncls__583 }; arg_581 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_582 any = jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref(); if linked_579 == nil { tmp10 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { tmp10 = linked_579.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) }; arg_577 = lang.RT_Nth_O_I__O_NoInit(tmp10, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(depth__7)))); if linked_574 == nil { ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { linked_574.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_573, arg_576, arg_577)
				} }
			var root_584 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_print_A_const_51; var arg_587 any = tmp13.Invoke_O_O__O(tmp14, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref()); if linked_585 == nil { ifn_586.Invoke_O__O(arg_587) } else { linked_585.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_584, arg_587) }; var tmp15 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_New_O_O_O_O_O(f__6, self, t.F_state, file__1, t.F_root); var tmp16 *jrt.Class; var fncls__547 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class; if fncls__547 == nil { var fncls__547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class = fncls__547d; tmp16 = fncls__547d } else { tmp16 = fncls__547 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :111:1
			seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000058__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_507 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_1344000055__2; if linked_508 == nil { temp__1927000414__auto____6 = ifn_509.Invoke_O__O(arg_510) } else { temp__1927000414__auto____6 = linked_508.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_507, arg_510) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1344000055__7 any = temp__1927000414__auto____6; var tmp17 any; var root_511 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1344000055__7; if linked_512 == nil { tmp17 = ifn_513.Invoke_O__O(arg_514) } else { tmp17 = linked_512.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_511, arg_514) }; if jrt.J2g_Truth(tmp17) { var c__1927000678__auto____8 any; var root_515 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = seq_1344000055__7; if linked_516 == nil { c__1927000678__auto____8 = ifn_517.Invoke_O__O(arg_518) } else { c__1927000678__auto____8 = linked_516.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_515, arg_518) }; var tmp18 any; var root_593 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = seq_1344000055__7; if linked_594 == nil { tmp18 = ifn_595.Invoke_O__O(arg_596) } else { tmp18 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_593, arg_596) }; seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = tmp18, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__8 any; var root_519 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = seq_1344000055__7; if linked_520 == nil { f__8 = ifn_521.Invoke_O__O(arg_522) } else { f__8 = linked_520.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_519, arg_522) }
				var tmp19 any; var and__1927000168__auto____9 bool; var tmp20 any; var root_622 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = t.F_root; if linked_623 == nil { tmp20 = ifn_624.Invoke_O__O(arg_625) } else { tmp20 = linked_623.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_622, arg_625) }; and__1927000168__auto____9 = lang.Util_Identical_O_O__Z_NoInit(tmp20, nil); if and__1927000168__auto____9 { var and__1927000168__auto____10 any; var root_626 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = f__8; if linked_627 == nil { and__1927000168__auto____10 = ifn_628.Invoke_O__O(arg_629) } else { and__1927000168__auto____10 = linked_627.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_626, arg_629) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp21 any = A_arbace_repr_go_print_A_const_69; var tmp22 any; var root_630 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = f__8; if linked_631 == nil { tmp22 = ifn_632.Invoke_O__O(arg_633) } else { tmp22 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; tmp19 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp21, tmp22)).Ref() } else { tmp19 = and__1927000168__auto____10 } } else { tmp19 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp19) { var depth__9 int32; var tmp23 any; var root_634 any = A_arbace_repr_go_print_A_const_70.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_636 lang.IFn
					if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = A_arbace_repr_go_print_A_const_71; var arg_638 any; var root_639 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any; var root_643 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = f__8; if linked_644 == nil { arg_642 = ifn_645.Invoke_O__O(arg_646) } else { arg_642 = linked_644.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_643, arg_646) }; if linked_640 == nil { arg_638 = ifn_641.Invoke_O__O(arg_642) } else { arg_638 = linked_640.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_639, arg_642) }; if linked_635 == nil { tmp23 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp23 = linked_635.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; depth__9 = lang.RT_Count_O__I_NoInit(tmp23)
					var root_647 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = t.F_root; var arg_651 any; var tmp24 any; var root_652 any = A_arbace_repr_go_print_A_const_74.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any; var tmp25 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_New(); var tmp26 *jrt.Class; var fncls__657 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class; if fncls__657 == nil { var fncls__657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class = fncls__657d; tmp26 = fncls__657d } else { tmp26 = fncls__657 }; arg_655 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_656 any = jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref(); if linked_653 == nil { tmp24 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { tmp24 = linked_653.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; arg_651 = lang.RT_Nth_O_I__O_NoInit(tmp24, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(depth__9)))); if linked_648 == nil { ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { linked_648.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_647, arg_650, arg_651)
					} }
				var root_658 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp28 any = A_arbace_repr_go_print_A_const_51; var arg_661 any = tmp27.Invoke_O_O__O(tmp28, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref()); if linked_659 == nil { ifn_660.Invoke_O__O(arg_661) } else { linked_659.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_658, arg_661) }; var tmp29 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_New_O_O_O_O_O(self, t.F_state, file__1, f__8, t.F_root); var tmp30 *jrt.Class; var fncls__621 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class; if fncls__621 == nil { var fncls__621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class = fncls__621d; tmp30 = fncls__621d } else { tmp30 = fncls__621 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil).Invoke__O()
//line :111:1
				var tmp31 any; var root_667 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq_1344000055__7; if linked_668 == nil { tmp31 = ifn_669.Invoke_O__O(arg_670) } else { tmp31 = linked_668.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_667, arg_670) }; seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = tmp31, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :110:1*/panic("j2g: unreachable") }
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :111:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A) Ctor_O_O(c__read_fn, c__file any) { t.F_read_fn = c__read_fn; t.F_file = c__file }
//line :111:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_read_fn; t.F_read_fn = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_file; t.F_file = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var root_494 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; if linked_495 == nil { ifn_496.Invoke__O() } else { linked_495.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_494) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_New() *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A) Ctor() {}
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A) Invoke_O_O__O(self, p1__1344000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1344000053_SHARP___1)).GetParentFile__File().Ref() }
//line :114:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_New() *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A) Ctor() {}
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A) Invoke_O_O__O(self, p1__1344000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1344000053_SHARP___1)).GetParentFile__File().Ref() }

func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A) Ctor_O_O_O_O_O(c__f, c__walk, c__state, c__file, c__root any) { t.F_f = c__f; t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_root = c__root }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_523 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var t_ any = t.F_state; t.F_state = nil; arg_526 = t_; var arg_527 any; var t__2 any = t.F_f; t.F_f = nil; arg_527 = t__2; var arg_528 any; var tmp2 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp3 *jrt.Class; var fncls__543 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class
														if fncls__543 == nil { var fncls__543d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class = fncls__543d; tmp3 = fncls__543d } else { tmp3 = fncls__543 }; arg_528 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :117:1
		if linked_524 == nil { tmp1 = ifn_525.Invoke_O_O_O__O(arg_526, arg_527, arg_528) } else { tmp1 = linked_524.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_523, arg_526, arg_527, arg_528) } }
//line :116:1
	return nil }(); var root_544 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; if linked_545 == nil { ifn_546.Invoke__O() } else { linked_545.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_544) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :116:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A) Ctor_O_O_O_O_O(c__walk, c__state, c__file, c__f, c__root any) { t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_f = c__f; t.F_root = c__root }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_597 any = A_arbace_repr_go_print_A_const_65.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, A_arbace_repr_go_print_add_form_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var t_ any = t.F_state; t.F_state = nil; arg_600 = t_; var arg_601 any; var t__2 any = t.F_f; t.F_f = nil; arg_601 = t__2; var arg_602 any; var tmp2 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp3 *jrt.Class; var fncls__617 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class
														if fncls__617 == nil { var fncls__617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class = fncls__617d; tmp3 = fncls__617d } else { tmp3 = fncls__617 }; arg_602 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :117:1
		if linked_598 == nil { tmp1 = ifn_599.Invoke_O_O_O__O(arg_600, arg_601, arg_602) } else { tmp1 = linked_598.(*A_arbace_repr_go_print_add_form_A).Invoke_O_O_O_O__O(root_597, arg_600, arg_601, arg_602) } }
//line :116:1
	return nil }(); var root_618 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; if linked_619 == nil { ifn_620.Invoke__O() } else { linked_619.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_618) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; var tmp3 any; var root_529 any = A_arbace_repr_go_print_A_const_52.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = p__1; var arg_533 any = Lit_10; if linked_530 == nil { tmp3 = ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { tmp3 = linked_530.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_529, arg_532, arg_533) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_534 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_536 lang.IFn
		if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = t.F_root; if linked_535 == nil { tmp4 = ifn_536.Invoke_O__O(arg_537) } else { tmp4 = linked_535.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_534, arg_537) }
//line :119:1
		var tmp5 *jrt.File = jrt.File_Cast(tmp4); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp7 any; var root_538 any = A_arbace_repr_go_print_A_const_67.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_540 lang.IFn
		if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = p__1; var arg_542 any = A_arbace_repr_go_print_A_const_68; if linked_539 == nil { tmp7 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { tmp7 = linked_539.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }
//line :119:1
		tmp2 = jrt.File_New_File_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref()) }
//line :118:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; var tmp3 any; var root_603 any = A_arbace_repr_go_print_A_const_52.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = p__1; var arg_607 any = Lit_10; if linked_604 == nil { tmp3 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { tmp3 = linked_604.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_608 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_610 lang.IFn
		if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = t.F_root; if linked_609 == nil { tmp4 = ifn_610.Invoke_O__O(arg_611) } else { tmp4 = linked_609.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_608, arg_611) }
//line :119:1
		var tmp5 *jrt.File = jrt.File_Cast(tmp4); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp7 any; var root_612 any = A_arbace_repr_go_print_A_const_67.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_614 lang.IFn
		if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = p__1; var arg_616 any = A_arbace_repr_go_print_A_const_68; if linked_613 == nil { tmp7 = ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { tmp7 = linked_613.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) }
//line :119:1
		tmp2 = jrt.File_New_File_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref())
}







func A_arbace_repr_go_print_name_text_A_New() *A_arbace_repr_go_print_name_text_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_name_text_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_repr_go_print_name_text_A) Ctor() {}
//line :128:1
func (t *A_arbace_repr_go_print_name_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_690 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = x__0; if linked_691 == nil { and__1927000168__auto____2 = ifn_692.Invoke_O__O(arg_693) } else { and__1927000168__auto____2 = linked_691.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_690, arg_693) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_repr_go_print_A_const_77; var tmp3 any; var root_694 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = x__0; if linked_695 == nil { tmp3 = ifn_696.Invoke_O__O(arg_697) } else { tmp3 = linked_695.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_694, arg_697) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_698 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any; var root_702 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = x__0; if linked_703 == nil { arg_701 = ifn_704.Invoke_O__O(arg_705) } else { arg_701 = linked_703.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_702, arg_705) }; if linked_699 == nil { return ifn_700.Invoke_O__O(arg_701) } else { return linked_699.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_698, arg_701) } } else { var root_706 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = x__0; if linked_707 == nil { return ifn_708.Invoke_O__O(arg_709) } else { return linked_707.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_706, arg_709)
	} } }
func A_arbace_repr_go_print_import_spec_A_New() *A_arbace_repr_go_print_import_spec_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_import_spec_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_repr_go_print_import_spec_A) Ctor() {}
//line :133:1
func (t *A_arbace_repr_go_print_import_spec_A) Invoke_O_O__O(self, v__0 any) any { var vec__1344000076__2 any = v__0; var nm__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000076__2, lang.RT_IntCast_J__I_NoInit(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000076__2, lang.RT_IntCast_J__I_NoInit(1), nil); var explicit_QMARK___5 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_78; var or__1927000174__auto____5 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)); if

	jrt.J2g_Truth(or__1927000174__auto____5) { explicit_QMARK___5 = or__1927000174__auto____5 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_79); var tmp3 any; var root_718 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = nm__3; if linked_719 == nil { tmp3 = ifn_720.Invoke_O__O(arg_721) } else { tmp3 = linked_719.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_718, arg_721) }; explicit_QMARK___5 = tmp2.Invoke_O__O(tmp3) }; if
	jrt.J2g_Truth(explicit_QMARK___5) { var root_725 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var root_729 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = nm__3; if linked_730 == nil { arg_728 = ifn_731.Invoke_O__O(arg_732) } else { arg_728 = linked_730.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_729, arg_732) }; if linked_726 == nil { ifn_727.Invoke_O__O(arg_728) } else { linked_726.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_725, arg_728) }; var root_722 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; if linked_723 == nil { ifn_724.Invoke__O() } else { linked_723.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_722) } }; var root_710 any =
	A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any; var root_714 any = A_arbace_repr_go_print_A_const_81.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_go_string_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = path__4; if linked_715 == nil { arg_713 = ifn_716.Invoke_O__O(arg_717) } else { arg_713 = linked_715.(*aot_arbace_repr_go_print_text.A_arbace_repr_go_print_text_go_string_A).Invoke_O_O__O(root_714, arg_717) }; if linked_711 == nil { return ifn_712.Invoke_O__O(arg_713) } else { return linked_711.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_710, arg_713) } }

func A_arbace_repr_go_print_write_import_decl_A_New() *A_arbace_repr_go_print_write_import_decl_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_import_decl_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_repr_go_print_write_import_decl_A) Ctor() {}
//line :139:1
func (t *A_arbace_repr_go_print_write_import_decl_A) Invoke_O_O__O(self, specs__0 any) any {
	if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(specs__0))) {
		var root_741 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = Lit_100; if linked_742 == nil { ifn_743.Invoke_O__O(arg_744) } else { linked_742.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_741, arg_744) }; var root_745 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; if linked_746 == nil { ifn_747.Invoke__O() } else { linked_746.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_745) }; var root_748 any = A_arbace_repr_go_print_A_const_86.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, A_arbace_repr_go_print_import_spec_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any; var root_752 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = specs__0; if linked_753 == nil { arg_751 = ifn_754.Invoke_O__O(arg_755) } else { arg_751 = linked_753.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_752, arg_755) }; if linked_749 == nil { ifn_750.Invoke_O__O(arg_751) } else { linked_749.(*A_arbace_repr_go_print_import_spec_A).Invoke_O_O__O(root_748, arg_751) }; var root_733 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = A_arbace_repr_go_print_A_const_85; if linked_734 == nil { return ifn_735.Invoke_O__O(arg_736) } else { return linked_734.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_733, arg_736) } } else {
			var root_756 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = Lit_100; if linked_757 == nil { ifn_758.Invoke_O__O(arg_759) } else { linked_757.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_756, arg_759) }; var root_760 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; if linked_761 == nil { ifn_762.Invoke__O() } else { linked_761.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_760) }; var root_763 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = Lit_101; if linked_764 == nil { ifn_765.Invoke_O__O(arg_766) } else { linked_764.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_763, arg_766) }
			var root_767 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = A_arbace_repr_go_print_A_const_68; if linked_768 == nil { ifn_769.Invoke_O__O(arg_770) } else { linked_768.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_767, arg_770) }
//line :140:1
			var G__1344000083__2_ any = specs__0; var vec__1344000084__3 any = G__1344000083__2_; var seq__1344000085__4 any; var root_771 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_773 lang.IFn



			if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = vec__1344000084__3; if linked_772 == nil { seq__1344000085__4 = ifn_773.Invoke_O__O(arg_774) } else { seq__1344000085__4 = linked_772.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_771, arg_774) }
//line :140:1
			var first__1344000086__5 any; var root_775 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_777 lang.IFn



			if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = seq__1344000085__4; if linked_776 == nil { first__1344000086__5 = ifn_777.Invoke_O__O(arg_778) } else { first__1344000086__5 = linked_776.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_775, arg_778) }
//line :140:1
			var seq__1344000085__6 any; var root_779 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_781 lang.IFn



			if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = seq__1344000085__4; if linked_780 == nil { seq__1344000085__6 = ifn_781.Invoke_O__O(arg_782) } else { seq__1344000085__6 = linked_780.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_779, arg_782) }
//line :140:1
			var v__7 any = first__1344000086__5; var more__8 any = seq__1344000085__6; var prev__9 any; var G__1344000083__10_ any = G__1344000083__2_; var prev__11 any = prev__9; _ = v__7; _ = more__8; L1: for { var vec__1344000087__12 any = G__1344000083__10_; var seq__1344000088__13 any; var root_783 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_785 lang.IFn



				if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = vec__1344000087__12; if linked_784 == nil { seq__1344000088__13 = ifn_785.Invoke_O__O(arg_786) } else { seq__1344000088__13 = linked_784.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_783, arg_786) }
//line :140:1
				var first__1344000089__14 any; var root_787 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_789 lang.IFn



				if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = seq__1344000088__13; if linked_788 == nil { first__1344000089__14 = ifn_789.Invoke_O__O(arg_790) } else { first__1344000089__14 = linked_788.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_787, arg_790) }
//line :140:1
				var seq__1344000088__15 any; var root_791 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_793 lang.IFn



				if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = seq__1344000088__13; if linked_792 == nil { seq__1344000088__15 = ifn_793.Invoke_O__O(arg_794) } else { seq__1344000088__15 = linked_792.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_791, arg_794) }
//line :140:1
				var v__16 any = first__1344000089__14
				var more__17 any = seq__1344000088__15
				var prev__18 any = prev__11


				if jrt.J2g_Truth(v__16) {


					var tmp1 any; var and__1927000168__auto____19 any = prev__18; if jrt.J2g_Truth(and__1927000168__auto____19) { var tmp2 any; var root_799 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any; var root_803 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = v__16; if linked_804 == nil { arg_802 = ifn_805.Invoke_O__O(arg_806) } else { arg_802 = linked_804.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_803, arg_806) }; if linked_800 == nil { tmp2 = ifn_801.Invoke_O__O(arg_802) } else { tmp2 = linked_800.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_799, arg_802) }; var tmp3 any = tmp2; var tmp4 any; var root_807 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any; var root_811 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = prev__18; if linked_812 == nil { arg_810 = ifn_813.Invoke_O__O(arg_814) } else { arg_810 = linked_812.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_811, arg_814) }; if linked_808 == nil { tmp4 = ifn_809.Invoke_O__O(arg_810) } else { tmp4 = linked_808.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_807, arg_810) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(tmp3, tmp4)))).Ref() } else { tmp1 = and__1927000168__auto____19 }; if jrt.J2g_Truth(tmp1) {
						var root_815 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = A_arbace_repr_go_print_A_const_68; if linked_816 == nil { ifn_817.Invoke_O__O(arg_818) } else { linked_816.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_815, arg_818) } }
					var root_819 any = A_arbace_repr_go_print_A_const_86.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, A_arbace_repr_go_print_import_spec_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = v__16; if linked_820 == nil { ifn_821.Invoke_O__O(arg_822) } else { linked_820.(*A_arbace_repr_go_print_import_spec_A).Invoke_O_O__O(root_819, arg_822) }
					var root_823 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; if jrt.J2g_Truth(more__17) { arg_826 = A_arbace_repr_go_print_A_const_68 } else { arg_826 = A_arbace_repr_go_print_A_const_85 }; if linked_824 == nil { ifn_825.Invoke_O__O(arg_826) } else { linked_824.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_823, arg_826) }
					G__1344000083__10_, prev__11 = more__17, v__16; continue L1 }
//line :140:1
				break L1
			}











			var root_795 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = Lit_102; if linked_796 == nil { ifn_797.Invoke_O__O(arg_798) } else { linked_796.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_795, arg_798) }; var root_737 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = A_arbace_repr_go_print_A_const_85; if linked_738 == nil { return ifn_739.Invoke_O__O(arg_740) } else { return linked_738.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_737, arg_740)
			} } }
func A_arbace_repr_go_print_write_imports_A_New() *A_arbace_repr_go_print_write_imports_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_repr_go_print_write_imports_A) Ctor() {}
//line :155:1
func (t *A_arbace_repr_go_print_write_imports_A) Invoke_O_O__O(self, imports__0 any) any {



	{ var tmp1 any; var root_827 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = imports__0; if linked_828 == nil { tmp1 = ifn_829.Invoke_O__O(arg_830) } else { tmp1 = linked_828.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_827, arg_830) }; if jrt.J2g_Truth(tmp1) {
		var root_853 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = A_arbace_repr_go_print_A_const_85; if linked_854 == nil { ifn_855.Invoke_O__O(arg_856) } else { linked_854.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_853, arg_856) }
//line :159:1
		var directive_QMARK___2 any; var tmp2 any = A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_New(); var tmp3 *jrt.Class
		var fncls__839 /*line :159:1*/*jrt.Class = A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_fn_class

		if fncls__839 == nil { var fncls__839d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_fn_class = fncls__839d; tmp3 = fncls__839d } else { tmp3 = fncls__839 }; directive_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :159:1
		var xs__3 any; var root_840 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_842 lang.IFn


		if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = imports__0; if linked_841 == nil { xs__3 = ifn_842.Invoke_O__O(arg_843) } else { xs__3 = linked_841.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_840, arg_843) }
//line :159:1
	L1: for {



		if jrt.J2g_Truth(xs__3) {
			var tmp4 lang.IFn = lang.IFn_Cast(directive_QMARK___2); var tmp5 any; var root_857 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = xs__3; if linked_858 == nil { tmp5 = ifn_859.Invoke_O__O(arg_860) } else { tmp5 = linked_858.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_857, arg_860) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) {
				var root_861 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any; var root_866 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var root_870 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var root_874 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = xs__3; if linked_875 == nil { arg_873 = ifn_876.Invoke_O__O(arg_877) } else { arg_873 = linked_875.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_874, arg_877) }; if linked_871 == nil { arg_869 = ifn_872.Invoke_O__O(arg_873) } else { arg_869 = linked_871.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_870, arg_873) }; if linked_867 == nil { arg_864 = ifn_868.Invoke_O__O(arg_869) } else { arg_864 = linked_867.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_866, arg_869) }; var arg_865 any = A_arbace_repr_go_print_A_const_85; if linked_862 == nil { ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { linked_862.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }
				var tmp6 any; var root_878 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = xs__3; if linked_879 == nil { tmp6 = ifn_880.Invoke_O__O(arg_881) } else { tmp6 = linked_879.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_878, arg_881) }; xs__3 = tmp6; continue L1 } else {
//line :164:1
					var vec__1344000094__4 any; var root_844 any = A_arbace_repr_go_print_A_const_87.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_846 lang.IFn


					if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any; var root_849 any = A_arbace_repr_go_print_A_const_88.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = directive_QMARK___2; if linked_850 == nil { arg_847 = ifn_851.Invoke_O__O(arg_852) } else { arg_847 = linked_850.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_849, arg_852) }; var arg_848 any = xs__3; if linked_845 == nil { vec__1344000094__4 = ifn_846.Invoke_O_O__O(arg_847, arg_848) } else { vec__1344000094__4 = linked_845.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_844, arg_847, arg_848) }
//line :164:1
					var specs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000094__4, lang.RT_IntCast_J__I_NoInit(0), nil); var more__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000094__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_882 any = A_arbace_repr_go_print_A_const_90.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, A_arbace_repr_go_print_write_import_decl_A_fn_class); var ifn_884 lang.IFn



					if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var root_886 any = A_arbace_repr_go_print_A_const_91.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = specs__5; if linked_887 == nil { arg_885 = ifn_888.Invoke_O__O(arg_889) } else { arg_885 = linked_887.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_886, arg_889) }; if linked_883 == nil { ifn_884.Invoke_O__O(arg_885) } else { linked_883.(*A_arbace_repr_go_print_write_import_decl_A).Invoke_O_O__O(root_882, arg_885) }
					var tmp7 any; var root_890 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = more__6; if linked_891 == nil { tmp7 = ifn_892.Invoke_O__O(arg_893) } else { tmp7 = linked_891.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_890, arg_893) }; xs__3 = tmp7; continue L1 } } else {
//line :163:1
						return nil } } } else {
//line :159:1
							return nil } }
//line :155:1
	panic("j2g: unreachable")
}




func A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_New() *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A) Invoke_O_O__O(self, p1__1344000091_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_831 any = A_arbace_repr_go_print_A_const_21.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = p1__1344000091_SHARP___1; if linked_832 == nil { and__1927000168__auto____2 = ifn_833.Invoke_O__O(arg_834) } else { and__1927000168__auto____2 = linked_832.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_831, arg_834) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any; var root_835 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = p1__1344000091_SHARP___1; if linked_836 == nil { tmp1 = ifn_837.Invoke_O__O(arg_838) } else { tmp1 = linked_836.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_835, arg_838) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, Lit_67)).Ref() } else { return and__1927000168__auto____2 } }









func A_arbace_repr_go_print_write_imports_full_A_New() *A_arbace_repr_go_print_write_imports_full_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_full_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_repr_go_print_write_imports_full_A) Ctor() {}
//line :171:1
func (t *A_arbace_repr_go_print_write_imports_full_A) Invoke_O_O__O(self, imports__0 any) any { var open__2 any; var root_894 any = A_arbace_repr_go_print_A_const_61.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_896 lang.IFn; if




	linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any; if linked_895 == nil { open__2 = ifn_896.Invoke_O__O(arg_897) } else { open__2 = linked_895.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_894, arg_897) }; var close_BANG___3 any; var tmp1 any = /*line :171:1*/A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_New_O(open__2); var tmp2 *jrt.Class; var fncls__912 *jrt.Class = A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_fn_class; if





	fncls__912 == nil { var fncls__912d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_fn_class = fncls__912d; tmp2 = fncls__912d } else { tmp2 = fncls__912 }; close_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var seq_1344000100__4 any; var root_913 any = /*line :171:1*/A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_915 lang.IFn; if






	linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = imports__0; if linked_914 == nil { seq_1344000100__4 = ifn_915.Invoke_O__O(arg_916) } else { seq_1344000100__4 = linked_914.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_913, arg_916) }; var chunk_1344000101__5 any; var count_1344000102__6 int64 = 0; var i_1344000103__7 int64 = 0; L1:
//line :171:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000103__7, count_1344000102__6) { var v__8 any = lang.Indexed_Cast(chunk_1344000101__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000103__7)); var tmp3 any; var root_917 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = v__8; if linked_918 == nil { tmp3 = ifn_919.Invoke_O__O(arg_920) } else { tmp3 = linked_918.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_917, arg_920) }; if jrt.J2g_Truth(tmp3) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var p__9 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__8)); var vec__1344000104__10 any = v__8; var nm__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000104__10, lang.RT_IntCast_J__I_NoInit(0), nil); var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000104__10, lang.RT_IntCast_J__I_NoInit(1), nil)


			if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__9)) {
				lang.IFn_Cast(close_BANG___3).Invoke__O()
				var root_962 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = Lit_100; var arg_966 any = A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__9); if linked_963 == nil { ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { linked_963.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_962, arg_965, arg_966) }; var root_967 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; if linked_968 == nil { ifn_969.Invoke__O() } else { linked_968.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_967) }
				if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__9)) { var root_970 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = Lit_101; var arg_974 any = A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__9); if linked_971 == nil { ifn_972.Invoke_O_O__O(arg_973, arg_974) } else { linked_971.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_970, arg_973, arg_974) } }
				var root_946 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = open__2; var arg_950 any = p__9; if linked_947 == nil { ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { linked_947.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } else {
					var root_951 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = A_arbace_repr_go_print_A_const_99; var arg_955 any = Lit_95; if linked_952 == nil { ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { linked_952.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) } }
			var tmp5 any; var tmp6 *lang.Keyword = A_arbace_repr_go_print_A_const_78; var or__1927000174__auto____13 any = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__8)); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp5 = or__1927000174__auto____13 } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_100); var tmp8 any; var root_975 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = nm__11; if linked_976 == nil { tmp8 = ifn_977.Invoke_O__O(arg_978) } else { tmp8 = linked_976.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_975, arg_978) }; tmp5 = tmp7.Invoke_O__O(tmp8) }; if jrt.J2g_Truth(tmp5) {
				var root_979 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var root_984 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = nm__11; if linked_985 == nil { arg_982 = ifn_986.Invoke_O__O(arg_987) } else { arg_982 = linked_985.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_984, arg_987) }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_A_const_101; var tmp10 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var arg_983 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__11))); if linked_980 == nil { ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { linked_980.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }; var root_956 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; if linked_957 == nil { ifn_958.Invoke__O() } else { linked_957.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_956) } }
			var root_959 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; if linked_960 == nil { ifn_961.Invoke__O() } else { linked_960.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_959) }
			var root_941 any = A_arbace_repr_go_print_A_const_96.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = path__12; var arg_945 any = A_arbace_repr_go_print_A_const_68; if linked_942 == nil { ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { linked_942.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) }
//line :178:1
			seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000103__7); continue L1 } else { seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000103__7); continue L1 } } else { var temp__1927000414__auto____8 any; var root_921 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = seq_1344000100__4; if linked_922 == nil { temp__1927000414__auto____8 = ifn_923.Invoke_O__O(arg_924) } else { temp__1927000414__auto____8 = linked_922.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_921, arg_924) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1344000100__9 any = temp__1927000414__auto____8; var tmp11 any; var root_925 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = seq_1344000100__9; if linked_926 == nil { tmp11 = ifn_927.Invoke_O__O(arg_928) } else { tmp11 = linked_926.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_925, arg_928) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____10 any; var root_929 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = seq_1344000100__9; if linked_930 == nil { c__1927000678__auto____10 = ifn_931.Invoke_O__O(arg_932) } else { c__1927000678__auto____10 = linked_930.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_929, arg_932) }; var tmp12 any; var root_988 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = seq_1344000100__9; if linked_989 == nil { tmp12 = ifn_990.Invoke_O__O(arg_991) } else { tmp12 = linked_989.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_988, arg_991) }; seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = tmp12, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var v__10 any; var root_933 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = seq_1344000100__9; if linked_934 == nil { v__10 = ifn_935.Invoke_O__O(arg_936) } else { v__10 = linked_934.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_933, arg_936) }; var tmp13 any; var root_937 any = A_arbace_repr_go_print_A_const_26.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = v__10; if linked_938 == nil { tmp13 = ifn_939.Invoke_O__O(arg_940) } else { tmp13 = linked_938.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_937, arg_940) }; if jrt.J2g_Truth(tmp13) { var tmp14 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var p__11 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__10)); var vec__1344000107__12 any = v__10; var nm__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000107__12, lang.RT_IntCast_J__I_NoInit(0), nil); var path__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000107__12, lang.RT_IntCast_J__I_NoInit(1), nil)


				if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__11)) {
					lang.IFn_Cast(close_BANG___3).Invoke__O()
					var root_1013 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = Lit_100; var arg_1017 any = A_arbace_repr_go_print_A_const_97.Invoke_O__O(p__11); if linked_1014 == nil { ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { linked_1014.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) }; var root_1018 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; if linked_1019 == nil { ifn_1020.Invoke__O() } else { linked_1019.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1018) }
					if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__11)) { var root_1021 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = Lit_101; var arg_1025 any = A_arbace_repr_go_print_A_const_92.Invoke_O__O(p__11); if linked_1022 == nil { ifn_1023.Invoke_O_O__O(arg_1024, arg_1025) } else { linked_1022.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1021, arg_1024, arg_1025) } }
					var root_997 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = open__2; var arg_1001 any = p__11; if linked_998 == nil { ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { linked_998.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) } } else {
						var root_1002 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = A_arbace_repr_go_print_A_const_99; var arg_1006 any = Lit_95; if linked_1003 == nil { ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { linked_1003.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) } }
				var tmp15 any; var tmp16 *lang.Keyword = A_arbace_repr_go_print_A_const_78; var or__1927000174__auto____15 any = tmp16.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__10)); if jrt.J2g_Truth(or__1927000174__auto____15) { tmp15 = or__1927000174__auto____15 } else { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_102); var tmp18 any; var root_1026 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = nm__13; if linked_1027 == nil { tmp18 = ifn_1028.Invoke_O__O(arg_1029) } else { tmp18 = linked_1027.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1026, arg_1029) }; tmp15 = tmp17.Invoke_O__O(tmp18) }; if jrt.J2g_Truth(tmp15) {
					var root_1030 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any; var root_1035 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = nm__13; if linked_1036 == nil { arg_1033 = ifn_1037.Invoke_O__O(arg_1038) } else { arg_1033 = linked_1036.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1035, arg_1038) }; var tmp19 *lang.Keyword = A_arbace_repr_go_print_A_const_101; var tmp20 *lang.Keyword = A_arbace_repr_go_print_A_const_95; var arg_1034 any = tmp19.Invoke_O__O(tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__13))); if linked_1031 == nil { ifn_1032.Invoke_O_O__O(arg_1033, arg_1034) } else { linked_1031.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1030, arg_1033, arg_1034) }; var root_1007 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; if linked_1008 == nil { ifn_1009.Invoke__O() } else { linked_1008.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1007) } }
				var root_1010 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; if linked_1011 == nil { ifn_1012.Invoke__O() } else { linked_1011.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1010) }
				var root_992 any = A_arbace_repr_go_print_A_const_96.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = path__14; var arg_996 any = A_arbace_repr_go_print_A_const_68; if linked_993 == nil { ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { linked_993.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_expr0_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) }
//line :178:1
				var tmp21 any; var root_1039 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = seq_1344000100__9; if linked_1040 == nil { tmp21 = ifn_1041.Invoke_O__O(arg_1042) } else { tmp21 = linked_1040.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1039, arg_1042) }; seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = tmp21, nil, 0, 0; continue L1 } else { var tmp22 any; var root_1043 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = seq_1344000100__9; if linked_1044 == nil { tmp22 = ifn_1045.Invoke_O__O(arg_1046) } else { tmp22 = linked_1044.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1043, arg_1046) }; seq_1344000100__4, chunk_1344000101__5, count_1344000102__6, i_1344000103__7 = tmp22, nil, 0, 0; continue L1 } } } }
//line :171:1
		break L1 }; return /*line :191:1*/ lang.IFn_Cast(close_BANG___3).Invoke__O() }
//line :177:1
func A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_New_O(p0 any) *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A) Ctor_O(c__open any) { t.F_open = c__open }
//line :177:1
func (t *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var root_903 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = t.F_open; if linked_904 == nil { temp__1927000414__auto____1 = ifn_905.Invoke_O__O(arg_906) } else { temp__1927000414__auto____1 = linked_904.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_903, arg_906) }; if jrt.J2g_Truth(temp__1927000414__auto____1) { var d__2 any = temp__1927000414__auto____1; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_92.Invoke_O__O(d__2)) { var root_907 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = Lit_102; var arg_911 any = A_arbace_repr_go_print_A_const_94.Invoke_O__O(d__2); if linked_908 == nil { ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { linked_908.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_907, arg_910, arg_911) } } }; var root_898 any = A_arbace_repr_go_print_A_const_73.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = t.F_open; var arg_902 any; if linked_899 == nil { return ifn_900.Invoke_O_O__O(arg_901, arg_902) } else { return linked_899.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_898, arg_901, arg_902) } }















func A_arbace_repr_go_print_one_line_func_QMARK__A_New() *A_arbace_repr_go_print_one_line_func_QMARK__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_one_line_func_QMARK__A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_repr_go_print_one_line_func_QMARK__A) Ctor() {}
//line :193:1
func (t *A_arbace_repr_go_print_one_line_func_QMARK__A) Invoke_O_O_O_O__O(self, f__0, lines_QMARK___1, t__2 any) any { var and__1927000168__auto____4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_103); var tmp2 any; var root_1091 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1093 lang.IFn; if



	linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = f__0; if linked_1092 == nil { tmp2 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp2 = linked_1092.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1091, arg_1094) }; and__1927000168__auto____4 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(and__1927000168__auto____4) {
		if jrt.J2g_Truth(lines_QMARK___1) { var and__1927000168__auto____5 any = t__2
			if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_104; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)), t__2)).Ref() } else { return and__1927000168__auto____5 } } else {
//line :198:1
				var vec__1344000111__5 any = f__0; var seq__1344000112__6 any; var root_1047 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1049 lang.IFn

				if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = vec__1344000111__5; if linked_1048 == nil { seq__1344000112__6 = ifn_1049.Invoke_O__O(arg_1050) } else { seq__1344000112__6 = linked_1048.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1047, arg_1050) }
//line :198:1
				var first__1344000113__7 any; var root_1051 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1053 lang.IFn

				if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = seq__1344000112__6; if linked_1052 == nil { first__1344000113__7 = ifn_1053.Invoke_O__O(arg_1054) } else { first__1344000113__7 = linked_1052.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1051, arg_1054) }
//line :198:1
				var seq__1344000112__8 any; var root_1055 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1057 lang.IFn

				if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = seq__1344000112__6; if linked_1056 == nil { seq__1344000112__8 = ifn_1057.Invoke_O__O(arg_1058) } else { seq__1344000112__8 = linked_1056.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1055, arg_1058) }
//line :198:1
				var ___9 any = first__1344000113__7; var first__1344000113__10 any; var root_1059 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1061 lang.IFn; _ = ___9

				if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = seq__1344000112__8; if linked_1060 == nil { first__1344000113__10 = ifn_1061.Invoke_O__O(arg_1062) } else { first__1344000113__10 = linked_1060.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1059, arg_1062) }
//line :198:1
				var seq__1344000112__11 any; var root_1063 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1065 lang.IFn

				if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = seq__1344000112__8; if linked_1064 == nil { seq__1344000112__11 = ifn_1065.Invoke_O__O(arg_1066) } else { seq__1344000112__11 = linked_1064.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1063, arg_1066) }
//line :198:1
				var nm__12 any = first__1344000113__10; var xs__13 any = seq__1344000112__11; var vec__1344000114__14 any; var root_1067 any = A_arbace_repr_go_print_A_const_105.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_parse_decl_head_A_fn_class); var ifn_1069 lang.IFn


				if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = xs__13; if linked_1068 == nil { vec__1344000114__14 = ifn_1069.Invoke_O__O(arg_1070) } else { vec__1344000114__14 = linked_1068.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_parse_decl_head_A).Invoke_O_O__O(root_1067, arg_1070) }
//line :198:1
				var ___15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000114__14, lang.RT_IntCast_J__I_NoInit(0), nil); var ___16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000114__14, lang.RT_IntCast_J__I_NoInit(1), nil); var xs__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000114__14, lang.RT_IntCast_J__I_NoInit(2), nil); var body__18 any; var root_1071 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1073 lang.IFn; _ = ___15; _ = ___16



				if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = xs__17; if linked_1072 == nil { body__18 = ifn_1073.Invoke_O__O(arg_1074) } else { body__18 = linked_1072.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1071, arg_1074) }
//line :198:1
				var body__19 any; var tmp4 any; var root_1075 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1077 lang.IFn




				if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = body__18; if linked_1076 == nil { tmp4 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp4 = linked_1076.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1075, arg_1078) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_repr_go_print_A_const_106) { var root_1079 any = A_arbace_repr_go_print_A_const_107.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = body__18; if linked_1080 == nil { body__19 = ifn_1081.Invoke_O__O(arg_1082) } else { body__19 = linked_1080.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_1079, arg_1082) } } else { body__19 = body__18 }
//line :198:1
				var and__1927000168__auto____20 any; var root_1083 any = A_arbace_repr_go_print_A_const_53.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1085 lang.IFn





				if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = body__19; if linked_1084 == nil { and__1927000168__auto____20 = ifn_1085.Invoke_O__O(arg_1086) } else { and__1927000168__auto____20 = linked_1084.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1083, arg_1086) }; if jrt.J2g_Truth(and__1927000168__auto____20) { var root_1087 any = A_arbace_repr_go_print_A_const_108.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_A_const_109; var arg_1090 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__12)); if linked_1088 == nil { return ifn_1089.Invoke_O__O(arg_1090) } else { return linked_1088.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1087, arg_1090) } } else { return and__1927000168__auto____20 } } } else {
//line :197:1
					return and__1927000168__auto____4 } }








func A_arbace_repr_go_print_decl_pre_A_New() *A_arbace_repr_go_print_decl_pre_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_decl_pre_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_repr_go_print_decl_pre_A) Ctor() {}
//line :206:1
func (t *A_arbace_repr_go_print_decl_pre_A) Invoke_O_O__O(self, f__0 any) any { var directive_QMARK___2 bool; var tmp1 any; var root_1095 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1097 lang.IFn; if


	linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = f__0; if linked_1096 == nil { tmp1 = ifn_1097.Invoke_O__O(arg_1098) } else { tmp1 = linked_1096.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1095, arg_1098) }; directive_QMARK___2 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, Lit_67); var vec__1344000118__3 any; if directive_QMARK___2 {
		vec__1344000118__3 = lang.Tuple_Create_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref()) } else { var root_1099 any = A_arbace_repr_go_print_A_const_110.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_decl_doc_and_directives_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = f__0; if linked_1100 == nil { vec__1344000118__3 = ifn_1101.Invoke_O__O(arg_1102) } else { vec__1344000118__3 = linked_1100.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_decl_doc_and_directives_A).Invoke_O_O__O(root_1099, arg_1102) } }; var doc__4 any = /*line :206:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1344000118__3, lang.RT_IntCast_J__I_NoInit(0), nil); var dirs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000118__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(directive_QMARK___2).Ref(); var tmp3 any; var root_1103 any = A_arbace_repr_go_print_A_const_111.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_pre_lines_A_fn_class); var ifn_1105 lang.IFn; if




	linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = doc__4; var arg_1107 any = dirs__5; if linked_1104 == nil { tmp3 = ifn_1105.Invoke_O_O__O(arg_1106, arg_1107) } else { tmp3 = linked_1104.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_pre_lines_A).Invoke_O_O_O__O(root_1103, arg_1106, arg_1107) }; return /*line :206:1*/ lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, doc__4, dirs__5, tmp3) }






func A_arbace_repr_go_print_next_target_A_New() *A_arbace_repr_go_print_next_target_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_next_target_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_repr_go_print_next_target_A) Ctor() {}
//line :213:1
func (t *A_arbace_repr_go_print_next_target_A) Invoke_O_O_O__O(self, decls__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, decls__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else {


	var root_1108 any = A_arbace_repr_go_print_A_const_112.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any; var tmp1 any = A_arbace_repr_go_print_next_target_fn__1344000122_A_New(); var tmp2 *jrt.Class; var fncls__1121 *jrt.Class = A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class; if fncls__1121 == nil { var fncls__1121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class = fncls__1121d; tmp2 = fncls__1121d } else { tmp2 = fncls__1121 }; arg_1111 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1112 any; var root_1122 any = A_arbace_repr_go_print_A_const_118.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1124 lang.IFn

	if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = decls__0; var arg_1126 any; var na_1127 any = i__1; if jrt.Long_InstanceOf(na_1127) { var n0_1128 int64 = jrt.NN(jrt.Long_Cast(na_1127)).LongValue__J(); if n0_1128 == 9223372036854775807 { arg_1126 = lang.Numbers_Inc_O__Number_NoInit(na_1127) } else { arg_1126 = jrt.Long_ValueOf_J__Long_NoInit(n0_1128 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1127) { var n0_1128_2 float64 = jrt.NN(jrt.Double_Cast(na_1127)).DoubleValue__D(); arg_1126 = jrt.Double_ValueOf_D__Double_NoInit(n0_1128_2 + 1.0).Ref() } else { arg_1126 = lang.Numbers_Inc_O__Number_NoInit(na_1127) } }; if linked_1123 == nil { arg_1112 = ifn_1124.Invoke_O_O__O(arg_1125, arg_1126) } else { arg_1112 = linked_1123.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_1122, arg_1125, arg_1126) }
//line :216:1
	if linked_1109 == nil { return ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { return linked_1109.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) } } }
//line :213:1
func (t *A_arbace_repr_go_print_next_target_A) InvokeSpec_O_O_J_O__O(self, decls__0 any, i__1_l int64, i__1_b any) any {


	var root_1129 any = A_arbace_repr_go_print_A_const_112.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any; var tmp1 any = A_arbace_repr_go_print_next_target_fn__1344000122_A_New(); var tmp2 *jrt.Class; var fncls__1134 *jrt.Class = A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class; if fncls__1134 == nil { var fncls__1134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class = fncls__1134d; tmp2 = fncls__1134d } else { tmp2 = fncls__1134 }; arg_1132 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1133 any; var root_1135 any = A_arbace_repr_go_print_A_const_118.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1137 lang.IFn

	if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = decls__0; var arg_1139 any; var n0_1140 int64 = i__1_l; if n0_1140 == 9223372036854775807 { var tmp3 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; arg_1139 = lang.Numbers_Inc_O__Number_NoInit(tmp3) } else { arg_1139 = jrt.Long_ValueOf_J__Long_NoInit(n0_1140 + 1).Ref() }; if linked_1136 == nil { arg_1133 = ifn_1137.Invoke_O_O__O(arg_1138, arg_1139) } else { arg_1133 = linked_1136.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_1135, arg_1138, arg_1139) }
//line :216:1
	if linked_1130 == nil { return ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { return linked_1130.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) } }
//line :216:1
func A_arbace_repr_go_print_next_target_fn__1344000122_A_New() *A_arbace_repr_go_print_next_target_fn__1344000122_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_next_target_fn__1344000122_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_repr_go_print_next_target_fn__1344000122_A) Ctor() {}
//line :216:1
func (t *A_arbace_repr_go_print_next_target_fn__1344000122_A) Invoke_O_O__O(self, d__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(d__1)); var tmp3 any; var root_1113 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = l__308000057__auto____2; if linked_1114 == nil { tmp3 = ifn_1115.Invoke_O__O(arg_1116) } else { tmp3 = linked_1114.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(tmp3) { temp__1927000414__auto____2 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____2)).Ref() } else { temp__1927000414__auto____2 = nil } } else { temp__1927000414__auto____2 = nil }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var tmp4 int64 = lang.RT_LongCast_O__J_NoInit(t__3); var tmp5 any; var root_1117 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1119 lang.IFn
												if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = d__1; if linked_1118 == nil { tmp5 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp5 = linked_1118.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1117, arg_1120) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(tmp4, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(3))))).Ref() } else {
//line :216:1
		return nil } }



func A_arbace_repr_go_print_decl_sep_BANG__A_New() *A_arbace_repr_go_print_decl_sep_BANG__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_decl_sep_BANG__A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_go_print_decl_sep_BANG__A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_go_print_decl_sep_BANG__A) Invoke_O_O_O_O_O__O(self, f__0, t__1, pre__2, lines_QMARK___3 any) any { { var ff__5 any; var or__1927000174__auto____5 any; var root_1141 any = A_arbace_repr_go_print_A_const_108.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1143 lang.IFn





	if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any; var root_1145 any = A_arbace_repr_go_print_A_const_119.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, A_arbace_repr_go_print_one_line_func_QMARK__A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = f__0; var arg_1149 any = lines_QMARK___3; var arg_1150 any = t__1; if linked_1146 == nil { arg_1144 = ifn_1147.Invoke_O_O_O__O(arg_1148, arg_1149, arg_1150) } else { arg_1144 = linked_1146.(*A_arbace_repr_go_print_one_line_func_QMARK__A).Invoke_O_O_O_O__O(root_1145, arg_1148, arg_1149, arg_1150) }; if linked_1142 == nil { or__1927000174__auto____5 = ifn_1143.Invoke_O__O(arg_1144) } else { or__1927000174__auto____5 = linked_1142.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1141, arg_1144) }; if jrt.J2g_Truth(or__1927000174__auto____5) { ff__5 = or__1927000174__auto____5 } else { var tmp1 bool; var na_1151 any; var root_1152 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_120; var arg_1155 any = tmp2.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1153 == nil { na_1151 = ifn_1154.Invoke_O__O(arg_1155) } else { na_1151 = linked_1153.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1152, arg_1155) }; if jrt.Long_InstanceOf(na_1151) { var n0_1156 int64 = jrt.NN(jrt.Long_Cast(na_1151)).LongValue__J(); tmp1 = n0_1156 > 0 } else { if jrt.Double_InstanceOf(na_1151) { var n0_1156_2 float64 = jrt.NN(jrt.Double_Cast(na_1151)).DoubleValue__D(); tmp1 = n0_1156_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_1151) } }; ff__5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() }
	var tmp3 any; var or__1927000174__auto____6 any; var root_1157 any = A_arbace_repr_go_print_A_const_108.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1159 lang.IFn
	if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = lines_QMARK___3; if linked_1158 == nil { or__1927000174__auto____6 = ifn_1159.Invoke_O__O(arg_1160) } else { or__1927000174__auto____6 = linked_1158.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1157, arg_1160) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp3 = or__1927000174__auto____6 } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t__1, nil)).Ref() }
//line :227:1
	if jrt.J2g_Truth(tmp3) {
		var tmp4 any; var root_1175 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var tmp5 *lang.Keyword = A_arbace_repr_go_print_A_const_121; var arg_1178 any = tmp5.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1176 == nil { tmp4 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp4 = linked_1176.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1175, arg_1178) }; if jrt.J2g_Truth(tmp4) { } else { var root_1179 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = A_arbace_repr_go_print_A_const_85; var arg_1183 any = ff__5; if linked_1180 == nil { ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { linked_1180.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) } }; var root_1161 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = A_arbace_repr_go_print_A_const_85; var arg_1165 any = ff__5; if linked_1162 == nil { return ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { return linked_1162.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) } } else {
//line :227:1
			if A_arbace_repr_go_print_A_const_59 != nil { var want__6 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(t__1), lang.RT_LongCast_O__J_NoInit(pre__2)); var tmp6 any; var root_1184 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1186 lang.IFn


				if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var tmp7 *lang.Keyword = A_arbace_repr_go_print_A_const_121; var arg_1187 any = tmp7.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1185 == nil { tmp6 = ifn_1186.Invoke_O__O(arg_1187) } else { tmp6 = linked_1185.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1184, arg_1187) }; if jrt.J2g_Truth(tmp6) { } else { var root_1188 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = A_arbace_repr_go_print_A_const_85; var arg_1192 any = ff__5; if linked_1189 == nil { ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { linked_1189.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) } }
//line :227:1
			L1: for {



				var tmp8 bool; var na_1166 any; var root_1168 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1171 any = tmp9.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1169 == nil { na_1166 = ifn_1170.Invoke_O__O(arg_1171) } else { na_1166 = linked_1169.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1168, arg_1171) }; var na_1167 int64 = want__6; if jrt.Long_InstanceOf(na_1166) { var n0_1172 int64 = jrt.NN(jrt.Long_Cast(na_1166)).LongValue__J(); var n1_1173 int64 = na_1167; tmp8 = n0_1172 < n1_1173 } else { tmp8 = lang.Numbers_Lt_O_J__Z_NoInit(na_1166, na_1167) }; if tmp8 { var root_1193 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = A_arbace_repr_go_print_A_const_85; var arg_1197 any = ff__5; if linked_1194 == nil { ifn_1195.Invoke_O_O__O(arg_1196, arg_1197) } else { linked_1194.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O_O__O(root_1193, arg_1196, arg_1197) }; continue L1 } else { return nil } } } else {
//line :227:1
					return nil } } }; /*line :220:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_print_decl_BANG__A_New() *A_arbace_repr_go_print_print_decl_BANG__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_decl_BANG__A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_repr_go_print_print_decl_BANG__A) Ctor() {}
//line :233:1
func (t *A_arbace_repr_go_print_print_decl_BANG__A) Invoke_O_O_O_O_O_O__O(self, decls__0, i__1, lines_QMARK___2, popts__3, sep_QMARK___4 any) any { var f__6 any = lang.RT_Nth_O_I__O_NoInit(decls__0, lang.RT_IntCast_O__I_NoInit(i__1)); var t__7 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if




	jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____7 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__6)); var tmp3 any; var root_1198 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = l__308000057__auto____7; if linked_1199 == nil { tmp3 = ifn_1200.Invoke_O__O(arg_1201) } else { tmp3 = linked_1199.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1198, arg_1201) }; if jrt.J2g_Truth(tmp3) { t__7 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____7)).Ref() } else { t__7 = nil } } else { t__7 = nil }; var vec__1344000126__8 any; var root_1202 any = /*line :233:1*/A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1204 lang.IFn; if





	linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = f__6; if linked_1203 == nil { vec__1344000126__8 = ifn_1204.Invoke_O__O(arg_1205) } else { vec__1344000126__8 = linked_1203.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1202, arg_1205) }; var directive_QMARK___9 any = /*line :233:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(0), nil); var doc__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(1), nil); var dirs__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(2), nil); var pre__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000126__8, lang.RT_IntCast_J__I_NoInit(3), nil); var root_1226 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1228 lang.IFn; if






	linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_A_const_123; var tmp6 any; var root_1235 any = A_arbace_repr_go_print_A_const_124.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1235, A_arbace_repr_go_print_next_target_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = decls__0; var arg_1239 any = i__1; if linked_1236 == nil { tmp6 = ifn_1237.Invoke_O_O__O(arg_1238, arg_1239) } else { if jrt.Long_InstanceOf(arg_1239) { tmp6 = linked_1236.(*A_arbace_repr_go_print_next_target_A).InvokeSpec_O_O_J_O__O(root_1235, arg_1238, jrt.NN(jrt.Long_Cast(arg_1239)).LongValue__J(), arg_1239) } else { tmp6 = linked_1236.(*A_arbace_repr_go_print_next_target_A).Invoke_O_O_O__O(root_1235, arg_1238, arg_1239) } }; arg_1229 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_1227 == nil { ifn_1228.Invoke_O__O(arg_1229) } else { linked_1227.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1226, arg_1229) }; var tmp7 any; tmp16 := /*line :233:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		if jrt.J2g_Truth(sep_QMARK___4) { var root_1240 any = A_arbace_repr_go_print_A_const_125.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, A_arbace_repr_go_print_decl_sep_BANG__A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = f__6; var arg_1244 any = t__7; var arg_1245 any = pre__12; var arg_1246 any = lines_QMARK___2; if linked_1241 == nil { ifn_1242.Invoke_O_O_O_O__O(arg_1243, arg_1244, arg_1245, arg_1246) } else { linked_1241.(*A_arbace_repr_go_print_decl_sep_BANG__A).Invoke_O_O_O_O_O__O(root_1240, arg_1243, arg_1244, arg_1245, arg_1246) } }
		if jrt.J2g_Truth(directive_QMARK___9) {
			var root_1206 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any; var root_1211 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any; var root_1215 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = f__6; if linked_1216 == nil { arg_1214 = ifn_1217.Invoke_O__O(arg_1218) } else { arg_1214 = linked_1216.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1215, arg_1218) }; if linked_1212 == nil { arg_1209 = ifn_1213.Invoke_O__O(arg_1214) } else { arg_1209 = linked_1212.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1211, arg_1214) }; var arg_1210 any = A_arbace_repr_go_print_A_const_85; if linked_1207 == nil { tmp7 = ifn_1208.Invoke_O_O__O(arg_1209, arg_1210) } else { tmp7 = linked_1207.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1206, arg_1209, arg_1210) } } else {

				var root_1247 any = A_arbace_repr_go_print_A_const_126.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_pre_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = doc__10; var arg_1251 any = dirs__11; var arg_1252 any = A_arbace_repr_go_print_A_const_85; if linked_1248 == nil { ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { linked_1248.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_pre_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) }
				var tmp8 any; var and__1927000168__auto____15 any = lines_QMARK___2; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any = t__7; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var root_1253 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(t__7)).Ref(); var arg_1257 any; var root_1258 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var tmp9 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1261 any = tmp9.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1259 == nil { arg_1257 = ifn_1260.Invoke_O__O(arg_1261) } else { arg_1257 = linked_1259.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1258, arg_1261) }; if linked_1254 == nil { and__1927000168__auto____17 = ifn_1255.Invoke_O_O__O(arg_1256, arg_1257) } else { and__1927000168__auto____17 = linked_1254.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1253, arg_1256, arg_1257) }; if jrt.J2g_Truth(and__1927000168__auto____17) { var tmp10 lang.IFn = A_arbace_repr_go_print_A_const_128; var tmp11 any; var or__1927000174__auto____18 any = popts__3; if jrt.J2g_Truth(or__1927000174__auto____18) { tmp11 = or__1927000174__auto____18 } else { tmp11 = lang.PersistentArrayMap_EMPTY.Ref() }; tmp8 = tmp10.Invoke_O_O__O(tmp11, jrt.Boolean_TRUE.Ref()) } else { tmp8 = and__1927000168__auto____17 } } else { tmp8 = and__1927000168__auto____16 } } else { tmp8 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp8) {
					var tmp12 bool; var na_1262 int64 = lang.RT_LongCast_O__J_NoInit(t__7); var na_1263 any; var root_1264 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1266 lang.IFn
					if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var tmp13 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1267 any = tmp13.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1265 == nil { na_1263 = ifn_1266.Invoke_O__O(arg_1267) } else { na_1263 = linked_1265.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1264, arg_1267) }; if jrt.Long_InstanceOf(na_1263) { var n0_1268 int64 = na_1262; var n1_1269 int64 = jrt.NN(jrt.Long_Cast(na_1263)).LongValue__J(); tmp12 = n0_1268 > n1_1269 } else { tmp12 = lang.Numbers_Gt_J_O__Z_NoInit(na_1262, na_1263) }
//line :247:1
					if tmp12 { L1: for {
						var tmp14 bool; var na_1271 any; var root_1273 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var tmp15 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var arg_1276 any = tmp15.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1274 == nil { na_1271 = ifn_1275.Invoke_O__O(arg_1276) } else { na_1271 = linked_1274.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1273, arg_1276) }; var na_1272 int64 = lang.RT_LongCast_O__J_NoInit(t__7); if jrt.Long_InstanceOf(na_1271) { var n0_1277 int64 = jrt.NN(jrt.Long_Cast(na_1271)).LongValue__J(); var n1_1278 int64 = na_1272; tmp14 = n0_1277 < n1_1278 } else { tmp14 = lang.Numbers_Lt_O_J__Z_NoInit(na_1271, na_1272) }; if tmp14 { var root_1284 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = A_arbace_repr_go_print_A_const_85; if linked_1285 == nil { ifn_1286.Invoke_O__O(arg_1287) } else { linked_1285.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1284, arg_1287) }; continue L1 }
//line :247:1
						break L1 } } else { if A_arbace_repr_go_print_A_const_59 != nil {

							var root_1280 any = A_arbace_repr_go_print_A_const_129.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_directive_own_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = t__7; if linked_1281 == nil { ifn_1282.Invoke_O__O(arg_1283) } else { linked_1281.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_line_directive_own_A).Invoke_O_O__O(root_1280, arg_1283) } } } }
				var root_1219 any = A_arbace_repr_go_print_A_const_122.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = f__6; if linked_1220 == nil { tmp7 = ifn_1221.Invoke_O__O(arg_1222) } else { tmp7 = linked_1220.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A).Invoke_O_O__O(root_1219, arg_1222) } }
//line :233:1
		return nil }(); var root_1223 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1225 lang.IFn; if






	linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; if linked_1224 == nil { ifn_1225.Invoke__O() } else { linked_1224.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1223) }; if /*line :233:1*/ tmp16 != nil { panic(tmp16) }; return tmp7 }






















func A_arbace_repr_go_print_chunk_starts_A_New() *A_arbace_repr_go_print_chunk_starts_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_go_print_chunk_starts_A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_go_print_chunk_starts_A) Invoke_O_O__O(self, decls__0 any) any { var n__2 int32 = lang.RT_Count_O__I_NoInit(decls__0); var k__3 any; var tmp1 int64 = lang.Numbers_Multiply_J_J__J_NoInit(2, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var tmp2 jrt.Number_I; var na_1288 int64 = int64(n__2); var na_1289 any = A_arbace_repr_go_print_A_const_130.GetRawRoot__O(); if




	jrt.Long_InstanceOf(na_1289) { var n0_1290 int64 = na_1288; var n1_1291 int64 = jrt.NN(jrt.Long_Cast(na_1289)).LongValue__J(); if n1_1291 == 0 { tmp2 = lang.Numbers_Quotient_J_O__Number_NoInit(na_1288, na_1289) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1290 / n1_1291)) } } else { tmp2 = lang.Numbers_Quotient_J_O__Number_NoInit(na_1288, na_1289) }; k__3 = lang.Numbers_Min_J_O__O_NoInit(tmp1, tmp2); var tmp3 bool; var na_1293 any = k__3; var na_1294 int64 = 2; if
	jrt.Long_InstanceOf(na_1293) { var n0_1295 int64 = jrt.NN(jrt.Long_Cast(na_1293)).LongValue__J(); var n1_1296 int64 = na_1294; tmp3 = n0_1295 >= n1_1296 } else { tmp3 = lang.Numbers_Gte_O_J__Z_NoInit(na_1293, na_1294) }; if tmp3 { var size__4 any; var na_1298 any; var na_1300 int64 = int64(n__2); var na_1301 any; var na_1302 any = k__3
		if jrt.Long_InstanceOf(na_1302) { var n0_1303 int64 = jrt.NN(jrt.Long_Cast(na_1302)).LongValue__J(); if n0_1303 == -9223372036854775808 { na_1301 = lang.Numbers_Dec_O__Number_NoInit(na_1302) } else { na_1301 = jrt.Long_ValueOf_J__Long_NoInit(n0_1303 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_1302) { var n0_1303_2 float64 = jrt.NN(jrt.Double_Cast(na_1302)).DoubleValue__D(); na_1301 = jrt.Double_ValueOf_D__Double_NoInit(n0_1303_2 - 1.0).Ref() } else { na_1301 = lang.Numbers_Dec_O__Number_NoInit(na_1302) } }; if jrt.Long_InstanceOf(na_1301) { var n0_1304 int64 = na_1300; var n1_1305 int64 = jrt.NN(jrt.Long_Cast(na_1301)).LongValue__J(); var nr_1306 int64 = n0_1304 + n1_1305; if (n0_1304^nr_1306)&(n1_1305^nr_1306) >= 0 { na_1298 = jrt.Long_ValueOf_J__Long_NoInit(nr_1306).Ref() } else { na_1298 = lang.Numbers_Add_J_O__Number_NoInit(na_1300, na_1301) } } else { na_1298 = lang.Numbers_Add_J_O__Number_NoInit(na_1300, na_1301) }; var na_1299 any = k__3; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_1298); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1299) }; tmp4 = tmp5; if tmp4 { var n0_1307 int64 = jrt.NN(jrt.Long_Cast(na_1298)).LongValue__J(); var n1_1308 int64 = jrt.NN(jrt.Long_Cast(na_1299)).LongValue__J(); if n1_1308 == 0 { size__4 = lang.Numbers_Quotient_O_O__Number_NoInit(na_1298, na_1299) } else { size__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_1307 / n1_1308).Ref() } } else { size__4 = lang.Numbers_Quotient_O_O__Number_NoInit(na_1298, na_1299) }
		var root_1310 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = lang.PersistentVector_EMPTY.Ref(); var arg_1314 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_131.GetRawRoot__O()); var tmp7 any; var root_1322 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1324 lang.IFn
		if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any; var tmp8 any = A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_New_O_I(decls__0, n__2); var tmp9 *jrt.Class; var fncls__1345 *jrt.Class = A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_fn_class; if fncls__1345 == nil { var fncls__1345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_fn_class = fncls__1345d; tmp9 = fncls__1345d } else { tmp9 = fncls__1345 }; arg_1325 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); if linked_1323 == nil { tmp7 = ifn_1324.Invoke_O__O(arg_1325) } else { tmp7 = linked_1323.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1322, arg_1325) }; var tmp10 any = tmp7; var tmp11 any; var root_1346 any = A_arbace_repr_go_print_A_const_135.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1348 lang.IFn
		if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = A_arbace_repr_go_print_A_const_136.GetRawRoot__O(); if linked_1347 == nil { tmp11 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp11 = linked_1347.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_1346, arg_1349) }
//line :265:1
		var tmp12 any = tmp11; var tmp13 any; var root_1350 any = A_arbace_repr_go_print_A_const_137.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1352 lang.IFn

		if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; if linked_1351 == nil { tmp13 = ifn_1352.Invoke__O() } else { tmp13 = linked_1351.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O__O(root_1350) }
//line :265:1
		arg_1314 = tmp6.Invoke_O_O_O__O(tmp10, tmp12, tmp13)
//line :264:1
		var arg_1315 any; var root_1353 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1355 lang.IFn



		if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = A_arbace_repr_go_print_A_const_85; var arg_1357 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref(); var arg_1358 any = size__4; if linked_1354 == nil { arg_1315 = ifn_1355.Invoke_O_O_O__O(arg_1356, arg_1357, arg_1358) } else { arg_1315 = linked_1354.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O_O__O(root_1353, arg_1356, arg_1357, arg_1358) }
//line :264:1
		if linked_1311 == nil { return ifn_1312.Invoke_O_O_O__O(arg_1313, arg_1314, arg_1315) } else { return linked_1311.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1310, arg_1313, arg_1314, arg_1315) } } else {
//line :262:1
			return nil } }


func A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_New_O_I(p0 any, p1 int32) *A_arbace_repr_go_print_chunk_starts_fn__1344000131_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_fn__1344000131_A{}; t.Ctor_O_I(p0, p1); return t }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_A) Ctor_O_I(c__decls any, c__n int32) { t.F_decls = c__decls; t.F_n = c__n }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_A) Invoke_O_O__O(self, a__1 any) any { var root_1326 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any; var root_1330 any = A_arbace_repr_go_print_A_const_133.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any; var tmp1 any = A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_New_O(t.F_decls); var tmp2 *jrt.Class; var fncls__1339 *jrt.Class = A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_fn_class; if fncls__1339 == nil { var fncls__1339d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_fn_class = fncls__1339d; tmp2 = fncls__1339d } else { tmp2 = fncls__1339 }; arg_1333 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1334 any; var root_1340 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = a__1; var arg_1344 any = jrt.Integer_ValueOf_I__Integer_NoInit(t.F_n).Ref(); if linked_1341 == nil { arg_1334 = ifn_1342.Invoke_O_O__O(arg_1343, arg_1344) } else { arg_1334 = linked_1341.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1340, arg_1343, arg_1344) }; if linked_1331 == nil { arg_1329 = ifn_1332.Invoke_O_O__O(arg_1333, arg_1334) } else { arg_1329 = linked_1331.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1330, arg_1333, arg_1334) }; if linked_1327 == nil { return ifn_1328.Invoke_O__O(arg_1329) } else { return linked_1327.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1326, arg_1329) } }
//line :265:1
func A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_New_O(p0 any) *A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A{}; t.Ctor_O(p0); return t }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :265:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A) Invoke_O_O__O(self, p1__1344000130_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var tmp3 any = t.F_decls; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(p1__1344000130_SHARP___1)))); var tmp4 any; var root_1335 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = l__308000057__auto____2; if linked_1336 == nil { tmp4 = ifn_1337.Invoke_O__O(arg_1338) } else { tmp4 = linked_1336.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1335, arg_1338) }; if jrt.J2g_Truth(tmp4) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____2)).Ref() } else { return nil } } else { return nil } }




func A_arbace_repr_go_print_print_file_full_A_New() *A_arbace_repr_go_print_print_file_full_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_full_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_repr_go_print_print_file_full_A) Ctor() {}
//line :270:1
func (t *A_arbace_repr_go_print_print_file_full_A) Invoke_O_O_O_O_O__O(self, file__0, opts__1, decls__2, pkg_name__3 any) any { var m__5 any = lang.RT_Meta_O__IPersistentMap_NoInit(file__0); var decls__6 any; var root_1359 any = A_arbace_repr_go_print_A_const_138.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1361 lang.IFn; if





	linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = A_arbace_repr_go_print_A_const_139.GetRawRoot__O(); var arg_1363 any = decls__2; if linked_1360 == nil { decls__6 = ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { decls__6 = linked_1360.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) }; var imports__7 any; var root_1364 any = /*line :270:1*/A_arbace_repr_go_print_A_const_139.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_wrap_full_A_fn_class); var ifn_1366 lang.IFn; if






	linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = A_arbace_repr_go_print_A_const_140.Invoke_O__O(opts__1); if linked_1365 == nil { imports__7 = ifn_1366.Invoke_O__O(arg_1367) } else { imports__7 = linked_1365.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_wrap_full_A).Invoke_O_O__O(root_1364, arg_1367) }; var p__8 any = /*line :270:1*/A_arbace_repr_go_print_A_const_95.Invoke_O__O(m__5); var root_1374 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1376 lang.IFn; if








	linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_114; var tmp3 any; var root_1387 any = A_arbace_repr_go_print_A_const_142.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var tmp4 any = A_arbace_repr_go_print_A_const_113; var tmp5 any = jrt.Boolean_FALSE.Ref(); var tmp6 any = A_arbace_repr_go_print_A_const_128; var tmp7 any = jrt.Boolean_FALSE.Ref(); var tmp8 any = A_arbace_repr_go_print_A_const_143; var tmp9 any = A_arbace_repr_go_print_A_const_144; var tmp10 any = A_arbace_repr_go_print_A_const_145.Invoke_O__O(m__5); var tmp11 any = A_arbace_repr_go_print_A_const_146; var tmp12 any = A_arbace_repr_go_print_A_const_147.Invoke_O__O(m__5); var tmp13 any = A_arbace_repr_go_print_A_const_148; var tmp14 any = A_arbace_repr_go_print_A_const_149.Invoke_O__O(m__5); var tmp15 any = A_arbace_repr_go_print_A_const_150; var tmp16 any = A_arbace_repr_go_print_A_const_151.Invoke_O__O(m__5); var tmp17 any = A_arbace_repr_go_print_A_const_152; var arg_1390 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, A_arbace_repr_go_print_A_const_153.Invoke_O__O(m__5))))); if linked_1388 == nil { tmp3 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp3 = linked_1388.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A).Invoke_O_O__O(root_1387, arg_1390) }; var tmp18 any = tmp3; var tmp19 any = A_arbace_repr_go_print_A_const_123; var tmp20 any = A_arbace_repr_go_print_A_const_154; var tmp21 any; var root_1391 any = A_arbace_repr_go_print_A_const_155.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A_fn_class); var ifn_1393 lang.IFn; if



	linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = decls__6; if linked_1392 == nil { tmp21 = ifn_1393.Invoke_O__O(arg_1394) } else { tmp21 = linked_1392.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A).Invoke_O_O__O(root_1391, arg_1394) }; arg_1377 = /*line :279:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp18, tmp19, nil, tmp20, tmp21); if linked_1375 == nil { ifn_1376.Invoke_O__O(arg_1377) } else { linked_1375.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1374, arg_1377) }; var tmp22 any; tmp29 := /*line :270:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)













		{ var root_1395 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = Lit_92; var arg_1399 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(p__8); if linked_1396 == nil { ifn_1397.Invoke_O_O__O(arg_1398, arg_1399) } else { linked_1396.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1395, arg_1398, arg_1399) }; var root_1400 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; if linked_1401 == nil { ifn_1402.Invoke__O() } else { linked_1401.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1400) }
			var root_1403 any = A_arbace_repr_go_print_A_const_93.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any; var root_1408 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var or__1927000174__auto____11 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(opts__1); if jrt.J2g_Truth(or__1927000174__auto____11) { arg_1411 = or__1927000174__auto____11 } else { arg_1411 = pkg_name__3 }; if linked_1409 == nil { arg_1406 = ifn_1410.Invoke_O__O(arg_1411) } else { arg_1406 = linked_1409.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1408, arg_1411) }; var arg_1407 any = A_arbace_repr_go_print_A_const_45.Invoke_O__O(p__8); if linked_1404 == nil { ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { linked_1404.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_ptok_STAR__A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }
			var root_1412 any = A_arbace_repr_go_print_A_const_156.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, A_arbace_repr_go_print_write_imports_full_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = imports__7; if linked_1413 == nil { ifn_1414.Invoke_O__O(arg_1415) } else { linked_1413.(*A_arbace_repr_go_print_write_imports_full_A).Invoke_O_O__O(root_1412, arg_1415) }
//line :270:1
			var seq_1344000136__11 any; var root_1416 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1418 lang.IFn
















			if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = decls__6; if linked_1417 == nil { seq_1344000136__11 = ifn_1418.Invoke_O__O(arg_1419) } else { seq_1344000136__11 = linked_1417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1416, arg_1419) }
//line :270:1
			var chunk_1344000137__12 any; var count_1344000138__13 int64 = 0; var i_1344000139__14 int64 = 0; L1: for {
















				if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000139__14, count_1344000138__13) { var f__15 any = lang.Indexed_Cast(chunk_1344000137__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000139__14)); var tmp23 any; var root_1420 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any; var root_1425 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = f__15; if linked_1426 == nil { arg_1423 = ifn_1427.Invoke_O__O(arg_1428) } else { arg_1423 = linked_1426.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1425, arg_1428) }; var arg_1424 any = Lit_67; if linked_1421 == nil { tmp23 = ifn_1422.Invoke_O_O__O(arg_1423, arg_1424) } else { tmp23 = linked_1421.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1420, arg_1423, arg_1424) }; if jrt.J2g_Truth(tmp23) {
					var root_1458 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = A_arbace_repr_go_print_A_const_99; var arg_1462 any = Lit_95; if linked_1459 == nil { ifn_1460.Invoke_O_O__O(arg_1461, arg_1462) } else { linked_1459.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_1458, arg_1461, arg_1462) }
					var root_1454 any = A_arbace_repr_go_print_A_const_122.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = f__15; if linked_1455 == nil { ifn_1456.Invoke_O__O(arg_1457) } else { linked_1455.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A).Invoke_O_O__O(root_1454, arg_1457) }
//line :287:1
					seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000139__14); continue L1 } else { seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000139__14); continue L1 } } else { var temp__1927000414__auto____15 any; var root_1429 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = seq_1344000136__11; if linked_1430 == nil { temp__1927000414__auto____15 = ifn_1431.Invoke_O__O(arg_1432) } else { temp__1927000414__auto____15 = linked_1430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1429, arg_1432) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1344000136__16 any = temp__1927000414__auto____15; var tmp24 any; var root_1433 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = seq_1344000136__16; if linked_1434 == nil { tmp24 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp24 = linked_1434.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1433, arg_1436) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____17 any; var root_1437 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = seq_1344000136__16; if linked_1438 == nil { c__1927000678__auto____17 = ifn_1439.Invoke_O__O(arg_1440) } else { c__1927000678__auto____17 = linked_1438.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1437, arg_1440) }; var tmp25 any; var root_1463 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = seq_1344000136__16; if linked_1464 == nil { tmp25 = ifn_1465.Invoke_O__O(arg_1466) } else { tmp25 = linked_1464.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1463, arg_1466) }; seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = tmp25, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__17 any; var root_1441 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = seq_1344000136__16; if linked_1442 == nil { f__17 = ifn_1443.Invoke_O__O(arg_1444) } else { f__17 = linked_1442.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1441, arg_1444) }; var tmp26 any; var root_1445 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any; var root_1450 any = A_arbace_repr_go_print_A_const_38.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = f__17; if linked_1451 == nil { arg_1448 = ifn_1452.Invoke_O__O(arg_1453) } else { arg_1448 = linked_1451.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_op_A).Invoke_O_O__O(root_1450, arg_1453) }; var arg_1449 any = Lit_67; if linked_1446 == nil { tmp26 = ifn_1447.Invoke_O_O__O(arg_1448, arg_1449) } else { tmp26 = linked_1446.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1445, arg_1448, arg_1449) }; if jrt.J2g_Truth(tmp26) {
						var root_1471 any = A_arbace_repr_go_print_A_const_98.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = A_arbace_repr_go_print_A_const_99; var arg_1475 any = Lit_95; if linked_1472 == nil { ifn_1473.Invoke_O_O__O(arg_1474, arg_1475) } else { linked_1472.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_soft_A).Invoke_O_O_O__O(root_1471, arg_1474, arg_1475) }
						var root_1467 any = A_arbace_repr_go_print_A_const_122.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = f__17; if linked_1468 == nil { ifn_1469.Invoke_O__O(arg_1470) } else { linked_1468.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_top_decl_A).Invoke_O_O__O(root_1467, arg_1470) }
//line :287:1
						var tmp27 any; var root_1476 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = seq_1344000136__16; if linked_1477 == nil { tmp27 = ifn_1478.Invoke_O__O(arg_1479) } else { tmp27 = linked_1477.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1476, arg_1479) }; seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = tmp27, nil, 0, 0; continue L1 } else { var tmp28 any; var root_1480 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = seq_1344000136__16; if linked_1481 == nil { tmp28 = ifn_1482.Invoke_O__O(arg_1483) } else { tmp28 = linked_1481.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1480, arg_1483) }; seq_1344000136__11, chunk_1344000137__12, count_1344000138__13, i_1344000139__14 = tmp28, nil, 0, 0; continue L1 } } } }
//line :270:1
				break L1
			}


















			var root_1368 any = A_arbace_repr_go_print_A_const_141.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; if linked_1369 == nil { tmp22 = ifn_1370.Invoke__O() } else { tmp22 = linked_1369.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A).Invoke_O__O(root_1368) } }
//line :270:1
		return nil }(); var root_1371 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1373 lang.IFn; if








	linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; if linked_1372 == nil { ifn_1373.Invoke__O() } else { linked_1372.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1371) }; if /*line :270:1*/ tmp29 != nil { panic(tmp29) }; return tmp22 }





















func A_arbace_repr_go_print_print_file_A_New() *A_arbace_repr_go_print_print_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_repr_go_print_print_file_A) Ctor() {}
//line :292:1
func (t *A_arbace_repr_go_print_print_file_A) Invoke_O_O_O_O__O(self, p__1344000141__0, pkg_name__1, p__1344000142__2 any) any { var map__1344000143__4 any = p__1344000141__0; var map__1344000143__5 any; if lang.ISeq_InstanceOf(map__1344000143__4) { var tmp1 any; var root_1484 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = map__1344000143__4; if linked_1485 == nil { tmp1 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp1 = linked_1485.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1484, arg_1487) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1488 any = A_arbace_repr_go_print_A_const_157.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = map__1344000143__4; if linked_1489 == nil { tmp2 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp2 = linked_1489.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1488, arg_1491) }; map__1344000143__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1492 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = map__1344000143__4; if linked_1493 == nil { tmp3 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp3 = linked_1493.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1492, arg_1495) }; if jrt.J2g_Truth(tmp3) { var root_1496 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = map__1344000143__4; if linked_1497 == nil { map__1344000143__5 = ifn_1498.Invoke_O__O(arg_1499) } else { map__1344000143__5 = linked_1497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1496, arg_1499) } } else { map__1344000143__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000143__5 = map__1344000143__4 }; var opts__6 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_48); var decls__7 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_49); var file__8 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_47); var src__9 any = lang.RT_Get_O_O__O_NoInit(map__1344000143__5, A_arbace_repr_go_print_A_const_50); var map__1344000145__10 any = p__1344000142__2; var map__1344000145__11 any; if lang.ISeq_InstanceOf(map__1344000145__10) { var tmp4 any; var root_1500 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = map__1344000145__10; if linked_1501 == nil { tmp4 = ifn_1502.Invoke_O__O(arg_1503) } else { tmp4 = linked_1501.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1500, arg_1503) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1504 any = A_arbace_repr_go_print_A_const_157.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = map__1344000145__10; if linked_1505 == nil { tmp5 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp5 = linked_1505.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1504, arg_1507) }; map__1344000145__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp5, jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 any; var root_1508 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = map__1344000145__10; if linked_1509 == nil { tmp6 = ifn_1510.Invoke_O__O(arg_1511) } else { tmp6 = linked_1509.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1508, arg_1511) }; if jrt.J2g_Truth(tmp6) { var root_1512 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = map__1344000145__10; if linked_1513 == nil { map__1344000145__11 = ifn_1514.Invoke_O__O(arg_1515) } else { map__1344000145__11 = linked_1513.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1512, arg_1515) } } else { map__1344000145__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000145__11 = map__1344000145__10 }; var popts__12 any = map__1344000145__11; var layout__13 any = lang.RT_Get_O_O__O_NoInit(map__1344000145__11, A_arbace_repr_go_print_A_const_158); var line_directives_QMARK___14 any = lang.RT_Get_O_O__O_NoInit(map__1344000145__11, A_arbace_repr_go_print_A_const_128); var line_file__15 any = lang.RT_Get_O_O__O_NoInit(map__1344000145__11, A_arbace_repr_go_print_A_const_159); if





	lang.Util_Equiv_O_O__Z_NoInit(layout__13, A_arbace_repr_go_print_A_const_143) {
		var root_1516 any = A_arbace_repr_go_print_A_const_160.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, A_arbace_repr_go_print_print_file_full_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = file__8; var arg_1520 any = opts__6; var arg_1521 any = decls__7; var arg_1522 any = pkg_name__1; if linked_1517 == nil { return ifn_1518.Invoke_O_O_O_O__O(arg_1519, arg_1520, arg_1521, arg_1522) } else { return linked_1517.(*A_arbace_repr_go_print_print_file_full_A).Invoke_O_O_O_O_O__O(root_1516, arg_1519, arg_1520, arg_1521, arg_1522) } } else {
//line :298:1
			var lines_QMARK___16 any
			var G__1344000147__16_ any = layout__13
		L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1344000147__16_) >> 6 & 1 { case 0: if any(G__1344000147__16_) == any(A_arbace_repr_go_print_A_const_161) { lines_QMARK___16 = jrt.Boolean_TRUE.Ref(); break L1 }; case 1: if any(G__1344000147__16_) == any(A_arbace_repr_go_print_A_const_162) { lines_QMARK___16 = jrt.Boolean_FALSE.Ref(); break L1 }; default:}
			var tmp7 *lang.Keyword = A_arbace_repr_go_print_A_const_115; lines_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(file__8)))).Ref()}
//line :298:1
			var state_opts__17 any; var tmp8 any = A_arbace_repr_go_print_A_const_113; var tmp9 any = A_arbace_repr_go_print_A_const_128; var tmp10 any



			if lang.Util_Identical_O_O__Z_NoInit(line_directives_QMARK___14, nil) { tmp10 = jrt.Boolean_TRUE.Ref() } else { tmp10 = line_directives_QMARK___14 }
//line :298:1
			state_opts__17 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, lines_QMARK___16, tmp9, tmp10))




			var root_1530 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp12 any = A_arbace_repr_go_print_A_const_114; var tmp13 any; var root_1543 any = A_arbace_repr_go_print_A_const_142.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = state_opts__17; if linked_1544 == nil { tmp13 = ifn_1545.Invoke_O__O(arg_1546) } else { tmp13 = linked_1544.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A).Invoke_O_O__O(root_1543, arg_1546) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_repr_go_print_A_const_123; var tmp16 any = A_arbace_repr_go_print_A_const_154; var tmp17 any; var root_1547 any = A_arbace_repr_go_print_A_const_155.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A_fn_class); var ifn_1549 lang.IFn

			if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = decls__7; if linked_1548 == nil { tmp17 = ifn_1549.Invoke_O__O(arg_1550) } else { tmp17 = linked_1548.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_uses_grouped_QMARK__A).Invoke_O_O__O(root_1547, arg_1550) }
//line :303:1
			arg_1533 = tmp11.Invoke_O_O_O_O_O_O__O(tmp12, tmp14, tmp15, nil, tmp16, tmp17); if linked_1531 == nil { ifn_1532.Invoke_O__O(arg_1533) } else { linked_1531.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1530, arg_1533) }
//line :298:1
			var tmp18 any; tmp55 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








				{ var tmp19 any; var and__1927000168__auto____20 any = lines_QMARK___16; if jrt.J2g_Truth(and__1927000168__auto____20) { var and__1927000168__auto____21 any = line_file__15; if jrt.J2g_Truth(and__1927000168__auto____21) { tmp19 = src__9 } else { tmp19 = and__1927000168__auto____21 } } else { tmp19 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp19) {
					var root_1798 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_90, nil, Lit_91), jrt.RefArrayOf(jrt.Object_class, nil, src__9, nil)).Ref(); var arg_1802 any = A_arbace_repr_go_print_A_const_85; if linked_1799 == nil { ifn_1800.Invoke_O_O__O(arg_1801, arg_1802) } else { linked_1799.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1798, arg_1801, arg_1802) }
					var root_1551 any = A_arbace_repr_go_print_A_const_163.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_set_line_BANG__A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = A_arbace_repr_go_print_A_const_68; if linked_1552 == nil { ifn_1553.Invoke_O__O(arg_1554) } else { linked_1552.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_set_line_BANG__A).Invoke_O_O__O(root_1551, arg_1554) } }
//line :298:1
					var seq_1344000148__20 any; var root_1555 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1557 lang.IFn











					if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = A_arbace_repr_go_print_A_const_164.Invoke_O__O(opts__6); if linked_1556 == nil { seq_1344000148__20 = ifn_1557.Invoke_O__O(arg_1558) } else { seq_1344000148__20 = linked_1556.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1555, arg_1558) }
//line :298:1
					var chunk_1344000149__21 any; var count_1344000150__22 int64 = 0; var i_1344000151__23 int64 = 0; L2: for {











						if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000151__23, count_1344000150__22) { var b__24 any = lang.Indexed_Cast(chunk_1344000149__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000151__23)); var root_1803 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any; var root_1808 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1808, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1810 lang.IFn; if linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = b__24; if linked_1809 == nil { arg_1806 = ifn_1810.Invoke_O__O(arg_1811) } else { arg_1806 = linked_1809.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1808, arg_1811) }; var arg_1807 any = A_arbace_repr_go_print_A_const_85; if linked_1804 == nil { ifn_1805.Invoke_O_O__O(arg_1806, arg_1807) } else { linked_1804.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1803, arg_1806, arg_1807) }; seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, i_1344000151__23 = seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000151__23); continue L2 } else { var temp__1927000414__auto____24 any; var root_1559 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = seq_1344000148__20; if linked_1560 == nil { temp__1927000414__auto____24 = ifn_1561.Invoke_O__O(arg_1562) } else { temp__1927000414__auto____24 = linked_1560.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1559, arg_1562) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1344000148__25 any = temp__1927000414__auto____24; var tmp20 any; var root_1563 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = seq_1344000148__25; if linked_1564 == nil { tmp20 = ifn_1565.Invoke_O__O(arg_1566) } else { tmp20 = linked_1564.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1563, arg_1566) }; if jrt.J2g_Truth(tmp20) { var c__1927000678__auto____26 any; var root_1567 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = seq_1344000148__25; if linked_1568 == nil { c__1927000678__auto____26 = ifn_1569.Invoke_O__O(arg_1570) } else { c__1927000678__auto____26 = linked_1568.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1567, arg_1570) }; var tmp21 any; var root_1812 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1814 lang.IFn; if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = seq_1344000148__25; if linked_1813 == nil { tmp21 = ifn_1814.Invoke_O__O(arg_1815) } else { tmp21 = linked_1813.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1812, arg_1815) }; seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, i_1344000151__23 = tmp21, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var b__26 any; var root_1571 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = seq_1344000148__25; if linked_1572 == nil { b__26 = ifn_1573.Invoke_O__O(arg_1574) } else { b__26 = linked_1572.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1571, arg_1574) }; var root_1816 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1818 lang.IFn; if linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any; var root_1821 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = b__26; if linked_1822 == nil { arg_1819 = ifn_1823.Invoke_O__O(arg_1824) } else { arg_1819 = linked_1822.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1821, arg_1824) }; var arg_1820 any = A_arbace_repr_go_print_A_const_85; if linked_1817 == nil { ifn_1818.Invoke_O_O__O(arg_1819, arg_1820) } else { linked_1817.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1816, arg_1819, arg_1820) }; var tmp22 any; var root_1825 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = seq_1344000148__25; if linked_1826 == nil { tmp22 = ifn_1827.Invoke_O__O(arg_1828) } else { tmp22 = linked_1826.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1825, arg_1828) }; seq_1344000148__20, chunk_1344000149__21, count_1344000150__22, i_1344000151__23 = tmp22, nil, 0, 0; continue L2 } } }
//line :298:1
						break L2
					}











					var tmp23 any; var root_1575 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = A_arbace_repr_go_print_A_const_164.Invoke_O__O(opts__6); if linked_1576 == nil { tmp23 = ifn_1577.Invoke_O__O(arg_1578) } else { tmp23 = linked_1576.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1575, arg_1578) }; if jrt.J2g_Truth(tmp23) { var root_1579 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = A_arbace_repr_go_print_A_const_85; if linked_1580 == nil { ifn_1581.Invoke_O__O(arg_1582) } else { linked_1580.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1579, arg_1582) } }
//line :298:1
					var seq_1344000152__20 any; var root_1583 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1585 lang.IFn













					if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = A_arbace_repr_go_print_A_const_165.Invoke_O__O(opts__6); if linked_1584 == nil { seq_1344000152__20 = ifn_1585.Invoke_O__O(arg_1586) } else { seq_1344000152__20 = linked_1584.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1583, arg_1586) }
//line :298:1
					var chunk_1344000153__21 any; var count_1344000154__22 int64 = 0; var i_1344000155__23 int64 = 0; L3: for {













						if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000155__23, count_1344000154__22) { var d__24 any = lang.Indexed_Cast(chunk_1344000153__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000155__23)); var root_1829 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any; var root_1834 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = d__24; if linked_1835 == nil { arg_1832 = ifn_1836.Invoke_O__O(arg_1837) } else { arg_1832 = linked_1835.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1834, arg_1837) }; var arg_1833 any = A_arbace_repr_go_print_A_const_85; if linked_1830 == nil { ifn_1831.Invoke_O_O__O(arg_1832, arg_1833) } else { linked_1830.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1829, arg_1832, arg_1833) }; seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, i_1344000155__23 = seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000155__23); continue L3 } else { var temp__1927000414__auto____24_2 any; var root_1587 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = seq_1344000152__20; if linked_1588 == nil { temp__1927000414__auto____24_2 = ifn_1589.Invoke_O__O(arg_1590) } else { temp__1927000414__auto____24_2 = linked_1588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1587, arg_1590) }; if jrt.J2g_Truth(temp__1927000414__auto____24_2) { var seq_1344000152__25 any = temp__1927000414__auto____24_2; var tmp24 any; var root_1591 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = seq_1344000152__25; if linked_1592 == nil { tmp24 = ifn_1593.Invoke_O__O(arg_1594) } else { tmp24 = linked_1592.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1591, arg_1594) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____26_2 any; var root_1595 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = seq_1344000152__25; if linked_1596 == nil { c__1927000678__auto____26_2 = ifn_1597.Invoke_O__O(arg_1598) } else { c__1927000678__auto____26_2 = linked_1596.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1595, arg_1598) }; var tmp25 any; var root_1838 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1840 lang.IFn; if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = seq_1344000152__25; if linked_1839 == nil { tmp25 = ifn_1840.Invoke_O__O(arg_1841) } else { tmp25 = linked_1839.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1838, arg_1841) }; seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, i_1344000155__23 = tmp25, c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var d__26 any; var root_1599 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = seq_1344000152__25; if linked_1600 == nil { d__26 = ifn_1601.Invoke_O__O(arg_1602) } else { d__26 = linked_1600.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1599, arg_1602) }; var root_1842 any = A_arbace_repr_go_print_A_const_89.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any; var root_1847 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = d__26; if linked_1848 == nil { arg_1845 = ifn_1849.Invoke_O__O(arg_1850) } else { arg_1845 = linked_1848.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1847, arg_1850) }; var arg_1846 any = A_arbace_repr_go_print_A_const_85; if linked_1843 == nil { ifn_1844.Invoke_O_O__O(arg_1845, arg_1846) } else { linked_1843.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_comment_line_A).Invoke_O_O_O__O(root_1842, arg_1845, arg_1846) }; var tmp26 any; var root_1851 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = seq_1344000152__25; if linked_1852 == nil { tmp26 = ifn_1853.Invoke_O__O(arg_1854) } else { tmp26 = linked_1852.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1851, arg_1854) }; seq_1344000152__20, chunk_1344000153__21, count_1344000154__22, i_1344000155__23 = tmp26, nil, 0, 0; continue L3 } } }
//line :298:1
						break L3
					}













					var tmp27 any; var root_1603 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = A_arbace_repr_go_print_A_const_165.Invoke_O__O(opts__6); if linked_1604 == nil { tmp27 = ifn_1605.Invoke_O__O(arg_1606) } else { tmp27 = linked_1604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1603, arg_1606) }; if jrt.J2g_Truth(tmp27) { var root_1607 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = A_arbace_repr_go_print_A_const_85; if linked_1608 == nil { ifn_1609.Invoke_O__O(arg_1610) } else { linked_1608.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1607, arg_1610) } }
					var root_1611 any = A_arbace_repr_go_print_A_const_166.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_doc_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = A_arbace_repr_go_print_A_const_167.Invoke_O__O(opts__6); var arg_1615 any = A_arbace_repr_go_print_A_const_85; if linked_1612 == nil { ifn_1613.Invoke_O_O__O(arg_1614, arg_1615) } else { linked_1612.(*aot_arbace_repr_go_print_code.A_arbace_repr_go_print_code_write_doc_A).Invoke_O_O_O__O(root_1611, arg_1614, arg_1615) }
					var root_1616 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = Lit_92; if linked_1617 == nil { ifn_1618.Invoke_O__O(arg_1619) } else { linked_1617.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_1616, arg_1619) }; var root_1620 any = A_arbace_repr_go_print_A_const_83.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; if linked_1621 == nil { ifn_1622.Invoke__O() } else { linked_1621.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_sp_A).Invoke_O__O(root_1620) }; var root_1623 any = A_arbace_repr_go_print_A_const_80.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any; var root_1627 any = A_arbace_repr_go_print_A_const_82.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, A_arbace_repr_go_print_name_text_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any; var or__1927000174__auto____20 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____20) { arg_1630 = or__1927000174__auto____20 } else { arg_1630 = pkg_name__1 }; if linked_1628 == nil { arg_1626 = ifn_1629.Invoke_O__O(arg_1630) } else { arg_1626 = linked_1628.(*A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_1627, arg_1630) }; if linked_1624 == nil { ifn_1625.Invoke_O__O(arg_1626) } else { linked_1624.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_tok_A).Invoke_O_O__O(root_1623, arg_1626) }
					var root_1631 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = A_arbace_repr_go_print_A_const_85; if linked_1632 == nil { ifn_1633.Invoke_O__O(arg_1634) } else { linked_1632.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1631, arg_1634) }
					var root_1635 any = A_arbace_repr_go_print_A_const_168.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, A_arbace_repr_go_print_write_imports_A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = A_arbace_repr_go_print_A_const_140.Invoke_O__O(opts__6); if linked_1636 == nil { ifn_1637.Invoke_O__O(arg_1638) } else { linked_1636.(*A_arbace_repr_go_print_write_imports_A).Invoke_O_O__O(root_1635, arg_1638) }
//line :298:1
					var decls__20 any; var root_1639 any = A_arbace_repr_go_print_A_const_91.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1641 lang.IFn



















					if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = decls__7; if linked_1640 == nil { decls__20 = ifn_1641.Invoke_O__O(arg_1642) } else { decls__20 = linked_1640.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1639, arg_1642) }
//line :298:1
					var n__21 int32 = lang.RT_Count_O__I_NoInit(decls__20); var starts__22 any





















					if jrt.J2g_Truth(lines_QMARK___16) { var root_1643 any = A_arbace_repr_go_print_A_const_169.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, A_arbace_repr_go_print_chunk_starts_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = decls__20; if linked_1644 == nil { starts__22 = ifn_1645.Invoke_O__O(arg_1646) } else { starts__22 = linked_1644.(*A_arbace_repr_go_print_chunk_starts_A).Invoke_O_O__O(root_1643, arg_1646) } } else { starts__22 = nil }
					var tmp28 any; var root_1647 any = A_arbace_repr_go_print_A_const_53.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = starts__22; if linked_1648 == nil { tmp28 = ifn_1649.Invoke_O__O(arg_1650) } else { tmp28 = linked_1648.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1647, arg_1650) }; if jrt.J2g_Truth(tmp28) { var n__1927000701__auto____23 int64 = lang.RT_LongCast_I__J_NoInit(n__21); var i__24 int64 = 0; L4: for {
						if lang.Numbers_Lt_J_J__Z_NoInit(i__24, n__1927000701__auto____23) { var root_1855 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any = decls__20; var arg_1859 any = jrt.Long_ValueOf_J__Long_NoInit(i__24).Ref(); var arg_1860 any = lines_QMARK___16; var arg_1861 any = popts__12; var arg_1862 any = jrt.Boolean_TRUE.Ref(); if linked_1856 == nil { ifn_1857.Invoke_O_O_O_O_O__O(arg_1858, arg_1859, arg_1860, arg_1861, arg_1862) } else { linked_1856.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1855, arg_1858, arg_1859, arg_1860, arg_1861, arg_1862) }; i__24 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__24); continue L4 }
//line :321:1
						break L4 } } else { var chunks__23 any; var root_1651 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1653 lang.IFn

							if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = A_arbace_repr_go_print_A_const_170.GetRawRoot__O(); var arg_1655 any = starts__22; var arg_1656 any; var root_1657 any = A_arbace_repr_go_print_A_const_9.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any; var root_1662 any = A_arbace_repr_go_print_A_const_118.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = starts__22; var arg_1666 any = A_arbace_repr_go_print_A_const_68; if linked_1663 == nil { arg_1660 = ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { arg_1660 = linked_1663.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) }; var arg_1661 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__21).Ref(); if linked_1658 == nil { arg_1656 = ifn_1659.Invoke_O_O__O(arg_1660, arg_1661) } else { arg_1656 = linked_1658.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1657, arg_1660, arg_1661) }; if linked_1652 == nil { chunks__23 = ifn_1653.Invoke_O_O_O__O(arg_1654, arg_1655, arg_1656) } else { chunks__23 = linked_1652.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1651, arg_1654, arg_1655, arg_1656) }
//line :321:1
							var first_line__24 any; var tmp29 any = A_arbace_repr_go_print_print_file_first_line__1344000156_A_New_O(decls__20); var tmp30 *jrt.Class
							var fncls__1675 /*line :321:1*/*jrt.Class = A_arbace_repr_go_print_print_file_first_line__1344000156_A_fn_class



							if fncls__1675 == nil { var fncls__1675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_repr_go_print_print_file_first_line__1344000156_A_fn_class = fncls__1675d; tmp30 = fncls__1675d } else { tmp30 = fncls__1675 }; first_line__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil)
//line :321:1
							var printed__25 any; var root_1676 any = A_arbace_repr_go_print_A_const_171.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_1678 lang.IFn





							if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any; var tmp31 any = A_arbace_repr_go_print_print_file_fn__1344000159_A_New_O_O_O_O_O(popts__12, first_line__24, lines_QMARK___16, decls__20, state_opts__17); var tmp32 *jrt.Class; var fncls__1763 *jrt.Class = A_arbace_repr_go_print_print_file_fn__1344000159_A_fn_class; if fncls__1763 == nil { var fncls__1763d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_repr_go_print_print_file_fn__1344000159_A_fn_class = fncls__1763d; tmp32 = fncls__1763d } else { tmp32 = fncls__1763 }; arg_1679 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var arg_1680 any = chunks__23; if linked_1677 == nil { printed__25 = ifn_1678.Invoke_O_O__O(arg_1679, arg_1680) } else { printed__25 = linked_1677.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_1676, arg_1679, arg_1680) }
//line :321:1
							var n__1927000701__auto____26 int64; var tmp33 any; var root_1863 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1865 lang.IFn













							if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = starts__22; if linked_1864 == nil { tmp33 = ifn_1865.Invoke_O__O(arg_1866) } else { tmp33 = linked_1864.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1863, arg_1866) }; n__1927000701__auto____26 = lang.RT_LongCast_O__J_NoInit(tmp33)
//line :321:1
							var i__27 int64 = 0; L5: for {













								if lang.Numbers_Lt_J_J__Z_NoInit(i__27, n__1927000701__auto____26) { var root_1867 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = decls__20; var arg_1871 any = jrt.Long_ValueOf_J__Long_NoInit(i__27).Ref(); var arg_1872 any = lines_QMARK___16; var arg_1873 any = popts__12; var arg_1874 any = jrt.Boolean_TRUE.Ref(); if linked_1868 == nil { ifn_1869.Invoke_O_O_O_O_O__O(arg_1870, arg_1871, arg_1872, arg_1873, arg_1874) } else { linked_1868.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1867, arg_1870, arg_1871, arg_1872, arg_1873, arg_1874) }; i__27 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__27); continue L5 }
//line :321:1
								break L5 }; var seq_1344000168__26 any; var root_1764 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1766 lang.IFn















							if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any; var root_1768 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = A_arbace_repr_go_print_A_const_170.GetRawRoot__O(); var arg_1772 any = chunks__23; var arg_1773 any = printed__25; if linked_1769 == nil { arg_1767 = ifn_1770.Invoke_O_O_O__O(arg_1771, arg_1772, arg_1773) } else { arg_1767 = linked_1769.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1768, arg_1771, arg_1772, arg_1773) }; if linked_1765 == nil { seq_1344000168__26 = ifn_1766.Invoke_O__O(arg_1767) } else { seq_1344000168__26 = linked_1765.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1764, arg_1767) }
//line :321:1
							var chunk_1344000169__27 any; var count_1344000170__28 int64 = 0; var i_1344000171__29 int64 = 0; L6: for {















								if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000171__29, count_1344000170__28) { var vec__1344000172__30 any = lang.Indexed_Cast(chunk_1344000169__27).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000171__29)); var vec__1344000175__31 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000172__30, lang.RT_IntCast_J__I_NoInit(0), nil); var a__32 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000175__31, lang.RT_IntCast_J__I_NoInit(0), nil); var b__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000175__31, lang.RT_IntCast_J__I_NoInit(1), nil); var c__34 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000172__30, lang.RT_IntCast_J__I_NoInit(1), nil); var f__35 any = lang.RT_Nth_O_I__O_NoInit(decls__20, lang.RT_IntCast_O__I_NoInit(a__32)); var root_1907 any = A_arbace_repr_go_print_A_const_125.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, A_arbace_repr_go_print_decl_sep_BANG__A_fn_class); var ifn_1909 lang.IFn

									if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = f__35; var arg_1911 any; var tmp34 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp34.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp35 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____36 any = tmp35.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__35)); var tmp36 any; var root_1914 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = l__308000057__auto____36; if linked_1915 == nil { tmp36 = ifn_1916.Invoke_O__O(arg_1917) } else { tmp36 = linked_1915.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1914, arg_1917) }; if jrt.J2g_Truth(tmp36) { arg_1911 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____36)).Ref() } else { arg_1911 = nil } } else { arg_1911 = nil }; var arg_1912 any; var tmp37 any; var root_1918 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = f__35; if linked_1919 == nil { tmp37 = ifn_1920.Invoke_O__O(arg_1921) } else { tmp37 = linked_1919.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1918, arg_1921) }; arg_1912 = lang.RT_Nth_O_I__O_NoInit(tmp37, lang.RT_IntCast_J__I_NoInit(3)); var arg_1913 any = lines_QMARK___16; if linked_1908 == nil { ifn_1909.Invoke_O_O_O_O__O(arg_1910, arg_1911, arg_1912, arg_1913) } else { linked_1908.(*A_arbace_repr_go_print_decl_sep_BANG__A).Invoke_O_O_O_O_O__O(root_1907, arg_1910, arg_1911, arg_1912, arg_1913) }
									var tmp38 any; var root_1875 any = A_arbace_repr_go_print_A_const_175.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = c__34; var arg_1879 any = lang.IFn_Cast(first_line__24).Invoke_O__O(a__32); if linked_1876 == nil { tmp38 = ifn_1877.Invoke_O_O__O(arg_1878, arg_1879) } else { tmp38 = linked_1876.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A).Invoke_O_O_O__O(root_1875, arg_1878, arg_1879) }; if jrt.J2g_Truth(tmp38) { } else {
										var root_1922 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = decls__20; var arg_1926 any = a__32; var arg_1927 any = lines_QMARK___16; var arg_1928 any = popts__12; var arg_1929 any = jrt.Boolean_FALSE.Ref(); if linked_1923 == nil { ifn_1924.Invoke_O_O_O_O_O__O(arg_1925, arg_1926, arg_1927, arg_1928, arg_1929) } else { linked_1923.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1922, arg_1925, arg_1926, arg_1927, arg_1928, arg_1929) }
//line :340:1
										var seq_1344000178__35 any; var root_1880 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1882 lang.IFn

										if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any; var root_1884 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any; var na_1889 any = a__32; if jrt.Long_InstanceOf(na_1889) { var n0_1890 int64 = jrt.NN(jrt.Long_Cast(na_1889)).LongValue__J(); if n0_1890 == 9223372036854775807 { arg_1887 = lang.Numbers_Inc_O__Number_NoInit(na_1889) } else { arg_1887 = jrt.Long_ValueOf_J__Long_NoInit(n0_1890 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1889) { var n0_1890_2 float64 = jrt.NN(jrt.Double_Cast(na_1889)).DoubleValue__D(); arg_1887 = jrt.Double_ValueOf_D__Double_NoInit(n0_1890_2 + 1.0).Ref() } else { arg_1887 = lang.Numbers_Inc_O__Number_NoInit(na_1889) } }; var arg_1888 any = b__33; if linked_1885 == nil { arg_1883 = ifn_1886.Invoke_O_O__O(arg_1887, arg_1888) } else { arg_1883 = linked_1885.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1884, arg_1887, arg_1888) }; if linked_1881 == nil { seq_1344000178__35 = ifn_1882.Invoke_O__O(arg_1883) } else { seq_1344000178__35 = linked_1881.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1880, arg_1883) }
//line :340:1
										var chunk_1344000179__36 any; var count_1344000180__37 int64 = 0; var i_1344000181__38 int64 = 0; L7: for {

											if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000181__38, count_1344000180__37) { var i__39 any = lang.Indexed_Cast(chunk_1344000179__36).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000181__38)); var root_1930 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = decls__20; var arg_1934 any = i__39; var arg_1935 any = lines_QMARK___16; var arg_1936 any = popts__12; var arg_1937 any = jrt.Boolean_TRUE.Ref(); if linked_1931 == nil { ifn_1932.Invoke_O_O_O_O_O__O(arg_1933, arg_1934, arg_1935, arg_1936, arg_1937) } else { linked_1931.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1930, arg_1933, arg_1934, arg_1935, arg_1936, arg_1937) }; seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, i_1344000181__38 = seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000181__38); continue L7 } else { var temp__1927000414__auto____39 any; var root_1891 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = seq_1344000178__35; if linked_1892 == nil { temp__1927000414__auto____39 = ifn_1893.Invoke_O__O(arg_1894) } else { temp__1927000414__auto____39 = linked_1892.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1891, arg_1894) }; if jrt.J2g_Truth(temp__1927000414__auto____39) { var seq_1344000178__40 any = temp__1927000414__auto____39; var tmp39 any; var root_1895 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = seq_1344000178__40; if linked_1896 == nil { tmp39 = ifn_1897.Invoke_O__O(arg_1898) } else { tmp39 = linked_1896.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1895, arg_1898) }; if jrt.J2g_Truth(tmp39) { var c__1927000678__auto____41 any; var root_1899 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = seq_1344000178__40; if linked_1900 == nil { c__1927000678__auto____41 = ifn_1901.Invoke_O__O(arg_1902) } else { c__1927000678__auto____41 = linked_1900.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1899, arg_1902) }; var tmp40 any; var root_1938 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = seq_1344000178__40; if linked_1939 == nil { tmp40 = ifn_1940.Invoke_O__O(arg_1941) } else { tmp40 = linked_1939.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1938, arg_1941) }; seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, i_1344000181__38 = tmp40, c__1927000678__auto____41, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var i__41 any; var root_1903 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = seq_1344000178__40; if linked_1904 == nil { i__41 = ifn_1905.Invoke_O__O(arg_1906) } else { i__41 = linked_1904.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1903, arg_1906) }; var root_1942 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = decls__20; var arg_1946 any = i__41; var arg_1947 any = lines_QMARK___16; var arg_1948 any = popts__12; var arg_1949 any = jrt.Boolean_TRUE.Ref(); if linked_1943 == nil { ifn_1944.Invoke_O_O_O_O_O__O(arg_1945, arg_1946, arg_1947, arg_1948, arg_1949) } else { linked_1943.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1942, arg_1945, arg_1946, arg_1947, arg_1948, arg_1949) }; var tmp41 any; var root_1950 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = seq_1344000178__40; if linked_1951 == nil { tmp41 = ifn_1952.Invoke_O__O(arg_1953) } else { tmp41 = linked_1951.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1950, arg_1953) }; seq_1344000178__35, chunk_1344000179__36, count_1344000180__37, i_1344000181__38 = tmp41, nil, 0, 0; continue L7 } } }
//line :340:1
											break L7 } }
//line :337:1
									seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, i_1344000171__29 = seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000171__29); continue L6 } else { var temp__1927000414__auto____30 any; var root_1774 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = seq_1344000168__26; if linked_1775 == nil { temp__1927000414__auto____30 = ifn_1776.Invoke_O__O(arg_1777) } else { temp__1927000414__auto____30 = linked_1775.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1774, arg_1777) }; if jrt.J2g_Truth(temp__1927000414__auto____30) { var seq_1344000168__31 any = temp__1927000414__auto____30; var tmp42 any; var root_1778 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = seq_1344000168__31; if linked_1779 == nil { tmp42 = ifn_1780.Invoke_O__O(arg_1781) } else { tmp42 = linked_1779.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1778, arg_1781) }; if jrt.J2g_Truth(tmp42) { var c__1927000678__auto____32 any; var root_1782 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = seq_1344000168__31; if linked_1783 == nil { c__1927000678__auto____32 = ifn_1784.Invoke_O__O(arg_1785) } else { c__1927000678__auto____32 = linked_1783.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1782, arg_1785) }; var tmp43 any; var root_1954 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1956 lang.IFn; if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = seq_1344000168__31; if linked_1955 == nil { tmp43 = ifn_1956.Invoke_O__O(arg_1957) } else { tmp43 = linked_1955.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1954, arg_1957) }; seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, i_1344000171__29 = tmp43, c__1927000678__auto____32, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____32))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var vec__1344000182__32 any; var root_1786 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = seq_1344000168__31; if linked_1787 == nil { vec__1344000182__32 = ifn_1788.Invoke_O__O(arg_1789) } else { vec__1344000182__32 = linked_1787.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1786, arg_1789) }; var vec__1344000185__33 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000182__32, lang.RT_IntCast_J__I_NoInit(0), nil); var a__34 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000185__33, lang.RT_IntCast_J__I_NoInit(0), nil); var b__35 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000185__33, lang.RT_IntCast_J__I_NoInit(1), nil); var c__36 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000182__32, lang.RT_IntCast_J__I_NoInit(1), nil); var f__37 any = lang.RT_Nth_O_I__O_NoInit(decls__20, lang.RT_IntCast_O__I_NoInit(a__34)); var root_1990 any = A_arbace_repr_go_print_A_const_125.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, A_arbace_repr_go_print_decl_sep_BANG__A_fn_class); var ifn_1992 lang.IFn

										if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = f__37; var arg_1994 any; var tmp44 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if jrt.J2g_Truth(tmp44.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp45 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____38 any = tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__37)); var tmp46 any; var root_1997 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = l__308000057__auto____38; if linked_1998 == nil { tmp46 = ifn_1999.Invoke_O__O(arg_2000) } else { tmp46 = linked_1998.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1997, arg_2000) }; if jrt.J2g_Truth(tmp46) { arg_1994 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____38)).Ref() } else { arg_1994 = nil } } else { arg_1994 = nil }; var arg_1995 any; var tmp47 any; var root_2001 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2001, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = f__37; if linked_2002 == nil { tmp47 = ifn_2003.Invoke_O__O(arg_2004) } else { tmp47 = linked_2002.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_2001, arg_2004) }; arg_1995 = lang.RT_Nth_O_I__O_NoInit(tmp47, lang.RT_IntCast_J__I_NoInit(3)); var arg_1996 any = lines_QMARK___16; if linked_1991 == nil { ifn_1992.Invoke_O_O_O_O__O(arg_1993, arg_1994, arg_1995, arg_1996) } else { linked_1991.(*A_arbace_repr_go_print_decl_sep_BANG__A).Invoke_O_O_O_O_O__O(root_1990, arg_1993, arg_1994, arg_1995, arg_1996) }
										var tmp48 any; var root_1958 any = A_arbace_repr_go_print_A_const_175.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = c__36; var arg_1962 any = lang.IFn_Cast(first_line__24).Invoke_O__O(a__34); if linked_1959 == nil { tmp48 = ifn_1960.Invoke_O_O__O(arg_1961, arg_1962) } else { tmp48 = linked_1959.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_join_BANG__A).Invoke_O_O_O__O(root_1958, arg_1961, arg_1962) }; if jrt.J2g_Truth(tmp48) { } else {
											var root_2005 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_2007 lang.IFn; if linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = decls__20; var arg_2009 any = a__34; var arg_2010 any = lines_QMARK___16; var arg_2011 any = popts__12; var arg_2012 any = jrt.Boolean_FALSE.Ref(); if linked_2006 == nil { ifn_2007.Invoke_O_O_O_O_O__O(arg_2008, arg_2009, arg_2010, arg_2011, arg_2012) } else { linked_2006.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_2005, arg_2008, arg_2009, arg_2010, arg_2011, arg_2012) }
//line :340:1
											var seq_1344000188__37 any; var root_1963 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1965 lang.IFn

											if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any; var root_1967 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1967, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1969 lang.IFn; if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any; var na_1972 any = a__34; if jrt.Long_InstanceOf(na_1972) { var n0_1973 int64 = jrt.NN(jrt.Long_Cast(na_1972)).LongValue__J(); if n0_1973 == 9223372036854775807 { arg_1970 = lang.Numbers_Inc_O__Number_NoInit(na_1972) } else { arg_1970 = jrt.Long_ValueOf_J__Long_NoInit(n0_1973 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1972) { var n0_1973_2 float64 = jrt.NN(jrt.Double_Cast(na_1972)).DoubleValue__D(); arg_1970 = jrt.Double_ValueOf_D__Double_NoInit(n0_1973_2 + 1.0).Ref() } else { arg_1970 = lang.Numbers_Inc_O__Number_NoInit(na_1972) } }; var arg_1971 any = b__35; if linked_1968 == nil { arg_1966 = ifn_1969.Invoke_O_O__O(arg_1970, arg_1971) } else { arg_1966 = linked_1968.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1967, arg_1970, arg_1971) }; if linked_1964 == nil { seq_1344000188__37 = ifn_1965.Invoke_O__O(arg_1966) } else { seq_1344000188__37 = linked_1964.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1963, arg_1966) }
//line :340:1
											var chunk_1344000189__38 any; var count_1344000190__39 int64 = 0; var i_1344000191__40 int64 = 0; L8: for {

												if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000191__40, count_1344000190__39) { var i__41_2 any = lang.Indexed_Cast(chunk_1344000189__38).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000191__40)); var root_2013 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = decls__20; var arg_2017 any = i__41_2; var arg_2018 any = lines_QMARK___16; var arg_2019 any = popts__12; var arg_2020 any = jrt.Boolean_TRUE.Ref(); if linked_2014 == nil { ifn_2015.Invoke_O_O_O_O_O__O(arg_2016, arg_2017, arg_2018, arg_2019, arg_2020) } else { linked_2014.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_2013, arg_2016, arg_2017, arg_2018, arg_2019, arg_2020) }; seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, i_1344000191__40 = seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000191__40); continue L8 } else { var temp__1927000414__auto____41 any; var root_1974 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = seq_1344000188__37; if linked_1975 == nil { temp__1927000414__auto____41 = ifn_1976.Invoke_O__O(arg_1977) } else { temp__1927000414__auto____41 = linked_1975.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1974, arg_1977) }; if jrt.J2g_Truth(temp__1927000414__auto____41) { var seq_1344000188__42 any = temp__1927000414__auto____41; var tmp49 any; var root_1978 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = seq_1344000188__42; if linked_1979 == nil { tmp49 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp49 = linked_1979.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1978, arg_1981) }; if jrt.J2g_Truth(tmp49) { var c__1927000678__auto____43 any; var root_1982 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = seq_1344000188__42; if linked_1983 == nil { c__1927000678__auto____43 = ifn_1984.Invoke_O__O(arg_1985) } else { c__1927000678__auto____43 = linked_1983.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1982, arg_1985) }; var tmp50 any; var root_2021 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = seq_1344000188__42; if linked_2022 == nil { tmp50 = ifn_2023.Invoke_O__O(arg_2024) } else { tmp50 = linked_2022.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2021, arg_2024) }; seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, i_1344000191__40 = tmp50, c__1927000678__auto____43, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____43))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var i__43 any; var root_1986 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1988 lang.IFn; if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = seq_1344000188__42; if linked_1987 == nil { i__43 = ifn_1988.Invoke_O__O(arg_1989) } else { i__43 = linked_1987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1986, arg_1989) }; var root_2025 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = decls__20; var arg_2029 any = i__43; var arg_2030 any = lines_QMARK___16; var arg_2031 any = popts__12; var arg_2032 any = jrt.Boolean_TRUE.Ref(); if linked_2026 == nil { ifn_2027.Invoke_O_O_O_O_O__O(arg_2028, arg_2029, arg_2030, arg_2031, arg_2032) } else { linked_2026.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_2025, arg_2028, arg_2029, arg_2030, arg_2031, arg_2032) }; var tmp51 any; var root_2033 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = seq_1344000188__42; if linked_2034 == nil { tmp51 = ifn_2035.Invoke_O__O(arg_2036) } else { tmp51 = linked_2034.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2033, arg_2036) }; seq_1344000188__37, chunk_1344000189__38, count_1344000190__39, i_1344000191__40 = tmp51, nil, 0, 0; continue L8 } } }
//line :340:1
												break L8 } }
//line :337:1
										var tmp52 any; var root_2037 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = seq_1344000168__31; if linked_2038 == nil { tmp52 = ifn_2039.Invoke_O__O(arg_2040) } else { tmp52 = linked_2038.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2037, arg_2040) }; seq_1344000168__26, chunk_1344000169__27, count_1344000170__28, i_1344000171__29 = tmp52, nil, 0, 0; continue L6 } } }
//line :321:1
								break L6
							}
						}



















					var tmp53 any; var root_1790 any = A_arbace_repr_go_print_A_const_7.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var tmp54 *lang.Keyword = A_arbace_repr_go_print_A_const_121; var arg_1793 any = tmp54.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O()); if linked_1791 == nil { tmp53 = ifn_1792.Invoke_O__O(arg_1793) } else { tmp53 = linked_1791.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1790, arg_1793) }; if jrt.J2g_Truth(tmp53) { } else { var root_1794 any = A_arbace_repr_go_print_A_const_84.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A_fn_class); var ifn_1796 lang.IFn; if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = A_arbace_repr_go_print_A_const_85; if linked_1795 == nil { ifn_1796.Invoke_O__O(arg_1797) } else { linked_1795.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_nl_A).Invoke_O_O__O(root_1794, arg_1797) } }
					var root_1524 any = A_arbace_repr_go_print_A_const_141.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; if linked_1525 == nil { tmp18 = ifn_1526.Invoke__O() } else { tmp18 = linked_1525.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_result_A).Invoke_O__O(root_1524) } }
//line :298:1
				return nil }(); var root_1527 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1529 lang.IFn




			if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; if linked_1528 == nil { ifn_1529.Invoke__O() } else { linked_1528.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1527) }
//line :298:1
			if tmp55 != nil { panic(tmp55) }; return tmp18 } }


























func A_arbace_repr_go_print_print_file_first_line__1344000156_A_New_O(p0 any) *A_arbace_repr_go_print_print_file_first_line__1344000156_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_first_line__1344000156_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_repr_go_print_print_file_first_line__1344000156_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :325:1
func (t *A_arbace_repr_go_print_print_file_first_line__1344000156_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 any = t.F_decls; var f__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(a__1)); var tmp2 *jrt.Long; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if
													jrt.J2g_Truth(tmp3.Invoke_O__O(A_arbace_repr_go_print_A_const_114.Get__O())) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_A_const_115; var l__308000057__auto____3 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__2)); var tmp5 any; var root_1667 any = A_arbace_repr_go_print_A_const_116.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = l__308000057__auto____3; if linked_1668 == nil { tmp5 = ifn_1669.Invoke_O__O(arg_1670) } else { tmp5 = linked_1668.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_1667, arg_1670) }; if jrt.J2g_Truth(tmp5) { tmp2 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(l__308000057__auto____3)) } else { tmp2 = nil } } else { tmp2 = nil }; var tmp6 int64 = lang.RT_LongCast_O__J_NoInit(tmp2.Ref()); var tmp7 any; var root_1671 any = A_arbace_repr_go_print_A_const_117.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, A_arbace_repr_go_print_decl_pre_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = f__2; if linked_1672 == nil { tmp7 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp7 = linked_1672.(*A_arbace_repr_go_print_decl_pre_A).Invoke_O_O__O(root_1671, arg_1674) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(tmp6, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp7, lang.RT_IntCast_J__I_NoInit(3))))).Ref() }
func A_arbace_repr_go_print_print_file_fn__1344000159_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_print_file_fn__1344000159_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_fn__1344000159_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :327:1
func (t *A_arbace_repr_go_print_print_file_fn__1344000159_A) Ctor_O_O_O_O_O(c__popts, c__first_line, c__lines_QMARK_, c__decls, c__state_opts any) { t.F_popts = c__popts; t.F_first_line = c__first_line; t.F_lines_QMARK_ = c__lines_QMARK_; t.F_decls = c__decls; t.F_state_opts = c__state_opts }
//line :327:1
func (t *A_arbace_repr_go_print_print_file_fn__1344000159_A) Invoke_O_O__O(self, p__1344000158__1 any) any { var vec__1344000160__2 any = p__1344000158__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000160__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000160__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1687 any = A_arbace_repr_go_print_A_const_14.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1689 lang.IFn; if
														linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_114; var tmp3 any; var root_1696 any = A_arbace_repr_go_print_A_const_142.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = t.F_state_opts; if linked_1697 == nil { tmp3 = ifn_1698.Invoke_O__O(arg_1699) } else { tmp3 = linked_1697.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_new_state_A).Invoke_O_O__O(root_1696, arg_1699) }; arg_1690 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_1688 == nil { ifn_1689.Invoke_O__O(arg_1690) } else { linked_1688.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1687, arg_1690) }; var tmp4 any; tmp8 := /*line :327:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_1700 any = A_arbace_repr_go_print_A_const_173.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_start_at_BANG__A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = lang.IFn_Cast(t.F_first_line).Invoke_O__O(a__3); if linked_1701 == nil { ifn_1702.Invoke_O__O(arg_1703) } else { linked_1701.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_start_at_BANG__A).Invoke_O_O__O(root_1700, arg_1703) }
			var root_1704 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = t.F_decls; var arg_1708 any = a__3; var arg_1709 any = t.F_lines_QMARK_; var arg_1710 any = t.F_popts; var arg_1711 any = jrt.Boolean_FALSE.Ref(); if linked_1705 == nil { ifn_1706.Invoke_O_O_O_O_O__O(arg_1707, arg_1708, arg_1709, arg_1710, arg_1711) } else { linked_1705.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1704, arg_1707, arg_1708, arg_1709, arg_1710, arg_1711) }
//line :327:1
			var seq_1344000163__7 any; var root_1712 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1714 lang.IFn



			if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any; var root_1716 any = A_arbace_repr_go_print_A_const_134.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any; var na_1721 any = a__3; if jrt.Long_InstanceOf(na_1721) { var n0_1722 int64 = jrt.NN(jrt.Long_Cast(na_1721)).LongValue__J(); if n0_1722 == 9223372036854775807 { arg_1719 = lang.Numbers_Inc_O__Number_NoInit(na_1721) } else { arg_1719 = jrt.Long_ValueOf_J__Long_NoInit(n0_1722 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1721) { var n0_1722_2 float64 = jrt.NN(jrt.Double_Cast(na_1721)).DoubleValue__D(); arg_1719 = jrt.Double_ValueOf_D__Double_NoInit(n0_1722_2 + 1.0).Ref() } else { arg_1719 = lang.Numbers_Inc_O__Number_NoInit(na_1721) } }; var arg_1720 any = b__4; if linked_1717 == nil { arg_1715 = ifn_1718.Invoke_O_O__O(arg_1719, arg_1720) } else { arg_1715 = linked_1717.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_1716, arg_1719, arg_1720) }; if linked_1713 == nil { seq_1344000163__7 = ifn_1714.Invoke_O__O(arg_1715) } else { seq_1344000163__7 = linked_1713.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1712, arg_1715) }
//line :327:1
			var chunk_1344000164__8 any; var count_1344000165__9 int64 = 0; var i_1344000166__10 int64 = 0; L1: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000166__10, count_1344000165__9) { var i__11 any = lang.Indexed_Cast(chunk_1344000164__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000166__10)); var root_1739 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = t.F_decls; var arg_1743 any = i__11; var arg_1744 any = t.F_lines_QMARK_; var arg_1745 any = t.F_popts; var arg_1746 any = jrt.Boolean_TRUE.Ref(); if linked_1740 == nil { ifn_1741.Invoke_O_O_O_O_O__O(arg_1742, arg_1743, arg_1744, arg_1745, arg_1746) } else { linked_1740.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1739, arg_1742, arg_1743, arg_1744, arg_1745, arg_1746) }; seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, i_1344000166__10 = seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000166__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1723 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = seq_1344000163__7; if linked_1724 == nil { temp__1927000414__auto____11 = ifn_1725.Invoke_O__O(arg_1726) } else { temp__1927000414__auto____11 = linked_1724.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1723, arg_1726) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1344000163__12 any = temp__1927000414__auto____11; var tmp5 any; var root_1727 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = seq_1344000163__12; if linked_1728 == nil { tmp5 = ifn_1729.Invoke_O__O(arg_1730) } else { tmp5 = linked_1728.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1727, arg_1730) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____13 any; var root_1731 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = seq_1344000163__12; if linked_1732 == nil { c__1927000678__auto____13 = ifn_1733.Invoke_O__O(arg_1734) } else { c__1927000678__auto____13 = linked_1732.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1731, arg_1734) }; var tmp6 any; var root_1747 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = seq_1344000163__12; if linked_1748 == nil { tmp6 = ifn_1749.Invoke_O__O(arg_1750) } else { tmp6 = linked_1748.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1747, arg_1750) }; seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, i_1344000166__10 = tmp6, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var i__13 any; var root_1735 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = seq_1344000163__12; if linked_1736 == nil { i__13 = ifn_1737.Invoke_O__O(arg_1738) } else { i__13 = linked_1736.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1735, arg_1738) }; var root_1751 any = A_arbace_repr_go_print_A_const_174.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, A_arbace_repr_go_print_print_decl_BANG__A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = t.F_decls; var arg_1755 any = i__13; var arg_1756 any = t.F_lines_QMARK_; var arg_1757 any = t.F_popts; var arg_1758 any = jrt.Boolean_TRUE.Ref(); if linked_1752 == nil { ifn_1753.Invoke_O_O_O_O_O__O(arg_1754, arg_1755, arg_1756, arg_1757, arg_1758) } else { linked_1752.(*A_arbace_repr_go_print_print_decl_BANG__A).Invoke_O_O_O_O_O_O__O(root_1751, arg_1754, arg_1755, arg_1756, arg_1757, arg_1758) }; var tmp7 any; var root_1759 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = seq_1344000163__12; if linked_1760 == nil { tmp7 = ifn_1761.Invoke_O__O(arg_1762) } else { tmp7 = linked_1760.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1759, arg_1762) }; seq_1344000163__7, chunk_1344000164__8, count_1344000165__9, i_1344000166__10 = tmp7, nil, 0, 0; continue L1 } } }
//line :327:1
				break L1
			}



			var root_1681 any = A_arbace_repr_go_print_A_const_172.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_chunk_state_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; if linked_1682 == nil { tmp4 = ifn_1683.Invoke__O() } else { tmp4 = linked_1682.(*aot_arbace_repr_go_print_emit.A_arbace_repr_go_print_emit_chunk_state_A).Invoke_O__O(root_1681) } }
//line :327:1
		return nil }(); var root_1684 any = A_arbace_repr_go_print_A_const_13.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1686 lang.IFn; if
	linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; if linked_1685 == nil { ifn_1686.Invoke__O() } else { linked_1685.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1684) }; if /*line :327:1*/ tmp8 != nil { panic(tmp8) }; return tmp4 }


















func A_arbace_repr_go_print_print_forms_A_New() *A_arbace_repr_go_print_print_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_forms_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_repr_go_print_print_forms_A) Ctor() {}
//line :346:1
func (t *A_arbace_repr_go_print_print_forms_A) Invoke_O_O_O__O(self, pkg__0, opts__1 any) any {



	var root_2041 any = A_arbace_repr_go_print_A_const_17.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_176.GetRawRoot__O()).Invoke__O(); var arg_2045 any; var root_2049 any = A_arbace_repr_go_print_A_const_171.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_2051 lang.IFn
	if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any; var tmp1 any = A_arbace_repr_go_print_print_forms_fn__1344000193_A_New_O_O(pkg__0, opts__1); var tmp2 *jrt.Class; var fncls__2064 *jrt.Class = A_arbace_repr_go_print_print_forms_fn__1344000193_A_fn_class; if fncls__2064 == nil { var fncls__2064d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_repr_go_print_print_forms_fn__1344000193_A_fn_class = fncls__2064d; tmp2 = fncls__2064d } else { tmp2 = fncls__2064 }; arg_2052 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2053 any = A_arbace_repr_go_print_A_const_46.Invoke_O__O(pkg__0); if linked_2050 == nil { arg_2045 = ifn_2051.Invoke_O_O__O(arg_2052, arg_2053) } else { arg_2045 = linked_2050.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_2049, arg_2052, arg_2053) }
//line :350:1
	if linked_2042 == nil { return ifn_2043.Invoke_O_O__O(arg_2044, arg_2045) } else { return linked_2042.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2041, arg_2044, arg_2045) } }
func A_arbace_repr_go_print_print_forms_fn__1344000193_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_print_forms_fn__1344000193_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_forms_fn__1344000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_repr_go_print_print_forms_fn__1344000193_A) Ctor_O_O(c__pkg, c__opts any) { t.F_pkg = c__pkg; t.F_opts = c__opts }
//line :351:1
func (t *A_arbace_repr_go_print_print_forms_fn__1344000193_A) Invoke_O_O__O(self, fl__1 any) any { var tmp1 any; var root_2054 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = A_arbace_repr_go_print_A_const_45.Invoke_O__O(fl__1); if linked_2055 == nil { tmp1 = ifn_2056.Invoke_O__O(arg_2057) } else { tmp1 = linked_2055.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2054, arg_2057) }; var tmp2 any = tmp1; var tmp3 any; var root_2058 any = A_arbace_repr_go_print_A_const_177.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, A_arbace_repr_go_print_print_file_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = fl__1; var arg_2062 any = A_arbace_repr_go_print_A_const_45.Invoke_O__O(t.F_pkg); var arg_2063 any = t.F_opts; if linked_2059 == nil { tmp3 = ifn_2060.Invoke_O_O_O__O(arg_2061, arg_2062, arg_2063) } else { tmp3 = linked_2059.(*A_arbace_repr_go_print_print_file_A).Invoke_O_O_O_O__O(root_2058, arg_2061, arg_2062, arg_2063) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }





func A_arbace_repr_go_print_sha256_A_New() *A_arbace_repr_go_print_sha256_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_sha256_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_repr_go_print_sha256_A) Ctor() {}
//line :357:1
func (t *A_arbace_repr_go_print_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_97); var bs__3 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path()).Ref(); var root_2065 any = A_arbace_repr_go_print_A_const_28.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2067 lang.IFn; if


	linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var arg_2069 any; var root_2070 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any; var tmp1 any = A_arbace_repr_go_print_sha256_fn__1344000197_A_New(); var tmp2 *jrt.Class; var fncls__2085 *jrt.Class = A_arbace_repr_go_print_sha256_fn__1344000197_A_fn_class; if fncls__2085 == nil { var fncls__2085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_repr_go_print_sha256_fn__1344000197_A_fn_class = fncls__2085d; tmp2 = fncls__2085d } else { tmp2 = fncls__2085 }; arg_2073 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2074 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.J2g_CastArray[*jrt.ByteArray](bs__3, jrt.Prim_byte.ArrayClass())).Ref(); if linked_2071 == nil { arg_2069 = ifn_2072.Invoke_O_O__O(arg_2073, arg_2074) } else { arg_2069 = linked_2071.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2070, arg_2073, arg_2074) }; if linked_2066 == nil { return ifn_2067.Invoke_O_O__O(arg_2068, arg_2069) } else { return linked_2066.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2065, arg_2068, arg_2069) } }
//line :360:1
func A_arbace_repr_go_print_sha256_fn__1344000197_A_New() *A_arbace_repr_go_print_sha256_fn__1344000197_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_sha256_fn__1344000197_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_repr_go_print_sha256_fn__1344000197_A) Ctor() {}
//line :360:1
func (t *A_arbace_repr_go_print_sha256_fn__1344000197_A) Invoke_O_O__O(self, p1__1344000196_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_178.GetRawRoot__O()); var tmp2 int64; var na_2080 any = p1__1344000196_SHARP___1; var na_2081 int64 = 255; if jrt.Long_InstanceOf(na_2080) { var n0_2082 int64 = jrt.NN(jrt.Long_Cast(na_2080)).LongValue__J(); var n1_2083 int64 = na_2081; tmp2 = n0_2082 & n1_2083 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_2080, na_2081) }; return tmp1.Invoke_O_O__O(Lit_99, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_repr_go_print_copy_file_A_New() *A_arbace_repr_go_print_copy_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_file_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_go_print_copy_file_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_go_print_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 any; var root_2086 any = A_arbace_repr_go_print_A_const_179.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_2088 lang.IFn
	if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any = A_arbace_repr_go_print_A_const_180; var arg_2090 any; var tmp4 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp4 = jrt.StandardCopyOption_REPLACE_EXISTING; arg_2090 = lang.Tuple_Create_O__IPersistentVector(tmp4.Ref()); if linked_2087 == nil { tmp3 = ifn_2088.Invoke_O_O__O(arg_2089, arg_2090) } else { tmp3 = linked_2087.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_2086, arg_2089, arg_2090) }
//line :364:1
	return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_repr_go_print_json_string_A_New() *A_arbace_repr_go_print_json_string_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_json_string_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_repr_go_print_json_string_A) Ctor() {}
//line :367:1
func (t *A_arbace_repr_go_print_json_string_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_85); var tmp2 any; var root_2091 any = A_arbace_repr_go_print_A_const_181.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any; var root_2097 any = A_arbace_repr_go_print_A_const_181.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2099 lang.IFn; if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any; var root_2103 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = s__0; if linked_2104 == nil { arg_2100 = ifn_2105.Invoke_O__O(arg_2106) } else { arg_2100 = linked_2104.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2103, arg_2106) }; var arg_2101 any = Lit_86; var arg_2102 any = Lit_87; if linked_2098 == nil { arg_2094 = ifn_2099.Invoke_O_O_O__O(arg_2100, arg_2101, arg_2102) } else { arg_2094 = linked_2098.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2097, arg_2100, arg_2101, arg_2102) }; var arg_2095 any = Lit_85; var arg_2096 any = Lit_88; if linked_2092 == nil { tmp2 = ifn_2093.Invoke_O_O_O__O(arg_2094, arg_2095, arg_2096) } else { tmp2 = linked_2092.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2091, arg_2094, arg_2095, arg_2096) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref()
}
func A_arbace_repr_go_print_copy_files_A_New() *A_arbace_repr_go_print_copy_files_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_repr_go_print_copy_files_A) Ctor() {}
//line :370:1
func (t *A_arbace_repr_go_print_copy_files_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, written__3 any) any { var opts__5 any = A_arbace_repr_go_print_A_const_44.Invoke_O__O(pkg__0); var seq_1344000202__6 any; var root_2208 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2210 lang.IFn; if




	linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = A_arbace_repr_go_print_A_const_185.Invoke_O__O(opts__5); if linked_2209 == nil { seq_1344000202__6 = ifn_2210.Invoke_O__O(arg_2211) } else { seq_1344000202__6 = linked_2209.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2208, arg_2211) }; var chunk_1344000203__7 any; var count_1344000204__8 int64 = 0; var i_1344000205__9 int64 = 0; L1:
//line :370:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000205__9, count_1344000204__8) { var f__10 any = lang.Indexed_Cast(chunk_1344000203__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000205__9)); var root_2248 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2250 lang.IFn
			if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any; var tmp1 *jrt.File = jrt.File_Cast(src__1); var tmp2 any; var root_2253 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = f__10; if linked_2254 == nil { tmp2 = ifn_2255.Invoke_O__O(arg_2256) } else { tmp2 = linked_2254.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2253, arg_2256) }; arg_2251 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2)); var arg_2252 any; var tmp3 *jrt.File = jrt.File_Cast(out__2); var tmp4 any; var root_2257 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = f__10; if linked_2258 == nil { tmp4 = ifn_2259.Invoke_O__O(arg_2260) } else { tmp4 = linked_2258.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2257, arg_2260) }; arg_2252 = jrt.File_New_File_String(tmp3, jrt.String_Cast(tmp4)); if linked_2249 == nil { ifn_2250.Invoke_O_O__O(arg_2251, arg_2252) } else { linked_2249.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2248, arg_2251, arg_2252) }
//line :375:1
			seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, i_1344000205__9 = seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000205__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_2212 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = seq_1344000202__6; if linked_2213 == nil { temp__1927000414__auto____10 = ifn_2214.Invoke_O__O(arg_2215) } else { temp__1927000414__auto____10 = linked_2213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2212, arg_2215) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1344000202__11 any = temp__1927000414__auto____10; var tmp5 any; var root_2216 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = seq_1344000202__11; if linked_2217 == nil { tmp5 = ifn_2218.Invoke_O__O(arg_2219) } else { tmp5 = linked_2217.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2216, arg_2219) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_2220 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = seq_1344000202__11; if linked_2221 == nil { c__1927000678__auto____12 = ifn_2222.Invoke_O__O(arg_2223) } else { c__1927000678__auto____12 = linked_2221.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2220, arg_2223) }; var tmp6 any; var root_2261 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = seq_1344000202__11; if linked_2262 == nil { tmp6 = ifn_2263.Invoke_O__O(arg_2264) } else { tmp6 = linked_2262.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2261, arg_2264) }; seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, i_1344000205__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__12 any; var root_2224 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = seq_1344000202__11; if linked_2225 == nil { f__12 = ifn_2226.Invoke_O__O(arg_2227) } else { f__12 = linked_2225.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2224, arg_2227) }
				var root_2265 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2267 lang.IFn; if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any; var tmp7 *jrt.File = jrt.File_Cast(src__1); var tmp8 any; var root_2270 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2270, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2272 lang.IFn; if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = f__12; if linked_2271 == nil { tmp8 = ifn_2272.Invoke_O__O(arg_2273) } else { tmp8 = linked_2271.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2270, arg_2273) }; arg_2268 = jrt.File_New_File_String(tmp7, jrt.String_Cast(tmp8)); var arg_2269 any; var tmp9 *jrt.File = jrt.File_Cast(out__2); var tmp10 any; var root_2274 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2274, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2276 lang.IFn; if linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any = f__12; if linked_2275 == nil { tmp10 = ifn_2276.Invoke_O__O(arg_2277) } else { tmp10 = linked_2275.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2274, arg_2277) }; arg_2269 = jrt.File_New_File_String(tmp9, jrt.String_Cast(tmp10)); if linked_2266 == nil { ifn_2267.Invoke_O_O__O(arg_2268, arg_2269) } else { linked_2266.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2265, arg_2268, arg_2269) }
//line :375:1
				var tmp11 any; var root_2278 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = seq_1344000202__11; if linked_2279 == nil { tmp11 = ifn_2280.Invoke_O__O(arg_2281) } else { tmp11 = linked_2279.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2278, arg_2281) }; seq_1344000202__6, chunk_1344000203__7, count_1344000204__8, i_1344000205__9 = tmp11, nil, 0, 0; continue L1 } } }
//line :370:1
		break L1 }; var seq_1344000206__6 any; var root_2228 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2230 lang.IFn; if






	linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any = A_arbace_repr_go_print_A_const_186.Invoke_O__O(opts__5); if linked_2229 == nil { seq_1344000206__6 = ifn_2230.Invoke_O__O(arg_2231) } else { seq_1344000206__6 = linked_2229.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2228, arg_2231) }; var chunk_1344000207__7 any; var count_1344000208__8 int64 = 0; var i_1344000209__9 int64 = 0; L2:
//line :370:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000209__9, count_1344000208__8) { var vec__1344000210__10 any = lang.Indexed_Cast(chunk_1344000207__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000209__9)); var f__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000210__10, lang.RT_IntCast_J__I_NoInit(0), nil); var h__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000210__10, lang.RT_IntCast_J__I_NoInit(1), nil); var from__13 any; var tmp12 *jrt.File = jrt.File_Cast(src__1); var tmp13 any; var root_2282 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2284 lang.IFn
			if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = f__11; if linked_2283 == nil { tmp13 = ifn_2284.Invoke_O__O(arg_2285) } else { tmp13 = linked_2283.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2282, arg_2285) }
//line :377:1
			from__13 = jrt.File_New_File_String(tmp12, jrt.String_Cast(tmp13)); var got__14 any; var root_2286 any = A_arbace_repr_go_print_A_const_188.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, A_arbace_repr_go_print_sha256_A_fn_class); var ifn_2288 lang.IFn

			if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = from__13; if linked_2287 == nil { got__14 = ifn_2288.Invoke_O__O(arg_2289) } else { got__14 = linked_2287.(*A_arbace_repr_go_print_sha256_A).Invoke_O_O__O(root_2286, arg_2289) }
			var tmp14 any; var and__1927000168__auto____15 any = h__12; if jrt.J2g_Truth(and__1927000168__auto____15) { var root_2299 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = got__14; var arg_2303 any; var root_2304 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2304, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2306 lang.IFn; if linked_2305 == nil { ifn_2306 = lang.IFn_Cast(root_2304) } else { ifn_2306 = nil }; var arg_2307 any = h__12; if linked_2305 == nil { arg_2303 = ifn_2306.Invoke_O__O(arg_2307) } else { arg_2303 = linked_2305.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2304, arg_2307) }; if linked_2300 == nil { tmp14 = ifn_2301.Invoke_O_O__O(arg_2302, arg_2303) } else { tmp14 = linked_2300.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2299, arg_2302, arg_2303) } } else { tmp14 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp14) { var tmp15 any; var root_2308 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2310 lang.IFn
				if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil, Lit_57, nil, Lit_58, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__11, nil, got__14, nil, h__12)).Ref(); var arg_2312 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_47, f__11)); if linked_2309 == nil { tmp15 = ifn_2310.Invoke_O_O__O(arg_2311, arg_2312) } else { tmp15 = linked_2309.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2308, arg_2311, arg_2312) }
//line :380:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp15)))
			}
			var root_2290 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = from__13; var arg_2294 any; var tmp16 *jrt.File = jrt.File_Cast(out__2); var tmp17 any; var root_2295 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any = f__11; if linked_2296 == nil { tmp17 = ifn_2297.Invoke_O__O(arg_2298) } else { tmp17 = linked_2296.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2295, arg_2298) }; arg_2294 = jrt.File_New_File_String(tmp16, jrt.String_Cast(tmp17)); if linked_2291 == nil { ifn_2292.Invoke_O_O__O(arg_2293, arg_2294) } else { linked_2291.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2290, arg_2293, arg_2294) }
//line :377:1
			seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, i_1344000209__9 = seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000209__9); continue L2 } else { var temp__1927000414__auto____10_2 any; var root_2232 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2234 lang.IFn; if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any = seq_1344000206__6; if linked_2233 == nil { temp__1927000414__auto____10_2 = ifn_2234.Invoke_O__O(arg_2235) } else { temp__1927000414__auto____10_2 = linked_2233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2232, arg_2235) }; if jrt.J2g_Truth(temp__1927000414__auto____10_2) { var seq_1344000206__11 any = temp__1927000414__auto____10_2; var tmp18 any; var root_2236 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any = seq_1344000206__11; if linked_2237 == nil { tmp18 = ifn_2238.Invoke_O__O(arg_2239) } else { tmp18 = linked_2237.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2236, arg_2239) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____12_2 any; var root_2240 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2240, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2242 lang.IFn; if linked_2241 == nil { ifn_2242 = lang.IFn_Cast(root_2240) } else { ifn_2242 = nil }; var arg_2243 any = seq_1344000206__11; if linked_2241 == nil { c__1927000678__auto____12_2 = ifn_2242.Invoke_O__O(arg_2243) } else { c__1927000678__auto____12_2 = linked_2241.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2240, arg_2243) }; var tmp19 any; var root_2313 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2313, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = seq_1344000206__11; if linked_2314 == nil { tmp19 = ifn_2315.Invoke_O__O(arg_2316) } else { tmp19 = linked_2314.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2313, arg_2316) }; seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, i_1344000209__9 = tmp19, c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1344000213__12 any; var root_2244 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2244, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2246 lang.IFn; if linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any = seq_1344000206__11; if linked_2245 == nil { vec__1344000213__12 = ifn_2246.Invoke_O__O(arg_2247) } else { vec__1344000213__12 = linked_2245.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2244, arg_2247) }; var f__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000213__12, lang.RT_IntCast_J__I_NoInit(0), nil); var h__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000213__12, lang.RT_IntCast_J__I_NoInit(1), nil); var from__15 any; var tmp20 *jrt.File = jrt.File_Cast(src__1); var tmp21 any; var root_2317 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2317, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2319 lang.IFn
				if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var arg_2320 any = f__13; if linked_2318 == nil { tmp21 = ifn_2319.Invoke_O__O(arg_2320) } else { tmp21 = linked_2318.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2317, arg_2320) }
//line :377:1
				from__15 = jrt.File_New_File_String(tmp20, jrt.String_Cast(tmp21)); var got__16 any; var root_2321 any = A_arbace_repr_go_print_A_const_188.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, A_arbace_repr_go_print_sha256_A_fn_class); var ifn_2323 lang.IFn

				if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = from__15; if linked_2322 == nil { got__16 = ifn_2323.Invoke_O__O(arg_2324) } else { got__16 = linked_2322.(*A_arbace_repr_go_print_sha256_A).Invoke_O_O__O(root_2321, arg_2324) }
				var tmp22 any; var and__1927000168__auto____17 any = h__14; if jrt.J2g_Truth(and__1927000168__auto____17) { var root_2334 any = A_arbace_repr_go_print_A_const_127.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = got__16; var arg_2338 any; var root_2339 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = h__14; if linked_2340 == nil { arg_2338 = ifn_2341.Invoke_O__O(arg_2342) } else { arg_2338 = linked_2340.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2339, arg_2342) }; if linked_2335 == nil { tmp22 = ifn_2336.Invoke_O_O__O(arg_2337, arg_2338) } else { tmp22 = linked_2335.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2334, arg_2337, arg_2338) } } else { tmp22 = and__1927000168__auto____17 }; if jrt.J2g_Truth(tmp22) { var tmp23 any; var root_2343 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2345 lang.IFn
					if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_56, nil, Lit_57, nil, Lit_58, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__13, nil, got__16, nil, h__14)).Ref(); var arg_2347 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_47, f__13)); if linked_2344 == nil { tmp23 = ifn_2345.Invoke_O_O__O(arg_2346, arg_2347) } else { tmp23 = linked_2344.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2343, arg_2346, arg_2347) }
//line :380:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp23)))
				}
				var root_2325 any = A_arbace_repr_go_print_A_const_187.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, A_arbace_repr_go_print_copy_file_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = from__15; var arg_2329 any; var tmp24 *jrt.File = jrt.File_Cast(out__2); var tmp25 any; var root_2330 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = f__13; if linked_2331 == nil { tmp25 = ifn_2332.Invoke_O__O(arg_2333) } else { tmp25 = linked_2331.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2330, arg_2333) }; arg_2329 = jrt.File_New_File_String(tmp24, jrt.String_Cast(tmp25)); if linked_2326 == nil { ifn_2327.Invoke_O_O__O(arg_2328, arg_2329) } else { linked_2326.(*A_arbace_repr_go_print_copy_file_A).Invoke_O_O_O__O(root_2325, arg_2328, arg_2329) }
//line :377:1
				var tmp26 any; var root_2348 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = seq_1344000206__11; if linked_2349 == nil { tmp26 = ifn_2350.Invoke_O__O(arg_2351) } else { tmp26 = linked_2349.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2348, arg_2351) }; seq_1344000206__6, chunk_1344000207__7, count_1344000208__8, i_1344000209__9 = tmp26, nil, 0, 0; continue L2 } } }
//line :370:1
		break L2 }; var tmp27 lang.IFn =












	lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()); var tmp28 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_24); var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60); var tmp30 any; var root_2112 any = A_arbace_repr_go_print_A_const_183.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2114 lang.IFn; if

	linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = Lit_61; var arg_2116 any; var iter__1927001039__auto____9 any; var tmp31 any = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_New_O_O(src__1, out__2); var tmp32 *jrt.Class; var fncls__2207 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_fn_class; if fncls__2207 == nil { var fncls__2207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_fn_class = fncls__2207d; tmp32 = fncls__2207d } else { tmp32 = fncls__2207 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); arg_2116 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(written__3); if linked_2113 == nil { tmp30 = ifn_2114.Invoke_O_O__O(arg_2115, arg_2116) } else { tmp30 = linked_2113.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2112, arg_2115, arg_2116) }; return /*line :383:1*/ tmp27.Invoke_O_O__O(tmp28, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, nil, tmp30, nil)).Ref()) }

func A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A{}; t.Ctor_O_O(p0, p1); return t }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A) Ctor_O_O(c__src, c__out any) { t.F_src = c__src; t.F_out = c__out }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A) Invoke_O_O__O(self, s__1344000217__1 any) any { var tmp1 any = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_New_O_O_O_O(self, t.F_src, t.F_out, s__1344000217__1); var tmp2 *jrt.Class; var fncls__2206 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_fn_class; if fncls__2206 == nil { var fncls__2206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_fn_class = fncls__2206d; tmp2 = fncls__2206d } else { tmp2 = fncls__2206 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :385:1
func A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A) Ctor_O_O_O_O(c__iter__1344000216, c__src, c__out, c__s__1344000217 any) { t.F_iter__1344000216 = c__iter__1344000216; t.F_src = c__src; t.F_out = c__out; t.F_s__1344000217 = c__s__1344000217 }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A) Invoke_O__O(self any) any { { var s__1344000217__1 any; var t_ any = t.F_s__1344000217; t.F_s__1344000217 = nil; s__1344000217__1 = t_; for { var temp__1927000414__auto____2 any; var root_2117 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = s__1344000217__1; if linked_2118 == nil { temp__1927000414__auto____2 = ifn_2119.Invoke_O__O(arg_2120) } else { temp__1927000414__auto____2 = linked_2118.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2117, arg_2120) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1344000217__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2121 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any = s__1344000217__3; if linked_2122 == nil { tmp1 = ifn_2123.Invoke_O__O(arg_2124) } else { tmp1 = linked_2122.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2121, arg_2124) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2125 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = s__1344000217__3; if linked_2126 == nil { c__1927001037__auto____4 = ifn_2127.Invoke_O__O(arg_2128) } else { c__1927001037__auto____4 = linked_2126.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2125, arg_2128) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1344000219__6 any; var root_2129 any = A_arbace_repr_go_print_A_const_25.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2130 == nil { b__1344000219__6 = ifn_2131.Invoke_O__O(arg_2132) } else { b__1344000219__6 = linked_2130.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2129, arg_2132) }; var tmp2 any = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_New_O_O_O_I_O(t.F_src, b__1344000219__6, t.F_out, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2154 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_fn_class; if fncls__2154 == nil { var fncls__2154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_fn_class = fncls__2154d; tmp3 = fncls__2154d } else { tmp3 = fncls__2154 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2155 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any; var root_2160 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any = b__1344000219__6; if linked_2161 == nil { arg_2158 = ifn_2162.Invoke_O__O(arg_2163) } else { arg_2158 = linked_2161.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2160, arg_2163) }; var arg_2159 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1344000216); var tmp5 any; var root_2164 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2166 lang.IFn; if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = s__1344000217__3; if linked_2165 == nil { tmp5 = ifn_2166.Invoke_O__O(arg_2167) } else { tmp5 = linked_2165.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2164, arg_2167) }; arg_2159 = tmp4.Invoke_O__O(tmp5); if linked_2156 == nil { return ifn_2157.Invoke_O_O__O(arg_2158, arg_2159) } else { return linked_2156.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2155, arg_2158, arg_2159) } } else { var root_2168 any = A_arbace_repr_go_print_A_const_33.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2170 lang.IFn; if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any; var root_2173 any = A_arbace_repr_go_print_A_const_34.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = b__1344000219__6; if linked_2174 == nil { arg_2171 = ifn_2175.Invoke_O__O(arg_2176) } else { arg_2171 = linked_2174.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2173, arg_2176) }; var arg_2172 any; if linked_2169 == nil { return ifn_2170.Invoke_O_O__O(arg_2171, arg_2172) } else { return linked_2169.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2168, arg_2171, arg_2172) } } } else { var n__4 any; var root_2177 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = s__1344000217__3; if linked_2178 == nil { n__4 = ifn_2179.Invoke_O__O(arg_2180) } else { n__4 = linked_2178.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2177, arg_2180) }; var root_2181 any = A_arbace_repr_go_print_A_const_36.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66, nil); var tmp7 any; var root_2186 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2188 lang.IFn
															if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any; var tmp8 *jrt.File = jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(); var tmp9 any; var root_2190 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = n__4; if linked_2191 == nil { tmp9 = ifn_2192.Invoke_O__O(arg_2193) } else { tmp9 = linked_2191.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2190, arg_2193) }; arg_2189 = jrt.File_New_File_String(tmp8, jrt.String_Cast(tmp9)).GetPath__String().Ref(); if linked_2187 == nil { tmp7 = ifn_2188.Invoke_O__O(arg_2189) } else { tmp7 = linked_2187.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2186, arg_2189) }; var tmp10 any = tmp7; var tmp11 any; var root_2194 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2196 lang.IFn
															if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any; var tmp12 *jrt.File = jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(); var tmp13 any; var root_2198 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2198, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any = n__4; if linked_2199 == nil { tmp13 = ifn_2200.Invoke_O__O(arg_2201) } else { tmp13 = linked_2199.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2198, arg_2201) }; arg_2197 = jrt.File_New_File_String(tmp12, jrt.String_Cast(tmp13)).GetPath__String().Ref(); if linked_2195 == nil { tmp11 = ifn_2196.Invoke_O__O(arg_2197) } else { tmp11 = linked_2195.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2194, arg_2197) }
//line :386:1
	arg_2184 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp11)).Ref()
//line :385:1
	var arg_2185 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1344000216); var tmp15 any; var root_2202 any = A_arbace_repr_go_print_A_const_29.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = s__1344000217__3; if linked_2203 == nil { tmp15 = ifn_2204.Invoke_O__O(arg_2205) } else { tmp15 = linked_2203.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2202, arg_2205) }; arg_2185 = tmp14.Invoke_O__O(tmp15); if linked_2182 == nil { return ifn_2183.Invoke_O_O__O(arg_2184, arg_2185) } else { return linked_2182.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2181, arg_2184, arg_2185) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :385:1
func A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A) Ctor_O_O_O_I_O(c__src, c__b__1344000219, c__out any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_src = c__src; t.F_b__1344000219 = c__b__1344000219; t.F_out = c__out; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :385:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A) Invoke_O__O(self any) any { { var i__1344000218__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1344000218__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1344000218__1)); var root_2133 any = A_arbace_repr_go_print_A_const_31.GetRawRoot__O(); var linked_2134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2133, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2135 lang.IFn; if linked_2134 == nil { ifn_2135 = lang.IFn_Cast(root_2133) } else { ifn_2135 = nil }; var arg_2136 any = t.F_b__1344000219; var arg_2137 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66, nil); var tmp3 any; var root_2138 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2140 lang.IFn
																	if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any; var tmp4 *jrt.File = jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(); var tmp5 any; var root_2142 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2142, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = n__2; if linked_2143 == nil { tmp5 = ifn_2144.Invoke_O__O(arg_2145) } else { tmp5 = linked_2143.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2142, arg_2145) }; arg_2141 = jrt.File_New_File_String(tmp4, jrt.String_Cast(tmp5)).GetPath__String().Ref(); if linked_2139 == nil { tmp3 = ifn_2140.Invoke_O__O(arg_2141) } else { tmp3 = linked_2139.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2138, arg_2141) }; var tmp6 any = tmp3; var tmp7 any; var root_2146 any = A_arbace_repr_go_print_A_const_184.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, A_arbace_repr_go_print_json_string_A_fn_class); var ifn_2148 lang.IFn
																	if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any; var tmp8 *jrt.File = jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(); var tmp9 any; var root_2150 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any = n__2; if linked_2151 == nil { tmp9 = ifn_2152.Invoke_O__O(arg_2153) } else { tmp9 = linked_2151.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2150, arg_2153) }; arg_2149 = jrt.File_New_File_String(tmp8, jrt.String_Cast(tmp9)).GetPath__String().Ref(); if linked_2147 == nil { tmp7 = ifn_2148.Invoke_O__O(arg_2149) } else { tmp7 = linked_2147.(*A_arbace_repr_go_print_json_string_A).Invoke_O_O__O(root_2146, arg_2149) }
//line :386:1
	arg_2137 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref()
//line :385:1
	if linked_2134 == nil { ifn_2135.Invoke_O_O__O(arg_2136, arg_2137) } else { linked_2134.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2133, arg_2136, arg_2137) }; i__1344000218__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1344000218__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_print_build_env_A_New() *A_arbace_repr_go_print_build_env_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_build_env_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_repr_go_print_build_env_A) Ctor() {}
//line :390:1
func (t *A_arbace_repr_go_print_build_env_A) Invoke_O_O_O__O(self, config__0, goroot__1 any) any { var G__1344000227__3_ any; var tmp1 *jrt.String; if



	jrt.J2g_Truth(A_arbace_repr_go_print_A_const_189.Invoke_O__O(config__0)) { tmp1 = Lit_35 } else { tmp1 = Lit_36 }; G__1344000227__3_ = /*line :390:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_27, goroot__1, Lit_28, Lit_29, Lit_30, Lit_31, Lit_32, Lit_33, Lit_34, tmp1.Ref())); var G__1344000227__4_ any; if


	jrt.J2g_Truth(A_arbace_repr_go_print_A_const_190.Invoke_O__O(config__0)) {

		var root_2352 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = G__1344000227__3_; var arg_2356 any = Lit_37; var arg_2357 any = A_arbace_repr_go_print_A_const_190.Invoke_O__O(config__0); if linked_2353 == nil { G__1344000227__4_ = ifn_2354.Invoke_O_O_O__O(arg_2355, arg_2356, arg_2357) } else { G__1344000227__4_ = linked_2353.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2352, arg_2355, arg_2356, arg_2357) } } else {
//line :393:1
			G__1344000227__4_ = G__1344000227__3_ }; var G__1344000227__5_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_191.Invoke_O__O(config__0)) {


				var root_2358 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2358, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2360 lang.IFn; if linked_2359 == nil { ifn_2360 = lang.IFn_Cast(root_2358) } else { ifn_2360 = nil }; var arg_2361 any = G__1344000227__4_; var arg_2362 any = Lit_38; var arg_2363 any = A_arbace_repr_go_print_A_const_191.Invoke_O__O(config__0); if linked_2359 == nil { G__1344000227__5_ = ifn_2360.Invoke_O_O_O__O(arg_2361, arg_2362, arg_2363) } else { G__1344000227__5_ = linked_2359.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2358, arg_2361, arg_2362, arg_2363) } } else {
//line :393:1
					G__1344000227__5_ = G__1344000227__4_ }; var G__1344000227__6_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_192.Invoke_O__O(config__0)) {



						var root_2364 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2364, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2366 lang.IFn; if linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = G__1344000227__5_; var arg_2368 any = Lit_39; var arg_2369 any = A_arbace_repr_go_print_A_const_192.Invoke_O__O(config__0); if linked_2365 == nil { G__1344000227__6_ = ifn_2366.Invoke_O_O_O__O(arg_2367, arg_2368, arg_2369) } else { G__1344000227__6_ = linked_2365.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2364, arg_2367, arg_2368, arg_2369) } } else {
//line :393:1
							G__1344000227__6_ = G__1344000227__5_ }; var G__1344000227__7_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_193.Invoke_O__O(config__0)) {




								var root_2370 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = G__1344000227__6_; var arg_2374 any = Lit_40; var arg_2375 any = A_arbace_repr_go_print_A_const_193.Invoke_O__O(config__0); if linked_2371 == nil { G__1344000227__7_ = ifn_2372.Invoke_O_O_O__O(arg_2373, arg_2374, arg_2375) } else { G__1344000227__7_ = linked_2371.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2370, arg_2373, arg_2374, arg_2375) } } else {
//line :393:1
									G__1344000227__7_ = G__1344000227__6_ }; var tmp2 any; var root_2376 any = A_arbace_repr_go_print_A_const_194.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2378 lang.IFn; if





	linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = A_arbace_repr_go_print_A_const_195.Invoke_O__O(config__0); if linked_2377 == nil { tmp2 = ifn_2378.Invoke_O__O(arg_2379) } else { tmp2 = linked_2377.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2376, arg_2379) }; if /*line :393:1*/ jrt.J2g_Truth(tmp2) {





		var root_2380 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2380, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any = G__1344000227__7_; var arg_2384 any = Lit_41; var arg_2385 any = A_arbace_repr_go_print_A_const_195.Invoke_O__O(config__0); if linked_2381 == nil { return ifn_2382.Invoke_O_O_O__O(arg_2383, arg_2384, arg_2385) } else { return linked_2381.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2380, arg_2383, arg_2384, arg_2385) } } else {
//line :393:1
			return G__1344000227__7_ } }







func A_arbace_repr_go_print_run_A_New() *A_arbace_repr_go_print_run_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_run_A{}; t.Ctor(); return t }
//line :401:1
func (t *A_arbace_repr_go_print_run_A) Ctor() {}
//line :401:1
func (t *A_arbace_repr_go_print_run_A) Invoke_O_O_O_O__O(self, cmd__0, dir__1, env__2 any) any { var pb__4 any; var tmp1 any; var root_2386 any = A_arbace_repr_go_print_A_const_132.GetRawRoot__O(); var linked_2387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2386, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2388 lang.IFn; if
												linked_2387 == nil { ifn_2388 = lang.IFn_Cast(root_2386) } else { ifn_2388 = nil }; var arg_2389 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var arg_2390 any = cmd__0; if linked_2387 == nil { tmp1 = ifn_2388.Invoke_O_O__O(arg_2389, arg_2390) } else { tmp1 = linked_2387.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2386, arg_2389, arg_2390) }; pb__4 = /*line :401:1*/jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp1));

	jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__5 any = /*line :401:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Environment__Map(); var seq_1344000229__6 any; var root_2395 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2395, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2397 lang.IFn; if



	linked_2396 == nil { ifn_2397 = lang.IFn_Cast(root_2395) } else { ifn_2397 = nil }; var arg_2398 any = env__2; if linked_2396 == nil { seq_1344000229__6 = ifn_2397.Invoke_O__O(arg_2398) } else { seq_1344000229__6 = linked_2396.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2395, arg_2398) }; var chunk_1344000230__7 any; var count_1344000231__8 int64 = 0; var i_1344000232__9 int64 = 0; L1:
//line :401:1
	for {



		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000232__9, count_1344000231__8) { var vec__1344000233__10 any = lang.Indexed_Cast(chunk_1344000230__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000232__9)); var k__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000233__10, lang.RT_IntCast_J__I_NoInit(0), nil); var v__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000233__10, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__11, v__12); seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, i_1344000232__9 = seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000232__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_2399 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = seq_1344000229__6; if linked_2400 == nil { temp__1927000414__auto____10 = ifn_2401.Invoke_O__O(arg_2402) } else { temp__1927000414__auto____10 = linked_2400.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2399, arg_2402) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1344000229__11 any = temp__1927000414__auto____10; var tmp2 any; var root_2403 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = seq_1344000229__11; if linked_2404 == nil { tmp2 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp2 = linked_2404.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2403, arg_2406) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____12 any; var root_2407 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = seq_1344000229__11; if linked_2408 == nil { c__1927000678__auto____12 = ifn_2409.Invoke_O__O(arg_2410) } else { c__1927000678__auto____12 = linked_2408.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2407, arg_2410) }; var tmp3 any; var root_2415 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = seq_1344000229__11; if linked_2416 == nil { tmp3 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp3 = linked_2416.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2415, arg_2418) }; seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, i_1344000232__9 = tmp3, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1344000236__12 any; var root_2411 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = seq_1344000229__11; if linked_2412 == nil { vec__1344000236__12 = ifn_2413.Invoke_O__O(arg_2414) } else { vec__1344000236__12 = linked_2412.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2411, arg_2414) }; var k__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000236__12, lang.RT_IntCast_J__I_NoInit(0), nil); var v__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000236__12, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__13, v__14); var tmp4 any; var root_2419 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = seq_1344000229__11; if linked_2420 == nil { tmp4 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp4 = linked_2420.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2419, arg_2422) }; seq_1344000229__6, chunk_1344000230__7, count_1344000231__8, i_1344000232__9 = tmp4, nil, 0, 0; continue L1 } } }
//line :401:1
		break L1 };




	jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()); var p__5 any = /*line :401:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Start__Process(); var out__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_196.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(p__5).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Process_Cast(p__5).WaitFor__I()).Ref(), out__6) }









func A_arbace_repr_go_print_build_A_New() *A_arbace_repr_go_print_build_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_build_A{}; t.Ctor(); return t }
//line :411:1
func (t *A_arbace_repr_go_print_build_A) Ctor() {}
//line :411:1
func (t *A_arbace_repr_go_print_build_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, goroot__3 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_197; var config__5 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_44.Invoke_O__O(pkg__0)); var tags__6 any = A_arbace_repr_go_print_A_const_198.Invoke_O__O(config__5); var cmd__7 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_37.GetRawRoot__O()); var tmp3 any = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, goroot__3, nil)).Ref(), Lit_21, Lit_22, Lit_23, jrt.File_New_File_String(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File(), Lit_24).GetPath__String().Ref()); var tmp4 lang.IPersistentVector; var tmp5 any; var root_2429 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2431 lang.IFn; if






	linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any = tags__6; if linked_2430 == nil { tmp5 = ifn_2431.Invoke_O__O(arg_2432) } else { tmp5 = linked_2430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2429, arg_2432) }; if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_2433 any = A_arbace_repr_go_print_A_const_183.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = Lit_26; var arg_2437 any = tags__6; if linked_2434 == nil { tmp6 = ifn_2435.Invoke_O_O__O(arg_2436, arg_2437) } else { tmp6 = linked_2434.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2433, arg_2436, arg_2437) }; tmp4 = lang.Tuple_Create_O_O__IPersistentVector(Lit_25, tmp6) } else { tmp4 = nil }; cmd__7 = /*line :416:1*/tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_repr_go_print_A_const_199); var root_2438 any =



	A_arbace_repr_go_print_A_const_200.GetRawRoot__O(); var linked_2439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2438, A_arbace_repr_go_print_run_A_fn_class); var ifn_2440 lang.IFn; if linked_2439 == nil { ifn_2440 = lang.IFn_Cast(root_2438) } else { ifn_2440 = nil }; var arg_2441 any = cmd__7; var arg_2442 any = src__1; var arg_2443 any; var root_2444 any = A_arbace_repr_go_print_A_const_201.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2444, A_arbace_repr_go_print_build_env_A_fn_class); var ifn_2446 lang.IFn; if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = config__5; var arg_2448 any = goroot__3; if linked_2445 == nil { arg_2443 = ifn_2446.Invoke_O_O__O(arg_2447, arg_2448) } else { arg_2443 = linked_2445.(*A_arbace_repr_go_print_build_env_A).Invoke_O_O_O__O(root_2444, arg_2447, arg_2448) }; if linked_2439 == nil { return ifn_2440.Invoke_O_O_O__O(arg_2441, arg_2442, arg_2443) } else { return linked_2439.(*A_arbace_repr_go_print_run_A).Invoke_O_O_O_O__O(root_2438, arg_2441, arg_2442, arg_2443) } }

func A_arbace_repr_go_print_print_package_A_New() *A_arbace_repr_go_print_print_package_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_package_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_repr_go_print_print_package_A) Ctor() {}
//line :422:1
func (t *A_arbace_repr_go_print_print_package_A) Invoke_O_O_O_O__O(self, path__0, out_dir__1, opts__2 any) any { var pkg__4 any; var root_2449 any = A_arbace_repr_go_print_A_const_75.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, A_arbace_repr_go_print_collect_A_fn_class); var ifn_2451 lang.IFn; if


	linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any = path__0; if linked_2450 == nil { pkg__4 = ifn_2451.Invoke_O__O(arg_2452) } else { pkg__4 = linked_2450.(*A_arbace_repr_go_print_collect_A).Invoke_O_O__O(root_2449, arg_2452) }; var out__5 any; var tmp1 any; var root_2453 any = /*line :422:1*/A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2453, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2455 lang.IFn; if



	linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any = out_dir__1; if linked_2454 == nil { tmp1 = ifn_2455.Invoke_O__O(arg_2456) } else { tmp1 = linked_2454.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2453, arg_2456) }; out__5 = /*line :422:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); var layout__6 any = A_arbace_repr_go_print_A_const_158.Invoke_O__O(opts__2); var files__7 any; var root_2457 any = A_arbace_repr_go_print_A_const_202.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, A_arbace_repr_go_print_print_forms_A_fn_class); var ifn_2459 lang.IFn; if





	linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = pkg__4; var arg_2461 any; var root_2462 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2463 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2462, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2464 lang.IFn; if linked_2463 == nil { ifn_2464 = lang.IFn_Cast(root_2462) } else { ifn_2464 = nil }; var arg_2465 any = opts__2; var arg_2466 any = A_arbace_repr_go_print_A_const_158; var arg_2467 any; var or__1927000174__auto____7 any = layout__6; if jrt.J2g_Truth(or__1927000174__auto____7) { arg_2467 = or__1927000174__auto____7 } else { var tmp2 any = A_arbace_repr_go_print_A_const_143; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_203; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3.Invoke_O__O(A_arbace_repr_go_print_A_const_44.Invoke_O__O(pkg__4))) { arg_2467 = A_arbace_repr_go_print_A_const_143 } else { arg_2467 = nil } }; if linked_2463 == nil { arg_2461 = ifn_2464.Invoke_O_O_O__O(arg_2465, arg_2466, arg_2467) } else { arg_2461 = linked_2463.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2462, arg_2465, arg_2466, arg_2467) }; if linked_2458 == nil { files__7 = ifn_2459.Invoke_O_O__O(arg_2460, arg_2461) } else { files__7 = linked_2458.(*A_arbace_repr_go_print_print_forms_A).Invoke_O_O_O__O(root_2457, arg_2460, arg_2461) };
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(out__5)).Mkdirs__Z()); var seq_1344000241__8 any; var root_2472 any = /*line :422:1*/A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2474 lang.IFn; if







	linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = files__7; if linked_2473 == nil { seq_1344000241__8 = ifn_2474.Invoke_O__O(arg_2475) } else { seq_1344000241__8 = linked_2473.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2472, arg_2475) }; var chunk_1344000242__9 any; var count_1344000243__10 int64 = 0; var i_1344000244__11 int64 = 0; L1:
//line :422:1
	for {







		if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000244__11, count_1344000243__10) { var vec__1344000245__12 any = lang.Indexed_Cast(chunk_1344000242__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000244__11)); var n__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000245__12, lang.RT_IntCast_J__I_NoInit(0), nil); var text__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000245__12, lang.RT_IntCast_J__I_NoInit(1), nil)
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__13)), text__14)
//line :430:1
			seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, i_1344000244__11 = seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000244__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_2476 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = seq_1344000241__8; if linked_2477 == nil { temp__1927000414__auto____12 = ifn_2478.Invoke_O__O(arg_2479) } else { temp__1927000414__auto____12 = linked_2477.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2476, arg_2479) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1344000241__13 any = temp__1927000414__auto____12; var tmp4 any; var root_2480 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = seq_1344000241__13; if linked_2481 == nil { tmp4 = ifn_2482.Invoke_O__O(arg_2483) } else { tmp4 = linked_2481.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2480, arg_2483) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_2484 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = seq_1344000241__13; if linked_2485 == nil { c__1927000678__auto____14 = ifn_2486.Invoke_O__O(arg_2487) } else { c__1927000678__auto____14 = linked_2485.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2484, arg_2487) }; var tmp5 any; var root_2497 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2499 lang.IFn; if linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any = seq_1344000241__13; if linked_2498 == nil { tmp5 = ifn_2499.Invoke_O__O(arg_2500) } else { tmp5 = linked_2498.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2497, arg_2500) }; seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, i_1344000244__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1344000248__14 any; var root_2488 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2488, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2490 lang.IFn; if linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = seq_1344000241__13; if linked_2489 == nil { vec__1344000248__14 = ifn_2490.Invoke_O__O(arg_2491) } else { vec__1344000248__14 = linked_2489.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2488, arg_2491) }; var n__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000248__14, lang.RT_IntCast_J__I_NoInit(0), nil); var text__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000248__14, lang.RT_IntCast_J__I_NoInit(1), nil)
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__15)), text__16)
//line :430:1
				var tmp6 any; var root_2506 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = seq_1344000241__13; if linked_2507 == nil { tmp6 = ifn_2508.Invoke_O__O(arg_2509) } else { tmp6 = linked_2507.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2506, arg_2509) }; seq_1344000241__8, chunk_1344000242__9, count_1344000243__10, i_1344000244__11 = tmp6, nil, 0, 0; continue L1 } } }
//line :422:1
		break L1 }; var tmp7 any = A_arbace_repr_go_print_A_const_44; var tmp8 any = A_arbace_repr_go_print_A_const_46; var tmp9 any; var root_2468 any = A_arbace_repr_go_print_A_const_204.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2470 lang.IFn; if









	linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = files__7; if linked_2469 == nil { tmp9 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp9 = linked_2469.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2468, arg_2471) }; return /*line :422:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, pkg__4, tmp8, tmp9)) }











func A_arbace_repr_go_print_gofmt_file_A_New() *A_arbace_repr_go_print_gofmt_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_gofmt_file_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_repr_go_print_gofmt_file_A) Ctor() {}
//line :434:1
func (t *A_arbace_repr_go_print_gofmt_file_A) Invoke_O_O_O__O(self, goroot__0, f__1 any) any { var vec__1344000252__3 any; var root_2510 any = A_arbace_repr_go_print_A_const_200.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, A_arbace_repr_go_print_run_A_fn_class); var ifn_2512 lang.IFn; if
												linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_82), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_83, jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetPath__String().Ref()); var arg_2514 any = jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetParentFile__File().Ref(); var arg_2515 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2511 == nil { vec__1344000252__3 = ifn_2512.Invoke_O_O_O__O(arg_2513, arg_2514, arg_2515) } else { vec__1344000252__3 = linked_2511.(*A_arbace_repr_go_print_run_A).Invoke_O_O_O_O__O(root_2510, arg_2513, arg_2514, arg_2515) }; var status__4 any = /*line :434:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1344000252__3, lang.RT_IntCast_J__I_NoInit(0), nil); var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000252__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_2516 any = status__4; if

	jrt.Long_InstanceOf(na_2516) { var n0_2517 int64 = jrt.NN(jrt.Long_Cast(na_2516)).LongValue__J(); tmp1 = n0_2517 == 0 } else { if jrt.Double_InstanceOf(na_2516) { var n0_2517_2 float64 = jrt.NN(jrt.Double_Cast(na_2516)).DoubleValue__D(); tmp1 = n0_2517_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_2516) } }; if tmp1 { return nil } else { var tmp2 any; var root_2518 any = A_arbace_repr_go_print_A_const_54.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2520 lang.IFn
		if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1, nil, out__5)).Ref(); var arg_2522 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_47, f__1)); if linked_2519 == nil { tmp2 = ifn_2520.Invoke_O_O__O(arg_2521, arg_2522) } else { tmp2 = linked_2519.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2518, arg_2521, arg_2522) }
//line :436:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) } }


func A_arbace_repr_go_print__main_A_New() *A_arbace_repr_go_print__main_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print__main_A{}; t.Ctor(); return t }
//line :439:1
func (t *A_arbace_repr_go_print__main_A) Ctor() {}
//line :439:1
func (t *A_arbace_repr_go_print__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :439:1
	var as__3 any = argv__0; var opts__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var G__1344000256__5_ any; var root_2523 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2525 lang.IFn


		if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = as__3; if linked_2524 == nil { G__1344000256__5_ = ifn_2525.Invoke_O__O(arg_2526) } else { G__1344000256__5_ = linked_2524.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2523, arg_2526) }; switch lang.Util_Hash_O__I_NoInit(G__1344000256__5_) >> 7 & 15 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_3) {
			var tmp1 any; var root_2553 any = A_arbace_repr_go_print_A_const_107.GetRawRoot__O(); var linked_2554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2553, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2555 lang.IFn; if linked_2554 == nil { ifn_2555 = lang.IFn_Cast(root_2553) } else { ifn_2555 = nil }; var arg_2556 any = as__3; if linked_2554 == nil { tmp1 = ifn_2555.Invoke_O__O(arg_2556) } else { tmp1 = linked_2554.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2553, arg_2556) }; var tmp2 any = tmp1; var tmp3 any; var root_2557 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2557, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2559 lang.IFn; if linked_2558 == nil { ifn_2559 = lang.IFn_Cast(root_2557) } else { ifn_2559 = nil }; var arg_2560 any = opts__4; var arg_2561 any = A_arbace_repr_go_print_A_const_158; var arg_2562 any; var root_2563 any = A_arbace_repr_go_print_A_const_207.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any; var root_2567 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2567, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2569 lang.IFn; if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any = as__3; if linked_2568 == nil { arg_2566 = ifn_2569.Invoke_O__O(arg_2570) } else { arg_2566 = linked_2568.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2567, arg_2570) }; if linked_2564 == nil { arg_2562 = ifn_2565.Invoke_O__O(arg_2566) } else { arg_2562 = linked_2564.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2563, arg_2566) }; if linked_2558 == nil { tmp3 = ifn_2559.Invoke_O_O_O__O(arg_2560, arg_2561, arg_2562) } else { tmp3 = linked_2558.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2557, arg_2560, arg_2561, arg_2562) }; as__3, opts__4 = tmp2, tmp3; continue L1 }
//line :442:1
		case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_4) {


			var tmp4 any; var root_2571 any = A_arbace_repr_go_print_A_const_107.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2573 lang.IFn; if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = as__3; if linked_2572 == nil { tmp4 = ifn_2573.Invoke_O__O(arg_2574) } else { tmp4 = linked_2572.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2571, arg_2574) }; var tmp5 any = tmp4; var tmp6 any; var root_2575 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2576 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2575, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2577 lang.IFn; if linked_2576 == nil { ifn_2577 = lang.IFn_Cast(root_2575) } else { ifn_2577 = nil }; var arg_2578 any = opts__4; var arg_2579 any = A_arbace_repr_go_print_A_const_50; var arg_2580 any; var root_2581 any = A_arbace_repr_go_print_A_const_72.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2583 lang.IFn; if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = as__3; if linked_2582 == nil { arg_2580 = ifn_2583.Invoke_O__O(arg_2584) } else { arg_2580 = linked_2582.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2581, arg_2584) }; if linked_2576 == nil { tmp6 = ifn_2577.Invoke_O_O_O__O(arg_2578, arg_2579, arg_2580) } else { tmp6 = linked_2576.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2575, arg_2578, arg_2579, arg_2580) }; as__3, opts__4 = tmp5, tmp6; continue L1 }
//line :442:1
		case 9: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_5) {



			var tmp7 any; var root_2585 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2585, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2587 lang.IFn; if linked_2586 == nil { ifn_2587 = lang.IFn_Cast(root_2585) } else { ifn_2587 = nil }; var arg_2588 any = as__3; if linked_2586 == nil { tmp7 = ifn_2587.Invoke_O__O(arg_2588) } else { tmp7 = linked_2586.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2585, arg_2588) }; var tmp8 any = tmp7; var tmp9 any; var root_2589 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2589, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = opts__4; var arg_2593 any = A_arbace_repr_go_print_A_const_164; var arg_2594 any = jrt.Boolean_TRUE.Ref(); if linked_2590 == nil { tmp9 = ifn_2591.Invoke_O_O_O__O(arg_2592, arg_2593, arg_2594) } else { tmp9 = linked_2590.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2589, arg_2592, arg_2593, arg_2594) }; as__3, opts__4 = tmp8, tmp9; continue L1 }
//line :442:1
		case 10: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_6) {




			var tmp10 any; var root_2595 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = as__3; if linked_2596 == nil { tmp10 = ifn_2597.Invoke_O__O(arg_2598) } else { tmp10 = linked_2596.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2595, arg_2598) }; var tmp11 any = tmp10; var tmp12 any; var root_2599 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2599, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2601 lang.IFn; if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = opts__4; var arg_2603 any = A_arbace_repr_go_print_A_const_162; var arg_2604 any = jrt.Boolean_TRUE.Ref(); if linked_2600 == nil { tmp12 = ifn_2601.Invoke_O_O_O__O(arg_2602, arg_2603, arg_2604) } else { tmp12 = linked_2600.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2599, arg_2602, arg_2603, arg_2604) }; as__3, opts__4 = tmp11, tmp12; continue L1 }
//line :442:1
		case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_7) {





			var tmp13 any; var root_2605 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2607 lang.IFn; if linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any = as__3; if linked_2606 == nil { tmp13 = ifn_2607.Invoke_O__O(arg_2608) } else { tmp13 = linked_2606.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2605, arg_2608) }; var tmp14 any = tmp13; var tmp15 any; var root_2609 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2609, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2611 lang.IFn; if linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = opts__4; var arg_2613 any = A_arbace_repr_go_print_A_const_159; var arg_2614 any = jrt.Boolean_TRUE.Ref(); if linked_2610 == nil { tmp15 = ifn_2611.Invoke_O_O_O__O(arg_2612, arg_2613, arg_2614) } else { tmp15 = linked_2610.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2609, arg_2612, arg_2613, arg_2614) }; as__3, opts__4 = tmp14, tmp15; continue L1 }
//line :442:1
		case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__1344000256__5_, Lit_8) {

			var tmp16 any; var root_2615 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2615, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2617 lang.IFn; if linked_2616 == nil { ifn_2617 = lang.IFn_Cast(root_2615) } else { ifn_2617 = nil }; var arg_2618 any = as__3; if linked_2616 == nil { tmp16 = ifn_2617.Invoke_O__O(arg_2618) } else { tmp16 = linked_2616.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2615, arg_2618) }; var tmp17 any = tmp16; var tmp18 any; var root_2619 any = A_arbace_repr_go_print_A_const_43.GetRawRoot__O(); var linked_2620 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2619, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2621 lang.IFn; if linked_2620 == nil { ifn_2621 = lang.IFn_Cast(root_2619) } else { ifn_2621 = nil }; var arg_2622 any = opts__4; var arg_2623 any = A_arbace_repr_go_print_A_const_128; var arg_2624 any = jrt.Boolean_FALSE.Ref(); if linked_2620 == nil { tmp18 = ifn_2621.Invoke_O_O_O__O(arg_2622, arg_2623, arg_2624) } else { tmp18 = linked_2620.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2619, arg_2622, arg_2623, arg_2624) }; as__3, opts__4 = tmp17, tmp18; continue L1 }
//line :442:1
		default:}; var vec__1344000257__6 any = as__3; var forms__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000257__6, lang.RT_IntCast_J__I_NoInit(0), nil); var out__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000257__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp19 any
		var and__1927000168__auto____9 any = forms__7






		if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = out__8; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp19 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(as__3)))).Ref() } else { tmp19 = and__1927000168__auto____10 } } else { tmp19 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp19) { } else {
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O__O(Lit_9)
			jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :442:1
		var map__1344000260__9 any; var root_2528 any = A_arbace_repr_go_print_A_const_205.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2528, A_arbace_repr_go_print_print_package_A_fn_class); var ifn_2530 lang.IFn










		if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = forms__7; var arg_2532 any = out__8; var arg_2533 any = opts__4; if linked_2529 == nil { map__1344000260__9 = ifn_2530.Invoke_O_O_O__O(arg_2531, arg_2532, arg_2533) } else { map__1344000260__9 = linked_2529.(*A_arbace_repr_go_print_print_package_A).Invoke_O_O_O_O__O(root_2528, arg_2531, arg_2532, arg_2533) }
//line :442:1
		var map__1344000260__10 any










		if lang.ISeq_InstanceOf(map__1344000260__9) { var tmp20 any; var root_2534 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any = map__1344000260__9; if linked_2535 == nil { tmp20 = ifn_2536.Invoke_O__O(arg_2537) } else { tmp20 = linked_2535.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2534, arg_2537) }; if jrt.J2g_Truth(tmp20) { var tmp21 any; var root_2538 any = A_arbace_repr_go_print_A_const_157.GetRawRoot__O(); var linked_2539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2538, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2540 lang.IFn; if linked_2539 == nil { ifn_2540 = lang.IFn_Cast(root_2538) } else { ifn_2540 = nil }; var arg_2541 any = map__1344000260__9; if linked_2539 == nil { tmp21 = ifn_2540.Invoke_O__O(arg_2541) } else { tmp21 = linked_2539.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2538, arg_2541) }; map__1344000260__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp21, jrt.Object_class.ArrayClass())).Ref() } else { var tmp22 any; var root_2542 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2544 lang.IFn; if linked_2543 == nil { ifn_2544 = lang.IFn_Cast(root_2542) } else { ifn_2544 = nil }; var arg_2545 any = map__1344000260__9; if linked_2543 == nil { tmp22 = ifn_2544.Invoke_O__O(arg_2545) } else { tmp22 = linked_2543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2542, arg_2545) }; if jrt.J2g_Truth(tmp22) { var root_2546 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2548 lang.IFn; if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any = map__1344000260__9; if linked_2547 == nil { map__1344000260__10 = ifn_2548.Invoke_O__O(arg_2549) } else { map__1344000260__10 = linked_2547.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2546, arg_2549) } } else { map__1344000260__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000260__10 = map__1344000260__9 }
//line :442:1
		var package__11 any = lang.RT_Get_O_O__O_NoInit(map__1344000260__10, A_arbace_repr_go_print_A_const_44); var files__12 any = lang.RT_Get_O_O__O_NoInit(map__1344000260__10, A_arbace_repr_go_print_A_const_46); var outf__13 any = jrt.File_New_String(jrt.String_Cast(out__8)); var seq_1344000262__14 any; var root_2629 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2631 lang.IFn












		if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = files__12; if linked_2630 == nil { seq_1344000262__14 = ifn_2631.Invoke_O__O(arg_2632) } else { seq_1344000262__14 = linked_2630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2629, arg_2632) }
//line :442:1
		var chunk_1344000263__15 any; var count_1344000264__16 int64 = 0; var i_1344000265__17 int64 = 0; L3: for {












			if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000265__17, count_1344000264__16) { var f__18 any = lang.Indexed_Cast(chunk_1344000263__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000265__17)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__18)).Ref()); seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, i_1344000265__17 = seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000265__17); continue L3 } else { var temp__1927000414__auto____18 any; var root_2633 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = seq_1344000262__14; if linked_2634 == nil { temp__1927000414__auto____18 = ifn_2635.Invoke_O__O(arg_2636) } else { temp__1927000414__auto____18 = linked_2634.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2633, arg_2636) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1344000262__19 any = temp__1927000414__auto____18; var tmp23 any; var root_2637 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any = seq_1344000262__19; if linked_2638 == nil { tmp23 = ifn_2639.Invoke_O__O(arg_2640) } else { tmp23 = linked_2638.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2637, arg_2640) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____20 any; var root_2641 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2643 lang.IFn; if linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = seq_1344000262__19; if linked_2642 == nil { c__1927000678__auto____20 = ifn_2643.Invoke_O__O(arg_2644) } else { c__1927000678__auto____20 = linked_2642.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2641, arg_2644) }; var tmp24 any; var root_2682 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any = seq_1344000262__19; if linked_2683 == nil { tmp24 = ifn_2684.Invoke_O__O(arg_2685) } else { tmp24 = linked_2683.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2682, arg_2685) }; seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, i_1344000265__17 = tmp24, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var f__20 any; var root_2645 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2647 lang.IFn; if linked_2646 == nil { ifn_2647 = lang.IFn_Cast(root_2645) } else { ifn_2647 = nil }; var arg_2648 any = seq_1344000262__19; if linked_2646 == nil { f__20 = ifn_2647.Invoke_O__O(arg_2648) } else { f__20 = linked_2646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2645, arg_2648) }; lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__20)).Ref()); var tmp25 any; var root_2690 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2690, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2692 lang.IFn; if linked_2691 == nil { ifn_2692 = lang.IFn_Cast(root_2690) } else { ifn_2692 = nil }; var arg_2693 any = seq_1344000262__19; if linked_2691 == nil { tmp25 = ifn_2692.Invoke_O__O(arg_2693) } else { tmp25 = linked_2691.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2690, arg_2693) }; seq_1344000262__14, chunk_1344000263__15, count_1344000264__16, i_1344000265__17 = tmp25, nil, 0, 0; continue L3 } } }
//line :442:1
			break L3
		}












		if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_162.Invoke_O__O(opts__4)) { var seq_1344000266__14 any; var root_2649 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2651 lang.IFn
			if linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any = files__12; if linked_2650 == nil { seq_1344000266__14 = ifn_2651.Invoke_O__O(arg_2652) } else { seq_1344000266__14 = linked_2650.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2649, arg_2652) }
//line :456:1
			var chunk_1344000267__15 any; var count_1344000268__16 int64 = 0; var i_1344000269__17 int64 = 0; L4: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1344000269__17, count_1344000268__16) { var f__18_2 any = lang.Indexed_Cast(chunk_1344000267__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1344000269__17)); var root_2694 any = A_arbace_repr_go_print_A_const_210.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, A_arbace_repr_go_print_gofmt_file_A_fn_class); var ifn_2696 lang.IFn; if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any = goroot__2; var arg_2698 any = jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__18_2)); if linked_2695 == nil { ifn_2696.Invoke_O_O__O(arg_2697, arg_2698) } else { linked_2695.(*A_arbace_repr_go_print_gofmt_file_A).Invoke_O_O_O__O(root_2694, arg_2697, arg_2698) }; seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, i_1344000269__17 = seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1344000269__17); continue L4 } else { var temp__1927000414__auto____18_2 any; var root_2653 any = A_arbace_repr_go_print_A_const_19.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = seq_1344000266__14; if linked_2654 == nil { temp__1927000414__auto____18_2 = ifn_2655.Invoke_O__O(arg_2656) } else { temp__1927000414__auto____18_2 = linked_2654.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2653, arg_2656) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1344000266__19 any = temp__1927000414__auto____18_2; var tmp26 any; var root_2657 any = A_arbace_repr_go_print_A_const_23.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = seq_1344000266__19; if linked_2658 == nil { tmp26 = ifn_2659.Invoke_O__O(arg_2660) } else { tmp26 = linked_2658.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2657, arg_2660) }; if jrt.J2g_Truth(tmp26) { var c__1927000678__auto____20_2 any; var root_2661 any = A_arbace_repr_go_print_A_const_24.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any = seq_1344000266__19; if linked_2662 == nil { c__1927000678__auto____20_2 = ifn_2663.Invoke_O__O(arg_2664) } else { c__1927000678__auto____20_2 = linked_2662.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2661, arg_2664) }; var tmp27 any; var root_2699 any = A_arbace_repr_go_print_A_const_35.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2701 lang.IFn; if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any = seq_1344000266__19; if linked_2700 == nil { tmp27 = ifn_2701.Invoke_O__O(arg_2702) } else { tmp27 = linked_2700.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2699, arg_2702) }; seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, i_1344000269__17 = tmp27, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var f__20_2 any; var root_2665 any = A_arbace_repr_go_print_A_const_20.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = seq_1344000266__19; if linked_2666 == nil { f__20_2 = ifn_2667.Invoke_O__O(arg_2668) } else { f__20_2 = linked_2666.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2665, arg_2668) }; var root_2703 any = A_arbace_repr_go_print_A_const_210.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, A_arbace_repr_go_print_gofmt_file_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = goroot__2; var arg_2707 any = jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__20_2)); if linked_2704 == nil { ifn_2705.Invoke_O_O__O(arg_2706, arg_2707) } else { linked_2704.(*A_arbace_repr_go_print_gofmt_file_A).Invoke_O_O_O__O(root_2703, arg_2706, arg_2707) }; var tmp28 any; var root_2708 any = A_arbace_repr_go_print_A_const_42.GetRawRoot__O(); var linked_2709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2708, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2710 lang.IFn; if linked_2709 == nil { ifn_2710 = lang.IFn_Cast(root_2708) } else { ifn_2710 = nil }; var arg_2711 any = seq_1344000266__19; if linked_2709 == nil { tmp28 = ifn_2710.Invoke_O__O(arg_2711) } else { tmp28 = linked_2709.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2708, arg_2711) }; seq_1344000266__14, chunk_1344000267__15, count_1344000268__16, i_1344000269__17 = tmp28, nil, 0, 0; continue L4 } } }
//line :456:1
				break L4 } }
//line :442:1
		var temp__1927000414__auto____14 any = A_arbace_repr_go_print_A_const_50.Invoke_O__O(opts__4)















		if jrt.J2g_Truth(temp__1927000414__auto____14) { var src__15 any = temp__1927000414__auto____14; var root_2712 any = A_arbace_repr_go_print_A_const_211.GetRawRoot__O(); var linked_2713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2712, A_arbace_repr_go_print_copy_files_A_fn_class); var ifn_2714 lang.IFn
			if linked_2713 == nil { ifn_2714 = lang.IFn_Cast(root_2712) } else { ifn_2714 = nil }; var arg_2715 any = package__11; var arg_2716 any = jrt.File_New_String(jrt.String_Cast(src__15)); var arg_2717 any = outf__13; var arg_2718 any = files__12; if linked_2713 == nil { ifn_2714.Invoke_O_O_O_O__O(arg_2715, arg_2716, arg_2717, arg_2718) } else { linked_2713.(*A_arbace_repr_go_print_copy_files_A).Invoke_O_O_O_O_O__O(root_2712, arg_2715, arg_2716, arg_2717, arg_2718) }
			if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_164.Invoke_O__O(opts__4)) { var vec__1344000270__16 any; var root_2669 any = A_arbace_repr_go_print_A_const_209.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, A_arbace_repr_go_print_build_A_fn_class); var ifn_2671 lang.IFn
				if linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any = package__11; var arg_2673 any = jrt.File_New_String(jrt.String_Cast(src__15)); var arg_2674 any = outf__13; var arg_2675 any = goroot__2; if linked_2670 == nil { vec__1344000270__16 = ifn_2671.Invoke_O_O_O_O__O(arg_2672, arg_2673, arg_2674, arg_2675) } else { vec__1344000270__16 = linked_2670.(*A_arbace_repr_go_print_build_A).Invoke_O_O_O_O_O__O(root_2669, arg_2672, arg_2673, arg_2674, arg_2675) }
//line :460:1
				var status__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000270__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1344000270__16, lang.RT_IntCast_J__I_NoInit(1), nil)

				lang.IFn_Cast(A_arbace_repr_go_print_A_const_212.GetRawRoot__O()).Invoke_O__O(text__18)
				var root_2723 any = A_arbace_repr_go_print_A_const_213.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; if linked_2724 == nil { ifn_2725.Invoke__O() } else { linked_2724.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_2723) }
				var tmp29 bool; var na_2676 any = status__17; if jrt.Long_InstanceOf(na_2676) { var n0_2677 int64 = jrt.NN(jrt.Long_Cast(na_2676)).LongValue__J(); tmp29 = n0_2677 == 0 } else { if jrt.Double_InstanceOf(na_2676) { var n0_2677_2 float64 = jrt.NN(jrt.Double_Cast(na_2676)).DoubleValue__D(); tmp29 = n0_2677_2 == 0.0 } else { tmp29 = lang.Numbers_IsZero_O__Z_NoInit(na_2676) } }; if tmp29 { } else { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)) } } }
		var root_2550 any = A_arbace_repr_go_print_A_const_206.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2550, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_2552 lang.IFn; if linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; if linked_2551 == nil { return ifn_2552.Invoke__O() } else { return linked_2551.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_2550) } } }; /*line :439:1*/panic("j2g: unreachable") }







type A_arbace_repr_go_print_A struct{ jrt.Object }

var A_arbace_repr_go_print_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_A_const_0 *lang.Var

var A_arbace_repr_go_print_A_const_1 any

var A_arbace_repr_go_print_A_const_2 *lang.Var

var A_arbace_repr_go_print_A_const_3 any

var A_arbace_repr_go_print_A_const_4 any

var A_arbace_repr_go_print_A_const_5 any

var A_arbace_repr_go_print_A_const_6 *lang.Var

var A_arbace_repr_go_print_A_const_7 *lang.Var

var A_arbace_repr_go_print_A_const_8 *lang.Var

var A_arbace_repr_go_print_A_const_9 *lang.Var

var A_arbace_repr_go_print_A_const_10 any

var A_arbace_repr_go_print_A_const_11 *lang.Var

var A_arbace_repr_go_print_A_const_12 *lang.Var

var A_arbace_repr_go_print_A_const_13 *lang.Var

var A_arbace_repr_go_print_A_const_14 *lang.Var

var A_arbace_repr_go_print_A_const_15 *lang.Var

var A_arbace_repr_go_print_A_const_16 *lang.Var

var A_arbace_repr_go_print_A_const_17 *lang.Var

var A_arbace_repr_go_print_A_const_18 any

var A_arbace_repr_go_print_A_const_19 *lang.Var

var A_arbace_repr_go_print_A_const_20 *lang.Var

var A_arbace_repr_go_print_A_const_21 *lang.Var

var A_arbace_repr_go_print_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_A_const_23 *lang.Var

var A_arbace_repr_go_print_A_const_24 *lang.Var

var A_arbace_repr_go_print_A_const_25 *lang.Var

var A_arbace_repr_go_print_A_const_26 *lang.Var

var A_arbace_repr_go_print_A_const_27 any

var A_arbace_repr_go_print_A_const_28 *lang.Var

var A_arbace_repr_go_print_A_const_29 *lang.Var

var A_arbace_repr_go_print_A_const_30 *lang.Keyword

var A_arbace_repr_go_print_A_const_31 *lang.Var

var A_arbace_repr_go_print_A_const_32 *lang.Var

var A_arbace_repr_go_print_A_const_33 *lang.Var

var A_arbace_repr_go_print_A_const_34 *lang.Var

var A_arbace_repr_go_print_A_const_35 *lang.Var

var A_arbace_repr_go_print_A_const_36 *lang.Var

var A_arbace_repr_go_print_A_const_37 *lang.Var

var A_arbace_repr_go_print_A_const_38 *lang.Var

var A_arbace_repr_go_print_A_const_39 *lang.Var

var A_arbace_repr_go_print_A_const_40 *lang.Keyword

var A_arbace_repr_go_print_A_const_41 *lang.Var

var A_arbace_repr_go_print_A_const_42 *lang.Var

var A_arbace_repr_go_print_A_const_43 *lang.Var

var A_arbace_repr_go_print_A_const_44 *lang.Keyword

var A_arbace_repr_go_print_A_const_45 *lang.Keyword

var A_arbace_repr_go_print_A_const_46 *lang.Keyword

var A_arbace_repr_go_print_A_const_47 *lang.Keyword

var A_arbace_repr_go_print_A_const_48 *lang.Keyword

var A_arbace_repr_go_print_A_const_49 *lang.Keyword

var A_arbace_repr_go_print_A_const_50 *lang.Keyword

var A_arbace_repr_go_print_A_const_51 *lang.Var

var A_arbace_repr_go_print_A_const_52 *lang.Var

var A_arbace_repr_go_print_A_const_53 *lang.Var

var A_arbace_repr_go_print_A_const_54 *lang.Var

var A_arbace_repr_go_print_A_const_55 *lang.Var

var A_arbace_repr_go_print_A_const_56 *lang.Keyword

var A_arbace_repr_go_print_A_const_57 *lang.Var

var A_arbace_repr_go_print_A_const_58 *lang.Var

var A_arbace_repr_go_print_A_const_59 *lang.Keyword

var A_arbace_repr_go_print_A_const_60 *lang.Var

var A_arbace_repr_go_print_A_const_61 *lang.Var

var A_arbace_repr_go_print_A_const_62 any

var A_arbace_repr_go_print_A_const_63 *lang.Var

var A_arbace_repr_go_print_A_const_64 *lang.Var

var A_arbace_repr_go_print_A_const_65 *lang.Var

var A_arbace_repr_go_print_A_const_66 *lang.Keyword

var A_arbace_repr_go_print_A_const_67 *lang.Var

var A_arbace_repr_go_print_A_const_68 any

var A_arbace_repr_go_print_A_const_69 any

var A_arbace_repr_go_print_A_const_70 *lang.Var

var A_arbace_repr_go_print_A_const_71 any

var A_arbace_repr_go_print_A_const_72 *lang.Var

var A_arbace_repr_go_print_A_const_73 *lang.Var

var A_arbace_repr_go_print_A_const_74 *lang.Var

var A_arbace_repr_go_print_A_const_75 *lang.Var

var A_arbace_repr_go_print_A_const_76 *lang.Var

var A_arbace_repr_go_print_A_const_77 any

var A_arbace_repr_go_print_A_const_78 *lang.Keyword

var A_arbace_repr_go_print_A_const_79 any

var A_arbace_repr_go_print_A_const_80 *lang.Var

var A_arbace_repr_go_print_A_const_81 *lang.Var

var A_arbace_repr_go_print_A_const_82 *lang.Var

var A_arbace_repr_go_print_A_const_83 *lang.Var

var A_arbace_repr_go_print_A_const_84 *lang.Var

var A_arbace_repr_go_print_A_const_85 any

var A_arbace_repr_go_print_A_const_86 *lang.Var

var A_arbace_repr_go_print_A_const_87 *lang.Var

var A_arbace_repr_go_print_A_const_88 *lang.Var

var A_arbace_repr_go_print_A_const_89 *lang.Var

var A_arbace_repr_go_print_A_const_90 *lang.Var

var A_arbace_repr_go_print_A_const_91 *lang.Var

var A_arbace_repr_go_print_A_const_92 *lang.Keyword

var A_arbace_repr_go_print_A_const_93 *lang.Var

var A_arbace_repr_go_print_A_const_94 *lang.Keyword

var A_arbace_repr_go_print_A_const_95 *lang.Keyword

var A_arbace_repr_go_print_A_const_96 *lang.Var

var A_arbace_repr_go_print_A_const_97 *lang.Keyword

var A_arbace_repr_go_print_A_const_98 *lang.Var

var A_arbace_repr_go_print_A_const_99 *lang.Keyword

var A_arbace_repr_go_print_A_const_100 any

var A_arbace_repr_go_print_A_const_101 *lang.Keyword

var A_arbace_repr_go_print_A_const_102 any

var A_arbace_repr_go_print_A_const_103 any

var A_arbace_repr_go_print_A_const_104 *lang.Keyword

var A_arbace_repr_go_print_A_const_105 *lang.Var

var A_arbace_repr_go_print_A_const_106 *lang.Keyword

var A_arbace_repr_go_print_A_const_107 *lang.Var

var A_arbace_repr_go_print_A_const_108 *lang.Var

var A_arbace_repr_go_print_A_const_109 *lang.Keyword

var A_arbace_repr_go_print_A_const_110 *lang.Var

var A_arbace_repr_go_print_A_const_111 *lang.Var

var A_arbace_repr_go_print_A_const_112 *lang.Var

var A_arbace_repr_go_print_A_const_113 *lang.Keyword

var A_arbace_repr_go_print_A_const_114 *lang.Var

var A_arbace_repr_go_print_A_const_115 *lang.Keyword

var A_arbace_repr_go_print_A_const_116 *lang.Var

var A_arbace_repr_go_print_A_const_117 *lang.Var

var A_arbace_repr_go_print_A_const_118 *lang.Var

var A_arbace_repr_go_print_A_const_119 *lang.Var

var A_arbace_repr_go_print_A_const_120 *lang.Keyword

var A_arbace_repr_go_print_A_const_121 *lang.Keyword

var A_arbace_repr_go_print_A_const_122 *lang.Var

var A_arbace_repr_go_print_A_const_123 *lang.Var

var A_arbace_repr_go_print_A_const_124 *lang.Var

var A_arbace_repr_go_print_A_const_125 *lang.Var

var A_arbace_repr_go_print_A_const_126 *lang.Var

var A_arbace_repr_go_print_A_const_127 *lang.Var

var A_arbace_repr_go_print_A_const_128 *lang.Keyword

var A_arbace_repr_go_print_A_const_129 *lang.Var

var A_arbace_repr_go_print_A_const_130 *lang.Var

var A_arbace_repr_go_print_A_const_131 *lang.Var

var A_arbace_repr_go_print_A_const_132 *lang.Var

var A_arbace_repr_go_print_A_const_133 *lang.Var

var A_arbace_repr_go_print_A_const_134 *lang.Var

var A_arbace_repr_go_print_A_const_135 *lang.Var

var A_arbace_repr_go_print_A_const_136 *lang.Var

var A_arbace_repr_go_print_A_const_137 *lang.Var

var A_arbace_repr_go_print_A_const_138 *lang.Var

var A_arbace_repr_go_print_A_const_139 *lang.Var

var A_arbace_repr_go_print_A_const_140 *lang.Keyword

var A_arbace_repr_go_print_A_const_141 *lang.Var

var A_arbace_repr_go_print_A_const_142 *lang.Var

var A_arbace_repr_go_print_A_const_143 *lang.Keyword

var A_arbace_repr_go_print_A_const_144 *lang.Keyword

var A_arbace_repr_go_print_A_const_145 *lang.Keyword

var A_arbace_repr_go_print_A_const_146 *lang.Keyword

var A_arbace_repr_go_print_A_const_147 *lang.Keyword

var A_arbace_repr_go_print_A_const_148 *lang.Keyword

var A_arbace_repr_go_print_A_const_149 *lang.Keyword

var A_arbace_repr_go_print_A_const_150 *lang.Keyword

var A_arbace_repr_go_print_A_const_151 *lang.Keyword

var A_arbace_repr_go_print_A_const_152 *lang.Keyword

var A_arbace_repr_go_print_A_const_153 *lang.Keyword

var A_arbace_repr_go_print_A_const_154 *lang.Var

var A_arbace_repr_go_print_A_const_155 *lang.Var

var A_arbace_repr_go_print_A_const_156 *lang.Var

var A_arbace_repr_go_print_A_const_157 *lang.Var

var A_arbace_repr_go_print_A_const_158 *lang.Keyword

var A_arbace_repr_go_print_A_const_159 *lang.Keyword

var A_arbace_repr_go_print_A_const_160 *lang.Var

var A_arbace_repr_go_print_A_const_161 *lang.Keyword

var A_arbace_repr_go_print_A_const_162 *lang.Keyword

var A_arbace_repr_go_print_A_const_163 *lang.Var

var A_arbace_repr_go_print_A_const_164 *lang.Keyword

var A_arbace_repr_go_print_A_const_165 *lang.Keyword

var A_arbace_repr_go_print_A_const_166 *lang.Var

var A_arbace_repr_go_print_A_const_167 *lang.Keyword

var A_arbace_repr_go_print_A_const_168 *lang.Var

var A_arbace_repr_go_print_A_const_169 *lang.Var

var A_arbace_repr_go_print_A_const_170 *lang.Var

var A_arbace_repr_go_print_A_const_171 *lang.Var

var A_arbace_repr_go_print_A_const_172 *lang.Var

var A_arbace_repr_go_print_A_const_173 *lang.Var

var A_arbace_repr_go_print_A_const_174 *lang.Var

var A_arbace_repr_go_print_A_const_175 *lang.Var

var A_arbace_repr_go_print_A_const_176 *lang.Var

var A_arbace_repr_go_print_A_const_177 *lang.Var

var A_arbace_repr_go_print_A_const_178 *lang.Var

var A_arbace_repr_go_print_A_const_179 *lang.Var

var A_arbace_repr_go_print_A_const_180 *jrt.Class

var A_arbace_repr_go_print_A_const_181 *lang.Var

var A_arbace_repr_go_print_A_const_182 *lang.Var

var A_arbace_repr_go_print_A_const_183 *lang.Var

var A_arbace_repr_go_print_A_const_184 *lang.Var

var A_arbace_repr_go_print_A_const_185 *lang.Keyword

var A_arbace_repr_go_print_A_const_186 *lang.Keyword

var A_arbace_repr_go_print_A_const_187 *lang.Var

var A_arbace_repr_go_print_A_const_188 *lang.Var

var A_arbace_repr_go_print_A_const_189 *lang.Keyword

var A_arbace_repr_go_print_A_const_190 *lang.Keyword

var A_arbace_repr_go_print_A_const_191 *lang.Keyword

var A_arbace_repr_go_print_A_const_192 *lang.Keyword

var A_arbace_repr_go_print_A_const_193 *lang.Keyword

var A_arbace_repr_go_print_A_const_194 *lang.Var

var A_arbace_repr_go_print_A_const_195 *lang.Keyword

var A_arbace_repr_go_print_A_const_196 *lang.Var

var A_arbace_repr_go_print_A_const_197 *lang.Keyword

var A_arbace_repr_go_print_A_const_198 *lang.Keyword

var A_arbace_repr_go_print_A_const_199 any

var A_arbace_repr_go_print_A_const_200 *lang.Var

var A_arbace_repr_go_print_A_const_201 *lang.Var

var A_arbace_repr_go_print_A_const_202 *lang.Var

var A_arbace_repr_go_print_A_const_203 *lang.Keyword

var A_arbace_repr_go_print_A_const_204 *lang.Var

var A_arbace_repr_go_print_A_const_205 *lang.Var

var A_arbace_repr_go_print_A_const_206 *lang.Var

var A_arbace_repr_go_print_A_const_207 *lang.Var

var A_arbace_repr_go_print_A_const_208 *lang.Var

var A_arbace_repr_go_print_A_const_209 *lang.Var

var A_arbace_repr_go_print_A_const_210 *lang.Var

var A_arbace_repr_go_print_A_const_211 *lang.Var

var A_arbace_repr_go_print_A_const_212 *lang.Var

var A_arbace_repr_go_print_A_const_213 *lang.Var

var A_arbace_repr_go_print_A_init jrt.ClassInit

func A_arbace_repr_go_print_A_Init() { if !A_arbace_repr_go_print_A_init.Done() { A_arbace_repr_go_print_A_init.Run(A_arbace_repr_go_print_A_clinit) } }

func A_arbace_repr_go_print_A_clinit() { A_arbace_repr_go_print_A_clinit_p0(); A_arbace_repr_go_print_A_clinit_p1(); A_arbace_repr_go_print_A_clinit_p2(); A_arbace_repr_go_print_A_clinit_p3(); A_arbace_repr_go_print_A_clinit_p4(); A_arbace_repr_go_print_A_clinit_p5(); A_arbace_repr_go_print_A_clinit_p6(); A_arbace_repr_go_print_A_clinit_p7(); A_arbace_repr_go_print_A_clinit_p8(); A_arbace_repr_go_print_A_clinit_p9(); A_arbace_repr_go_print_A_clinit_p10(); A_arbace_repr_go_print_A_clinit_p11(); A_arbace_repr_go_print_A_clinit_p12(); A_arbace_repr_go_print_A_clinit_p13(); A_arbace_repr_go_print_A_clinit_p14(); A_arbace_repr_go_print_A_clinit_p15(); A_arbace_repr_go_print_A_clinit_p16(); A_arbace_repr_go_print_A_clinit_p17() }

func A_arbace_repr_go_print_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 282); A_arbace_repr_go_print_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[68]); A_arbace_repr_go_print_A_const_1 = A_arbace_repr_go_print_A_const_pool.A[69]; A_arbace_repr_go_print_A_const_2 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[70]); A_arbace_repr_go_print_A_const_3 = A_arbace_repr_go_print_A_const_pool.A[71]; A_arbace_repr_go_print_A_const_4 = A_arbace_repr_go_print_A_const_pool.A[72]; A_arbace_repr_go_print_A_const_5 = A_arbace_repr_go_print_A_const_pool.A[73]; A_arbace_repr_go_print_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[74]); A_arbace_repr_go_print_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[75]); A_arbace_repr_go_print_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[76]); A_arbace_repr_go_print_A_const_9 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[77]); A_arbace_repr_go_print_A_const_10 = A_arbace_repr_go_print_A_const_pool.A[78]; A_arbace_repr_go_print_A_const_11 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[79]) }

func A_arbace_repr_go_print_A_clinit_p1() { A_arbace_repr_go_print_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[80]); A_arbace_repr_go_print_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[81]); A_arbace_repr_go_print_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[82]); A_arbace_repr_go_print_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[83]); A_arbace_repr_go_print_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[84]); A_arbace_repr_go_print_A_const_17 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[85]); A_arbace_repr_go_print_A_const_18 = A_arbace_repr_go_print_A_const_pool.A[86]; A_arbace_repr_go_print_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[87]); A_arbace_repr_go_print_A_const_20 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[88]); A_arbace_repr_go_print_A_const_21 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[89]); A_arbace_repr_go_print_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[90]); A_arbace_repr_go_print_A_const_23 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[91]) }

func A_arbace_repr_go_print_A_clinit_p2() { A_arbace_repr_go_print_A_const_24 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[92]); A_arbace_repr_go_print_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[93]); A_arbace_repr_go_print_A_const_26 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[94]); A_arbace_repr_go_print_A_const_27 = A_arbace_repr_go_print_A_const_pool.A[95]; A_arbace_repr_go_print_A_const_28 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[96]); A_arbace_repr_go_print_A_const_29 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[97]); A_arbace_repr_go_print_A_const_30 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[98]); A_arbace_repr_go_print_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[99]); A_arbace_repr_go_print_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[100]); A_arbace_repr_go_print_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[101]); A_arbace_repr_go_print_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[102]); A_arbace_repr_go_print_A_const_35 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[103]) }

func A_arbace_repr_go_print_A_clinit_p3() { A_arbace_repr_go_print_A_const_36 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[104]); A_arbace_repr_go_print_A_const_37 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[105]); A_arbace_repr_go_print_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[106]); A_arbace_repr_go_print_A_const_39 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[107]); A_arbace_repr_go_print_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[108]); A_arbace_repr_go_print_A_const_41 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[109]); A_arbace_repr_go_print_A_const_42 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[110]); A_arbace_repr_go_print_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[111]); A_arbace_repr_go_print_A_const_44 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[112]); A_arbace_repr_go_print_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[113]); A_arbace_repr_go_print_A_const_46 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[114]); A_arbace_repr_go_print_A_const_47 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[115]) }

func A_arbace_repr_go_print_A_clinit_p4() { A_arbace_repr_go_print_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[116]); A_arbace_repr_go_print_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[117]); A_arbace_repr_go_print_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[118]); A_arbace_repr_go_print_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[119]); A_arbace_repr_go_print_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[120]); A_arbace_repr_go_print_A_const_53 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[121]); A_arbace_repr_go_print_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[122]); A_arbace_repr_go_print_A_const_55 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[123]); A_arbace_repr_go_print_A_const_56 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[124]); A_arbace_repr_go_print_A_const_57 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[125]); A_arbace_repr_go_print_A_const_58 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[126]); A_arbace_repr_go_print_A_const_59 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[127]) }

func A_arbace_repr_go_print_A_clinit_p5() { A_arbace_repr_go_print_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[128]); A_arbace_repr_go_print_A_const_61 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[129]); A_arbace_repr_go_print_A_const_62 = A_arbace_repr_go_print_A_const_pool.A[130]; A_arbace_repr_go_print_A_const_63 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[131]); A_arbace_repr_go_print_A_const_64 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[132]); A_arbace_repr_go_print_A_const_65 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[133]); A_arbace_repr_go_print_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[134]); A_arbace_repr_go_print_A_const_67 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[135]); A_arbace_repr_go_print_A_const_68 = A_arbace_repr_go_print_A_const_pool.A[136]; A_arbace_repr_go_print_A_const_69 = A_arbace_repr_go_print_A_const_pool.A[137]; A_arbace_repr_go_print_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[138]); A_arbace_repr_go_print_A_const_71 = A_arbace_repr_go_print_A_const_pool.A[139]; A_arbace_repr_go_print_A_const_72 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[140]) }

func A_arbace_repr_go_print_A_clinit_p6() { A_arbace_repr_go_print_A_const_73 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[141]); A_arbace_repr_go_print_A_const_74 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[142]); A_arbace_repr_go_print_A_const_75 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[143]); A_arbace_repr_go_print_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[144]); A_arbace_repr_go_print_A_const_77 = A_arbace_repr_go_print_A_const_pool.A[145]; A_arbace_repr_go_print_A_const_78 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[146]); A_arbace_repr_go_print_A_const_79 = A_arbace_repr_go_print_A_const_pool.A[147]; A_arbace_repr_go_print_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[148]); A_arbace_repr_go_print_A_const_81 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[149]); A_arbace_repr_go_print_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[150]); A_arbace_repr_go_print_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[151]); A_arbace_repr_go_print_A_const_84 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[152]) }

func A_arbace_repr_go_print_A_clinit_p7() { A_arbace_repr_go_print_A_const_85 = A_arbace_repr_go_print_A_const_pool.A[153]; A_arbace_repr_go_print_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[154]); A_arbace_repr_go_print_A_const_87 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[155]); A_arbace_repr_go_print_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[156]); A_arbace_repr_go_print_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[157]); A_arbace_repr_go_print_A_const_90 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[158]); A_arbace_repr_go_print_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[159]); A_arbace_repr_go_print_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[160]); A_arbace_repr_go_print_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[161]); A_arbace_repr_go_print_A_const_94 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[162]); A_arbace_repr_go_print_A_const_95 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[163]); A_arbace_repr_go_print_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[164]) }

func A_arbace_repr_go_print_A_clinit_p8() { A_arbace_repr_go_print_A_const_97 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[165]); A_arbace_repr_go_print_A_const_98 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[166]); A_arbace_repr_go_print_A_const_99 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[167]); A_arbace_repr_go_print_A_const_100 = A_arbace_repr_go_print_A_const_pool.A[168]; A_arbace_repr_go_print_A_const_101 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[169]); A_arbace_repr_go_print_A_const_102 = A_arbace_repr_go_print_A_const_pool.A[170]; A_arbace_repr_go_print_A_const_103 = A_arbace_repr_go_print_A_const_pool.A[171]; A_arbace_repr_go_print_A_const_104 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[172]); A_arbace_repr_go_print_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[173]); A_arbace_repr_go_print_A_const_106 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[174]); A_arbace_repr_go_print_A_const_107 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[175]); A_arbace_repr_go_print_A_const_108 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[176]) }

func A_arbace_repr_go_print_A_clinit_p9() { A_arbace_repr_go_print_A_const_109 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[177]); A_arbace_repr_go_print_A_const_110 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[178]); A_arbace_repr_go_print_A_const_111 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[179]); A_arbace_repr_go_print_A_const_112 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[180]); A_arbace_repr_go_print_A_const_113 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[181]); A_arbace_repr_go_print_A_const_114 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[182]); A_arbace_repr_go_print_A_const_115 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[183]); A_arbace_repr_go_print_A_const_116 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[184]); A_arbace_repr_go_print_A_const_117 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[185]); A_arbace_repr_go_print_A_const_118 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[186]); A_arbace_repr_go_print_A_const_119 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[187]); A_arbace_repr_go_print_A_const_120 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[188]) }

func A_arbace_repr_go_print_A_clinit_p10() { A_arbace_repr_go_print_A_const_121 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[189]); A_arbace_repr_go_print_A_const_122 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[190]); A_arbace_repr_go_print_A_const_123 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[191]); A_arbace_repr_go_print_A_const_124 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[192]); A_arbace_repr_go_print_A_const_125 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[193]); A_arbace_repr_go_print_A_const_126 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[194]); A_arbace_repr_go_print_A_const_127 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[195]); A_arbace_repr_go_print_A_const_128 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[196]); A_arbace_repr_go_print_A_const_129 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[197]); A_arbace_repr_go_print_A_const_130 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[198]); A_arbace_repr_go_print_A_const_131 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[199]); A_arbace_repr_go_print_A_const_132 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[200]) }

func A_arbace_repr_go_print_A_clinit_p11() { A_arbace_repr_go_print_A_const_133 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[201]); A_arbace_repr_go_print_A_const_134 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[202]); A_arbace_repr_go_print_A_const_135 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[203]); A_arbace_repr_go_print_A_const_136 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[204]); A_arbace_repr_go_print_A_const_137 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[205]); A_arbace_repr_go_print_A_const_138 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[206]); A_arbace_repr_go_print_A_const_139 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[207]); A_arbace_repr_go_print_A_const_140 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[208]); A_arbace_repr_go_print_A_const_141 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[209]); A_arbace_repr_go_print_A_const_142 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[210]); A_arbace_repr_go_print_A_const_143 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[211]); A_arbace_repr_go_print_A_const_144 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[212]) }

func A_arbace_repr_go_print_A_clinit_p12() { A_arbace_repr_go_print_A_const_145 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[213]); A_arbace_repr_go_print_A_const_146 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[214]); A_arbace_repr_go_print_A_const_147 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[215]); A_arbace_repr_go_print_A_const_148 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[216]); A_arbace_repr_go_print_A_const_149 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[217]); A_arbace_repr_go_print_A_const_150 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[218]); A_arbace_repr_go_print_A_const_151 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[219]); A_arbace_repr_go_print_A_const_152 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[220]); A_arbace_repr_go_print_A_const_153 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[221]); A_arbace_repr_go_print_A_const_154 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[222]); A_arbace_repr_go_print_A_const_155 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[223]); A_arbace_repr_go_print_A_const_156 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[224]) }

func A_arbace_repr_go_print_A_clinit_p13() { A_arbace_repr_go_print_A_const_157 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[225]); A_arbace_repr_go_print_A_const_158 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[226]); A_arbace_repr_go_print_A_const_159 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[227]); A_arbace_repr_go_print_A_const_160 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[228]); A_arbace_repr_go_print_A_const_161 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[229]); A_arbace_repr_go_print_A_const_162 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[230]); A_arbace_repr_go_print_A_const_163 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[231]); A_arbace_repr_go_print_A_const_164 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[232]); A_arbace_repr_go_print_A_const_165 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[233]); A_arbace_repr_go_print_A_const_166 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[234]); A_arbace_repr_go_print_A_const_167 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[235]); A_arbace_repr_go_print_A_const_168 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[236]) }

func A_arbace_repr_go_print_A_clinit_p14() { A_arbace_repr_go_print_A_const_169 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[237]); A_arbace_repr_go_print_A_const_170 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[238]); A_arbace_repr_go_print_A_const_171 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[239]); A_arbace_repr_go_print_A_const_172 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[240]); A_arbace_repr_go_print_A_const_173 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[241]); A_arbace_repr_go_print_A_const_174 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[242]); A_arbace_repr_go_print_A_const_175 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[243]); A_arbace_repr_go_print_A_const_176 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[244]); A_arbace_repr_go_print_A_const_177 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[245]); A_arbace_repr_go_print_A_const_178 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[246]); A_arbace_repr_go_print_A_const_179 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[247]); A_arbace_repr_go_print_A_const_180 = jrt.Class_Cast(A_arbace_repr_go_print_A_const_pool.A[248]) }

func A_arbace_repr_go_print_A_clinit_p15() { A_arbace_repr_go_print_A_const_181 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[249]); A_arbace_repr_go_print_A_const_182 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[250]); A_arbace_repr_go_print_A_const_183 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[251]); A_arbace_repr_go_print_A_const_184 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[252]); A_arbace_repr_go_print_A_const_185 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[253]); A_arbace_repr_go_print_A_const_186 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[254]); A_arbace_repr_go_print_A_const_187 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[255]); A_arbace_repr_go_print_A_const_188 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[256]); A_arbace_repr_go_print_A_const_189 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[257]); A_arbace_repr_go_print_A_const_190 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[258]); A_arbace_repr_go_print_A_const_191 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[259]); A_arbace_repr_go_print_A_const_192 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[260]) }

func A_arbace_repr_go_print_A_clinit_p16() { A_arbace_repr_go_print_A_const_193 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[261]); A_arbace_repr_go_print_A_const_194 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[262]); A_arbace_repr_go_print_A_const_195 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[263]); A_arbace_repr_go_print_A_const_196 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[264]); A_arbace_repr_go_print_A_const_197 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[265]); A_arbace_repr_go_print_A_const_198 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[266]); A_arbace_repr_go_print_A_const_199 = A_arbace_repr_go_print_A_const_pool.A[267]; A_arbace_repr_go_print_A_const_200 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[268]); A_arbace_repr_go_print_A_const_201 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[269]); A_arbace_repr_go_print_A_const_202 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[270]); A_arbace_repr_go_print_A_const_203 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[271]); A_arbace_repr_go_print_A_const_204 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[272]) }

func A_arbace_repr_go_print_A_clinit_p17() { A_arbace_repr_go_print_A_const_205 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[273]); A_arbace_repr_go_print_A_const_206 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[274]); A_arbace_repr_go_print_A_const_207 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[275]); A_arbace_repr_go_print_A_const_208 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[276]); A_arbace_repr_go_print_A_const_209 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[277]); A_arbace_repr_go_print_A_const_210 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[278]); A_arbace_repr_go_print_A_const_211 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[279]); A_arbace_repr_go_print_A_const_212 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[280]); A_arbace_repr_go_print_A_const_213 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[281]) }

func A_arbace_repr_go_print_A_New() *A_arbace_repr_go_print_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_A) Ctor() {}

func (t *A_arbace_repr_go_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_A_class }

func (t *A_arbace_repr_go_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_A); return ok }

func A_arbace_repr_go_print_A_Cast(x any) *A_arbace_repr_go_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_A_class)) }; return v }



type A_arbace_repr_go_print__main_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print__main_A_fn_class *jrt.Class



type A_arbace_repr_go_print_add_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_add_form_A_fn_class *jrt.Class



type A_arbace_repr_go_print_add_form_fn__1344000040_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class *jrt.Class



type A_arbace_repr_go_print_build_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_build_A_fn_class *jrt.Class



type A_arbace_repr_go_print_build_env_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_build_env_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_chunk_starts_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_fn__1344000131_A struct{ j2g_header uint64; F_decls any; F_n int32 }

var A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A struct{ j2g_header uint64; F_decls any }

var A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_A struct{ j2g_header uint64; F_state, F_read_fn, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A struct{ j2g_header uint64; F_read_fn, F_file any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A struct{ j2g_header uint64; F_f, F_walk, F_state, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A struct{ j2g_header uint64; F_walk, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A struct{ j2g_header uint64; F_walk, F_state, F_file, F_f, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A struct{ j2g_header uint64; F_walk, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_fn__1344000048_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_fn__1344000050_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_copy_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_copy_files_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A struct{ j2g_header uint64; F_src, F_out any }

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A struct{ j2g_header uint64; F_iter__1344000216, F_src, F_out, F_s__1344000217 any }

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A struct{ j2g_header uint64; F_src, F_b__1344000219, F_out any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_fn_class *jrt.Class



type A_arbace_repr_go_print_decl_pre_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_decl_pre_A_fn_class *jrt.Class



type A_arbace_repr_go_print_decl_sep_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_decl_sep_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_eval1344000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_eval1344000004_A_New() *A_arbace_repr_go_print_eval1344000004_A { t := &A_arbace_repr_go_print_eval1344000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_eval1344000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_eval1344000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_eval1344000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_eval1344000004_A_class }

func (t *A_arbace_repr_go_print_eval1344000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_eval1344000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_eval1344000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_eval1344000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_eval1344000004_A); return ok }

func A_arbace_repr_go_print_eval1344000004_A_Cast(x any) *A_arbace_repr_go_print_eval1344000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_eval1344000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_eval1344000004_A_class)) }; return v }



type A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_eval1344000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_eval1344000008_A_New() *A_arbace_repr_go_print_eval1344000008_A { t := &A_arbace_repr_go_print_eval1344000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_eval1344000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_eval1344000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_eval1344000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_eval1344000008_A_class }

func (t *A_arbace_repr_go_print_eval1344000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_eval1344000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_eval1344000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_eval1344000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_eval1344000008_A); return ok }

func A_arbace_repr_go_print_eval1344000008_A_Cast(x any) *A_arbace_repr_go_print_eval1344000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_eval1344000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_eval1344000008_A_class)) }; return v }



type A_arbace_repr_go_print_eval1344000008_fn__1344000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A struct{ j2g_header uint64; F_s__1344000014, F_iter__1344000013 any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A struct{ j2g_header uint64; F_s__1344000016, F_iter__1344000015 any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A struct{ j2g_header uint64; F_b__1344000018 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class *jrt.Class



type A_arbace_repr_go_print_gofmt_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_gofmt_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_import_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_import_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_json_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_json_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_name_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_name_text_A_fn_class *jrt.Class



type A_arbace_repr_go_print_new_package_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_new_package_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_next_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_next_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_next_target_fn__1344000122_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_next_target_fn__1344000122_A_fn_class *jrt.Class



type A_arbace_repr_go_print_one_line_func_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_one_line_func_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_decl_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_decl_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_first_line__1344000156_A struct{ j2g_header uint64; F_decls any }

var A_arbace_repr_go_print_print_file_first_line__1344000156_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_fn__1344000159_A struct{ j2g_header uint64; F_popts, F_first_line, F_lines_QMARK_, F_decls, F_state_opts any }

var A_arbace_repr_go_print_print_file_fn__1344000159_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_full_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_file_full_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_forms_fn__1344000193_A struct{ j2g_header uint64; F_pkg, F_opts any }

var A_arbace_repr_go_print_print_forms_fn__1344000193_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_package_A_fn_class *jrt.Class



type A_arbace_repr_go_print_read_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_read_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_run_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_run_A_fn_class *jrt.Class



type A_arbace_repr_go_print_sha256_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_sha256_A_fn_class *jrt.Class



type A_arbace_repr_go_print_sha256_fn__1344000197_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_sha256_fn__1344000197_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_import_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_import_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_full_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_full_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A struct{ j2g_header uint64; F_open any }

var A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_fn_class *jrt.Class
