//line aot_arbace_repr_go_print.ae:1
package aot_arbace_repr_go_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_New() *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_2); lang.IFn_Cast(A_arbace_repr_go_print_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_A_const_3, A_arbace_repr_go_print_A_const_4, A_arbace_repr_go_print_A_const_5); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_68)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_69)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_70)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_71)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_72)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_73)); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_74)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_75)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_76)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp13 != nil { panic(tmp13) }; return tmp3 }
//line :1:1
func A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_New() *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_eval1344000008_fn__1344000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_eval1344000008_fn__1344000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_10), A_arbace_repr_go_print_A_const_8.GetRawRoot__O(), A_arbace_repr_go_print_A_const_9) }






































func A_arbace_repr_go_print_read_forms_A_New() *A_arbace_repr_go_print_read_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_read_forms_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_repr_go_print_read_forms_A) Ctor() {}
//line :40:1
func (t *A_arbace_repr_go_print_read_forms_A) Invoke_O_O__O(self, path__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream_Charset(jrt.FileInputStream_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(path__0))), jrt.StandardCharsets_UTF_8)); var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_A_const_16; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())); tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :40:1
		{ var eof__7 any = jrt.Object_New(); var acc__8 any; lang.PersistentVector_Init(); acc__8 = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__9 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_12.GetRawRoot__O()); var tmp7 *jrt.Boolean







			jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; f__9 = tmp6.Invoke_O_O_O__O(r__2, tmp7.Ref(), eof__7)
			if lang.Util_Identical_O_O__Z(f__9, eof__7) { tmp1 = acc__8 } else { acc__8 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__8, f__9); continue L1 }
//line :40:1
			break L1
		}
		}


		return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O()
//line :40:1
		if tmp8 != nil { panic(tmp8) } }; return nil }();


	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :40:1*/ tmp9 != nil { panic(tmp9) }; return tmp1 }










func A_arbace_repr_go_print_go_ns_aliases_A_New() *A_arbace_repr_go_print_go_ns_aliases_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_go_print_go_ns_aliases_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_go_print_go_ns_aliases_A) Invoke_O_O__O(self, ns_form__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_18; var tmp3 any; var iter__1927001039__auto____2 any; var tmp4 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_New(); var tmp5 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class
	if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class = fncls__5d; tmp5 = fncls__5d } else { tmp5 = fncls__5 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(ns_form__0))
//line :54:1
	return tmp1.Invoke_O_O__O(tmp2, tmp3) }
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_New() *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A) Invoke_O_O__O(self, s__1344000014__1 any) any { var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_New_O_O(s__1344000014__1, self); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A) Ctor_O_O(c__s__1344000014, c__iter__1344000013 any) { t.F_s__1344000014 = c__s__1344000014; t.F_iter__1344000013 = c__iter__1344000013 }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A) Invoke_O__O(self any) any { { var s__1344000014__1 any; var t_ any = t.F_s__1344000014; t.F_s__1344000014 = nil; s__1344000014__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1344000014__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var clause__4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_21.GetRawRoot__O()).Invoke_O__O(clause__4)
															if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 any = A_arbace_repr_go_print_A_const_22; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(clause__4))).Ref() } else { tmp1 = and__1927000168__auto____5 }
//line :55:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp3 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(clause__4))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1344000013); return lang.IFn_Cast(A_arbace_repr_go_print_A_const_37.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1344000014__1))) } else { s__1344000014__1 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1344000014__1); continue L1 } } else { s__1344000014__1 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1344000014__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_New() *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A) Invoke_O_O__O(self, s__1344000016__1 any) any { var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_New_O_O(s__1344000016__1, self); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A) Ctor_O_O(c__s__1344000016, c__iter__1344000015 any) { t.F_s__1344000016 = c__s__1344000016; t.F_iter__1344000015 = c__iter__1344000015 }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A) Invoke_O__O(self any) any { { var s__1344000016__1 any; var t_ any = t.F_s__1344000016; t.F_s__1344000016 = nil; s__1344000016__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1344000016__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1344000016__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(s__1344000016__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1344000016__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1344000018__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_New_O_I_O(b__1344000018__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1344000015); return lang.IFn_Cast(A_arbace_repr_go_print_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_35.GetRawRoot__O()).Invoke_O__O(b__1344000018__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(s__1344000016__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_print_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_35.GetRawRoot__O()).Invoke_O__O(b__1344000018__6), nil) } } else { var spec__4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1344000016__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_26.GetRawRoot__O()).Invoke_O__O(spec__4)


	if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp5 any = A_arbace_repr_go_print_A_const_27; tmp4 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(spec__4))).Ref() } else { tmp4 = and__1927000168__auto____5 }
//line :55:1
	if jrt.J2g_Truth(tmp4) { var m__5 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_15.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(spec__4)); if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_29.Invoke_O__O(m__5)) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1344000015); return lang.IFn_Cast(A_arbace_repr_go_print_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_32.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_29.Invoke_O__O(m__5)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1344000016__3))) } else { s__1344000016__1 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1344000016__3); continue L1 } } else { s__1344000016__1 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1344000016__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :55:1
func A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A) Ctor_O_I_O(c__b__1344000018 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1344000018 = c__b__1344000018; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :55:1
func (t *A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A) Invoke_O__O(self any) any { { var i__1344000017__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1344000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1344000017__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_26.GetRawRoot__O()).Invoke_O__O(spec__2)


	if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_repr_go_print_A_const_27; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(spec__2))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :55:1
	if jrt.J2g_Truth(tmp2) { var m__3 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_15.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(spec__2)); if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_29.Invoke_O__O(m__3)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_31.GetRawRoot__O()); var tmp5 any = t.F_b__1344000018; tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_repr_go_print_A_const_32.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_29.Invoke_O__O(m__3))); i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J(i__1344000017__1); continue L1 } else { i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J(i__1344000017__1); continue L1 } } else { i__1344000017__1 = lang.Numbers_Unchecked_inc_J__J(i__1344000017__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_repr_go_print_add_form_A_New() *A_arbace_repr_go_print_add_form_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_add_form_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_repr_go_print_add_form_A) Ctor() {}
//line :65:1
func (t *A_arbace_repr_go_print_add_form_A) Invoke_O_O_O_O__O(self, state__0, f__1, load_fn__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_46; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_47; lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(state__0))))
//line :65:1
	var tmp4 any; tmp32 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var o__6 any



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_21.GetRawRoot__O()).Invoke_O__O(f__1)) { o__6 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_38.GetRawRoot__O()).Invoke_O__O(f__1) } else { o__6 = nil }
		if lang.Util_Equiv_O_O__Z(o__6, Lit_11) {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_39.GetRawRoot__O()); var tmp6 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp7 any = A_arbace_repr_go_print_A_const_47; tmp4 = jrt.NN(lang.Volatile_Cast(state__0)).Reset_O__O(tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, A_arbace_repr_go_print_A_const_17.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_A_const_48.GetRawRoot__O()).Invoke_O__O(f__1))) } else {
//line :70:1
				if lang.Util_Equiv_O_O__Z(o__6, Lit_12) { tmp4 = nil } else { if lang.Util_Equiv_O_O__Z(o__6, Lit_13) { var seq_1344000030__7 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(f__1)); var chunk_1344000031__8 any; var count_1344000032__9 int64 = 0; var i_1344000033__10 int64 = 0; L1: for {


					if lang.Numbers_Lt_J_J__Z(i_1344000033__10, count_1344000032__9) { var p__11 any = lang.Indexed_Cast(chunk_1344000031__8).Nth_I__O(lang.RT_IntCast_J__I(i_1344000033__10)); lang.IFn_Cast(load_fn__2).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(p__11)); seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, lang.Numbers_Unchecked_inc_J__J(i_1344000033__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000030__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1344000030__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000030__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000030__12); seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000030__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var p__13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000030__12); lang.IFn_Cast(load_fn__2).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(p__13)); seq_1344000030__7, chunk_1344000031__8, count_1344000032__9, i_1344000033__10 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000030__12), nil, 0, 0; continue L1 } } else { tmp4 = nil } }
//line :70:1
					break L1 } } else { if lang.Util_Equiv_O_O__Z(o__6, Lit_14) { var vec__1344000034__7 any = f__1; var seq__1344000035__8 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(vec__1344000034__7); var first__1344000036__9 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000035__8); var seq__1344000035__10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000035__8); var ___11 any = first__1344000036__9; var first__1344000036__12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000035__10); var seq__1344000035__13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000035__10); var nm__14 any = first__1344000036__12; var opts__15 any = seq__1344000035__13; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp9 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp10 any = A_arbace_repr_go_print_A_const_49; _ = ___11





						tmp4 = jrt.NN(lang.Volatile_Cast(state__0)).Reset_O__O(tmp8.Invoke_O_O_O_O_O__O(tmp9, tmp10, lang.IFn_Cast(A_arbace_repr_go_print_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_15.GetRawRoot__O(), opts__15), A_arbace_repr_go_print_A_const_50, nm__14)) } else {
//line :70:1
							if lang.Util_Equiv_O_O__Z(o__6, Lit_15) { var vec__1344000037__7 any = f__1; var seq__1344000038__8 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(vec__1344000037__7); var first__1344000039__9 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000038__8); var seq__1344000038__10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000038__8); var ___11_2 any = first__1344000039__9; var first__1344000039__12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000038__10); var seq__1344000038__13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000038__10); var nm__14_2 any = first__1344000039__12; var opts__15_2 any = seq__1344000038__13; var tmp11 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_39.GetRawRoot__O()); var tmp13 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp14 any = A_arbace_repr_go_print_A_const_51; var tmp15 any = A_arbace_repr_go_print_A_const_8.GetRawRoot__O(); var tmp16 any = A_arbace_repr_go_print_A_const_50; var tmp17 any = A_arbace_repr_go_print_A_const_52; var tmp18 any = A_arbace_repr_go_print_A_const_53; var tmp19 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_15.GetRawRoot__O(), opts__15_2); var tmp20 any = A_arbace_repr_go_print_A_const_54; var tmp21 *lang.PersistentVector; _ = ___11_2








								lang.PersistentVector_Init(); tmp21 = lang.PersistentVector_EMPTY; var tmp22 any = tmp21.Ref(); var tmp23 any = A_arbace_repr_go_print_A_const_55; tmp4 = jrt.NN(tmp11).Reset_O__O(tmp12.Invoke_O_O_O_O__O(tmp13, tmp14, tmp15, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, nm__14_2, tmp17, f__1, tmp18, tmp19, tmp20, tmp22, tmp23, A_arbace_repr_go_print_A_const_56.Get__O())))) } else {
//line :70:1
									var tmp24 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_21.GetRawRoot__O()).Invoke_O__O(f__1)










									if jrt.J2g_Truth(and__1927000168__auto____7) { tmp24 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_42.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(o__6), Lit_16) } else { tmp24 = and__1927000168__auto____7 }
//line :70:1
									if jrt.J2g_Truth(tmp24) {











										var tmp25 *lang.Keyword = A_arbace_repr_go_print_A_const_51; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_43.GetRawRoot__O()).Invoke_O__O(tmp25.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(state__0)))) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_57.GetRawRoot__O()).Invoke_O__O(f__1))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_58, f__1)))))) } else {

											var tmp26 *lang.Volatile = lang.Volatile_Cast(state__0); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_39.GetRawRoot__O()); var tmp28 any = jrt.NN(lang.Volatile_Cast(state__0)).Deref__O(); var tmp29 any = A_arbace_repr_go_print_A_const_51; var tmp30 any = A_arbace_repr_go_print_add_form_fn__1344000040_A_New_O(f__1); var tmp31 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class = fncls__6d; tmp31 = fncls__6d } else { tmp31 = fncls__6 }; tmp4 = jrt.NN(tmp26).Reset_O__O(tmp27.Invoke_O_O_O__O(tmp28, tmp29, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil))) } } else {
//line :70:1
												if lang.Util_Identical_O_O__Z(f__1, nil) { tmp4 = nil } else { if A_arbace_repr_go_print_A_const_45 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_57.GetRawRoot__O()).Invoke_O__O(f__1))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_58, f__1)))))) } else { tmp4 = nil } } } } } } } } }; return nil }()
//line :68:1
	lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O()
//line :65:1
	if tmp32 != nil { panic(tmp32) }; return tmp4
}

















func A_arbace_repr_go_print_add_form_fn__1344000040_A_New_O(p0 any) *A_arbace_repr_go_print_add_form_fn__1344000040_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_add_form_fn__1344000040_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_repr_go_print_add_form_fn__1344000040_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :84:1
func (t *A_arbace_repr_go_print_add_form_fn__1344000040_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_39.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_60.GetRawRoot__O()).Invoke_O__O(fs__1); var tmp3 any = A_arbace_repr_go_print_A_const_54; return lang.IFn_Cast(A_arbace_repr_go_print_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_59.GetRawRoot__O()).Invoke_O__O(fs__1), tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, A_arbace_repr_go_print_A_const_8.GetRawRoot__O(), t.F_f)) }



func A_arbace_repr_go_print_new_package_state_A_New() *A_arbace_repr_go_print_new_package_state_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_new_package_state_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_repr_go_print_new_package_state_A) Ctor() {}
//line :88:1
func (t *A_arbace_repr_go_print_new_package_state_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_61.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_49; var tmp3 any = A_arbace_repr_go_print_A_const_50; var tmp4 any = A_arbace_repr_go_print_A_const_51; var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, nil, tmp3, nil, tmp4, tmp5.Ref(), A_arbace_repr_go_print_A_const_47, A_arbace_repr_go_print_A_const_62)))
}
func A_arbace_repr_go_print_collect_forms_A_New() *A_arbace_repr_go_print_collect_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_repr_go_print_collect_forms_A) Ctor() {}
//line :91:1
func (t *A_arbace_repr_go_print_collect_forms_A) Invoke_O_O__O(self, forms__0 any) any { var state__2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_63.GetRawRoot__O()).Invoke__O(); var seq_1344000044__3 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(forms__0); var chunk_1344000045__4 any; var count_1344000046__5 int64 = 0; var i_1344000047__6 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z(i_1344000047__6, count_1344000046__5) { var f__7 any = lang.Indexed_Cast(chunk_1344000045__4).Nth_I__O(lang.RT_IntCast_J__I(i_1344000047__6)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_65.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_collect_forms_fn__1344000048_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class
		if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.Invoke_O_O_O__O(state__2, f__7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))
//line :96:1
		seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, lang.Numbers_Unchecked_inc_J__J(i_1344000047__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000044__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1344000044__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000044__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000044__8); seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000044__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__9 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000044__8); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_65.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_collect_forms_fn__1344000050_A_New(); var tmp6 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class
			if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class = fncls__8d; tmp6 = fncls__8d } else { tmp6 = fncls__8 }; tmp4.Invoke_O_O_O__O(state__2, f__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil))
//line :96:1
			seq_1344000044__3, chunk_1344000045__4, count_1344000046__5, i_1344000047__6 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000044__8), nil, 0, 0; continue L1 } } }
//line :91:1
	break L1 }; return /*line :98:1*/ lang.IFn_Cast(A_arbace_repr_go_print_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(state__2), A_arbace_repr_go_print_A_const_47) }
//line :97:1
func A_arbace_repr_go_print_collect_forms_fn__1344000048_A_New() *A_arbace_repr_go_print_collect_forms_fn__1344000048_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_fn__1344000048_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000048_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000048_A) Invoke_O_O__O(self, p__1 any) any { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_66, p__1)))))) }
//line :97:1
func A_arbace_repr_go_print_collect_forms_fn__1344000050_A_New() *A_arbace_repr_go_print_collect_forms_fn__1344000050_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_forms_fn__1344000050_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000050_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_go_print_collect_forms_fn__1344000050_A) Invoke_O_O__O(self, p__1 any) any { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__1)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_66, p__1)))))) }


func A_arbace_repr_go_print_collect_A_New() *A_arbace_repr_go_print_collect_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Ctor() {}
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Invoke_O_O_O__O(self, path__0, read_fn__1 any) any { var state__3 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_63.GetRawRoot__O()).Invoke__O(); var root__4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_61.GetRawRoot__O()).Invoke_O__O(nil); var body_walk__5 *A_arbace_repr_go_print_collect_walk__1344000054_A = A_arbace_repr_go_print_collect_walk__1344000054_A_New_O_O_O(state__3, read_fn__1, root__4); var walk__5 any; var tmp1 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class = fncls__16d; tmp1 = fncls__16d } else { tmp1 = fncls__16 }; walk__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__5), tmp1, nil);





















	lang.IFn_Cast(walk__5).Invoke_O__O(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(path__0)))); return /*line :123:1*/ lang.IFn_Cast(A_arbace_repr_go_print_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(state__3), A_arbace_repr_go_print_A_const_47) }
//line :100:1
func (t *A_arbace_repr_go_print_collect_A) Invoke_O_O__O(self, path__0 any) any {





	return lang.IFn_Cast(A_arbace_repr_go_print_A_const_75.GetRawRoot__O()).Invoke_O_O__O(path__0, A_arbace_repr_go_print_A_const_76.GetRawRoot__O())
}


func A_arbace_repr_go_print_collect_walk__1344000054_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :110:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_A) Ctor_O_O_O(c__state, c__read_fn, c__root any) { t.F_state = c__state; t.F_read_fn = c__read_fn; t.F_root = c__root }
//line :110:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_A) Invoke_O_O__O(self, file__1 any) any { { var seq_1344000055__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()); var tmp2 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_A_const_56
													lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref())); var tmp5 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_New_O_O(t.F_read_fn, file__1); var tmp6 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class = fncls__9d; tmp6 = fncls__9d } else { tmp6 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); seq_1344000055__2 = tmp1.Invoke_O__O(tmp2)
//line :110:1
	var chunk_1344000056__3 any; var count_1344000057__4 int64 = 0; var i_1344000058__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1344000058__5, count_1344000057__4) { var f__6 any = lang.Indexed_Cast(chunk_1344000056__3).Nth_I__O(lang.RT_IntCast_J__I(i_1344000058__5)); var tmp7 any; var and__1927000168__auto____7 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_root), nil)
			if and__1927000168__auto____7 { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_21.GetRawRoot__O()).Invoke_O__O(f__6); if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp8 any = A_arbace_repr_go_print_A_const_69; tmp7 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp8, lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(f__6))).Ref() } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp7) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_70.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_print_A_const_72; var depth__7 int32 = lang.RT_Count_O__I(tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(f__6)))); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_71.GetRawRoot__O()); var tmp12 any = t.F_root; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_74.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_New(); var tmp15 *jrt.Class
				var fncls__12 /*line :112:1*/*jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class

				if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class = fncls__12d; tmp15 = fncls__12d } else { tmp15 = fncls__12 }; tmp11.Invoke_O_O__O(tmp12, lang.RT_Nth_O_I__O(tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref()), lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(int64(depth__7)))))
			}
			var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp17 any = A_arbace_repr_go_print_A_const_56; lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()).Invoke_O__O(tmp16.Invoke_O_O__O(tmp17, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref())); var tmp18 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_New_O_O_O_O_O(f__6, self, t.F_state, file__1, t.F_root); var tmp19 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class = fncls__11d; tmp19 = fncls__11d } else { tmp19 = fncls__11 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O()
//line :111:1
			seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, lang.Numbers_Unchecked_inc_J__J(i_1344000058__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000055__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1344000055__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000055__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000055__7); seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000055__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__8 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000055__7); var tmp20 any; var and__1927000168__auto____9 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_root), nil)
				if and__1927000168__auto____9 { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_21.GetRawRoot__O()).Invoke_O__O(f__8); if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp21 any = A_arbace_repr_go_print_A_const_69; tmp20 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp21, lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(f__8))).Ref() } else { tmp20 = and__1927000168__auto____10 } } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp20) { var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_70.GetRawRoot__O()); var tmp23 any = A_arbace_repr_go_print_A_const_72; var depth__9 int32 = lang.RT_Count_O__I(tmp22.Invoke_O_O__O(tmp23, lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(f__8)))); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_71.GetRawRoot__O()); var tmp25 any = t.F_root; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_74.GetRawRoot__O()); var tmp27 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_New(); var tmp28 *jrt.Class
					var fncls__15 /*line :112:1*/*jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class

					if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class = fncls__15d; tmp28 = fncls__15d } else { tmp28 = fncls__15 }; tmp24.Invoke_O_O__O(tmp25, lang.RT_Nth_O_I__O(tmp26.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil), jrt.NN(jrt.File_Cast(file__1)).GetAbsoluteFile__File().Ref()), lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(int64(depth__9)))))
				}
				var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp30 any = A_arbace_repr_go_print_A_const_56; lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()).Invoke_O__O(tmp29.Invoke_O_O__O(tmp30, jrt.NN(jrt.File_Cast(file__1)).GetPath__String().Ref())); var tmp31 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_New_O_O_O_O_O(self, t.F_state, file__1, f__8, t.F_root); var tmp32 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class = fncls__14d; tmp32 = fncls__14d } else { tmp32 = fncls__14 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O()
//line :111:1
				seq_1344000055__2, chunk_1344000056__3, count_1344000057__4, i_1344000058__5 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000055__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :110:1*/panic("j2g: unreachable") }
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :111:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A) Ctor_O_O(c__read_fn, c__file any) { t.F_read_fn = c__read_fn; t.F_file = c__file }
//line :111:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_read_fn; t.F_read_fn = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_file; t.F_file = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_New() *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A) Ctor() {}
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A) Invoke_O_O__O(self, p1__1344000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1344000053_SHARP___1)).GetParentFile__File().Ref() }
//line :114:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_New() *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A) Ctor() {}
//line :114:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A) Invoke_O_O__O(self, p1__1344000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1344000053_SHARP___1)).GetParentFile__File().Ref() }

func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A) Ctor_O_O_O_O_O(c__f, c__walk, c__state, c__file, c__root any) { t.F_f = c__f; t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_root = c__root }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_65.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_state; t.F_state = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_f; t.F_f = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp8 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class
														if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class = fncls__10d; tmp8 = fncls__10d } else { tmp8 = fncls__10 }
//line :117:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp4, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) }
//line :116:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O(); if tmp9 != nil { panic(tmp9) }; return tmp1 }
//line :116:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A) Ctor_O_O_O_O_O(c__walk, c__state, c__file, c__f, c__root any) { t.F_walk = c__walk; t.F_state = c__state; t.F_file = c__file; t.F_f = c__f; t.F_root = c__root }
//line :116:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_65.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_state; t.F_state = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_f; t.F_f = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_New_O_O_O(t.F_walk, t.F_file, t.F_root); var tmp8 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class
														if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class = fncls__13d; tmp8 = fncls__13d } else { tmp8 = fncls__13 }
//line :117:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp4, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) }
//line :116:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O(); if tmp9 != nil { panic(tmp9) }; return tmp1 }

func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_42.GetRawRoot__O()).Invoke_O_O__O(p__1, Lit_10)) { tmp2 = jrt.File_New_File_String(jrt.File_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_root)), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_go_print_A_const_67.GetRawRoot__O()).Invoke_O_O__O(p__1, A_arbace_repr_go_print_A_const_68), nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref()) }
//line :118:1
func A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A) Ctor_O_O_O(c__walk, c__file, c__root any) { t.F_walk = c__walk; t.F_file = c__file; t.F_root = c__root }
//line :118:1
func (t *A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A) Invoke_O_O__O(self, p__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); var tmp2 *jrt.File; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_42.GetRawRoot__O()).Invoke_O_O__O(p__1, Lit_10)) { tmp2 = jrt.File_New_File_String(jrt.File_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_root)), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_go_print_A_const_67.GetRawRoot__O()).Invoke_O_O__O(p__1, A_arbace_repr_go_print_A_const_68), nil))) } else { tmp2 = jrt.File_New_File_String(jrt.NN(jrt.NN(jrt.File_Cast(t.F_file)).GetAbsoluteFile__File()).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, p__1, nil))) }; return tmp1.Invoke_O__O(tmp2.Ref())
}







func A_arbace_repr_go_print_import_spec_A_New() *A_arbace_repr_go_print_import_spec_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_import_spec_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_repr_go_print_import_spec_A) Ctor() {}
//line :128:1
func (t *A_arbace_repr_go_print_import_spec_A) Invoke_O_O__O(self, v__0 any) any { var vec__1344000075__2 any = v__0; var nm__3 any = lang.RT_Nth_O_I_O__O(vec__1344000075__2, lang.RT_IntCast_J__I(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O(vec__1344000075__2, lang.RT_IntCast_J__I(1), nil); var explicit_QMARK___5 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_77; var or__1927000174__auto____5 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__0)); if

	jrt.J2g_Truth(or__1927000174__auto____5) { explicit_QMARK___5 = or__1927000174__auto____5 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_78); explicit_QMARK___5 = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(nm__3)) }; if
	jrt.J2g_Truth(explicit_QMARK___5) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(nm__3)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O() }; return /*line :132:1*/ lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_81.GetRawRoot__O()).Invoke_O__O(path__4)) }

func A_arbace_repr_go_print_write_import_decl_A_New() *A_arbace_repr_go_print_write_import_decl_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_import_decl_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_repr_go_print_write_import_decl_A) Ctor() {}
//line :134:1
func (t *A_arbace_repr_go_print_write_import_decl_A) Invoke_O_O__O(self, specs__0 any) any {
	if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(specs__0))) {
		lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_100); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(specs__0)); return lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84) } else {
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_100); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O(); lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_101)
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_68)
//line :135:1
			var G__1344000082__2_ any = specs__0; var vec__1344000083__3 any = G__1344000082__2_; var seq__1344000084__4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(vec__1344000083__3); var first__1344000085__5 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000084__4); var seq__1344000084__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000084__4); var v__7 any = first__1344000085__5; var more__8 any = seq__1344000084__6; var prev__9 any; var G__1344000082__10_ any = G__1344000082__2_; var prev__11 any = prev__9; _ = v__7; _ = more__8; L1: for { var vec__1344000086__12 any = G__1344000082__10_; var seq__1344000087__13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(vec__1344000086__12); var first__1344000088__14 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000087__13); var seq__1344000087__15 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000087__13)
				var v__16 any = first__1344000088__14
				var more__17 any = seq__1344000087__15
				var prev__18 any = prev__11

				if jrt.J2g_Truth(v__16) {


					var tmp1 any; var and__1927000168__auto____19 any = prev__18; if jrt.J2g_Truth(and__1927000168__auto____19) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_J__Z(int64(lang.Util_Compare_O_O__I(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(v__16)), lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(prev__18)))))).Ref() } else { tmp1 = and__1927000168__auto____19 }; if jrt.J2g_Truth(tmp1) {
						lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_68) }
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_83.GetRawRoot__O()).Invoke_O__O(v__16)
					var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()); var tmp3 any; if jrt.J2g_Truth(more__17) { tmp3 = A_arbace_repr_go_print_A_const_68 } else { tmp3 = A_arbace_repr_go_print_A_const_84 }; tmp2.Invoke_O__O(tmp3)
					G__1344000082__10_, prev__11 = more__17, v__16; continue L1 }
//line :135:1
				break L1
			}











			lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_102); return lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84)
		} }
func A_arbace_repr_go_print_write_imports_A_New() *A_arbace_repr_go_print_write_imports_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_repr_go_print_write_imports_A) Ctor() {}
//line :150:1
func (t *A_arbace_repr_go_print_write_imports_A) Invoke_O_O__O(self, imports__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(imports__0)) {
		lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84)
//line :154:1
		var directive_QMARK___2 any; var tmp1 any = A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A_New(); var tmp2 *jrt.Class
		var fncls__17 /*line :154:1*/*jrt.Class = A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A_fn_class

		if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; directive_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :154:1
		var xs__3 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(imports__0); L1: for {



			if jrt.J2g_Truth(xs__3) {
				if jrt.J2g_Truth(lang.IFn_Cast(directive_QMARK___2).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__3))) {
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__3))), A_arbace_repr_go_print_A_const_84)
					xs__3 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(xs__3); continue L1 } else {
//line :159:1
						var vec__1344000093__4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_87.GetRawRoot__O()).Invoke_O__O(directive_QMARK___2), xs__3); var specs__5 any = lang.RT_Nth_O_I_O__O(vec__1344000093__4, lang.RT_IntCast_J__I(0), nil); var more__6 any = lang.RT_Nth_O_I_O__O(vec__1344000093__4, lang.RT_IntCast_J__I(1), nil)



						lang.IFn_Cast(A_arbace_repr_go_print_A_const_88.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_89.GetRawRoot__O()).Invoke_O__O(specs__5))
						xs__3 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(more__6); continue L1 } } else {
//line :158:1
							return nil } } } else {
//line :154:1
								return nil }
//line :150:1
	panic("j2g: unreachable")
}




func A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A_New() *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A) Ctor() {}
//line :156:1
func (t *A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A) Invoke_O_O__O(self, p1__1344000090_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_21.GetRawRoot__O()).Invoke_O__O(p1__1344000090_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_38.GetRawRoot__O()).Invoke_O__O(p1__1344000090_SHARP___1), Lit_67)).Ref() } else { return and__1927000168__auto____2 } }









func A_arbace_repr_go_print_write_imports_full_A_New() *A_arbace_repr_go_print_write_imports_full_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_full_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_repr_go_print_write_imports_full_A) Ctor() {}
//line :166:1
func (t *A_arbace_repr_go_print_write_imports_full_A) Invoke_O_O__O(self, imports__0 any) any { var open__2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_61.GetRawRoot__O()).Invoke_O__O(nil); var close_BANG___3 any; var tmp1 any = A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A_New_O(open__2); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A_fn_class; if





	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; close_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var seq_1344000099__4 any = /*line :166:1*/lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(imports__0); var chunk_1344000100__5 any; var count_1344000101__6 int64 = 0; var i_1344000102__7 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z(i_1344000102__7, count_1344000101__6) { var v__8 any = lang.Indexed_Cast(chunk_1344000100__5).Nth_I__O(lang.RT_IntCast_J__I(i_1344000102__7)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_26.GetRawRoot__O()).Invoke_O__O(v__8)) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_93; var p__9 any = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__8)); var vec__1344000103__10 any = v__8; var nm__11 any = lang.RT_Nth_O_I_O__O(vec__1344000103__10, lang.RT_IntCast_J__I(0), nil); var path__12 any = lang.RT_Nth_O_I_O__O(vec__1344000103__10, lang.RT_IntCast_J__I(1), nil)


			if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_95.Invoke_O__O(p__9)) {
				lang.IFn_Cast(close_BANG___3).Invoke__O()
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_100, A_arbace_repr_go_print_A_const_95.Invoke_O__O(p__9)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O()
				if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_90.Invoke_O__O(p__9)) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_101, A_arbace_repr_go_print_A_const_90.Invoke_O__O(p__9)) }
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_71.GetRawRoot__O()).Invoke_O_O__O(open__2, p__9) } else {
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_98, Lit_95) }
			var tmp4 any; var tmp5 *lang.Keyword = A_arbace_repr_go_print_A_const_77; var or__1927000174__auto____13 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__8)); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp4 = or__1927000174__auto____13 } else { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_97); tmp4 = tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(nm__11)) }; if jrt.J2g_Truth(tmp4) {
				var tmp7 *lang.Keyword = A_arbace_repr_go_print_A_const_99; var tmp8 *lang.Keyword = A_arbace_repr_go_print_A_const_93; lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(nm__11), tmp7.Invoke_O__O(tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__11)))); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O() }
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O()
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_94.GetRawRoot__O()).Invoke_O_O__O(path__12, A_arbace_repr_go_print_A_const_68)
//line :173:1
			seq_1344000099__4, chunk_1344000100__5, count_1344000101__6, i_1344000102__7 = seq_1344000099__4, chunk_1344000100__5, count_1344000101__6, lang.Numbers_Unchecked_inc_J__J(i_1344000102__7); continue L1 } else { seq_1344000099__4, chunk_1344000100__5, count_1344000101__6, i_1344000102__7 = seq_1344000099__4, chunk_1344000100__5, count_1344000101__6, lang.Numbers_Unchecked_inc_J__J(i_1344000102__7); continue L1 } } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000099__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1344000099__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000099__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000099__9); seq_1344000099__4, chunk_1344000100__5, count_1344000101__6, i_1344000102__7 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000099__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var v__10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000099__9); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_26.GetRawRoot__O()).Invoke_O__O(v__10)) { var tmp9 *lang.Keyword = A_arbace_repr_go_print_A_const_93; var p__11 any = tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__10)); var vec__1344000106__12 any = v__10; var nm__13 any = lang.RT_Nth_O_I_O__O(vec__1344000106__12, lang.RT_IntCast_J__I(0), nil); var path__14 any = lang.RT_Nth_O_I_O__O(vec__1344000106__12, lang.RT_IntCast_J__I(1), nil)


				if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_95.Invoke_O__O(p__11)) {
					lang.IFn_Cast(close_BANG___3).Invoke__O()
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_100, A_arbace_repr_go_print_A_const_95.Invoke_O__O(p__11)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O()
					if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_90.Invoke_O__O(p__11)) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_101, A_arbace_repr_go_print_A_const_90.Invoke_O__O(p__11)) }
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_71.GetRawRoot__O()).Invoke_O_O__O(open__2, p__11) } else {
						lang.IFn_Cast(A_arbace_repr_go_print_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_98, Lit_95) }
				var tmp10 any; var tmp11 *lang.Keyword = A_arbace_repr_go_print_A_const_77; var or__1927000174__auto____15 any = tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__10)); if jrt.J2g_Truth(or__1927000174__auto____15) { tmp10 = or__1927000174__auto____15 } else { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_100); tmp10 = tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(nm__13)) }; if jrt.J2g_Truth(tmp10) {
					var tmp13 *lang.Keyword = A_arbace_repr_go_print_A_const_99; var tmp14 *lang.Keyword = A_arbace_repr_go_print_A_const_93; lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(nm__13), tmp13.Invoke_O__O(tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__13)))); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O() }
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O()
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_94.GetRawRoot__O()).Invoke_O_O__O(path__14, A_arbace_repr_go_print_A_const_68)
//line :173:1
				seq_1344000099__4, chunk_1344000100__5, count_1344000101__6, i_1344000102__7 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000099__9), nil, 0, 0; continue L1 } else { seq_1344000099__4, chunk_1344000100__5, count_1344000101__6, i_1344000102__7 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000099__9), nil, 0, 0; continue L1 } } } }
//line :166:1
		break L1 }; return /*line :186:1*/ lang.IFn_Cast(close_BANG___3).Invoke__O() }
//line :172:1
func A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A_New_O(p0 any) *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A) Ctor_O(c__open any) { t.F_open = c__open }
//line :172:1
func (t *A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_open); if jrt.J2g_Truth(temp__1927000414__auto____1) { var d__2 any = temp__1927000414__auto____1; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_90.Invoke_O__O(d__2)) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_102, A_arbace_repr_go_print_A_const_92.Invoke_O__O(d__2)) } }; return lang.IFn_Cast(A_arbace_repr_go_print_A_const_71.GetRawRoot__O()).Invoke_O_O__O(t.F_open, nil) }















func A_arbace_repr_go_print_one_line_func_QMARK__A_New() *A_arbace_repr_go_print_one_line_func_QMARK__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_one_line_func_QMARK__A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_repr_go_print_one_line_func_QMARK__A) Ctor() {}
//line :188:1
func (t *A_arbace_repr_go_print_one_line_func_QMARK__A) Invoke_O_O_O_O__O(self, f__0, lines_QMARK___1, t__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_101); var and__1927000168__auto____4 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0)); if



	jrt.J2g_Truth(and__1927000168__auto____4) {
		if jrt.J2g_Truth(lines_QMARK___1) { var and__1927000168__auto____5 any = t__2
			if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_102; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)), t__2)).Ref() } else { return and__1927000168__auto____5 } } else {
//line :193:1
				var vec__1344000110__5 any = f__0; var seq__1344000111__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(vec__1344000110__5); var first__1344000112__7 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000111__6); var seq__1344000111__8 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000111__6); var ___9 any = first__1344000112__7; var first__1344000112__10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq__1344000111__8); var seq__1344000111__11 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq__1344000111__8); var nm__12 any = first__1344000112__10; var xs__13 any = seq__1344000111__11; var vec__1344000113__14 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_103.GetRawRoot__O()).Invoke_O__O(xs__13); var ___15 any = lang.RT_Nth_O_I_O__O(vec__1344000113__14, lang.RT_IntCast_J__I(0), nil); var ___16 any = lang.RT_Nth_O_I_O__O(vec__1344000113__14, lang.RT_IntCast_J__I(1), nil); var xs__17 any = lang.RT_Nth_O_I_O__O(vec__1344000113__14, lang.RT_IntCast_J__I(2), nil); var body__18 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(xs__17); var body__19 any; _ = ___9; _ = ___15; _ = ___16




				if lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(body__18), A_arbace_repr_go_print_A_const_104) { body__19 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_105.GetRawRoot__O()).Invoke_O__O(body__18) } else { body__19 = body__18 }
//line :193:1
				var and__1927000168__auto____20 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_43.GetRawRoot__O()).Invoke_O__O(body__19)





				if jrt.J2g_Truth(and__1927000168__auto____20) { var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_107; return lang.IFn_Cast(A_arbace_repr_go_print_A_const_106.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(nm__12))) } else { return and__1927000168__auto____20 } } } else {
//line :192:1
					return and__1927000168__auto____4 } }








func A_arbace_repr_go_print_decl_pre_A_New() *A_arbace_repr_go_print_decl_pre_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_decl_pre_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_repr_go_print_decl_pre_A) Ctor() {}
//line :201:1
func (t *A_arbace_repr_go_print_decl_pre_A) Invoke_O_O__O(self, f__0 any) any { var directive_QMARK___2 bool = lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_38.GetRawRoot__O()).Invoke_O__O(f__0), Lit_67); var vec__1344000117__3 any; if directive_QMARK___2 {



	var tmp1 *lang.PersistentVector; lang.PersistentVector_Init(); tmp1 = lang.PersistentVector_EMPTY; vec__1344000117__3 = lang.Tuple_Create_O_O__IPersistentVector(nil, tmp1.Ref()) } else { vec__1344000117__3 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_108.GetRawRoot__O()).Invoke_O__O(f__0) }; var doc__4 any = /*line :201:1*/lang.RT_Nth_O_I_O__O(vec__1344000117__3, lang.RT_IntCast_J__I(0), nil); var dirs__5 any = lang.RT_Nth_O_I_O__O(vec__1344000117__3, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O_O_O__IPersistentVector(jrt.Boolean_ValueOf_Z__Boolean(directive_QMARK___2).Ref(), doc__4, dirs__5, lang.IFn_Cast(A_arbace_repr_go_print_A_const_109.GetRawRoot__O()).Invoke_O_O__O(doc__4, dirs__5)) }






func A_arbace_repr_go_print_next_target_A_New() *A_arbace_repr_go_print_next_target_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_next_target_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_repr_go_print_next_target_A) Ctor() {}
//line :208:1
func (t *A_arbace_repr_go_print_next_target_A) Invoke_O_O_O__O(self, decls__0, i__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_110.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_next_target_fn__1344000121_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_go_print_next_target_fn__1344000121_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_repr_go_print_next_target_fn__1344000121_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_repr_go_print_A_const_116.GetRawRoot__O()).Invoke_O_O__O(decls__0, lang.Numbers_Inc_O__Number(i__1))) }
//line :211:1
func A_arbace_repr_go_print_next_target_fn__1344000121_A_New() *A_arbace_repr_go_print_next_target_fn__1344000121_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_next_target_fn__1344000121_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_repr_go_print_next_target_fn__1344000121_A) Ctor() {}
//line :211:1
func (t *A_arbace_repr_go_print_next_target_fn__1344000121_A) Invoke_O_O__O(self, d__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_111; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_113; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(d__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_114.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____2)) { temp__1927000414__auto____2 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__308000057__auto____2)).Ref() } else { temp__1927000414__auto____2 = nil } } else { temp__1927000414__auto____2 = nil }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2
												return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(lang.RT_LongCast_O__J(t__3), lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_115.GetRawRoot__O()).Invoke_O__O(d__1), lang.RT_IntCast_J__I(3))))).Ref() } else {
//line :211:1
		return nil } }



func A_arbace_repr_go_print_decl_sep_BANG__A_New() *A_arbace_repr_go_print_decl_sep_BANG__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_decl_sep_BANG__A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_repr_go_print_decl_sep_BANG__A) Ctor() {}
//line :215:1
func (t *A_arbace_repr_go_print_decl_sep_BANG__A) Invoke_O_O_O_O_O__O(self, f__0, t__1, pre__2, lines_QMARK___3 any) any { { var ff__5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_117.GetRawRoot__O()).Invoke_O_O_O__O(f__0, lines_QMARK___3, t__1))





	if jrt.J2g_Truth(or__1927000174__auto____5) { ff__5 = or__1927000174__auto____5 } else { var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_118; ff__5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())))).Ref() }
	var tmp2 any; var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_106.GetRawRoot__O()).Invoke_O__O(lines_QMARK___3)
	if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(t__1, nil)).Ref() }
//line :222:1
	if jrt.J2g_Truth(tmp2) {
		var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_119; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O()))) { } else { lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_84, ff__5) }; return lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_84, ff__5) } else {
//line :222:1
			if A_arbace_repr_go_print_A_const_45 != nil { var want__6 int64 = lang.Numbers_Minus_J_J__J(lang.RT_LongCast_O__J(t__1), lang.RT_LongCast_O__J(pre__2))
				var tmp4 /*line :222:1*/*lang.Keyword = A_arbace_repr_go_print_A_const_119


				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O()))) { } else { lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_84, ff__5) }
//line :222:1
			L1: for {



				var tmp5 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if lang.Numbers_Lt_O_J__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())), want__6) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_84, ff__5); continue L1 } else { return nil } } } else {
//line :222:1
					return nil } } }; /*line :215:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_print_decl_BANG__A_New() *A_arbace_repr_go_print_print_decl_BANG__A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_decl_BANG__A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_repr_go_print_print_decl_BANG__A) Ctor() {}
//line :228:1
func (t *A_arbace_repr_go_print_print_decl_BANG__A) Invoke_O_O_O_O_O_O__O(self, decls__0, i__1, lines_QMARK___2, popts__3, sep_QMARK___4 any) any { var f__6 any = lang.RT_Nth_O_I__O(decls__0, lang.RT_IntCast_O__I(i__1)); var t__7 any; var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_111; if




	jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_113; var l__308000057__auto____7 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__6)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_114.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____7)) { t__7 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__308000057__auto____7)).Ref() } else { t__7 = nil } } else { t__7 = nil }; var vec__1344000125__8 any = /*line :228:1*/lang.IFn_Cast(A_arbace_repr_go_print_A_const_115.GetRawRoot__O()).Invoke_O__O(f__6); var directive_QMARK___9 any = lang.RT_Nth_O_I_O__O(vec__1344000125__8, lang.RT_IntCast_J__I(0), nil); var doc__10 any = lang.RT_Nth_O_I_O__O(vec__1344000125__8, lang.RT_IntCast_J__I(1), nil); var dirs__11 any = lang.RT_Nth_O_I_O__O(vec__1344000125__8, lang.RT_IntCast_J__I(2), nil); var pre__12 any = lang.RT_Nth_O_I_O__O(vec__1344000125__8, lang.RT_IntCast_J__I(3), nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_A_const_121;






	lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_repr_go_print_A_const_122.GetRawRoot__O()).Invoke_O_O__O(decls__0, i__1))); var tmp5 any; tmp14 := /*line :228:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		if jrt.J2g_Truth(sep_QMARK___4) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_123.GetRawRoot__O()).Invoke_O_O_O_O__O(f__6, t__7, pre__12, lines_QMARK___2) }
		if jrt.J2g_Truth(directive_QMARK___9) {
			tmp5 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(f__6)), A_arbace_repr_go_print_A_const_84) } else {

				lang.IFn_Cast(A_arbace_repr_go_print_A_const_124.GetRawRoot__O()).Invoke_O_O_O__O(doc__10, dirs__11, A_arbace_repr_go_print_A_const_84)
				var tmp6 any; var and__1927000168__auto____15 any = lines_QMARK___2; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any = t__7; if jrt.J2g_Truth(and__1927000168__auto____16) { var tmp7 *lang.Keyword = A_arbace_repr_go_print_A_const_113; var and__1927000168__auto____17 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_125.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(t__7)).Ref(), lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O()))); if jrt.J2g_Truth(and__1927000168__auto____17) { var tmp8 lang.IFn = A_arbace_repr_go_print_A_const_126; var tmp9 any; var or__1927000174__auto____18 any = popts__3; if jrt.J2g_Truth(or__1927000174__auto____18) { tmp9 = or__1927000174__auto____18 } else { lang.PersistentArrayMap_Init(); tmp9 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp10 any = tmp9; var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; tmp6 = tmp8.Invoke_O_O__O(tmp10, tmp11.Ref()) } else { tmp6 = and__1927000168__auto____17 } } else { tmp6 = and__1927000168__auto____16 } } else { tmp6 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp6) {
					var tmp12 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(t__7), lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O()))) { L1: for {
						var tmp13 *lang.Keyword = A_arbace_repr_go_print_A_const_113; if lang.Numbers_Lt_O_J__Z(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp13.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())), lang.RT_LongCast_O__J(t__7)) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84); continue L1 }
//line :242:1
						break L1 } } else { if A_arbace_repr_go_print_A_const_45 != nil {

							lang.IFn_Cast(A_arbace_repr_go_print_A_const_127.GetRawRoot__O()).Invoke_O__O(t__7) } } }
				tmp5 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_120.GetRawRoot__O()).Invoke_O__O(f__6) }
//line :228:1
		return nil }();






	lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O(); if /*line :228:1*/ tmp14 != nil { panic(tmp14) }; return tmp5 }






















func A_arbace_repr_go_print_chunk_starts_A_New() *A_arbace_repr_go_print_chunk_starts_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_repr_go_print_chunk_starts_A) Ctor() {}
//line :251:1
func (t *A_arbace_repr_go_print_chunk_starts_A) Invoke_O_O__O(self, decls__0 any) any { var n__2 int32 = lang.RT_Count_O__I(decls__0); var k__3 any = lang.Numbers_Min_J_O__O(lang.Numbers_Multiply_J_J__J(2, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())), lang.Numbers_Quotient_J_O__Number(int64(n__2), A_arbace_repr_go_print_A_const_128.GetRawRoot__O())); if





	lang.Numbers_Gte_O_J__Z(k__3, 2) { var size__4 any = lang.Numbers_Quotient_O_O__Number(lang.Numbers_Add_J_O__Number(int64(n__2), lang.Numbers_Dec_O__Number(k__3)), k__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_17.GetRawRoot__O()); var tmp2 *lang.PersistentVector

		lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_129.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_131.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_chunk_starts_fn__1344000130_A_New_O_I(decls__0, n__2); var tmp7 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_print_chunk_starts_fn__1344000130_A_fn_class
		if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_repr_go_print_chunk_starts_fn__1344000130_A_fn_class = fncls__21d; tmp7 = fncls__21d } else { tmp7 = fncls__21 }
//line :259:1
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_130.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_print_A_const_84; return tmp1.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)), lang.IFn_Cast(A_arbace_repr_go_print_A_const_132.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_135.GetRawRoot__O()), lang.IFn_Cast(A_arbace_repr_go_print_A_const_133.GetRawRoot__O()).Invoke__O()), tmp8.Invoke_O_O_O__O(tmp9, jrt.Integer_ValueOf_I__Integer(n__2).Ref(), size__4)) } else {
//line :257:1
			return nil } }


func A_arbace_repr_go_print_chunk_starts_fn__1344000130_A_New_O_I(p0 any, p1 int32) *A_arbace_repr_go_print_chunk_starts_fn__1344000130_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_fn__1344000130_A{}; t.Ctor_O_I(p0, p1); return t }
//line :260:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000130_A) Ctor_O_I(c__decls any, c__n int32) { t.F_decls = c__decls; t.F_n = c__n }
//line :260:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000130_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_134.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A_New_O(t.F_decls); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_repr_go_print_A_const_130.GetRawRoot__O()).Invoke_O_O__O(a__1, jrt.Integer_ValueOf_I__Integer(t.F_n).Ref()))) }
//line :260:1
func A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A_New_O(p0 any) *A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A{}; t.Ctor_O(p0); return t }
//line :260:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :260:1
func (t *A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A) Invoke_O_O__O(self, p1__1344000129_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_111; if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())) { var tmp2 *lang.Keyword = A_arbace_repr_go_print_A_const_113; var tmp3 any = t.F_decls; var l__308000057__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(p1__1344000129_SHARP___1)))); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_114.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____2)) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__308000057__auto____2)).Ref() } else { return nil } } else { return nil } }




func A_arbace_repr_go_print_print_file_full_A_New() *A_arbace_repr_go_print_print_file_full_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_full_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_repr_go_print_print_file_full_A) Ctor() {}
//line :265:1
func (t *A_arbace_repr_go_print_print_file_full_A) Invoke_O_O_O_O_O__O(self, file__0, opts__1, decls__2, pkg_name__3 any) any { var m__5 any = lang.RT_Meta_O__IPersistentMap(file__0); var decls__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_136.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_137.GetRawRoot__O(), decls__2); var imports__7 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_139.Invoke_O__O(opts__1)); var p__8 any = A_arbace_repr_go_print_A_const_93.Invoke_O__O(m__5); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_A_const_112; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_140.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_print_A_const_111; var tmp6 *jrt.Boolean;








	jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_repr_go_print_A_const_126; var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; var tmp10 any = tmp9.Ref(); var tmp11 any = A_arbace_repr_go_print_A_const_143; var tmp12 any = A_arbace_repr_go_print_A_const_144; var tmp13 any = A_arbace_repr_go_print_A_const_145.Invoke_O__O(m__5); var tmp14 any = A_arbace_repr_go_print_A_const_146; var tmp15 any = A_arbace_repr_go_print_A_const_147.Invoke_O__O(m__5); var tmp16 any = A_arbace_repr_go_print_A_const_148; var tmp17 any = A_arbace_repr_go_print_A_const_149.Invoke_O__O(m__5); var tmp18 any = A_arbace_repr_go_print_A_const_150; var tmp19 any = A_arbace_repr_go_print_A_const_151.Invoke_O__O(m__5); var tmp20 any = A_arbace_repr_go_print_A_const_152; var tmp21 any = tmp4.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp7, tmp8, tmp10, tmp11, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, A_arbace_repr_go_print_A_const_153.Invoke_O__O(m__5)))))); var tmp22 any = A_arbace_repr_go_print_A_const_121; var tmp23 any = A_arbace_repr_go_print_A_const_141; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O__O(tmp3, tmp21, tmp22, nil, tmp23, lang.IFn_Cast(A_arbace_repr_go_print_A_const_142.GetRawRoot__O()).Invoke_O__O(decls__6))); var tmp24 any; tmp28 := /*line :265:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)













		lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_92, A_arbace_repr_go_print_A_const_49.Invoke_O__O(p__8)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O()
		{ var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_91.GetRawRoot__O()); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()); var tmp27 any; var or__1927000174__auto____11 any = A_arbace_repr_go_print_A_const_49.Invoke_O__O(opts__1); if jrt.J2g_Truth(or__1927000174__auto____11) { tmp27 = or__1927000174__auto____11 } else { tmp27 = pkg_name__3 }; tmp25.Invoke_O_O__O(tmp26.Invoke_O__O(tmp27), A_arbace_repr_go_print_A_const_50.Invoke_O__O(p__8))
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_154.GetRawRoot__O()).Invoke_O__O(imports__7)
//line :265:1
			var seq_1344000135__11 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(decls__6); var chunk_1344000136__12 any; var count_1344000137__13 int64 = 0; var i_1344000138__14 int64 = 0; L1: for {
















				if lang.Numbers_Lt_J_J__Z(i_1344000138__14, count_1344000137__13) { var f__15 any = lang.Indexed_Cast(chunk_1344000136__12).Nth_I__O(lang.RT_IntCast_J__I(i_1344000138__14)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_125.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_38.GetRawRoot__O()).Invoke_O__O(f__15), Lit_67)) {
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_98, Lit_95)
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_120.GetRawRoot__O()).Invoke_O__O(f__15)
//line :282:1
					seq_1344000135__11, chunk_1344000136__12, count_1344000137__13, i_1344000138__14 = seq_1344000135__11, chunk_1344000136__12, count_1344000137__13, lang.Numbers_Unchecked_inc_J__J(i_1344000138__14); continue L1 } else { seq_1344000135__11, chunk_1344000136__12, count_1344000137__13, i_1344000138__14 = seq_1344000135__11, chunk_1344000136__12, count_1344000137__13, lang.Numbers_Unchecked_inc_J__J(i_1344000138__14); continue L1 } } else { var temp__1927000414__auto____15 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000135__11); if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1344000135__16 any = temp__1927000414__auto____15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000135__16)) { var c__1927000678__auto____17 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000135__16); seq_1344000135__11, chunk_1344000136__12, count_1344000137__13, i_1344000138__14 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000135__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__17 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000135__16); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_125.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_38.GetRawRoot__O()).Invoke_O__O(f__17), Lit_67)) {
						lang.IFn_Cast(A_arbace_repr_go_print_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_98, Lit_95)
						lang.IFn_Cast(A_arbace_repr_go_print_A_const_120.GetRawRoot__O()).Invoke_O__O(f__17)
//line :282:1
						seq_1344000135__11, chunk_1344000136__12, count_1344000137__13, i_1344000138__14 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000135__16), nil, 0, 0; continue L1 } else { seq_1344000135__11, chunk_1344000136__12, count_1344000137__13, i_1344000138__14 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000135__16), nil, 0, 0; continue L1 } } } }
//line :265:1
				break L1
			}


















			tmp24 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_138.GetRawRoot__O()).Invoke__O() }
//line :265:1
		return nil }();








	lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O(); if /*line :265:1*/ tmp28 != nil { panic(tmp28) }; return tmp24 }





















func A_arbace_repr_go_print_print_file_A_New() *A_arbace_repr_go_print_print_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_repr_go_print_print_file_A) Ctor() {}
//line :287:1
func (t *A_arbace_repr_go_print_print_file_A) Invoke_O_O_O_O__O(self, p__1344000140__0, pkg_name__1, p__1344000141__2 any) any { var map__1344000142__4 any = p__1344000140__0; var map__1344000142__5 any; if lang.ISeq_InstanceOf(map__1344000142__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(map__1344000142__4)) { map__1344000142__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_print_A_const_155.GetRawRoot__O()).Invoke_O__O(map__1344000142__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(map__1344000142__4)) { map__1344000142__5 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1344000142__4) } else { lang.PersistentArrayMap_Init(); map__1344000142__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000142__5 = map__1344000142__4 }; var opts__6 any = lang.RT_Get_O_O__O(map__1344000142__5, A_arbace_repr_go_print_A_const_53); var decls__7 any = lang.RT_Get_O_O__O(map__1344000142__5, A_arbace_repr_go_print_A_const_54); var file__8 any = lang.RT_Get_O_O__O(map__1344000142__5, A_arbace_repr_go_print_A_const_52); var src__9 any = lang.RT_Get_O_O__O(map__1344000142__5, A_arbace_repr_go_print_A_const_55); var map__1344000144__10 any = p__1344000141__2; var map__1344000144__11 any; if lang.ISeq_InstanceOf(map__1344000144__10) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(map__1344000144__10)) { map__1344000144__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_print_A_const_155.GetRawRoot__O()).Invoke_O__O(map__1344000144__10), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(map__1344000144__10)) { map__1344000144__11 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1344000144__10) } else { lang.PersistentArrayMap_Init(); map__1344000144__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000144__11 = map__1344000144__10 }; var popts__12 any = map__1344000144__11; var layout__13 any = lang.RT_Get_O_O__O(map__1344000144__11, A_arbace_repr_go_print_A_const_156); var line_directives_QMARK___14 any = lang.RT_Get_O_O__O(map__1344000144__11, A_arbace_repr_go_print_A_const_126); var line_file__15 any = lang.RT_Get_O_O__O(map__1344000144__11, A_arbace_repr_go_print_A_const_157); if





	lang.Util_Equiv_O_O__Z(layout__13, A_arbace_repr_go_print_A_const_143) {
		return lang.IFn_Cast(A_arbace_repr_go_print_A_const_158.GetRawRoot__O()).Invoke_O_O_O_O__O(file__8, opts__6, decls__7, pkg_name__1) } else {
//line :293:1
			var lines_QMARK___16 any
			var G__1344000146__16_ any = layout__13
		L1: switch { default: switch lang.Util_Hash_O__I(G__1344000146__16_) >> 6 & 1 { case 0: if any(G__1344000146__16_) == any(A_arbace_repr_go_print_A_const_159) { jrt.Boolean_Init(); lines_QMARK___16 = jrt.Boolean_TRUE.Ref(); break L1 }; case 1: if any(G__1344000146__16_) == any(A_arbace_repr_go_print_A_const_160) { jrt.Boolean_Init(); lines_QMARK___16 = jrt.Boolean_FALSE.Ref(); break L1 }; default:}
			var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_113; lines_QMARK___16 = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(file__8)))).Ref()}
//line :293:1
			var state_opts__17 any; var tmp2 any = A_arbace_repr_go_print_A_const_111; var tmp3 any = A_arbace_repr_go_print_A_const_126; var tmp4 any



			if lang.Util_Identical_O_O__Z(line_directives_QMARK___14, nil) { jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE.Ref() } else { tmp4 = line_directives_QMARK___14 }
//line :293:1
			state_opts__17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, lines_QMARK___16, tmp3, tmp4))




			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp6 any = A_arbace_repr_go_print_A_const_112; var tmp7 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_140.GetRawRoot__O()).Invoke_O__O(state_opts__17); var tmp8 any = A_arbace_repr_go_print_A_const_121; var tmp9 any = A_arbace_repr_go_print_A_const_141; lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O_O_O_O_O_O__O(tmp6, tmp7, tmp8, nil, tmp9, lang.IFn_Cast(A_arbace_repr_go_print_A_const_142.GetRawRoot__O()).Invoke_O__O(decls__7)))
//line :293:1
			var tmp10 any; tmp47 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








				{ var tmp11 any; var and__1927000168__auto____20 any = lines_QMARK___16; if jrt.J2g_Truth(and__1927000168__auto____20) { var and__1927000168__auto____21 any = line_file__15; if jrt.J2g_Truth(and__1927000168__auto____21) { tmp11 = src__9 } else { tmp11 = and__1927000168__auto____21 } } else { tmp11 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp11) {
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_90, nil, Lit_91), jrt.RefArrayOf(jrt.Object_class, nil, src__9, nil)).Ref(), A_arbace_repr_go_print_A_const_84)
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_161.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_68) }
//line :293:1
					var seq_1344000147__20 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_166.Invoke_O__O(opts__6)); var chunk_1344000148__21 any; var count_1344000149__22 int64 = 0; var i_1344000150__23 int64 = 0; L2: for {











						if lang.Numbers_Lt_J_J__Z(i_1344000150__23, count_1344000149__22) { var b__24 any = lang.Indexed_Cast(chunk_1344000148__21).Nth_I__O(lang.RT_IntCast_J__I(i_1344000150__23)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(b__24), A_arbace_repr_go_print_A_const_84); seq_1344000147__20, chunk_1344000148__21, count_1344000149__22, i_1344000150__23 = seq_1344000147__20, chunk_1344000148__21, count_1344000149__22, lang.Numbers_Unchecked_inc_J__J(i_1344000150__23); continue L2 } else { var temp__1927000414__auto____24 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000147__20); if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1344000147__25 any = temp__1927000414__auto____24; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000147__25)) { var c__1927000678__auto____26 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000147__25); seq_1344000147__20, chunk_1344000148__21, count_1344000149__22, i_1344000150__23 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000147__25), c__1927000678__auto____26, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var b__26 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000147__25); lang.IFn_Cast(A_arbace_repr_go_print_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(b__26), A_arbace_repr_go_print_A_const_84); seq_1344000147__20, chunk_1344000148__21, count_1344000149__22, i_1344000150__23 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000147__25), nil, 0, 0; continue L2 } } }
//line :293:1
						break L2
					}











					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_166.Invoke_O__O(opts__6))) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84) }
//line :293:1
					var seq_1344000151__20 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_167.Invoke_O__O(opts__6)); var chunk_1344000152__21 any; var count_1344000153__22 int64 = 0; var i_1344000154__23 int64 = 0; L3: for {













						if lang.Numbers_Lt_J_J__Z(i_1344000154__23, count_1344000153__22) { var d__24 any = lang.Indexed_Cast(chunk_1344000152__21).Nth_I__O(lang.RT_IntCast_J__I(i_1344000154__23)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(d__24), A_arbace_repr_go_print_A_const_84); seq_1344000151__20, chunk_1344000152__21, count_1344000153__22, i_1344000154__23 = seq_1344000151__20, chunk_1344000152__21, count_1344000153__22, lang.Numbers_Unchecked_inc_J__J(i_1344000154__23); continue L3 } else { var temp__1927000414__auto____24_2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000151__20); if jrt.J2g_Truth(temp__1927000414__auto____24_2) { var seq_1344000151__25 any = temp__1927000414__auto____24_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000151__25)) { var c__1927000678__auto____26_2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000151__25); seq_1344000151__20, chunk_1344000152__21, count_1344000153__22, i_1344000154__23 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000151__25), c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var d__26 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000151__25); lang.IFn_Cast(A_arbace_repr_go_print_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(d__26), A_arbace_repr_go_print_A_const_84); seq_1344000151__20, chunk_1344000152__21, count_1344000153__22, i_1344000154__23 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000151__25), nil, 0, 0; continue L3 } } }
//line :293:1
						break L3
					}













					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_167.Invoke_O__O(opts__6))) { lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84) }
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_162.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_168.Invoke_O__O(opts__6), A_arbace_repr_go_print_A_const_84)
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_92); lang.IFn_Cast(A_arbace_repr_go_print_A_const_80.GetRawRoot__O()).Invoke__O(); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_79.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()); var tmp14 any; var or__1927000174__auto____20 any = A_arbace_repr_go_print_A_const_49.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____20) { tmp14 = or__1927000174__auto____20 } else { tmp14 = pkg_name__1 }; tmp12.Invoke_O__O(tmp13.Invoke_O__O(tmp14))
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84)
					lang.IFn_Cast(A_arbace_repr_go_print_A_const_163.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_139.Invoke_O__O(opts__6))
//line :293:1
					var decls__20 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_89.GetRawRoot__O()).Invoke_O__O(decls__7); var n__21 int32 = lang.RT_Count_O__I(decls__20); var starts__22 any





















					if jrt.J2g_Truth(lines_QMARK___16) { starts__22 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_164.GetRawRoot__O()).Invoke_O__O(decls__20) } else { starts__22 = nil }
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_43.GetRawRoot__O()).Invoke_O__O(starts__22)) { var n__1927000701__auto____23 int64 = lang.RT_LongCast_I__J(n__21); var i__24 int64 = 0; L4: for {
						if lang.Numbers_Lt_J_J__Z(i__24, n__1927000701__auto____23) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp16 any = jrt.Long_ValueOf_J__Long(i__24).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; tmp15.Invoke_O_O_O_O_O__O(decls__20, tmp16, lines_QMARK___16, popts__12, tmp17.Ref()); i__24 = lang.Numbers_Unchecked_inc_J__J(i__24); continue L4 }
//line :316:1
						break L4 } } else { var chunks__23 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_A_const_170.GetRawRoot__O(), starts__22, lang.IFn_Cast(A_arbace_repr_go_print_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_116.GetRawRoot__O()).Invoke_O_O__O(starts__22, A_arbace_repr_go_print_A_const_68), jrt.Integer_ValueOf_I__Integer(n__21).Ref())); var first_line__24 any; var tmp18 any = A_arbace_repr_go_print_print_file_first_line__1344000155_A_New_O(decls__20); var tmp19 *jrt.Class
							var fncls__23 /*line :316:1*/*jrt.Class = A_arbace_repr_go_print_print_file_first_line__1344000155_A_fn_class



							if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_repr_go_print_print_file_first_line__1344000155_A_fn_class = fncls__23d; tmp19 = fncls__23d } else { tmp19 = fncls__23 }; first_line__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :316:1
							var printed__25 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_165.GetRawRoot__O()); var tmp21 any = A_arbace_repr_go_print_print_file_fn__1344000158_A_New_O_O_O_O_O(popts__12, first_line__24, lines_QMARK___16, decls__20, state_opts__17); var tmp22 *jrt.Class
							var fncls__24 /*line :316:1*/*jrt.Class = A_arbace_repr_go_print_print_file_fn__1344000158_A_fn_class





							if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_repr_go_print_print_file_fn__1344000158_A_fn_class = fncls__24d; tmp22 = fncls__24d } else { tmp22 = fncls__24 }; printed__25 = tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), chunks__23)
//line :316:1
							var n__1927000701__auto____26 int64 = lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(starts__22)); var i__27 int64 = 0; L5: for {













								if lang.Numbers_Lt_J_J__Z(i__27, n__1927000701__auto____26) { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp24 any = jrt.Long_ValueOf_J__Long(i__27).Ref(); var tmp25 *jrt.Boolean; jrt.Boolean_Init(); tmp25 = jrt.Boolean_TRUE; tmp23.Invoke_O_O_O_O_O__O(decls__20, tmp24, lines_QMARK___16, popts__12, tmp25.Ref()); i__27 = lang.Numbers_Unchecked_inc_J__J(i__27); continue L5 }
//line :316:1
								break L5 }; var seq_1344000167__26 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_A_const_170.GetRawRoot__O(), chunks__23, printed__25)); var chunk_1344000168__27 any; var count_1344000169__28 int64 = 0; var i_1344000170__29 int64 = 0; L6: for {















									if lang.Numbers_Lt_J_J__Z(i_1344000170__29, count_1344000169__28) { var vec__1344000171__30 any = lang.Indexed_Cast(chunk_1344000168__27).Nth_I__O(lang.RT_IntCast_J__I(i_1344000170__29)); var vec__1344000174__31 any = lang.RT_Nth_O_I_O__O(vec__1344000171__30, lang.RT_IntCast_J__I(0), nil); var a__32 any = lang.RT_Nth_O_I_O__O(vec__1344000174__31, lang.RT_IntCast_J__I(0), nil); var b__33 any = lang.RT_Nth_O_I_O__O(vec__1344000174__31, lang.RT_IntCast_J__I(1), nil); var c__34 any = lang.RT_Nth_O_I_O__O(vec__1344000171__30, lang.RT_IntCast_J__I(1), nil); var f__35 any = lang.RT_Nth_O_I__O(decls__20, lang.RT_IntCast_O__I(a__32)); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_123.GetRawRoot__O()); var tmp27 *jrt.Long
										var tmp28 /*line :332:1*/*lang.Keyword = A_arbace_repr_go_print_A_const_111

										if jrt.J2g_Truth(tmp28.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())) { var tmp29 *lang.Keyword = A_arbace_repr_go_print_A_const_113; var l__308000057__auto____36 any = tmp29.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__35)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_114.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____36)) { tmp27 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__308000057__auto____36)) } else { tmp27 = nil } } else { tmp27 = nil }; tmp26.Invoke_O_O_O_O__O(f__35, tmp27.Ref(), lang.RT_Nth_O_I__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_115.GetRawRoot__O()).Invoke_O__O(f__35), lang.RT_IntCast_J__I(3)), lines_QMARK___16)
										if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_173.GetRawRoot__O()).Invoke_O_O__O(c__34, lang.IFn_Cast(first_line__24).Invoke_O__O(a__32))) { } else {
											var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp31 *jrt.Boolean; jrt.Boolean_Init(); tmp31 = jrt.Boolean_FALSE; tmp30.Invoke_O_O_O_O_O__O(decls__20, a__32, lines_QMARK___16, popts__12, tmp31.Ref())
//line :335:1
											var seq_1344000177__35 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Inc_O__Number(a__32), b__33)); var chunk_1344000178__36 any; var count_1344000179__37 int64 = 0; var i_1344000180__38 int64 = 0; L7: for {

												if lang.Numbers_Lt_J_J__Z(i_1344000180__38, count_1344000179__37) { var i__39 any = lang.Indexed_Cast(chunk_1344000178__36).Nth_I__O(lang.RT_IntCast_J__I(i_1344000180__38)); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp33 *jrt.Boolean; jrt.Boolean_Init(); tmp33 = jrt.Boolean_TRUE; tmp32.Invoke_O_O_O_O_O__O(decls__20, i__39, lines_QMARK___16, popts__12, tmp33.Ref()); seq_1344000177__35, chunk_1344000178__36, count_1344000179__37, i_1344000180__38 = seq_1344000177__35, chunk_1344000178__36, count_1344000179__37, lang.Numbers_Unchecked_inc_J__J(i_1344000180__38); continue L7 } else { var temp__1927000414__auto____39 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000177__35); if jrt.J2g_Truth(temp__1927000414__auto____39) { var seq_1344000177__40 any = temp__1927000414__auto____39; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000177__40)) { var c__1927000678__auto____41 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000177__40); seq_1344000177__35, chunk_1344000178__36, count_1344000179__37, i_1344000180__38 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000177__40), c__1927000678__auto____41, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I(0)); continue L7 } else { var i__41 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000177__40); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; tmp34.Invoke_O_O_O_O_O__O(decls__20, i__41, lines_QMARK___16, popts__12, tmp35.Ref()); seq_1344000177__35, chunk_1344000178__36, count_1344000179__37, i_1344000180__38 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000177__40), nil, 0, 0; continue L7 } } }
//line :335:1
												break L7 } }
//line :332:1
										seq_1344000167__26, chunk_1344000168__27, count_1344000169__28, i_1344000170__29 = seq_1344000167__26, chunk_1344000168__27, count_1344000169__28, lang.Numbers_Unchecked_inc_J__J(i_1344000170__29); continue L6 } else { var temp__1927000414__auto____30 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000167__26); if jrt.J2g_Truth(temp__1927000414__auto____30) { var seq_1344000167__31 any = temp__1927000414__auto____30; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000167__31)) { var c__1927000678__auto____32 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000167__31); seq_1344000167__26, chunk_1344000168__27, count_1344000169__28, i_1344000170__29 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000167__31), c__1927000678__auto____32, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____32))), int64(lang.RT_IntCast_J__I(0)); continue L6 } else { var vec__1344000181__32 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000167__31); var vec__1344000184__33 any = lang.RT_Nth_O_I_O__O(vec__1344000181__32, lang.RT_IntCast_J__I(0), nil); var a__34 any = lang.RT_Nth_O_I_O__O(vec__1344000184__33, lang.RT_IntCast_J__I(0), nil); var b__35 any = lang.RT_Nth_O_I_O__O(vec__1344000184__33, lang.RT_IntCast_J__I(1), nil); var c__36 any = lang.RT_Nth_O_I_O__O(vec__1344000181__32, lang.RT_IntCast_J__I(1), nil); var f__37 any = lang.RT_Nth_O_I__O(decls__20, lang.RT_IntCast_O__I(a__34)); var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_123.GetRawRoot__O()); var tmp37 *jrt.Long
											var tmp38 /*line :332:1*/*lang.Keyword = A_arbace_repr_go_print_A_const_111

											if jrt.J2g_Truth(tmp38.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())) { var tmp39 *lang.Keyword = A_arbace_repr_go_print_A_const_113; var l__308000057__auto____38 any = tmp39.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__37)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_114.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____38)) { tmp37 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__308000057__auto____38)) } else { tmp37 = nil } } else { tmp37 = nil }; tmp36.Invoke_O_O_O_O__O(f__37, tmp37.Ref(), lang.RT_Nth_O_I__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_115.GetRawRoot__O()).Invoke_O__O(f__37), lang.RT_IntCast_J__I(3)), lines_QMARK___16)
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_173.GetRawRoot__O()).Invoke_O_O__O(c__36, lang.IFn_Cast(first_line__24).Invoke_O__O(a__34))) { } else {
												var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_FALSE; tmp40.Invoke_O_O_O_O_O__O(decls__20, a__34, lines_QMARK___16, popts__12, tmp41.Ref())
//line :335:1
												var seq_1344000187__37 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Inc_O__Number(a__34), b__35)); var chunk_1344000188__38 any; var count_1344000189__39 int64 = 0; var i_1344000190__40 int64 = 0; L8: for {

													if lang.Numbers_Lt_J_J__Z(i_1344000190__40, count_1344000189__39) { var i__41_2 any = lang.Indexed_Cast(chunk_1344000188__38).Nth_I__O(lang.RT_IntCast_J__I(i_1344000190__40)); var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp43 *jrt.Boolean; jrt.Boolean_Init(); tmp43 = jrt.Boolean_TRUE; tmp42.Invoke_O_O_O_O_O__O(decls__20, i__41_2, lines_QMARK___16, popts__12, tmp43.Ref()); seq_1344000187__37, chunk_1344000188__38, count_1344000189__39, i_1344000190__40 = seq_1344000187__37, chunk_1344000188__38, count_1344000189__39, lang.Numbers_Unchecked_inc_J__J(i_1344000190__40); continue L8 } else { var temp__1927000414__auto____41 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000187__37); if jrt.J2g_Truth(temp__1927000414__auto____41) { var seq_1344000187__42 any = temp__1927000414__auto____41; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000187__42)) { var c__1927000678__auto____43 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000187__42); seq_1344000187__37, chunk_1344000188__38, count_1344000189__39, i_1344000190__40 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000187__42), c__1927000678__auto____43, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____43))), int64(lang.RT_IntCast_J__I(0)); continue L8 } else { var i__43 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000187__42); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp45 *jrt.Boolean; jrt.Boolean_Init(); tmp45 = jrt.Boolean_TRUE; tmp44.Invoke_O_O_O_O_O__O(decls__20, i__43, lines_QMARK___16, popts__12, tmp45.Ref()); seq_1344000187__37, chunk_1344000188__38, count_1344000189__39, i_1344000190__40 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000187__42), nil, 0, 0; continue L8 } } }
//line :335:1
													break L8 } }
//line :332:1
											seq_1344000167__26, chunk_1344000168__27, count_1344000169__28, i_1344000170__29 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000167__31), nil, 0, 0; continue L6 } } }
//line :316:1
									break L6
								}
						}



















					var tmp46 *lang.Keyword = A_arbace_repr_go_print_A_const_119; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_7.GetRawRoot__O()).Invoke_O__O(tmp46.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O()))) { } else { lang.IFn_Cast(A_arbace_repr_go_print_A_const_82.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_84) }
					tmp10 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_138.GetRawRoot__O()).Invoke__O() }
//line :293:1
				return nil
			}()



			lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O()
//line :293:1
			if tmp47 != nil { panic(tmp47) }; return tmp10 } }


























func A_arbace_repr_go_print_print_file_first_line__1344000155_A_New_O(p0 any) *A_arbace_repr_go_print_print_file_first_line__1344000155_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_first_line__1344000155_A{}; t.Ctor_O(p0); return t }
//line :320:1
func (t *A_arbace_repr_go_print_print_file_first_line__1344000155_A) Ctor_O(c__decls any) { t.F_decls = c__decls }
//line :320:1
func (t *A_arbace_repr_go_print_print_file_first_line__1344000155_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 any = t.F_decls; var f__2 any = lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(a__1)); var tmp2 *jrt.Long; var tmp3 *lang.Keyword = A_arbace_repr_go_print_A_const_111; if
													jrt.J2g_Truth(tmp3.Invoke_O__O(A_arbace_repr_go_print_A_const_112.Get__O())) { var tmp4 *lang.Keyword = A_arbace_repr_go_print_A_const_113; var l__308000057__auto____3 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__2)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_114.GetRawRoot__O()).Invoke_O__O(l__308000057__auto____3)) { tmp2 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__308000057__auto____3)) } else { tmp2 = nil } } else { tmp2 = nil }; return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(lang.RT_LongCast_O__J(tmp2.Ref()), lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_115.GetRawRoot__O()).Invoke_O__O(f__2), lang.RT_IntCast_J__I(3))))).Ref() }
func A_arbace_repr_go_print_print_file_fn__1344000158_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_print_print_file_fn__1344000158_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_file_fn__1344000158_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :322:1
func (t *A_arbace_repr_go_print_print_file_fn__1344000158_A) Ctor_O_O_O_O_O(c__popts, c__first_line, c__lines_QMARK_, c__decls, c__state_opts any) { t.F_popts = c__popts; t.F_first_line = c__first_line; t.F_lines_QMARK_ = c__lines_QMARK_; t.F_decls = c__decls; t.F_state_opts = c__state_opts }
//line :322:1
func (t *A_arbace_repr_go_print_print_file_fn__1344000158_A) Invoke_O_O__O(self, p__1344000157__1 any) any { var vec__1344000159__2 any = p__1344000157__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1344000159__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1344000159__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_112;
														lang.IFn_Cast(A_arbace_repr_go_print_A_const_14.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_print_A_const_140.GetRawRoot__O()).Invoke_O__O(t.F_state_opts))); var tmp3 any; tmp19 := /*line :322:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_repr_go_print_A_const_172.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_first_line).Invoke_O__O(a__3))
		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp5 any = t.F_decls; var tmp6 any = t.F_lines_QMARK_; var tmp7 any = t.F_popts; var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; tmp4.Invoke_O_O_O_O_O__O(tmp5, a__3, tmp6, tmp7, tmp8.Ref())
//line :322:1
			var seq_1344000162__7 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Inc_O__Number(a__3), b__4)); var chunk_1344000163__8 any; var count_1344000164__9 int64 = 0; var i_1344000165__10 int64 = 0; L1: for {



				if lang.Numbers_Lt_J_J__Z(i_1344000165__10, count_1344000164__9) { var i__11 any = lang.Indexed_Cast(chunk_1344000163__8).Nth_I__O(lang.RT_IntCast_J__I(i_1344000165__10)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp10 any = t.F_decls; var tmp11 any = t.F_lines_QMARK_; var tmp12 any = t.F_popts; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; tmp9.Invoke_O_O_O_O_O__O(tmp10, i__11, tmp11, tmp12, tmp13.Ref()); seq_1344000162__7, chunk_1344000163__8, count_1344000164__9, i_1344000165__10 = seq_1344000162__7, chunk_1344000163__8, count_1344000164__9, lang.Numbers_Unchecked_inc_J__J(i_1344000165__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000162__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1344000162__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000162__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000162__12); seq_1344000162__7, chunk_1344000163__8, count_1344000164__9, i_1344000165__10 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000162__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var i__13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000162__12); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_169.GetRawRoot__O()); var tmp15 any = t.F_decls; var tmp16 any = t.F_lines_QMARK_; var tmp17 any = t.F_popts; var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; tmp14.Invoke_O_O_O_O_O__O(tmp15, i__13, tmp16, tmp17, tmp18.Ref()); seq_1344000162__7, chunk_1344000163__8, count_1344000164__9, i_1344000165__10 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000162__12), nil, 0, 0; continue L1 } } }
//line :322:1
				break L1
			}



			tmp3 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_171.GetRawRoot__O()).Invoke__O() }
//line :322:1
		return nil }();
	lang.IFn_Cast(A_arbace_repr_go_print_A_const_13.GetRawRoot__O()).Invoke__O(); if /*line :322:1*/ tmp19 != nil { panic(tmp19) }; return tmp3 }


















func A_arbace_repr_go_print_print_forms_A_New() *A_arbace_repr_go_print_print_forms_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_forms_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_repr_go_print_print_forms_A) Ctor() {}
//line :341:1
func (t *A_arbace_repr_go_print_print_forms_A) Invoke_O_O_O__O(self, pkg__0, opts__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_17.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_174.GetRawRoot__O()).Invoke__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_165.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_print_forms_fn__1344000192_A_New_O_O(pkg__0, opts__1); var tmp5 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_repr_go_print_print_forms_fn__1344000192_A_fn_class
	if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_repr_go_print_print_forms_fn__1344000192_A_fn_class = fncls__25d; tmp5 = fncls__25d } else { tmp5 = fncls__25 }
//line :345:1
	return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_repr_go_print_A_const_51.Invoke_O__O(pkg__0))) }
func A_arbace_repr_go_print_print_forms_fn__1344000192_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_print_forms_fn__1344000192_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_forms_fn__1344000192_A{}; t.Ctor_O_O(p0, p1); return t }
//line :346:1
func (t *A_arbace_repr_go_print_print_forms_fn__1344000192_A) Ctor_O_O(c__pkg, c__opts any) { t.F_pkg = c__pkg; t.F_opts = c__opts }
//line :346:1
func (t *A_arbace_repr_go_print_print_forms_fn__1344000192_A) Invoke_O_O__O(self, fl__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_50.Invoke_O__O(fl__1)), lang.IFn_Cast(A_arbace_repr_go_print_A_const_175.GetRawRoot__O()).Invoke_O_O_O__O(fl__1, A_arbace_repr_go_print_A_const_50.Invoke_O__O(t.F_pkg), t.F_opts)) }





func A_arbace_repr_go_print_sha256_A_New() *A_arbace_repr_go_print_sha256_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_sha256_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_repr_go_print_sha256_A) Ctor() {}
//line :352:1
func (t *A_arbace_repr_go_print_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_97); var bs__3 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path()).Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_28.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_11.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_131.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_sha256_fn__1344000196_A_New(); var tmp5 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_repr_go_print_sha256_fn__1344000196_A_fn_class; if


	fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_repr_go_print_sha256_fn__1344000196_A_fn_class = fncls__26d; tmp5 = fncls__26d } else { tmp5 = fncls__26 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.J2g_CastArray[*jrt.ByteArray](bs__3, jrt.Prim_byte.ArrayClass())).Ref())) }
//line :355:1
func A_arbace_repr_go_print_sha256_fn__1344000196_A_New() *A_arbace_repr_go_print_sha256_fn__1344000196_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_sha256_fn__1344000196_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_repr_go_print_sha256_fn__1344000196_A) Ctor() {}
//line :355:1
func (t *A_arbace_repr_go_print_sha256_fn__1344000196_A) Invoke_O_O__O(self, p1__1344000195_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_A_const_176.GetRawRoot__O()).Invoke_O_O__O(Lit_99, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__1344000195_SHARP___1, 255)).Ref()) }

func A_arbace_repr_go_print_copy_file_A_New() *A_arbace_repr_go_print_copy_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_file_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_repr_go_print_copy_file_A) Ctor() {}
//line :357:1
func (t *A_arbace_repr_go_print_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_177.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_A_const_178; var tmp5 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp5 = jrt.StandardCopyOption_REPLACE_EXISTING; return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.J2g_CastArray[*jrt.RefArray](tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5.Ref())), jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_repr_go_print_json_string_A_New() *A_arbace_repr_go_print_json_string_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_json_string_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_go_print_json_string_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_go_print_json_string_A) Invoke_O_O__O(self, s__0 any) any {
	return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_179.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_179.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(s__0), Lit_86, Lit_87), Lit_85, Lit_88), nil)).Ref()
}
func A_arbace_repr_go_print_copy_files_A_New() *A_arbace_repr_go_print_copy_files_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_repr_go_print_copy_files_A) Ctor() {}
//line :365:1
func (t *A_arbace_repr_go_print_copy_files_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, written__3 any) any { var opts__5 any = A_arbace_repr_go_print_A_const_49.Invoke_O__O(pkg__0); var seq_1344000201__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_181.Invoke_O__O(opts__5)); var chunk_1344000202__7 any; var count_1344000203__8 int64 = 0; var i_1344000204__9 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z(i_1344000204__9, count_1344000203__8) { var f__10 any = lang.Indexed_Cast(chunk_1344000202__7).Nth_I__O(lang.RT_IntCast_J__I(i_1344000204__9))
		lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__1), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__10))), jrt.File_New_File_String(jrt.File_Cast(out__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__10))))
//line :370:1
		seq_1344000201__6, chunk_1344000202__7, count_1344000203__8, i_1344000204__9 = seq_1344000201__6, chunk_1344000202__7, count_1344000203__8, lang.Numbers_Unchecked_inc_J__J(i_1344000204__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000201__6); if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1344000201__11 any = temp__1927000414__auto____10; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000201__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000201__11); seq_1344000201__6, chunk_1344000202__7, count_1344000203__8, i_1344000204__9 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000201__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000201__11)
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__1), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__12))), jrt.File_New_File_String(jrt.File_Cast(out__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__12))))
//line :370:1
			seq_1344000201__6, chunk_1344000202__7, count_1344000203__8, i_1344000204__9 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000201__11), nil, 0, 0; continue L1 } } }
//line :365:1
	break L1 }; var seq_1344000205__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_183.Invoke_O__O(opts__5)); var chunk_1344000206__7 any; var count_1344000207__8 int64 = 0; var i_1344000208__9 int64 = 0; L2: for {






		if lang.Numbers_Lt_J_J__Z(i_1344000208__9, count_1344000207__8) { var vec__1344000209__10 any = lang.Indexed_Cast(chunk_1344000206__7).Nth_I__O(lang.RT_IntCast_J__I(i_1344000208__9)); var f__11 any = lang.RT_Nth_O_I_O__O(vec__1344000209__10, lang.RT_IntCast_J__I(0), nil); var h__12 any = lang.RT_Nth_O_I_O__O(vec__1344000209__10, lang.RT_IntCast_J__I(1), nil); var from__13 any = jrt.File_New_File_String(jrt.File_Cast(src__1), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__11))); var got__14 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_184.GetRawRoot__O()).Invoke_O__O(from__13); var tmp1 any
			var and__1927000168__auto____15 any = h__12

			if jrt.J2g_Truth(and__1927000168__auto____15) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_125.GetRawRoot__O()).Invoke_O_O__O(got__14, lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(h__12)) } else { tmp1 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp1) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_56, nil, Lit_57, nil, Lit_58, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__11, nil, got__14, nil, h__12)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_52, f__11))))))
			}
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(from__13, jrt.File_New_File_String(jrt.File_Cast(out__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__11))))
//line :372:1
			seq_1344000205__6, chunk_1344000206__7, count_1344000207__8, i_1344000208__9 = seq_1344000205__6, chunk_1344000206__7, count_1344000207__8, lang.Numbers_Unchecked_inc_J__J(i_1344000208__9); continue L2 } else { var temp__1927000414__auto____10_2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000205__6); if jrt.J2g_Truth(temp__1927000414__auto____10_2) { var seq_1344000205__11 any = temp__1927000414__auto____10_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000205__11)) { var c__1927000678__auto____12_2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000205__11); seq_1344000205__6, chunk_1344000206__7, count_1344000207__8, i_1344000208__9 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000205__11), c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var vec__1344000212__12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000205__11); var f__13 any = lang.RT_Nth_O_I_O__O(vec__1344000212__12, lang.RT_IntCast_J__I(0), nil); var h__14 any = lang.RT_Nth_O_I_O__O(vec__1344000212__12, lang.RT_IntCast_J__I(1), nil); var from__15 any = jrt.File_New_File_String(jrt.File_Cast(src__1), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__13))); var got__16 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_184.GetRawRoot__O()).Invoke_O__O(from__15); var tmp2 any
				var and__1927000168__auto____17 any = h__14

				if jrt.J2g_Truth(and__1927000168__auto____17) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_125.GetRawRoot__O()).Invoke_O_O__O(got__16, lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(h__14)) } else { tmp2 = and__1927000168__auto____17 }; if jrt.J2g_Truth(tmp2) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_56, nil, Lit_57, nil, Lit_58, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__13, nil, got__16, nil, h__14)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_52, f__13))))))
				}
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_182.GetRawRoot__O()).Invoke_O_O__O(from__15, jrt.File_New_File_String(jrt.File_Cast(out__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(f__13))))
//line :372:1
				seq_1344000205__6, chunk_1344000206__7, count_1344000207__8, i_1344000208__9 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000205__11), nil, 0, 0; continue L2 } } }
//line :365:1
		break L2 }; var tmp3 lang.IFn =












	lang.IFn_Cast(A_arbace_repr_go_print_A_const_180.GetRawRoot__O()); var tmp4 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_24); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_185.GetRawRoot__O()); var tmp7 any; var iter__1927001039__auto____9 any; var tmp8 any = A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A_New_O_O(src__1, out__2); var tmp9 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A_fn_class; if

	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A_fn_class = fncls__29d; tmp9 = fncls__29d } else { tmp9 = fncls__29 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(written__3); return /*line :378:1*/ tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O_O__O(Lit_61, tmp7), nil)).Ref()) }

func A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A{}; t.Ctor_O_O(p0, p1); return t }
//line :380:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A) Ctor_O_O(c__src, c__out any) { t.F_src = c__src; t.F_out = c__out }
//line :380:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A) Invoke_O_O__O(self, s__1344000216__1 any) any { var tmp1 any = A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A_New_O_O_O_O(self, t.F_src, t.F_out, s__1344000216__1); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :380:1
func A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :380:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A) Ctor_O_O_O_O(c__iter__1344000215, c__src, c__out, c__s__1344000216 any) { t.F_iter__1344000215 = c__iter__1344000215; t.F_src = c__src; t.F_out = c__out; t.F_s__1344000216 = c__s__1344000216 }
//line :380:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A) Invoke_O__O(self any) any { { var s__1344000216__1 any; var t_ any = t.F_s__1344000216; t.F_s__1344000216 = nil; s__1344000216__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(s__1344000216__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1344000216__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(s__1344000216__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(s__1344000216__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1344000218__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A_New_O_O_O_I_O(t.F_src, b__1344000218__6, t.F_out, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1344000215); return lang.IFn_Cast(A_arbace_repr_go_print_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_35.GetRawRoot__O()).Invoke_O__O(b__1344000218__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(s__1344000216__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_print_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_35.GetRawRoot__O()).Invoke_O__O(b__1344000218__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1344000216__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1344000215); return lang.IFn_Cast(A_arbace_repr_go_print_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_186.GetRawRoot__O()).Invoke_O__O(jrt.File_New_File_String(jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(n__4))).GetPath__String().Ref()), nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_186.GetRawRoot__O()).Invoke_O__O(jrt.File_New_File_String(jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(n__4))).GetPath__String().Ref()))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1344000216__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :380:1
func A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :380:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A) Ctor_O_O_O_I_O(c__src, c__b__1344000218, c__out any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_src = c__src; t.F_b__1344000218 = c__b__1344000218; t.F_out = c__out; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :380:1
func (t *A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A) Invoke_O__O(self any) any { { var i__1344000217__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1344000217__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1344000217__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_31.GetRawRoot__O()); var tmp3 any = t.F_b__1344000218; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_186.GetRawRoot__O()).Invoke_O__O(jrt.File_New_File_String(jrt.NN(jrt.File_Cast(t.F_src)).GetAbsoluteFile__File(), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(n__2))).GetPath__String().Ref()), nil, lang.IFn_Cast(A_arbace_repr_go_print_A_const_186.GetRawRoot__O()).Invoke_O__O(jrt.File_New_File_String(jrt.NN(jrt.File_Cast(t.F_out)).GetAbsoluteFile__File(), jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(n__2))).GetPath__String().Ref()))).Ref()); i__1344000217__1 = lang.Numbers_Unchecked_inc_J__J(i__1344000217__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_print_build_env_A_New() *A_arbace_repr_go_print_build_env_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_build_env_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_repr_go_print_build_env_A) Ctor() {}
//line :385:1
func (t *A_arbace_repr_go_print_build_env_A) Invoke_O_O_O__O(self, config__0, goroot__1 any) any { var G__1344000226__3_ any; var tmp1 *jrt.String; if



	jrt.J2g_Truth(A_arbace_repr_go_print_A_const_187.Invoke_O__O(config__0)) { tmp1 = Lit_35 } else { tmp1 = Lit_36 }; G__1344000226__3_ = /*line :385:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_27, goroot__1, Lit_28, Lit_29, Lit_30, Lit_31, Lit_32, Lit_33, Lit_34, tmp1.Ref())); var G__1344000226__4_ any; if


	jrt.J2g_Truth(A_arbace_repr_go_print_A_const_188.Invoke_O__O(config__0)) {

		G__1344000226__4_ = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(G__1344000226__3_, Lit_37, A_arbace_repr_go_print_A_const_188.Invoke_O__O(config__0)) } else {
//line :388:1
			G__1344000226__4_ = G__1344000226__3_ }; var G__1344000226__5_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_189.Invoke_O__O(config__0)) {


				G__1344000226__5_ = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(G__1344000226__4_, Lit_38, A_arbace_repr_go_print_A_const_189.Invoke_O__O(config__0)) } else {
//line :388:1
					G__1344000226__5_ = G__1344000226__4_ }; var G__1344000226__6_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_190.Invoke_O__O(config__0)) {



						G__1344000226__6_ = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(G__1344000226__5_, Lit_39, A_arbace_repr_go_print_A_const_190.Invoke_O__O(config__0)) } else {
//line :388:1
							G__1344000226__6_ = G__1344000226__5_ }; var G__1344000226__7_ any; if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_191.Invoke_O__O(config__0)) {




								G__1344000226__7_ = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(G__1344000226__6_, Lit_40, A_arbace_repr_go_print_A_const_191.Invoke_O__O(config__0)) } else {
//line :388:1
									G__1344000226__7_ = G__1344000226__6_ }; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_192.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_A_const_193.Invoke_O__O(config__0))) {





										return lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(G__1344000226__7_, Lit_41, A_arbace_repr_go_print_A_const_193.Invoke_O__O(config__0)) } else {
//line :388:1
											return G__1344000226__7_ } }







func A_arbace_repr_go_print_run_A_New() *A_arbace_repr_go_print_run_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_run_A{}; t.Ctor(); return t }
//line :396:1
func (t *A_arbace_repr_go_print_run_A) Ctor() {}
//line :396:1
func (t *A_arbace_repr_go_print_run_A) Invoke_O_O_O_O__O(self, cmd__0, dir__1, env__2 any) any { var pb__4 any = jrt.ProcessBuilder_New_List(jrt.List_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_131.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_A_const_11.GetRawRoot__O(), cmd__0)));

	jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__5 any = /*line :396:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Environment__Map(); var seq_1344000228__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(env__2); var chunk_1344000229__7 any; var count_1344000230__8 int64 = 0; var i_1344000231__9 int64 = 0; L1: for {



		if lang.Numbers_Lt_J_J__Z(i_1344000231__9, count_1344000230__8) { var vec__1344000232__10 any = lang.Indexed_Cast(chunk_1344000229__7).Nth_I__O(lang.RT_IntCast_J__I(i_1344000231__9)); var k__11 any = lang.RT_Nth_O_I_O__O(vec__1344000232__10, lang.RT_IntCast_J__I(0), nil); var v__12 any = lang.RT_Nth_O_I_O__O(vec__1344000232__10, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__11, v__12); seq_1344000228__6, chunk_1344000229__7, count_1344000230__8, i_1344000231__9 = seq_1344000228__6, chunk_1344000229__7, count_1344000230__8, lang.Numbers_Unchecked_inc_J__J(i_1344000231__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000228__6); if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1344000228__11 any = temp__1927000414__auto____10; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000228__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000228__11); seq_1344000228__6, chunk_1344000229__7, count_1344000230__8, i_1344000231__9 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000228__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1344000235__12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000228__11); var k__13 any = lang.RT_Nth_O_I_O__O(vec__1344000235__12, lang.RT_IntCast_J__I(0), nil); var v__14 any = lang.RT_Nth_O_I_O__O(vec__1344000235__12, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__5).Put_O_O__O(k__13, v__14); seq_1344000228__6, chunk_1344000229__7, count_1344000230__8, i_1344000231__9 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000228__11), nil, 0, 0; continue L1 } } }
//line :396:1
		break L1 }; var tmp1 /*line :401:1*/*jrt.ProcessBuilder = jrt.ProcessBuilder_Cast(pb__4); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; jrt.NN(tmp1).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(tmp2).BooleanValue__Z()); var p__5 any = /*line :396:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__4)).Start__Process(); var out__6 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_194.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(p__5).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.Process_Cast(p__5).WaitFor__I()).Ref(), out__6) }









func A_arbace_repr_go_print_build_A_New() *A_arbace_repr_go_print_build_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_build_A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_repr_go_print_build_A) Ctor() {}
//line :406:1
func (t *A_arbace_repr_go_print_build_A) Invoke_O_O_O_O_O__O(self, pkg__0, src__1, out__2, goroot__3 any) any { var tmp1 *lang.Keyword = A_arbace_repr_go_print_A_const_195; var config__5 any = tmp1.Invoke_O__O(A_arbace_repr_go_print_A_const_49.Invoke_O__O(pkg__0)); var tags__6 any = A_arbace_repr_go_print_A_const_196.Invoke_O__O(config__5); var cmd__7 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_37.GetRawRoot__O()); var tmp3 any = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, goroot__3, nil)).Ref(), Lit_21, Lit_22, Lit_23, jrt.File_New_File_String(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File(), Lit_24).GetPath__String().Ref()); var tmp4 lang.IPersistentVector; if






	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(tags__6)) { tmp4 = lang.Tuple_Create_O_O__IPersistentVector(Lit_25, lang.IFn_Cast(A_arbace_repr_go_print_A_const_185.GetRawRoot__O()).Invoke_O_O__O(Lit_26, tags__6)) } else { tmp4 = nil }; cmd__7 = /*line :411:1*/tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_repr_go_print_A_const_198); return /*line :415:1*/ lang.IFn_Cast(A_arbace_repr_go_print_A_const_197.GetRawRoot__O()).Invoke_O_O_O__O(cmd__7, src__1, lang.IFn_Cast(A_arbace_repr_go_print_A_const_199.GetRawRoot__O()).Invoke_O_O__O(config__5, goroot__3)) }

func A_arbace_repr_go_print_print_package_A_New() *A_arbace_repr_go_print_print_package_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_print_package_A{}; t.Ctor(); return t }
//line :417:1
func (t *A_arbace_repr_go_print_print_package_A) Ctor() {}
//line :417:1
func (t *A_arbace_repr_go_print_print_package_A) Invoke_O_O_O_O__O(self, path__0, out_dir__1, opts__2 any) any { var pkg__4 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_75.GetRawRoot__O()).Invoke_O__O(path__0); var out__5 any = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_11.GetRawRoot__O()).Invoke_O__O(out_dir__1))); var layout__6 any = A_arbace_repr_go_print_A_const_156.Invoke_O__O(opts__2); var files__7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_200.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_print_A_const_156; var tmp4 any; var or__1927000174__auto____7 any = layout__6; if





	jrt.J2g_Truth(or__1927000174__auto____7) { tmp4 = or__1927000174__auto____7 } else { var tmp5 any = A_arbace_repr_go_print_A_const_143; var tmp6 *lang.Keyword = A_arbace_repr_go_print_A_const_202; if lang.Util_Equiv_O_O__Z(tmp5, tmp6.Invoke_O__O(A_arbace_repr_go_print_A_const_49.Invoke_O__O(pkg__4))) { tmp4 = A_arbace_repr_go_print_A_const_143 } else { tmp4 = nil } }; files__7 = tmp1.Invoke_O_O__O(pkg__4, tmp2.Invoke_O_O_O__O(opts__2, tmp3, tmp4));
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(out__5)).Mkdirs__Z()); var seq_1344000240__8 any = /*line :417:1*/lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(files__7); var chunk_1344000241__9 any; var count_1344000242__10 int64 = 0; var i_1344000243__11 int64 = 0; L1: for {







		if lang.Numbers_Lt_J_J__Z(i_1344000243__11, count_1344000242__10) { var vec__1344000244__12 any = lang.Indexed_Cast(chunk_1344000241__9).Nth_I__O(lang.RT_IntCast_J__I(i_1344000243__11)); var n__13 any = lang.RT_Nth_O_I_O__O(vec__1344000244__12, lang.RT_IntCast_J__I(0), nil); var text__14 any = lang.RT_Nth_O_I_O__O(vec__1344000244__12, lang.RT_IntCast_J__I(1), nil)
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_180.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__13)), text__14)
//line :425:1
			seq_1344000240__8, chunk_1344000241__9, count_1344000242__10, i_1344000243__11 = seq_1344000240__8, chunk_1344000241__9, count_1344000242__10, lang.Numbers_Unchecked_inc_J__J(i_1344000243__11); continue L1 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000240__8); if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1344000240__13 any = temp__1927000414__auto____12; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000240__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000240__13); seq_1344000240__8, chunk_1344000241__9, count_1344000242__10, i_1344000243__11 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000240__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1344000247__14 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000240__13); var n__15 any = lang.RT_Nth_O_I_O__O(vec__1344000247__14, lang.RT_IntCast_J__I(0), nil); var text__16 any = lang.RT_Nth_O_I_O__O(vec__1344000247__14, lang.RT_IntCast_J__I(1), nil)
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_180.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__5), jrt.String_Cast(n__15)), text__16)
//line :425:1
				seq_1344000240__8, chunk_1344000241__9, count_1344000242__10, i_1344000243__11 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000240__13), nil, 0, 0; continue L1 } } }
//line :417:1
		break L1 }; var tmp7 any = A_arbace_repr_go_print_A_const_49; var tmp8 any = A_arbace_repr_go_print_A_const_51; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, pkg__4, tmp8, lang.IFn_Cast(A_arbace_repr_go_print_A_const_201.GetRawRoot__O()).Invoke_O__O(files__7))) }











func A_arbace_repr_go_print_gofmt_file_A_New() *A_arbace_repr_go_print_gofmt_file_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_gofmt_file_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_repr_go_print_gofmt_file_A) Ctor() {}
//line :429:1
func (t *A_arbace_repr_go_print_gofmt_file_A) Invoke_O_O_O__O(self, goroot__0, f__1 any) any { var vec__1344000251__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_197.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_82), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_83, jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetPath__String().Ref()); var tmp3 any = jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).GetParentFile__File().Ref(); var tmp4 *lang.PersistentArrayMap;
												lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; vec__1344000251__3 = tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Ref()); var status__4 any = /*line :429:1*/lang.RT_Nth_O_I_O__O(vec__1344000251__3, lang.RT_IntCast_J__I(0), nil); var out__5 any = lang.RT_Nth_O_I_O__O(vec__1344000251__3, lang.RT_IntCast_J__I(1), nil); if

	lang.Numbers_IsZero_O__Z(status__4) { return nil } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_84, nil, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1, nil, out__5)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_A_const_52, f__1)))))) } }


func A_arbace_repr_go_print__main_A_New() *A_arbace_repr_go_print__main_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print__main_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_repr_go_print__main_A) Ctor() {}
//line :434:1
func (t *A_arbace_repr_go_print__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :434:1
	var as__3 any = argv__0; var opts__4 any; lang.PersistentArrayMap_Init(); opts__4 = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var G__1344000255__5_ any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(as__3)


		switch lang.Util_Hash_O__I(G__1344000255__5_) >> 7 & 15 { case 1: if lang.Util_Equiv_O_O__Z(G__1344000255__5_, Lit_3) {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_A_const_156; as__3, opts__4 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_105.GetRawRoot__O()).Invoke_O__O(as__3), tmp1.Invoke_O_O_O__O(opts__4, tmp2, lang.IFn_Cast(A_arbace_repr_go_print_A_const_205.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(as__3))); continue L1 }
//line :437:1
		case 8: if lang.Util_Equiv_O_O__Z(G__1344000255__5_, Lit_4) {


			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_A_const_55; as__3, opts__4 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_105.GetRawRoot__O()).Invoke_O__O(as__3), tmp3.Invoke_O_O_O__O(opts__4, tmp4, lang.IFn_Cast(A_arbace_repr_go_print_A_const_73.GetRawRoot__O()).Invoke_O__O(as__3)); continue L1 }
//line :437:1
		case 9: if lang.Util_Equiv_O_O__Z(G__1344000255__5_, Lit_5) {



			var tmp5 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(as__3); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_print_A_const_166; var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; as__3, opts__4 = tmp5, tmp6.Invoke_O_O_O__O(opts__4, tmp7, tmp8.Ref()); continue L1 }
//line :437:1
		case 10: if lang.Util_Equiv_O_O__Z(G__1344000255__5_, Lit_6) {




			var tmp9 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(as__3); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_print_A_const_160; var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; as__3, opts__4 = tmp9, tmp10.Invoke_O_O_O__O(opts__4, tmp11, tmp12.Ref()); continue L1 }
//line :437:1
		case 12: if lang.Util_Equiv_O_O__Z(G__1344000255__5_, Lit_7) {





			var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(as__3); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_print_A_const_157; var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; as__3, opts__4 = tmp13, tmp14.Invoke_O_O_O__O(opts__4, tmp15, tmp16.Ref()); continue L1 }
//line :437:1
		case 14: if lang.Util_Equiv_O_O__Z(G__1344000255__5_, Lit_8) {

			var tmp17 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(as__3); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_A_const_41.GetRawRoot__O()); var tmp19 any = A_arbace_repr_go_print_A_const_126; var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_FALSE; as__3, opts__4 = tmp17, tmp18.Invoke_O_O_O__O(opts__4, tmp19, tmp20.Ref()); continue L1 }
//line :437:1
		default:}; var vec__1344000256__6 any = as__3; var forms__7 any = lang.RT_Nth_O_I_O__O(vec__1344000256__6, lang.RT_IntCast_J__I(0), nil); var out__8 any = lang.RT_Nth_O_I_O__O(vec__1344000256__6, lang.RT_IntCast_J__I(1), nil); var tmp21 any
		var and__1927000168__auto____9 any = forms__7






		if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = out__8; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp21 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(as__3)))).Ref() } else { tmp21 = and__1927000168__auto____10 } } else { tmp21 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp21) { } else {
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_206.GetRawRoot__O()).Invoke_O__O(Lit_9)
			jrt.System_Exit_I__V(lang.RT_IntCast_J__I(2)) }
//line :437:1
		var map__1344000259__9 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_203.GetRawRoot__O()).Invoke_O_O_O__O(forms__7, out__8, opts__4); var map__1344000259__10 any










		if lang.ISeq_InstanceOf(map__1344000259__9) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(map__1344000259__9)) { map__1344000259__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_go_print_A_const_155.GetRawRoot__O()).Invoke_O__O(map__1344000259__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(map__1344000259__9)) { map__1344000259__10 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1344000259__9) } else { lang.PersistentArrayMap_Init(); map__1344000259__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1344000259__10 = map__1344000259__9 }
//line :437:1
		var package__11 any = lang.RT_Get_O_O__O(map__1344000259__10, A_arbace_repr_go_print_A_const_49); var files__12 any = lang.RT_Get_O_O__O(map__1344000259__10, A_arbace_repr_go_print_A_const_51); var outf__13 any = jrt.File_New_String(jrt.String_Cast(out__8)); var seq_1344000261__14 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(files__12); var chunk_1344000262__15 any; var count_1344000263__16 int64 = 0; var i_1344000264__17 int64 = 0; L3: for {












			if lang.Numbers_Lt_J_J__Z(i_1344000264__17, count_1344000263__16) { var f__18 any = lang.Indexed_Cast(chunk_1344000262__15).Nth_I__O(lang.RT_IntCast_J__I(i_1344000264__17)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_206.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__18)).Ref()); seq_1344000261__14, chunk_1344000262__15, count_1344000263__16, i_1344000264__17 = seq_1344000261__14, chunk_1344000262__15, count_1344000263__16, lang.Numbers_Unchecked_inc_J__J(i_1344000264__17); continue L3 } else { var temp__1927000414__auto____18 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000261__14); if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1344000261__19 any = temp__1927000414__auto____18; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000261__19)) { var c__1927000678__auto____20 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000261__19); seq_1344000261__14, chunk_1344000262__15, count_1344000263__16, i_1344000264__17 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000261__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var f__20 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000261__19); lang.IFn_Cast(A_arbace_repr_go_print_A_const_206.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, out__8, nil, f__20)).Ref()); seq_1344000261__14, chunk_1344000262__15, count_1344000263__16, i_1344000264__17 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000261__19), nil, 0, 0; continue L3 } } }
//line :437:1
			break L3
		}












		if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_160.Invoke_O__O(opts__4)) { var seq_1344000265__14 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(files__12); var chunk_1344000266__15 any; var count_1344000267__16 int64 = 0; var i_1344000268__17 int64 = 0; L4: for {
			if lang.Numbers_Lt_J_J__Z(i_1344000268__17, count_1344000267__16) { var f__18_2 any = lang.Indexed_Cast(chunk_1344000266__15).Nth_I__O(lang.RT_IntCast_J__I(i_1344000268__17)); lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O_O__O(goroot__2, jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__18_2))); seq_1344000265__14, chunk_1344000266__15, count_1344000267__16, i_1344000268__17 = seq_1344000265__14, chunk_1344000266__15, count_1344000267__16, lang.Numbers_Unchecked_inc_J__J(i_1344000268__17); continue L4 } else { var temp__1927000414__auto____18_2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_1344000265__14); if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1344000265__19 any = temp__1927000414__auto____18_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_1344000265__19)) { var c__1927000678__auto____20_2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_1344000265__19); seq_1344000265__14, chunk_1344000266__15, count_1344000267__16, i_1344000268__17 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1344000265__19), c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var f__20_2 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1344000265__19); lang.IFn_Cast(A_arbace_repr_go_print_A_const_208.GetRawRoot__O()).Invoke_O_O__O(goroot__2, jrt.File_New_File_String(jrt.File_Cast(outf__13), jrt.String_Cast(f__20_2))); seq_1344000265__14, chunk_1344000266__15, count_1344000267__16, i_1344000268__17 = lang.IFn_Cast(A_arbace_repr_go_print_A_const_40.GetRawRoot__O()).Invoke_O__O(seq_1344000265__19), nil, 0, 0; continue L4 } } }
//line :451:1
			break L4 } }
//line :437:1
		var temp__1927000414__auto____14 any = A_arbace_repr_go_print_A_const_55.Invoke_O__O(opts__4)















		if jrt.J2g_Truth(temp__1927000414__auto____14) { var src__15 any = temp__1927000414__auto____14
			lang.IFn_Cast(A_arbace_repr_go_print_A_const_209.GetRawRoot__O()).Invoke_O_O_O_O__O(package__11, jrt.File_New_String(jrt.String_Cast(src__15)), outf__13, files__12)
			if jrt.J2g_Truth(A_arbace_repr_go_print_A_const_166.Invoke_O__O(opts__4)) { var vec__1344000269__16 any = lang.IFn_Cast(A_arbace_repr_go_print_A_const_207.GetRawRoot__O()).Invoke_O_O_O_O__O(package__11, jrt.File_New_String(jrt.String_Cast(src__15)), outf__13, goroot__2); var status__17 any = lang.RT_Nth_O_I_O__O(vec__1344000269__16, lang.RT_IntCast_J__I(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O(vec__1344000269__16, lang.RT_IntCast_J__I(1), nil)

				lang.IFn_Cast(A_arbace_repr_go_print_A_const_210.GetRawRoot__O()).Invoke_O__O(text__18)
				lang.IFn_Cast(A_arbace_repr_go_print_A_const_211.GetRawRoot__O()).Invoke__O()
				if lang.Numbers_IsZero_O__Z(status__17) { } else { jrt.System_Exit_I__V(lang.RT_IntCast_J__I(1)) } } }
		return lang.IFn_Cast(A_arbace_repr_go_print_A_const_204.GetRawRoot__O()).Invoke__O() } }; /*line :434:1*/panic("j2g: unreachable") }







type A_arbace_repr_go_print_A struct{ jrt.Object }

var A_arbace_repr_go_print_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_A_const_0 *lang.Var

var A_arbace_repr_go_print_A_const_1 *lang.Var

var A_arbace_repr_go_print_A_const_2 any

var A_arbace_repr_go_print_A_const_3 any

var A_arbace_repr_go_print_A_const_4 any

var A_arbace_repr_go_print_A_const_5 any

var A_arbace_repr_go_print_A_const_6 *lang.Var

var A_arbace_repr_go_print_A_const_7 *lang.Var

var A_arbace_repr_go_print_A_const_8 *lang.Var

var A_arbace_repr_go_print_A_const_9 any

var A_arbace_repr_go_print_A_const_10 *lang.Var

var A_arbace_repr_go_print_A_const_11 *lang.Var

var A_arbace_repr_go_print_A_const_12 *lang.Var

var A_arbace_repr_go_print_A_const_13 *lang.Var

var A_arbace_repr_go_print_A_const_14 *lang.Var

var A_arbace_repr_go_print_A_const_15 *lang.Var

var A_arbace_repr_go_print_A_const_16 *lang.Var

var A_arbace_repr_go_print_A_const_17 *lang.Var

var A_arbace_repr_go_print_A_const_18 any

var A_arbace_repr_go_print_A_const_19 *lang.Var

var A_arbace_repr_go_print_A_const_20 *lang.Var

var A_arbace_repr_go_print_A_const_21 *lang.Var

var A_arbace_repr_go_print_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_A_const_23 *lang.Var

var A_arbace_repr_go_print_A_const_24 *lang.Var

var A_arbace_repr_go_print_A_const_25 *lang.Var

var A_arbace_repr_go_print_A_const_26 *lang.Var

var A_arbace_repr_go_print_A_const_27 any

var A_arbace_repr_go_print_A_const_28 *lang.Var

var A_arbace_repr_go_print_A_const_29 *lang.Keyword

var A_arbace_repr_go_print_A_const_30 *lang.Var

var A_arbace_repr_go_print_A_const_31 *lang.Var

var A_arbace_repr_go_print_A_const_32 *lang.Var

var A_arbace_repr_go_print_A_const_33 *lang.Var

var A_arbace_repr_go_print_A_const_34 *lang.Var

var A_arbace_repr_go_print_A_const_35 *lang.Var

var A_arbace_repr_go_print_A_const_36 *lang.Var

var A_arbace_repr_go_print_A_const_37 *lang.Var

var A_arbace_repr_go_print_A_const_38 *lang.Var

var A_arbace_repr_go_print_A_const_39 *lang.Var

var A_arbace_repr_go_print_A_const_40 *lang.Var

var A_arbace_repr_go_print_A_const_41 *lang.Var

var A_arbace_repr_go_print_A_const_42 *lang.Var

var A_arbace_repr_go_print_A_const_43 *lang.Var

var A_arbace_repr_go_print_A_const_44 *lang.Var

var A_arbace_repr_go_print_A_const_45 *lang.Keyword

var A_arbace_repr_go_print_A_const_46 *lang.Var

var A_arbace_repr_go_print_A_const_47 *lang.Keyword

var A_arbace_repr_go_print_A_const_48 *lang.Var

var A_arbace_repr_go_print_A_const_49 *lang.Keyword

var A_arbace_repr_go_print_A_const_50 *lang.Keyword

var A_arbace_repr_go_print_A_const_51 *lang.Keyword

var A_arbace_repr_go_print_A_const_52 *lang.Keyword

var A_arbace_repr_go_print_A_const_53 *lang.Keyword

var A_arbace_repr_go_print_A_const_54 *lang.Keyword

var A_arbace_repr_go_print_A_const_55 *lang.Keyword

var A_arbace_repr_go_print_A_const_56 *lang.Var

var A_arbace_repr_go_print_A_const_57 *lang.Var

var A_arbace_repr_go_print_A_const_58 *lang.Keyword

var A_arbace_repr_go_print_A_const_59 *lang.Var

var A_arbace_repr_go_print_A_const_60 *lang.Var

var A_arbace_repr_go_print_A_const_61 *lang.Var

var A_arbace_repr_go_print_A_const_62 any

var A_arbace_repr_go_print_A_const_63 *lang.Var

var A_arbace_repr_go_print_A_const_64 *lang.Var

var A_arbace_repr_go_print_A_const_65 *lang.Var

var A_arbace_repr_go_print_A_const_66 *lang.Keyword

var A_arbace_repr_go_print_A_const_67 *lang.Var

var A_arbace_repr_go_print_A_const_68 any

var A_arbace_repr_go_print_A_const_69 any

var A_arbace_repr_go_print_A_const_70 *lang.Var

var A_arbace_repr_go_print_A_const_71 *lang.Var

var A_arbace_repr_go_print_A_const_72 any

var A_arbace_repr_go_print_A_const_73 *lang.Var

var A_arbace_repr_go_print_A_const_74 *lang.Var

var A_arbace_repr_go_print_A_const_75 *lang.Var

var A_arbace_repr_go_print_A_const_76 *lang.Var

var A_arbace_repr_go_print_A_const_77 *lang.Keyword

var A_arbace_repr_go_print_A_const_78 any

var A_arbace_repr_go_print_A_const_79 *lang.Var

var A_arbace_repr_go_print_A_const_80 *lang.Var

var A_arbace_repr_go_print_A_const_81 *lang.Var

var A_arbace_repr_go_print_A_const_82 *lang.Var

var A_arbace_repr_go_print_A_const_83 *lang.Var

var A_arbace_repr_go_print_A_const_84 any

var A_arbace_repr_go_print_A_const_85 *lang.Var

var A_arbace_repr_go_print_A_const_86 *lang.Var

var A_arbace_repr_go_print_A_const_87 *lang.Var

var A_arbace_repr_go_print_A_const_88 *lang.Var

var A_arbace_repr_go_print_A_const_89 *lang.Var

var A_arbace_repr_go_print_A_const_90 *lang.Keyword

var A_arbace_repr_go_print_A_const_91 *lang.Var

var A_arbace_repr_go_print_A_const_92 *lang.Keyword

var A_arbace_repr_go_print_A_const_93 *lang.Keyword

var A_arbace_repr_go_print_A_const_94 *lang.Var

var A_arbace_repr_go_print_A_const_95 *lang.Keyword

var A_arbace_repr_go_print_A_const_96 *lang.Var

var A_arbace_repr_go_print_A_const_97 any

var A_arbace_repr_go_print_A_const_98 *lang.Keyword

var A_arbace_repr_go_print_A_const_99 *lang.Keyword

var A_arbace_repr_go_print_A_const_100 any

var A_arbace_repr_go_print_A_const_101 any

var A_arbace_repr_go_print_A_const_102 *lang.Keyword

var A_arbace_repr_go_print_A_const_103 *lang.Var

var A_arbace_repr_go_print_A_const_104 *lang.Keyword

var A_arbace_repr_go_print_A_const_105 *lang.Var

var A_arbace_repr_go_print_A_const_106 *lang.Var

var A_arbace_repr_go_print_A_const_107 *lang.Keyword

var A_arbace_repr_go_print_A_const_108 *lang.Var

var A_arbace_repr_go_print_A_const_109 *lang.Var

var A_arbace_repr_go_print_A_const_110 *lang.Var

var A_arbace_repr_go_print_A_const_111 *lang.Keyword

var A_arbace_repr_go_print_A_const_112 *lang.Var

var A_arbace_repr_go_print_A_const_113 *lang.Keyword

var A_arbace_repr_go_print_A_const_114 *lang.Var

var A_arbace_repr_go_print_A_const_115 *lang.Var

var A_arbace_repr_go_print_A_const_116 *lang.Var

var A_arbace_repr_go_print_A_const_117 *lang.Var

var A_arbace_repr_go_print_A_const_118 *lang.Keyword

var A_arbace_repr_go_print_A_const_119 *lang.Keyword

var A_arbace_repr_go_print_A_const_120 *lang.Var

var A_arbace_repr_go_print_A_const_121 *lang.Var

var A_arbace_repr_go_print_A_const_122 *lang.Var

var A_arbace_repr_go_print_A_const_123 *lang.Var

var A_arbace_repr_go_print_A_const_124 *lang.Var

var A_arbace_repr_go_print_A_const_125 *lang.Var

var A_arbace_repr_go_print_A_const_126 *lang.Keyword

var A_arbace_repr_go_print_A_const_127 *lang.Var

var A_arbace_repr_go_print_A_const_128 *lang.Var

var A_arbace_repr_go_print_A_const_129 *lang.Var

var A_arbace_repr_go_print_A_const_130 *lang.Var

var A_arbace_repr_go_print_A_const_131 *lang.Var

var A_arbace_repr_go_print_A_const_132 *lang.Var

var A_arbace_repr_go_print_A_const_133 *lang.Var

var A_arbace_repr_go_print_A_const_134 *lang.Var

var A_arbace_repr_go_print_A_const_135 *lang.Var

var A_arbace_repr_go_print_A_const_136 *lang.Var

var A_arbace_repr_go_print_A_const_137 *lang.Var

var A_arbace_repr_go_print_A_const_138 *lang.Var

var A_arbace_repr_go_print_A_const_139 *lang.Keyword

var A_arbace_repr_go_print_A_const_140 *lang.Var

var A_arbace_repr_go_print_A_const_141 *lang.Var

var A_arbace_repr_go_print_A_const_142 *lang.Var

var A_arbace_repr_go_print_A_const_143 *lang.Keyword

var A_arbace_repr_go_print_A_const_144 *lang.Keyword

var A_arbace_repr_go_print_A_const_145 *lang.Keyword

var A_arbace_repr_go_print_A_const_146 *lang.Keyword

var A_arbace_repr_go_print_A_const_147 *lang.Keyword

var A_arbace_repr_go_print_A_const_148 *lang.Keyword

var A_arbace_repr_go_print_A_const_149 *lang.Keyword

var A_arbace_repr_go_print_A_const_150 *lang.Keyword

var A_arbace_repr_go_print_A_const_151 *lang.Keyword

var A_arbace_repr_go_print_A_const_152 *lang.Keyword

var A_arbace_repr_go_print_A_const_153 *lang.Keyword

var A_arbace_repr_go_print_A_const_154 *lang.Var

var A_arbace_repr_go_print_A_const_155 *lang.Var

var A_arbace_repr_go_print_A_const_156 *lang.Keyword

var A_arbace_repr_go_print_A_const_157 *lang.Keyword

var A_arbace_repr_go_print_A_const_158 *lang.Var

var A_arbace_repr_go_print_A_const_159 *lang.Keyword

var A_arbace_repr_go_print_A_const_160 *lang.Keyword

var A_arbace_repr_go_print_A_const_161 *lang.Var

var A_arbace_repr_go_print_A_const_162 *lang.Var

var A_arbace_repr_go_print_A_const_163 *lang.Var

var A_arbace_repr_go_print_A_const_164 *lang.Var

var A_arbace_repr_go_print_A_const_165 *lang.Var

var A_arbace_repr_go_print_A_const_166 *lang.Keyword

var A_arbace_repr_go_print_A_const_167 *lang.Keyword

var A_arbace_repr_go_print_A_const_168 *lang.Keyword

var A_arbace_repr_go_print_A_const_169 *lang.Var

var A_arbace_repr_go_print_A_const_170 *lang.Var

var A_arbace_repr_go_print_A_const_171 *lang.Var

var A_arbace_repr_go_print_A_const_172 *lang.Var

var A_arbace_repr_go_print_A_const_173 *lang.Var

var A_arbace_repr_go_print_A_const_174 *lang.Var

var A_arbace_repr_go_print_A_const_175 *lang.Var

var A_arbace_repr_go_print_A_const_176 *lang.Var

var A_arbace_repr_go_print_A_const_177 *lang.Var

var A_arbace_repr_go_print_A_const_178 *jrt.Class

var A_arbace_repr_go_print_A_const_179 *lang.Var

var A_arbace_repr_go_print_A_const_180 *lang.Var

var A_arbace_repr_go_print_A_const_181 *lang.Keyword

var A_arbace_repr_go_print_A_const_182 *lang.Var

var A_arbace_repr_go_print_A_const_183 *lang.Keyword

var A_arbace_repr_go_print_A_const_184 *lang.Var

var A_arbace_repr_go_print_A_const_185 *lang.Var

var A_arbace_repr_go_print_A_const_186 *lang.Var

var A_arbace_repr_go_print_A_const_187 *lang.Keyword

var A_arbace_repr_go_print_A_const_188 *lang.Keyword

var A_arbace_repr_go_print_A_const_189 *lang.Keyword

var A_arbace_repr_go_print_A_const_190 *lang.Keyword

var A_arbace_repr_go_print_A_const_191 *lang.Keyword

var A_arbace_repr_go_print_A_const_192 *lang.Var

var A_arbace_repr_go_print_A_const_193 *lang.Keyword

var A_arbace_repr_go_print_A_const_194 *lang.Var

var A_arbace_repr_go_print_A_const_195 *lang.Keyword

var A_arbace_repr_go_print_A_const_196 *lang.Keyword

var A_arbace_repr_go_print_A_const_197 *lang.Var

var A_arbace_repr_go_print_A_const_198 any

var A_arbace_repr_go_print_A_const_199 *lang.Var

var A_arbace_repr_go_print_A_const_200 *lang.Var

var A_arbace_repr_go_print_A_const_201 *lang.Var

var A_arbace_repr_go_print_A_const_202 *lang.Keyword

var A_arbace_repr_go_print_A_const_203 *lang.Var

var A_arbace_repr_go_print_A_const_204 *lang.Var

var A_arbace_repr_go_print_A_const_205 *lang.Var

var A_arbace_repr_go_print_A_const_206 *lang.Var

var A_arbace_repr_go_print_A_const_207 *lang.Var

var A_arbace_repr_go_print_A_const_208 *lang.Var

var A_arbace_repr_go_print_A_const_209 *lang.Var

var A_arbace_repr_go_print_A_const_210 *lang.Var

var A_arbace_repr_go_print_A_const_211 *lang.Var

var A_arbace_repr_go_print_A_init jrt.ClassInit

func A_arbace_repr_go_print_A_Init() { if !A_arbace_repr_go_print_A_init.Done() { A_arbace_repr_go_print_A_init.Run(A_arbace_repr_go_print_A_clinit) } }

func A_arbace_repr_go_print_A_clinit() { A_arbace_repr_go_print_A_clinit_p0(); A_arbace_repr_go_print_A_clinit_p1(); A_arbace_repr_go_print_A_clinit_p2(); A_arbace_repr_go_print_A_clinit_p3(); A_arbace_repr_go_print_A_clinit_p4(); A_arbace_repr_go_print_A_clinit_p5(); A_arbace_repr_go_print_A_clinit_p6(); A_arbace_repr_go_print_A_clinit_p7(); A_arbace_repr_go_print_A_clinit_p8(); A_arbace_repr_go_print_A_clinit_p9(); A_arbace_repr_go_print_A_clinit_p10(); A_arbace_repr_go_print_A_clinit_p11(); A_arbace_repr_go_print_A_clinit_p12(); A_arbace_repr_go_print_A_clinit_p13(); A_arbace_repr_go_print_A_clinit_p14(); A_arbace_repr_go_print_A_clinit_p15(); A_arbace_repr_go_print_A_clinit_p16(); A_arbace_repr_go_print_A_clinit_p17() }

func A_arbace_repr_go_print_A_clinit_p0() { A_arbace_repr_go_print_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 279); A_arbace_repr_go_print_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[67]); A_arbace_repr_go_print_A_const_1 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[68]); A_arbace_repr_go_print_A_const_2 = A_arbace_repr_go_print_A_const_pool.A[69]; A_arbace_repr_go_print_A_const_3 = A_arbace_repr_go_print_A_const_pool.A[70]; A_arbace_repr_go_print_A_const_4 = A_arbace_repr_go_print_A_const_pool.A[71]; A_arbace_repr_go_print_A_const_5 = A_arbace_repr_go_print_A_const_pool.A[72]; A_arbace_repr_go_print_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[73]); A_arbace_repr_go_print_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[74]); A_arbace_repr_go_print_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[75]); A_arbace_repr_go_print_A_const_9 = A_arbace_repr_go_print_A_const_pool.A[76]; A_arbace_repr_go_print_A_const_10 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[77]); A_arbace_repr_go_print_A_const_11 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[78]) }

func A_arbace_repr_go_print_A_clinit_p1() { A_arbace_repr_go_print_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[79]); A_arbace_repr_go_print_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[80]); A_arbace_repr_go_print_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[81]); A_arbace_repr_go_print_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[82]); A_arbace_repr_go_print_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[83]); A_arbace_repr_go_print_A_const_17 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[84]); A_arbace_repr_go_print_A_const_18 = A_arbace_repr_go_print_A_const_pool.A[85]; A_arbace_repr_go_print_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[86]); A_arbace_repr_go_print_A_const_20 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[87]); A_arbace_repr_go_print_A_const_21 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[88]); A_arbace_repr_go_print_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[89]); A_arbace_repr_go_print_A_const_23 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[90]) }

func A_arbace_repr_go_print_A_clinit_p2() { A_arbace_repr_go_print_A_const_24 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[91]); A_arbace_repr_go_print_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[92]); A_arbace_repr_go_print_A_const_26 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[93]); A_arbace_repr_go_print_A_const_27 = A_arbace_repr_go_print_A_const_pool.A[94]; A_arbace_repr_go_print_A_const_28 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[95]); A_arbace_repr_go_print_A_const_29 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[96]); A_arbace_repr_go_print_A_const_30 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[97]); A_arbace_repr_go_print_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[98]); A_arbace_repr_go_print_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[99]); A_arbace_repr_go_print_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[100]); A_arbace_repr_go_print_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[101]); A_arbace_repr_go_print_A_const_35 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[102]) }

func A_arbace_repr_go_print_A_clinit_p3() { A_arbace_repr_go_print_A_const_36 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[103]); A_arbace_repr_go_print_A_const_37 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[104]); A_arbace_repr_go_print_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[105]); A_arbace_repr_go_print_A_const_39 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[106]); A_arbace_repr_go_print_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[107]); A_arbace_repr_go_print_A_const_41 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[108]); A_arbace_repr_go_print_A_const_42 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[109]); A_arbace_repr_go_print_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[110]); A_arbace_repr_go_print_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[111]); A_arbace_repr_go_print_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[112]); A_arbace_repr_go_print_A_const_46 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[113]); A_arbace_repr_go_print_A_const_47 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[114]) }

func A_arbace_repr_go_print_A_clinit_p4() { A_arbace_repr_go_print_A_const_48 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[115]); A_arbace_repr_go_print_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[116]); A_arbace_repr_go_print_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[117]); A_arbace_repr_go_print_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[118]); A_arbace_repr_go_print_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[119]); A_arbace_repr_go_print_A_const_53 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[120]); A_arbace_repr_go_print_A_const_54 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[121]); A_arbace_repr_go_print_A_const_55 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[122]); A_arbace_repr_go_print_A_const_56 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[123]); A_arbace_repr_go_print_A_const_57 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[124]); A_arbace_repr_go_print_A_const_58 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[125]); A_arbace_repr_go_print_A_const_59 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[126]) }

func A_arbace_repr_go_print_A_clinit_p5() { A_arbace_repr_go_print_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[127]); A_arbace_repr_go_print_A_const_61 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[128]); A_arbace_repr_go_print_A_const_62 = A_arbace_repr_go_print_A_const_pool.A[129]; A_arbace_repr_go_print_A_const_63 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[130]); A_arbace_repr_go_print_A_const_64 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[131]); A_arbace_repr_go_print_A_const_65 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[132]); A_arbace_repr_go_print_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[133]); A_arbace_repr_go_print_A_const_67 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[134]); A_arbace_repr_go_print_A_const_68 = A_arbace_repr_go_print_A_const_pool.A[135]; A_arbace_repr_go_print_A_const_69 = A_arbace_repr_go_print_A_const_pool.A[136]; A_arbace_repr_go_print_A_const_70 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[137]); A_arbace_repr_go_print_A_const_71 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[138]); A_arbace_repr_go_print_A_const_72 = A_arbace_repr_go_print_A_const_pool.A[139] }

func A_arbace_repr_go_print_A_clinit_p6() { A_arbace_repr_go_print_A_const_73 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[140]); A_arbace_repr_go_print_A_const_74 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[141]); A_arbace_repr_go_print_A_const_75 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[142]); A_arbace_repr_go_print_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[143]); A_arbace_repr_go_print_A_const_77 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[144]); A_arbace_repr_go_print_A_const_78 = A_arbace_repr_go_print_A_const_pool.A[145]; A_arbace_repr_go_print_A_const_79 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[146]); A_arbace_repr_go_print_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[147]); A_arbace_repr_go_print_A_const_81 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[148]); A_arbace_repr_go_print_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[149]); A_arbace_repr_go_print_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[150]); A_arbace_repr_go_print_A_const_84 = A_arbace_repr_go_print_A_const_pool.A[151] }

func A_arbace_repr_go_print_A_clinit_p7() { A_arbace_repr_go_print_A_const_85 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[152]); A_arbace_repr_go_print_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[153]); A_arbace_repr_go_print_A_const_87 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[154]); A_arbace_repr_go_print_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[155]); A_arbace_repr_go_print_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[156]); A_arbace_repr_go_print_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[157]); A_arbace_repr_go_print_A_const_91 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[158]); A_arbace_repr_go_print_A_const_92 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[159]); A_arbace_repr_go_print_A_const_93 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[160]); A_arbace_repr_go_print_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[161]); A_arbace_repr_go_print_A_const_95 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[162]); A_arbace_repr_go_print_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[163]) }

func A_arbace_repr_go_print_A_clinit_p8() { A_arbace_repr_go_print_A_const_97 = A_arbace_repr_go_print_A_const_pool.A[164]; A_arbace_repr_go_print_A_const_98 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[165]); A_arbace_repr_go_print_A_const_99 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[166]); A_arbace_repr_go_print_A_const_100 = A_arbace_repr_go_print_A_const_pool.A[167]; A_arbace_repr_go_print_A_const_101 = A_arbace_repr_go_print_A_const_pool.A[168]; A_arbace_repr_go_print_A_const_102 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[169]); A_arbace_repr_go_print_A_const_103 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[170]); A_arbace_repr_go_print_A_const_104 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[171]); A_arbace_repr_go_print_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[172]); A_arbace_repr_go_print_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[173]); A_arbace_repr_go_print_A_const_107 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[174]); A_arbace_repr_go_print_A_const_108 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[175]) }

func A_arbace_repr_go_print_A_clinit_p9() { A_arbace_repr_go_print_A_const_109 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[176]); A_arbace_repr_go_print_A_const_110 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[177]); A_arbace_repr_go_print_A_const_111 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[178]); A_arbace_repr_go_print_A_const_112 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[179]); A_arbace_repr_go_print_A_const_113 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[180]); A_arbace_repr_go_print_A_const_114 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[181]); A_arbace_repr_go_print_A_const_115 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[182]); A_arbace_repr_go_print_A_const_116 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[183]); A_arbace_repr_go_print_A_const_117 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[184]); A_arbace_repr_go_print_A_const_118 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[185]); A_arbace_repr_go_print_A_const_119 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[186]); A_arbace_repr_go_print_A_const_120 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[187]) }

func A_arbace_repr_go_print_A_clinit_p10() { A_arbace_repr_go_print_A_const_121 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[188]); A_arbace_repr_go_print_A_const_122 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[189]); A_arbace_repr_go_print_A_const_123 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[190]); A_arbace_repr_go_print_A_const_124 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[191]); A_arbace_repr_go_print_A_const_125 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[192]); A_arbace_repr_go_print_A_const_126 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[193]); A_arbace_repr_go_print_A_const_127 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[194]); A_arbace_repr_go_print_A_const_128 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[195]); A_arbace_repr_go_print_A_const_129 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[196]); A_arbace_repr_go_print_A_const_130 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[197]); A_arbace_repr_go_print_A_const_131 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[198]); A_arbace_repr_go_print_A_const_132 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[199]) }

func A_arbace_repr_go_print_A_clinit_p11() { A_arbace_repr_go_print_A_const_133 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[200]); A_arbace_repr_go_print_A_const_134 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[201]); A_arbace_repr_go_print_A_const_135 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[202]); A_arbace_repr_go_print_A_const_136 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[203]); A_arbace_repr_go_print_A_const_137 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[204]); A_arbace_repr_go_print_A_const_138 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[205]); A_arbace_repr_go_print_A_const_139 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[206]); A_arbace_repr_go_print_A_const_140 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[207]); A_arbace_repr_go_print_A_const_141 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[208]); A_arbace_repr_go_print_A_const_142 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[209]); A_arbace_repr_go_print_A_const_143 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[210]); A_arbace_repr_go_print_A_const_144 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[211]) }

func A_arbace_repr_go_print_A_clinit_p12() { A_arbace_repr_go_print_A_const_145 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[212]); A_arbace_repr_go_print_A_const_146 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[213]); A_arbace_repr_go_print_A_const_147 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[214]); A_arbace_repr_go_print_A_const_148 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[215]); A_arbace_repr_go_print_A_const_149 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[216]); A_arbace_repr_go_print_A_const_150 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[217]); A_arbace_repr_go_print_A_const_151 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[218]); A_arbace_repr_go_print_A_const_152 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[219]); A_arbace_repr_go_print_A_const_153 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[220]); A_arbace_repr_go_print_A_const_154 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[221]); A_arbace_repr_go_print_A_const_155 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[222]); A_arbace_repr_go_print_A_const_156 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[223]) }

func A_arbace_repr_go_print_A_clinit_p13() { A_arbace_repr_go_print_A_const_157 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[224]); A_arbace_repr_go_print_A_const_158 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[225]); A_arbace_repr_go_print_A_const_159 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[226]); A_arbace_repr_go_print_A_const_160 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[227]); A_arbace_repr_go_print_A_const_161 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[228]); A_arbace_repr_go_print_A_const_162 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[229]); A_arbace_repr_go_print_A_const_163 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[230]); A_arbace_repr_go_print_A_const_164 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[231]); A_arbace_repr_go_print_A_const_165 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[232]); A_arbace_repr_go_print_A_const_166 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[233]); A_arbace_repr_go_print_A_const_167 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[234]); A_arbace_repr_go_print_A_const_168 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[235]) }

func A_arbace_repr_go_print_A_clinit_p14() { A_arbace_repr_go_print_A_const_169 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[236]); A_arbace_repr_go_print_A_const_170 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[237]); A_arbace_repr_go_print_A_const_171 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[238]); A_arbace_repr_go_print_A_const_172 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[239]); A_arbace_repr_go_print_A_const_173 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[240]); A_arbace_repr_go_print_A_const_174 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[241]); A_arbace_repr_go_print_A_const_175 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[242]); A_arbace_repr_go_print_A_const_176 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[243]); A_arbace_repr_go_print_A_const_177 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[244]); A_arbace_repr_go_print_A_const_178 = jrt.Class_Cast(A_arbace_repr_go_print_A_const_pool.A[245]); A_arbace_repr_go_print_A_const_179 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[246]); A_arbace_repr_go_print_A_const_180 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[247]) }

func A_arbace_repr_go_print_A_clinit_p15() { A_arbace_repr_go_print_A_const_181 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[248]); A_arbace_repr_go_print_A_const_182 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[249]); A_arbace_repr_go_print_A_const_183 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[250]); A_arbace_repr_go_print_A_const_184 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[251]); A_arbace_repr_go_print_A_const_185 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[252]); A_arbace_repr_go_print_A_const_186 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[253]); A_arbace_repr_go_print_A_const_187 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[254]); A_arbace_repr_go_print_A_const_188 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[255]); A_arbace_repr_go_print_A_const_189 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[256]); A_arbace_repr_go_print_A_const_190 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[257]); A_arbace_repr_go_print_A_const_191 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[258]); A_arbace_repr_go_print_A_const_192 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[259]) }

func A_arbace_repr_go_print_A_clinit_p16() { A_arbace_repr_go_print_A_const_193 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[260]); A_arbace_repr_go_print_A_const_194 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[261]); A_arbace_repr_go_print_A_const_195 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[262]); A_arbace_repr_go_print_A_const_196 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[263]); A_arbace_repr_go_print_A_const_197 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[264]); A_arbace_repr_go_print_A_const_198 = A_arbace_repr_go_print_A_const_pool.A[265]; A_arbace_repr_go_print_A_const_199 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[266]); A_arbace_repr_go_print_A_const_200 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[267]); A_arbace_repr_go_print_A_const_201 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[268]); A_arbace_repr_go_print_A_const_202 = lang.Keyword_Cast(A_arbace_repr_go_print_A_const_pool.A[269]); A_arbace_repr_go_print_A_const_203 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[270]); A_arbace_repr_go_print_A_const_204 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[271]) }

func A_arbace_repr_go_print_A_clinit_p17() { A_arbace_repr_go_print_A_const_205 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[272]); A_arbace_repr_go_print_A_const_206 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[273]); A_arbace_repr_go_print_A_const_207 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[274]); A_arbace_repr_go_print_A_const_208 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[275]); A_arbace_repr_go_print_A_const_209 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[276]); A_arbace_repr_go_print_A_const_210 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[277]); A_arbace_repr_go_print_A_const_211 = lang.Var_Cast(A_arbace_repr_go_print_A_const_pool.A[278]) }

func A_arbace_repr_go_print_A_New() *A_arbace_repr_go_print_A { A_arbace_repr_go_print_A_Init(); t := &A_arbace_repr_go_print_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_A) Ctor() {}

func (t *A_arbace_repr_go_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_A_class }

func (t *A_arbace_repr_go_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_A); return ok }

func A_arbace_repr_go_print_A_Cast(x any) *A_arbace_repr_go_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_A_class)) }; return v }



type A_arbace_repr_go_print__main_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print__main_A_fn_class *jrt.Class



type A_arbace_repr_go_print_add_form_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_add_form_A_fn_class *jrt.Class



type A_arbace_repr_go_print_add_form_fn__1344000040_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_print_add_form_fn__1344000040_A_fn_class *jrt.Class



type A_arbace_repr_go_print_build_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_build_A_fn_class *jrt.Class



type A_arbace_repr_go_print_build_env_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_build_env_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_chunk_starts_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_fn__1344000130_A struct{ j2g_header uint64; F_decls any; F_n int32 }

var A_arbace_repr_go_print_chunk_starts_fn__1344000130_A_fn_class *jrt.Class



type A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A struct{ j2g_header uint64; F_decls any }

var A_arbace_repr_go_print_chunk_starts_fn__1344000130_fn__1344000131_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_A struct{ j2g_header uint64; F_state, F_read_fn, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A struct{ j2g_header uint64; F_read_fn, F_file any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A struct{ j2g_header uint64; F_f, F_walk, F_state, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A struct{ j2g_header uint64; F_walk, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A struct{ j2g_header uint64; F_walk, F_state, F_file, F_f, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A struct{ j2g_header uint64; F_walk, F_file, F_root any }

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_fn__1344000048_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_fn__1344000048_A_fn_class *jrt.Class



type A_arbace_repr_go_print_collect_forms_fn__1344000050_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_collect_forms_fn__1344000050_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_copy_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_copy_files_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A struct{ j2g_header uint64; F_src, F_out any }

var A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A struct{ j2g_header uint64; F_iter__1344000215, F_src, F_out, F_s__1344000216 any }

var A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_A_fn_class *jrt.Class



type A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A struct{ j2g_header uint64; F_src, F_b__1344000218, F_out any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_copy_files_iter__1344000215__1344000219_fn__1344000220_fn__1344000221_A_fn_class *jrt.Class



type A_arbace_repr_go_print_decl_pre_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_decl_pre_A_fn_class *jrt.Class



type A_arbace_repr_go_print_decl_sep_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_decl_sep_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_eval1344000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_eval1344000004_A_New() *A_arbace_repr_go_print_eval1344000004_A { t := &A_arbace_repr_go_print_eval1344000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_eval1344000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_eval1344000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_eval1344000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_eval1344000004_A_class }

func (t *A_arbace_repr_go_print_eval1344000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_eval1344000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_eval1344000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_eval1344000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_eval1344000004_A); return ok }

func A_arbace_repr_go_print_eval1344000004_A_Cast(x any) *A_arbace_repr_go_print_eval1344000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_eval1344000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_eval1344000004_A_class)) }; return v }



type A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_eval1344000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_eval1344000008_A_New() *A_arbace_repr_go_print_eval1344000008_A { t := &A_arbace_repr_go_print_eval1344000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_eval1344000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_eval1344000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_eval1344000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_eval1344000008_A_class }

func (t *A_arbace_repr_go_print_eval1344000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_eval1344000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_eval1344000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_eval1344000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_eval1344000008_A); return ok }

func A_arbace_repr_go_print_eval1344000008_A_Cast(x any) *A_arbace_repr_go_print_eval1344000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_eval1344000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_eval1344000008_A_class)) }; return v }



type A_arbace_repr_go_print_eval1344000008_fn__1344000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A struct{ j2g_header uint64; F_s__1344000014, F_iter__1344000013 any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A struct{ j2g_header uint64; F_s__1344000016, F_iter__1344000015 any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_fn_class *jrt.Class



type A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A struct{ j2g_header uint64; F_b__1344000018 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_fn_class *jrt.Class



type A_arbace_repr_go_print_gofmt_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_gofmt_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_import_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_import_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_print_json_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_json_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_new_package_state_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_new_package_state_A_fn_class *jrt.Class



type A_arbace_repr_go_print_next_target_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_next_target_A_fn_class *jrt.Class



type A_arbace_repr_go_print_next_target_fn__1344000121_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_next_target_fn__1344000121_A_fn_class *jrt.Class



type A_arbace_repr_go_print_one_line_func_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_one_line_func_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_decl_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_decl_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_file_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_first_line__1344000155_A struct{ j2g_header uint64; F_decls any }

var A_arbace_repr_go_print_print_file_first_line__1344000155_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_fn__1344000158_A struct{ j2g_header uint64; F_popts, F_first_line, F_lines_QMARK_, F_decls, F_state_opts any }

var A_arbace_repr_go_print_print_file_fn__1344000158_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_file_full_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_file_full_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_forms_fn__1344000192_A struct{ j2g_header uint64; F_pkg, F_opts any }

var A_arbace_repr_go_print_print_forms_fn__1344000192_A_fn_class *jrt.Class



type A_arbace_repr_go_print_print_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_print_package_A_fn_class *jrt.Class



type A_arbace_repr_go_print_read_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_read_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_print_run_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_run_A_fn_class *jrt.Class



type A_arbace_repr_go_print_sha256_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_sha256_A_fn_class *jrt.Class



type A_arbace_repr_go_print_sha256_fn__1344000196_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_sha256_fn__1344000196_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_import_decl_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_import_decl_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_directive_QMARK___1344000091_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_full_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_write_imports_full_A_fn_class *jrt.Class



type A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A struct{ j2g_header uint64; F_open any }

var A_arbace_repr_go_print_write_imports_full_close_BANG___1344000097_A_fn_class *jrt.Class
