//line j2g_classes.ae:1
package aot_arbace_repr_go_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_repr_go_print__main_A_class, Name: "arbace.repr.go.print$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print__main_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_add_form_A_class, Name: "arbace.repr.go.print$add_form", Modifiers: 25, Simple: "add_form", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_add_form_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_add_form_fn__1344000040_A_class, Name: "arbace.repr.go.print$add_form$fn__1344000040", Modifiers: 25, Simple: "fn__1344000040", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_add_form_fn__1344000040_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_add_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_build_A_class, Name: "arbace.repr.go.print$build", Modifiers: 25, Simple: "build", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_build_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_build_env_A_class, Name: "arbace.repr.go.print$build_env", Modifiers: 25, Simple: "build_env", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_build_env_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_chunk_starts_A_class, Name: "arbace.repr.go.print$chunk_starts", Modifiers: 25, Simple: "chunk_starts", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_chunk_starts_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_class, Name: "arbace.repr.go.print$chunk_starts$fn__1344000131", Modifiers: 25, Simple: "fn__1344000131", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_chunk_starts_fn__1344000131_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_chunk_starts_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_class, Name: "arbace.repr.go.print$chunk_starts$fn__1344000131$fn__1344000132", Modifiers: 25, Simple: "fn__1344000132", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_A_class, Name: "arbace.repr.go.print$collect", Modifiers: 25, Simple: "collect", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054", Modifiers: 25, Simple: "walk__1344000054", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054$fn__1344000059", Modifiers: 25, Simple: "fn__1344000059", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_walk__1344000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054$fn__1344000061", Modifiers: 25, Simple: "fn__1344000061", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_walk__1344000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054$fn__1344000063", Modifiers: 25, Simple: "fn__1344000063", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_walk__1344000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054$fn__1344000063$fn__1344000064", Modifiers: 25, Simple: "fn__1344000064", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054$fn__1344000067", Modifiers: 25, Simple: "fn__1344000067", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_walk__1344000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054$fn__1344000069", Modifiers: 25, Simple: "fn__1344000069", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_walk__1344000054_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_class, Name: "arbace.repr.go.print$collect$walk__1344000054$fn__1344000069$fn__1344000070", Modifiers: 25, Simple: "fn__1344000070", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_forms_A_class, Name: "arbace.repr.go.print$collect_forms", Modifiers: 25, Simple: "collect_forms", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_forms_fn__1344000048_A_class, Name: "arbace.repr.go.print$collect_forms$fn__1344000048", Modifiers: 25, Simple: "fn__1344000048", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_fn__1344000048_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_forms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_collect_forms_fn__1344000050_A_class, Name: "arbace.repr.go.print$collect_forms$fn__1344000050", Modifiers: 25, Simple: "fn__1344000050", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_fn__1344000050_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_collect_forms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_copy_file_A_class, Name: "arbace.repr.go.print$copy_file", Modifiers: 25, Simple: "copy_file", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_copy_file_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_copy_files_A_class, Name: "arbace.repr.go.print$copy_files", Modifiers: 25, Simple: "copy_files", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_copy_files_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_class, Name: "arbace.repr.go.print$copy_files$iter__1344000216__1344000220", Modifiers: 25, Simple: "iter__1344000216__1344000220", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_copy_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_class, Name: "arbace.repr.go.print$copy_files$iter__1344000216__1344000220$fn__1344000221", Modifiers: 25, Simple: "fn__1344000221", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_class, Name: "arbace.repr.go.print$copy_files$iter__1344000216__1344000220$fn__1344000221$fn__1344000222", Modifiers: 25, Simple: "fn__1344000222", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_decl_pre_A_class, Name: "arbace.repr.go.print$decl_pre", Modifiers: 25, Simple: "decl_pre", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_decl_pre_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_decl_sep_BANG__A_class, Name: "arbace.repr.go.print$decl_sep_BANG_", Modifiers: 25, Simple: "decl_sep_BANG_", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_decl_sep_BANG__A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_class, Name: "arbace.repr.go.print$eval1344000004$loading__1927001464__auto____1344000005", Modifiers: 25, Simple: "loading__1927001464__auto____1344000005", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_eval1344000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_class, Name: "arbace.repr.go.print$eval1344000008$fn__1344000009", Modifiers: 25, Simple: "fn__1344000009", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_eval1344000008_fn__1344000009_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_eval1344000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_go_ns_aliases_A_class, Name: "arbace.repr.go.print$go_ns_aliases", Modifiers: 25, Simple: "go_ns_aliases", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_go_ns_aliases_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_class, Name: "arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019", Modifiers: 25, Simple: "iter__1344000013__1344000019", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_go_ns_aliases_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_class, Name: "arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020", Modifiers: 25, Simple: "fn__1344000020", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_class, Name: "arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020$iter__1344000015__1344000021", Modifiers: 25, Simple: "iter__1344000015__1344000021", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_class, Name: "arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020$iter__1344000015__1344000021$fn__1344000022", Modifiers: 25, Simple: "fn__1344000022", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_class, Name: "arbace.repr.go.print$go_ns_aliases$iter__1344000013__1344000019$fn__1344000020$iter__1344000015__1344000021$fn__1344000022$fn__1344000023", Modifiers: 25, Simple: "fn__1344000023", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_gofmt_file_A_class, Name: "arbace.repr.go.print$gofmt_file", Modifiers: 25, Simple: "gofmt_file", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_gofmt_file_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_import_spec_A_class, Name: "arbace.repr.go.print$import_spec", Modifiers: 25, Simple: "import_spec", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_import_spec_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_json_string_A_class, Name: "arbace.repr.go.print$json_string", Modifiers: 25, Simple: "json_string", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_json_string_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_name_text_A_class, Name: "arbace.repr.go.print$name_text", Modifiers: 25, Simple: "name_text", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_new_package_state_A_class, Name: "arbace.repr.go.print$new_package_state", Modifiers: 25, Simple: "new_package_state", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_new_package_state_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_next_target_A_class, Name: "arbace.repr.go.print$next_target", Modifiers: 25, Simple: "next_target", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_next_target_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_next_target_fn__1344000122_A_class, Name: "arbace.repr.go.print$next_target$fn__1344000122", Modifiers: 25, Simple: "fn__1344000122", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_next_target_fn__1344000122_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_next_target_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_one_line_func_QMARK__A_class, Name: "arbace.repr.go.print$one_line_func_QMARK_", Modifiers: 25, Simple: "one_line_func_QMARK_", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_one_line_func_QMARK__A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_decl_BANG__A_class, Name: "arbace.repr.go.print$print_decl_BANG_", Modifiers: 25, Simple: "print_decl_BANG_", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_decl_BANG__A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_file_A_class, Name: "arbace.repr.go.print$print_file", Modifiers: 25, Simple: "print_file", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_file_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_file_first_line__1344000156_A_class, Name: "arbace.repr.go.print$print_file$first_line__1344000156", Modifiers: 25, Simple: "first_line__1344000156", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_file_first_line__1344000156_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_print_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_file_fn__1344000159_A_class, Name: "arbace.repr.go.print$print_file$fn__1344000159", Modifiers: 25, Simple: "fn__1344000159", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_file_fn__1344000159_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_print_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_file_full_A_class, Name: "arbace.repr.go.print$print_file_full", Modifiers: 25, Simple: "print_file_full", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_file_full_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_forms_A_class, Name: "arbace.repr.go.print$print_forms", Modifiers: 25, Simple: "print_forms", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_forms_fn__1344000193_A_class, Name: "arbace.repr.go.print$print_forms$fn__1344000193", Modifiers: 25, Simple: "fn__1344000193", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_fn__1344000193_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_print_forms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_print_package_A_class, Name: "arbace.repr.go.print$print_package", Modifiers: 25, Simple: "print_package", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_print_package_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_read_forms_A_class, Name: "arbace.repr.go.print$read_forms", Modifiers: 25, Simple: "read_forms", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_run_A_class, Name: "arbace.repr.go.print$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_run_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_sha256_A_class, Name: "arbace.repr.go.print$sha256", Modifiers: 25, Simple: "sha256", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_sha256_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_sha256_fn__1344000197_A_class, Name: "arbace.repr.go.print$sha256$fn__1344000197", Modifiers: 25, Simple: "fn__1344000197", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_sha256_fn__1344000197_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_sha256_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_write_import_decl_A_class, Name: "arbace.repr.go.print$write_import_decl", Modifiers: 25, Simple: "write_import_decl", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_write_import_decl_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_write_imports_A_class, Name: "arbace.repr.go.print$write_imports", Modifiers: 25, Simple: "write_imports", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_write_imports_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_class, Name: "arbace.repr.go.print$write_imports$directive_QMARK___1344000092", Modifiers: 25, Simple: "directive_QMARK___1344000092", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_write_imports_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_write_imports_full_A_class, Name: "arbace.repr.go.print$write_imports_full", Modifiers: 25, Simple: "write_imports_full", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_write_imports_full_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_class, Name: "arbace.repr.go.print$write_imports_full$close_BANG___1344000098", Modifiers: 25, Simple: "close_BANG___1344000098", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A", Source: "print.ae", Declaring: &A_arbace_repr_go_print_write_imports_full_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_repr_go_print_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_A_New()}; return nil }

var A_arbace_repr_go_print_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_A_new}

var A_arbace_repr_go_print_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_A"})

func init() { i := A_arbace_repr_go_print_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_A_InstanceOf; i.Init = A_arbace_repr_go_print_A_Init; i.Table = A_arbace_repr_go_print_A_members }

var A_arbace_repr_go_print__main_A_class *jrt.Class

var A_arbace_repr_go_print_add_form_A_class *jrt.Class

var A_arbace_repr_go_print_add_form_fn__1344000040_A_class *jrt.Class

var A_arbace_repr_go_print_build_A_class *jrt.Class

var A_arbace_repr_go_print_build_env_A_class *jrt.Class

var A_arbace_repr_go_print_chunk_starts_A_class *jrt.Class

var A_arbace_repr_go_print_chunk_starts_fn__1344000131_A_class *jrt.Class

var A_arbace_repr_go_print_chunk_starts_fn__1344000131_fn__1344000132_A_class *jrt.Class

var A_arbace_repr_go_print_collect_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000059_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000061_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000063_fn__1344000064_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000067_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_A_class *jrt.Class

var A_arbace_repr_go_print_collect_walk__1344000054_fn__1344000069_fn__1344000070_A_class *jrt.Class

var A_arbace_repr_go_print_collect_forms_A_class *jrt.Class

var A_arbace_repr_go_print_collect_forms_fn__1344000048_A_class *jrt.Class

var A_arbace_repr_go_print_collect_forms_fn__1344000050_A_class *jrt.Class

var A_arbace_repr_go_print_copy_file_A_class *jrt.Class

var A_arbace_repr_go_print_copy_files_A_class *jrt.Class

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_A_class *jrt.Class

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_A_class *jrt.Class

var A_arbace_repr_go_print_copy_files_iter__1344000216__1344000220_fn__1344000221_fn__1344000222_A_class *jrt.Class

var A_arbace_repr_go_print_decl_pre_A_class *jrt.Class

var A_arbace_repr_go_print_decl_sep_BANG__A_class *jrt.Class

func A_arbace_repr_go_print_eval1344000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_eval1344000004_A_New()}; return nil }

var A_arbace_repr_go_print_eval1344000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_eval1344000004_A_new}

var A_arbace_repr_go_print_eval1344000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print$eval1344000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_A_class, Simple: "eval1344000004", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_eval1344000004_A"})

func init() { i := A_arbace_repr_go_print_eval1344000004_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_eval1344000004_A_InstanceOf; i.Table = A_arbace_repr_go_print_eval1344000004_A_members }

var A_arbace_repr_go_print_eval1344000004_loading__1927001464__auto____1344000005_A_class *jrt.Class

func A_arbace_repr_go_print_eval1344000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print_eval1344000008_A_New()}; return nil }

var A_arbace_repr_go_print_eval1344000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_print_eval1344000008_A_new}

var A_arbace_repr_go_print_eval1344000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print$eval1344000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_print_A_class, Simple: "eval1344000008", Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print_eval1344000008_A"})

func init() { i := A_arbace_repr_go_print_eval1344000008_A_class.Info(); i.IsInstance = A_arbace_repr_go_print_eval1344000008_A_InstanceOf; i.Table = A_arbace_repr_go_print_eval1344000008_A_members }

var A_arbace_repr_go_print_eval1344000008_fn__1344000009_A_class *jrt.Class

var A_arbace_repr_go_print_go_ns_aliases_A_class *jrt.Class

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_A_class *jrt.Class

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_A_class *jrt.Class

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_A_class *jrt.Class

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_A_class *jrt.Class

var A_arbace_repr_go_print_go_ns_aliases_iter__1344000013__1344000019_fn__1344000020_iter__1344000015__1344000021_fn__1344000022_fn__1344000023_A_class *jrt.Class

var A_arbace_repr_go_print_gofmt_file_A_class *jrt.Class

var A_arbace_repr_go_print_import_spec_A_class *jrt.Class

var A_arbace_repr_go_print_json_string_A_class *jrt.Class

var A_arbace_repr_go_print_name_text_A_class *jrt.Class

var A_arbace_repr_go_print_new_package_state_A_class *jrt.Class

var A_arbace_repr_go_print_next_target_A_class *jrt.Class

var A_arbace_repr_go_print_next_target_fn__1344000122_A_class *jrt.Class

var A_arbace_repr_go_print_one_line_func_QMARK__A_class *jrt.Class

var A_arbace_repr_go_print_print_decl_BANG__A_class *jrt.Class

var A_arbace_repr_go_print_print_file_A_class *jrt.Class

var A_arbace_repr_go_print_print_file_first_line__1344000156_A_class *jrt.Class

var A_arbace_repr_go_print_print_file_fn__1344000159_A_class *jrt.Class

var A_arbace_repr_go_print_print_file_full_A_class *jrt.Class

var A_arbace_repr_go_print_print_forms_A_class *jrt.Class

var A_arbace_repr_go_print_print_forms_fn__1344000193_A_class *jrt.Class

var A_arbace_repr_go_print_print_package_A_class *jrt.Class

var A_arbace_repr_go_print_read_forms_A_class *jrt.Class

var A_arbace_repr_go_print_run_A_class *jrt.Class

var A_arbace_repr_go_print_sha256_A_class *jrt.Class

var A_arbace_repr_go_print_sha256_fn__1344000197_A_class *jrt.Class

var A_arbace_repr_go_print_write_import_decl_A_class *jrt.Class

var A_arbace_repr_go_print_write_imports_A_class *jrt.Class

var A_arbace_repr_go_print_write_imports_directive_QMARK___1344000092_A_class *jrt.Class

var A_arbace_repr_go_print_write_imports_full_A_class *jrt.Class

var A_arbace_repr_go_print_write_imports_full_close_BANG___1344000098_A_class *jrt.Class

func A_arbace_repr_go_print__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repr_go_print__init_A_Load__O()}; return nil }

func A_arbace_repr_go_print__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_print__init_A_New()}; return nil }

var A_arbace_repr_go_print__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repr_go_print__init_A_invoke, New: A_arbace_repr_go_print__init_A_new}

var A_arbace_repr_go_print__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.print__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_print.A_arbace_repr_go_print__init_A", Source: "print.ae"})

func init() { i := A_arbace_repr_go_print__init_A_class.Info(); i.IsInstance = A_arbace_repr_go_print__init_A_InstanceOf; i.Init = A_arbace_repr_go_print__init_A_Init; i.Table = A_arbace_repr_go_print__init_A_members }
