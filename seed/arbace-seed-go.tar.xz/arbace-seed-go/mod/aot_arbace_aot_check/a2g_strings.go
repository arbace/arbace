//line a2g_strings.ae:1
package aot_arbace_aot_check

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("io")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_7 *jrt.String = jrt.Intern("env")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_9 *jrt.String = jrt.Intern("a")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.parse")

var Lit_11 *jrt.String = jrt.Intern("p")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.interp")

var Lit_13 *jrt.String = jrt.Intern("interp")

var Lit_14 *jrt.String = jrt.Intern("commute")

var Lit_15 *jrt.String = jrt.Intern("deref")

var Lit_16 *jrt.String = jrt.Intern("conj")

var Lit_17 *jrt.String = jrt.Intern("arbace.aot.check")

var Lit_18 *jrt.String = jrt.Intern("doc")

var Lit_19 *jrt.String = jrt.Intern("A quick check of the back end's output (standalone S6), without a2g: the class forms of a\n  compiled tree analyzed in the running program, as one compilation, by the class forms'\n  analysis the REPL uses (arbace.classes.interp/analyze-forms), against the program's classes\n  by reflection. a2g's analysis is the same code against the class forms; this finds most of\n  what a2g's load would report, in seconds.")

var Lit_20 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_21 *jrt.String = jrt.Intern("reader")

var Lit_22 *jrt.String = jrt.Intern("doall")

var Lit_23 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_24 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_25 *jrt.String = jrt.Intern("hash-map")

var Lit_26 *jrt.String = jrt.Intern("*read-eval*")

var Lit_27 *jrt.String = jrt.Intern("take-while")

var Lit_28 *jrt.String = jrt.Intern("not=")

var Lit_29 *jrt.String = jrt.Intern("eof")

var Lit_30 *jrt.String = jrt.Intern("repeatedly")

var Lit_31 *jrt.String = jrt.Intern("read")

var Lit_32 *jrt.String = jrt.Intern("sort")

var Lit_33 *jrt.String = jrt.Intern("seq")

var Lit_34 *jrt.String = jrt.Intern("first")

var Lit_35 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_36 *jrt.String = jrt.Intern("chunk-first")

var Lit_37 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_38 *jrt.String = jrt.Intern("seq?")

var Lit_39 *jrt.String = jrt.Intern("defclass")

var Lit_40 *jrt.String = jrt.Intern("chunk-append")

var Lit_41 *jrt.String = jrt.Intern("rest")

var Lit_42 *jrt.String = jrt.Intern("chunk-cons")

var Lit_43 *jrt.String = jrt.Intern("cons")

var Lit_44 *jrt.String = jrt.Intern("chunk")

var Lit_45 *jrt.String = jrt.Intern("chunk-rest")

var Lit_46 *jrt.String = jrt.Intern("concat")

var Lit_47 *jrt.String = jrt.Intern("read-all")

var Lit_48 *jrt.String = jrt.Intern("create-ns")

var Lit_49 *jrt.String = jrt.Intern("with-redefs-fn")

var Lit_50 *jrt.String = jrt.Intern("filter")

var Lit_51 *jrt.String = jrt.Intern("str")

var Lit_52 *jrt.String = jrt.Intern("file-seq")

var Lit_53 *jrt.String = jrt.Intern("file")

var Lit_54 *jrt.String = jrt.Intern("arbace")

var Lit_55 *jrt.String = jrt.Intern("*ns*")

var Lit_56 *jrt.String = jrt.Intern("*compile-set*")

var Lit_57 *jrt.String = jrt.Intern("atom")

var Lit_58 *jrt.String = jrt.Intern("*unit*")

var Lit_59 *jrt.String = jrt.Intern("order")

var Lit_60 *jrt.String = jrt.Intern("counters")

var Lit_61 *jrt.String = jrt.Intern("switch-maps")

var Lit_62 *jrt.String = jrt.Intern("switch-holders")

var Lit_63 *jrt.String = jrt.Intern("source-tried")

var Lit_64 *jrt.String = jrt.Intern("assert-holders")

var Lit_65 *jrt.String = jrt.Intern("holder-first")

var Lit_66 *jrt.String = jrt.Intern("accessorize")

var Lit_67 *jrt.String = jrt.Intern("vec")

var Lit_68 *jrt.String = jrt.Intern("swap!")

var Lit_69 *jrt.String = jrt.Intern("println")

var Lit_70 *jrt.String = jrt.Intern("declare-class!")

var Lit_71 *jrt.String = jrt.Intern("nesting")

var Lit_72 *jrt.String = jrt.Intern("top")

var Lit_73 *jrt.String = jrt.Intern("parse-class")

var Lit_74 *jrt.String = jrt.Intern("ns")

var Lit_75 *jrt.String = jrt.Intern("reset!")

var Lit_76 *jrt.String = jrt.Intern("not")

var Lit_77 *jrt.String = jrt.Intern("headers-done")

var Lit_78 *jrt.String = jrt.Intern("decl")

var Lit_79 *jrt.String = jrt.Intern("resolve-header!")

var Lit_80 *jrt.String = jrt.Intern("next")

var Lit_81 *jrt.String = jrt.Intern("resolve-members!")

var Lit_82 *jrt.String = jrt.Intern("supertypes-first")

var Lit_83 *jrt.String = jrt.Intern("add-bridges!")

var Lit_84 *jrt.String = jrt.Intern("mark-enum-abstract!")

var Lit_85 *jrt.String = jrt.Intern("analyze-class!")

var Lit_86 *jrt.String = jrt.Intern("arbace.aot.check$check")

var Lit_87 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000019")

var Lit_88 *jrt.String = jrt.Intern(".ae")

var Lit_89 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000037")

var Lit_90 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000039")

var Lit_91 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000041")

var Lit_92 *jrt.String = jrt.Intern("parse and declare")

var Lit_93 *jrt.String = jrt.Intern("header")

var Lit_94 *jrt.String = jrt.Intern("headers")

var Lit_95 *jrt.String = jrt.Intern("members")

var Lit_96 *jrt.String = jrt.Intern("bridges")

var Lit_97 *jrt.String = jrt.Intern("enum")

var Lit_98 *jrt.String = jrt.Intern("analysis")

var Lit_99 *jrt.String = jrt.Intern("aot check:")

var Lit_100 *jrt.String = jrt.Intern("top-level classes,")

var Lit_101 *jrt.String = jrt.Intern("classes analyzed,")

var Lit_102 *jrt.String = jrt.Intern("failed")

var Lit_103 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046")

var Lit_104 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046$fn__1217000047")

var Lit_105 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046$fn__1217000047$fn__1217000048")

var Lit_106 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000041$lap__1217000054")

var Lit_107 *jrt.String = jrt.Intern("s")

var Lit_108 *jrt.String = jrt.Intern("arbace.aot.check$check$fn__1217000041$try_BANG___1217000052")

var Lit_109 *jrt.String = jrt.Intern("aot check: FAILED")

var Lit_110 *jrt.String = jrt.Intern("arbace.aot.check$check$iter__1217000021__1217000027")

var Lit_111 *jrt.String = jrt.Intern("arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028")

var Lit_112 *jrt.String = jrt.Intern("arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029")

var Lit_113 *jrt.String = jrt.Intern("arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029$fn__1217000030")

var Lit_114 *jrt.String = jrt.Intern("arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029$fn__1217000030$fn__1217000031")

var Lit_115 *jrt.String = jrt.Intern("arbace.aot.check$eval1217000004$loading__1927001464__auto____1217000005")

var Lit_116 *jrt.String = jrt.Intern("arbace.aot.check$eval1217000008$fn__1217000009")

var Lit_117 *jrt.String = jrt.Intern("arbace.aot.check$read_all")

var Lit_118 *jrt.String = jrt.Intern("arbace.aot.check$read_all$fn__1217000013")

var Lit_119 *jrt.String = jrt.Intern("arbace.aot.check$read_all$fn__1217000015")

var Lit_120 *jrt.String = jrt.Intern("in-ns")

var Lit_121 *jrt.String = jrt.Intern("private")

var Lit_122 *jrt.String = jrt.Intern("arglists")

var Lit_123 *jrt.String = jrt.Intern("f")

var Lit_124 *jrt.String = jrt.Intern("line")

var Lit_125 *jrt.String = jrt.Intern("column")

var Lit_126 *jrt.String = jrt.Intern("arbace/aot/check.ae")

var Lit_127 *jrt.String = jrt.Intern("check")

var Lit_128 *jrt.String = jrt.Intern("dir")

var Lit_129 *jrt.String = jrt.Intern("Analyzes the class forms of every file under dir; prints and returns the failures.")
