//line aot_arbace_aot_check.ae:1
package aot_arbace_aot_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_New() *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A { A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_Init(); t := &A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_aot_check_A_Init(); tmp4 = A_arbace_aot_check_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_aot_check_A_Init(); tmp6 = A_arbace_aot_check_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_aot_check_A_Init(); tmp9 = A_arbace_aot_check_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_aot_check_A_Init(); tmp11 = A_arbace_aot_check_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_aot_check_A_Init(); tmp13 = A_arbace_aot_check_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_aot_check_A_Init(); tmp15 = A_arbace_aot_check_A_const_6; var tmp16 any = tmp15; var tmp17 any; A_arbace_aot_check_A_Init(); tmp17 = A_arbace_aot_check_A_const_7; tmp3 = tmp8.Invoke_O_O_O_O_O__O(tmp10, tmp12, tmp14, tmp16, tmp17) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp18 != nil { panic(tmp18) }; return tmp3 }
//line :1:1
func A_arbace_aot_check_eval1217000008_fn__1217000009_A_New() *A_arbace_aot_check_eval1217000008_fn__1217000009_A { A_arbace_aot_check_eval1217000008_fn__1217000009_A_Init(); t := &A_arbace_aot_check_eval1217000008_fn__1217000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_8; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_9; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_aot_check_A_Init(); tmp5 = A_arbace_aot_check_A_const_12; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_10; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_aot_check_A_Init(); tmp9 = A_arbace_aot_check_A_const_11; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }











func A_arbace_aot_check_read_all_A_New() *A_arbace_aot_check_read_all_A { A_arbace_aot_check_read_all_A_Init(); t := &A_arbace_aot_check_read_all_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_aot_check_read_all_A) Ctor() {}
//line :13:1
func (t *A_arbace_aot_check_read_all_A) Invoke_O_O__O(self, f__0 any) any { var r__2 any; var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_13; r__2 = jrt.PushbackReader_New_Reader(jrt.Reader_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0))); var tmp2 any; tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp3 *lang.Var; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_16; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_aot_check_A_Init(); tmp5 = A_arbace_aot_check_A_const_17; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_18; var tmp8 any = tmp7.Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp8, tmp9.Ref())); tmp21 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var tmp10 *lang.Var; A_arbace_aot_check_A_Init(); tmp10 = A_arbace_aot_check_A_const_14; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_aot_check_A_Init(); tmp12 = A_arbace_aot_check_A_const_19; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_aot_check_read_all_fn__1217000013_A_New(); var tmp15 *jrt.Class; A_arbace_aot_check_read_all_fn__1217000013_A_Init(); tmp15 = A_arbace_aot_check_read_all_fn__1217000013_A_fn_class; var tmp16 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp17 *lang.Var; A_arbace_aot_check_A_Init(); tmp17 = A_arbace_aot_check_A_const_22; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_aot_check_read_all_fn__1217000015_A_New_O(r__2); var tmp20 *jrt.Class; A_arbace_aot_check_read_all_fn__1217000015_A_Init(); tmp20 = A_arbace_aot_check_read_all_fn__1217000015_A_fn_class; tmp2 = tmp11.Invoke_O__O(tmp13.Invoke_O_O__O(tmp16, tmp18.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil)))) }
//line :15:1
		return nil }(); var tmp22 *lang.Var; A_arbace_aot_check_A_Init(); tmp22 = A_arbace_aot_check_A_const_15; lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke__O()
//line :13:1
		if tmp21 != nil { panic(tmp21) } }; return nil }();
	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :13:1*/ tmp23 != nil { panic(tmp23) }; return tmp2 }


func A_arbace_aot_check_read_all_fn__1217000013_A_New() *A_arbace_aot_check_read_all_fn__1217000013_A { A_arbace_aot_check_read_all_fn__1217000013_A_Init(); t := &A_arbace_aot_check_read_all_fn__1217000013_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_aot_check_read_all_fn__1217000013_A) Ctor() {}
//line :16:1
func (t *A_arbace_aot_check_read_all_fn__1217000013_A) Invoke_O_O__O(self, p1__1217000012_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_21; return tmp2.Invoke_O_O__O(tmp3.Ref(), p1__1217000012_SHARP___1) }
//line :16:1
func A_arbace_aot_check_read_all_fn__1217000015_A_New_O(p0 any) *A_arbace_aot_check_read_all_fn__1217000015_A { A_arbace_aot_check_read_all_fn__1217000015_A_Init(); t := &A_arbace_aot_check_read_all_fn__1217000015_A{}; t.Ctor_O(p0); return t }
//line :16:1
func (t *A_arbace_aot_check_read_all_fn__1217000015_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :16:1
func (t *A_arbace_aot_check_read_all_fn__1217000015_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_24; return tmp2.Invoke_O_O__O(tmp3, t.F_r) }

func A_arbace_aot_check_check_A_New() *A_arbace_aot_check_check_A { A_arbace_aot_check_check_A_Init(); t := &A_arbace_aot_check_check_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_aot_check_check_A) Ctor() {}
//line :18:1
func (t *A_arbace_aot_check_check_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var tmp1 *lang.Var;


	A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_25; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_43; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_aot_check_check_fn__1217000019_A_New(); var tmp6 *jrt.Class; A_arbace_aot_check_check_fn__1217000019_A_Init(); tmp6 = A_arbace_aot_check_check_fn__1217000019_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.Var; A_arbace_aot_check_A_Init(); tmp8 = A_arbace_aot_check_A_const_45; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_aot_check_A_Init(); tmp10 = A_arbace_aot_check_A_const_46; files__2 = tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp7, tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(dir__0, Lit_54)))); var forms__3 any; var iter__1927001039__auto____3 any; var tmp11 any = /*line :18:1*/A_arbace_aot_check_check_iter__1217000021__1217000027_A_New(); var tmp12 *jrt.Class;



	A_arbace_aot_check_check_iter__1217000021__1217000027_A_Init(); tmp12 = A_arbace_aot_check_check_iter__1217000021__1217000027_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); forms__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); var ns__4 any; var tmp13 /*line :18:1*/*lang.Var;







	A_arbace_aot_check_A_Init(); tmp13 = A_arbace_aot_check_A_const_41; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_aot_check_A_Init(); tmp15 = A_arbace_aot_check_A_const_47; ns__4 = tmp14.Invoke_O__O(tmp15); var tmp16 /*line :27:1*/*lang.Var; A_arbace_aot_check_A_Init(); tmp16 = A_arbace_aot_check_A_const_16; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_aot_check_A_Init(); tmp18 = A_arbace_aot_check_A_const_17; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_aot_check_A_Init(); tmp20 = A_arbace_aot_check_A_const_49; tmp17.Invoke_O__O(tmp19.Invoke_O_O__O(tmp20.Ref(), ns__4)); var tmp21 any = A_arbace_aot_check_check_fn__1217000037_A_New(); var tmp22 *jrt.Class; A_arbace_aot_check_check_fn__1217000037_A_Init(); tmp22 = A_arbace_aot_check_check_fn__1217000037_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O(); var tmp23 /*line :29:1*/*lang.Var; A_arbace_aot_check_A_Init(); tmp23 = A_arbace_aot_check_A_const_16; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_aot_check_A_Init(); tmp25 = A_arbace_aot_check_A_const_17; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_aot_check_A_Init(); tmp27 = A_arbace_aot_check_A_const_50; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Var; A_arbace_aot_check_A_Init(); tmp29 = A_arbace_aot_check_A_const_51; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp31 = lang.PersistentArrayMap_EMPTY; var tmp32 any = tmp30.Invoke_O__O(tmp31.Ref()); var tmp33 *lang.Var; A_arbace_aot_check_A_Init(); tmp33 = A_arbace_aot_check_A_const_52; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp35 = A_arbace_aot_check_A_const_53; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Var; A_arbace_aot_check_A_Init(); tmp37 = A_arbace_aot_check_A_const_51; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.PersistentVector; lang.PersistentVector_Init(); tmp39 = lang.PersistentVector_EMPTY; var tmp40 any = tmp38.Invoke_O__O(tmp39.Ref()); var tmp41 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp41 = A_arbace_aot_check_A_const_54; var tmp42 any = tmp41.Ref(); var tmp43 *lang.Var; A_arbace_aot_check_A_Init(); tmp43 = A_arbace_aot_check_A_const_51; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp45 = lang.PersistentArrayMap_EMPTY; var tmp46 any = tmp44.Invoke_O__O(tmp45.Ref()); var tmp47 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp47 = A_arbace_aot_check_A_const_55; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Var; A_arbace_aot_check_A_Init(); tmp49 = A_arbace_aot_check_A_const_51; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp51 = lang.PersistentArrayMap_EMPTY; var tmp52 any = tmp50.Invoke_O__O(tmp51.Ref()); var tmp53 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp53 = A_arbace_aot_check_A_const_56; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Var; A_arbace_aot_check_A_Init(); tmp55 = A_arbace_aot_check_A_const_51; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp57 = lang.PersistentArrayMap_EMPTY; var tmp58 any = tmp56.Invoke_O__O(tmp57.Ref()); var tmp59 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp59 = A_arbace_aot_check_A_const_57; var tmp60 any = tmp59.Ref(); var tmp61 *lang.Var; A_arbace_aot_check_A_Init(); tmp61 = A_arbace_aot_check_A_const_51; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp63 = lang.PersistentHashSet_EMPTY; var tmp64 any = tmp62.Invoke_O__O(tmp63.Ref()); var tmp65 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp65 = A_arbace_aot_check_A_const_58; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Var; A_arbace_aot_check_A_Init(); tmp67 = A_arbace_aot_check_A_const_51; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp69 = lang.PersistentArrayMap_EMPTY; var tmp70 any = tmp68.Invoke_O__O(tmp69.Ref()); var tmp71 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp71 = A_arbace_aot_check_A_const_59; var tmp72 any = tmp71.Ref(); var tmp73 *lang.Var; A_arbace_aot_check_A_Init(); tmp73 = A_arbace_aot_check_A_const_51; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp75 = lang.PersistentArrayMap_EMPTY; tmp24.Invoke_O__O(tmp26.Invoke_O_O_O_O__O(tmp28, tmp32, tmp34, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp36, tmp40, tmp42, tmp46, tmp48, tmp52, tmp54, tmp58, tmp60, tmp64, tmp66, tmp70, tmp72, tmp74.Invoke_O__O(tmp75.Ref()))))); var tmp76 any; tmp86 := /*line :18:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)














		{ var tmp77 *lang.Var; A_arbace_aot_check_A_Init(); tmp77 = A_arbace_aot_check_A_const_42; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 *lang.Var; A_arbace_aot_check_A_Init(); tmp79 = A_arbace_aot_check_A_const_60; var tmp80 any = tmp79.Ref(); var tmp81 any = A_arbace_aot_check_check_fn__1217000039_A_New(); var tmp82 *jrt.Class; A_arbace_aot_check_check_fn__1217000039_A_Init(); tmp82 = A_arbace_aot_check_check_fn__1217000039_A_fn_class; var tmp83 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp80, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp81, tmp82, nil))); var tmp84 any = A_arbace_aot_check_check_fn__1217000041_A_New_O_O(ns__4, forms__3); var tmp85 *jrt.Class; A_arbace_aot_check_check_fn__1217000041_A_Init(); tmp85 = A_arbace_aot_check_check_fn__1217000041_A_fn_class; tmp76 = tmp78.Invoke_O_O__O(tmp83, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp84, tmp85, nil)) }
//line :18:1
		return nil }(); var tmp87 *lang.Var;










	A_arbace_aot_check_A_Init(); tmp87 = A_arbace_aot_check_A_const_15; lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()).Invoke__O(); if /*line :18:1*/ tmp86 != nil { panic(tmp86) }; return tmp76 }


func A_arbace_aot_check_check_fn__1217000019_A_New() *A_arbace_aot_check_check_fn__1217000019_A { A_arbace_aot_check_check_fn__1217000019_A_Init(); t := &A_arbace_aot_check_check_fn__1217000019_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_aot_check_check_fn__1217000019_A) Ctor() {}
//line :21:1
func (t *A_arbace_aot_check_check_fn__1217000019_A) Invoke_O_O__O(self, p1__1217000018_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_44; return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__1217000018_SHARP___1))).EndsWith_String__Z(Lit_88)).Ref() }
func A_arbace_aot_check_check_iter__1217000021__1217000027_A_New() *A_arbace_aot_check_check_iter__1217000021__1217000027_A { A_arbace_aot_check_check_iter__1217000021__1217000027_A_Init(); t := &A_arbace_aot_check_check_iter__1217000021__1217000027_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) Ctor() {}
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) Invoke_O_O__O(self, s__1217000022__1 any) any { var tmp1 any = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_New_O_O(s__1217000022__1, self); var tmp2 *jrt.Class; A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_Init(); tmp2 = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_New_O_O(p0, p1 any) *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_Init(); t := &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) Ctor_O_O(c__s__1217000022, c__iter__1217000021 any) { t.F_s__1217000022 = c__s__1217000022; t.F_iter__1217000021 = c__iter__1217000021 }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) Invoke_O__O(self any) any { { var s__1217000022__1 any; var t_ any = t.F_s__1217000022; t.F_s__1217000022 = nil; s__1217000022__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1217000022__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var tmp2 *lang.Var; A_arbace_aot_check_A_Init(); tmp2 = A_arbace_aot_check_A_const_27; f__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp3 any = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_New(); var tmp4 *jrt.Class; A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_Init(); tmp4 = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_fn_class; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var fs__1927001036__auto____6 any; var tmp5 *lang.Var; A_arbace_aot_check_A_Init(); tmp5 = A_arbace_aot_check_A_const_26; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp8 *lang.Var; A_arbace_aot_check_A_Init(); tmp8 = A_arbace_aot_check_A_const_40; fs__1927001036__auto____6 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(f__4))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp9 *lang.Var; A_arbace_aot_check_A_Init(); tmp9 = A_arbace_aot_check_A_const_39; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1217000021); var tmp12 *lang.Var; A_arbace_aot_check_A_Init(); tmp12 = A_arbace_aot_check_A_const_34; return tmp10.Invoke_O_O__O(fs__1927001036__auto____6, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1217000022__1))) } else { var tmp13 *lang.Var; A_arbace_aot_check_A_Init(); tmp13 = A_arbace_aot_check_A_const_34; s__1217000022__1 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(s__1217000022__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :22:1
func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_New() *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_Init(); t := &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) Ctor() {}
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) Invoke_O_O__O(self, s__1217000024__1 any) any { var tmp1 any = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_New_O_O(self, s__1217000024__1); var tmp2 *jrt.Class; A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_Init(); tmp2 = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :22:1
func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_New_O_O(p0, p1 any) *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_Init(); t := &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) Ctor_O_O(c__iter__1217000023, c__s__1217000024 any) { t.F_iter__1217000023 = c__iter__1217000023; t.F_s__1217000024 = c__s__1217000024 }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) Invoke_O__O(self any) any { { var s__1217000024__1 any; var t_ any = t.F_s__1217000024; t.F_s__1217000024 = nil; s__1217000024__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1217000024__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1217000024__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_aot_check_A_Init(); tmp2 = A_arbace_aot_check_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1217000024__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_29; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1217000024__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1217000026__6 any; var tmp4 *lang.Var; A_arbace_aot_check_A_Init(); tmp4 = A_arbace_aot_check_A_const_30; b__1217000026__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_New_O_I_O(b__1217000026__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_Init(); tmp6 = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_35; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_aot_check_A_Init(); tmp9 = A_arbace_aot_check_A_const_37; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1217000026__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1217000023); var tmp12 *lang.Var; A_arbace_aot_check_A_Init(); tmp12 = A_arbace_aot_check_A_const_38; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1217000024__3))) } else { var tmp13 *lang.Var; A_arbace_aot_check_A_Init(); tmp13 = A_arbace_aot_check_A_const_35; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_aot_check_A_Init(); tmp15 = A_arbace_aot_check_A_const_37; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1217000026__6), nil) } } else { var fm__4 any; var tmp16 *lang.Var; A_arbace_aot_check_A_Init(); tmp16 = A_arbace_aot_check_A_const_27; fm__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1217000024__3); var tmp17 any; var and__1927000168__auto____5 any; var tmp18 *lang.Var

	A_arbace_aot_check_A_Init(); tmp18 = A_arbace_aot_check_A_const_31; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(fm__4); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp19 any; A_arbace_aot_check_A_Init(); tmp19 = A_arbace_aot_check_A_const_32; var tmp20 any = tmp19; var tmp21 *lang.Var; A_arbace_aot_check_A_Init(); tmp21 = A_arbace_aot_check_A_const_27; tmp17 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(fm__4))).Ref() } else { tmp17 = and__1927000168__auto____5 }
//line :22:1
	if jrt.A2g_Truth(tmp17) { var tmp22 *lang.Var; A_arbace_aot_check_A_Init(); tmp22 = A_arbace_aot_check_A_const_36; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_aot_check_A_Init(); tmp24 = A_arbace_aot_check_A_const_34; var tmp25 any = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(fm__4); var tmp26 lang.IFn = lang.IFn_Cast(t.F_iter__1217000023); var tmp27 *lang.Var; A_arbace_aot_check_A_Init(); tmp27 = A_arbace_aot_check_A_const_34; return tmp23.Invoke_O_O__O(tmp25, tmp26.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__1217000024__3))) } else { var tmp28 *lang.Var; A_arbace_aot_check_A_Init(); tmp28 = A_arbace_aot_check_A_const_34; s__1217000024__1 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(s__1217000024__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :22:1
func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_Init(); t := &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) Ctor_O_I_O(c__b__1217000026 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1217000026 = c__b__1217000026; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :22:1
func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) Invoke_O__O(self any) any { { var i__1217000025__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1217000025__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1217000025__1)); var tmp2 any; var and__1927000168__auto____3 any; var tmp3 *lang.Var

	A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_31; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(fm__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp4 any; A_arbace_aot_check_A_Init(); tmp4 = A_arbace_aot_check_A_const_32; var tmp5 any = tmp4; var tmp6 *lang.Var; A_arbace_aot_check_A_Init(); tmp6 = A_arbace_aot_check_A_const_27; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(fm__2))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :22:1
	if jrt.A2g_Truth(tmp2) { var tmp7 *lang.Var; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_33; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_b__1217000026; var tmp10 *lang.Var; A_arbace_aot_check_A_Init(); tmp10 = A_arbace_aot_check_A_const_34; tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(fm__2)); i__1217000025__1 = lang.Numbers_Unchecked_inc_J__J(i__1217000025__1); continue L1 } else { i__1217000025__1 = lang.Numbers_Unchecked_inc_J__J(i__1217000025__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_aot_check_check_fn__1217000037_A_New() *A_arbace_aot_check_check_fn__1217000037_A { A_arbace_aot_check_check_fn__1217000037_A_Init(); t := &A_arbace_aot_check_check_fn__1217000037_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_aot_check_check_fn__1217000037_A) Ctor() {}
//line :27:1
func (t *A_arbace_aot_check_check_fn__1217000037_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 *lang.Var; A_arbace_aot_check_A_Init(); tmp2 = A_arbace_aot_check_A_const_1; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_aot_check_A_Init(); tmp4 = A_arbace_aot_check_A_const_48; tmp1 = tmp3.Invoke_O__O(tmp4) }
//line :27:1
	return nil }(); var tmp6 *lang.Var; A_arbace_aot_check_A_Init(); tmp6 = A_arbace_aot_check_A_const_15; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }





func A_arbace_aot_check_check_fn__1217000039_A_New() *A_arbace_aot_check_check_fn__1217000039_A { A_arbace_aot_check_check_fn__1217000039_A_Init(); t := &A_arbace_aot_check_check_fn__1217000039_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_aot_check_check_fn__1217000039_A) Ctor() {}
//line :33:1
func (t *A_arbace_aot_check_check_fn__1217000039_A) Invoke_O_O_O__O(self, ___1, node__2 any) any { return node__2 }
//line :33:1
func A_arbace_aot_check_check_fn__1217000041_A_New_O_O(p0, p1 any) *A_arbace_aot_check_check_fn__1217000041_A { A_arbace_aot_check_check_fn__1217000041_A_Init(); t := &A_arbace_aot_check_check_fn__1217000041_A{}; t.Ctor_O_O(p0, p1); return t }
//line :33:1
func (t *A_arbace_aot_check_check_fn__1217000041_A) Ctor_O_O(c__ns, c__forms any) { t.F_ns = c__ns; t.F_forms = c__forms }
//line :33:1
func (t *A_arbace_aot_check_check_fn__1217000041_A) Invoke_O__O(self any) any { var names__1 any; var tmp1 *lang.Var;
										A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_61; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var iter__1927001039__auto____1 any; var tmp4 any = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_New_O(t.F_ns); var tmp5 *jrt.Class; A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_Init(); tmp5 = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_fn_class; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(t.F_forms); names__1 = tmp2.Invoke_O__O(tmp3); var order__2 any; var tmp6 /*line :33:1*/*lang.Var;
										A_arbace_aot_check_A_Init(); tmp6 = A_arbace_aot_check_A_const_9; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp8 = A_arbace_aot_check_A_const_53; var tmp9 *lang.Keyword = tmp8; var tmp10 *lang.Var; A_arbace_aot_check_A_Init(); tmp10 = A_arbace_aot_check_A_const_52; order__2 = tmp7.Invoke_O__O(jrt.NN(tmp9).Invoke_O__O(jrt.NN(tmp10).Get__O())); var fails__3 any; var tmp11 /*line :33:1*/*lang.Var;



	A_arbace_aot_check_A_Init(); tmp11 = A_arbace_aot_check_A_const_51; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.PersistentVector; lang.PersistentVector_Init(); tmp13 = lang.PersistentVector_EMPTY; fails__3 = tmp12.Invoke_O__O(tmp13.Ref()); var try_BANG___4 any; var tmp14 any = /*line :33:1*/A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_New_O(fails__3); var tmp15 *jrt.Class;




	A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_Init(); tmp15 = A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_fn_class; try_BANG___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var t__5 any; var tmp16 /*line :33:1*/*lang.Var;








	A_arbace_aot_check_A_Init(); tmp16 = A_arbace_aot_check_A_const_51; t__5 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref()); var lap__6 any; var tmp17 any = /*line :33:1*/A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_New_O(t__5); var tmp18 *jrt.Class;









	A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_Init(); tmp18 = A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_fn_class; lap__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil);
	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_92); var seq_1217000056__7 any; var tmp19 /*line :33:1*/*lang.Var;











	A_arbace_aot_check_A_Init(); tmp19 = A_arbace_aot_check_A_const_26; seq_1217000056__7 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(order__2); var chunk_1217000057__8 any; var count_1217000058__9 int64 = 0; var i_1217000059__10 int64 = 0; L1:
//line :33:1
	for {











		if lang.Numbers_Lt_J_J__Z(i_1217000059__10, count_1217000058__9) { var n__11 any = lang.Indexed_Cast(chunk_1217000057__8).Nth_I__O(lang.RT_IntCast_J__I(i_1217000059__10)); var tmp20 *lang.Var; A_arbace_aot_check_A_Init(); tmp20 = A_arbace_aot_check_A_const_72; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp22 = A_arbace_aot_check_A_const_73; var tmp23 *lang.Keyword = tmp22; var tmp24 *lang.Var; A_arbace_aot_check_A_Init(); tmp24 = A_arbace_aot_check_A_const_74; if jrt.A2g_Truth(tmp21.Invoke_O__O(jrt.NN(tmp23).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(n__11)))) { var tmp25 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp26 *lang.Var; A_arbace_aot_check_A_Init(); tmp26 = A_arbace_aot_check_A_const_75; tmp25.Invoke_O_O_O__O(Lit_93, n__11, jrt.NN(tmp26).GetRawRoot__O()); seq_1217000056__7, chunk_1217000057__8, count_1217000058__9, i_1217000059__10 = seq_1217000056__7, chunk_1217000057__8, count_1217000058__9, lang.Numbers_Unchecked_inc_J__J(i_1217000059__10); continue L1 } else { seq_1217000056__7, chunk_1217000057__8, count_1217000058__9, i_1217000059__10 = seq_1217000056__7, chunk_1217000057__8, count_1217000058__9, lang.Numbers_Unchecked_inc_J__J(i_1217000059__10); continue L1 } } else { var temp__1927000414__auto____11 any; var tmp27 *lang.Var; A_arbace_aot_check_A_Init(); tmp27 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____11 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_1217000056__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1217000056__12 any = temp__1927000414__auto____11; var tmp28 *lang.Var; A_arbace_aot_check_A_Init(); tmp28 = A_arbace_aot_check_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_1217000056__12)) { var c__1927000678__auto____13 any; var tmp29 *lang.Var; A_arbace_aot_check_A_Init(); tmp29 = A_arbace_aot_check_A_const_29; c__1927000678__auto____13 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_1217000056__12); var tmp30 *lang.Var; A_arbace_aot_check_A_Init(); tmp30 = A_arbace_aot_check_A_const_38; seq_1217000056__7, chunk_1217000057__8, count_1217000058__9, i_1217000059__10 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq_1217000056__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var n__13 any; var tmp31 *lang.Var; A_arbace_aot_check_A_Init(); tmp31 = A_arbace_aot_check_A_const_27; n__13 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(seq_1217000056__12); var tmp32 *lang.Var; A_arbace_aot_check_A_Init(); tmp32 = A_arbace_aot_check_A_const_72; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp34 = A_arbace_aot_check_A_const_73; var tmp35 *lang.Keyword = tmp34; var tmp36 *lang.Var; A_arbace_aot_check_A_Init(); tmp36 = A_arbace_aot_check_A_const_74; if jrt.A2g_Truth(tmp33.Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(n__13)))) { var tmp37 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp38 *lang.Var; A_arbace_aot_check_A_Init(); tmp38 = A_arbace_aot_check_A_const_75; tmp37.Invoke_O_O_O__O(Lit_93, n__13, jrt.NN(tmp38).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_aot_check_A_Init(); tmp39 = A_arbace_aot_check_A_const_76; seq_1217000056__7, chunk_1217000057__8, count_1217000058__9, i_1217000059__10 = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(seq_1217000056__12), nil, 0, 0; continue L1 } else { var tmp40 *lang.Var; A_arbace_aot_check_A_Init(); tmp40 = A_arbace_aot_check_A_const_76; seq_1217000056__7, chunk_1217000057__8, count_1217000058__9, i_1217000059__10 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq_1217000056__12), nil, 0, 0; continue L1 } } } }
//line :33:1
		break L1 };












	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_94); var seq_1217000060__7 any; var tmp41 /*line :33:1*/*lang.Var;













	A_arbace_aot_check_A_Init(); tmp41 = A_arbace_aot_check_A_const_26; seq_1217000060__7 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(order__2); var chunk_1217000061__8 any; var count_1217000062__9 int64 = 0; var i_1217000063__10 int64 = 0; L2:
//line :33:1
	for {













		if lang.Numbers_Lt_J_J__Z(i_1217000063__10, count_1217000062__9) { var n__11_2 any = lang.Indexed_Cast(chunk_1217000061__8).Nth_I__O(lang.RT_IntCast_J__I(i_1217000063__10)); var tmp42 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp43 *lang.Var; A_arbace_aot_check_A_Init(); tmp43 = A_arbace_aot_check_A_const_77; tmp42.Invoke_O_O_O__O(Lit_95, n__11_2, jrt.NN(tmp43).GetRawRoot__O()); seq_1217000060__7, chunk_1217000061__8, count_1217000062__9, i_1217000063__10 = seq_1217000060__7, chunk_1217000061__8, count_1217000062__9, lang.Numbers_Unchecked_inc_J__J(i_1217000063__10); continue L2 } else { var temp__1927000414__auto____11_2 any; var tmp44 *lang.Var; A_arbace_aot_check_A_Init(); tmp44 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____11_2 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq_1217000060__7); if jrt.A2g_Truth(temp__1927000414__auto____11_2) { var seq_1217000060__12 any = temp__1927000414__auto____11_2; var tmp45 *lang.Var; A_arbace_aot_check_A_Init(); tmp45 = A_arbace_aot_check_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(seq_1217000060__12)) { var c__1927000678__auto____13_2 any; var tmp46 *lang.Var; A_arbace_aot_check_A_Init(); tmp46 = A_arbace_aot_check_A_const_29; c__1927000678__auto____13_2 = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(seq_1217000060__12); var tmp47 *lang.Var; A_arbace_aot_check_A_Init(); tmp47 = A_arbace_aot_check_A_const_38; seq_1217000060__7, chunk_1217000061__8, count_1217000062__9, i_1217000063__10 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(seq_1217000060__12), c__1927000678__auto____13_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var n__13_2 any; var tmp48 *lang.Var; A_arbace_aot_check_A_Init(); tmp48 = A_arbace_aot_check_A_const_27; n__13_2 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O__O(seq_1217000060__12); var tmp49 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp50 *lang.Var; A_arbace_aot_check_A_Init(); tmp50 = A_arbace_aot_check_A_const_77; tmp49.Invoke_O_O_O__O(Lit_95, n__13_2, jrt.NN(tmp50).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_aot_check_A_Init(); tmp51 = A_arbace_aot_check_A_const_76; seq_1217000060__7, chunk_1217000061__8, count_1217000062__9, i_1217000063__10 = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(seq_1217000060__12), nil, 0, 0; continue L2 } } }
//line :33:1
		break L2 };














	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_95); var seq_1217000064__7 any; var tmp52 /*line :33:1*/*lang.Var;















	A_arbace_aot_check_A_Init(); tmp52 = A_arbace_aot_check_A_const_26; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_aot_check_A_Init(); tmp54 = A_arbace_aot_check_A_const_78; seq_1217000064__7 = tmp53.Invoke_O__O(Up_Var_IFn(tmp54).Invoke_O__O(order__2)); var chunk_1217000065__8 any; var count_1217000066__9 int64 = 0; var i_1217000067__10 int64 = 0; L3:
//line :33:1
	for {















		if lang.Numbers_Lt_J_J__Z(i_1217000067__10, count_1217000066__9) { var n__11_3 any = lang.Indexed_Cast(chunk_1217000065__8).Nth_I__O(lang.RT_IntCast_J__I(i_1217000067__10)); var tmp55 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp56 *lang.Var; A_arbace_aot_check_A_Init(); tmp56 = A_arbace_aot_check_A_const_79; tmp55.Invoke_O_O_O__O(Lit_96, n__11_3, jrt.NN(tmp56).GetRawRoot__O()); seq_1217000064__7, chunk_1217000065__8, count_1217000066__9, i_1217000067__10 = seq_1217000064__7, chunk_1217000065__8, count_1217000066__9, lang.Numbers_Unchecked_inc_J__J(i_1217000067__10); continue L3 } else { var temp__1927000414__auto____11_3 any; var tmp57 *lang.Var; A_arbace_aot_check_A_Init(); tmp57 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____11_3 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(seq_1217000064__7); if jrt.A2g_Truth(temp__1927000414__auto____11_3) { var seq_1217000064__12 any = temp__1927000414__auto____11_3; var tmp58 *lang.Var; A_arbace_aot_check_A_Init(); tmp58 = A_arbace_aot_check_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke_O__O(seq_1217000064__12)) { var c__1927000678__auto____13_3 any; var tmp59 *lang.Var; A_arbace_aot_check_A_Init(); tmp59 = A_arbace_aot_check_A_const_29; c__1927000678__auto____13_3 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(seq_1217000064__12); var tmp60 *lang.Var; A_arbace_aot_check_A_Init(); tmp60 = A_arbace_aot_check_A_const_38; seq_1217000064__7, chunk_1217000065__8, count_1217000066__9, i_1217000067__10 = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(seq_1217000064__12), c__1927000678__auto____13_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var n__13_3 any; var tmp61 *lang.Var; A_arbace_aot_check_A_Init(); tmp61 = A_arbace_aot_check_A_const_27; n__13_3 = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(seq_1217000064__12); var tmp62 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp63 *lang.Var; A_arbace_aot_check_A_Init(); tmp63 = A_arbace_aot_check_A_const_79; tmp62.Invoke_O_O_O__O(Lit_96, n__13_3, jrt.NN(tmp63).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_aot_check_A_Init(); tmp64 = A_arbace_aot_check_A_const_76; seq_1217000064__7, chunk_1217000065__8, count_1217000066__9, i_1217000067__10 = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(seq_1217000064__12), nil, 0, 0; continue L3 } } }
//line :33:1
		break L3 };
















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_96); var seq_1217000068__7 any; var tmp65 /*line :33:1*/*lang.Var;

















	A_arbace_aot_check_A_Init(); tmp65 = A_arbace_aot_check_A_const_26; seq_1217000068__7 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(order__2); var chunk_1217000069__8 any; var count_1217000070__9 int64 = 0; var i_1217000071__10 int64 = 0; L4:
//line :33:1
	for {

















		if lang.Numbers_Lt_J_J__Z(i_1217000071__10, count_1217000070__9) { var n__11_4 any = lang.Indexed_Cast(chunk_1217000069__8).Nth_I__O(lang.RT_IntCast_J__I(i_1217000071__10)); var tmp66 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp67 *lang.Var; A_arbace_aot_check_A_Init(); tmp67 = A_arbace_aot_check_A_const_80; tmp66.Invoke_O_O_O__O(Lit_97, n__11_4, tmp67.Ref()); seq_1217000068__7, chunk_1217000069__8, count_1217000070__9, i_1217000071__10 = seq_1217000068__7, chunk_1217000069__8, count_1217000070__9, lang.Numbers_Unchecked_inc_J__J(i_1217000071__10); continue L4 } else { var temp__1927000414__auto____11_4 any; var tmp68 *lang.Var; A_arbace_aot_check_A_Init(); tmp68 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____11_4 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(seq_1217000068__7); if jrt.A2g_Truth(temp__1927000414__auto____11_4) { var seq_1217000068__12 any = temp__1927000414__auto____11_4; var tmp69 *lang.Var; A_arbace_aot_check_A_Init(); tmp69 = A_arbace_aot_check_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(seq_1217000068__12)) { var c__1927000678__auto____13_4 any; var tmp70 *lang.Var; A_arbace_aot_check_A_Init(); tmp70 = A_arbace_aot_check_A_const_29; c__1927000678__auto____13_4 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(seq_1217000068__12); var tmp71 *lang.Var; A_arbace_aot_check_A_Init(); tmp71 = A_arbace_aot_check_A_const_38; seq_1217000068__7, chunk_1217000069__8, count_1217000070__9, i_1217000071__10 = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(seq_1217000068__12), c__1927000678__auto____13_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_4))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var n__13_4 any; var tmp72 *lang.Var; A_arbace_aot_check_A_Init(); tmp72 = A_arbace_aot_check_A_const_27; n__13_4 = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(seq_1217000068__12); var tmp73 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp74 *lang.Var; A_arbace_aot_check_A_Init(); tmp74 = A_arbace_aot_check_A_const_80; tmp73.Invoke_O_O_O__O(Lit_97, n__13_4, tmp74.Ref()); var tmp75 *lang.Var; A_arbace_aot_check_A_Init(); tmp75 = A_arbace_aot_check_A_const_76; seq_1217000068__7, chunk_1217000069__8, count_1217000070__9, i_1217000071__10 = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(seq_1217000068__12), nil, 0, 0; continue L4 } } }
//line :33:1
		break L4 }; var seq_1217000072__7 any; var tmp76 *lang.Var;


















	A_arbace_aot_check_A_Init(); tmp76 = A_arbace_aot_check_A_const_26; seq_1217000072__7 = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(order__2); var chunk_1217000073__8 any; var count_1217000074__9 int64 = 0; var i_1217000075__10 int64 = 0; L5:
//line :33:1
	for {


















		if lang.Numbers_Lt_J_J__Z(i_1217000075__10, count_1217000074__9) { var n__11_5 any = lang.Indexed_Cast(chunk_1217000073__8).Nth_I__O(lang.RT_IntCast_J__I(i_1217000075__10)); var tmp77 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp78 *lang.Var; A_arbace_aot_check_A_Init(); tmp78 = A_arbace_aot_check_A_const_81; tmp77.Invoke_O_O_O__O(Lit_98, n__11_5, jrt.NN(tmp78).GetRawRoot__O()); seq_1217000072__7, chunk_1217000073__8, count_1217000074__9, i_1217000075__10 = seq_1217000072__7, chunk_1217000073__8, count_1217000074__9, lang.Numbers_Unchecked_inc_J__J(i_1217000075__10); continue L5 } else { var temp__1927000414__auto____11_5 any; var tmp79 *lang.Var; A_arbace_aot_check_A_Init(); tmp79 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____11_5 = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(seq_1217000072__7); if jrt.A2g_Truth(temp__1927000414__auto____11_5) { var seq_1217000072__12 any = temp__1927000414__auto____11_5; var tmp80 *lang.Var; A_arbace_aot_check_A_Init(); tmp80 = A_arbace_aot_check_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(seq_1217000072__12)) { var c__1927000678__auto____13_5 any; var tmp81 *lang.Var; A_arbace_aot_check_A_Init(); tmp81 = A_arbace_aot_check_A_const_29; c__1927000678__auto____13_5 = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O__O(seq_1217000072__12); var tmp82 *lang.Var; A_arbace_aot_check_A_Init(); tmp82 = A_arbace_aot_check_A_const_38; seq_1217000072__7, chunk_1217000073__8, count_1217000074__9, i_1217000075__10 = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(seq_1217000072__12), c__1927000678__auto____13_5, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13_5))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var n__13_5 any; var tmp83 *lang.Var; A_arbace_aot_check_A_Init(); tmp83 = A_arbace_aot_check_A_const_27; n__13_5 = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()).Invoke_O__O(seq_1217000072__12); var tmp84 lang.IFn = lang.IFn_Cast(try_BANG___4); var tmp85 *lang.Var; A_arbace_aot_check_A_Init(); tmp85 = A_arbace_aot_check_A_const_81; tmp84.Invoke_O_O_O__O(Lit_98, n__13_5, jrt.NN(tmp85).GetRawRoot__O()); var tmp86 *lang.Var; A_arbace_aot_check_A_Init(); tmp86 = A_arbace_aot_check_A_const_76; seq_1217000072__7, chunk_1217000073__8, count_1217000074__9, i_1217000075__10 = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()).Invoke_O__O(seq_1217000072__12), nil, 0, 0; continue L5 } } }
//line :33:1
		break L5 };



















	lang.IFn_Cast(lap__6).Invoke_O__O(Lit_98); var tmp87 /*line :54:1*/*lang.Var; A_arbace_aot_check_A_Init(); tmp87 = A_arbace_aot_check_A_const_63; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(names__1)).Ref(); var tmp90 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(order__2)).Ref(); var tmp91 *lang.Var; A_arbace_aot_check_A_Init(); tmp91 = A_arbace_aot_check_A_const_9; tmp88.Invoke_O_O_O_O_O_O_O__O(Lit_99, tmp89, Lit_100, tmp90, Lit_101, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()).Invoke_O__O(fails__3))).Ref(), Lit_102); var tmp92 /*line :34:1*/*lang.Var; A_arbace_aot_check_A_Init(); tmp92 = A_arbace_aot_check_A_const_9; return lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()).Invoke_O__O(fails__3) }
//line :34:1
func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_New_O(p0 any) *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_Init(); t := &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A{}; t.Ctor_O(p0); return t }
//line :34:1
func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :34:1
func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) Invoke_O_O__O(self, s__1217000043__1 any) any { var tmp1 any = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_New_O_O_O(t.F_ns, s__1217000043__1, self); var tmp2 *jrt.Class; A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_Init(); tmp2 = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :34:1
func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_Init(); t := &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :34:1
func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) Ctor_O_O_O(c__ns, c__s__1217000043, c__iter__1217000042 any) { t.F_ns = c__ns; t.F_s__1217000043 = c__s__1217000043; t.F_iter__1217000042 = c__iter__1217000042 }
//line :34:1
func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) Invoke_O__O(self any) any { { var s__1217000043__1 any; var t_ any = t.F_s__1217000043; t.F_s__1217000043 = nil; s__1217000043__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_26; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1217000043__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1217000043__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_aot_check_A_Init(); tmp2 = A_arbace_aot_check_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1217000043__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_29; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1217000043__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1217000045__6 any; var tmp4 *lang.Var; A_arbace_aot_check_A_Init(); tmp4 = A_arbace_aot_check_A_const_30; b__1217000045__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_New_O_O_I_O(t.F_ns, b__1217000045__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_Init(); tmp6 = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_35; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_aot_check_A_Init(); tmp9 = A_arbace_aot_check_A_const_37; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1217000045__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1217000042); var tmp12 *lang.Var; A_arbace_aot_check_A_Init(); tmp12 = A_arbace_aot_check_A_const_38; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1217000043__3))) } else { var tmp13 *lang.Var; A_arbace_aot_check_A_Init(); tmp13 = A_arbace_aot_check_A_const_35; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_aot_check_A_Init(); tmp15 = A_arbace_aot_check_A_const_37; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1217000045__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_aot_check_A_Init(); tmp16 = A_arbace_aot_check_A_const_27; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1217000043__3); var tmp17 *lang.Var; A_arbace_aot_check_A_Init(); tmp17 = A_arbace_aot_check_A_const_36; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_aot_check_A_Init(); tmp19 = A_arbace_aot_check_A_const_64; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_aot_check_A_Init(); tmp21 = A_arbace_aot_check_A_const_70; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_aot_check_A_Init(); tmp23 = A_arbace_aot_check_A_const_66; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp25 = A_arbace_aot_check_A_const_67; var tmp26 any = tmp25.Ref(); var tmp27 any = t.F_ns; var tmp28 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp28 = A_arbace_aot_check_A_const_68; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp30 = A_arbace_aot_check_A_const_69; var tmp31 any = tmp20.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp27, tmp29, tmp30.Ref())), f__4)); var tmp32 lang.IFn = lang.IFn_Cast(t.F_iter__1217000042); var tmp33 *lang.Var; A_arbace_aot_check_A_Init(); tmp33 = A_arbace_aot_check_A_const_34; return tmp18.Invoke_O_O__O(tmp31, tmp32.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(s__1217000043__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :34:1
func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_Init(); t := &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :34:1
func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) Ctor_O_O_I_O(c__ns, c__b__1217000045 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ns = c__ns; t.F_b__1217000045 = c__b__1217000045; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :34:1
func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) Invoke_O__O(self any) any { { var i__1217000044__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1217000044__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1217000044__1)); var tmp2 *lang.Var; A_arbace_aot_check_A_Init(); tmp2 = A_arbace_aot_check_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1217000045; var tmp5 *lang.Var; A_arbace_aot_check_A_Init(); tmp5 = A_arbace_aot_check_A_const_64; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_65; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_aot_check_A_Init(); tmp9 = A_arbace_aot_check_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp11 = A_arbace_aot_check_A_const_67; var tmp12 any = tmp11.Ref(); var tmp13 any = t.F_ns; var tmp14 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp14 = A_arbace_aot_check_A_const_68; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_aot_check_A_Init(); tmp16 = A_arbace_aot_check_A_const_69; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp15, tmp16.Ref())), f__2))); i__1217000044__1 = lang.Numbers_Unchecked_inc_J__J(i__1217000044__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_New_O(p0 any) *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A { A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_Init(); t := &A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) Ctor_O(c__fails any) { t.F_fails = c__fails }
//line :38:1
func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) Invoke_O_O_O_O__O(self, what__1, n__2, f__3 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																tmp1 = lang.IFn_Cast(f__3).Invoke_O__O(n__2)
//line :38:1
	return nil }(); if tmp2 != nil { if true { var t__6 jrt.Throwable_I = tmp2; var tmp3 *lang.Var

		A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_63; lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_109, what__1, n__2, t__6.GetMessage__String().Ref())
		var tmp4 *lang.Var; A_arbace_aot_check_A_Init(); tmp4 = A_arbace_aot_check_A_const_62; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_fails; var tmp7 *lang.Var; A_arbace_aot_check_A_Init(); tmp7 = A_arbace_aot_check_A_const_10; tmp1 = tmp5.Invoke_O_O_O__O(tmp6, jrt.NN(tmp7).GetRawRoot__O(), lang.Tuple_Create_O_O_O__IPersistentVector(n__2, what__1, t__6.GetMessage__String().Ref())) } }; return tmp1 }

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_New_O(p0 any) *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A { A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_Init(); t := &A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A{}; t.Ctor_O(p0); return t }
//line :43:1
func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :43:1
func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) Invoke_O_O__O(self, k__1 any) any { var x__2 int64 = jrt.System_NanoTime__J(); var tmp1 *lang.Var; A_arbace_aot_check_A_Init(); tmp1 = A_arbace_aot_check_A_const_63; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_aot_check_A_Init(); tmp3 = A_arbace_aot_check_A_const_9; tmp2.Invoke_O_O_O_O__O(Lit_99, k__1, jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(jrt.Math_Round_D__J(lang.Numbers_Divide_O_D__D(lang.Numbers_Minus_J_O__Number(x__2, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_t)), 1.0e7)), 100.0)).Ref(), Lit_107); var tmp4 *lang.Var; A_arbace_aot_check_A_Init(); tmp4 = A_arbace_aot_check_A_const_71; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_t; return tmp5.Invoke_O_O__O(tmp6, jrt.Long_ValueOf_J__Long(x__2).Ref()) }




















































































type A_arbace_aot_check_A struct{ jrt.Object }

var A_arbace_aot_check_A_const_0 *lang.Var

var A_arbace_aot_check_A_const_1 *lang.Var

var A_arbace_aot_check_A_const_2 any

var A_arbace_aot_check_A_const_3 any

var A_arbace_aot_check_A_const_4 any

var A_arbace_aot_check_A_const_5 any

var A_arbace_aot_check_A_const_6 any

var A_arbace_aot_check_A_const_7 any

var A_arbace_aot_check_A_const_8 *lang.Var

var A_arbace_aot_check_A_const_9 *lang.Var

var A_arbace_aot_check_A_const_10 *lang.Var

var A_arbace_aot_check_A_const_11 any

var A_arbace_aot_check_A_const_12 *lang.Var

var A_arbace_aot_check_A_const_13 *lang.Var

var A_arbace_aot_check_A_const_14 *lang.Var

var A_arbace_aot_check_A_const_15 *lang.Var

var A_arbace_aot_check_A_const_16 *lang.Var

var A_arbace_aot_check_A_const_17 *lang.Var

var A_arbace_aot_check_A_const_18 *lang.Var

var A_arbace_aot_check_A_const_19 *lang.Var

var A_arbace_aot_check_A_const_20 *lang.Var

var A_arbace_aot_check_A_const_21 *lang.Keyword

var A_arbace_aot_check_A_const_22 *lang.Var

var A_arbace_aot_check_A_const_23 *lang.Var

var A_arbace_aot_check_A_const_24 any

var A_arbace_aot_check_A_const_25 *lang.Var

var A_arbace_aot_check_A_const_26 *lang.Var

var A_arbace_aot_check_A_const_27 *lang.Var

var A_arbace_aot_check_A_const_28 *lang.Var

var A_arbace_aot_check_A_const_29 *lang.Var

var A_arbace_aot_check_A_const_30 *lang.Var

var A_arbace_aot_check_A_const_31 *lang.Var

var A_arbace_aot_check_A_const_32 any

var A_arbace_aot_check_A_const_33 *lang.Var

var A_arbace_aot_check_A_const_34 *lang.Var

var A_arbace_aot_check_A_const_35 *lang.Var

var A_arbace_aot_check_A_const_36 *lang.Var

var A_arbace_aot_check_A_const_37 *lang.Var

var A_arbace_aot_check_A_const_38 *lang.Var

var A_arbace_aot_check_A_const_39 *lang.Var

var A_arbace_aot_check_A_const_40 *lang.Var

var A_arbace_aot_check_A_const_41 *lang.Var

var A_arbace_aot_check_A_const_42 *lang.Var

var A_arbace_aot_check_A_const_43 *lang.Var

var A_arbace_aot_check_A_const_44 *lang.Var

var A_arbace_aot_check_A_const_45 *lang.Var

var A_arbace_aot_check_A_const_46 *lang.Var

var A_arbace_aot_check_A_const_47 any

var A_arbace_aot_check_A_const_48 any

var A_arbace_aot_check_A_const_49 *lang.Var

var A_arbace_aot_check_A_const_50 *lang.Var

var A_arbace_aot_check_A_const_51 *lang.Var

var A_arbace_aot_check_A_const_52 *lang.Var

var A_arbace_aot_check_A_const_53 *lang.Keyword

var A_arbace_aot_check_A_const_54 *lang.Keyword

var A_arbace_aot_check_A_const_55 *lang.Keyword

var A_arbace_aot_check_A_const_56 *lang.Keyword

var A_arbace_aot_check_A_const_57 *lang.Keyword

var A_arbace_aot_check_A_const_58 *lang.Keyword

var A_arbace_aot_check_A_const_59 *lang.Keyword

var A_arbace_aot_check_A_const_60 *lang.Var

var A_arbace_aot_check_A_const_61 *lang.Var

var A_arbace_aot_check_A_const_62 *lang.Var

var A_arbace_aot_check_A_const_63 *lang.Var

var A_arbace_aot_check_A_const_64 *lang.Var

var A_arbace_aot_check_A_const_65 any

var A_arbace_aot_check_A_const_66 *lang.Var

var A_arbace_aot_check_A_const_67 *lang.Keyword

var A_arbace_aot_check_A_const_68 *lang.Keyword

var A_arbace_aot_check_A_const_69 *lang.Keyword

var A_arbace_aot_check_A_const_70 any

var A_arbace_aot_check_A_const_71 *lang.Var

var A_arbace_aot_check_A_const_72 *lang.Var

var A_arbace_aot_check_A_const_73 *lang.Keyword

var A_arbace_aot_check_A_const_74 *lang.Var

var A_arbace_aot_check_A_const_75 *lang.Var

var A_arbace_aot_check_A_const_76 *lang.Var

var A_arbace_aot_check_A_const_77 *lang.Var

var A_arbace_aot_check_A_const_78 *lang.Var

var A_arbace_aot_check_A_const_79 *lang.Var

var A_arbace_aot_check_A_const_80 *lang.Var

var A_arbace_aot_check_A_const_81 *lang.Var

var A_arbace_aot_check_A_init jrt.ClassInit

func A_arbace_aot_check_A_Init() { if !A_arbace_aot_check_A_init.Done() { A_arbace_aot_check_A_init.Run(A_arbace_aot_check_A_clinit) } }

func A_arbace_aot_check_A_clinit() { A_arbace_aot_check_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_aot_check_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_aot_check_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_aot_check_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_aot_check_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_aot_check_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_aot_check_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_aot_check_A_const_7 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_aot_check_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_aot_check_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_aot_check_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_aot_check_A_const_11 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_17)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19))); A_arbace_aot_check_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_aot_check_A_const_13 = lang.RT_Var_String_String__Var(Lit_3, Lit_21); A_arbace_aot_check_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_aot_check_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_aot_check_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_aot_check_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_aot_check_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_aot_check_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_aot_check_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_aot_check_A_const_21 = lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_29); A_arbace_aot_check_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_aot_check_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_aot_check_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_29).Ref())); A_arbace_aot_check_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_aot_check_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_aot_check_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_aot_check_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_aot_check_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_aot_check_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_aot_check_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_aot_check_A_const_32 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(); A_arbace_aot_check_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_aot_check_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_aot_check_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_aot_check_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_aot_check_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_aot_check_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_aot_check_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_aot_check_A_const_40 = lang.RT_Var_String_String__Var(Lit_17, Lit_47); A_arbace_aot_check_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_aot_check_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_aot_check_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_aot_check_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_aot_check_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_aot_check_A_const_46 = lang.RT_Var_String_String__Var(Lit_3, Lit_53); A_arbace_aot_check_A_const_47 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_54).Ref(); A_arbace_aot_check_A_const_48 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_aot_check_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_aot_check_A_const_50 = lang.RT_Var_String_String__Var(Lit_6, Lit_56); A_arbace_aot_check_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_aot_check_A_const_52 = lang.RT_Var_String_String__Var(Lit_8, Lit_58); A_arbace_aot_check_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_59); A_arbace_aot_check_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_aot_check_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_aot_check_A_const_56 = lang.RT_Keyword_String_String__Keyword(nil, Lit_62); A_arbace_aot_check_A_const_57 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_aot_check_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_aot_check_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_aot_check_A_const_60 = lang.RT_Var_String_String__Var(Lit_8, Lit_66); A_arbace_aot_check_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_aot_check_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_aot_check_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_aot_check_A_const_64 = lang.RT_Var_String_String__Var(Lit_8, Lit_70); A_arbace_aot_check_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_71).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref())); A_arbace_aot_check_A_const_66 = lang.RT_Var_String_String__Var(Lit_10, Lit_73); A_arbace_aot_check_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_aot_check_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_aot_check_A_const_69 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_aot_check_A_const_70 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_71).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref())); A_arbace_aot_check_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_aot_check_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_aot_check_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_77); A_arbace_aot_check_A_const_74 = lang.RT_Var_String_String__Var(Lit_8, Lit_78); A_arbace_aot_check_A_const_75 = lang.RT_Var_String_String__Var(Lit_8, Lit_79); A_arbace_aot_check_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_aot_check_A_const_77 = lang.RT_Var_String_String__Var(Lit_8, Lit_81); A_arbace_aot_check_A_const_78 = lang.RT_Var_String_String__Var(Lit_8, Lit_82); A_arbace_aot_check_A_const_79 = lang.RT_Var_String_String__Var(Lit_8, Lit_83); A_arbace_aot_check_A_const_80 = lang.RT_Var_String_String__Var(Lit_8, Lit_84); A_arbace_aot_check_A_const_81 = lang.RT_Var_String_String__Var(Lit_8, Lit_85) }

func A_arbace_aot_check_A_New() *A_arbace_aot_check_A { A_arbace_aot_check_A_Init(); t := &A_arbace_aot_check_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_check_A) Ctor() {}

func (t *A_arbace_aot_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_A_class }

func (t *A_arbace_aot_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_A); return ok }

func A_arbace_aot_check_A_Cast(x any) *A_arbace_aot_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_A_class)) }; return v }



type A_arbace_aot_check_check_A struct{ jrt.Object }

func (t *A_arbace_aot_check_check_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_check_A_fn_class *jrt.Class

var A_arbace_aot_check_check_A_init jrt.ClassInit

func A_arbace_aot_check_check_A_Init() { if !A_arbace_aot_check_check_A_init.Done() { A_arbace_aot_check_check_A_init.Run(A_arbace_aot_check_check_A_clinit) } }

func A_arbace_aot_check_check_A_clinit() { A_arbace_aot_check_check_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_A_class }

func (t *A_arbace_aot_check_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_A); return ok }

func A_arbace_aot_check_check_A_Cast(x any) *A_arbace_aot_check_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000019_A struct{ jrt.Object }

func (t *A_arbace_aot_check_check_fn__1217000019_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_check_fn__1217000019_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000019_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000019_A_Init() { if !A_arbace_aot_check_check_fn__1217000019_A_init.Done() { A_arbace_aot_check_check_fn__1217000019_A_init.Run(A_arbace_aot_check_check_fn__1217000019_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000019_A_clinit() { A_arbace_aot_check_check_fn__1217000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000019_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000019_A_class }

func (t *A_arbace_aot_check_check_fn__1217000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000019_A); return ok }

func A_arbace_aot_check_check_fn__1217000019_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000019_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000037_A struct{ jrt.Object }

func (t *A_arbace_aot_check_check_fn__1217000037_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_check_fn__1217000037_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000037_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000037_A_Init() { if !A_arbace_aot_check_check_fn__1217000037_A_init.Done() { A_arbace_aot_check_check_fn__1217000037_A_init.Run(A_arbace_aot_check_check_fn__1217000037_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000037_A_clinit() { A_arbace_aot_check_check_fn__1217000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000037_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000037_A_class }

func (t *A_arbace_aot_check_check_fn__1217000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000037_A); return ok }

func A_arbace_aot_check_check_fn__1217000037_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000037_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000039_A struct{ jrt.Object }

func (t *A_arbace_aot_check_check_fn__1217000039_A) Is_Compiler_AOTF2() {}

var A_arbace_aot_check_check_fn__1217000039_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000039_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000039_A_Init() { if !A_arbace_aot_check_check_fn__1217000039_A_init.Done() { A_arbace_aot_check_check_fn__1217000039_A_init.Run(A_arbace_aot_check_check_fn__1217000039_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000039_A_clinit() { A_arbace_aot_check_check_fn__1217000039_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000039_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000039_A_class }

func (t *A_arbace_aot_check_check_fn__1217000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000039_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000039_A); return ok }

func A_arbace_aot_check_check_fn__1217000039_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000039_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000041_A struct{ jrt.Object; F_ns, F_forms any }

func (t *A_arbace_aot_check_check_fn__1217000041_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_check_fn__1217000041_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000041_A_Init() { if !A_arbace_aot_check_check_fn__1217000041_A_init.Done() { A_arbace_aot_check_check_fn__1217000041_A_init.Run(A_arbace_aot_check_check_fn__1217000041_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000041_A_clinit() { A_arbace_aot_check_check_fn__1217000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000041_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000041_A_class }

func (t *A_arbace_aot_check_check_fn__1217000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000041_A); return ok }

func A_arbace_aot_check_check_fn__1217000041_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000041_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A struct{ jrt.Object; F_ns any }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_Init() { if !A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_init.Done() { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_init.Run(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_clinit() { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A); return ok }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A struct{ jrt.Object; F_ns, F_s__1217000043, F_iter__1217000042 any }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_Init() { if !A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_init.Done() { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_init.Run(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_clinit() { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A); return ok }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A struct{ jrt.Object; F_ns, F_b__1217000045 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_Init() { if !A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_init.Done() { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_init.Run(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_clinit() { A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_class }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A); return ok }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A struct{ jrt.Object; F_t any }

func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_Init() { if !A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_init.Done() { A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_init.Run(A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_clinit() { A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_class }

func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A); return ok }

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_class)) }; return v }



type A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A struct{ jrt.Object; F_fails any }

func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) Is_Compiler_AOTF3() {}

var A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_fn_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_init jrt.ClassInit

func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_Init() { if !A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_init.Done() { A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_init.Run(A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_clinit) } }

func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_clinit() { A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_class }

func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A); return ok }

func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_Cast(x any) *A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_class)) }; return v }



type A_arbace_aot_check_check_iter__1217000021__1217000027_A struct{ jrt.Object }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_check_iter__1217000021__1217000027_A_fn_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_A_init jrt.ClassInit

func A_arbace_aot_check_check_iter__1217000021__1217000027_A_Init() { if !A_arbace_aot_check_check_iter__1217000021__1217000027_A_init.Done() { A_arbace_aot_check_check_iter__1217000021__1217000027_A_init.Run(A_arbace_aot_check_check_iter__1217000021__1217000027_A_clinit) } }

func A_arbace_aot_check_check_iter__1217000021__1217000027_A_clinit() { A_arbace_aot_check_check_iter__1217000021__1217000027_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_iter__1217000021__1217000027_A_class }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_A); return ok }

func A_arbace_aot_check_check_iter__1217000021__1217000027_A_Cast(x any) *A_arbace_aot_check_check_iter__1217000021__1217000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_iter__1217000021__1217000027_A_class)) }; return v }



type A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A struct{ jrt.Object; F_s__1217000022, F_iter__1217000021 any }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_fn_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_init jrt.ClassInit

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_Init() { if !A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_init.Done() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_init.Run(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_clinit) } }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_clinit() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A); return ok }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_Cast(x any) *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class)) }; return v }



type A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A struct{ jrt.Object }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_fn_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_init jrt.ClassInit

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_Init() { if !A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_init.Done() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_init.Run(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_clinit) } }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_clinit() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A); return ok }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_Cast(x any) *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class)) }; return v }



type A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A struct{ jrt.Object; F_iter__1217000023, F_s__1217000024 any }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_fn_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_init jrt.ClassInit

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_Init() { if !A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_init.Done() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_init.Run(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_clinit) } }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_clinit() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A); return ok }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_Cast(x any) *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class)) }; return v }



type A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A struct{ jrt.Object; F_b__1217000026 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_fn_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_init jrt.ClassInit

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_Init() { if !A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_init.Done() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_init.Run(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_clinit) } }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_clinit() { A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_class }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A); return ok }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_Cast(x any) *A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_class)) }; return v }



type A_arbace_aot_check_eval1217000004_A struct{ jrt.Object }

func A_arbace_aot_check_eval1217000004_A_New() *A_arbace_aot_check_eval1217000004_A { t := &A_arbace_aot_check_eval1217000004_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_check_eval1217000004_A) Ctor() {}

func (t *A_arbace_aot_check_eval1217000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_eval1217000004_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_eval1217000004_A_class }

func (t *A_arbace_aot_check_eval1217000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_eval1217000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_eval1217000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_eval1217000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_eval1217000004_A); return ok }

func A_arbace_aot_check_eval1217000004_A_Cast(x any) *A_arbace_aot_check_eval1217000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_eval1217000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_eval1217000004_A_class)) }; return v }



type A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A struct{ jrt.Object }

func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_fn_class *jrt.Class

var A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_init jrt.ClassInit

func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_Init() { if !A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_init.Done() { A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_init.Run(A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_clinit) } }

func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_clinit() { A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_class }

func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A); return ok }

func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_Cast(x any) *A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_class)) }; return v }



type A_arbace_aot_check_eval1217000008_A struct{ jrt.Object }

func A_arbace_aot_check_eval1217000008_A_New() *A_arbace_aot_check_eval1217000008_A { t := &A_arbace_aot_check_eval1217000008_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_check_eval1217000008_A) Ctor() {}

func (t *A_arbace_aot_check_eval1217000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_eval1217000008_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_eval1217000008_A_class }

func (t *A_arbace_aot_check_eval1217000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_eval1217000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_eval1217000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_eval1217000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_eval1217000008_A); return ok }

func A_arbace_aot_check_eval1217000008_A_Cast(x any) *A_arbace_aot_check_eval1217000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_eval1217000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_eval1217000008_A_class)) }; return v }



type A_arbace_aot_check_eval1217000008_fn__1217000009_A struct{ jrt.Object }

func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_eval1217000008_fn__1217000009_A_fn_class *jrt.Class

var A_arbace_aot_check_eval1217000008_fn__1217000009_A_init jrt.ClassInit

func A_arbace_aot_check_eval1217000008_fn__1217000009_A_Init() { if !A_arbace_aot_check_eval1217000008_fn__1217000009_A_init.Done() { A_arbace_aot_check_eval1217000008_fn__1217000009_A_init.Run(A_arbace_aot_check_eval1217000008_fn__1217000009_A_clinit) } }

func A_arbace_aot_check_eval1217000008_fn__1217000009_A_clinit() { A_arbace_aot_check_eval1217000008_fn__1217000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_eval1217000008_fn__1217000009_A_class }

func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_eval1217000008_fn__1217000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_eval1217000008_fn__1217000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_eval1217000008_fn__1217000009_A); return ok }

func A_arbace_aot_check_eval1217000008_fn__1217000009_A_Cast(x any) *A_arbace_aot_check_eval1217000008_fn__1217000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_eval1217000008_fn__1217000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_eval1217000008_fn__1217000009_A_class)) }; return v }



type A_arbace_aot_check_read_all_A struct{ jrt.Object }

func (t *A_arbace_aot_check_read_all_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_read_all_A_fn_class *jrt.Class

var A_arbace_aot_check_read_all_A_init jrt.ClassInit

func A_arbace_aot_check_read_all_A_Init() { if !A_arbace_aot_check_read_all_A_init.Done() { A_arbace_aot_check_read_all_A_init.Run(A_arbace_aot_check_read_all_A_clinit) } }

func A_arbace_aot_check_read_all_A_clinit() { A_arbace_aot_check_read_all_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_read_all_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_read_all_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_read_all_A_class }

func (t *A_arbace_aot_check_read_all_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_read_all_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_read_all_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_read_all_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_read_all_A); return ok }

func A_arbace_aot_check_read_all_A_Cast(x any) *A_arbace_aot_check_read_all_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_read_all_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_read_all_A_class)) }; return v }



type A_arbace_aot_check_read_all_fn__1217000013_A struct{ jrt.Object }

func (t *A_arbace_aot_check_read_all_fn__1217000013_A) Is_Compiler_AOTF1() {}

var A_arbace_aot_check_read_all_fn__1217000013_A_fn_class *jrt.Class

var A_arbace_aot_check_read_all_fn__1217000013_A_init jrt.ClassInit

func A_arbace_aot_check_read_all_fn__1217000013_A_Init() { if !A_arbace_aot_check_read_all_fn__1217000013_A_init.Done() { A_arbace_aot_check_read_all_fn__1217000013_A_init.Run(A_arbace_aot_check_read_all_fn__1217000013_A_clinit) } }

func A_arbace_aot_check_read_all_fn__1217000013_A_clinit() { A_arbace_aot_check_read_all_fn__1217000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_read_all_fn__1217000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_read_all_fn__1217000013_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_read_all_fn__1217000013_A_class }

func (t *A_arbace_aot_check_read_all_fn__1217000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_read_all_fn__1217000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_read_all_fn__1217000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_read_all_fn__1217000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_read_all_fn__1217000013_A); return ok }

func A_arbace_aot_check_read_all_fn__1217000013_A_Cast(x any) *A_arbace_aot_check_read_all_fn__1217000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_read_all_fn__1217000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_read_all_fn__1217000013_A_class)) }; return v }



type A_arbace_aot_check_read_all_fn__1217000015_A struct{ jrt.Object; F_r any }

func (t *A_arbace_aot_check_read_all_fn__1217000015_A) Is_Compiler_AOTF0() {}

var A_arbace_aot_check_read_all_fn__1217000015_A_fn_class *jrt.Class

var A_arbace_aot_check_read_all_fn__1217000015_A_init jrt.ClassInit

func A_arbace_aot_check_read_all_fn__1217000015_A_Init() { if !A_arbace_aot_check_read_all_fn__1217000015_A_init.Done() { A_arbace_aot_check_read_all_fn__1217000015_A_init.Run(A_arbace_aot_check_read_all_fn__1217000015_A_clinit) } }

func A_arbace_aot_check_read_all_fn__1217000015_A_clinit() { A_arbace_aot_check_read_all_fn__1217000015_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_aot_check_read_all_fn__1217000015_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check_read_all_fn__1217000015_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check_read_all_fn__1217000015_A_class }

func (t *A_arbace_aot_check_read_all_fn__1217000015_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check_read_all_fn__1217000015_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check_read_all_fn__1217000015_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check_read_all_fn__1217000015_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check_read_all_fn__1217000015_A); return ok }

func A_arbace_aot_check_read_all_fn__1217000015_A_Cast(x any) *A_arbace_aot_check_read_all_fn__1217000015_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check_read_all_fn__1217000015_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check_read_all_fn__1217000015_A_class)) }; return v }
