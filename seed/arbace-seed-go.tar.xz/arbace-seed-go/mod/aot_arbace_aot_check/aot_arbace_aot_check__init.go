//line aot_arbace_aot_check__init.ae:1
package aot_arbace_aot_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_aot_check__init_A_Unit0__O() any { A_arbace_aot_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_aot_check__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_aot_check__init_A_const_1) }
//line :1:1
func A_arbace_aot_check__init_A_Unit1__O() any { A_arbace_aot_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_aot_check__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_aot_check__init_A_const_2)) }
//line :1:1
func A_arbace_aot_check__init_A_Unit2__O() any { A_arbace_aot_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_New(); var tmp2 *jrt.Class; A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_Init(); tmp2 = A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_aot_check__init_A_Unit3__O() any { A_arbace_aot_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_aot_check__init_A_const_1)).Equals_O__Z(A_arbace_aot_check__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_aot_check_eval1217000008_fn__1217000009_A_New(); var tmp2 *jrt.Class; A_arbace_aot_check_eval1217000008_fn__1217000009_A_Init(); tmp2 = A_arbace_aot_check_eval1217000008_fn__1217000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_aot_check__init_A_Load__O() any { A_arbace_aot_check__init_A_Init(); A_arbace_aot_check__init_A_Unit0__O(); A_arbace_aot_check__init_A_Unit1__O(); A_arbace_aot_check__init_A_Unit2__O(); A_arbace_aot_check__init_A_Unit3__O(); A_arbace_aot_check__init_A_Unit4__O(); A_arbace_aot_check__init_A_Unit5__O(); return nil }







func A_arbace_aot_check__init_A_Unit4__O() any { A_arbace_aot_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var = A_arbace_aot_check__init_A_const_4; var tmp2 any = A_arbace_aot_check_read_all_A_New(); var tmp3 *jrt.Class; A_arbace_aot_check_read_all_A_Init(); tmp3 = A_arbace_aot_check_read_all_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_check__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_check__init_A_const_5)); return A_arbace_aot_check__init_A_const_4.Ref() }




func A_arbace_aot_check__init_A_Unit5__O() any { A_arbace_aot_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_aot_check__init_A_const_6; var tmp2 any = A_arbace_aot_check_check_A_New(); var tmp3 *jrt.Class; A_arbace_aot_check_check_A_Init(); tmp3 = A_arbace_aot_check_check_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_aot_check__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_aot_check__init_A_const_7)); return A_arbace_aot_check__init_A_const_6.Ref() }



type A_arbace_aot_check__init_A struct{ jrt.Object }

var A_arbace_aot_check__init_A_const_0 *lang.Var

var A_arbace_aot_check__init_A_const_1 any

var A_arbace_aot_check__init_A_const_2 any

var A_arbace_aot_check__init_A_const_3 any

var A_arbace_aot_check__init_A_const_4 *lang.Var

var A_arbace_aot_check__init_A_const_5 any

var A_arbace_aot_check__init_A_const_6 *lang.Var

var A_arbace_aot_check__init_A_const_7 any

var A_arbace_aot_check__init_A_init jrt.ClassInit

func A_arbace_aot_check__init_A_Init() { if !A_arbace_aot_check__init_A_init.Done() { A_arbace_aot_check__init_A_init.Run(A_arbace_aot_check__init_A_clinit) } }

func A_arbace_aot_check__init_A_clinit() { A_arbace_aot_check__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_120); A_arbace_aot_check__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_17)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19))); A_arbace_aot_check__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19)); A_arbace_aot_check__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_aot_check__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_17, Lit_47); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_aot_check__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_125).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), Lit_126)); A_arbace_aot_check__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_17, Lit_127); A_arbace_aot_check__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_125).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), Lit_126)) }

func A_arbace_aot_check__init_A_New() *A_arbace_aot_check__init_A { A_arbace_aot_check__init_A_Init(); t := &A_arbace_aot_check__init_A{}; t.Ctor(); return t }

func (t *A_arbace_aot_check__init_A) Ctor() {}

func (t *A_arbace_aot_check__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_aot_check__init_A) GetClass__Class() *jrt.Class { return A_arbace_aot_check__init_A_class }

func (t *A_arbace_aot_check__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_aot_check__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_aot_check__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_aot_check__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_aot_check__init_A); return ok }

func A_arbace_aot_check__init_A_Cast(x any) *A_arbace_aot_check__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_aot_check__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_aot_check__init_A_class)) }; return v }
