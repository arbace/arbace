//line a2g_classes.ae:1
package aot_arbace_aot_check

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_aot_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_A_New()}; return nil }

var A_arbace_aot_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_check_A_new}

var A_arbace_aot_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_A"})

func init() { i := A_arbace_aot_check_A_class.Info(); i.IsInstance = A_arbace_aot_check_A_InstanceOf; i.Init = A_arbace_aot_check_A_Init; i.Table = A_arbace_aot_check_A_members; jrt.RegisterGoType(A_arbace_aot_check_A_class, reflect.TypeFor[A_arbace_aot_check_A]()) }

func A_arbace_aot_check_check_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_A_New()}; return nil }

func A_arbace_aot_check_check_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_A_fn_class)}; return nil }

var A_arbace_aot_check_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_A_invoke, New: A_arbace_aot_check_check_A_new, Get: A_arbace_aot_check_check_A_get}

var A_arbace_aot_check_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_A_class, Simple: "check", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_A_InstanceOf; i.Init = A_arbace_aot_check_check_A_Init; i.Table = A_arbace_aot_check_check_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_A_class, reflect.TypeFor[A_arbace_aot_check_check_A]()) }

func A_arbace_aot_check_check_fn__1217000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_fn__1217000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000019_A_New()}; return nil }

func A_arbace_aot_check_check_fn__1217000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000019_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000019_A_invoke, New: A_arbace_aot_check_check_fn__1217000019_A_new, Get: A_arbace_aot_check_check_fn__1217000019_A_get}

var A_arbace_aot_check_check_fn__1217000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_check_A_class, Simple: "fn__1217000019", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000019_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000019_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000019_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000019_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000019_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000019_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000019_A]()) }

func A_arbace_aot_check_check_fn__1217000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000037_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_check_fn__1217000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000037_A_New()}; return nil }

func A_arbace_aot_check_check_fn__1217000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000037_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000037_A_invoke, New: A_arbace_aot_check_check_fn__1217000037_A_new, Get: A_arbace_aot_check_check_fn__1217000037_A_get}

var A_arbace_aot_check_check_fn__1217000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_check_A_class, Simple: "fn__1217000037", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000037_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000037_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000037_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000037_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000037_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000037_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000037_A]()) }

func A_arbace_aot_check_check_fn__1217000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000039_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_check_check_fn__1217000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000039_A_New()}; return nil }

func A_arbace_aot_check_check_fn__1217000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000039_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000039_A_invoke, New: A_arbace_aot_check_check_fn__1217000039_A_new, Get: A_arbace_aot_check_check_fn__1217000039_A_get}

var A_arbace_aot_check_check_fn__1217000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_aot_check_check_A_class, Simple: "fn__1217000039", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000039_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000039_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000039_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000039_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000039_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000039_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000039_A]()) }

func A_arbace_aot_check_check_fn__1217000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000041_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000041_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000041_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000041_A_invoke, New: A_arbace_aot_check_check_fn__1217000041_A_new, Get: A_arbace_aot_check_check_fn__1217000041_A_get}

var A_arbace_aot_check_check_fn__1217000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_check_A_class, Simple: "fn__1217000041", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000041_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000041_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000041_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000041_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000041_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000041_A]()) }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_New_O(args[0])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_invoke, New: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_new, Get: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_get}

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_check_fn__1217000041_A_class, Simple: "iter__1217000042__1217000046", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A]()) }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_invoke, New: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_new, Get: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_get}

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046$fn__1217000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class, Simple: "fn__1217000047", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A]()) }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_invoke, New: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_new, Get: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_get}

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046$fn__1217000047$fn__1217000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class, Simple: "fn__1217000048", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A]()) }

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_New_O(args[0])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_invoke, New: A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_new, Get: A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_get}

var A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000041$lap__1217000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_check_fn__1217000041_A_class, Simple: "lap__1217000054", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A]()) }

func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_New_O(args[0])}; return nil }

func A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_fn_class)}; return nil }

var A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_invoke, New: A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_new, Get: A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_get}

var A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$fn__1217000041$try_BANG___1217000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_aot_check_check_fn__1217000041_A_class, Simple: "try_BANG___1217000052", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_InstanceOf; i.Init = A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_Init; i.Table = A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_class, reflect.TypeFor[A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A]()) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_iter__1217000021__1217000027_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_iter__1217000021__1217000027_A_New()}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_iter__1217000021__1217000027_A_fn_class)}; return nil }

var A_arbace_aot_check_check_iter__1217000021__1217000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_iter__1217000021__1217000027_A_invoke, New: A_arbace_aot_check_check_iter__1217000021__1217000027_A_new, Get: A_arbace_aot_check_check_iter__1217000021__1217000027_A_get}

var A_arbace_aot_check_check_iter__1217000021__1217000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$iter__1217000021__1217000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_check_A_class, Simple: "iter__1217000021__1217000027", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_iter__1217000021__1217000027_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_iter__1217000021__1217000027_A_InstanceOf; i.Init = A_arbace_aot_check_check_iter__1217000021__1217000027_A_Init; i.Table = A_arbace_aot_check_check_iter__1217000021__1217000027_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_iter__1217000021__1217000027_A_class, reflect.TypeFor[A_arbace_aot_check_check_iter__1217000021__1217000027_A]()) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_fn_class)}; return nil }

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_invoke, New: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_new, Get: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_get}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_check_iter__1217000021__1217000027_A_class, Simple: "fn__1217000028", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_InstanceOf; i.Init = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_Init; i.Table = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class, reflect.TypeFor[A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A]()) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_New()}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_fn_class)}; return nil }

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_invoke, New: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_new, Get: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_get}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class, Simple: "iter__1217000023__1217000029", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_InstanceOf; i.Init = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_Init; i.Table = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class, reflect.TypeFor[A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A]()) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_fn_class)}; return nil }

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_invoke, New: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_new, Get: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_get}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029$fn__1217000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class, Simple: "fn__1217000030", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_InstanceOf; i.Init = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_Init; i.Table = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class, reflect.TypeFor[A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A]()) }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_fn_class)}; return nil }

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_invoke, New: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_new, Get: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_get}

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029$fn__1217000030$fn__1217000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class, Simple: "fn__1217000031", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_class.Info(); i.IsInstance = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_InstanceOf; i.Init = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_Init; i.Table = A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_members; jrt.RegisterGoType(A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_class, reflect.TypeFor[A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A]()) }

func A_arbace_aot_check_eval1217000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_eval1217000004_A_New()}; return nil }

var A_arbace_aot_check_eval1217000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_check_eval1217000004_A_new}

var A_arbace_aot_check_eval1217000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$eval1217000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_check_A_class, Simple: "eval1217000004", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000004_A"})

func init() { i := A_arbace_aot_check_eval1217000004_A_class.Info(); i.IsInstance = A_arbace_aot_check_eval1217000004_A_InstanceOf; i.Table = A_arbace_aot_check_eval1217000004_A_members; jrt.RegisterGoType(A_arbace_aot_check_eval1217000004_A_class, reflect.TypeFor[A_arbace_aot_check_eval1217000004_A]()) }

func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_New()}; return nil }

func A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_fn_class)}; return nil }

var A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_invoke, New: A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_new, Get: A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_get}

var A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$eval1217000004$loading__1927001464__auto____1217000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_eval1217000004_A_class, Simple: "loading__1927001464__auto____1217000005", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_class.Info(); i.IsInstance = A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_InstanceOf; i.Init = A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_Init; i.Table = A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_members; jrt.RegisterGoType(A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_class, reflect.TypeFor[A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A]()) }

func A_arbace_aot_check_eval1217000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_eval1217000008_A_New()}; return nil }

var A_arbace_aot_check_eval1217000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_check_eval1217000008_A_new}

var A_arbace_aot_check_eval1217000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$eval1217000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_check_A_class, Simple: "eval1217000008", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000008_A"})

func init() { i := A_arbace_aot_check_eval1217000008_A_class.Info(); i.IsInstance = A_arbace_aot_check_eval1217000008_A_InstanceOf; i.Table = A_arbace_aot_check_eval1217000008_A_members; jrt.RegisterGoType(A_arbace_aot_check_eval1217000008_A_class, reflect.TypeFor[A_arbace_aot_check_eval1217000008_A]()) }

func A_arbace_aot_check_eval1217000008_fn__1217000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_eval1217000008_fn__1217000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_eval1217000008_fn__1217000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_eval1217000008_fn__1217000009_A_New()}; return nil }

func A_arbace_aot_check_eval1217000008_fn__1217000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_eval1217000008_fn__1217000009_A_fn_class)}; return nil }

var A_arbace_aot_check_eval1217000008_fn__1217000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_eval1217000008_fn__1217000009_A_invoke, New: A_arbace_aot_check_eval1217000008_fn__1217000009_A_new, Get: A_arbace_aot_check_eval1217000008_fn__1217000009_A_get}

var A_arbace_aot_check_eval1217000008_fn__1217000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$eval1217000008$fn__1217000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_eval1217000008_A_class, Simple: "fn__1217000009", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000008_fn__1217000009_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_eval1217000008_fn__1217000009_A_class.Info(); i.IsInstance = A_arbace_aot_check_eval1217000008_fn__1217000009_A_InstanceOf; i.Init = A_arbace_aot_check_eval1217000008_fn__1217000009_A_Init; i.Table = A_arbace_aot_check_eval1217000008_fn__1217000009_A_members; jrt.RegisterGoType(A_arbace_aot_check_eval1217000008_fn__1217000009_A_class, reflect.TypeFor[A_arbace_aot_check_eval1217000008_fn__1217000009_A]()) }

func A_arbace_aot_check_read_all_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_read_all_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_read_all_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_read_all_A_New()}; return nil }

func A_arbace_aot_check_read_all_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_read_all_A_fn_class)}; return nil }

var A_arbace_aot_check_read_all_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_read_all_A_invoke, New: A_arbace_aot_check_read_all_A_new, Get: A_arbace_aot_check_read_all_A_get}

var A_arbace_aot_check_read_all_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$read_all", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_A_class, Simple: "read_all", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_read_all_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_read_all_A_class.Info(); i.IsInstance = A_arbace_aot_check_read_all_A_InstanceOf; i.Init = A_arbace_aot_check_read_all_A_Init; i.Table = A_arbace_aot_check_read_all_A_members; jrt.RegisterGoType(A_arbace_aot_check_read_all_A_class, reflect.TypeFor[A_arbace_aot_check_read_all_A]()) }

func A_arbace_aot_check_read_all_fn__1217000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_read_all_fn__1217000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_aot_check_read_all_fn__1217000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_read_all_fn__1217000013_A_New()}; return nil }

func A_arbace_aot_check_read_all_fn__1217000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_read_all_fn__1217000013_A_fn_class)}; return nil }

var A_arbace_aot_check_read_all_fn__1217000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_read_all_fn__1217000013_A_invoke, New: A_arbace_aot_check_read_all_fn__1217000013_A_new, Get: A_arbace_aot_check_read_all_fn__1217000013_A_get}

var A_arbace_aot_check_read_all_fn__1217000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$read_all$fn__1217000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_aot_check_read_all_A_class, Simple: "fn__1217000013", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_read_all_fn__1217000013_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_read_all_fn__1217000013_A_class.Info(); i.IsInstance = A_arbace_aot_check_read_all_fn__1217000013_A_InstanceOf; i.Init = A_arbace_aot_check_read_all_fn__1217000013_A_Init; i.Table = A_arbace_aot_check_read_all_fn__1217000013_A_members; jrt.RegisterGoType(A_arbace_aot_check_read_all_fn__1217000013_A_class, reflect.TypeFor[A_arbace_aot_check_read_all_fn__1217000013_A]()) }

func A_arbace_aot_check_read_all_fn__1217000015_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_aot_check_read_all_fn__1217000015_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_aot_check_read_all_fn__1217000015_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_read_all_fn__1217000015_A_New_O(args[0])}; return nil }

func A_arbace_aot_check_read_all_fn__1217000015_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_aot_check_read_all_fn__1217000015_A_fn_class)}; return nil }

var A_arbace_aot_check_read_all_fn__1217000015_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_aot_check_read_all_fn__1217000015_A_invoke, New: A_arbace_aot_check_read_all_fn__1217000015_A_new, Get: A_arbace_aot_check_read_all_fn__1217000015_A_get}

var A_arbace_aot_check_read_all_fn__1217000015_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$read_all$fn__1217000015", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_aot_check_read_all_A_class, Simple: "fn__1217000015", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_read_all_fn__1217000015_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check_read_all_fn__1217000015_A_class.Info(); i.IsInstance = A_arbace_aot_check_read_all_fn__1217000015_A_InstanceOf; i.Init = A_arbace_aot_check_read_all_fn__1217000015_A_Init; i.Table = A_arbace_aot_check_read_all_fn__1217000015_A_members; jrt.RegisterGoType(A_arbace_aot_check_read_all_fn__1217000015_A_class, reflect.TypeFor[A_arbace_aot_check_read_all_fn__1217000015_A]()) }

func A_arbace_aot_check__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_aot_check__init_A_Load__O(); case 1: return A_arbace_aot_check__init_A_Unit0__O(); case 2: return A_arbace_aot_check__init_A_Unit1__O(); case 3: return A_arbace_aot_check__init_A_Unit2__O(); case 4: return A_arbace_aot_check__init_A_Unit3__O(); case 5: return A_arbace_aot_check__init_A_Unit4__O(); case 6: return A_arbace_aot_check__init_A_Unit5__O()}; return nil }

func A_arbace_aot_check__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check__init_A_New()}; return nil }

var A_arbace_aot_check__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_aot_check__init_A_invoke, New: A_arbace_aot_check__init_A_new}

var A_arbace_aot_check__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check__init_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check__init_A_class.Info(); i.IsInstance = A_arbace_aot_check__init_A_InstanceOf; i.Init = A_arbace_aot_check__init_A_Init; i.Table = A_arbace_aot_check__init_A_members; jrt.RegisterGoType(A_arbace_aot_check__init_A_class, reflect.TypeFor[A_arbace_aot_check__init_A]()) }
