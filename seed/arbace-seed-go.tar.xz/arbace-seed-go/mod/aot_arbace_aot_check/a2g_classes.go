//line a2g_classes.ae:1
package aot_arbace_aot_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_aot_check_check_A_class, Name: "arbace.aot.check$check", Modifiers: 25, Simple: "check", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_A", Source: "check.ae", Declaring: &A_arbace_aot_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000019_A_class, Name: "arbace.aot.check$check$fn__1217000019", Modifiers: 25, Simple: "fn__1217000019", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000019_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000037_A_class, Name: "arbace.aot.check$check$fn__1217000037", Modifiers: 25, Simple: "fn__1217000037", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000037_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000039_A_class, Name: "arbace.aot.check$check$fn__1217000039", Modifiers: 25, Simple: "fn__1217000039", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000039_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000041_A_class, Name: "arbace.aot.check$check$fn__1217000041", Modifiers: 25, Simple: "fn__1217000041", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class, Name: "arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046", Modifiers: 25, Simple: "iter__1217000042__1217000046", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_fn__1217000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class, Name: "arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046$fn__1217000047", Modifiers: 25, Simple: "fn__1217000047", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_class, Name: "arbace.aot.check$check$fn__1217000041$iter__1217000042__1217000046$fn__1217000047$fn__1217000048", Modifiers: 25, Simple: "fn__1217000048", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_class, Name: "arbace.aot.check$check$fn__1217000041$lap__1217000054", Modifiers: 25, Simple: "lap__1217000054", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_fn__1217000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_class, Name: "arbace.aot.check$check$fn__1217000041$try_BANG___1217000052", Modifiers: 25, Simple: "try_BANG___1217000052", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_fn__1217000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_iter__1217000021__1217000027_A_class, Name: "arbace.aot.check$check$iter__1217000021__1217000027", Modifiers: 25, Simple: "iter__1217000021__1217000027", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class, Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028", Modifiers: 25, Simple: "fn__1217000028", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_iter__1217000021__1217000027_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class, Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029", Modifiers: 25, Simple: "iter__1217000023__1217000029", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class, Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029$fn__1217000030", Modifiers: 25, Simple: "fn__1217000030", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_class, Name: "arbace.aot.check$check$iter__1217000021__1217000027$fn__1217000028$iter__1217000023__1217000029$fn__1217000030$fn__1217000031", Modifiers: 25, Simple: "fn__1217000031", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A", Source: "check.ae", Declaring: &A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_class, Name: "arbace.aot.check$eval1217000004$loading__1927001464__auto____1217000005", Modifiers: 25, Simple: "loading__1927001464__auto____1217000005", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A", Source: "check.ae", Declaring: &A_arbace_aot_check_eval1217000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_eval1217000008_fn__1217000009_A_class, Name: "arbace.aot.check$eval1217000008$fn__1217000009", Modifiers: 25, Simple: "fn__1217000009", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000008_fn__1217000009_A", Source: "check.ae", Declaring: &A_arbace_aot_check_eval1217000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_read_all_A_class, Name: "arbace.aot.check$read_all", Modifiers: 25, Simple: "read_all", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_read_all_A", Source: "check.ae", Declaring: &A_arbace_aot_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_read_all_fn__1217000013_A_class, Name: "arbace.aot.check$read_all$fn__1217000013", Modifiers: 25, Simple: "fn__1217000013", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_read_all_fn__1217000013_A", Source: "check.ae", Declaring: &A_arbace_aot_check_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_aot_check_read_all_fn__1217000015_A_class, Name: "arbace.aot.check$read_all$fn__1217000015", Modifiers: 25, Simple: "fn__1217000015", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_read_all_fn__1217000015_A", Source: "check.ae", Declaring: &A_arbace_aot_check_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_aot_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_A_New()}; return nil }

var A_arbace_aot_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_check_A_new}

var A_arbace_aot_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_A"})

func init() { i := A_arbace_aot_check_A_class.Info(); i.IsInstance = A_arbace_aot_check_A_InstanceOf; i.Init = A_arbace_aot_check_A_Init; i.Table = A_arbace_aot_check_A_members }

var A_arbace_aot_check_check_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000019_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000037_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000039_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_iter__1217000042__1217000046_fn__1217000047_fn__1217000048_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_lap__1217000054_A_class *jrt.Class

var A_arbace_aot_check_check_fn__1217000041_try_BANG___1217000052_A_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_A_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_A_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_A_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_A_class *jrt.Class

var A_arbace_aot_check_check_iter__1217000021__1217000027_fn__1217000028_iter__1217000023__1217000029_fn__1217000030_fn__1217000031_A_class *jrt.Class

func A_arbace_aot_check_eval1217000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_eval1217000004_A_New()}; return nil }

var A_arbace_aot_check_eval1217000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_check_eval1217000004_A_new}

var A_arbace_aot_check_eval1217000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$eval1217000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_check_A_class, Simple: "eval1217000004", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000004_A"})

func init() { i := A_arbace_aot_check_eval1217000004_A_class.Info(); i.IsInstance = A_arbace_aot_check_eval1217000004_A_InstanceOf; i.Table = A_arbace_aot_check_eval1217000004_A_members }

var A_arbace_aot_check_eval1217000004_loading__1927001464__auto____1217000005_A_class *jrt.Class

func A_arbace_aot_check_eval1217000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check_eval1217000008_A_New()}; return nil }

var A_arbace_aot_check_eval1217000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_aot_check_eval1217000008_A_new}

var A_arbace_aot_check_eval1217000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check$eval1217000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_aot_check_A_class, Simple: "eval1217000008", Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check_eval1217000008_A"})

func init() { i := A_arbace_aot_check_eval1217000008_A_class.Info(); i.IsInstance = A_arbace_aot_check_eval1217000008_A_InstanceOf; i.Table = A_arbace_aot_check_eval1217000008_A_members }

var A_arbace_aot_check_eval1217000008_fn__1217000009_A_class *jrt.Class

var A_arbace_aot_check_read_all_A_class *jrt.Class

var A_arbace_aot_check_read_all_fn__1217000013_A_class *jrt.Class

var A_arbace_aot_check_read_all_fn__1217000015_A_class *jrt.Class

func A_arbace_aot_check__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_aot_check__init_A_Load__O()}; return nil }

func A_arbace_aot_check__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_aot_check__init_A_New()}; return nil }

var A_arbace_aot_check__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_aot_check__init_A_invoke, New: A_arbace_aot_check__init_A_new}

var A_arbace_aot_check__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.aot.check__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_aot_check.A_arbace_aot_check__init_A", Source: "check.ae"})

func init() { i := A_arbace_aot_check__init_A_class.Info(); i.IsInstance = A_arbace_aot_check__init_A_InstanceOf; i.Init = A_arbace_aot_check__init_A_Init; i.Table = A_arbace_aot_check__init_A_members }
