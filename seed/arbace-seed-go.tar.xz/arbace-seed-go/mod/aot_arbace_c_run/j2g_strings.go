//line j2g_strings.ae:1
package aot_arbace_c_run

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.repr.ckn2,asyn2,rcyn18,arbace.repr.c.hostyn4,hostyn14,arbace.c.checkyn3,chkyn19,arbace.repr.c.annotyn5,annotyn14,arbace.c.buildyn5,buildyn13,arbace.stringyn3,stryn11,arbace.corekn3,docyn11,long-doubleyn3,litkn4,linekn6,columnkn4,argskn3,stdkn7,resultskn12,ldouble-sizekn13,unsigned-charkn10,permissivekn2,rdkn6,errorskn5,errorkn6,statuskn10,read-errorkn7,messagekn7,refusedkn12,read-refusedkn4,elsekn11,check-errorkn2,okkn4,textys16,arbace.c.runtime9,link-textks2,ci7,refusedkn5,classkn7,timeoutkn6,stdoutkn6,differkn2,o2kn4,failkn4,passkn11,regressionskn8,improvedkn6,absentkn5,levelkn7,subjectkn9,referencekn4,leftkn10,not-judgedkn6,passeskn7,differskn2,idkn3,runkn6,appendkn5,matchys16,arbace.c.runtime7,librarykn5,formskn5,titlev11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,v11,arbace.core5,referR13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn12,arbace.c.runm2,R14,s460,ci's programs (doc/C23-SURVEY.md §6, \"As built: C5 (write-ahead)\"): C files read by repr/c, checked\n  (arbace.c.check with its per-form results, CS95 (a), long double as double, CS35), linked with musl's\n  units (arbace.c.musl) and built into a node program (arbace.c.build) for ci's back end. On the light path\n  the node program is written for tools/cirun; on the executable arbace.c.repl hands it to\n  arbace.lang.CInterp. bin/ci run and check call `-main`.R15,v11,arbace.core4,seq?R16,v11,arbace.core5,firstR15,v11,arbace.core6,secondv11,arbace.core7,vector?v11,arbace.core4,somev11,arbace.core4,map?v11,arbace.core4,valsv11,arbace.core6,dissocR17,R18,S1,s15,-funsigned-charR19,v14,arbace.c.check10,check-unitv11,arbace.core7,keywordR20,v19,arbace.repr.c.annot13,builtin-formsR21,R22,l8,R23,R24,R25,R26,v18,arbace.repr.c.host11,file-configv13,arbace.repr.c6,read-cv18,arbace.repr.c.host6,configv11,arbace.core19,pop-thread-bindingsR27,R28,R29,R30,v13,arbace.string4,joinv11,arbace.core4,takel3,R31,R32,v11,arbace.core4,nameR33,v12,arbace.c.run10,check-readv11,arbace.core6,updatev11,arbace.core3,vecv11,arbace.core6,removev11,arbace.core7,re-findp32,implicit declaration of functionv11,arbace.core3,seqv11,arbace.core5,assocR34,R35,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv21,arbace.repr.c.convert16,*include-inside*v16,arbace.repr.c.pp9,*reentry*R36,v12,arbace.c.run6,*musl*v11,arbace.core7,resolveR37,v14,arbace.c.build9,link-textv11,arbace.core4,mapvv14,arbace.c.build13,unit-fragmentR38,v11,arbace.core7,ex-dataR39,v13,arbace.string5,splitp2,\\tl-1,v13,arbace.string6,blank?v13,arbace.string11,split-linesv11,arbace.core5,slurpv11,arbace.core4,readv11,arbace.core4,not=R40,R41,p48,^(ci(run|aot): internal|fatal error: |runtime: )v11,arbace.core3,strR42,R43,R44,R45,v11,arbace.core8,keyword?v11,arbace.core11,read-stringv13,arbace.string12,starts-with?v11,arbace.core4,intov11,arbace.core3,mapv11,arbace.core4,juxtv11,arbace.core8,identityv11,arbace.core6,filterR46,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restR47,R48,v11,arbace.core3,notv11,arbace.core9,contains?v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core6,concatl40,v11,arbace.core7,printlnv11,arbace.core6,pr-strl10,v11,arbace.core7,filtervR49,R50,R51,p1,/R52,v11,arbace.core3,setv12,arbace.c.run3,tsvR53,v12,arbace.c.run6,resultR54,R55,R56,v12,arbace.c.run14,control-resultS2,R54,R53,S2,R54,R53,v12,arbace.c.run8,controlsR57,v11,arbace.core9,not-emptyv11,arbace.core4,spitv11,arbace.core5,applyR58,v12,arbace.c.run14,report-failingS1,s8,--recordS2,s0,s8,--recordv12,arbace.c.run21,subset-record-refusalv12,arbace.c.run14,read-all-formsR59,v13,arbace.string7,replacev12,arbace.c.run14,compare-recordv12,arbace.c.run13,report-recordv12,arbace.c.run16,controls-failingv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core7,sort-byv11,arbace.core11,frequenciesv11,arbace.core6,formatv11,arbace.core4,compv11,arbace.core1,-v11,arbace.core3,valv18,arbace.repr.c.host9,load-hostv11,arbace.core10,drop-whilev11,arbace.core5,nnextv11,arbace.core4,subsl6,v12,arbace.c.run9,read-unitv12,arbace.c.run5,nodesv12,arbace.c.run5,judgev11,arbace.core17,requiring-resolveR60,p8,[\\t\\n\\r]v11,arbace.core5,doallv11,arbace.core11,future-callp2,\\tp1, v12,arbace.c.run17,uses-long-double?R61,v11,arbace.core5,classv11,arbace.core5,rangev11,arbace.core8,group-byR60,v11,arbace.core4,sortR62,")

var Lit_1 *jrt.String = jrt.Intern("nodes")

var Lit_2 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000259")

var Lit_3 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000261")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000263")

var Lit_5 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000265")

var Lit_6 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000267")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000269")

var Lit_8 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000271")

var Lit_9 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000273")

var Lit_10 *jrt.String = jrt.Intern("CI_NO_MUSL")

var Lit_11 *jrt.String = jrt.Intern("user.dir")

var Lit_12 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000275")

var Lit_13 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000277")

var Lit_14 *jrt.String = jrt.Intern("judge")

var Lit_15 *jrt.String = jrt.Intern("nodes-list")

var Lit_16 *jrt.String = jrt.Intern("arbace.c.run$_main$clean__49000282")

var Lit_17 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288")

var Lit_18 *jrt.String = jrt.Intern("3")

var Lit_19 *jrt.String = jrt.Intern("/nodes.tsv")

var Lit_20 *jrt.String = jrt.Intern("\n")

var Lit_21 *jrt.String = jrt.Intern("divergences")

var Lit_22 *jrt.String = jrt.Intern("test/c/check-known.edn")

var Lit_23 *jrt.String = jrt.Intern("arbace.c.run$_main$klass__49000320")

var Lit_24 *jrt.String = jrt.Intern("arbace.c.run$_main$fn__49000329")

var Lit_25 *jrt.String = jrt.Intern("programs,")

var Lit_26 *jrt.String = jrt.Intern("pass")

var Lit_27 *jrt.String = jrt.Intern("  %-22s %5d  %s")

var Lit_28 *jrt.String = jrt.Intern("UNCLASSED")

var Lit_29 *jrt.String = jrt.Intern("ci: nodes, nodes-list, judge")

var Lit_30 *jrt.String = jrt.Intern(" ")

var Lit_31 *jrt.String = jrt.Intern("-o")

var Lit_32 *jrt.String = jrt.Intern("--std=")

var Lit_33 *jrt.String = jrt.Intern("-std=")

var Lit_34 *jrt.String = jrt.Intern("-")

var Lit_35 *jrt.String = jrt.Intern(".")

var Lit_36 *jrt.String = jrt.Intern(": ")

var Lit_37 *jrt.String = jrt.Intern("refused (")

var Lit_38 *jrt.String = jrt.Intern("): ")

var Lit_39 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289")

var Lit_40 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289$fn__49000290")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289$fn__49000301")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289$fn__49000290$fn__49000291")

var Lit_43 *jrt.String = jrt.Intern("")

var Lit_44 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289$fn__49000290$fn__49000291$fn__49000295")

var Lit_45 *jrt.String = jrt.Intern("\t")

var Lit_46 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289$fn__49000290$fn__49000291$fn__49000295$fn__49000296")

var Lit_47 *jrt.String = jrt.Intern("long-double")

var Lit_48 *jrt.String = jrt.Intern("/")

var Lit_49 *jrt.String = jrt.Intern(".nodes")

var Lit_50 *jrt.String = jrt.Intern("ok")

var Lit_51 *jrt.String = jrt.Intern("refused")

var Lit_52 *jrt.String = jrt.Intern("build-error")

var Lit_53 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289$fn__49000301$fn__49000305")

var Lit_54 *jrt.String = jrt.Intern("arbace.c.run$_main$iter__49000284__49000288$fn__49000289$fn__49000301$fn__49000305$fn__49000306")

var Lit_55 *jrt.String = jrt.Intern("arbace.c.run$_main$klass__49000320$fn__49000324")

var Lit_56 *jrt.String = jrt.Intern("arbace.c.run$_main$klass__49000320$fn__49000324$fn__49000325")

var Lit_57 *jrt.String = jrt.Intern("arbace.c.run$compare_record$in_QMARK___49000041")

var Lit_58 *jrt.String = jrt.Intern("arbace.c.run$compare_record$fn__49000045")

var Lit_59 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000047__49000051")

var Lit_60 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000063__49000067")

var Lit_61 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000079__49000083")

var Lit_62 *jrt.String = jrt.Intern("arbace.c.run$compare_record$in_QMARK___49000041$fn__49000042")

var Lit_63 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000047__49000051$fn__49000052")

var Lit_64 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000047__49000051$fn__49000052$fn__49000053")

var Lit_65 *jrt.String = jrt.Intern("known ")

var Lit_66 *jrt.String = jrt.Intern("recorded ")

var Lit_67 *jrt.String = jrt.Intern(", now ")

var Lit_68 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000063__49000067$fn__49000068")

var Lit_69 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000063__49000067$fn__49000068$fn__49000069")

var Lit_70 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000079__49000083$fn__49000084")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.run$compare_record$iter__49000079__49000083$fn__49000084$fn__49000085")

var Lit_72 *jrt.String = jrt.Intern("/list.tsv")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.run$control_result$fn__49000131")

var Lit_74 *jrt.String = jrt.Intern("arbace.c.run$control_result$fn__49000133")

var Lit_75 *jrt.String = jrt.Intern("/run.tsv")

var Lit_76 *jrt.String = jrt.Intern("arbace.c.run$controls$fn__49000123")

var Lit_77 *jrt.String = jrt.Intern("test/c/controls.edn")

var Lit_78 *jrt.String = jrt.Intern("arbace.c.run$controls_failing$iter__49000136__49000140")

var Lit_79 *jrt.String = jrt.Intern("arbace.c.run$controls_failing$iter__49000136__49000140$fn__49000141")

var Lit_80 *jrt.String = jrt.Intern("arbace.c.run$controls_failing$iter__49000136__49000140$fn__49000141$fn__49000142")

var Lit_81 *jrt.String = jrt.Intern(": control not judged: ")

var Lit_82 *jrt.String = jrt.Intern(" has no gcc run")

var Lit_83 *jrt.String = jrt.Intern(": control ")

var Lit_84 *jrt.String = jrt.Intern(": left (")

var Lit_85 *jrt.String = jrt.Intern(" not in the run, not built or not run)")

var Lit_86 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_87 *jrt.String = jrt.Intern("control ")

var Lit_88 *jrt.String = jrt.Intern(" (test/c/controls.edn)")

var Lit_89 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000173")

var Lit_90 *jrt.String = jrt.Intern("arbace.c.run$judge$klass__49000176")

var Lit_91 *jrt.String = jrt.Intern("arbace.c.run$judge$iter__49000185__49000191")

var Lit_92 *jrt.String = jrt.Intern("test/c/check-linux-amd64.edn")

var Lit_93 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000207")

var Lit_94 *jrt.String = jrt.Intern("/results.edn")

var Lit_95 *jrt.String = jrt.Intern("[\n")

var Lit_96 *jrt.String = jrt.Intern("\n]\n")

var Lit_97 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000213")

var Lit_98 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000215")

var Lit_99 *jrt.String = jrt.Intern("%-24s %5d programs: %s")

var Lit_100 *jrt.String = jrt.Intern(", ")

var Lit_101 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000218")

var Lit_102 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000223")

var Lit_103 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000225")

var Lit_104 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000228")

var Lit_105 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000234")

var Lit_106 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000242")

var Lit_107 *jrt.String = jrt.Intern(";; ci's check (bin/ci check --record): each program of the run corpora, [ID RESULT REASON],\n")

var Lit_108 *jrt.String = jrt.Intern(";; against gcc 15.2's -O0 run (test/c/ref-gcc15.edn); its classes test/c/divergences.edn.\n[\n")

var Lit_109 *jrt.String = jrt.Intern("recorded")

var Lit_110 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000247")

var Lit_111 *jrt.String = jrt.Intern("ci judge")

var Lit_112 *jrt.String = jrt.Intern("ci judge:")

var Lit_113 *jrt.String = jrt.Intern("arbace.c.run$judge$fn__49000234$fn__49000238")

var Lit_114 *jrt.String = jrt.Intern("arbace.c.run$judge$iter__49000185__49000191$fn__49000192")

var Lit_115 *jrt.String = jrt.Intern("arbace.c.run$judge$iter__49000185__49000191$fn__49000192$iter__49000187__49000193")

var Lit_116 *jrt.String = jrt.Intern("arbace.c.run$judge$iter__49000185__49000191$fn__49000192$iter__49000187__49000193$fn__49000194")

var Lit_117 *jrt.String = jrt.Intern("arbace.c.run$judge$iter__49000185__49000191$fn__49000192$iter__49000187__49000193$fn__49000194$fn__49000195")

var Lit_118 *jrt.String = jrt.Intern("torture-execute-mirror/")

var Lit_119 *jrt.String = jrt.Intern("torture-execute/")

var Lit_120 *jrt.String = jrt.Intern("internal: ")

var Lit_121 *jrt.String = jrt.Intern(" (")

var Lit_122 *jrt.String = jrt.Intern(")")

var Lit_123 *jrt.String = jrt.Intern("arbace.c.run$judge$klass__49000176$fn__49000180")

var Lit_124 *jrt.String = jrt.Intern("arbace.c.run$judge$klass__49000176$fn__49000180$fn__49000181")

var Lit_125 *jrt.String = jrt.Intern("gnu23")

var Lit_126 *jrt.String = jrt.Intern("arbace.c.run$read_unit$fn__49000019")

var Lit_127 *jrt.String = jrt.Intern("; ")

var Lit_128 *jrt.String = jrt.Intern("arbace.c.run$read_unit$fn__49000021")

var Lit_129 *jrt.String = jrt.Intern("arbace.c.run$read_unit$fn__49000021$fn__49000022")

var Lit_130 *jrt.String = jrt.Intern("arbace.c.run$report_failing$line__49000154")

var Lit_131 *jrt.String = jrt.Intern("arbace.c.run$report_failing$fn__49000160")

var Lit_132 *jrt.String = jrt.Intern("GATE_FAIL_LINES")

var Lit_133 *jrt.String = jrt.Intern("FAIL ")

var Lit_134 *jrt.String = jrt.Intern("REGRESSION")

var Lit_135 *jrt.String = jrt.Intern("recorded failures now pass (an improvement, not a failure; re-record):")

var Lit_136 *jrt.String = jrt.Intern("recorded rows absent from the run")

var Lit_137 *jrt.String = jrt.Intern("CI_SUBSET")

var Lit_138 *jrt.String = jrt.Intern("(a subset run)")

var Lit_139 *jrt.String = jrt.Intern("arbace.c.run$report_record$fn__49000110")

var Lit_140 *jrt.String = jrt.Intern("arbace.c.run$report_record$fn__49000115")

var Lit_141 *jrt.String = jrt.Intern("regression: ")

var Lit_142 *jrt.String = jrt.Intern("absent from the run")

var Lit_143 *jrt.String = jrt.Intern(" uses-long-double")

var Lit_144 *jrt.String = jrt.Intern("not built")

var Lit_145 *jrt.String = jrt.Intern("not run")

var Lit_146 *jrt.String = jrt.Intern("timeout")

var Lit_147 *jrt.String = jrt.Intern("differ stdout")

var Lit_148 *jrt.String = jrt.Intern("differ status ")

var Lit_149 *jrt.String = jrt.Intern(" (gcc ")

var Lit_150 *jrt.String = jrt.Intern("arbace.c.run$subset_record_refusal$fn__49000119")

var Lit_151 *jrt.String = jrt.Intern("--record records whole corpora: the run judged was a subset (--only or --sample)")

var Lit_152 *jrt.String = jrt.Intern("/subset")

var Lit_153 *jrt.String = jrt.Intern("arbace.c.run$tsv$fn__49000028")

var Lit_154 *jrt.String = jrt.Intern("arbace.c.run$uses_long_double_QMARK_$walk__49000014")

var Lit_155 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn5,formsyn1,hyn2,fcyn2,rdyn4,optskn3,tagyn6,Stringyn5,unitskn7,privateyn2,idyn3,refyn4,nodeyn3,runyn4,rowsyn7,corporakn4,keysyn11,regressionsyn6,absentyn8,improvedyn4,workyn5,levelyn4,refsyn7,subjectyn9,referenceyn3,whoyn7,failingyn4,fileyn4,reffyn4,divfyn1,&yn4,moreyn8,host-diryn4,verbyn4,argsv11,arbace.core5,in-nsMyn12,arbace.c.runm2,R0,s460,ci's programs (doc/C23-SURVEY.md §6, \"As built: C5 (write-ahead)\"): C files read by repr/c, checked\n  (arbace.c.check with its per-form results, CS95 (a), long double as double, CS35), linked with musl's\n  units (arbace.c.musl) and built into a node program (arbace.c.build) for ci's back end. On the light path\n  the node program is written for tools/cirun; on the executable arbace.c.repl hands it to\n  arbace.lang.CInterp. bin/ci run and check call `-main`.m2,R0,s460,ci's programs (doc/C23-SURVEY.md §6, \"As built: C5 (write-ahead)\"): C files read by repr/c, checked\n  (arbace.c.check with its per-form results, CS95 (a), long double as double, CS35), linked with musl's\n  units (arbace.c.musl) and built into a node program (arbace.c.build) for ci's back end. On the light path\n  the node program is written for tools/cirun; on the executable arbace.c.repl hands it to\n  arbace.lang.CInterp. bin/ci run and check call `-main`.R1,v11,arbace.core20,*warn-on-reflection*v12,arbace.c.run6,*musl*m8,R2,TR3,i16,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run17,uses-long-double?m10,R6,L1,V1,R7,R0,s182,Whether a program's main-file forms declare or convert to a long double type (SPEC §12.5's rule for the\n  class long-double): the type symbol anywhere in the forms or their metadata.R3,i18,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run10,check-readm10,R6,L1,V3,R8,R9,R10,R0,s66,A read checked for ci: {:rd :results :std :unsigned-char :errors}.R3,i30,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run9,read-unitm10,R6,L1,V4,R8,R11,Myn4,basem2,R12,R13,Myn4,pathm2,R12,R13,R0,s109,The C file `path` (absolute, or relative to `base`) read and checked: a unit, or {:error ...}/{:refused ...}.R3,i39,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run5,nodesm10,R6,L1,V1,R14,R0,s132,The node program of the units (the program's), linked with musl when *musl* is set: {:text} or\n  {:status :refused :class :message}.R3,i55,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run3,tsvm10,R15,TR6,L1,V1,Myn1,fm2,R12,R13,R3,i68,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run14,read-all-formsm10,R15,TR6,L1,V1,Myn1,fm2,R12,R13,R3,i72,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run6,resultm10,R6,L1,V4,R16,R17,R18,R19,R0,s112,A program's result: [id result reason] (result :pass, :fail, :refused, :read-error, :check-error, :build-error).R3,i76,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run14,compare-recordm10,R6,L1,V3,R20,Myn4,recfm2,R12,R13,R21,R0,s299,A judge's rows against its committed record (review 006, finding 3), for the corpora judged: {:regressions [[id why]]\n  (a row the record passes that does not pass now, whatever its class; a known row whose reason changed), :absent [id]\n  (the record's rows of these corpora the run does not hold)}.R3,i100,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run13,report-recordm10,R6,L1,V1,m2,R22,V3,R23,R24,R25,R0,s154,Prints compare-record's result; the rows that fail because of it (absent rows only when the run is not a subset:\n  CI_SUBSET, set by --only and --sample).R3,i122,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run21,subset-record-refusalm10,R6,L1,V2,R26,R21,R0,s192,Review 027, finding 3: the message refusing --record when the run judged is a subset (CI_SUBSET, or a corpus's\n  WORK/CORPUS/subset marker that a run with --only or --sample leaves), else nil.R3,i133,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run8,controlsm10,R6,L1,V1,R27,R0,s99,GTS81 (a): the negative controls of a level (test/c/controls.edn, :run or :dg); the file must read.R3,i140,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run14,control-resultm10,R6,L1,V4,R26,R28,R21,m2,R22,V2,R29,R30,R0,s271,A :run control judged by result: :differs (it fails: a control must), :passes (the judge passes what differs),\n  :not-judged (the reference has no gcc run), :left (the subject's corpus not judged, the subject not in its list, not\n  built or not run: its own row says so).R3,i145,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run16,controls-failingm10,R6,L1,V4,R31,R26,R28,R21,R0,s100,Each :run control's result printed (who: the judge's name); the failing ones as rows [ID :fail WHY].R3,i164,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run14,report-failingm10,R6,L2,V1,R32,V2,R32,R33,R0,s359,The failing rows' lines FAIL ID<tab>WHY (the tab the steps' one :failed-re reads): the first 40 printed, every one appended to the file GATE_FAIL_LINES names when\n  it is set (the gate's runner reads it with the log for its step's :failed-re: review 181 L3, so that every failing\n  file of a mass regression joins the rotation's subset at once, not 40 a run).R3,i177,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run5,judgem12,R15,TR6,L1,V1,V5,R26,R34,R35,R36,R37,R0,s158,judge WORK REF DIVERGENCES [--record] CORPUS...: each program's result against gcc's run and the classes, and against\n  the committed record (compare-record).R3,i188,R4,i1,R5,s15,arbace/c/run.aev12,arbace.c.run5,-mainm10,R6,L1,V4,R38,R39,R36,R40,R0,s196,bin/ci nodes HOST-DIR [--std S] [OPTION...] -o OUT FILE...: FILE... (one program) read, checked, built\n  into the node program OUT; the exit status 0, else 1 with the reason on the standard error.R3,i236,R4,i1,R5,s15,arbace/c/run.ae")

var Lit_156 *jrt.String = jrt.Intern("arbace.c.run$eval49000004$loading__1927001464__auto____49000005")

var Lit_157 *jrt.String = jrt.Intern("arbace.c.run$eval49000008$fn__49000009")

var Lit_158 *jrt.String = jrt.Intern("arbace.c.run$uses_long_double_QMARK_")

var Lit_159 *jrt.String = jrt.Intern("arbace.c.run$check_read")

var Lit_160 *jrt.String = jrt.Intern("arbace.c.run$read_unit")

var Lit_161 *jrt.String = jrt.Intern("arbace.c.run$nodes")

var Lit_162 *jrt.String = jrt.Intern("arbace.c.run$tsv")

var Lit_163 *jrt.String = jrt.Intern("arbace.c.run$read_all_forms")

var Lit_164 *jrt.String = jrt.Intern("arbace.c.run$result")

var Lit_165 *jrt.String = jrt.Intern("arbace.c.run$compare_record")

var Lit_166 *jrt.String = jrt.Intern("arbace.c.run$report_record")

var Lit_167 *jrt.String = jrt.Intern("arbace.c.run$subset_record_refusal")

var Lit_168 *jrt.String = jrt.Intern("arbace.c.run$controls")

var Lit_169 *jrt.String = jrt.Intern("arbace.c.run$control_result")

var Lit_170 *jrt.String = jrt.Intern("arbace.c.run$controls_failing")

var Lit_171 *jrt.String = jrt.Intern("arbace.c.run$report_failing")

var Lit_172 *jrt.String = jrt.Intern("arbace.c.run$judge")

var Lit_173 *jrt.String = jrt.Intern("arbace.c.run$_main")
