//line aot_arbace_stacktrace.ae:1
package aot_arbace_stacktrace

import (
	"arbace/jrt"
	"arbace/lang"
)







func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_New() *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A { A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_Init(); t := &A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Ctor() {}
//line :14:1
func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_stacktrace_A_Init(); tmp4 = A_arbace_stacktrace_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_stacktrace_A_Init(); tmp6 = A_arbace_stacktrace_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :14:1
func A_arbace_stacktrace_eval457000008_fn__457000009_A_New() *A_arbace_stacktrace_eval457000008_fn__457000009_A { A_arbace_stacktrace_eval457000008_fn__457000009_A_Init(); t := &A_arbace_stacktrace_eval457000008_fn__457000009_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Ctor() {}
//line :14:1
func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_stacktrace_A_Init(); tmp3 = A_arbace_stacktrace_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_stacktrace_A_Init(); tmp5 = A_arbace_stacktrace_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_stacktrace_A_Init(); tmp7 = A_arbace_stacktrace_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_stacktrace_A_Init(); tmp9 = A_arbace_stacktrace_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }





func A_arbace_stacktrace_root_cause_A_New() *A_arbace_stacktrace_root_cause_A { A_arbace_stacktrace_root_cause_A_Init(); t := &A_arbace_stacktrace_root_cause_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_stacktrace_root_cause_A) Ctor() {}
//line :20:1
func (t *A_arbace_stacktrace_root_cause_A) Invoke_O_O__O(self, tr__0 any) any { { var tr__0_2 any = tr__0; L1: for { var temp__1927000408__auto____2 any = jrt.Throwable_Cast(tr__0_2).GetCause__Throwable()



	if jrt.A2g_Truth(temp__1927000408__auto____2) { var cause__3 any = temp__1927000408__auto____2
		tr__0_2 = cause__3; continue L1 } else {
//line :24:1
			return tr__0_2 } } }; /*line :20:1*/panic("a2g: unreachable") }







func A_arbace_stacktrace_print_trace_element_A_New() *A_arbace_stacktrace_print_trace_element_A { A_arbace_stacktrace_print_trace_element_A_Init(); t := &A_arbace_stacktrace_print_trace_element_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_stacktrace_print_trace_element_A) Ctor() {}
//line :28:1
func (t *A_arbace_stacktrace_print_trace_element_A) Invoke_O_O__O(self, e__0 any) any { var class__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetClassName__String().Ref(); var method__3 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetMethodName__String().Ref(); var match__4 any; var tmp1 *lang.Var;





	A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_8; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_stacktrace_A_Init(); tmp3 = A_arbace_stacktrace_A_const_10; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_stacktrace_A_Init(); tmp5 = A_arbace_stacktrace_A_const_11; match__4 = tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(class__2)); var tmp6 any; var and__1927000168__auto____5 any = match__4; if
	jrt.A2g_Truth(and__1927000168__auto____5) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_47, method__3)).Ref() } else { tmp6 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp6) {
		var tmp7 *lang.Var; A_arbace_stacktrace_A_Init(); tmp7 = A_arbace_stacktrace_A_const_9; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_stacktrace_A_Init(); tmp9 = A_arbace_stacktrace_A_const_7; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_stacktrace_A_Init(); tmp11 = A_arbace_stacktrace_A_const_12; tmp8.Invoke_O_O_O__O(tmp10, Lit_48, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(match__4)) } else {
			var tmp12 *lang.Var; A_arbace_stacktrace_A_Init(); tmp12 = A_arbace_stacktrace_A_const_7; lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O_O__O(Lit_49, class__2, method__3) }; var tmp13 /*line :38:1*/*lang.Var; A_arbace_stacktrace_A_Init(); tmp13 = A_arbace_stacktrace_A_const_7; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; var or__1927000174__auto____2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetFileName__String().Ref(); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp15 = or__1927000174__auto____2 } else { tmp15 = Lit_51 }; return tmp14.Invoke_O_O_O__O(Lit_50, tmp15, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetLineNumber__I()).Ref()) }

func A_arbace_stacktrace_print_throwable_A_New() *A_arbace_stacktrace_print_throwable_A { A_arbace_stacktrace_print_throwable_A_Init(); t := &A_arbace_stacktrace_print_throwable_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_stacktrace_print_throwable_A) Ctor() {}
//line :40:1
func (t *A_arbace_stacktrace_print_throwable_A) Invoke_O_O__O(self, tr__0 any) any {




	var tmp1 *lang.Var; A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_stacktrace_A_Init(); tmp3 = A_arbace_stacktrace_A_const_15; tmp2.Invoke_O_O_O__O(Lit_45, jrt.NN(jrt.Class_Cast(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(tr__0))).GetName__String().Ref(), jrt.Throwable_Cast(tr__0).GetMessage__String().Ref())
//line :40:1
	var temp__1927000414__auto____2 any; var tmp4 *lang.Var





	A_arbace_stacktrace_A_Init(); tmp4 = A_arbace_stacktrace_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(tr__0); if jrt.A2g_Truth(temp__1927000414__auto____2) { var info__3 any = temp__1927000414__auto____2; var tmp5 *lang.Var
		A_arbace_stacktrace_A_Init(); tmp5 = A_arbace_stacktrace_A_const_16; lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke__O()
		var tmp6 *lang.Var; A_arbace_stacktrace_A_Init(); tmp6 = A_arbace_stacktrace_A_const_14; return lang.IFn_Cast(jrt.NN(tmp6).Get__O()).Invoke_O__O(info__3) } else {
//line :46:1
			return nil
		}
}

func A_arbace_stacktrace_print_stack_trace_A_New() *A_arbace_stacktrace_print_stack_trace_A { A_arbace_stacktrace_print_stack_trace_A_Init(); t := &A_arbace_stacktrace_print_stack_trace_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Ctor() {}
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Invoke_O_O_O__O(self, tr__0, n__1 any) any { { var st__3 any = jrt.Throwable_Cast(tr__0).GetStackTrace__StackTraceElement1().Ref(); var tmp1 *lang.Var







	A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_21; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(tr__0)
	var tmp2 *lang.Var; A_arbace_stacktrace_A_Init(); tmp2 = A_arbace_stacktrace_A_const_16; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke__O()
	var tmp3 *lang.Var; A_arbace_stacktrace_A_Init(); tmp3 = A_arbace_stacktrace_A_const_22; lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(Lit_41)
//line :50:1
	var temp__1927000408__auto____4 any; var tmp4 *lang.Var










	A_arbace_stacktrace_A_Init(); tmp4 = A_arbace_stacktrace_A_const_20; temp__1927000408__auto____4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(st__3); if jrt.A2g_Truth(temp__1927000408__auto____4) { var e__5 any = temp__1927000408__auto____4; var tmp5 *lang.Var
		A_arbace_stacktrace_A_Init(); tmp5 = A_arbace_stacktrace_A_const_23; lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(e__5) } else {
			var tmp6 *lang.Var; A_arbace_stacktrace_A_Init(); tmp6 = A_arbace_stacktrace_A_const_22; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(Lit_42) }
	var tmp7 *lang.Var; A_arbace_stacktrace_A_Init(); tmp7 = A_arbace_stacktrace_A_const_16; lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke__O()
//line :50:1
	var seq_457000017__4 any; var tmp8 *lang.Var














	A_arbace_stacktrace_A_Init(); tmp8 = A_arbace_stacktrace_A_const_17; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; if lang.Util_Identical_O_O__Z(n__1, nil) {
		var tmp11 *lang.Var; A_arbace_stacktrace_A_Init(); tmp11 = A_arbace_stacktrace_A_const_12; tmp10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(st__3) } else {
			var tmp12 *lang.Var; A_arbace_stacktrace_A_Init(); tmp12 = A_arbace_stacktrace_A_const_24; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = lang.Numbers_Dec_O__Number(n__1); var tmp15 *lang.Var; A_arbace_stacktrace_A_Init(); tmp15 = A_arbace_stacktrace_A_const_12; tmp10 = tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(st__3)) }
//line :65:1
	seq_457000017__4 = tmp9.Invoke_O__O(tmp10)
//line :50:1
	var chunk_457000018__5 any; var count_457000019__6 int64 = 0; var i_457000020__7 int64 = 0; L1: for {














		if lang.Numbers_Lt_J_J__Z(i_457000020__7, count_457000019__6) { var e__8 any = lang.Indexed_Cast(chunk_457000018__5).Nth_I__O(lang.RT_IntCast_J__I(i_457000020__7)); var tmp16 *lang.Var


			A_arbace_stacktrace_A_Init(); tmp16 = A_arbace_stacktrace_A_const_22; lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(Lit_43)
			var tmp17 *lang.Var; A_arbace_stacktrace_A_Init(); tmp17 = A_arbace_stacktrace_A_const_23; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(e__8)
			var tmp18 *lang.Var; A_arbace_stacktrace_A_Init(); tmp18 = A_arbace_stacktrace_A_const_16; lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke__O()
//line :65:1
			seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = seq_457000017__4, chunk_457000018__5, count_457000019__6, lang.Numbers_Unchecked_inc_J__J(i_457000020__7); continue L1 } else { var temp__1927000414__auto____8 any; var tmp19 *lang.Var; A_arbace_stacktrace_A_Init(); tmp19 = A_arbace_stacktrace_A_const_17; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_457000017__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_457000017__9 any = temp__1927000414__auto____8; var tmp20 *lang.Var; A_arbace_stacktrace_A_Init(); tmp20 = A_arbace_stacktrace_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_457000017__9)) { var c__1927000678__auto____10 any; var tmp21 *lang.Var; A_arbace_stacktrace_A_Init(); tmp21 = A_arbace_stacktrace_A_const_19; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_457000017__9); var tmp22 *lang.Var; A_arbace_stacktrace_A_Init(); tmp22 = A_arbace_stacktrace_A_const_25; seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_457000017__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var e__10 any; var tmp23 *lang.Var; A_arbace_stacktrace_A_Init(); tmp23 = A_arbace_stacktrace_A_const_20; e__10 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_457000017__9)


				var tmp24 *lang.Var; A_arbace_stacktrace_A_Init(); tmp24 = A_arbace_stacktrace_A_const_22; lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(Lit_43)
				var tmp25 *lang.Var; A_arbace_stacktrace_A_Init(); tmp25 = A_arbace_stacktrace_A_const_23; lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(e__10)
				var tmp26 *lang.Var; A_arbace_stacktrace_A_Init(); tmp26 = A_arbace_stacktrace_A_const_16; lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke__O()
//line :65:1
				var tmp27 *lang.Var; A_arbace_stacktrace_A_Init(); tmp27 = A_arbace_stacktrace_A_const_26; seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_457000017__9), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :50:1*/panic("a2g: unreachable") }
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Invoke_O_O__O(self, tr__0 any) any {




	var tmp1 *lang.Var; A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_27; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(tr__0, nil)
}















func A_arbace_stacktrace_print_cause_trace_A_New() *A_arbace_stacktrace_print_cause_trace_A { A_arbace_stacktrace_print_cause_trace_A_Init(); t := &A_arbace_stacktrace_print_cause_trace_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Ctor() {}
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Invoke_O_O_O__O(self, tr__0, n__1 any) any { { var tr__0_2 any = tr__0; var n__1_2 any = n__1; L1: for {




	var tmp1 *lang.Var; A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_27; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(tr__0_2, n__1_2)
//line :72:1
	var temp__1927000414__auto____3 any = jrt.Throwable_Cast(tr__0_2).GetCause__Throwable()





	if jrt.A2g_Truth(temp__1927000414__auto____3) { var cause__4 any = temp__1927000414__auto____3; var tmp2 *lang.Var
		A_arbace_stacktrace_A_Init(); tmp2 = A_arbace_stacktrace_A_const_22; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(Lit_39)
		tr__0_2, n__1_2 = cause__4, n__1_2; continue L1 } else {
//line :78:1
			return nil } } }; /*line :72:1*/panic("a2g: unreachable") }
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Invoke_O_O__O(self, tr__0 any) any {


	var tmp1 *lang.Var; A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_28; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(tr__0, nil)
}





func A_arbace_stacktrace_e_A_New() *A_arbace_stacktrace_e_A { A_arbace_stacktrace_e_A_Init(); t := &A_arbace_stacktrace_e_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_stacktrace_e_A) Ctor() {}
//line :82:1
func (t *A_arbace_stacktrace_e_A) Invoke_O__O(self any) any {




	var tmp1 *lang.Var; A_arbace_stacktrace_A_Init(); tmp1 = A_arbace_stacktrace_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_stacktrace_A_Init(); tmp3 = A_arbace_stacktrace_A_const_29; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_stacktrace_A_Init(); tmp5 = A_arbace_stacktrace_A_const_31; var tmp6 any = tmp4.Invoke_O__O(jrt.NN(tmp5).Get__O()); var tmp7 any; A_arbace_stacktrace_A_Init(); tmp7 = A_arbace_stacktrace_A_const_30; return tmp2.Invoke_O_O__O(tmp6, tmp7)
}

type A_arbace_stacktrace_A struct{ jrt.Object }

var A_arbace_stacktrace_A_const_0 *lang.Var

var A_arbace_stacktrace_A_const_1 any

var A_arbace_stacktrace_A_const_2 *lang.Var

var A_arbace_stacktrace_A_const_3 *lang.Var

var A_arbace_stacktrace_A_const_4 *lang.Var

var A_arbace_stacktrace_A_const_5 any

var A_arbace_stacktrace_A_const_6 *lang.Var

var A_arbace_stacktrace_A_const_7 *lang.Var

var A_arbace_stacktrace_A_const_8 *lang.Var

var A_arbace_stacktrace_A_const_9 *lang.Var

var A_arbace_stacktrace_A_const_10 any

var A_arbace_stacktrace_A_const_11 *lang.Var

var A_arbace_stacktrace_A_const_12 *lang.Var

var A_arbace_stacktrace_A_const_13 *lang.Var

var A_arbace_stacktrace_A_const_14 *lang.Var

var A_arbace_stacktrace_A_const_15 *lang.Var

var A_arbace_stacktrace_A_const_16 *lang.Var

var A_arbace_stacktrace_A_const_17 *lang.Var

var A_arbace_stacktrace_A_const_18 *lang.Var

var A_arbace_stacktrace_A_const_19 *lang.Var

var A_arbace_stacktrace_A_const_20 *lang.Var

var A_arbace_stacktrace_A_const_21 *lang.Var

var A_arbace_stacktrace_A_const_22 *lang.Var

var A_arbace_stacktrace_A_const_23 *lang.Var

var A_arbace_stacktrace_A_const_24 *lang.Var

var A_arbace_stacktrace_A_const_25 *lang.Var

var A_arbace_stacktrace_A_const_26 *lang.Var

var A_arbace_stacktrace_A_const_27 *lang.Var

var A_arbace_stacktrace_A_const_28 *lang.Var

var A_arbace_stacktrace_A_const_29 *lang.Var

var A_arbace_stacktrace_A_const_30 any

var A_arbace_stacktrace_A_const_31 *lang.Var

var A_arbace_stacktrace_A_init jrt.ClassInit

func A_arbace_stacktrace_A_Init() { if !A_arbace_stacktrace_A_init.Done() { A_arbace_stacktrace_A_init.Run(A_arbace_stacktrace_A_clinit) } }

func A_arbace_stacktrace_A_clinit() { A_arbace_stacktrace_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_stacktrace_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_stacktrace_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_stacktrace_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_stacktrace_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_stacktrace_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_stacktrace_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_stacktrace_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_stacktrace_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_stacktrace_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_stacktrace_A_const_10 = jrt.Pattern_Compile_String__Pattern(Lit_14).Ref(); A_arbace_stacktrace_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_stacktrace_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_stacktrace_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_stacktrace_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_stacktrace_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_stacktrace_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_stacktrace_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_stacktrace_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_stacktrace_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_stacktrace_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_stacktrace_A_const_21 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); A_arbace_stacktrace_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_stacktrace_A_const_23 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_stacktrace_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_stacktrace_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_stacktrace_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_stacktrace_A_const_27 = lang.RT_Var_String_String__Var(Lit_5, Lit_31); A_arbace_stacktrace_A_const_28 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_stacktrace_A_const_29 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_stacktrace_A_const_30 = jrt.Long_ValueOf_J__Long(8).Ref(); A_arbace_stacktrace_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_34) }

func A_arbace_stacktrace_A_New() *A_arbace_stacktrace_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_A) Ctor() {}

func (t *A_arbace_stacktrace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_A_class }

func (t *A_arbace_stacktrace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_A); return ok }

func A_arbace_stacktrace_A_Cast(x any) *A_arbace_stacktrace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_A_class)) }; return v }



type A_arbace_stacktrace_e_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_e_A) Is_Compiler_AOTF0() {}

var A_arbace_stacktrace_e_A_fn_class *jrt.Class

var A_arbace_stacktrace_e_A_init jrt.ClassInit

func A_arbace_stacktrace_e_A_Init() { if !A_arbace_stacktrace_e_A_init.Done() { A_arbace_stacktrace_e_A_init.Run(A_arbace_stacktrace_e_A_clinit) } }

func A_arbace_stacktrace_e_A_clinit() { A_arbace_stacktrace_e_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_35, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_e_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_e_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_e_A_class }

func (t *A_arbace_stacktrace_e_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_e_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_e_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_e_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_e_A); return ok }

func A_arbace_stacktrace_e_A_Cast(x any) *A_arbace_stacktrace_e_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_e_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_e_A_class)) }; return v }



type A_arbace_stacktrace_eval457000004_A struct{ jrt.Object }

func A_arbace_stacktrace_eval457000004_A_New() *A_arbace_stacktrace_eval457000004_A { t := &A_arbace_stacktrace_eval457000004_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_eval457000004_A) Ctor() {}

func (t *A_arbace_stacktrace_eval457000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000004_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000004_A_class }

func (t *A_arbace_stacktrace_eval457000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000004_A); return ok }

func A_arbace_stacktrace_eval457000004_A_Cast(x any) *A_arbace_stacktrace_eval457000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000004_A_class)) }; return v }



type A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Is_Compiler_AOTF0() {}

var A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class *jrt.Class

var A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_init jrt.ClassInit

func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_Init() { if !A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_init.Done() { A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_init.Run(A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_clinit) } }

func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_clinit() { A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_36, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_class }

func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A); return ok }

func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_Cast(x any) *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_class)) }; return v }



type A_arbace_stacktrace_eval457000008_A struct{ jrt.Object }

func A_arbace_stacktrace_eval457000008_A_New() *A_arbace_stacktrace_eval457000008_A { t := &A_arbace_stacktrace_eval457000008_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_eval457000008_A) Ctor() {}

func (t *A_arbace_stacktrace_eval457000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000008_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000008_A_class }

func (t *A_arbace_stacktrace_eval457000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000008_A); return ok }

func A_arbace_stacktrace_eval457000008_A_Cast(x any) *A_arbace_stacktrace_eval457000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000008_A_class)) }; return v }



type A_arbace_stacktrace_eval457000008_fn__457000009_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Is_Compiler_AOTF0() {}

var A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class *jrt.Class

var A_arbace_stacktrace_eval457000008_fn__457000009_A_init jrt.ClassInit

func A_arbace_stacktrace_eval457000008_fn__457000009_A_Init() { if !A_arbace_stacktrace_eval457000008_fn__457000009_A_init.Done() { A_arbace_stacktrace_eval457000008_fn__457000009_A_init.Run(A_arbace_stacktrace_eval457000008_fn__457000009_A_clinit) } }

func A_arbace_stacktrace_eval457000008_fn__457000009_A_clinit() { A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_37, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000008_fn__457000009_A_class }

func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000008_fn__457000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000008_fn__457000009_A); return ok }

func A_arbace_stacktrace_eval457000008_fn__457000009_A_Cast(x any) *A_arbace_stacktrace_eval457000008_fn__457000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000008_fn__457000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000008_fn__457000009_A_class)) }; return v }



type A_arbace_stacktrace_print_cause_trace_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_print_cause_trace_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_stacktrace_print_cause_trace_A) Is_Compiler_AOTF1() {}

var A_arbace_stacktrace_print_cause_trace_A_fn_class *jrt.Class

var A_arbace_stacktrace_print_cause_trace_A_init jrt.ClassInit

func A_arbace_stacktrace_print_cause_trace_A_Init() { if !A_arbace_stacktrace_print_cause_trace_A_init.Done() { A_arbace_stacktrace_print_cause_trace_A_init.Run(A_arbace_stacktrace_print_cause_trace_A_clinit) } }

func A_arbace_stacktrace_print_cause_trace_A_clinit() { A_arbace_stacktrace_print_cause_trace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_38, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_print_cause_trace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_print_cause_trace_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_print_cause_trace_A_class }

func (t *A_arbace_stacktrace_print_cause_trace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_print_cause_trace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_print_cause_trace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_print_cause_trace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_print_cause_trace_A); return ok }

func A_arbace_stacktrace_print_cause_trace_A_Cast(x any) *A_arbace_stacktrace_print_cause_trace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_print_cause_trace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_print_cause_trace_A_class)) }; return v }



type A_arbace_stacktrace_print_stack_trace_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_print_stack_trace_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_stacktrace_print_stack_trace_A) Is_Compiler_AOTF1() {}

var A_arbace_stacktrace_print_stack_trace_A_fn_class *jrt.Class

var A_arbace_stacktrace_print_stack_trace_A_init jrt.ClassInit

func A_arbace_stacktrace_print_stack_trace_A_Init() { if !A_arbace_stacktrace_print_stack_trace_A_init.Done() { A_arbace_stacktrace_print_stack_trace_A_init.Run(A_arbace_stacktrace_print_stack_trace_A_clinit) } }

func A_arbace_stacktrace_print_stack_trace_A_clinit() { A_arbace_stacktrace_print_stack_trace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_40, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_print_stack_trace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_print_stack_trace_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_print_stack_trace_A_class }

func (t *A_arbace_stacktrace_print_stack_trace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_print_stack_trace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_print_stack_trace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_print_stack_trace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_print_stack_trace_A); return ok }

func A_arbace_stacktrace_print_stack_trace_A_Cast(x any) *A_arbace_stacktrace_print_stack_trace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_print_stack_trace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_print_stack_trace_A_class)) }; return v }



type A_arbace_stacktrace_print_throwable_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_print_throwable_A) Is_Compiler_AOTF1() {}

var A_arbace_stacktrace_print_throwable_A_fn_class *jrt.Class

var A_arbace_stacktrace_print_throwable_A_init jrt.ClassInit

func A_arbace_stacktrace_print_throwable_A_Init() { if !A_arbace_stacktrace_print_throwable_A_init.Done() { A_arbace_stacktrace_print_throwable_A_init.Run(A_arbace_stacktrace_print_throwable_A_clinit) } }

func A_arbace_stacktrace_print_throwable_A_clinit() { A_arbace_stacktrace_print_throwable_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_44, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_print_throwable_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_print_throwable_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_print_throwable_A_class }

func (t *A_arbace_stacktrace_print_throwable_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_print_throwable_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_print_throwable_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_print_throwable_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_print_throwable_A); return ok }

func A_arbace_stacktrace_print_throwable_A_Cast(x any) *A_arbace_stacktrace_print_throwable_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_print_throwable_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_print_throwable_A_class)) }; return v }



type A_arbace_stacktrace_print_trace_element_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_print_trace_element_A) Is_Compiler_AOTF1() {}

var A_arbace_stacktrace_print_trace_element_A_fn_class *jrt.Class

var A_arbace_stacktrace_print_trace_element_A_init jrt.ClassInit

func A_arbace_stacktrace_print_trace_element_A_Init() { if !A_arbace_stacktrace_print_trace_element_A_init.Done() { A_arbace_stacktrace_print_trace_element_A_init.Run(A_arbace_stacktrace_print_trace_element_A_clinit) } }

func A_arbace_stacktrace_print_trace_element_A_clinit() { A_arbace_stacktrace_print_trace_element_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_46, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_print_trace_element_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_print_trace_element_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_print_trace_element_A_class }

func (t *A_arbace_stacktrace_print_trace_element_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_print_trace_element_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_print_trace_element_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_print_trace_element_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_print_trace_element_A); return ok }

func A_arbace_stacktrace_print_trace_element_A_Cast(x any) *A_arbace_stacktrace_print_trace_element_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_print_trace_element_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_print_trace_element_A_class)) }; return v }



type A_arbace_stacktrace_root_cause_A struct{ jrt.Object }

func (t *A_arbace_stacktrace_root_cause_A) Is_Compiler_AOTF1() {}

var A_arbace_stacktrace_root_cause_A_fn_class *jrt.Class

var A_arbace_stacktrace_root_cause_A_init jrt.ClassInit

func A_arbace_stacktrace_root_cause_A_Init() { if !A_arbace_stacktrace_root_cause_A_init.Done() { A_arbace_stacktrace_root_cause_A_init.Run(A_arbace_stacktrace_root_cause_A_clinit) } }

func A_arbace_stacktrace_root_cause_A_clinit() { A_arbace_stacktrace_root_cause_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_stacktrace_root_cause_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_root_cause_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_root_cause_A_class }

func (t *A_arbace_stacktrace_root_cause_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_root_cause_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_root_cause_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_root_cause_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_root_cause_A); return ok }

func A_arbace_stacktrace_root_cause_A_Cast(x any) *A_arbace_stacktrace_root_cause_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_root_cause_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_root_cause_A_class)) }; return v }
