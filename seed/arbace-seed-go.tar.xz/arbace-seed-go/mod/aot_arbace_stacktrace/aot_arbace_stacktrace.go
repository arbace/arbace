//line aot_arbace_stacktrace.ae:1
package aot_arbace_stacktrace

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)






func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_New() *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Ctor() {}
//line :14:1
func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_stacktrace_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_stacktrace_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :14:1
func A_arbace_stacktrace_eval457000008_fn__457000009_A_New() *A_arbace_stacktrace_eval457000008_fn__457000009_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_eval457000008_fn__457000009_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Ctor() {}
//line :14:1
func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_stacktrace_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_stacktrace_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_stacktrace_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_stacktrace_A_const_5.GetRawRoot__O(), A_arbace_stacktrace_A_const_6) }





func A_arbace_stacktrace_root_cause_A_New() *A_arbace_stacktrace_root_cause_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_root_cause_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_stacktrace_root_cause_A) Ctor() {}
//line :20:1
func (t *A_arbace_stacktrace_root_cause_A) Invoke_O_O__O(self, tr__0 any) any { { var tr__0_2 any = tr__0; L1: for { var temp__1927000408__auto____2 any = jrt.Throwable_Cast(tr__0_2).GetCause__Throwable()



	if jrt.J2g_Truth(temp__1927000408__auto____2) { var cause__3 any = temp__1927000408__auto____2
		tr__0_2 = cause__3; continue L1 } else {
//line :24:1
			return tr__0_2 } } }; /*line :20:1*/panic("j2g: unreachable") }







func A_arbace_stacktrace_print_trace_element_A_New() *A_arbace_stacktrace_print_trace_element_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_trace_element_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_stacktrace_print_trace_element_A) Ctor() {}
//line :28:1
func (t *A_arbace_stacktrace_print_trace_element_A) Invoke_O_O__O(self, e__0 any) any { var class__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetClassName__String().Ref(); var method__3 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetMethodName__String().Ref(); var match__4 any; var root_25 any = A_arbace_stacktrace_A_const_8.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_27 lang.IFn; if





	linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_stacktrace_A_const_9; var arg_29 any; var root_21 any = A_arbace_stacktrace_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = class__2; if linked_22 == nil { arg_29 = ifn_23.Invoke_O__O(arg_24) } else { arg_29 = linked_22.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_21, arg_24) }; if linked_26 == nil { match__4 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { match__4 = linked_26.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; var tmp1 any; var and__1927000168__auto____5 any = match__4; if
	jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_6, method__3)).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) {
		var root_34 any = A_arbace_stacktrace_A_const_11.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = A_arbace_stacktrace_A_const_7.GetRawRoot__O(); var arg_38 any = Lit_7; var arg_39 any; var root_30 any = A_arbace_stacktrace_A_const_12.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = match__4; if linked_31 == nil { arg_39 = ifn_32.Invoke_O__O(arg_33) } else { arg_39 = linked_31.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_30, arg_33) }; if linked_35 == nil { ifn_36.Invoke_O_O_O__O(arg_37, arg_38, arg_39) } else { linked_35.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_34, arg_37, arg_38, arg_39) } } else {
			lang.IFn_Cast(A_arbace_stacktrace_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(Lit_8, class__2, method__3) }; var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_stacktrace_A_const_7.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetFileName__String().Ref(); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp3 = or__1927000174__auto____2 } else { tmp3 = Lit_10 }; return tmp2.Invoke_O_O_O__O(Lit_9, tmp3, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetLineNumber__I()).Ref()) }

func A_arbace_stacktrace_print_throwable_A_New() *A_arbace_stacktrace_print_throwable_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_throwable_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_stacktrace_print_throwable_A) Ctor() {}
//line :40:1
func (t *A_arbace_stacktrace_print_throwable_A) Invoke_O_O__O(self, tr__0 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_stacktrace_A_const_7.GetRawRoot__O()); var tmp2 any; var root_50 any = A_arbace_stacktrace_A_const_15.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = tr__0; if linked_51 == nil { tmp2 = ifn_52.Invoke_O__O(arg_53) } else { tmp2 = linked_51.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_50, arg_53) }; tmp1.Invoke_O_O_O__O(Lit_5, jrt.NN(jrt.Class_Cast(tmp2)).GetName__String().Ref(), jrt.Throwable_Cast(tr__0).GetMessage__String().Ref())
//line :40:1
	var temp__1927000414__auto____2 any; var root_46 any = A_arbace_stacktrace_A_const_13.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_48 lang.IFn





	if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = tr__0; if linked_47 == nil { temp__1927000414__auto____2 = ifn_48.Invoke_O__O(arg_49) } else { temp__1927000414__auto____2 = linked_47.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_46, arg_49) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var info__3 any = temp__1927000414__auto____2; var root_60 any = A_arbace_stacktrace_A_const_16.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_newline_A_fn_class); var ifn_62 lang.IFn
		if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; if linked_61 == nil { ifn_62.Invoke__O() } else { linked_61.(*aot_arbace_core.A_arbace_core_newline_A).Invoke_O__O(root_60) }
		return lang.IFn_Cast(A_arbace_stacktrace_A_const_14.Get__O()).Invoke_O__O(info__3) } else {
//line :46:1
			return nil
		}
}

func A_arbace_stacktrace_print_stack_trace_A_New() *A_arbace_stacktrace_print_stack_trace_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_stack_trace_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Ctor() {}
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Invoke_O_O_O__O(self, tr__0, n__1 any) any { { var st__3 any = jrt.Throwable_Cast(tr__0).GetStackTrace__StackTraceElement1().Ref(); var root_98 any = A_arbace_stacktrace_A_const_22.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, A_arbace_stacktrace_print_throwable_A_fn_class); var ifn_100 lang.IFn







	if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = tr__0; if linked_99 == nil { ifn_100.Invoke_O__O(arg_101) } else { linked_99.(*A_arbace_stacktrace_print_throwable_A).Invoke_O_O__O(root_98, arg_101) }
	var root_102 any = A_arbace_stacktrace_A_const_16.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_newline_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; if linked_103 == nil { ifn_104.Invoke__O() } else { linked_103.(*aot_arbace_core.A_arbace_core_newline_A).Invoke_O__O(root_102) }
	lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(Lit_2)
//line :50:1
	var temp__1927000408__auto____4 any; var root_109 any = A_arbace_stacktrace_A_const_21.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_111 lang.IFn










	if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = st__3; if linked_110 == nil { temp__1927000408__auto____4 = ifn_111.Invoke_O__O(arg_112) } else { temp__1927000408__auto____4 = linked_110.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var e__5 any = temp__1927000408__auto____4; var root_113 any = A_arbace_stacktrace_A_const_24.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_stacktrace_print_trace_element_A_fn_class); var ifn_115 lang.IFn
		if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = e__5; if linked_114 == nil { ifn_115.Invoke_O__O(arg_116) } else { linked_114.(*A_arbace_stacktrace_print_trace_element_A).Invoke_O_O__O(root_113, arg_116) } } else {
			lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(Lit_3) }
	var root_121 any = A_arbace_stacktrace_A_const_16.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_newline_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; if linked_122 == nil { ifn_123.Invoke__O() } else { linked_122.(*aot_arbace_core.A_arbace_core_newline_A).Invoke_O__O(root_121) }
//line :50:1
	var seq_457000017__4 any; var root_78 any = A_arbace_stacktrace_A_const_17.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_80 lang.IFn














	if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; if lang.Util_Identical_O_O__Z_NoInit(n__1, nil) {
		var root_63 any = A_arbace_stacktrace_A_const_12.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = st__3; if linked_64 == nil { arg_81 = ifn_65.Invoke_O__O(arg_66) } else { arg_81 = linked_64.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_63, arg_66) } } else {
			var root_73 any = A_arbace_stacktrace_A_const_18.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var na_67 any = n__1; if jrt.Long_InstanceOf(na_67) { var n0_68 int64 = jrt.NN(jrt.Long_Cast(na_67)).LongValue__J(); if n0_68 == -9223372036854775808 { arg_76 = lang.Numbers_Dec_O__Number_NoInit(na_67) } else { arg_76 = jrt.Long_ValueOf_J__Long_NoInit(n0_68 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_67) { var n0_68_2 float64 = jrt.NN(jrt.Double_Cast(na_67)).DoubleValue__D(); arg_76 = jrt.Double_ValueOf_D__Double_NoInit(n0_68_2 - 1.0).Ref() } else { arg_76 = lang.Numbers_Dec_O__Number_NoInit(na_67) } }; var arg_77 any; var root_69 any = A_arbace_stacktrace_A_const_12.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = st__3; if linked_70 == nil { arg_77 = ifn_71.Invoke_O__O(arg_72) } else { arg_77 = linked_70.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_69, arg_72) }; if linked_74 == nil { arg_81 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { arg_81 = linked_74.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) } }
//line :65:1
	if linked_79 == nil { seq_457000017__4 = ifn_80.Invoke_O__O(arg_81) } else { seq_457000017__4 = linked_79.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_78, arg_81) }
//line :50:1
	var chunk_457000018__5 any; var count_457000019__6 int64 = 0; var i_457000020__7 int64 = 0; L1: for {














		if lang.Numbers_Lt_J_J__Z_NoInit(i_457000020__7, count_457000019__6) { var e__8 any = lang.Indexed_Cast(chunk_457000018__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_457000020__7))


			lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(Lit_4)
			var root_131 any = A_arbace_stacktrace_A_const_24.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, A_arbace_stacktrace_print_trace_element_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = e__8; if linked_132 == nil { ifn_133.Invoke_O__O(arg_134) } else { linked_132.(*A_arbace_stacktrace_print_trace_element_A).Invoke_O_O__O(root_131, arg_134) }
			var root_124 any = A_arbace_stacktrace_A_const_16.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_newline_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; if linked_125 == nil { ifn_126.Invoke__O() } else { linked_125.(*aot_arbace_core.A_arbace_core_newline_A).Invoke_O__O(root_124) }
//line :65:1
			seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = seq_457000017__4, chunk_457000018__5, count_457000019__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_457000020__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_82 any = A_arbace_stacktrace_A_const_17.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq_457000017__4; if linked_83 == nil { temp__1927000414__auto____8 = ifn_84.Invoke_O__O(arg_85) } else { temp__1927000414__auto____8 = linked_83.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_82, arg_85) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_457000017__9 any = temp__1927000414__auto____8; var tmp1 any; var root_86 any = A_arbace_stacktrace_A_const_19.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq_457000017__9; if linked_87 == nil { tmp1 = ifn_88.Invoke_O__O(arg_89) } else { tmp1 = linked_87.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_90 any = A_arbace_stacktrace_A_const_20.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = seq_457000017__9; if linked_91 == nil { c__1927000678__auto____10 = ifn_92.Invoke_O__O(arg_93) } else { c__1927000678__auto____10 = linked_91.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_90, arg_93) }; var tmp2 any; var root_135 any = A_arbace_stacktrace_A_const_25.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = seq_457000017__9; if linked_136 == nil { tmp2 = ifn_137.Invoke_O__O(arg_138) } else { tmp2 = linked_136.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_135, arg_138) }; seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var e__10 any; var root_94 any = A_arbace_stacktrace_A_const_21.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq_457000017__9; if linked_95 == nil { e__10 = ifn_96.Invoke_O__O(arg_97) } else { e__10 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97)
			}

				lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(Lit_4)
				var root_146 any = A_arbace_stacktrace_A_const_24.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_stacktrace_print_trace_element_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = e__10; if linked_147 == nil { ifn_148.Invoke_O__O(arg_149) } else { linked_147.(*A_arbace_stacktrace_print_trace_element_A).Invoke_O_O__O(root_146, arg_149) }
				var root_139 any = A_arbace_stacktrace_A_const_16.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_newline_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; if linked_140 == nil { ifn_141.Invoke__O() } else { linked_140.(*aot_arbace_core.A_arbace_core_newline_A).Invoke_O__O(root_139) }
//line :65:1
				var tmp3 any; var root_150 any = A_arbace_stacktrace_A_const_26.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = seq_457000017__9; if linked_151 == nil { tmp3 = ifn_152.Invoke_O__O(arg_153) } else { tmp3 = linked_151.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_150, arg_153) }; seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :50:1*/panic("j2g: unreachable") }
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Invoke_O_O__O(self, tr__0 any) any {




	var root_154 any = A_arbace_stacktrace_A_const_27.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, A_arbace_stacktrace_print_stack_trace_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = tr__0; var arg_158 any; if linked_155 == nil { return ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { return linked_155.(*A_arbace_stacktrace_print_stack_trace_A).Invoke_O_O_O__O(root_154, arg_157, arg_158)
	}
}














func A_arbace_stacktrace_print_cause_trace_A_New() *A_arbace_stacktrace_print_cause_trace_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_cause_trace_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Ctor() {}
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Invoke_O_O_O__O(self, tr__0, n__1 any) any { { var tr__0_2 any = tr__0; var n__1_2 any = n__1; L1: for {




	var root_159 any = A_arbace_stacktrace_A_const_27.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_stacktrace_print_stack_trace_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = tr__0_2; var arg_163 any = n__1_2; if linked_160 == nil { ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { linked_160.(*A_arbace_stacktrace_print_stack_trace_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }
//line :72:1
	var temp__1927000414__auto____3 any = jrt.Throwable_Cast(tr__0_2).GetCause__Throwable()





	if jrt.J2g_Truth(temp__1927000414__auto____3) { var cause__4 any = temp__1927000414__auto____3
		lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(Lit_1)
		tr__0_2, n__1_2 = cause__4, n__1_2; continue L1 } else {
//line :78:1
			return nil } } }; /*line :72:1*/panic("j2g: unreachable") }
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Invoke_O_O__O(self, tr__0 any) any {


	var root_168 any = A_arbace_stacktrace_A_const_28.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_stacktrace_print_cause_trace_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = tr__0; var arg_172 any; if linked_169 == nil { return ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { return linked_169.(*A_arbace_stacktrace_print_cause_trace_A).Invoke_O_O_O__O(root_168, arg_171, arg_172)
	}
}




func A_arbace_stacktrace_e_A_New() *A_arbace_stacktrace_e_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_e_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_stacktrace_e_A) Ctor() {}
//line :82:1
func (t *A_arbace_stacktrace_e_A) Invoke_O__O(self any) any {




	var root_177 any = A_arbace_stacktrace_A_const_27.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_stacktrace_print_stack_trace_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var root_173 any = A_arbace_stacktrace_A_const_29.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_stacktrace_root_cause_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = A_arbace_stacktrace_A_const_30.Get__O(); if linked_174 == nil { arg_180 = ifn_175.Invoke_O__O(arg_176) } else { arg_180 = linked_174.(*A_arbace_stacktrace_root_cause_A).Invoke_O_O__O(root_173, arg_176) }; var arg_181 any = A_arbace_stacktrace_A_const_31; if linked_178 == nil { return ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { return linked_178.(*A_arbace_stacktrace_print_stack_trace_A).Invoke_O_O_O__O(root_177, arg_180, arg_181)
	}
}
type A_arbace_stacktrace_A struct{ jrt.Object }

var A_arbace_stacktrace_A_const_pool *jrt.RefArray

var A_arbace_stacktrace_A_const_0 *lang.Var

var A_arbace_stacktrace_A_const_1 any

var A_arbace_stacktrace_A_const_2 *lang.Var

var A_arbace_stacktrace_A_const_3 *lang.Var

var A_arbace_stacktrace_A_const_4 *lang.Var

var A_arbace_stacktrace_A_const_5 *lang.Var

var A_arbace_stacktrace_A_const_6 any

var A_arbace_stacktrace_A_const_7 *lang.Var

var A_arbace_stacktrace_A_const_8 *lang.Var

var A_arbace_stacktrace_A_const_9 any

var A_arbace_stacktrace_A_const_10 *lang.Var

var A_arbace_stacktrace_A_const_11 *lang.Var

var A_arbace_stacktrace_A_const_12 *lang.Var

var A_arbace_stacktrace_A_const_13 *lang.Var

var A_arbace_stacktrace_A_const_14 *lang.Var

var A_arbace_stacktrace_A_const_15 *lang.Var

var A_arbace_stacktrace_A_const_16 *lang.Var

var A_arbace_stacktrace_A_const_17 *lang.Var

var A_arbace_stacktrace_A_const_18 *lang.Var

var A_arbace_stacktrace_A_const_19 *lang.Var

var A_arbace_stacktrace_A_const_20 *lang.Var

var A_arbace_stacktrace_A_const_21 *lang.Var

var A_arbace_stacktrace_A_const_22 *lang.Var

var A_arbace_stacktrace_A_const_23 *lang.Var

var A_arbace_stacktrace_A_const_24 *lang.Var

var A_arbace_stacktrace_A_const_25 *lang.Var

var A_arbace_stacktrace_A_const_26 *lang.Var

var A_arbace_stacktrace_A_const_27 *lang.Var

var A_arbace_stacktrace_A_const_28 *lang.Var

var A_arbace_stacktrace_A_const_29 *lang.Var

var A_arbace_stacktrace_A_const_30 *lang.Var

var A_arbace_stacktrace_A_const_31 any

var A_arbace_stacktrace_A_init jrt.ClassInit

func A_arbace_stacktrace_A_Init() { if !A_arbace_stacktrace_A_init.Done() { A_arbace_stacktrace_A_init.Run(A_arbace_stacktrace_A_clinit) } }

func A_arbace_stacktrace_A_clinit() { A_arbace_stacktrace_A_clinit_p0(); A_arbace_stacktrace_A_clinit_p1(); A_arbace_stacktrace_A_clinit_p2() }

func A_arbace_stacktrace_A_clinit_p0() { jrt.StartCheck(); A_arbace_stacktrace_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 35); A_arbace_stacktrace_A_const_0 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[3]); A_arbace_stacktrace_A_const_1 = A_arbace_stacktrace_A_const_pool.A[4]; A_arbace_stacktrace_A_const_2 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[5]); A_arbace_stacktrace_A_const_3 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[6]); A_arbace_stacktrace_A_const_4 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[7]); A_arbace_stacktrace_A_const_5 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[8]); A_arbace_stacktrace_A_const_6 = A_arbace_stacktrace_A_const_pool.A[9]; A_arbace_stacktrace_A_const_7 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[10]); A_arbace_stacktrace_A_const_8 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[11]); A_arbace_stacktrace_A_const_9 = A_arbace_stacktrace_A_const_pool.A[12]; A_arbace_stacktrace_A_const_10 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[13]); A_arbace_stacktrace_A_const_11 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[14]) }

func A_arbace_stacktrace_A_clinit_p1() { A_arbace_stacktrace_A_const_12 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[15]); A_arbace_stacktrace_A_const_13 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[16]); A_arbace_stacktrace_A_const_14 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[17]); A_arbace_stacktrace_A_const_15 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[18]); A_arbace_stacktrace_A_const_16 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[19]); A_arbace_stacktrace_A_const_17 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[20]); A_arbace_stacktrace_A_const_18 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[21]); A_arbace_stacktrace_A_const_19 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[22]); A_arbace_stacktrace_A_const_20 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[23]); A_arbace_stacktrace_A_const_21 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[24]); A_arbace_stacktrace_A_const_22 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[25]); A_arbace_stacktrace_A_const_23 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[26]) }

func A_arbace_stacktrace_A_clinit_p2() { A_arbace_stacktrace_A_const_24 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[27]); A_arbace_stacktrace_A_const_25 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[28]); A_arbace_stacktrace_A_const_26 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[29]); A_arbace_stacktrace_A_const_27 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[30]); A_arbace_stacktrace_A_const_28 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[31]); A_arbace_stacktrace_A_const_29 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[32]); A_arbace_stacktrace_A_const_30 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[33]); A_arbace_stacktrace_A_const_31 = A_arbace_stacktrace_A_const_pool.A[34] }

func A_arbace_stacktrace_A_New() *A_arbace_stacktrace_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_A) Ctor() {}

func (t *A_arbace_stacktrace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_A_class }

func (t *A_arbace_stacktrace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_A); return ok }

func A_arbace_stacktrace_A_Cast(x any) *A_arbace_stacktrace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_A_class)) }; return v }



type A_arbace_stacktrace_e_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_e_A_fn_class *jrt.Class



type A_arbace_stacktrace_eval457000004_A struct{ jrt.Object }

func A_arbace_stacktrace_eval457000004_A_New() *A_arbace_stacktrace_eval457000004_A { t := &A_arbace_stacktrace_eval457000004_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_eval457000004_A) Ctor() {}

func (t *A_arbace_stacktrace_eval457000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000004_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000004_A_class }

func (t *A_arbace_stacktrace_eval457000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000004_A); return ok }

func A_arbace_stacktrace_eval457000004_A_Cast(x any) *A_arbace_stacktrace_eval457000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000004_A_class)) }; return v }



type A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class *jrt.Class



type A_arbace_stacktrace_eval457000008_A struct{ jrt.Object }

func A_arbace_stacktrace_eval457000008_A_New() *A_arbace_stacktrace_eval457000008_A { t := &A_arbace_stacktrace_eval457000008_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_eval457000008_A) Ctor() {}

func (t *A_arbace_stacktrace_eval457000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000008_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000008_A_class }

func (t *A_arbace_stacktrace_eval457000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000008_A); return ok }

func A_arbace_stacktrace_eval457000008_A_Cast(x any) *A_arbace_stacktrace_eval457000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000008_A_class)) }; return v }



type A_arbace_stacktrace_eval457000008_fn__457000009_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_cause_trace_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_print_cause_trace_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_stack_trace_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_print_stack_trace_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_throwable_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_print_throwable_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_trace_element_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_print_trace_element_A_fn_class *jrt.Class



type A_arbace_stacktrace_root_cause_A struct{ j2g_header uint64 }

var A_arbace_stacktrace_root_cause_A_fn_class *jrt.Class
