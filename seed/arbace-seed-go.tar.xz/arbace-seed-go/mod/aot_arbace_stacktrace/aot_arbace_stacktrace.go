//line aot_arbace_stacktrace.ae:1
package aot_arbace_stacktrace

import (
	"arbace/jrt"
	"arbace/lang"
)







func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_New() *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Ctor() {}
//line :14:1
func (t *A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp3 = lang.IFn_Cast(A_arbace_stacktrace_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_stacktrace_A_const_1); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :14:1
func A_arbace_stacktrace_eval457000008_fn__457000009_A_New() *A_arbace_stacktrace_eval457000008_fn__457000009_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_eval457000008_fn__457000009_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Ctor() {}
//line :14:1
func (t *A_arbace_stacktrace_eval457000008_fn__457000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_stacktrace_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_stacktrace_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_stacktrace_A_const_6), A_arbace_stacktrace_A_const_4.GetRawRoot__O(), A_arbace_stacktrace_A_const_5) }





func A_arbace_stacktrace_root_cause_A_New() *A_arbace_stacktrace_root_cause_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_root_cause_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_stacktrace_root_cause_A) Ctor() {}
//line :20:1
func (t *A_arbace_stacktrace_root_cause_A) Invoke_O_O__O(self, tr__0 any) any { { var tr__0_2 any = tr__0; L1: for { var temp__1927000408__auto____2 any = jrt.Throwable_Cast(tr__0_2).GetCause__Throwable()



	if jrt.A2g_Truth(temp__1927000408__auto____2) { var cause__3 any = temp__1927000408__auto____2
		tr__0_2 = cause__3; continue L1 } else {
//line :24:1
			return tr__0_2 } } }; /*line :20:1*/panic("a2g: unreachable") }







func A_arbace_stacktrace_print_trace_element_A_New() *A_arbace_stacktrace_print_trace_element_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_trace_element_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_stacktrace_print_trace_element_A) Ctor() {}
//line :28:1
func (t *A_arbace_stacktrace_print_trace_element_A) Invoke_O_O__O(self, e__0 any) any { var class__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetClassName__String().Ref(); var method__3 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetMethodName__String().Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_stacktrace_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_stacktrace_A_const_10; var match__4 any = tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_stacktrace_A_const_11.GetRawRoot__O()).Invoke_O__O(class__2)); var tmp3 any; var and__1927000168__auto____5 any = match__4; if






	jrt.A2g_Truth(and__1927000168__auto____5) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_6, method__3)).Ref() } else { tmp3 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp3) {
		lang.IFn_Cast(A_arbace_stacktrace_A_const_9.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_stacktrace_A_const_7.GetRawRoot__O(), Lit_7, lang.IFn_Cast(A_arbace_stacktrace_A_const_12.GetRawRoot__O()).Invoke_O__O(match__4)) } else {
			lang.IFn_Cast(A_arbace_stacktrace_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(Lit_8, class__2, method__3) }; var tmp4 lang.IFn =
	lang.IFn_Cast(A_arbace_stacktrace_A_const_7.GetRawRoot__O()); var tmp5 any; var or__1927000174__auto____2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetFileName__String().Ref(); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { tmp5 = Lit_10 }; return tmp4.Invoke_O_O_O__O(Lit_9, tmp5, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](e__0)).GetLineNumber__I()).Ref()) }

func A_arbace_stacktrace_print_throwable_A_New() *A_arbace_stacktrace_print_throwable_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_throwable_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_stacktrace_print_throwable_A) Ctor() {}
//line :40:1
func (t *A_arbace_stacktrace_print_throwable_A) Invoke_O_O__O(self, tr__0 any) any {




	lang.IFn_Cast(A_arbace_stacktrace_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(Lit_5, jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_stacktrace_A_const_15.GetRawRoot__O()).Invoke_O__O(tr__0))).GetName__String().Ref(), jrt.Throwable_Cast(tr__0).GetMessage__String().Ref())
//line :40:1
	var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_stacktrace_A_const_13.GetRawRoot__O()).Invoke_O__O(tr__0)





	if jrt.A2g_Truth(temp__1927000414__auto____2) { var info__3 any = temp__1927000414__auto____2
		lang.IFn_Cast(A_arbace_stacktrace_A_const_16.GetRawRoot__O()).Invoke__O()
		return lang.IFn_Cast(A_arbace_stacktrace_A_const_14.Get__O()).Invoke_O__O(info__3) } else {
//line :46:1
			return nil
		}
}

func A_arbace_stacktrace_print_stack_trace_A_New() *A_arbace_stacktrace_print_stack_trace_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_stack_trace_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Ctor() {}
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Invoke_O_O_O__O(self, tr__0, n__1 any) any { { var st__3 any = jrt.Throwable_Cast(tr__0).GetStackTrace__StackTraceElement1().Ref()







	lang.IFn_Cast(A_arbace_stacktrace_A_const_21.GetRawRoot__O()).Invoke_O__O(tr__0)
	lang.IFn_Cast(A_arbace_stacktrace_A_const_16.GetRawRoot__O()).Invoke__O()
	lang.IFn_Cast(A_arbace_stacktrace_A_const_22.GetRawRoot__O()).Invoke_O__O(Lit_2)
//line :50:1
	var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_stacktrace_A_const_20.GetRawRoot__O()).Invoke_O__O(st__3)










	if jrt.A2g_Truth(temp__1927000408__auto____4) { var e__5 any = temp__1927000408__auto____4
		lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(e__5) } else {
			lang.IFn_Cast(A_arbace_stacktrace_A_const_22.GetRawRoot__O()).Invoke_O__O(Lit_3) }
	lang.IFn_Cast(A_arbace_stacktrace_A_const_16.GetRawRoot__O()).Invoke__O()
//line :50:1
	var seq_457000017__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_stacktrace_A_const_17.GetRawRoot__O()); var tmp2 any














	if lang.Util_Identical_O_O__Z(n__1, nil) {
		tmp2 = lang.IFn_Cast(A_arbace_stacktrace_A_const_12.GetRawRoot__O()).Invoke_O__O(st__3) } else {
			tmp2 = lang.IFn_Cast(A_arbace_stacktrace_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Dec_O__Number(n__1), lang.IFn_Cast(A_arbace_stacktrace_A_const_12.GetRawRoot__O()).Invoke_O__O(st__3)) }
//line :65:1
	seq_457000017__4 = tmp1.Invoke_O__O(tmp2)
//line :50:1
	var chunk_457000018__5 any; var count_457000019__6 int64 = 0; var i_457000020__7 int64 = 0; L1: for {














		if lang.Numbers_Lt_J_J__Z(i_457000020__7, count_457000019__6) { var e__8 any = lang.Indexed_Cast(chunk_457000018__5).Nth_I__O(lang.RT_IntCast_J__I(i_457000020__7))


			lang.IFn_Cast(A_arbace_stacktrace_A_const_22.GetRawRoot__O()).Invoke_O__O(Lit_4)
			lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(e__8)
			lang.IFn_Cast(A_arbace_stacktrace_A_const_16.GetRawRoot__O()).Invoke__O()
//line :65:1
			seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = seq_457000017__4, chunk_457000018__5, count_457000019__6, lang.Numbers_Unchecked_inc_J__J(i_457000020__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_stacktrace_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_457000017__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_457000017__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_stacktrace_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_457000017__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_stacktrace_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_457000017__9); seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = lang.IFn_Cast(A_arbace_stacktrace_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_457000017__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var e__10 any = lang.IFn_Cast(A_arbace_stacktrace_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_457000017__9)


				lang.IFn_Cast(A_arbace_stacktrace_A_const_22.GetRawRoot__O()).Invoke_O__O(Lit_4)
				lang.IFn_Cast(A_arbace_stacktrace_A_const_23.GetRawRoot__O()).Invoke_O__O(e__10)
				lang.IFn_Cast(A_arbace_stacktrace_A_const_16.GetRawRoot__O()).Invoke__O()
//line :65:1
				seq_457000017__4, chunk_457000018__5, count_457000019__6, i_457000020__7 = lang.IFn_Cast(A_arbace_stacktrace_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_457000017__9), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :50:1*/panic("a2g: unreachable") }
//line :50:1
func (t *A_arbace_stacktrace_print_stack_trace_A) Invoke_O_O__O(self, tr__0 any) any {




	return lang.IFn_Cast(A_arbace_stacktrace_A_const_27.GetRawRoot__O()).Invoke_O_O__O(tr__0, nil)
}















func A_arbace_stacktrace_print_cause_trace_A_New() *A_arbace_stacktrace_print_cause_trace_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_print_cause_trace_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Ctor() {}
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Invoke_O_O_O__O(self, tr__0, n__1 any) any { { var tr__0_2 any = tr__0; var n__1_2 any = n__1; L1: for {




	lang.IFn_Cast(A_arbace_stacktrace_A_const_27.GetRawRoot__O()).Invoke_O_O__O(tr__0_2, n__1_2)
//line :72:1
	var temp__1927000414__auto____3 any = jrt.Throwable_Cast(tr__0_2).GetCause__Throwable()





	if jrt.A2g_Truth(temp__1927000414__auto____3) { var cause__4 any = temp__1927000414__auto____3
		lang.IFn_Cast(A_arbace_stacktrace_A_const_22.GetRawRoot__O()).Invoke_O__O(Lit_1)
		tr__0_2, n__1_2 = cause__4, n__1_2; continue L1 } else {
//line :78:1
			return nil } } }; /*line :72:1*/panic("a2g: unreachable") }
//line :72:1
func (t *A_arbace_stacktrace_print_cause_trace_A) Invoke_O_O__O(self, tr__0 any) any {


	return lang.IFn_Cast(A_arbace_stacktrace_A_const_28.GetRawRoot__O()).Invoke_O_O__O(tr__0, nil)
}





func A_arbace_stacktrace_e_A_New() *A_arbace_stacktrace_e_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_e_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_stacktrace_e_A) Ctor() {}
//line :82:1
func (t *A_arbace_stacktrace_e_A) Invoke_O__O(self any) any {




	return lang.IFn_Cast(A_arbace_stacktrace_A_const_27.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_stacktrace_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_stacktrace_A_const_31.Get__O()), A_arbace_stacktrace_A_const_30)
}

type A_arbace_stacktrace_A struct{ jrt.Object }

var A_arbace_stacktrace_A_const_pool *jrt.RefArray

var A_arbace_stacktrace_A_const_0 *lang.Var

var A_arbace_stacktrace_A_const_1 any

var A_arbace_stacktrace_A_const_2 *lang.Var

var A_arbace_stacktrace_A_const_3 *lang.Var

var A_arbace_stacktrace_A_const_4 *lang.Var

var A_arbace_stacktrace_A_const_5 any

var A_arbace_stacktrace_A_const_6 *lang.Var

var A_arbace_stacktrace_A_const_7 *lang.Var

var A_arbace_stacktrace_A_const_8 *lang.Var

var A_arbace_stacktrace_A_const_9 *lang.Var

var A_arbace_stacktrace_A_const_10 any

var A_arbace_stacktrace_A_const_11 *lang.Var

var A_arbace_stacktrace_A_const_12 *lang.Var

var A_arbace_stacktrace_A_const_13 *lang.Var

var A_arbace_stacktrace_A_const_14 *lang.Var

var A_arbace_stacktrace_A_const_15 *lang.Var

var A_arbace_stacktrace_A_const_16 *lang.Var

var A_arbace_stacktrace_A_const_17 *lang.Var

var A_arbace_stacktrace_A_const_18 *lang.Var

var A_arbace_stacktrace_A_const_19 *lang.Var

var A_arbace_stacktrace_A_const_20 *lang.Var

var A_arbace_stacktrace_A_const_21 *lang.Var

var A_arbace_stacktrace_A_const_22 *lang.Var

var A_arbace_stacktrace_A_const_23 *lang.Var

var A_arbace_stacktrace_A_const_24 *lang.Var

var A_arbace_stacktrace_A_const_25 *lang.Var

var A_arbace_stacktrace_A_const_26 *lang.Var

var A_arbace_stacktrace_A_const_27 *lang.Var

var A_arbace_stacktrace_A_const_28 *lang.Var

var A_arbace_stacktrace_A_const_29 *lang.Var

var A_arbace_stacktrace_A_const_30 any

var A_arbace_stacktrace_A_const_31 *lang.Var

var A_arbace_stacktrace_A_init jrt.ClassInit

func A_arbace_stacktrace_A_Init() { if !A_arbace_stacktrace_A_init.Done() { A_arbace_stacktrace_A_init.Run(A_arbace_stacktrace_A_clinit) } }

func A_arbace_stacktrace_A_clinit() { A_arbace_stacktrace_A_clinit_p0(); A_arbace_stacktrace_A_clinit_p1(); A_arbace_stacktrace_A_clinit_p2() }

func A_arbace_stacktrace_A_clinit_p0() { A_arbace_stacktrace_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 35); A_arbace_stacktrace_A_const_0 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[3]); A_arbace_stacktrace_A_const_1 = A_arbace_stacktrace_A_const_pool.A[4]; A_arbace_stacktrace_A_const_2 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[5]); A_arbace_stacktrace_A_const_3 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[6]); A_arbace_stacktrace_A_const_4 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[7]); A_arbace_stacktrace_A_const_5 = A_arbace_stacktrace_A_const_pool.A[8]; A_arbace_stacktrace_A_const_6 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[9]); A_arbace_stacktrace_A_const_7 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[10]); A_arbace_stacktrace_A_const_8 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[11]); A_arbace_stacktrace_A_const_9 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[12]); A_arbace_stacktrace_A_const_10 = A_arbace_stacktrace_A_const_pool.A[13]; A_arbace_stacktrace_A_const_11 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[14]) }

func A_arbace_stacktrace_A_clinit_p1() { A_arbace_stacktrace_A_const_12 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[15]); A_arbace_stacktrace_A_const_13 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[16]); A_arbace_stacktrace_A_const_14 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[17]); A_arbace_stacktrace_A_const_15 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[18]); A_arbace_stacktrace_A_const_16 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[19]); A_arbace_stacktrace_A_const_17 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[20]); A_arbace_stacktrace_A_const_18 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[21]); A_arbace_stacktrace_A_const_19 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[22]); A_arbace_stacktrace_A_const_20 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[23]); A_arbace_stacktrace_A_const_21 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[24]); A_arbace_stacktrace_A_const_22 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[25]); A_arbace_stacktrace_A_const_23 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[26]) }

func A_arbace_stacktrace_A_clinit_p2() { A_arbace_stacktrace_A_const_24 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[27]); A_arbace_stacktrace_A_const_25 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[28]); A_arbace_stacktrace_A_const_26 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[29]); A_arbace_stacktrace_A_const_27 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[30]); A_arbace_stacktrace_A_const_28 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[31]); A_arbace_stacktrace_A_const_29 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[32]); A_arbace_stacktrace_A_const_30 = A_arbace_stacktrace_A_const_pool.A[33]; A_arbace_stacktrace_A_const_31 = lang.Var_Cast(A_arbace_stacktrace_A_const_pool.A[34]) }

func A_arbace_stacktrace_A_New() *A_arbace_stacktrace_A { A_arbace_stacktrace_A_Init(); t := &A_arbace_stacktrace_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_A) Ctor() {}

func (t *A_arbace_stacktrace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_A_class }

func (t *A_arbace_stacktrace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_A); return ok }

func A_arbace_stacktrace_A_Cast(x any) *A_arbace_stacktrace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_A_class)) }; return v }



type A_arbace_stacktrace_e_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_e_A_fn_class *jrt.Class



type A_arbace_stacktrace_eval457000004_A struct{ jrt.Object }

func A_arbace_stacktrace_eval457000004_A_New() *A_arbace_stacktrace_eval457000004_A { t := &A_arbace_stacktrace_eval457000004_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_eval457000004_A) Ctor() {}

func (t *A_arbace_stacktrace_eval457000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000004_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000004_A_class }

func (t *A_arbace_stacktrace_eval457000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000004_A); return ok }

func A_arbace_stacktrace_eval457000004_A_Cast(x any) *A_arbace_stacktrace_eval457000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000004_A_class)) }; return v }



type A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class *jrt.Class



type A_arbace_stacktrace_eval457000008_A struct{ jrt.Object }

func A_arbace_stacktrace_eval457000008_A_New() *A_arbace_stacktrace_eval457000008_A { t := &A_arbace_stacktrace_eval457000008_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace_eval457000008_A) Ctor() {}

func (t *A_arbace_stacktrace_eval457000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace_eval457000008_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace_eval457000008_A_class }

func (t *A_arbace_stacktrace_eval457000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace_eval457000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace_eval457000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace_eval457000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace_eval457000008_A); return ok }

func A_arbace_stacktrace_eval457000008_A_Cast(x any) *A_arbace_stacktrace_eval457000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace_eval457000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace_eval457000008_A_class)) }; return v }



type A_arbace_stacktrace_eval457000008_fn__457000009_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_cause_trace_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_print_cause_trace_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_stack_trace_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_print_stack_trace_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_throwable_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_print_throwable_A_fn_class *jrt.Class



type A_arbace_stacktrace_print_trace_element_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_print_trace_element_A_fn_class *jrt.Class



type A_arbace_stacktrace_root_cause_A struct{ a2g_header uint64 }

var A_arbace_stacktrace_root_cause_A_fn_class *jrt.Class
