//line j2g_classes.ae:1
package aot_arbace_stacktrace

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_stacktrace_e_A_class, Name: "arbace.stacktrace$e", Modifiers: 25, Simple: "e", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_e_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_class, Name: "arbace.stacktrace$eval457000004$loading__1927001464__auto____457000005", Modifiers: 25, Simple: "loading__1927001464__auto____457000005", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_eval457000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_stacktrace_eval457000008_fn__457000009_A_class, Name: "arbace.stacktrace$eval457000008$fn__457000009", Modifiers: 25, Simple: "fn__457000009", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000008_fn__457000009_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_eval457000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_stacktrace_print_cause_trace_A_class, Name: "arbace.stacktrace$print_cause_trace", Modifiers: 25, Simple: "print_cause_trace", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_stacktrace_print_stack_trace_A_class, Name: "arbace.stacktrace$print_stack_trace", Modifiers: 25, Simple: "print_stack_trace", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_stack_trace_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_stacktrace_print_throwable_A_class, Name: "arbace.stacktrace$print_throwable", Modifiers: 25, Simple: "print_throwable", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_throwable_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_stacktrace_print_trace_element_A_class, Name: "arbace.stacktrace$print_trace_element", Modifiers: 25, Simple: "print_trace_element", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_trace_element_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_stacktrace_root_cause_A_class, Name: "arbace.stacktrace$root_cause", Modifiers: 25, Simple: "root_cause", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_root_cause_A", Source: "stacktrace.ae", Declaring: &A_arbace_stacktrace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_stacktrace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_A_New()}; return nil }

var A_arbace_stacktrace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_stacktrace_A_new}

var A_arbace_stacktrace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_A"})

func init() { i := A_arbace_stacktrace_A_class.Info(); i.IsInstance = A_arbace_stacktrace_A_InstanceOf; i.Init = A_arbace_stacktrace_A_Init; i.Table = A_arbace_stacktrace_A_members }

var A_arbace_stacktrace_e_A_class *jrt.Class

func A_arbace_stacktrace_eval457000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_eval457000004_A_New()}; return nil }

var A_arbace_stacktrace_eval457000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_stacktrace_eval457000004_A_new}

var A_arbace_stacktrace_eval457000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$eval457000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_stacktrace_A_class, Simple: "eval457000004", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000004_A"})

func init() { i := A_arbace_stacktrace_eval457000004_A_class.Info(); i.IsInstance = A_arbace_stacktrace_eval457000004_A_InstanceOf; i.Table = A_arbace_stacktrace_eval457000004_A_members }

var A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_class *jrt.Class

func A_arbace_stacktrace_eval457000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_eval457000008_A_New()}; return nil }

var A_arbace_stacktrace_eval457000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_stacktrace_eval457000008_A_new}

var A_arbace_stacktrace_eval457000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$eval457000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_stacktrace_A_class, Simple: "eval457000008", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000008_A"})

func init() { i := A_arbace_stacktrace_eval457000008_A_class.Info(); i.IsInstance = A_arbace_stacktrace_eval457000008_A_InstanceOf; i.Table = A_arbace_stacktrace_eval457000008_A_members }

var A_arbace_stacktrace_eval457000008_fn__457000009_A_class *jrt.Class

var A_arbace_stacktrace_print_cause_trace_A_class *jrt.Class

var A_arbace_stacktrace_print_stack_trace_A_class *jrt.Class

var A_arbace_stacktrace_print_throwable_A_class *jrt.Class

var A_arbace_stacktrace_print_trace_element_A_class *jrt.Class

var A_arbace_stacktrace_root_cause_A_class *jrt.Class

func A_arbace_stacktrace__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_stacktrace__init_A_Load__O()}; return nil }

func A_arbace_stacktrace__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace__init_A_New()}; return nil }

var A_arbace_stacktrace__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_stacktrace__init_A_invoke, New: A_arbace_stacktrace__init_A_new}

var A_arbace_stacktrace__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace__init_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace__init_A_class.Info(); i.IsInstance = A_arbace_stacktrace__init_A_InstanceOf; i.Init = A_arbace_stacktrace__init_A_Init; i.Table = A_arbace_stacktrace__init_A_members }
