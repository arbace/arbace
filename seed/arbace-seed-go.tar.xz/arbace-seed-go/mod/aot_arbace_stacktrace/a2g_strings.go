//line a2g_strings.ae:1
package aot_arbace_stacktrace

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn6,authorv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn17,arbace.stacktracem4,R1,s54,Print stack traces oriented towards Clojure, not Java.R2,s13,Stuart Sierrav11,arbace.core13,*loaded-libs*v11,arbace.core6,printfv11,arbace.core10,re-matchesv11,arbace.core5,applyp31,^([A-Za-z0-9_.-]+)\\$(\\w+)__\\d+$v11,arbace.core3,strv11,arbace.core4,restv11,arbace.core7,ex-datav11,arbace.core2,prv11,arbace.core5,classv11,arbace.core7,newlinev11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv17,arbace.stacktrace15,print-throwablev11,arbace.core5,printv17,arbace.stacktrace19,print-trace-elementv11,arbace.core4,takev11,arbace.core10,chunk-restv11,arbace.core4,nextv17,arbace.stacktrace17,print-stack-tracev17,arbace.stacktrace17,print-cause-tracev17,arbace.stacktrace10,root-causel8,v11,arbace.core2,*e")

var Lit_1 *jrt.String = jrt.Intern("Caused by: ")

var Lit_2 *jrt.String = jrt.Intern(" at ")

var Lit_3 *jrt.String = jrt.Intern("[empty stack trace]")

var Lit_4 *jrt.String = jrt.Intern("    ")

var Lit_5 *jrt.String = jrt.Intern("%s: %s")

var Lit_6 *jrt.String = jrt.Intern("invoke")

var Lit_7 *jrt.String = jrt.Intern("%s/%s")

var Lit_8 *jrt.String = jrt.Intern("%s.%s")

var Lit_9 *jrt.String = jrt.Intern(" (%s:%d)")

var Lit_10 *jrt.String = jrt.Intern("")

var Lit_11 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn8,arglistskn3,tagyn9,Throwablekn5,addedkn4,linekn6,columnkn4,fileyn17,StackTraceElementyn2,tryn1,nv11,arbace.core5,in-nsMyn17,arbace.stacktracem4,R0,s54,Print stack traces oriented towards Clojure, not Java.R1,s13,Stuart Sierram4,R0,s54,Print stack traces oriented towards Clojure, not Java.R1,s13,Stuart SierraR2,v11,arbace.core20,*warn-on-reflection*v17,arbace.stacktrace10,root-causem12,R3,L1,V1,Myn2,trm2,R4,R5,R0,s60,Returns the last 'cause' Throwable in a chain of Throwables.R6,s3,1.1R7,i20,R8,i1,R9,s20,arbace/stacktrace.aev17,arbace.stacktrace19,print-trace-elementm12,R3,L1,V1,Myn1,em2,R4,R10,R0,s63,Prints a Clojure-oriented view of one element in a stack trace.R6,s3,1.1R7,i28,R8,i1,R9,s20,arbace/stacktrace.aev17,arbace.stacktrace15,print-throwablem12,R3,L1,V1,Myn2,trm2,R4,R5,R0,s81,Prints the class and message of a Throwable. Prints the ex-data map\n  if present.R6,s3,1.1R7,i40,R8,i1,R9,s20,arbace/stacktrace.aev17,arbace.stacktrace17,print-stack-tracem12,R3,L2,V1,R11,V2,Myn2,trm2,R4,R5,R12,R0,s162,Prints a Clojure-oriented stack trace of tr, a Throwable.\n  Prints a maximum of n stack frames (default: unlimited).\n  Does not print chained exceptions (causes).R6,s3,1.1R7,i50,R8,i1,R9,s20,arbace/stacktrace.aev17,arbace.stacktrace17,print-cause-tracem12,R3,L2,V1,R11,V2,Myn2,trm2,R4,R5,R12,R0,s62,Like print-stack-trace but prints chained exceptions (causes).R6,s3,1.1R7,i72,R8,i1,R9,s20,arbace/stacktrace.aev17,arbace.stacktrace1,em12,R3,L1,V0,R0,s92,REPL utility.  Prints a brief stack trace for the root cause of the\n  most recent exception.R6,s3,1.1R7,i82,R8,i1,R9,s20,arbace/stacktrace.ae")

var Lit_12 *jrt.String = jrt.Intern("arbace.stacktrace$eval457000004$loading__1927001464__auto____457000005")

var Lit_13 *jrt.String = jrt.Intern("arbace.stacktrace$eval457000008$fn__457000009")

var Lit_14 *jrt.String = jrt.Intern("arbace.stacktrace$root_cause")

var Lit_15 *jrt.String = jrt.Intern("arbace.stacktrace$print_trace_element")

var Lit_16 *jrt.String = jrt.Intern("arbace.stacktrace$print_throwable")

var Lit_17 *jrt.String = jrt.Intern("arbace.stacktrace$print_stack_trace")

var Lit_18 *jrt.String = jrt.Intern("arbace.stacktrace$print_cause_trace")

var Lit_19 *jrt.String = jrt.Intern("arbace.stacktrace$e")
