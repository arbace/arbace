//line a2g_strings.ae:1
package aot_arbace_stacktrace

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.stacktrace")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("Print stack traces oriented towards Clojure, not Java.")

var Lit_8 *jrt.String = jrt.Intern("author")

var Lit_9 *jrt.String = jrt.Intern("Stuart Sierra")

var Lit_10 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_11 *jrt.String = jrt.Intern("printf")

var Lit_12 *jrt.String = jrt.Intern("re-matches")

var Lit_13 *jrt.String = jrt.Intern("apply")

var Lit_14 *jrt.String = jrt.Intern("^([A-Za-z0-9_.-]+)\\$(\\w+)__\\d+$")

var Lit_15 *jrt.String = jrt.Intern("str")

var Lit_16 *jrt.String = jrt.Intern("rest")

var Lit_17 *jrt.String = jrt.Intern("ex-data")

var Lit_18 *jrt.String = jrt.Intern("pr")

var Lit_19 *jrt.String = jrt.Intern("class")

var Lit_20 *jrt.String = jrt.Intern("newline")

var Lit_21 *jrt.String = jrt.Intern("seq")

var Lit_22 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_23 *jrt.String = jrt.Intern("chunk-first")

var Lit_24 *jrt.String = jrt.Intern("first")

var Lit_25 *jrt.String = jrt.Intern("print-throwable")

var Lit_26 *jrt.String = jrt.Intern("print")

var Lit_27 *jrt.String = jrt.Intern("print-trace-element")

var Lit_28 *jrt.String = jrt.Intern("take")

var Lit_29 *jrt.String = jrt.Intern("chunk-rest")

var Lit_30 *jrt.String = jrt.Intern("next")

var Lit_31 *jrt.String = jrt.Intern("print-stack-trace")

var Lit_32 *jrt.String = jrt.Intern("print-cause-trace")

var Lit_33 *jrt.String = jrt.Intern("root-cause")

var Lit_34 *jrt.String = jrt.Intern("*e")

var Lit_35 *jrt.String = jrt.Intern("arbace.stacktrace$e")

var Lit_36 *jrt.String = jrt.Intern("arbace.stacktrace$eval457000004$loading__1927001464__auto____457000005")

var Lit_37 *jrt.String = jrt.Intern("arbace.stacktrace$eval457000008$fn__457000009")

var Lit_38 *jrt.String = jrt.Intern("arbace.stacktrace$print_cause_trace")

var Lit_39 *jrt.String = jrt.Intern("Caused by: ")

var Lit_40 *jrt.String = jrt.Intern("arbace.stacktrace$print_stack_trace")

var Lit_41 *jrt.String = jrt.Intern(" at ")

var Lit_42 *jrt.String = jrt.Intern("[empty stack trace]")

var Lit_43 *jrt.String = jrt.Intern("    ")

var Lit_44 *jrt.String = jrt.Intern("arbace.stacktrace$print_throwable")

var Lit_45 *jrt.String = jrt.Intern("%s: %s")

var Lit_46 *jrt.String = jrt.Intern("arbace.stacktrace$print_trace_element")

var Lit_47 *jrt.String = jrt.Intern("invoke")

var Lit_48 *jrt.String = jrt.Intern("%s/%s")

var Lit_49 *jrt.String = jrt.Intern("%s.%s")

var Lit_50 *jrt.String = jrt.Intern(" (%s:%d)")

var Lit_51 *jrt.String = jrt.Intern("")

var Lit_52 *jrt.String = jrt.Intern("arbace.stacktrace$root_cause")

var Lit_53 *jrt.String = jrt.Intern("in-ns")

var Lit_54 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_55 *jrt.String = jrt.Intern("arglists")

var Lit_56 *jrt.String = jrt.Intern("tr")

var Lit_57 *jrt.String = jrt.Intern("tag")

var Lit_58 *jrt.String = jrt.Intern("Throwable")

var Lit_59 *jrt.String = jrt.Intern("Returns the last 'cause' Throwable in a chain of Throwables.")

var Lit_60 *jrt.String = jrt.Intern("added")

var Lit_61 *jrt.String = jrt.Intern("1.1")

var Lit_62 *jrt.String = jrt.Intern("line")

var Lit_63 *jrt.String = jrt.Intern("column")

var Lit_64 *jrt.String = jrt.Intern("file")

var Lit_65 *jrt.String = jrt.Intern("arbace/stacktrace.ae")

var Lit_66 *jrt.String = jrt.Intern("e")

var Lit_67 *jrt.String = jrt.Intern("StackTraceElement")

var Lit_68 *jrt.String = jrt.Intern("Prints a Clojure-oriented view of one element in a stack trace.")

var Lit_69 *jrt.String = jrt.Intern("Prints the class and message of a Throwable. Prints the ex-data map\n  if present.")

var Lit_70 *jrt.String = jrt.Intern("n")

var Lit_71 *jrt.String = jrt.Intern("Prints a Clojure-oriented stack trace of tr, a Throwable.\n  Prints a maximum of n stack frames (default: unlimited).\n  Does not print chained exceptions (causes).")

var Lit_72 *jrt.String = jrt.Intern("Like print-stack-trace but prints chained exceptions (causes).")

var Lit_73 *jrt.String = jrt.Intern("REPL utility.  Prints a brief stack trace for the root cause of the\n  most recent exception.")
