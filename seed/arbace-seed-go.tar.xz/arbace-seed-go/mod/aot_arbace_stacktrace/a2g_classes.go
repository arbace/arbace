//line a2g_classes.ae:1
package aot_arbace_stacktrace

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_stacktrace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_A_New()}; return nil }

var A_arbace_stacktrace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_stacktrace_A_new}

var A_arbace_stacktrace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_A"})

func init() { i := A_arbace_stacktrace_A_class.Info(); i.IsInstance = A_arbace_stacktrace_A_InstanceOf; i.Init = A_arbace_stacktrace_A_Init; i.Table = A_arbace_stacktrace_A_members; jrt.RegisterGoType(A_arbace_stacktrace_A_class, reflect.TypeFor[A_arbace_stacktrace_A]()) }

func A_arbace_stacktrace_e_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_e_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_stacktrace_e_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_e_A_New()}; return nil }

func A_arbace_stacktrace_e_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_e_A_fn_class)}; return nil }

var A_arbace_stacktrace_e_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_e_A_invoke, New: A_arbace_stacktrace_e_A_new, Get: A_arbace_stacktrace_e_A_get}

var A_arbace_stacktrace_e_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$e", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_stacktrace_A_class, Simple: "e", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_e_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_e_A_class.Info(); i.IsInstance = A_arbace_stacktrace_e_A_InstanceOf; i.Init = A_arbace_stacktrace_e_A_Init; i.Table = A_arbace_stacktrace_e_A_members; jrt.RegisterGoType(A_arbace_stacktrace_e_A_class, reflect.TypeFor[A_arbace_stacktrace_e_A]()) }

func A_arbace_stacktrace_eval457000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_eval457000004_A_New()}; return nil }

var A_arbace_stacktrace_eval457000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_stacktrace_eval457000004_A_new}

var A_arbace_stacktrace_eval457000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$eval457000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_stacktrace_A_class, Simple: "eval457000004", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000004_A"})

func init() { i := A_arbace_stacktrace_eval457000004_A_class.Info(); i.IsInstance = A_arbace_stacktrace_eval457000004_A_InstanceOf; i.Table = A_arbace_stacktrace_eval457000004_A_members; jrt.RegisterGoType(A_arbace_stacktrace_eval457000004_A_class, reflect.TypeFor[A_arbace_stacktrace_eval457000004_A]()) }

func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_New()}; return nil }

func A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class)}; return nil }

var A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_invoke, New: A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_new, Get: A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_get}

var A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$eval457000004$loading__1927001464__auto____457000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_stacktrace_eval457000004_A_class, Simple: "loading__1927001464__auto____457000005", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_class.Info(); i.IsInstance = A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_InstanceOf; i.Init = A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_Init; i.Table = A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_members; jrt.RegisterGoType(A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_class, reflect.TypeFor[A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A]()) }

func A_arbace_stacktrace_eval457000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_eval457000008_A_New()}; return nil }

var A_arbace_stacktrace_eval457000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_stacktrace_eval457000008_A_new}

var A_arbace_stacktrace_eval457000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$eval457000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_stacktrace_A_class, Simple: "eval457000008", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000008_A"})

func init() { i := A_arbace_stacktrace_eval457000008_A_class.Info(); i.IsInstance = A_arbace_stacktrace_eval457000008_A_InstanceOf; i.Table = A_arbace_stacktrace_eval457000008_A_members; jrt.RegisterGoType(A_arbace_stacktrace_eval457000008_A_class, reflect.TypeFor[A_arbace_stacktrace_eval457000008_A]()) }

func A_arbace_stacktrace_eval457000008_fn__457000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_eval457000008_fn__457000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_stacktrace_eval457000008_fn__457000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_eval457000008_fn__457000009_A_New()}; return nil }

func A_arbace_stacktrace_eval457000008_fn__457000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class)}; return nil }

var A_arbace_stacktrace_eval457000008_fn__457000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_eval457000008_fn__457000009_A_invoke, New: A_arbace_stacktrace_eval457000008_fn__457000009_A_new, Get: A_arbace_stacktrace_eval457000008_fn__457000009_A_get}

var A_arbace_stacktrace_eval457000008_fn__457000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$eval457000008$fn__457000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_stacktrace_eval457000008_A_class, Simple: "fn__457000009", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_eval457000008_fn__457000009_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_eval457000008_fn__457000009_A_class.Info(); i.IsInstance = A_arbace_stacktrace_eval457000008_fn__457000009_A_InstanceOf; i.Init = A_arbace_stacktrace_eval457000008_fn__457000009_A_Init; i.Table = A_arbace_stacktrace_eval457000008_fn__457000009_A_members; jrt.RegisterGoType(A_arbace_stacktrace_eval457000008_fn__457000009_A_class, reflect.TypeFor[A_arbace_stacktrace_eval457000008_fn__457000009_A]()) }

func A_arbace_stacktrace_print_cause_trace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_print_cause_trace_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_stacktrace_print_cause_trace_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_stacktrace_print_cause_trace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_print_cause_trace_A_New()}; return nil }

func A_arbace_stacktrace_print_cause_trace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_print_cause_trace_A_fn_class)}; return nil }

var A_arbace_stacktrace_print_cause_trace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_print_cause_trace_A_invoke, New: A_arbace_stacktrace_print_cause_trace_A_new, Get: A_arbace_stacktrace_print_cause_trace_A_get}

var A_arbace_stacktrace_print_cause_trace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$print_cause_trace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_stacktrace_A_class, Simple: "print_cause_trace", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_print_cause_trace_A_class.Info(); i.IsInstance = A_arbace_stacktrace_print_cause_trace_A_InstanceOf; i.Init = A_arbace_stacktrace_print_cause_trace_A_Init; i.Table = A_arbace_stacktrace_print_cause_trace_A_members; jrt.RegisterGoType(A_arbace_stacktrace_print_cause_trace_A_class, reflect.TypeFor[A_arbace_stacktrace_print_cause_trace_A]()) }

func A_arbace_stacktrace_print_stack_trace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_print_stack_trace_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_stacktrace_print_stack_trace_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_stacktrace_print_stack_trace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_print_stack_trace_A_New()}; return nil }

func A_arbace_stacktrace_print_stack_trace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_print_stack_trace_A_fn_class)}; return nil }

var A_arbace_stacktrace_print_stack_trace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_print_stack_trace_A_invoke, New: A_arbace_stacktrace_print_stack_trace_A_new, Get: A_arbace_stacktrace_print_stack_trace_A_get}

var A_arbace_stacktrace_print_stack_trace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$print_stack_trace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_stacktrace_A_class, Simple: "print_stack_trace", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_stack_trace_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_print_stack_trace_A_class.Info(); i.IsInstance = A_arbace_stacktrace_print_stack_trace_A_InstanceOf; i.Init = A_arbace_stacktrace_print_stack_trace_A_Init; i.Table = A_arbace_stacktrace_print_stack_trace_A_members; jrt.RegisterGoType(A_arbace_stacktrace_print_stack_trace_A_class, reflect.TypeFor[A_arbace_stacktrace_print_stack_trace_A]()) }

func A_arbace_stacktrace_print_throwable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_print_throwable_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_stacktrace_print_throwable_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_print_throwable_A_New()}; return nil }

func A_arbace_stacktrace_print_throwable_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_print_throwable_A_fn_class)}; return nil }

var A_arbace_stacktrace_print_throwable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_print_throwable_A_invoke, New: A_arbace_stacktrace_print_throwable_A_new, Get: A_arbace_stacktrace_print_throwable_A_get}

var A_arbace_stacktrace_print_throwable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$print_throwable", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_stacktrace_A_class, Simple: "print_throwable", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_throwable_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_print_throwable_A_class.Info(); i.IsInstance = A_arbace_stacktrace_print_throwable_A_InstanceOf; i.Init = A_arbace_stacktrace_print_throwable_A_Init; i.Table = A_arbace_stacktrace_print_throwable_A_members; jrt.RegisterGoType(A_arbace_stacktrace_print_throwable_A_class, reflect.TypeFor[A_arbace_stacktrace_print_throwable_A]()) }

func A_arbace_stacktrace_print_trace_element_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_print_trace_element_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_stacktrace_print_trace_element_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_print_trace_element_A_New()}; return nil }

func A_arbace_stacktrace_print_trace_element_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_print_trace_element_A_fn_class)}; return nil }

var A_arbace_stacktrace_print_trace_element_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_print_trace_element_A_invoke, New: A_arbace_stacktrace_print_trace_element_A_new, Get: A_arbace_stacktrace_print_trace_element_A_get}

var A_arbace_stacktrace_print_trace_element_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$print_trace_element", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_stacktrace_A_class, Simple: "print_trace_element", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_print_trace_element_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_print_trace_element_A_class.Info(); i.IsInstance = A_arbace_stacktrace_print_trace_element_A_InstanceOf; i.Init = A_arbace_stacktrace_print_trace_element_A_Init; i.Table = A_arbace_stacktrace_print_trace_element_A_members; jrt.RegisterGoType(A_arbace_stacktrace_print_trace_element_A_class, reflect.TypeFor[A_arbace_stacktrace_print_trace_element_A]()) }

func A_arbace_stacktrace_root_cause_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_stacktrace_root_cause_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_stacktrace_root_cause_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace_root_cause_A_New()}; return nil }

func A_arbace_stacktrace_root_cause_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_stacktrace_root_cause_A_fn_class)}; return nil }

var A_arbace_stacktrace_root_cause_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_stacktrace_root_cause_A_invoke, New: A_arbace_stacktrace_root_cause_A_new, Get: A_arbace_stacktrace_root_cause_A_get}

var A_arbace_stacktrace_root_cause_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace$root_cause", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_stacktrace_A_class, Simple: "root_cause", Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace_root_cause_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace_root_cause_A_class.Info(); i.IsInstance = A_arbace_stacktrace_root_cause_A_InstanceOf; i.Init = A_arbace_stacktrace_root_cause_A_Init; i.Table = A_arbace_stacktrace_root_cause_A_members; jrt.RegisterGoType(A_arbace_stacktrace_root_cause_A_class, reflect.TypeFor[A_arbace_stacktrace_root_cause_A]()) }

func A_arbace_stacktrace__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_stacktrace__init_A_Load__O(); case 1: return A_arbace_stacktrace__init_A_Unit0__O(); case 2: return A_arbace_stacktrace__init_A_Unit1__O(); case 3: return A_arbace_stacktrace__init_A_Unit10__O(); case 4: return A_arbace_stacktrace__init_A_Unit2__O(); case 5: return A_arbace_stacktrace__init_A_Unit3__O(); case 6: return A_arbace_stacktrace__init_A_Unit4__O(); case 7: return A_arbace_stacktrace__init_A_Unit5__O(); case 8: return A_arbace_stacktrace__init_A_Unit6__O(); case 9: return A_arbace_stacktrace__init_A_Unit7__O(); case 10: return A_arbace_stacktrace__init_A_Unit8__O(); case 11: return A_arbace_stacktrace__init_A_Unit9__O()}; return nil }

func A_arbace_stacktrace__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_stacktrace__init_A_New()}; return nil }

var A_arbace_stacktrace__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_stacktrace__init_A_invoke, New: A_arbace_stacktrace__init_A_new}

var A_arbace_stacktrace__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.stacktrace__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_stacktrace.A_arbace_stacktrace__init_A", Source: "stacktrace.ae"})

func init() { i := A_arbace_stacktrace__init_A_class.Info(); i.IsInstance = A_arbace_stacktrace__init_A_InstanceOf; i.Init = A_arbace_stacktrace__init_A_Init; i.Table = A_arbace_stacktrace__init_A_members; jrt.RegisterGoType(A_arbace_stacktrace__init_A_class, reflect.TypeFor[A_arbace_stacktrace__init_A]()) }
