//line aot_arbace_stacktrace__init.ae:1
package aot_arbace_stacktrace

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_stacktrace__init_A_Load__O() any { A_arbace_stacktrace__init_A_Init(); A_arbace_stacktrace__init_A_Unit0__O(); A_arbace_stacktrace__init_A_Unit1__O(); A_arbace_stacktrace__init_A_Unit2__O(); A_arbace_stacktrace__init_A_Unit3__O(); A_arbace_stacktrace__init_A_Unit4__O(); A_arbace_stacktrace__init_A_Unit5__O(); A_arbace_stacktrace__init_A_Unit6__O(); A_arbace_stacktrace__init_A_Unit7__O(); A_arbace_stacktrace__init_A_Unit8__O(); A_arbace_stacktrace__init_A_Unit9__O(); A_arbace_stacktrace__init_A_Unit10__O(); return nil }








func A_arbace_stacktrace__init_A_Unit0__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return lang.IFn_Cast(jrt.NN(A_arbace_stacktrace__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_stacktrace__init_A_const_1) }
//line :14:1
func A_arbace_stacktrace__init_A_Unit1__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_stacktrace__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_2)) }
//line :14:1
func A_arbace_stacktrace__init_A_Unit2__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 any = A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_New(); var tmp2 *jrt.Class; A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_Init(); tmp2 = A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :14:1
func A_arbace_stacktrace__init_A_Unit3__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_stacktrace__init_A_const_1)).Equals_O__Z(A_arbace_stacktrace__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_stacktrace_eval457000008_fn__457000009_A_New(); var tmp2 *jrt.Class; A_arbace_stacktrace_eval457000008_fn__457000009_A_Init(); tmp2 = A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_stacktrace__init_A_Unit4__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_stacktrace__init_A_Unit5__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_5; var tmp2 any = A_arbace_stacktrace_root_cause_A_New(); var tmp3 *jrt.Class; A_arbace_stacktrace_root_cause_A_Init(); tmp3 = A_arbace_stacktrace_root_cause_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_5; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_6)); return A_arbace_stacktrace__init_A_const_5.Ref() }







func A_arbace_stacktrace__init_A_Unit6__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_7; var tmp2 any = A_arbace_stacktrace_print_trace_element_A_New(); var tmp3 *jrt.Class; A_arbace_stacktrace_print_trace_element_A_Init(); tmp3 = A_arbace_stacktrace_print_trace_element_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_8)); return A_arbace_stacktrace__init_A_const_7.Ref() }











func A_arbace_stacktrace__init_A_Unit7__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(40, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_9; var tmp2 any = A_arbace_stacktrace_print_throwable_A_New(); var tmp3 *jrt.Class; A_arbace_stacktrace_print_throwable_A_Init(); tmp3 = A_arbace_stacktrace_print_throwable_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_10)); return A_arbace_stacktrace__init_A_const_9.Ref() }









func A_arbace_stacktrace__init_A_Unit8__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(50, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_11; var tmp2 any = A_arbace_stacktrace_print_stack_trace_A_New(); var tmp3 *jrt.Class; A_arbace_stacktrace_print_stack_trace_A_Init(); tmp3 = A_arbace_stacktrace_print_stack_trace_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_12)); return A_arbace_stacktrace__init_A_const_11.Ref() }





















func A_arbace_stacktrace__init_A_Unit9__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_13; var tmp2 any = A_arbace_stacktrace_print_cause_trace_A_New(); var tmp3 *jrt.Class; A_arbace_stacktrace_print_cause_trace_A_Init(); tmp3 = A_arbace_stacktrace_print_cause_trace_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_14)); return A_arbace_stacktrace__init_A_const_13.Ref() }









func A_arbace_stacktrace__init_A_Unit10__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_15; var tmp2 any = A_arbace_stacktrace_e_A_New(); var tmp3 *jrt.Class; A_arbace_stacktrace_e_A_Init(); tmp3 = A_arbace_stacktrace_e_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_16)); return A_arbace_stacktrace__init_A_const_15.Ref() }



type A_arbace_stacktrace__init_A struct{ jrt.Object }

var A_arbace_stacktrace__init_A_const_0 *lang.Var

var A_arbace_stacktrace__init_A_const_1 any

var A_arbace_stacktrace__init_A_const_2 any

var A_arbace_stacktrace__init_A_const_3 any

var A_arbace_stacktrace__init_A_const_4 *lang.Var

var A_arbace_stacktrace__init_A_const_5 *lang.Var

var A_arbace_stacktrace__init_A_const_6 any

var A_arbace_stacktrace__init_A_const_7 *lang.Var

var A_arbace_stacktrace__init_A_const_8 any

var A_arbace_stacktrace__init_A_const_9 *lang.Var

var A_arbace_stacktrace__init_A_const_10 any

var A_arbace_stacktrace__init_A_const_11 *lang.Var

var A_arbace_stacktrace__init_A_const_12 any

var A_arbace_stacktrace__init_A_const_13 *lang.Var

var A_arbace_stacktrace__init_A_const_14 any

var A_arbace_stacktrace__init_A_const_15 *lang.Var

var A_arbace_stacktrace__init_A_const_16 any

var A_arbace_stacktrace__init_A_init jrt.ClassInit

func A_arbace_stacktrace__init_A_Init() { if !A_arbace_stacktrace__init_A_init.Done() { A_arbace_stacktrace__init_A_init.Run(A_arbace_stacktrace__init_A_clinit) } }

func A_arbace_stacktrace__init_A_clinit() { A_arbace_stacktrace__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_stacktrace__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_stacktrace__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_stacktrace__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_stacktrace__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_stacktrace__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_stacktrace__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_59, lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_65)); A_arbace_stacktrace__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_stacktrace__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_66)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_68, lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_65)); A_arbace_stacktrace__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); A_arbace_stacktrace__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_69, lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_65)); A_arbace_stacktrace__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_5, Lit_31); A_arbace_stacktrace__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref()), lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_70).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_71, lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(50).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_65)); A_arbace_stacktrace__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_stacktrace__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref()), lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_70).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_72, lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_65)); A_arbace_stacktrace__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_5, Lit_66); A_arbace_stacktrace__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_73, lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_65)) }

func A_arbace_stacktrace__init_A_New() *A_arbace_stacktrace__init_A { A_arbace_stacktrace__init_A_Init(); t := &A_arbace_stacktrace__init_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace__init_A) Ctor() {}

func (t *A_arbace_stacktrace__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace__init_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace__init_A_class }

func (t *A_arbace_stacktrace__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_stacktrace__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace__init_A); return ok }

func A_arbace_stacktrace__init_A_Cast(x any) *A_arbace_stacktrace__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace__init_A_class)) }; return v }
