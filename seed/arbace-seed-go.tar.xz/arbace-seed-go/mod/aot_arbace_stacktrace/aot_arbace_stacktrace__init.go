//line aot_arbace_stacktrace__init.ae:1
package aot_arbace_stacktrace

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_stacktrace__init_A_Load__O() any { A_arbace_stacktrace__init_A_Init(); jrt.StartCheck(); A_arbace_stacktrace__init_A_Unit0__O(); A_arbace_stacktrace__init_A_Unit1__O(); A_arbace_stacktrace__init_A_Unit2__O(); A_arbace_stacktrace__init_A_Unit3__O(); A_arbace_stacktrace__init_A_Unit4__O(); A_arbace_stacktrace__init_A_Unit5__O(); A_arbace_stacktrace__init_A_Unit6__O(); A_arbace_stacktrace__init_A_Unit7__O(); A_arbace_stacktrace__init_A_Unit8__O(); A_arbace_stacktrace__init_A_Unit9__O(); A_arbace_stacktrace__init_A_Unit10__O(); return nil }








func A_arbace_stacktrace__init_A_Unit0__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); return lang.IFn_Cast(A_arbace_stacktrace__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_stacktrace__init_A_const_1) }
//line :14:1
func A_arbace_stacktrace__init_A_Unit1__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_stacktrace__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_2)) }
//line :14:1
func A_arbace_stacktrace__init_A_Unit2__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); var tmp1 any = A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_stacktrace_eval457000004_loading__1927001464__auto____457000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :14:1
func A_arbace_stacktrace__init_A_Unit3__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_stacktrace__init_A_const_1)).Equals_O__Z(A_arbace_stacktrace__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_stacktrace_eval457000008_fn__457000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_stacktrace_eval457000008_fn__457000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_stacktrace__init_A_Unit4__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return A_arbace_stacktrace__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_stacktrace__init_A_Unit5__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_5; var tmp2 any = A_arbace_stacktrace_root_cause_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_stacktrace_root_cause_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_stacktrace_root_cause_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_6)); return A_arbace_stacktrace__init_A_const_5 }







func A_arbace_stacktrace__init_A_Unit6__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_7; var tmp2 any = A_arbace_stacktrace_print_trace_element_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_stacktrace_print_trace_element_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_stacktrace_print_trace_element_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_8)); return A_arbace_stacktrace__init_A_const_7 }











func A_arbace_stacktrace__init_A_Unit7__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_9; var tmp2 any = A_arbace_stacktrace_print_throwable_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_stacktrace_print_throwable_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_stacktrace_print_throwable_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_10)); return A_arbace_stacktrace__init_A_const_9 }









func A_arbace_stacktrace__init_A_Unit8__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_11; var tmp2 any = A_arbace_stacktrace_print_stack_trace_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_stacktrace_print_stack_trace_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_stacktrace_print_stack_trace_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_12)); return A_arbace_stacktrace__init_A_const_11 }





















func A_arbace_stacktrace__init_A_Unit9__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_13; var tmp2 any = A_arbace_stacktrace_print_cause_trace_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_stacktrace_print_cause_trace_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_stacktrace_print_cause_trace_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_14)); return A_arbace_stacktrace__init_A_const_13 }









func A_arbace_stacktrace__init_A_Unit10__O() any { A_arbace_stacktrace__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_stacktrace__init_A_const_15; var tmp2 any = A_arbace_stacktrace_e_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_stacktrace_e_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_stacktrace_e_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_stacktrace__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_stacktrace__init_A_const_16)); return A_arbace_stacktrace__init_A_const_15 }



type A_arbace_stacktrace__init_A struct{ jrt.Object }

var A_arbace_stacktrace__init_A_const_pool *jrt.RefArray

var A_arbace_stacktrace__init_A_const_0 *lang.Var

var A_arbace_stacktrace__init_A_const_1 any

var A_arbace_stacktrace__init_A_const_2 any

var A_arbace_stacktrace__init_A_const_3 any

var A_arbace_stacktrace__init_A_const_4 *lang.Var

var A_arbace_stacktrace__init_A_const_5 *lang.Var

var A_arbace_stacktrace__init_A_const_6 any

var A_arbace_stacktrace__init_A_const_7 *lang.Var

var A_arbace_stacktrace__init_A_const_8 any

var A_arbace_stacktrace__init_A_const_9 *lang.Var

var A_arbace_stacktrace__init_A_const_10 any

var A_arbace_stacktrace__init_A_const_11 *lang.Var

var A_arbace_stacktrace__init_A_const_12 any

var A_arbace_stacktrace__init_A_const_13 *lang.Var

var A_arbace_stacktrace__init_A_const_14 any

var A_arbace_stacktrace__init_A_const_15 *lang.Var

var A_arbace_stacktrace__init_A_const_16 any

var A_arbace_stacktrace__init_A_init jrt.ClassInit

func A_arbace_stacktrace__init_A_Init() { if !A_arbace_stacktrace__init_A_init.Done() { A_arbace_stacktrace__init_A_init.Run(A_arbace_stacktrace__init_A_clinit) } }

func A_arbace_stacktrace__init_A_clinit() { jrt.StartCheck(); A_arbace_stacktrace__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_11, 30); A_arbace_stacktrace__init_A_const_0 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[13]); A_arbace_stacktrace__init_A_const_1 = A_arbace_stacktrace__init_A_const_pool.A[14]; A_arbace_stacktrace__init_A_const_2 = A_arbace_stacktrace__init_A_const_pool.A[15]; A_arbace_stacktrace__init_A_const_3 = A_arbace_stacktrace__init_A_const_pool.A[16]; A_arbace_stacktrace__init_A_const_4 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[17]); A_arbace_stacktrace__init_A_const_5 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[18]); A_arbace_stacktrace__init_A_const_6 = A_arbace_stacktrace__init_A_const_pool.A[19]; A_arbace_stacktrace__init_A_const_7 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[20]); A_arbace_stacktrace__init_A_const_8 = A_arbace_stacktrace__init_A_const_pool.A[21]; A_arbace_stacktrace__init_A_const_9 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[22]); A_arbace_stacktrace__init_A_const_10 = A_arbace_stacktrace__init_A_const_pool.A[23]; A_arbace_stacktrace__init_A_const_11 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[24]); A_arbace_stacktrace__init_A_const_12 = A_arbace_stacktrace__init_A_const_pool.A[25]; A_arbace_stacktrace__init_A_const_13 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[26]); A_arbace_stacktrace__init_A_const_14 = A_arbace_stacktrace__init_A_const_pool.A[27]; A_arbace_stacktrace__init_A_const_15 = lang.Var_Cast(A_arbace_stacktrace__init_A_const_pool.A[28]); A_arbace_stacktrace__init_A_const_16 = A_arbace_stacktrace__init_A_const_pool.A[29] }

func A_arbace_stacktrace__init_A_New() *A_arbace_stacktrace__init_A { A_arbace_stacktrace__init_A_Init(); t := &A_arbace_stacktrace__init_A{}; t.Ctor(); return t }

func (t *A_arbace_stacktrace__init_A) Ctor() {}

func (t *A_arbace_stacktrace__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_stacktrace__init_A) GetClass__Class() *jrt.Class { return A_arbace_stacktrace__init_A_class }

func (t *A_arbace_stacktrace__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_stacktrace__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_stacktrace__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_stacktrace__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_stacktrace__init_A); return ok }

func A_arbace_stacktrace__init_A_Cast(x any) *A_arbace_stacktrace__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_stacktrace__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_stacktrace__init_A_class)) }; return v }
