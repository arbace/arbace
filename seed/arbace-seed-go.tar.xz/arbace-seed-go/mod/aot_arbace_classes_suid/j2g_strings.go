//line j2g_strings.ae:1
package aot_arbace_classes_suid

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn22,arbace.classes.analyzeyn1,ayn22,arbace.classes.opcodesyn7,Opcodeskn3,dockn7,methodskn4,modskn4,namekn10,interfaceskn6,fieldskn6,clinitkn4,desckn5,ctorskn3,topkn7,nestingkn5,flagskn11,inner-flagskn15,outer-instance?kn5,outerkn5,statekn9,interfacekn10,annotationkn4,anonkn5,localkn4,typekn11,uses-assertkn10,clj-constskn16,interface-assertkn4,kindkn8,capturesv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn19,arbace.classes.suidm2,R10,s1997,The default serialVersionUID of a class of Java forms (JCS168, doc/classes/JAVA-DEFERRED-TRIAGE.md,\n  \"As built: JCS167 slices 2-3 (write-ahead)\"): jdk26u's java.io.ObjectStreamClass.computeDefaultSUID\n  (openjdk/jdk26u at baf63fb, src/java.base/share/classes/java/io/ObjectStreamClass.java) rule for rule,\n  over the class as javac compiles it rather than over reflection: the SHA-1 of the class's name, its\n  modifiers (public, final, interface, abstract; an interface abstract when it declares methods), its\n  interfaces' names sorted, its fields sorted by name (all but the private static and the private\n  transient ones; name, modifiers, descriptor), <clinit> when it has one, its non-private constructors\n  sorted by descriptor and its non-private methods sorted by name and descriptor (\"<init>\" or the name,\n  modifiers, the descriptor with dots), written by DataOutputStream, the first eight bytes of the hash\n  little-endian.\n\n  The class as javac compiles it (class-view) is the declaration arbace.classes.analyze makes (javac's\n  derived members: default and anonymous constructors with their implicit parameters, a.ctor-real-desc;\n  bridges; records' and enums' members) and javac's synthetic members a serializable class has besides\n  (Lower, jdk26u): the enclosing instance's field this$N (final, synthetic; javac keeps it in a\n  serializable class, Lower.shouldEmitOuterThis), the captured locals' fields val$x (final, synthetic),\n  $assertionsDisabled (static, final, synthetic) in a class with an assert, and the <clinit> that a\n  static initializer, a static field's non-constant initializer, an assert or an enum's constants give.\n  j2g writes it into a translated class's ClassInfo.SerialUID (arbace.j2g.out, J2G_DEFAULT_SUID=1) and\n  the variant's computeDefaultSUID asks it first (jdk.internal.jrt.SerialAlloc.defaultSUID): the table of\n  a translated JDK class lists only its public and serial members, so the stock computation over it\n  gives another value than the JDK's.v11,arbace.core3,notl0,R11,R12,v19,arbace.classes.suid6,PUBLICv19,arbace.classes.suid5,FINALv19,arbace.classes.suid9,INTERFACEv19,arbace.classes.suid8,ABSTRACTv19,arbace.classes.suid4,has?v11,arbace.core3,seqR13,v11,arbace.core4,sortR14,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core7,sort-byR15,v19,arbace.classes.suid7,PRIVATEv19,arbace.classes.suid9,PROTECTEDv19,arbace.classes.suid6,STATICv19,arbace.classes.suid8,VOLATILEv19,arbace.classes.suid9,TRANSIENTR16,v19,arbace.classes.suid12,SYNCHRONIZEDv19,arbace.classes.suid6,NATIVEv19,arbace.classes.suid6,STRICTv11,arbace.core4,juxtR17,v11,arbace.core10,chunk-restv11,arbace.core4,nextR18,v13,arbace.string7,replaceR19,R20,R21,R22,v22,arbace.classes.analyze4,declR23,R24,R25,S2,R26,R27,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core4,restS2,R28,R29,v22,arbace.classes.analyze18,capture-field-nameR30,R31,v19,arbace.classes.suid10,class-modsv11,arbace.core3,mapv11,arbace.core6,concatR32,R33,v22,arbace.classes.analyze14,ctor-real-descS2,s6,<init>s8,<clinit>S2,s6,<init>s8,<clinit>R34,v19,arbace.classes.suid16,outer-this-levelv20,arbace.classes.types14,internal->descR35,v19,arbace.classes.suid7,suid-ofv19,arbace.classes.suid10,class-view")

var Lit_1 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$dotted__336000033")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000035__336000039")

var Lit_3 *jrt.String = jrt.Intern("this$")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000045__336000049")

var Lit_5 *jrt.String = jrt.Intern("$assertionsDisabled")

var Lit_6 *jrt.String = jrt.Intern("Z")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000055__336000059")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000065__336000069")

var Lit_9 *jrt.String = jrt.Intern("/")

var Lit_10 *jrt.String = jrt.Intern(".")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000035__336000039$fn__336000040")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000035__336000039$fn__336000040$fn__336000041")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000045__336000049$fn__336000050")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000045__336000049$fn__336000050$fn__336000051")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000055__336000059$fn__336000060")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000055__336000059$fn__336000060$fn__336000061")

var Lit_17 *jrt.String = jrt.Intern("<init>")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000065__336000069$fn__336000070")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.suid$class_view$iter__336000065__336000069$fn__336000070$fn__336000071")

var Lit_20 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_21 *jrt.String = jrt.Intern("java.io.DataOutputStream")

var Lit_22 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_23 *jrt.String = jrt.Intern("<clinit>")

var Lit_24 *jrt.String = jrt.Intern("()V")

var Lit_25 *jrt.String = jrt.Intern("SHA")

var Lit_26 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn1,myn1,vyn1,dyn5,outeryn1,nv11,arbace.core5,in-nsMyn19,arbace.classes.suidm2,R0,s1997,The default serialVersionUID of a class of Java forms (JCS168, doc/classes/JAVA-DEFERRED-TRIAGE.md,\n  \"As built: JCS167 slices 2-3 (write-ahead)\"): jdk26u's java.io.ObjectStreamClass.computeDefaultSUID\n  (openjdk/jdk26u at baf63fb, src/java.base/share/classes/java/io/ObjectStreamClass.java) rule for rule,\n  over the class as javac compiles it rather than over reflection: the SHA-1 of the class's name, its\n  modifiers (public, final, interface, abstract; an interface abstract when it declares methods), its\n  interfaces' names sorted, its fields sorted by name (all but the private static and the private\n  transient ones; name, modifiers, descriptor), <clinit> when it has one, its non-private constructors\n  sorted by descriptor and its non-private methods sorted by name and descriptor (\"<init>\" or the name,\n  modifiers, the descriptor with dots), written by DataOutputStream, the first eight bytes of the hash\n  little-endian.\n\n  The class as javac compiles it (class-view) is the declaration arbace.classes.analyze makes (javac's\n  derived members: default and anonymous constructors with their implicit parameters, a.ctor-real-desc;\n  bridges; records' and enums' members) and javac's synthetic members a serializable class has besides\n  (Lower, jdk26u): the enclosing instance's field this$N (final, synthetic; javac keeps it in a\n  serializable class, Lower.shouldEmitOuterThis), the captured locals' fields val$x (final, synthetic),\n  $assertionsDisabled (static, final, synthetic) in a class with an assert, and the <clinit> that a\n  static initializer, a static field's non-constant initializer, an assert or an enum's constants give.\n  j2g writes it into a translated class's ClassInfo.SerialUID (arbace.j2g.out, J2G_DEFAULT_SUID=1) and\n  the variant's computeDefaultSUID asks it first (jdk.internal.jrt.SerialAlloc.defaultSUID): the table of\n  a translated JDK class lists only its public and serial members, so the stock computation over it\n  gives another value than the JDK's.m2,R0,s1997,The default serialVersionUID of a class of Java forms (JCS168, doc/classes/JAVA-DEFERRED-TRIAGE.md,\n  \"As built: JCS167 slices 2-3 (write-ahead)\"): jdk26u's java.io.ObjectStreamClass.computeDefaultSUID\n  (openjdk/jdk26u at baf63fb, src/java.base/share/classes/java/io/ObjectStreamClass.java) rule for rule,\n  over the class as javac compiles it rather than over reflection: the SHA-1 of the class's name, its\n  modifiers (public, final, interface, abstract; an interface abstract when it declares methods), its\n  interfaces' names sorted, its fields sorted by name (all but the private static and the private\n  transient ones; name, modifiers, descriptor), <clinit> when it has one, its non-private constructors\n  sorted by descriptor and its non-private methods sorted by name and descriptor (\"<init>\" or the name,\n  modifiers, the descriptor with dots), written by DataOutputStream, the first eight bytes of the hash\n  little-endian.\n\n  The class as javac compiles it (class-view) is the declaration arbace.classes.analyze makes (javac's\n  derived members: default and anonymous constructors with their implicit parameters, a.ctor-real-desc;\n  bridges; records' and enums' members) and javac's synthetic members a serializable class has besides\n  (Lower, jdk26u): the enclosing instance's field this$N (final, synthetic; javac keeps it in a\n  serializable class, Lower.shouldEmitOuterThis), the captured locals' fields val$x (final, synthetic),\n  $assertionsDisabled (static, final, synthetic) in a class with an assert, and the <clinit> that a\n  static initializer, a static field's non-constant initializer, an assert or an enum's constants give.\n  j2g writes it into a translated class's ClassInfo.SerialUID (arbace.j2g.out, J2G_DEFAULT_SUID=1) and\n  the variant's computeDefaultSUID asks it first (jdk.internal.jrt.SerialAlloc.defaultSUID): the table of\n  a translated JDK class lists only its public and serial members, so the stock computation over it\n  gives another value than the JDK's.R1,v19,arbace.classes.suid6,PUBLICl1,m8,R2,TR3,i59,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid7,PRIVATEl2,m8,R2,TR3,i59,R4,i28,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid9,PROTECTEDl4,m8,R2,TR3,i59,R4,i56,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid6,STATICl8,m8,R2,TR3,i60,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid5,FINALl16,m8,R2,TR3,i60,R4,i28,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid12,SYNCHRONIZEDl32,m8,R2,TR3,i60,R4,i55,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid8,VOLATILEl64,m8,R2,TR3,i61,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid9,TRANSIENTl128,m8,R2,TR3,i61,R4,i31,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid6,NATIVEl256,m8,R2,TR3,i61,R4,i62,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid9,INTERFACEl512,m8,R2,TR3,i62,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid8,ABSTRACTl1024,m8,R2,TR3,i62,R4,i33,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid6,STRICTl2048,m8,R2,TR3,i62,R4,i64,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid4,has?m10,R2,TR6,L1,V2,R7,R8,R3,i64,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid7,suid-ofm10,R6,L1,V1,R9,R0,s390,computeDefaultSUID of the class view v: {:name the binary name (dots) :mods Class.getModifiers\n  :interfaces [binary names] :fields [{:name :mods :desc}] :clinit boolean :ctors [{:mods :desc}]\n  :methods [{:name :mods :desc}]} (descriptors with slashes, as the class file has them), every\n  declared member, private ones too (getDeclaredFields, getDeclaredConstructors, getDeclaredMethods).R3,i66,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid10,class-modsm12,R2,TR6,L1,V1,R10,R0,s137,Class.getModifiers of class n: a nested class's flags from its InnerClasses entry (javac's), a\n  top-level class's from its access flags.R3,i115,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid16,outer-this-levelm12,R2,TR6,L1,V1,R11,R0,s149,javac's Lower.outerThisName: the nesting level of the enclosing instance's type (how many enclosing\n  instance types it has itself), the N of this$N.R3,i121,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid10,class-viewm10,R6,L1,V1,R12,R0,s301,The class view (suid-of) of class n of the compilation, as javac compiles it: its declaration's\n  members, with javac's synthetic members (this$N, val$x, $assertionsDisabled, <clinit>). The class must\n  be analyzed (a/analyze-class!: its bodies tell the captures, the static initializer, the asserts).R3,i129,R4,i1,R5,s22,arbace/classes/suid.aev19,arbace.classes.suid12,default-suidm10,R6,L1,V1,R12,R0,s151,The default serialVersionUID of class n of the compilation (computeDefaultSUID's value on the JVM\n  for the class javac compiles from the same source).R3,i157,R4,i1,R5,s22,arbace/classes/suid.ae")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.suid$eval336000004$loading__1927001464__auto____336000005")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.suid$eval336000008$fn__336000009")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.suid$has_QMARK_")

var Lit_30 *jrt.String = jrt.Intern("arbace.classes.suid$suid_of")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.suid$class_mods")

var Lit_32 *jrt.String = jrt.Intern("arbace.classes.suid$outer_this_level")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.suid$class_view")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.suid$default_suid")
