//line aot_arbace_classes_suid__init.ae:1
package aot_arbace_classes_suid

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_classes_suid__init_A_Load__O() any { A_arbace_classes_suid__init_A_Init(); jrt.StartCheck(); A_arbace_classes_suid__init_A_Unit0__O(); A_arbace_classes_suid__init_A_Unit1__O(); A_arbace_classes_suid__init_A_Unit2__O(); A_arbace_classes_suid__init_A_Unit3__O(); A_arbace_classes_suid__init_A_Unit4__O(); A_arbace_classes_suid__init_A_Unit5__O(); A_arbace_classes_suid__init_A_Unit6__O(); A_arbace_classes_suid__init_A_Unit7__O(); A_arbace_classes_suid__init_A_Unit8__O(); A_arbace_classes_suid__init_A_Unit9__O(); A_arbace_classes_suid__init_A_Unit10__O(); A_arbace_classes_suid__init_A_Unit11__O(); A_arbace_classes_suid__init_A_Unit12__O(); A_arbace_classes_suid__init_A_Unit13__O(); A_arbace_classes_suid__init_A_Unit14__O(); A_arbace_classes_suid__init_A_Unit15__O(); A_arbace_classes_suid__init_A_Unit16__O(); A_arbace_classes_suid__init_A_Unit17__O(); A_arbace_classes_suid__init_A_Unit18__O(); A_arbace_classes_suid__init_A_Unit19__O(); A_arbace_classes_suid__init_A_Unit20__O(); A_arbace_classes_suid__init_A_Unit21__O(); return nil }























func A_arbace_classes_suid__init_A_Unit0__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); return lang.IFn_Cast(A_arbace_classes_suid__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_suid__init_A_const_1) }
//line :29:1
func A_arbace_classes_suid__init_A_Unit1__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_suid__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_2)) }
//line :29:1
func A_arbace_classes_suid__init_A_Unit2__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_suid_eval336000004_loading__1927001464__auto____336000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_suid_eval336000004_loading__1927001464__auto____336000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_classes_suid_eval336000004_loading__1927001464__auto____336000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :29:1
func A_arbace_classes_suid__init_A_Unit3__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_suid__init_A_const_1)).Equals_O__Z(A_arbace_classes_suid__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_suid_eval336000008_fn__336000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_suid_eval336000008_fn__336000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_classes_suid_eval336000008_fn__336000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }





























func A_arbace_classes_suid__init_A_Unit4__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); A_arbace_classes_suid__init_A_const_4.BindRoot_O__V(A_arbace_classes_suid__init_A_const_5); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_6)); return A_arbace_classes_suid__init_A_const_4 }
//line :59:1
func A_arbace_classes_suid__init_A_Unit5__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 28); A_arbace_classes_suid__init_A_const_7.BindRoot_O__V(A_arbace_classes_suid__init_A_const_8); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_9)); return A_arbace_classes_suid__init_A_const_7 }
//line :59:1
func A_arbace_classes_suid__init_A_Unit6__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 56); A_arbace_classes_suid__init_A_const_10.BindRoot_O__V(A_arbace_classes_suid__init_A_const_11); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_12)); return A_arbace_classes_suid__init_A_const_10 }
func A_arbace_classes_suid__init_A_Unit7__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); A_arbace_classes_suid__init_A_const_13.BindRoot_O__V(A_arbace_classes_suid__init_A_const_14); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_13; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_15)); return A_arbace_classes_suid__init_A_const_13 }
//line :60:1
func A_arbace_classes_suid__init_A_Unit8__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 28); A_arbace_classes_suid__init_A_const_16.BindRoot_O__V(A_arbace_classes_suid__init_A_const_17); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_18)); return A_arbace_classes_suid__init_A_const_16 }
//line :60:1
func A_arbace_classes_suid__init_A_Unit9__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 55); A_arbace_classes_suid__init_A_const_19.BindRoot_O__V(A_arbace_classes_suid__init_A_const_20); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_19; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_21)); return A_arbace_classes_suid__init_A_const_19 }
func A_arbace_classes_suid__init_A_Unit10__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); A_arbace_classes_suid__init_A_const_22.BindRoot_O__V(A_arbace_classes_suid__init_A_const_23); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_24)); return A_arbace_classes_suid__init_A_const_22 }
//line :61:1
func A_arbace_classes_suid__init_A_Unit11__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 31); A_arbace_classes_suid__init_A_const_25.BindRoot_O__V(A_arbace_classes_suid__init_A_const_26); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_27)); return A_arbace_classes_suid__init_A_const_25 }
//line :61:1
func A_arbace_classes_suid__init_A_Unit12__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 62); A_arbace_classes_suid__init_A_const_28.BindRoot_O__V(A_arbace_classes_suid__init_A_const_29); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_30)); return A_arbace_classes_suid__init_A_const_28 }
func A_arbace_classes_suid__init_A_Unit13__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); A_arbace_classes_suid__init_A_const_31.BindRoot_O__V(A_arbace_classes_suid__init_A_const_32); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_31; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_33)); return A_arbace_classes_suid__init_A_const_31 }
//line :62:1
func A_arbace_classes_suid__init_A_Unit14__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 33); A_arbace_classes_suid__init_A_const_34.BindRoot_O__V(A_arbace_classes_suid__init_A_const_35); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_36)); return A_arbace_classes_suid__init_A_const_34 }
//line :62:1
func A_arbace_classes_suid__init_A_Unit15__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 64); A_arbace_classes_suid__init_A_const_37.BindRoot_O__V(A_arbace_classes_suid__init_A_const_38); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_37; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_39)); return A_arbace_classes_suid__init_A_const_37 }

func A_arbace_classes_suid__init_A_Unit16__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_classes_suid_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_suid_has_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_classes_suid_has_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_suid__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_41)); return A_arbace_classes_suid__init_A_const_40 }

func A_arbace_classes_suid__init_A_Unit17__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_classes_suid_suid_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_suid_suid_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_classes_suid_suid_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_suid__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_43)); return A_arbace_classes_suid__init_A_const_42 }
















































func A_arbace_classes_suid__init_A_Unit18__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_suid_class_mods_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_suid_class_mods_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_classes_suid_class_mods_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_suid__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_45)); return A_arbace_classes_suid__init_A_const_44 }





func A_arbace_classes_suid__init_A_Unit19__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_suid_outer_this_level_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_suid_outer_this_level_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_classes_suid_outer_this_level_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_suid__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_47)); return A_arbace_classes_suid__init_A_const_46 }







func A_arbace_classes_suid__init_A_Unit20__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_suid_class_view_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_suid_class_view_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_classes_suid_class_view_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_suid__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_49)); return A_arbace_classes_suid__init_A_const_48 }



























func A_arbace_classes_suid__init_A_Unit21__O() any { A_arbace_classes_suid__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.Var = A_arbace_classes_suid__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_suid_default_suid_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_suid_default_suid_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_classes_suid_default_suid_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_suid__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_suid__init_A_const_51)); return A_arbace_classes_suid__init_A_const_50 }



type A_arbace_classes_suid__init_A struct{ jrt.Object }

var A_arbace_classes_suid__init_A_const_pool *jrt.RefArray

var A_arbace_classes_suid__init_A_const_0 *lang.Var

var A_arbace_classes_suid__init_A_const_1 any

var A_arbace_classes_suid__init_A_const_2 any

var A_arbace_classes_suid__init_A_const_3 any

var A_arbace_classes_suid__init_A_const_4 *lang.Var

var A_arbace_classes_suid__init_A_const_5 any

var A_arbace_classes_suid__init_A_const_6 any

var A_arbace_classes_suid__init_A_const_7 *lang.Var

var A_arbace_classes_suid__init_A_const_8 any

var A_arbace_classes_suid__init_A_const_9 any

var A_arbace_classes_suid__init_A_const_10 *lang.Var

var A_arbace_classes_suid__init_A_const_11 any

var A_arbace_classes_suid__init_A_const_12 any

var A_arbace_classes_suid__init_A_const_13 *lang.Var

var A_arbace_classes_suid__init_A_const_14 any

var A_arbace_classes_suid__init_A_const_15 any

var A_arbace_classes_suid__init_A_const_16 *lang.Var

var A_arbace_classes_suid__init_A_const_17 any

var A_arbace_classes_suid__init_A_const_18 any

var A_arbace_classes_suid__init_A_const_19 *lang.Var

var A_arbace_classes_suid__init_A_const_20 any

var A_arbace_classes_suid__init_A_const_21 any

var A_arbace_classes_suid__init_A_const_22 *lang.Var

var A_arbace_classes_suid__init_A_const_23 any

var A_arbace_classes_suid__init_A_const_24 any

var A_arbace_classes_suid__init_A_const_25 *lang.Var

var A_arbace_classes_suid__init_A_const_26 any

var A_arbace_classes_suid__init_A_const_27 any

var A_arbace_classes_suid__init_A_const_28 *lang.Var

var A_arbace_classes_suid__init_A_const_29 any

var A_arbace_classes_suid__init_A_const_30 any

var A_arbace_classes_suid__init_A_const_31 *lang.Var

var A_arbace_classes_suid__init_A_const_32 any

var A_arbace_classes_suid__init_A_const_33 any

var A_arbace_classes_suid__init_A_const_34 *lang.Var

var A_arbace_classes_suid__init_A_const_35 any

var A_arbace_classes_suid__init_A_const_36 any

var A_arbace_classes_suid__init_A_const_37 *lang.Var

var A_arbace_classes_suid__init_A_const_38 any

var A_arbace_classes_suid__init_A_const_39 any

var A_arbace_classes_suid__init_A_const_40 *lang.Var

var A_arbace_classes_suid__init_A_const_41 any

var A_arbace_classes_suid__init_A_const_42 *lang.Var

var A_arbace_classes_suid__init_A_const_43 any

var A_arbace_classes_suid__init_A_const_44 *lang.Var

var A_arbace_classes_suid__init_A_const_45 any

var A_arbace_classes_suid__init_A_const_46 *lang.Var

var A_arbace_classes_suid__init_A_const_47 any

var A_arbace_classes_suid__init_A_const_48 *lang.Var

var A_arbace_classes_suid__init_A_const_49 any

var A_arbace_classes_suid__init_A_const_50 *lang.Var

var A_arbace_classes_suid__init_A_const_51 any

var A_arbace_classes_suid__init_A_init jrt.ClassInit

func A_arbace_classes_suid__init_A_Init() { if !A_arbace_classes_suid__init_A_init.Done() { A_arbace_classes_suid__init_A_init.Run(A_arbace_classes_suid__init_A_clinit) } }

func A_arbace_classes_suid__init_A_clinit() { A_arbace_classes_suid__init_A_clinit_p0(); A_arbace_classes_suid__init_A_clinit_p1(); A_arbace_classes_suid__init_A_clinit_p2(); A_arbace_classes_suid__init_A_clinit_p3() }

func A_arbace_classes_suid__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_suid__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_26, 65); A_arbace_classes_suid__init_A_const_0 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[13]); A_arbace_classes_suid__init_A_const_1 = A_arbace_classes_suid__init_A_const_pool.A[14]; A_arbace_classes_suid__init_A_const_2 = A_arbace_classes_suid__init_A_const_pool.A[15]; A_arbace_classes_suid__init_A_const_3 = A_arbace_classes_suid__init_A_const_pool.A[16]; A_arbace_classes_suid__init_A_const_4 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[17]); A_arbace_classes_suid__init_A_const_5 = A_arbace_classes_suid__init_A_const_pool.A[18]; A_arbace_classes_suid__init_A_const_6 = A_arbace_classes_suid__init_A_const_pool.A[19]; A_arbace_classes_suid__init_A_const_7 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[20]); A_arbace_classes_suid__init_A_const_8 = A_arbace_classes_suid__init_A_const_pool.A[21]; A_arbace_classes_suid__init_A_const_9 = A_arbace_classes_suid__init_A_const_pool.A[22]; A_arbace_classes_suid__init_A_const_10 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[23]); A_arbace_classes_suid__init_A_const_11 = A_arbace_classes_suid__init_A_const_pool.A[24]; A_arbace_classes_suid__init_A_const_12 = A_arbace_classes_suid__init_A_const_pool.A[25] }

func A_arbace_classes_suid__init_A_clinit_p1() { A_arbace_classes_suid__init_A_const_13 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[26]); A_arbace_classes_suid__init_A_const_14 = A_arbace_classes_suid__init_A_const_pool.A[27]; A_arbace_classes_suid__init_A_const_15 = A_arbace_classes_suid__init_A_const_pool.A[28]; A_arbace_classes_suid__init_A_const_16 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[29]); A_arbace_classes_suid__init_A_const_17 = A_arbace_classes_suid__init_A_const_pool.A[30]; A_arbace_classes_suid__init_A_const_18 = A_arbace_classes_suid__init_A_const_pool.A[31]; A_arbace_classes_suid__init_A_const_19 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[32]); A_arbace_classes_suid__init_A_const_20 = A_arbace_classes_suid__init_A_const_pool.A[33]; A_arbace_classes_suid__init_A_const_21 = A_arbace_classes_suid__init_A_const_pool.A[34]; A_arbace_classes_suid__init_A_const_22 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[35]); A_arbace_classes_suid__init_A_const_23 = A_arbace_classes_suid__init_A_const_pool.A[36]; A_arbace_classes_suid__init_A_const_24 = A_arbace_classes_suid__init_A_const_pool.A[37]; A_arbace_classes_suid__init_A_const_25 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[38]); A_arbace_classes_suid__init_A_const_26 = A_arbace_classes_suid__init_A_const_pool.A[39] }

func A_arbace_classes_suid__init_A_clinit_p2() { A_arbace_classes_suid__init_A_const_27 = A_arbace_classes_suid__init_A_const_pool.A[40]; A_arbace_classes_suid__init_A_const_28 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[41]); A_arbace_classes_suid__init_A_const_29 = A_arbace_classes_suid__init_A_const_pool.A[42]; A_arbace_classes_suid__init_A_const_30 = A_arbace_classes_suid__init_A_const_pool.A[43]; A_arbace_classes_suid__init_A_const_31 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[44]); A_arbace_classes_suid__init_A_const_32 = A_arbace_classes_suid__init_A_const_pool.A[45]; A_arbace_classes_suid__init_A_const_33 = A_arbace_classes_suid__init_A_const_pool.A[46]; A_arbace_classes_suid__init_A_const_34 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[47]); A_arbace_classes_suid__init_A_const_35 = A_arbace_classes_suid__init_A_const_pool.A[48]; A_arbace_classes_suid__init_A_const_36 = A_arbace_classes_suid__init_A_const_pool.A[49]; A_arbace_classes_suid__init_A_const_37 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[50]); A_arbace_classes_suid__init_A_const_38 = A_arbace_classes_suid__init_A_const_pool.A[51]; A_arbace_classes_suid__init_A_const_39 = A_arbace_classes_suid__init_A_const_pool.A[52]; A_arbace_classes_suid__init_A_const_40 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[53]) }

func A_arbace_classes_suid__init_A_clinit_p3() { A_arbace_classes_suid__init_A_const_41 = A_arbace_classes_suid__init_A_const_pool.A[54]; A_arbace_classes_suid__init_A_const_42 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[55]); A_arbace_classes_suid__init_A_const_43 = A_arbace_classes_suid__init_A_const_pool.A[56]; A_arbace_classes_suid__init_A_const_44 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[57]); A_arbace_classes_suid__init_A_const_45 = A_arbace_classes_suid__init_A_const_pool.A[58]; A_arbace_classes_suid__init_A_const_46 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[59]); A_arbace_classes_suid__init_A_const_47 = A_arbace_classes_suid__init_A_const_pool.A[60]; A_arbace_classes_suid__init_A_const_48 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[61]); A_arbace_classes_suid__init_A_const_49 = A_arbace_classes_suid__init_A_const_pool.A[62]; A_arbace_classes_suid__init_A_const_50 = lang.Var_Cast(A_arbace_classes_suid__init_A_const_pool.A[63]); A_arbace_classes_suid__init_A_const_51 = A_arbace_classes_suid__init_A_const_pool.A[64] }

func A_arbace_classes_suid__init_A_New() *A_arbace_classes_suid__init_A { A_arbace_classes_suid__init_A_Init(); t := &A_arbace_classes_suid__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_suid__init_A) Ctor() {}

func (t *A_arbace_classes_suid__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_suid__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_suid__init_A_class }

func (t *A_arbace_classes_suid__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_suid__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_suid__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_suid__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_suid__init_A); return ok }

func A_arbace_classes_suid__init_A_Cast(x any) *A_arbace_classes_suid__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_suid__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_suid__init_A_class)) }; return v }
