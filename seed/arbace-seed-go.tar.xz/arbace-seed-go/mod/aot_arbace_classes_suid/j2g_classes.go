//line j2g_classes.ae:1
package aot_arbace_classes_suid

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_classes_suid_class_mods_A_class, Name: "arbace.classes.suid$class_mods", Modifiers: 25, Simple: "class_mods", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_mods_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_A_class, Name: "arbace.classes.suid$class_view", Modifiers: 25, Simple: "class_view", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_dotted__336000033_A_class, Name: "arbace.classes.suid$class_view$dotted__336000033", Modifiers: 25, Simple: "dotted__336000033", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_dotted__336000033_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000035__336000039_A_class, Name: "arbace.classes.suid$class_view$iter__336000035__336000039", Modifiers: 25, Simple: "iter__336000035__336000039", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000035__336000039_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000035__336000039_fn__336000040_A_class, Name: "arbace.classes.suid$class_view$iter__336000035__336000039$fn__336000040", Modifiers: 25, Simple: "fn__336000040", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000035__336000039_fn__336000040_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000035__336000039_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000035__336000039_fn__336000040_fn__336000041_A_class, Name: "arbace.classes.suid$class_view$iter__336000035__336000039$fn__336000040$fn__336000041", Modifiers: 25, Simple: "fn__336000041", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000035__336000039_fn__336000040_fn__336000041_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000035__336000039_fn__336000040_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000045__336000049_A_class, Name: "arbace.classes.suid$class_view$iter__336000045__336000049", Modifiers: 25, Simple: "iter__336000045__336000049", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000045__336000049_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000045__336000049_fn__336000050_A_class, Name: "arbace.classes.suid$class_view$iter__336000045__336000049$fn__336000050", Modifiers: 25, Simple: "fn__336000050", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000045__336000049_fn__336000050_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000045__336000049_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000045__336000049_fn__336000050_fn__336000051_A_class, Name: "arbace.classes.suid$class_view$iter__336000045__336000049$fn__336000050$fn__336000051", Modifiers: 25, Simple: "fn__336000051", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000045__336000049_fn__336000050_fn__336000051_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000045__336000049_fn__336000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000055__336000059_A_class, Name: "arbace.classes.suid$class_view$iter__336000055__336000059", Modifiers: 25, Simple: "iter__336000055__336000059", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000055__336000059_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000055__336000059_fn__336000060_A_class, Name: "arbace.classes.suid$class_view$iter__336000055__336000059$fn__336000060", Modifiers: 25, Simple: "fn__336000060", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000055__336000059_fn__336000060_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000055__336000059_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000055__336000059_fn__336000060_fn__336000061_A_class, Name: "arbace.classes.suid$class_view$iter__336000055__336000059$fn__336000060$fn__336000061", Modifiers: 25, Simple: "fn__336000061", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000055__336000059_fn__336000060_fn__336000061_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000055__336000059_fn__336000060_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000065__336000069_A_class, Name: "arbace.classes.suid$class_view$iter__336000065__336000069", Modifiers: 25, Simple: "iter__336000065__336000069", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000065__336000069_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000065__336000069_fn__336000070_A_class, Name: "arbace.classes.suid$class_view$iter__336000065__336000069$fn__336000070", Modifiers: 25, Simple: "fn__336000070", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000065__336000069_fn__336000070_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000065__336000069_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_class_view_iter__336000065__336000069_fn__336000070_fn__336000071_A_class, Name: "arbace.classes.suid$class_view$iter__336000065__336000069$fn__336000070$fn__336000071", Modifiers: 25, Simple: "fn__336000071", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_class_view_iter__336000065__336000069_fn__336000070_fn__336000071_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_class_view_iter__336000065__336000069_fn__336000070_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_default_suid_A_class, Name: "arbace.classes.suid$default_suid", Modifiers: 25, Simple: "default_suid", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_default_suid_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_eval336000004_loading__1927001464__auto____336000005_A_class, Name: "arbace.classes.suid$eval336000004$loading__1927001464__auto____336000005", Modifiers: 25, Simple: "loading__1927001464__auto____336000005", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_eval336000004_loading__1927001464__auto____336000005_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_eval336000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_eval336000008_fn__336000009_A_class, Name: "arbace.classes.suid$eval336000008$fn__336000009", Modifiers: 25, Simple: "fn__336000009", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_eval336000008_fn__336000009_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_eval336000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_has_QMARK__A_class, Name: "arbace.classes.suid$has_QMARK_", Modifiers: 25, Simple: "has_QMARK_", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_has_QMARK__A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_outer_this_level_A_class, Name: "arbace.classes.suid$outer_this_level", Modifiers: 25, Simple: "outer_this_level", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_outer_this_level_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_suid_suid_of_A_class, Name: "arbace.classes.suid$suid_of", Modifiers: 25, Simple: "suid_of", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_suid_of_A", Source: "suid.ae", Declaring: &A_arbace_classes_suid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_classes_suid_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_suid_A_New()}; return nil }

var A_arbace_classes_suid_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_suid_A_new}

var A_arbace_classes_suid_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.suid", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_A"})

func init() { i := A_arbace_classes_suid_A_class.Info(); i.IsInstance = A_arbace_classes_suid_A_InstanceOf; i.Init = A_arbace_classes_suid_A_Init; i.Table = A_arbace_classes_suid_A_members }

var A_arbace_classes_suid_class_mods_A_class *jrt.Class

var A_arbace_classes_suid_class_view_A_class *jrt.Class

var A_arbace_classes_suid_class_view_dotted__336000033_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000035__336000039_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000035__336000039_fn__336000040_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000035__336000039_fn__336000040_fn__336000041_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000045__336000049_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000045__336000049_fn__336000050_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000045__336000049_fn__336000050_fn__336000051_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000055__336000059_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000055__336000059_fn__336000060_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000055__336000059_fn__336000060_fn__336000061_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000065__336000069_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000065__336000069_fn__336000070_A_class *jrt.Class

var A_arbace_classes_suid_class_view_iter__336000065__336000069_fn__336000070_fn__336000071_A_class *jrt.Class

var A_arbace_classes_suid_default_suid_A_class *jrt.Class

func A_arbace_classes_suid_eval336000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_suid_eval336000004_A_New()}; return nil }

var A_arbace_classes_suid_eval336000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_suid_eval336000004_A_new}

var A_arbace_classes_suid_eval336000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.suid$eval336000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_suid_A_class, Simple: "eval336000004", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_eval336000004_A"})

func init() { i := A_arbace_classes_suid_eval336000004_A_class.Info(); i.IsInstance = A_arbace_classes_suid_eval336000004_A_InstanceOf; i.Table = A_arbace_classes_suid_eval336000004_A_members }

var A_arbace_classes_suid_eval336000004_loading__1927001464__auto____336000005_A_class *jrt.Class

func A_arbace_classes_suid_eval336000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_suid_eval336000008_A_New()}; return nil }

var A_arbace_classes_suid_eval336000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_suid_eval336000008_A_new}

var A_arbace_classes_suid_eval336000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.suid$eval336000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_suid_A_class, Simple: "eval336000008", Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid_eval336000008_A"})

func init() { i := A_arbace_classes_suid_eval336000008_A_class.Info(); i.IsInstance = A_arbace_classes_suid_eval336000008_A_InstanceOf; i.Table = A_arbace_classes_suid_eval336000008_A_members }

var A_arbace_classes_suid_eval336000008_fn__336000009_A_class *jrt.Class

var A_arbace_classes_suid_has_QMARK__A_class *jrt.Class

var A_arbace_classes_suid_outer_this_level_A_class *jrt.Class

var A_arbace_classes_suid_suid_of_A_class *jrt.Class

func A_arbace_classes_suid__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_suid__init_A_Load__O()}; return nil }

func A_arbace_classes_suid__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_suid__init_A_New()}; return nil }

var A_arbace_classes_suid__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_suid__init_A_invoke, New: A_arbace_classes_suid__init_A_new}

var A_arbace_classes_suid__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.suid__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_suid.A_arbace_classes_suid__init_A", Source: "suid.ae"})

func init() { i := A_arbace_classes_suid__init_A_class.Info(); i.IsInstance = A_arbace_classes_suid__init_A_InstanceOf; i.Init = A_arbace_classes_suid__init_A_Init; i.Table = A_arbace_classes_suid__init_A_members }
