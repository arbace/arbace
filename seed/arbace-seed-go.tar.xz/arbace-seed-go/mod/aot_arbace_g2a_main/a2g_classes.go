//line a2g_classes.ae:1
package aot_arbace_g2a_main

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_A_New()}; return nil }

var A_arbace_g2a_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_main_A_new}

var A_arbace_g2a_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_A"})

func init() { i := A_arbace_g2a_main_A_class.Info(); i.IsInstance = A_arbace_g2a_main_A_InstanceOf; i.Init = A_arbace_g2a_main_A_Init; i.Table = A_arbace_g2a_main_A_members; jrt.RegisterGoType(A_arbace_g2a_main_A_class, reflect.TypeFor[A_arbace_g2a_main_A]()) }

func A_arbace_g2a_main__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_A_New()}; return nil }

func A_arbace_g2a_main__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_A_invoke, New: A_arbace_g2a_main__main_A_new, Get: A_arbace_g2a_main__main_A_get}

var A_arbace_g2a_main__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "_main", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_A_InstanceOf; i.Init = A_arbace_g2a_main__main_A_Init; i.Table = A_arbace_g2a_main__main_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_A_class, reflect.TypeFor[A_arbace_g2a_main__main_A]()) }

func A_arbace_g2a_main__main_fn__468000127_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000127_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main__main_fn__468000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000127_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000127_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000127_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000127_A_invoke, New: A_arbace_g2a_main__main_fn__468000127_A_new, Get: A_arbace_g2a_main__main_fn__468000127_A_get}

var A_arbace_g2a_main__main_fn__468000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main__main_A_class, Simple: "fn__468000127", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000127_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000127_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000127_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000127_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000127_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000127_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000127_A]()) }

func A_arbace_g2a_main__main_fn__468000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000134_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000134_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000134_A_invoke, New: A_arbace_g2a_main__main_fn__468000134_A_new, Get: A_arbace_g2a_main__main_fn__468000134_A_get}

var A_arbace_g2a_main__main_fn__468000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main__main_A_class, Simple: "fn__468000134", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000134_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000134_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000134_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000134_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000134_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000134_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000134_A]()) }

func A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000134_fn__468000138_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_invoke, New: A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_new, Get: A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_get}

var A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000134$fn__468000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main__main_fn__468000134_A_class, Simple: "fn__468000138", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000134_fn__468000138_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000134_fn__468000138_A]()) }

func A_arbace_g2a_main__main_fn__468000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000141_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000141_A_New()}; return nil }

func A_arbace_g2a_main__main_fn__468000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000141_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000141_A_invoke, New: A_arbace_g2a_main__main_fn__468000141_A_new, Get: A_arbace_g2a_main__main_fn__468000141_A_get}

var A_arbace_g2a_main__main_fn__468000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main__main_A_class, Simple: "fn__468000141", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000141_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000141_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000141_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000141_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000141_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000141_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000141_A]()) }

func A_arbace_g2a_main__main_fn__468000143_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000143_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000143_A_New()}; return nil }

func A_arbace_g2a_main__main_fn__468000143_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000143_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000143_A_invoke, New: A_arbace_g2a_main__main_fn__468000143_A_new, Get: A_arbace_g2a_main__main_fn__468000143_A_get}

var A_arbace_g2a_main__main_fn__468000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main__main_A_class, Simple: "fn__468000143", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000143_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000143_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000143_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000143_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000143_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000143_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000143_A]()) }

func A_arbace_g2a_main__main_fn__468000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000145_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000145_A_New()}; return nil }

func A_arbace_g2a_main__main_fn__468000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000145_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000145_A_invoke, New: A_arbace_g2a_main__main_fn__468000145_A_new, Get: A_arbace_g2a_main__main_fn__468000145_A_get}

var A_arbace_g2a_main__main_fn__468000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main__main_A_class, Simple: "fn__468000145", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000145_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000145_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000145_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000145_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000145_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000145_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000145_A]()) }

func A_arbace_g2a_main__main_fn__468000147_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000147_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000147_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000147_A_New()}; return nil }

func A_arbace_g2a_main__main_fn__468000147_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000147_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000147_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000147_A_invoke, New: A_arbace_g2a_main__main_fn__468000147_A_new, Get: A_arbace_g2a_main__main_fn__468000147_A_get}

var A_arbace_g2a_main__main_fn__468000147_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000147", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main__main_A_class, Simple: "fn__468000147", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000147_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000147_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000147_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000147_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000147_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000147_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000147_A]()) }

func A_arbace_g2a_main__main_fn__468000149_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000149_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000149_A_New()}; return nil }

func A_arbace_g2a_main__main_fn__468000149_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000149_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000149_A_invoke, New: A_arbace_g2a_main__main_fn__468000149_A_new, Get: A_arbace_g2a_main__main_fn__468000149_A_get}

var A_arbace_g2a_main__main_fn__468000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main__main_A_class, Simple: "fn__468000149", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000149_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000149_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000149_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000149_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000149_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000149_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000149_A]()) }

func A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main__main_fn__468000149_fn__468000150_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_New_O(args[0])}; return nil }

func A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_fn_class)}; return nil }

var A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_invoke, New: A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_new, Get: A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_get}

var A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$_main$fn__468000149$fn__468000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main__main_fn__468000149_A_class, Simple: "fn__468000150", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000149_fn__468000150_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_class.Info(); i.IsInstance = A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_InstanceOf; i.Init = A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_Init; i.Table = A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_members; jrt.RegisterGoType(A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_class, reflect.TypeFor[A_arbace_g2a_main__main_fn__468000149_fn__468000150_A]()) }

func A_arbace_g2a_main_candidate_dir_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_candidate_dir_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_candidate_dir_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_candidate_dir_A_New()}; return nil }

func A_arbace_g2a_main_candidate_dir_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_candidate_dir_A_fn_class)}; return nil }

var A_arbace_g2a_main_candidate_dir_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_candidate_dir_A_invoke, New: A_arbace_g2a_main_candidate_dir_A_new, Get: A_arbace_g2a_main_candidate_dir_A_get}

var A_arbace_g2a_main_candidate_dir_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$candidate_dir", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "candidate_dir", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_candidate_dir_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_candidate_dir_A_class.Info(); i.IsInstance = A_arbace_g2a_main_candidate_dir_A_InstanceOf; i.Init = A_arbace_g2a_main_candidate_dir_A_Init; i.Table = A_arbace_g2a_main_candidate_dir_A_members; jrt.RegisterGoType(A_arbace_g2a_main_candidate_dir_A_class, reflect.TypeFor[A_arbace_g2a_main_candidate_dir_A]()) }

func A_arbace_g2a_main_check_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_check_text_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_check_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_check_text_A_New()}; return nil }

func A_arbace_g2a_main_check_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_check_text_A_fn_class)}; return nil }

var A_arbace_g2a_main_check_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_check_text_A_invoke, New: A_arbace_g2a_main_check_text_A_new, Get: A_arbace_g2a_main_check_text_A_get}

var A_arbace_g2a_main_check_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$check_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "check_text", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_check_text_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_check_text_A_class.Info(); i.IsInstance = A_arbace_g2a_main_check_text_A_InstanceOf; i.Init = A_arbace_g2a_main_check_text_A_Init; i.Table = A_arbace_g2a_main_check_text_A_members; jrt.RegisterGoType(A_arbace_g2a_main_check_text_A_class, reflect.TypeFor[A_arbace_g2a_main_check_text_A]()) }

func A_arbace_g2a_main_check_text_fn__468000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_check_text_fn__468000036_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_check_text_fn__468000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_check_text_fn__468000036_A_New()}; return nil }

func A_arbace_g2a_main_check_text_fn__468000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_check_text_fn__468000036_A_fn_class)}; return nil }

var A_arbace_g2a_main_check_text_fn__468000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_check_text_fn__468000036_A_invoke, New: A_arbace_g2a_main_check_text_fn__468000036_A_new, Get: A_arbace_g2a_main_check_text_fn__468000036_A_get}

var A_arbace_g2a_main_check_text_fn__468000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$check_text$fn__468000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_check_text_A_class, Simple: "fn__468000036", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_check_text_fn__468000036_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_check_text_fn__468000036_A_class.Info(); i.IsInstance = A_arbace_g2a_main_check_text_fn__468000036_A_InstanceOf; i.Init = A_arbace_g2a_main_check_text_fn__468000036_A_Init; i.Table = A_arbace_g2a_main_check_text_fn__468000036_A_members; jrt.RegisterGoType(A_arbace_g2a_main_check_text_fn__468000036_A_class, reflect.TypeFor[A_arbace_g2a_main_check_text_fn__468000036_A]()) }

func A_arbace_g2a_main_convert_dump_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_main_convert_dump_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_A_New()}; return nil }

func A_arbace_g2a_main_convert_dump_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_A_invoke, New: A_arbace_g2a_main_convert_dump_A_new, Get: A_arbace_g2a_main_convert_dump_A_get}

var A_arbace_g2a_main_convert_dump_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "convert_dump", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_A_Init; i.Table = A_arbace_g2a_main_convert_dump_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_A]()) }

func A_arbace_g2a_main_convert_dump_fn__468000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_fn__468000052_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_fn__468000052_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_fn__468000052_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_fn__468000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_fn__468000052_A_invoke, New: A_arbace_g2a_main_convert_dump_fn__468000052_A_new, Get: A_arbace_g2a_main_convert_dump_fn__468000052_A_get}

var A_arbace_g2a_main_convert_dump_fn__468000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$fn__468000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_convert_dump_A_class, Simple: "fn__468000052", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_fn__468000052_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_fn__468000052_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_fn__468000052_A_Init; i.Table = A_arbace_g2a_main_convert_dump_fn__468000052_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_fn__468000052_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_fn__468000052_A]()) }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_New_O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_invoke, New: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_new, Get: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_get}

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_convert_dump_fn__468000052_A_class, Simple: "iter__468000053__468000057", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_Init; i.Table = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A]()) }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_invoke, New: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_new, Get: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_get}

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_class, Simple: "fn__468000058", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_Init; i.Table = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A]()) }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_invoke, New: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_new, Get: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_get}

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058$fn__468000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_class, Simple: "fn__468000059", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_Init; i.Table = A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A]()) }

func A_arbace_g2a_main_convert_dump_fn__468000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_fn__468000064_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_fn__468000064_A_New_O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_fn__468000064_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_fn__468000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_fn__468000064_A_invoke, New: A_arbace_g2a_main_convert_dump_fn__468000064_A_new, Get: A_arbace_g2a_main_convert_dump_fn__468000064_A_get}

var A_arbace_g2a_main_convert_dump_fn__468000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$fn__468000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_convert_dump_A_class, Simple: "fn__468000064", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000064_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_fn__468000064_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_fn__468000064_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_fn__468000064_A_Init; i.Table = A_arbace_g2a_main_convert_dump_fn__468000064_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_fn__468000064_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_fn__468000064_A]()) }

func A_arbace_g2a_main_convert_dump_fn__468000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_fn__468000066_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_fn__468000066_A_New_O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_fn__468000066_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_fn__468000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_fn__468000066_A_invoke, New: A_arbace_g2a_main_convert_dump_fn__468000066_A_new, Get: A_arbace_g2a_main_convert_dump_fn__468000066_A_get}

var A_arbace_g2a_main_convert_dump_fn__468000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$fn__468000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_convert_dump_A_class, Simple: "fn__468000066", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000066_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_fn__468000066_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_fn__468000066_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_fn__468000066_A_Init; i.Table = A_arbace_g2a_main_convert_dump_fn__468000066_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_fn__468000066_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_fn__468000066_A]()) }

func A_arbace_g2a_main_convert_dump_fn__468000088_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_fn__468000088_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_fn__468000088_A_New()}; return nil }

func A_arbace_g2a_main_convert_dump_fn__468000088_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_fn__468000088_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_fn__468000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_fn__468000088_A_invoke, New: A_arbace_g2a_main_convert_dump_fn__468000088_A_new, Get: A_arbace_g2a_main_convert_dump_fn__468000088_A_get}

var A_arbace_g2a_main_convert_dump_fn__468000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$fn__468000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_convert_dump_A_class, Simple: "fn__468000088", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000088_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_fn__468000088_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_fn__468000088_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_fn__468000088_A_Init; i.Table = A_arbace_g2a_main_convert_dump_fn__468000088_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_fn__468000088_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_fn__468000088_A]()) }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_New()}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_invoke, New: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_new, Get: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_get}

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_convert_dump_A_class, Simple: "iter__468000072__468000078", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_Init; i.Table = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A]()) }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_invoke, New: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_new, Get: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_get}

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_class, Simple: "fn__468000079", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_Init; i.Table = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A]()) }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_New_O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_invoke, New: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_new, Get: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_get}

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_class, Simple: "iter__468000074__468000080", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_Init; i.Table = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A]()) }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_invoke, New: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_new, Get: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_get}

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_class, Simple: "fn__468000081", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_Init; i.Table = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A]()) }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_fn_class)}; return nil }

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_invoke, New: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_new, Get: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_get}

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081$fn__468000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_class, Simple: "fn__468000082", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_class.Info(); i.IsInstance = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_InstanceOf; i.Init = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_Init; i.Table = A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_members; jrt.RegisterGoType(A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_class, reflect.TypeFor[A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A]()) }

func A_arbace_g2a_main_data_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_data_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_data_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_data_of_A_New()}; return nil }

func A_arbace_g2a_main_data_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_data_of_A_fn_class)}; return nil }

var A_arbace_g2a_main_data_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_data_of_A_invoke, New: A_arbace_g2a_main_data_of_A_new, Get: A_arbace_g2a_main_data_of_A_get}

var A_arbace_g2a_main_data_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$data_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "data_of", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_data_of_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_data_of_A_class.Info(); i.IsInstance = A_arbace_g2a_main_data_of_A_InstanceOf; i.Init = A_arbace_g2a_main_data_of_A_Init; i.Table = A_arbace_g2a_main_data_of_A_members; jrt.RegisterGoType(A_arbace_g2a_main_data_of_A_class, reflect.TypeFor[A_arbace_g2a_main_data_of_A]()) }

func A_arbace_g2a_main_data_of_fn__468000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_data_of_fn__468000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_data_of_fn__468000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_data_of_fn__468000013_A_New()}; return nil }

func A_arbace_g2a_main_data_of_fn__468000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_data_of_fn__468000013_A_fn_class)}; return nil }

var A_arbace_g2a_main_data_of_fn__468000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_data_of_fn__468000013_A_invoke, New: A_arbace_g2a_main_data_of_fn__468000013_A_new, Get: A_arbace_g2a_main_data_of_fn__468000013_A_get}

var A_arbace_g2a_main_data_of_fn__468000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$data_of$fn__468000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_data_of_A_class, Simple: "fn__468000013", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_data_of_fn__468000013_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_data_of_fn__468000013_A_class.Info(); i.IsInstance = A_arbace_g2a_main_data_of_fn__468000013_A_InstanceOf; i.Init = A_arbace_g2a_main_data_of_fn__468000013_A_Init; i.Table = A_arbace_g2a_main_data_of_fn__468000013_A_members; jrt.RegisterGoType(A_arbace_g2a_main_data_of_fn__468000013_A_class, reflect.TypeFor[A_arbace_g2a_main_data_of_fn__468000013_A]()) }

func A_arbace_g2a_main_diff_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_diff_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_main_diff_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_diff_A_New()}; return nil }

func A_arbace_g2a_main_diff_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_diff_A_fn_class)}; return nil }

var A_arbace_g2a_main_diff_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_diff_A_invoke, New: A_arbace_g2a_main_diff_A_new, Get: A_arbace_g2a_main_diff_A_get}

var A_arbace_g2a_main_diff_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$diff", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "diff", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_diff_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_diff_A_class.Info(); i.IsInstance = A_arbace_g2a_main_diff_A_InstanceOf; i.Init = A_arbace_g2a_main_diff_A_Init; i.Table = A_arbace_g2a_main_diff_A_members; jrt.RegisterGoType(A_arbace_g2a_main_diff_A_class, reflect.TypeFor[A_arbace_g2a_main_diff_A]()) }

func A_arbace_g2a_main_diff_fn__468000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_diff_fn__468000028_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_diff_fn__468000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_diff_fn__468000028_A_New_O(args[0])}; return nil }

func A_arbace_g2a_main_diff_fn__468000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_diff_fn__468000028_A_fn_class)}; return nil }

var A_arbace_g2a_main_diff_fn__468000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_diff_fn__468000028_A_invoke, New: A_arbace_g2a_main_diff_fn__468000028_A_new, Get: A_arbace_g2a_main_diff_fn__468000028_A_get}

var A_arbace_g2a_main_diff_fn__468000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$diff$fn__468000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_main_diff_A_class, Simple: "fn__468000028", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_diff_fn__468000028_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_diff_fn__468000028_A_class.Info(); i.IsInstance = A_arbace_g2a_main_diff_fn__468000028_A_InstanceOf; i.Init = A_arbace_g2a_main_diff_fn__468000028_A_Init; i.Table = A_arbace_g2a_main_diff_fn__468000028_A_members; jrt.RegisterGoType(A_arbace_g2a_main_diff_fn__468000028_A_class, reflect.TypeFor[A_arbace_g2a_main_diff_fn__468000028_A]()) }

func A_arbace_g2a_main_dump_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_dump_files_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_dump_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_dump_files_A_New()}; return nil }

func A_arbace_g2a_main_dump_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_dump_files_A_fn_class)}; return nil }

var A_arbace_g2a_main_dump_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_dump_files_A_invoke, New: A_arbace_g2a_main_dump_files_A_new, Get: A_arbace_g2a_main_dump_files_A_get}

var A_arbace_g2a_main_dump_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$dump_files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "dump_files", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_dump_files_A_class.Info(); i.IsInstance = A_arbace_g2a_main_dump_files_A_InstanceOf; i.Init = A_arbace_g2a_main_dump_files_A_Init; i.Table = A_arbace_g2a_main_dump_files_A_members; jrt.RegisterGoType(A_arbace_g2a_main_dump_files_A_class, reflect.TypeFor[A_arbace_g2a_main_dump_files_A]()) }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_dump_files_iter__468000091__468000097_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_New()}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_fn_class)}; return nil }

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_invoke, New: A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_new, Get: A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_get}

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$dump_files$iter__468000091__468000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_dump_files_A_class, Simple: "iter__468000091__468000097", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_class.Info(); i.IsInstance = A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_InstanceOf; i.Init = A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_Init; i.Table = A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_members; jrt.RegisterGoType(A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_class, reflect.TypeFor[A_arbace_g2a_main_dump_files_iter__468000091__468000097_A]()) }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_fn_class)}; return nil }

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_invoke, New: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_new, Get: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_get}

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_class, Simple: "fn__468000098", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_class.Info(); i.IsInstance = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_InstanceOf; i.Init = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_Init; i.Table = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_members; jrt.RegisterGoType(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_class, reflect.TypeFor[A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A]()) }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_New_O(args[0])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_fn_class)}; return nil }

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_invoke, New: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_new, Get: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_get}

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_class, Simple: "iter__468000093__468000099", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_class.Info(); i.IsInstance = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_InstanceOf; i.Init = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_Init; i.Table = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_members; jrt.RegisterGoType(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_class, reflect.TypeFor[A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A]()) }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_fn_class)}; return nil }

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_invoke, New: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_new, Get: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_get}

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_class, Simple: "fn__468000100", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_class.Info(); i.IsInstance = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_InstanceOf; i.Init = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_Init; i.Table = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_members; jrt.RegisterGoType(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_class, reflect.TypeFor[A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A]()) }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_fn_class)}; return nil }

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_invoke, New: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_new, Get: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_get}

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100$fn__468000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_class, Simple: "fn__468000101", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_class.Info(); i.IsInstance = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_InstanceOf; i.Init = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_Init; i.Table = A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_members; jrt.RegisterGoType(A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_class, reflect.TypeFor[A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A]()) }

func A_arbace_g2a_main_eval468000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_eval468000004_A_New()}; return nil }

var A_arbace_g2a_main_eval468000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_main_eval468000004_A_new}

var A_arbace_g2a_main_eval468000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$eval468000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_main_A_class, Simple: "eval468000004", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000004_A"})

func init() { i := A_arbace_g2a_main_eval468000004_A_class.Info(); i.IsInstance = A_arbace_g2a_main_eval468000004_A_InstanceOf; i.Table = A_arbace_g2a_main_eval468000004_A_members; jrt.RegisterGoType(A_arbace_g2a_main_eval468000004_A_class, reflect.TypeFor[A_arbace_g2a_main_eval468000004_A]()) }

func A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_New()}; return nil }

func A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_fn_class)}; return nil }

var A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_invoke, New: A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_new, Get: A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_get}

var A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$eval468000004$loading__1927001464__auto____468000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_eval468000004_A_class, Simple: "loading__1927001464__auto____468000005", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_class.Info(); i.IsInstance = A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_InstanceOf; i.Init = A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_Init; i.Table = A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_members; jrt.RegisterGoType(A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_class, reflect.TypeFor[A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A]()) }

func A_arbace_g2a_main_eval468000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_eval468000008_A_New()}; return nil }

var A_arbace_g2a_main_eval468000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_main_eval468000008_A_new}

var A_arbace_g2a_main_eval468000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$eval468000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_main_A_class, Simple: "eval468000008", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000008_A"})

func init() { i := A_arbace_g2a_main_eval468000008_A_class.Info(); i.IsInstance = A_arbace_g2a_main_eval468000008_A_InstanceOf; i.Table = A_arbace_g2a_main_eval468000008_A_members; jrt.RegisterGoType(A_arbace_g2a_main_eval468000008_A_class, reflect.TypeFor[A_arbace_g2a_main_eval468000008_A]()) }

func A_arbace_g2a_main_eval468000008_fn__468000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_eval468000008_fn__468000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_main_eval468000008_fn__468000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_eval468000008_fn__468000009_A_New()}; return nil }

func A_arbace_g2a_main_eval468000008_fn__468000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_eval468000008_fn__468000009_A_fn_class)}; return nil }

var A_arbace_g2a_main_eval468000008_fn__468000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_eval468000008_fn__468000009_A_invoke, New: A_arbace_g2a_main_eval468000008_fn__468000009_A_new, Get: A_arbace_g2a_main_eval468000008_fn__468000009_A_get}

var A_arbace_g2a_main_eval468000008_fn__468000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$eval468000008$fn__468000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_main_eval468000008_A_class, Simple: "fn__468000009", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000008_fn__468000009_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_eval468000008_fn__468000009_A_class.Info(); i.IsInstance = A_arbace_g2a_main_eval468000008_fn__468000009_A_InstanceOf; i.Init = A_arbace_g2a_main_eval468000008_fn__468000009_A_Init; i.Table = A_arbace_g2a_main_eval468000008_fn__468000009_A_members; jrt.RegisterGoType(A_arbace_g2a_main_eval468000008_fn__468000009_A_class, reflect.TypeFor[A_arbace_g2a_main_eval468000008_fn__468000009_A]()) }

func A_arbace_g2a_main_expected_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_expected_meta_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_expected_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_expected_meta_A_New()}; return nil }

func A_arbace_g2a_main_expected_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_expected_meta_A_fn_class)}; return nil }

var A_arbace_g2a_main_expected_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_expected_meta_A_invoke, New: A_arbace_g2a_main_expected_meta_A_new, Get: A_arbace_g2a_main_expected_meta_A_get}

var A_arbace_g2a_main_expected_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$expected_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "expected_meta", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_expected_meta_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_expected_meta_A_class.Info(); i.IsInstance = A_arbace_g2a_main_expected_meta_A_InstanceOf; i.Init = A_arbace_g2a_main_expected_meta_A_Init; i.Table = A_arbace_g2a_main_expected_meta_A_members; jrt.RegisterGoType(A_arbace_g2a_main_expected_meta_A_class, reflect.TypeFor[A_arbace_g2a_main_expected_meta_A]()) }

func A_arbace_g2a_main_expected_meta_fn__468000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_expected_meta_fn__468000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_expected_meta_fn__468000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_expected_meta_fn__468000020_A_New()}; return nil }

func A_arbace_g2a_main_expected_meta_fn__468000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_expected_meta_fn__468000020_A_fn_class)}; return nil }

var A_arbace_g2a_main_expected_meta_fn__468000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_expected_meta_fn__468000020_A_invoke, New: A_arbace_g2a_main_expected_meta_fn__468000020_A_new, Get: A_arbace_g2a_main_expected_meta_fn__468000020_A_get}

var A_arbace_g2a_main_expected_meta_fn__468000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$expected_meta$fn__468000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_expected_meta_A_class, Simple: "fn__468000020", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_expected_meta_fn__468000020_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_expected_meta_fn__468000020_A_class.Info(); i.IsInstance = A_arbace_g2a_main_expected_meta_fn__468000020_A_InstanceOf; i.Init = A_arbace_g2a_main_expected_meta_fn__468000020_A_Init; i.Table = A_arbace_g2a_main_expected_meta_fn__468000020_A_members; jrt.RegisterGoType(A_arbace_g2a_main_expected_meta_fn__468000020_A_class, reflect.TypeFor[A_arbace_g2a_main_expected_meta_fn__468000020_A]()) }

func A_arbace_g2a_main_merge_counts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_merge_counts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_merge_counts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_merge_counts_A_New()}; return nil }

func A_arbace_g2a_main_merge_counts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_merge_counts_A_fn_class)}; return nil }

var A_arbace_g2a_main_merge_counts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_merge_counts_A_invoke, New: A_arbace_g2a_main_merge_counts_A_new, Get: A_arbace_g2a_main_merge_counts_A_get}

var A_arbace_g2a_main_merge_counts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$merge_counts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "merge_counts", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_merge_counts_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_merge_counts_A_class.Info(); i.IsInstance = A_arbace_g2a_main_merge_counts_A_InstanceOf; i.Init = A_arbace_g2a_main_merge_counts_A_Init; i.Table = A_arbace_g2a_main_merge_counts_A_members; jrt.RegisterGoType(A_arbace_g2a_main_merge_counts_A_class, reflect.TypeFor[A_arbace_g2a_main_merge_counts_A]()) }

func A_arbace_g2a_main_munge_seg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_munge_seg_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_munge_seg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_munge_seg_A_New()}; return nil }

func A_arbace_g2a_main_munge_seg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_munge_seg_A_fn_class)}; return nil }

var A_arbace_g2a_main_munge_seg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_munge_seg_A_invoke, New: A_arbace_g2a_main_munge_seg_A_new, Get: A_arbace_g2a_main_munge_seg_A_get}

var A_arbace_g2a_main_munge_seg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$munge_seg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "munge_seg", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_munge_seg_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_munge_seg_A_class.Info(); i.IsInstance = A_arbace_g2a_main_munge_seg_A_InstanceOf; i.Init = A_arbace_g2a_main_munge_seg_A_Init; i.Table = A_arbace_g2a_main_munge_seg_A_members; jrt.RegisterGoType(A_arbace_g2a_main_munge_seg_A_class, reflect.TypeFor[A_arbace_g2a_main_munge_seg_A]()) }

func A_arbace_g2a_main_ns_dir_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_ns_dir_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_ns_dir_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_ns_dir_A_New()}; return nil }

func A_arbace_g2a_main_ns_dir_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_ns_dir_A_fn_class)}; return nil }

var A_arbace_g2a_main_ns_dir_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_ns_dir_A_invoke, New: A_arbace_g2a_main_ns_dir_A_new, Get: A_arbace_g2a_main_ns_dir_A_get}

var A_arbace_g2a_main_ns_dir_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$ns_dir", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "ns_dir", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_ns_dir_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_ns_dir_A_class.Info(); i.IsInstance = A_arbace_g2a_main_ns_dir_A_InstanceOf; i.Init = A_arbace_g2a_main_ns_dir_A_Init; i.Table = A_arbace_g2a_main_ns_dir_A_members; jrt.RegisterGoType(A_arbace_g2a_main_ns_dir_A_class, reflect.TypeFor[A_arbace_g2a_main_ns_dir_A]()) }

func A_arbace_g2a_main_print_candidate_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_print_candidate_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_print_candidate_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_print_candidate_A_New()}; return nil }

func A_arbace_g2a_main_print_candidate_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_print_candidate_A_fn_class)}; return nil }

var A_arbace_g2a_main_print_candidate_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_print_candidate_A_invoke, New: A_arbace_g2a_main_print_candidate_A_new, Get: A_arbace_g2a_main_print_candidate_A_get}

var A_arbace_g2a_main_print_candidate_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$print_candidate", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "print_candidate", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_print_candidate_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_print_candidate_A_class.Info(); i.IsInstance = A_arbace_g2a_main_print_candidate_A_InstanceOf; i.Init = A_arbace_g2a_main_print_candidate_A_Init; i.Table = A_arbace_g2a_main_print_candidate_A_members; jrt.RegisterGoType(A_arbace_g2a_main_print_candidate_A_class, reflect.TypeFor[A_arbace_g2a_main_print_candidate_A]()) }

func A_arbace_g2a_main_program_ns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_program_ns_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_program_ns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_program_ns_A_New()}; return nil }

func A_arbace_g2a_main_program_ns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_program_ns_A_fn_class)}; return nil }

var A_arbace_g2a_main_program_ns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_program_ns_A_invoke, New: A_arbace_g2a_main_program_ns_A_new, Get: A_arbace_g2a_main_program_ns_A_get}

var A_arbace_g2a_main_program_ns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$program_ns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "program_ns", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_program_ns_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_program_ns_A_class.Info(); i.IsInstance = A_arbace_g2a_main_program_ns_A_InstanceOf; i.Init = A_arbace_g2a_main_program_ns_A_Init; i.Table = A_arbace_g2a_main_program_ns_A_members; jrt.RegisterGoType(A_arbace_g2a_main_program_ns_A_class, reflect.TypeFor[A_arbace_g2a_main_program_ns_A]()) }

func A_arbace_g2a_main_read_all_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_read_all_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_read_all_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_read_all_A_New()}; return nil }

func A_arbace_g2a_main_read_all_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_read_all_A_fn_class)}; return nil }

var A_arbace_g2a_main_read_all_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_read_all_A_invoke, New: A_arbace_g2a_main_read_all_A_new, Get: A_arbace_g2a_main_read_all_A_get}

var A_arbace_g2a_main_read_all_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$read_all", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "read_all", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_read_all_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_read_all_A_class.Info(); i.IsInstance = A_arbace_g2a_main_read_all_A_InstanceOf; i.Init = A_arbace_g2a_main_read_all_A_Init; i.Table = A_arbace_g2a_main_read_all_A_members; jrt.RegisterGoType(A_arbace_g2a_main_read_all_A_class, reflect.TypeFor[A_arbace_g2a_main_read_all_A]()) }

func A_arbace_g2a_main_read_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_read_meta_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_main_read_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_read_meta_A_New()}; return nil }

func A_arbace_g2a_main_read_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_read_meta_A_fn_class)}; return nil }

var A_arbace_g2a_main_read_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_read_meta_A_invoke, New: A_arbace_g2a_main_read_meta_A_new, Get: A_arbace_g2a_main_read_meta_A_get}

var A_arbace_g2a_main_read_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$read_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "read_meta", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_read_meta_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_read_meta_A_class.Info(); i.IsInstance = A_arbace_g2a_main_read_meta_A_InstanceOf; i.Init = A_arbace_g2a_main_read_meta_A_Init; i.Table = A_arbace_g2a_main_read_meta_A_members; jrt.RegisterGoType(A_arbace_g2a_main_read_meta_A_class, reflect.TypeFor[A_arbace_g2a_main_read_meta_A]()) }

func A_arbace_g2a_main_spit_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_main_spit_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_main_spit_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_spit_file_A_New()}; return nil }

func A_arbace_g2a_main_spit_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_main_spit_file_A_fn_class)}; return nil }

var A_arbace_g2a_main_spit_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_main_spit_file_A_invoke, New: A_arbace_g2a_main_spit_file_A_new, Get: A_arbace_g2a_main_spit_file_A_get}

var A_arbace_g2a_main_spit_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$spit_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_main_A_class, Simple: "spit_file", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_spit_file_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main_spit_file_A_class.Info(); i.IsInstance = A_arbace_g2a_main_spit_file_A_InstanceOf; i.Init = A_arbace_g2a_main_spit_file_A_Init; i.Table = A_arbace_g2a_main_spit_file_A_members; jrt.RegisterGoType(A_arbace_g2a_main_spit_file_A_class, reflect.TypeFor[A_arbace_g2a_main_spit_file_A]()) }

func A_arbace_g2a_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_main__init_A_Load__O(); case 1: return A_arbace_g2a_main__init_A_Unit0__O(); case 2: return A_arbace_g2a_main__init_A_Unit1__O(); case 3: return A_arbace_g2a_main__init_A_Unit10__O(); case 4: return A_arbace_g2a_main__init_A_Unit11__O(); case 5: return A_arbace_g2a_main__init_A_Unit12__O(); case 6: return A_arbace_g2a_main__init_A_Unit13__O(); case 7: return A_arbace_g2a_main__init_A_Unit14__O(); case 8: return A_arbace_g2a_main__init_A_Unit15__O(); case 9: return A_arbace_g2a_main__init_A_Unit16__O(); case 10: return A_arbace_g2a_main__init_A_Unit17__O(); case 11: return A_arbace_g2a_main__init_A_Unit18__O(); case 12: return A_arbace_g2a_main__init_A_Unit19__O(); case 13: return A_arbace_g2a_main__init_A_Unit2__O(); case 14: return A_arbace_g2a_main__init_A_Unit3__O(); case 15: return A_arbace_g2a_main__init_A_Unit4__O(); case 16: return A_arbace_g2a_main__init_A_Unit5__O(); case 17: return A_arbace_g2a_main__init_A_Unit6__O(); case 18: return A_arbace_g2a_main__init_A_Unit7__O(); case 19: return A_arbace_g2a_main__init_A_Unit8__O(); case 20: return A_arbace_g2a_main__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__init_A_New()}; return nil }

var A_arbace_g2a_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_main__init_A_invoke, New: A_arbace_g2a_main__init_A_new}

var A_arbace_g2a_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__init_A_class.Info(); i.IsInstance = A_arbace_g2a_main__init_A_InstanceOf; i.Init = A_arbace_g2a_main__init_A_Init; i.Table = A_arbace_g2a_main__init_A_members; jrt.RegisterGoType(A_arbace_g2a_main__init_A_class, reflect.TypeFor[A_arbace_g2a_main__init_A]()) }
