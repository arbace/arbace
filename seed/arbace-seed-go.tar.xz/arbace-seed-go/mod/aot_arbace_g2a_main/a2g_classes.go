//line a2g_classes.ae:1
package aot_arbace_g2a_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_g2a_main__main_A_class, Name: "arbace.g2a.main$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000127_A_class, Name: "arbace.g2a.main$_main$fn__468000127", Modifiers: 25, Simple: "fn__468000127", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000127_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000134_A_class, Name: "arbace.g2a.main$_main$fn__468000134", Modifiers: 25, Simple: "fn__468000134", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000134_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_class, Name: "arbace.g2a.main$_main$fn__468000134$fn__468000138", Modifiers: 25, Simple: "fn__468000138", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000134_fn__468000138_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_fn__468000134_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000141_A_class, Name: "arbace.g2a.main$_main$fn__468000141", Modifiers: 25, Simple: "fn__468000141", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000141_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000143_A_class, Name: "arbace.g2a.main$_main$fn__468000143", Modifiers: 25, Simple: "fn__468000143", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000143_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000145_A_class, Name: "arbace.g2a.main$_main$fn__468000145", Modifiers: 25, Simple: "fn__468000145", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000145_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000147_A_class, Name: "arbace.g2a.main$_main$fn__468000147", Modifiers: 25, Simple: "fn__468000147", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000147_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000149_A_class, Name: "arbace.g2a.main$_main$fn__468000149", Modifiers: 25, Simple: "fn__468000149", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000149_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_class, Name: "arbace.g2a.main$_main$fn__468000149$fn__468000150", Modifiers: 25, Simple: "fn__468000150", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__main_fn__468000149_fn__468000150_A", Source: "main.ae", Declaring: &A_arbace_g2a_main__main_fn__468000149_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_candidate_dir_A_class, Name: "arbace.g2a.main$candidate_dir", Modifiers: 25, Simple: "candidate_dir", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_candidate_dir_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_check_text_A_class, Name: "arbace.g2a.main$check_text", Modifiers: 25, Simple: "check_text", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_check_text_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_check_text_fn__468000036_A_class, Name: "arbace.g2a.main$check_text$fn__468000036", Modifiers: 25, Simple: "fn__468000036", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_check_text_fn__468000036_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_check_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_A_class, Name: "arbace.g2a.main$convert_dump", Modifiers: 25, Simple: "convert_dump", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_fn__468000052_A_class, Name: "arbace.g2a.main$convert_dump$fn__468000052", Modifiers: 25, Simple: "fn__468000052", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_class, Name: "arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057", Modifiers: 25, Simple: "iter__468000053__468000057", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_fn__468000052_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_class, Name: "arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058", Modifiers: 25, Simple: "fn__468000058", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_class, Name: "arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058$fn__468000059", Modifiers: 25, Simple: "fn__468000059", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_fn__468000064_A_class, Name: "arbace.g2a.main$convert_dump$fn__468000064", Modifiers: 25, Simple: "fn__468000064", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000064_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_fn__468000066_A_class, Name: "arbace.g2a.main$convert_dump$fn__468000066", Modifiers: 25, Simple: "fn__468000066", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000066_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_fn__468000088_A_class, Name: "arbace.g2a.main$convert_dump$fn__468000088", Modifiers: 25, Simple: "fn__468000088", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_fn__468000088_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_class, Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078", Modifiers: 25, Simple: "iter__468000072__468000078", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_class, Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079", Modifiers: 25, Simple: "fn__468000079", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_class, Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080", Modifiers: 25, Simple: "iter__468000074__468000080", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_class, Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081", Modifiers: 25, Simple: "fn__468000081", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_class, Name: "arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081$fn__468000082", Modifiers: 25, Simple: "fn__468000082", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_data_of_A_class, Name: "arbace.g2a.main$data_of", Modifiers: 25, Simple: "data_of", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_data_of_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_data_of_fn__468000013_A_class, Name: "arbace.g2a.main$data_of$fn__468000013", Modifiers: 25, Simple: "fn__468000013", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_data_of_fn__468000013_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_data_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_diff_A_class, Name: "arbace.g2a.main$diff", Modifiers: 25, Simple: "diff", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_diff_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_diff_fn__468000028_A_class, Name: "arbace.g2a.main$diff$fn__468000028", Modifiers: 25, Simple: "fn__468000028", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_diff_fn__468000028_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_diff_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_dump_files_A_class, Name: "arbace.g2a.main$dump_files", Modifiers: 25, Simple: "dump_files", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_class, Name: "arbace.g2a.main$dump_files$iter__468000091__468000097", Modifiers: 25, Simple: "iter__468000091__468000097", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_dump_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_class, Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098", Modifiers: 25, Simple: "fn__468000098", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_class, Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099", Modifiers: 25, Simple: "iter__468000093__468000099", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_class, Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100", Modifiers: 25, Simple: "fn__468000100", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_class, Name: "arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100$fn__468000101", Modifiers: 25, Simple: "fn__468000101", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_class, Name: "arbace.g2a.main$eval468000004$loading__1927001464__auto____468000005", Modifiers: 25, Simple: "loading__1927001464__auto____468000005", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_eval468000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_eval468000008_fn__468000009_A_class, Name: "arbace.g2a.main$eval468000008$fn__468000009", Modifiers: 25, Simple: "fn__468000009", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000008_fn__468000009_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_eval468000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_expected_meta_A_class, Name: "arbace.g2a.main$expected_meta", Modifiers: 25, Simple: "expected_meta", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_expected_meta_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_expected_meta_fn__468000020_A_class, Name: "arbace.g2a.main$expected_meta$fn__468000020", Modifiers: 25, Simple: "fn__468000020", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_expected_meta_fn__468000020_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_expected_meta_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_merge_counts_A_class, Name: "arbace.g2a.main$merge_counts", Modifiers: 25, Simple: "merge_counts", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_merge_counts_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_munge_seg_A_class, Name: "arbace.g2a.main$munge_seg", Modifiers: 25, Simple: "munge_seg", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_munge_seg_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_ns_dir_A_class, Name: "arbace.g2a.main$ns_dir", Modifiers: 25, Simple: "ns_dir", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_ns_dir_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_print_candidate_A_class, Name: "arbace.g2a.main$print_candidate", Modifiers: 25, Simple: "print_candidate", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_print_candidate_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_program_ns_A_class, Name: "arbace.g2a.main$program_ns", Modifiers: 25, Simple: "program_ns", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_program_ns_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_read_all_A_class, Name: "arbace.g2a.main$read_all", Modifiers: 25, Simple: "read_all", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_read_all_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_read_meta_A_class, Name: "arbace.g2a.main$read_meta", Modifiers: 25, Simple: "read_meta", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_read_meta_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_main_spit_file_A_class, Name: "arbace.g2a.main$spit_file", Modifiers: 25, Simple: "spit_file", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_spit_file_A", Source: "main.ae", Declaring: &A_arbace_g2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_g2a_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_A_New()}; return nil }

var A_arbace_g2a_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_main_A_new}

var A_arbace_g2a_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_A"})

func init() { i := A_arbace_g2a_main_A_class.Info(); i.IsInstance = A_arbace_g2a_main_A_InstanceOf; i.Init = A_arbace_g2a_main_A_Init; i.Table = A_arbace_g2a_main_A_members }

var A_arbace_g2a_main__main_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000127_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000134_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000134_fn__468000138_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000141_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000143_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000145_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000147_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000149_A_class *jrt.Class

var A_arbace_g2a_main__main_fn__468000149_fn__468000150_A_class *jrt.Class

var A_arbace_g2a_main_candidate_dir_A_class *jrt.Class

var A_arbace_g2a_main_check_text_A_class *jrt.Class

var A_arbace_g2a_main_check_text_fn__468000036_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_fn__468000052_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_fn__468000052_iter__468000053__468000057_fn__468000058_fn__468000059_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_fn__468000064_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_fn__468000066_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_fn__468000088_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_A_class *jrt.Class

var A_arbace_g2a_main_convert_dump_iter__468000072__468000078_fn__468000079_iter__468000074__468000080_fn__468000081_fn__468000082_A_class *jrt.Class

var A_arbace_g2a_main_data_of_A_class *jrt.Class

var A_arbace_g2a_main_data_of_fn__468000013_A_class *jrt.Class

var A_arbace_g2a_main_diff_A_class *jrt.Class

var A_arbace_g2a_main_diff_fn__468000028_A_class *jrt.Class

var A_arbace_g2a_main_dump_files_A_class *jrt.Class

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_A_class *jrt.Class

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_A_class *jrt.Class

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_A_class *jrt.Class

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_A_class *jrt.Class

var A_arbace_g2a_main_dump_files_iter__468000091__468000097_fn__468000098_iter__468000093__468000099_fn__468000100_fn__468000101_A_class *jrt.Class

func A_arbace_g2a_main_eval468000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_eval468000004_A_New()}; return nil }

var A_arbace_g2a_main_eval468000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_main_eval468000004_A_new}

var A_arbace_g2a_main_eval468000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$eval468000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_main_A_class, Simple: "eval468000004", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000004_A"})

func init() { i := A_arbace_g2a_main_eval468000004_A_class.Info(); i.IsInstance = A_arbace_g2a_main_eval468000004_A_InstanceOf; i.Table = A_arbace_g2a_main_eval468000004_A_members }

var A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_class *jrt.Class

func A_arbace_g2a_main_eval468000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main_eval468000008_A_New()}; return nil }

var A_arbace_g2a_main_eval468000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_main_eval468000008_A_new}

var A_arbace_g2a_main_eval468000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main$eval468000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_main_A_class, Simple: "eval468000008", Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main_eval468000008_A"})

func init() { i := A_arbace_g2a_main_eval468000008_A_class.Info(); i.IsInstance = A_arbace_g2a_main_eval468000008_A_InstanceOf; i.Table = A_arbace_g2a_main_eval468000008_A_members }

var A_arbace_g2a_main_eval468000008_fn__468000009_A_class *jrt.Class

var A_arbace_g2a_main_expected_meta_A_class *jrt.Class

var A_arbace_g2a_main_expected_meta_fn__468000020_A_class *jrt.Class

var A_arbace_g2a_main_merge_counts_A_class *jrt.Class

var A_arbace_g2a_main_munge_seg_A_class *jrt.Class

var A_arbace_g2a_main_ns_dir_A_class *jrt.Class

var A_arbace_g2a_main_print_candidate_A_class *jrt.Class

var A_arbace_g2a_main_program_ns_A_class *jrt.Class

var A_arbace_g2a_main_read_all_A_class *jrt.Class

var A_arbace_g2a_main_read_meta_A_class *jrt.Class

var A_arbace_g2a_main_spit_file_A_class *jrt.Class

func A_arbace_g2a_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_main__init_A_Load__O()}; return nil }

func A_arbace_g2a_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_main__init_A_New()}; return nil }

var A_arbace_g2a_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_main__init_A_invoke, New: A_arbace_g2a_main__init_A_new}

var A_arbace_g2a_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_main.A_arbace_g2a_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_g2a_main__init_A_class.Info(); i.IsInstance = A_arbace_g2a_main__init_A_InstanceOf; i.Init = A_arbace_g2a_main__init_A_Init; i.Table = A_arbace_g2a_main__init_A_members }
