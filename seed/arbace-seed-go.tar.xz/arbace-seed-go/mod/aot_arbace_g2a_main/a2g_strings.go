//line a2g_strings.ae:1
package aot_arbace_g2a_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn18,arbace.g2a.convertkn2,asyn2,cvyn17,arbace.g2a.layoutyn6,layoutyn14,arbace.g2a.lityn3,lityn15,arbace.g2a.readyn2,rdyn16,arbace.g2a.typesyn2,tyyn13,arbace.stringyn3,strkn3,dockn5,valueks18,arbace.g2a.convert3,rawks18,arbace.g2a.convert5,derefkn4,elseyn5,in-nsyn5,quoteys11,arbace.core5,derefkn4,linekn6,columnkn5,linesks18,arbace.g2a.convert1,lkn4,datakn4,metakn3,dirys16,arbace.g2a.print13,print-packagekn3,outkn9,positionskn6,gorootkn5,checkkn5,printkn7,packagekn5,formskn8,commentskn4,textkn3,badkn5,fileskn4,pathkn2,nskn5,byteskn2,mskn7,read-mskn5,statskn6,layoutkn10,dump-nodeskn8,unplacedkn7,src-dirkn4,stemkn3,astkn4,namekn4,failkn5,tracekn4,jobskn4,fullkn5,quietkn6,reportyn16,arbace.g2a.printkn3,tagkn5,nodeskn5,noteskn5,dumpskn6,failedkn7,secondsv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.g2a.mainm2,R14,s783,Command line of g2a's converter (doc/go/CONVERTER-NOTES.md).\n\n  bin/g2a convert ... runs\n    -m arbace.g2a.main convert [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check]\n       [--report FILE] DUMP|DIR...\n  Converts each helper dump (DIRs: every .edn below them) to Go forms under OUT (default\n  .tmp/g2a/forms): go/<path>.ae and go/<path>/<file>.ae per package (doc/go/SPEC.md §4.1).\n  A single-file program (path command-line-arguments) gets the namespace go.test. plus its\n  dump's path relative to the DIR given. Unless --no-check, every file written is read back\n  with Arbace's reader and compared with the forms in memory, metadata and the lines of lists\n  included. Prints per dump a line, then totals and the coverage per node kind; --report\n  writes them as data.v11,arbace.core13,*loaded-libs*v14,arbace.g2a.lit4,lit?R15,v11,arbace.core4,seq?R16,v11,arbace.core4,listR17,v11,arbace.core5,applyv11,arbace.core7,vector?v11,arbace.core4,mapvv11,arbace.core4,map?v11,arbace.core4,intoR18,R19,R20,v11,arbace.core6,secondR21,v15,arbace.g2a.main7,data-ofv11,arbace.core3,mapv17,arbace.g2a.layout11,public-metav11,arbace.core6,dissocR22,R23,v11,arbace.core4,not=v15,arbace.g2a.main13,expected-metav15,arbace.g2a.main9,read-metav11,arbace.core3,seqv17,arbace.g2a.layout6,*mode*R24,v11,arbace.core3,notR25,v15,arbace.g2a.main4,diffv11,arbace.core5,firstR26,R27,l1,v11,arbace.core4,keepv11,arbace.core8,identityv11,arbace.core11,map-indexedv11,arbace.core6,vectorv11,arbace.core4,readv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v15,arbace.g2a.main8,read-allv11,arbace.core4,somev11,arbace.core6,pr-strv11,arbace.core5,rangeC16,java.lang.Stringv13,arbace.string7,replacev11,arbace.core6,symbolp6,\\.edn$p5,\\.go$v13,arbace.string4,joinv15,arbace.g2a.main9,munge-segv13,arbace.string5,splitp1,/v11,arbace.core3,strp2,\\.v11,arbace.core4,spitR28,v13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core17,requiring-resolveR29,v11,arbace.core5,classv11,arbace.core4,nextv11,arbace.core8,to-arrayR30,R31,R32,R33,R34,v15,arbace.g2a.read9,read-dumpR35,v15,arbace.g2a.main10,program-nsv16,arbace.g2a.types10,ns-name-ofv18,arbace.g2a.convert15,convert-packagev15,arbace.g2a.main6,ns-dirv11,arbace.core4,lastv11,arbace.core4,atomv11,arbace.core3,vecv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv17,arbace.g2a.layout10,write-filev15,arbace.g2a.main10,check-textv11,arbace.core5,assocR36,R37,v17,arbace.g2a.layout7,prepareR38,R39,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restR40,v17,arbace.g2a.layout13,write-packagev15,arbace.g2a.main15,print-candidatev11,arbace.core11,frequenciesR41,R42,R43,R44,R45,R46,R47,R48,R49,R50,p1,/v17,arbace.g2a.layout7,*stats*R51,v15,arbace.g2a.main9,spit-filev11,arbace.core5,swap!v11,arbace.core1,+v15,arbace.g2a.main13,candidate-dirv11,arbace.core6,mapcatv11,arbace.core4,compv15,arbace.g2a.read5,nodesR52,R53,v11,arbace.core6,concatR54,R55,v11,arbace.core4,takel12,v11,arbace.core7,sort-byv13,arbace.string10,ends-with?v11,arbace.core8,file-seqv11,arbace.core10,merge-withm8,R30,s14,.tmp/g2a/formsR31,R24,R56,l1,R33,TR57,R58,R59,R56,v11,arbace.core10,parse-longv15,arbace.g2a.main10,dump-filesv11,arbace.core6,filterv11,arbace.core6,removev15,arbace.g2a.main12,merge-countsv11,arbace.core7,printlnR60,v15,arbace.g2a.main12,convert-dumpm2,R61,C29,java.util.concurrent.Callablev11,arbace.core6,get-inV2,R46,R62,V2,R46,R63,v11,arbace.core15,shutdown-agentsv11,arbace.core6,formatv11,arbace.core4,sortv11,arbace.core3,setv11,arbace.core4,keysv11,arbace.core4,namel0,v11,arbace.core10,sorted-mapv11,arbace.core6,reduceR64,R65,R66,R62,R63,")

var Lit_1 *jrt.String = jrt.Intern("convert")

var Lit_2 *jrt.String = jrt.Intern("usage: convert [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check] [--report FILE] DUMP|DIR...")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000127")

var Lit_4 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000134")

var Lit_5 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000141")

var Lit_6 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000143")

var Lit_7 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000145")

var Lit_8 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000147")

var Lit_9 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000149")

var Lit_10 *jrt.String = jrt.Intern("FAIL")

var Lit_11 *jrt.String = jrt.Intern("    ")

var Lit_12 *jrt.String = jrt.Intern("BAD")

var Lit_13 *jrt.String = jrt.Intern("%s: %s, %d files, %.1f KB, %.0f ms (read %.0f ms)")

var Lit_14 *jrt.String = jrt.Intern("UNPLACED directive")

var Lit_15 *jrt.String = jrt.Intern("node kinds (converted / in the dumps):")

var Lit_16 *jrt.String = jrt.Intern("  %-20s %9d / %9d%s")

var Lit_17 *jrt.String = jrt.Intern("")

var Lit_18 *jrt.String = jrt.Intern("  *")

var Lit_19 *jrt.String = jrt.Intern("notes:")

var Lit_20 *jrt.String = jrt.Intern("layout:")

var Lit_21 *jrt.String = jrt.Intern("converted %d of %d dumps (%d files, %.1f MB of forms) in %.1f s with %d threads; %d failed, %d did not read back")

var Lit_22 *jrt.String = jrt.Intern("--full")

var Lit_23 *jrt.String = jrt.Intern("--quiet")

var Lit_24 *jrt.String = jrt.Intern("--report")

var Lit_25 *jrt.String = jrt.Intern("--print")

var Lit_26 *jrt.String = jrt.Intern("--goroot")

var Lit_27 *jrt.String = jrt.Intern("--no-check")

var Lit_28 *jrt.String = jrt.Intern("--out")

var Lit_29 *jrt.String = jrt.Intern("--jobs")

var Lit_30 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000134$fn__468000138")

var Lit_31 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000149$fn__468000150")

var Lit_32 *jrt.String = jrt.Intern("$GOROOT/")

var Lit_33 *jrt.String = jrt.Intern("/")

var Lit_34 *jrt.String = jrt.Intern("/test/")

var Lit_35 *jrt.String = jrt.Intern("read ")

var Lit_36 *jrt.String = jrt.Intern(" forms, wrote ")

var Lit_37 *jrt.String = jrt.Intern("arbace.g2a.main$check_text$fn__468000036")

var Lit_38 *jrt.String = jrt.Intern("read error: ")

var Lit_39 *jrt.String = jrt.Intern("command-line-arguments")

var Lit_40 *jrt.String = jrt.Intern("$GOROOT")

var Lit_41 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052")

var Lit_42 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000064")

var Lit_43 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000066")

var Lit_44 *jrt.String = jrt.Intern("getBytes")

var Lit_45 *jrt.String = jrt.Intern("UTF-8")

var Lit_46 *jrt.String = jrt.Intern(".ae")

var Lit_47 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078")

var Lit_48 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000088")

var Lit_49 *jrt.String = jrt.Intern("package")

var Lit_50 *jrt.String = jrt.Intern("print")

var Lit_51 *jrt.String = jrt.Intern(": ")

var Lit_52 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057")

var Lit_53 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058")

var Lit_54 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058$fn__468000059")

var Lit_55 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079")

var Lit_56 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080")

var Lit_57 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081")

var Lit_58 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081$fn__468000082")

var Lit_59 *jrt.String = jrt.Intern("arbace.g2a.main$data_of$fn__468000013")

var Lit_60 *jrt.String = jrt.Intern("arbace.g2a.main$diff$fn__468000028")

var Lit_61 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097")

var Lit_62 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098")

var Lit_63 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099")

var Lit_64 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100")

var Lit_65 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100$fn__468000101")

var Lit_66 *jrt.String = jrt.Intern(".edn")

var Lit_67 *jrt.String = jrt.Intern("java.io.File")

var Lit_68 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_69 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_70 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_71 *jrt.String = jrt.Intern("arbace.g2a.main$expected_meta$fn__468000020")

var Lit_72 *jrt.String = jrt.Intern("replaceAll")

var Lit_73 *jrt.String = jrt.Intern("[.-]")

var Lit_74 *jrt.String = jrt.Intern("_")

var Lit_75 *jrt.String = jrt.Intern("go.test.")

var Lit_76 *jrt.String = jrt.Intern(".")

var Lit_77 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,xkn4,linekn6,columnkn4,filekn7,privateyn1,ryn4,pathkn3,tagyn6,Stringyn4,textyn8,preparedyn6,ns-symyn4,Fileyn4,candyn4,dumpyn8,pkg-fileyn3,diryn3,relkn4,keysyn3,outyn9,positionsyn6,gorootyn5,checkyn5,printyn5,pathsyn2,msyn1,&yn4,argsv11,arbace.core5,in-nsMyn15,arbace.g2a.mainm2,R0,s783,Command line of g2a's converter (doc/go/CONVERTER-NOTES.md).\n\n  bin/g2a convert ... runs\n    -m arbace.g2a.main convert [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check]\n       [--report FILE] DUMP|DIR...\n  Converts each helper dump (DIRs: every .edn below them) to Go forms under OUT (default\n  .tmp/g2a/forms): go/<path>.ae and go/<path>/<file>.ae per package (doc/go/SPEC.md §4.1).\n  A single-file program (path command-line-arguments) gets the namespace go.test. plus its\n  dump's path relative to the DIR given. Unless --no-check, every file written is read back\n  with Arbace's reader and compared with the forms in memory, metadata and the lines of lists\n  included. Prints per dump a line, then totals and the coverage per node kind; --report\n  writes them as data.m2,R0,s783,Command line of g2a's converter (doc/go/CONVERTER-NOTES.md).\n\n  bin/g2a convert ... runs\n    -m arbace.g2a.main convert [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check]\n       [--report FILE] DUMP|DIR...\n  Converts each helper dump (DIRs: every .edn below them) to Go forms under OUT (default\n  .tmp/g2a/forms): go/<path>.ae and go/<path>/<file>.ae per package (doc/go/SPEC.md §4.1).\n  A single-file program (path command-line-arguments) gets the namespace go.test. plus its\n  dump's path relative to the DIR given. Unless --no-check, every file written is read back\n  with Arbace's reader and compared with the forms in memory, metadata and the lines of lists\n  included. Prints per dump a line, then totals and the coverage per node kind; --report\n  writes them as data.R1,v15,arbace.g2a.main7,data-ofm10,R2,L1,V1,R3,R0,s60,The data an in-memory form reads back as (without metadata).R4,i25,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main13,expected-metam12,R7,TR2,L1,V1,R3,R0,s79,The metadata x reads back with, as data, without :line/:column (checked apart).R4,i37,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main9,read-metam10,R7,TR2,L1,V1,R3,R4,i43,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main4,diffm10,R2,L1,V3,R3,R8,R9,R0,s125,The first difference between the in-memory form x (prepared) and the form r read back, or\n  nil: [path what expected actual].R4,i47,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main8,read-allm8,R2,L1,V1,Myn4,textm2,R10,R11,R4,i70,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main10,check-textm10,R2,L1,V2,R12,R13,R0,s63,nil when text reads back as the prepared forms, else a message.R4,i78,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main9,munge-segm10,R7,TR2,L1,V1,Myn1,sm2,R10,R11,R4,i91,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main10,program-nsm10,R2,L1,V1,Myn3,relm2,R10,R11,R0,s82,The namespace of a single-file program from its dump's relative path (x/y.go.edn).R4,i93,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main6,ns-dirm8,R2,L1,V1,R14,R4,i100,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main9,spit-filem10,R7,TR2,L1,V2,Myn1,fm2,R10,R15,Myn4,textm2,R10,R11,R4,i103,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main13,candidate-dirm10,R2,L1,V2,R16,R17,R0,s76,Where the printed Go files of a dump go in a candidate laid out like GOROOT.R4,i107,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main15,print-candidatem10,R2,L1,V2,R18,R19,R0,s132,Prints the forms of the package file pkg-file (arbace.g2a.print, loaded on first use) into\n  the candidate; nil or an error message.R4,i115,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main12,convert-dumpm10,R2,L1,V3,R9,R20,m2,R21,V5,R22,R23,R24,R25,R26,R0,s57,Converts the dump at path into out; returns a result map.R4,i124,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main10,dump-filesm10,R2,L1,V1,R27,R0,s82,[path rel] of the .edn files of the paths, sorted; rel relative to the path given.R4,i170,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main12,merge-countsm10,R7,TR2,L1,V1,R28,R4,i183,R5,i1,R6,s18,arbace/g2a/main.aev15,arbace.g2a.main5,-mainm8,R2,L1,V2,R29,R30,R4,i185,R5,i1,R6,s18,arbace/g2a/main.ae")

var Lit_78 *jrt.String = jrt.Intern("arbace.g2a.main$eval468000004$loading__1927001464__auto____468000005")

var Lit_79 *jrt.String = jrt.Intern("arbace.g2a.main$eval468000008$fn__468000009")

var Lit_80 *jrt.String = jrt.Intern("arbace.g2a.main$data_of")

var Lit_81 *jrt.String = jrt.Intern("arbace.g2a.main$expected_meta")

var Lit_82 *jrt.String = jrt.Intern("arbace.g2a.main$read_meta")

var Lit_83 *jrt.String = jrt.Intern("arbace.g2a.main$diff")

var Lit_84 *jrt.String = jrt.Intern("arbace.g2a.main$read_all")

var Lit_85 *jrt.String = jrt.Intern("arbace.g2a.main$check_text")

var Lit_86 *jrt.String = jrt.Intern("arbace.g2a.main$munge_seg")

var Lit_87 *jrt.String = jrt.Intern("arbace.g2a.main$program_ns")

var Lit_88 *jrt.String = jrt.Intern("arbace.g2a.main$ns_dir")

var Lit_89 *jrt.String = jrt.Intern("arbace.g2a.main$spit_file")

var Lit_90 *jrt.String = jrt.Intern("arbace.g2a.main$candidate_dir")

var Lit_91 *jrt.String = jrt.Intern("arbace.g2a.main$print_candidate")

var Lit_92 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump")

var Lit_93 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files")

var Lit_94 *jrt.String = jrt.Intern("arbace.g2a.main$merge_counts")

var Lit_95 *jrt.String = jrt.Intern("arbace.g2a.main$_main")
