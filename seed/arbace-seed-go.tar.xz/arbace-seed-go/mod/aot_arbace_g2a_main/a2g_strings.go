//line a2g_strings.ae:1
package aot_arbace_g2a_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.convert")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("cv")

var Lit_6 *jrt.String = jrt.Intern("arbace.g2a.layout")

var Lit_7 *jrt.String = jrt.Intern("layout")

var Lit_8 *jrt.String = jrt.Intern("arbace.g2a.lit")

var Lit_9 *jrt.String = jrt.Intern("lit")

var Lit_10 *jrt.String = jrt.Intern("arbace.g2a.read")

var Lit_11 *jrt.String = jrt.Intern("rd")

var Lit_12 *jrt.String = jrt.Intern("arbace.g2a.types")

var Lit_13 *jrt.String = jrt.Intern("ty")

var Lit_14 *jrt.String = jrt.Intern("arbace.string")

var Lit_15 *jrt.String = jrt.Intern("str")

var Lit_16 *jrt.String = jrt.Intern("commute")

var Lit_17 *jrt.String = jrt.Intern("deref")

var Lit_18 *jrt.String = jrt.Intern("conj")

var Lit_19 *jrt.String = jrt.Intern("arbace.g2a.main")

var Lit_20 *jrt.String = jrt.Intern("doc")

var Lit_21 *jrt.String = jrt.Intern("Command line of g2a's converter (doc/go/CONVERTER-NOTES.md).\n\n  bin/g2a convert ... runs\n    -m arbace.g2a.main convert [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check]\n       [--report FILE] DUMP|DIR...\n  Converts each helper dump (DIRs: every .edn below them) to Go forms under OUT (default\n  .tmp/g2a/forms): go/<path>.ae and go/<path>/<file>.ae per package (doc/go/SPEC.md §4.1).\n  A single-file program (path command-line-arguments) gets the namespace go.test. plus its\n  dump's path relative to the DIR given. Unless --no-check, every file written is read back\n  with Arbace's reader and compared with the forms in memory, metadata and the lines of lists\n  included. Prints per dump a line, then totals and the coverage per node kind; --report\n  writes them as data.")

var Lit_22 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_23 *jrt.String = jrt.Intern("lit?")

var Lit_24 *jrt.String = jrt.Intern("value")

var Lit_25 *jrt.String = jrt.Intern("seq?")

var Lit_26 *jrt.String = jrt.Intern("raw")

var Lit_27 *jrt.String = jrt.Intern("list")

var Lit_28 *jrt.String = jrt.Intern("apply")

var Lit_29 *jrt.String = jrt.Intern("vector?")

var Lit_30 *jrt.String = jrt.Intern("mapv")

var Lit_31 *jrt.String = jrt.Intern("map?")

var Lit_32 *jrt.String = jrt.Intern("into")

var Lit_33 *jrt.String = jrt.Intern("else")

var Lit_34 *jrt.String = jrt.Intern("in-ns")

var Lit_35 *jrt.String = jrt.Intern("quote")

var Lit_36 *jrt.String = jrt.Intern("second")

var Lit_37 *jrt.String = jrt.Intern("data-of")

var Lit_38 *jrt.String = jrt.Intern("map")

var Lit_39 *jrt.String = jrt.Intern("public-meta")

var Lit_40 *jrt.String = jrt.Intern("dissoc")

var Lit_41 *jrt.String = jrt.Intern("line")

var Lit_42 *jrt.String = jrt.Intern("column")

var Lit_43 *jrt.String = jrt.Intern("not=")

var Lit_44 *jrt.String = jrt.Intern("expected-meta")

var Lit_45 *jrt.String = jrt.Intern("read-meta")

var Lit_46 *jrt.String = jrt.Intern("seq")

var Lit_47 *jrt.String = jrt.Intern("*mode*")

var Lit_48 *jrt.String = jrt.Intern("lines")

var Lit_49 *jrt.String = jrt.Intern("not")

var Lit_50 *jrt.String = jrt.Intern("l")

var Lit_51 *jrt.String = jrt.Intern("diff")

var Lit_52 *jrt.String = jrt.Intern("first")

var Lit_53 *jrt.String = jrt.Intern("data")

var Lit_54 *jrt.String = jrt.Intern("meta")

var Lit_55 *jrt.String = jrt.Intern("keep")

var Lit_56 *jrt.String = jrt.Intern("identity")

var Lit_57 *jrt.String = jrt.Intern("map-indexed")

var Lit_58 *jrt.String = jrt.Intern("vector")

var Lit_59 *jrt.String = jrt.Intern("read")

var Lit_60 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_61 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_62 *jrt.String = jrt.Intern("hash-map")

var Lit_63 *jrt.String = jrt.Intern("*read-eval*")

var Lit_64 *jrt.String = jrt.Intern("read-all")

var Lit_65 *jrt.String = jrt.Intern("some")

var Lit_66 *jrt.String = jrt.Intern("pr-str")

var Lit_67 *jrt.String = jrt.Intern("range")

var Lit_68 *jrt.String = jrt.Intern("java.lang.String")

var Lit_69 *jrt.String = jrt.Intern("replace")

var Lit_70 *jrt.String = jrt.Intern("symbol")

var Lit_71 *jrt.String = jrt.Intern("\\.edn$")

var Lit_72 *jrt.String = jrt.Intern("\\.go$")

var Lit_73 *jrt.String = jrt.Intern("join")

var Lit_74 *jrt.String = jrt.Intern("munge-seg")

var Lit_75 *jrt.String = jrt.Intern("split")

var Lit_76 *jrt.String = jrt.Intern("/")

var Lit_77 *jrt.String = jrt.Intern("\\.")

var Lit_78 *jrt.String = jrt.Intern("spit")

var Lit_79 *jrt.String = jrt.Intern("dir")

var Lit_80 *jrt.String = jrt.Intern("starts-with?")

var Lit_81 *jrt.String = jrt.Intern("subs")

var Lit_82 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_83 *jrt.String = jrt.Intern("arbace.g2a.print")

var Lit_84 *jrt.String = jrt.Intern("print-package")

var Lit_85 *jrt.String = jrt.Intern("class")

var Lit_86 *jrt.String = jrt.Intern("next")

var Lit_87 *jrt.String = jrt.Intern("to-array")

var Lit_88 *jrt.String = jrt.Intern("out")

var Lit_89 *jrt.String = jrt.Intern("positions")

var Lit_90 *jrt.String = jrt.Intern("goroot")

var Lit_91 *jrt.String = jrt.Intern("check")

var Lit_92 *jrt.String = jrt.Intern("print")

var Lit_93 *jrt.String = jrt.Intern("read-dump")

var Lit_94 *jrt.String = jrt.Intern("package")

var Lit_95 *jrt.String = jrt.Intern("program-ns")

var Lit_96 *jrt.String = jrt.Intern("ns-name-of")

var Lit_97 *jrt.String = jrt.Intern("convert-package")

var Lit_98 *jrt.String = jrt.Intern("ns-dir")

var Lit_99 *jrt.String = jrt.Intern("last")

var Lit_100 *jrt.String = jrt.Intern("atom")

var Lit_101 *jrt.String = jrt.Intern("vec")

var Lit_102 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_103 *jrt.String = jrt.Intern("chunk-first")

var Lit_104 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_105 *jrt.String = jrt.Intern("chunk-append")

var Lit_106 *jrt.String = jrt.Intern("write-file")

var Lit_107 *jrt.String = jrt.Intern("check-text")

var Lit_108 *jrt.String = jrt.Intern("assoc")

var Lit_109 *jrt.String = jrt.Intern("forms")

var Lit_110 *jrt.String = jrt.Intern("comments")

var Lit_111 *jrt.String = jrt.Intern("prepare")

var Lit_112 *jrt.String = jrt.Intern("text")

var Lit_113 *jrt.String = jrt.Intern("bad")

var Lit_114 *jrt.String = jrt.Intern("chunk-cons")

var Lit_115 *jrt.String = jrt.Intern("cons")

var Lit_116 *jrt.String = jrt.Intern("chunk")

var Lit_117 *jrt.String = jrt.Intern("chunk-rest")

var Lit_118 *jrt.String = jrt.Intern("rest")

var Lit_119 *jrt.String = jrt.Intern("files")

var Lit_120 *jrt.String = jrt.Intern("write-package")

var Lit_121 *jrt.String = jrt.Intern("print-candidate")

var Lit_122 *jrt.String = jrt.Intern("frequencies")

var Lit_123 *jrt.String = jrt.Intern("path")

var Lit_124 *jrt.String = jrt.Intern("ns")

var Lit_125 *jrt.String = jrt.Intern("bytes")

var Lit_126 *jrt.String = jrt.Intern("ms")

var Lit_127 *jrt.String = jrt.Intern("read-ms")

var Lit_128 *jrt.String = jrt.Intern("stats")

var Lit_129 *jrt.String = jrt.Intern("dump-nodes")

var Lit_130 *jrt.String = jrt.Intern("unplaced")

var Lit_131 *jrt.String = jrt.Intern("src-dir")

var Lit_132 *jrt.String = jrt.Intern("*stats*")

var Lit_133 *jrt.String = jrt.Intern("stem")

var Lit_134 *jrt.String = jrt.Intern("spit-file")

var Lit_135 *jrt.String = jrt.Intern("swap!")

var Lit_136 *jrt.String = jrt.Intern("+")

var Lit_137 *jrt.String = jrt.Intern("candidate-dir")

var Lit_138 *jrt.String = jrt.Intern("mapcat")

var Lit_139 *jrt.String = jrt.Intern("comp")

var Lit_140 *jrt.String = jrt.Intern("nodes")

var Lit_141 *jrt.String = jrt.Intern("ast")

var Lit_142 *jrt.String = jrt.Intern("name")

var Lit_143 *jrt.String = jrt.Intern("concat")

var Lit_144 *jrt.String = jrt.Intern("fail")

var Lit_145 *jrt.String = jrt.Intern("trace")

var Lit_146 *jrt.String = jrt.Intern("take")

var Lit_147 *jrt.String = jrt.Intern("sort-by")

var Lit_148 *jrt.String = jrt.Intern("ends-with?")

var Lit_149 *jrt.String = jrt.Intern("file-seq")

var Lit_150 *jrt.String = jrt.Intern("merge-with")

var Lit_151 *jrt.String = jrt.Intern(".tmp/g2a/forms")

var Lit_152 *jrt.String = jrt.Intern("jobs")

var Lit_153 *jrt.String = jrt.Intern("full")

var Lit_154 *jrt.String = jrt.Intern("quiet")

var Lit_155 *jrt.String = jrt.Intern("report")

var Lit_156 *jrt.String = jrt.Intern("parse-long")

var Lit_157 *jrt.String = jrt.Intern("dump-files")

var Lit_158 *jrt.String = jrt.Intern("filter")

var Lit_159 *jrt.String = jrt.Intern("remove")

var Lit_160 *jrt.String = jrt.Intern("merge-counts")

var Lit_161 *jrt.String = jrt.Intern("println")

var Lit_162 *jrt.String = jrt.Intern("convert-dump")

var Lit_163 *jrt.String = jrt.Intern("tag")

var Lit_164 *jrt.String = jrt.Intern("java.util.concurrent.Callable")

var Lit_165 *jrt.String = jrt.Intern("get-in")

var Lit_166 *jrt.String = jrt.Intern("notes")

var Lit_167 *jrt.String = jrt.Intern("shutdown-agents")

var Lit_168 *jrt.String = jrt.Intern("format")

var Lit_169 *jrt.String = jrt.Intern("sort")

var Lit_170 *jrt.String = jrt.Intern("set")

var Lit_171 *jrt.String = jrt.Intern("keys")

var Lit_172 *jrt.String = jrt.Intern("sorted-map")

var Lit_173 *jrt.String = jrt.Intern("reduce")

var Lit_174 *jrt.String = jrt.Intern("dumps")

var Lit_175 *jrt.String = jrt.Intern("failed")

var Lit_176 *jrt.String = jrt.Intern("seconds")

var Lit_177 *jrt.String = jrt.Intern("arbace.g2a.main$_main")

var Lit_178 *jrt.String = jrt.Intern("convert")

var Lit_179 *jrt.String = jrt.Intern("usage: convert [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check] [--report FILE] DUMP|DIR...")

var Lit_180 *jrt.String = jrt.Intern("FAIL")

var Lit_181 *jrt.String = jrt.Intern("    ")

var Lit_182 *jrt.String = jrt.Intern("BAD")

var Lit_183 *jrt.String = jrt.Intern("%s: %s, %d files, %.1f KB, %.0f ms (read %.0f ms)")

var Lit_184 *jrt.String = jrt.Intern("UNPLACED directive")

var Lit_185 *jrt.String = jrt.Intern("node kinds (converted / in the dumps):")

var Lit_186 *jrt.String = jrt.Intern("  %-20s %9d / %9d%s")

var Lit_187 *jrt.String = jrt.Intern("")

var Lit_188 *jrt.String = jrt.Intern("  *")

var Lit_189 *jrt.String = jrt.Intern("notes:")

var Lit_190 *jrt.String = jrt.Intern("layout:")

var Lit_191 *jrt.String = jrt.Intern("converted %d of %d dumps (%d files, %.1f MB of forms) in %.1f s with %d threads; %d failed, %d did not read back")

var Lit_192 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000127")

var Lit_193 *jrt.String = jrt.Intern("--full")

var Lit_194 *jrt.String = jrt.Intern("--quiet")

var Lit_195 *jrt.String = jrt.Intern("--report")

var Lit_196 *jrt.String = jrt.Intern("--print")

var Lit_197 *jrt.String = jrt.Intern("--goroot")

var Lit_198 *jrt.String = jrt.Intern("--no-check")

var Lit_199 *jrt.String = jrt.Intern("--out")

var Lit_200 *jrt.String = jrt.Intern("--jobs")

var Lit_201 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000134")

var Lit_202 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000134$fn__468000138")

var Lit_203 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000141")

var Lit_204 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000143")

var Lit_205 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000145")

var Lit_206 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000147")

var Lit_207 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000149")

var Lit_208 *jrt.String = jrt.Intern("arbace.g2a.main$_main$fn__468000149$fn__468000150")

var Lit_209 *jrt.String = jrt.Intern("arbace.g2a.main$candidate_dir")

var Lit_210 *jrt.String = jrt.Intern("$GOROOT/")

var Lit_211 *jrt.String = jrt.Intern("/test/")

var Lit_212 *jrt.String = jrt.Intern("arbace.g2a.main$check_text")

var Lit_213 *jrt.String = jrt.Intern("read ")

var Lit_214 *jrt.String = jrt.Intern(" forms, wrote ")

var Lit_215 *jrt.String = jrt.Intern("read error: ")

var Lit_216 *jrt.String = jrt.Intern("arbace.g2a.main$check_text$fn__468000036")

var Lit_217 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump")

var Lit_218 *jrt.String = jrt.Intern("command-line-arguments")

var Lit_219 *jrt.String = jrt.Intern("$GOROOT")

var Lit_220 *jrt.String = jrt.Intern("getBytes")

var Lit_221 *jrt.String = jrt.Intern("UTF-8")

var Lit_222 *jrt.String = jrt.Intern(".ae")

var Lit_223 *jrt.String = jrt.Intern(": ")

var Lit_224 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052")

var Lit_225 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057")

var Lit_226 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058")

var Lit_227 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000052$iter__468000053__468000057$fn__468000058$fn__468000059")

var Lit_228 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000064")

var Lit_229 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000066")

var Lit_230 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$fn__468000088")

var Lit_231 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078")

var Lit_232 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079")

var Lit_233 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080")

var Lit_234 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081")

var Lit_235 *jrt.String = jrt.Intern("arbace.g2a.main$convert_dump$iter__468000072__468000078$fn__468000079$iter__468000074__468000080$fn__468000081$fn__468000082")

var Lit_236 *jrt.String = jrt.Intern("arbace.g2a.main$data_of")

var Lit_237 *jrt.String = jrt.Intern("arbace.g2a.main$data_of$fn__468000013")

var Lit_238 *jrt.String = jrt.Intern("arbace.g2a.main$diff")

var Lit_239 *jrt.String = jrt.Intern("arbace.g2a.main$diff$fn__468000028")

var Lit_240 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files")

var Lit_241 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097")

var Lit_242 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098")

var Lit_243 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099")

var Lit_244 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100")

var Lit_245 *jrt.String = jrt.Intern(".edn")

var Lit_246 *jrt.String = jrt.Intern("arbace.g2a.main$dump_files$iter__468000091__468000097$fn__468000098$iter__468000093__468000099$fn__468000100$fn__468000101")

var Lit_247 *jrt.String = jrt.Intern("arbace.g2a.main$eval468000004$loading__1927001464__auto____468000005")

var Lit_248 *jrt.String = jrt.Intern("java.io.File")

var Lit_249 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_250 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_251 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_252 *jrt.String = jrt.Intern("arbace.g2a.main$eval468000008$fn__468000009")

var Lit_253 *jrt.String = jrt.Intern("arbace.g2a.main$expected_meta")

var Lit_254 *jrt.String = jrt.Intern("arbace.g2a.main$expected_meta$fn__468000020")

var Lit_255 *jrt.String = jrt.Intern("arbace.g2a.main$merge_counts")

var Lit_256 *jrt.String = jrt.Intern("arbace.g2a.main$munge_seg")

var Lit_257 *jrt.String = jrt.Intern("replaceAll")

var Lit_258 *jrt.String = jrt.Intern("[.-]")

var Lit_259 *jrt.String = jrt.Intern("_")

var Lit_260 *jrt.String = jrt.Intern("arbace.g2a.main$ns_dir")

var Lit_261 *jrt.String = jrt.Intern("arbace.g2a.main$print_candidate")

var Lit_262 *jrt.String = jrt.Intern("arbace.g2a.main$program_ns")

var Lit_263 *jrt.String = jrt.Intern("go.test.")

var Lit_264 *jrt.String = jrt.Intern(".")

var Lit_265 *jrt.String = jrt.Intern("arbace.g2a.main$read_all")

var Lit_266 *jrt.String = jrt.Intern("arbace.g2a.main$read_meta")

var Lit_267 *jrt.String = jrt.Intern("arbace.g2a.main$spit_file")

var Lit_268 *jrt.String = jrt.Intern("arglists")

var Lit_269 *jrt.String = jrt.Intern("x")

var Lit_270 *jrt.String = jrt.Intern("The data an in-memory form reads back as (without metadata).")

var Lit_271 *jrt.String = jrt.Intern("file")

var Lit_272 *jrt.String = jrt.Intern("arbace/g2a/main.ae")

var Lit_273 *jrt.String = jrt.Intern("private")

var Lit_274 *jrt.String = jrt.Intern("The metadata x reads back with, as data, without :line/:column (checked apart).")

var Lit_275 *jrt.String = jrt.Intern("r")

var Lit_276 *jrt.String = jrt.Intern("The first difference between the in-memory form x (prepared) and the form r read back, or\n  nil: [path what expected actual].")

var Lit_277 *jrt.String = jrt.Intern("String")

var Lit_278 *jrt.String = jrt.Intern("prepared")

var Lit_279 *jrt.String = jrt.Intern("nil when text reads back as the prepared forms, else a message.")

var Lit_280 *jrt.String = jrt.Intern("s")

var Lit_281 *jrt.String = jrt.Intern("rel")

var Lit_282 *jrt.String = jrt.Intern("The namespace of a single-file program from its dump's relative path (x/y.go.edn).")

var Lit_283 *jrt.String = jrt.Intern("ns-sym")

var Lit_284 *jrt.String = jrt.Intern("f")

var Lit_285 *jrt.String = jrt.Intern("File")

var Lit_286 *jrt.String = jrt.Intern("cand")

var Lit_287 *jrt.String = jrt.Intern("dump")

var Lit_288 *jrt.String = jrt.Intern("Where the printed Go files of a dump go in a candidate laid out like GOROOT.")

var Lit_289 *jrt.String = jrt.Intern("pkg-file")

var Lit_290 *jrt.String = jrt.Intern("Prints the forms of the package file pkg-file (arbace.g2a.print, loaded on first use) into\n  the candidate; nil or an error message.")

var Lit_291 *jrt.String = jrt.Intern("Converts the dump at path into out; returns a result map.")

var Lit_292 *jrt.String = jrt.Intern("paths")

var Lit_293 *jrt.String = jrt.Intern("[path rel] of the .edn files of the paths, sorted; rel relative to the path given.")

var Lit_294 *jrt.String = jrt.Intern("-main")

var Lit_295 *jrt.String = jrt.Intern("&")

var Lit_296 *jrt.String = jrt.Intern("args")
