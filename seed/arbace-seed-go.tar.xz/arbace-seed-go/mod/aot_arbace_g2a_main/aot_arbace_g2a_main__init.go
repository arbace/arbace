//line aot_arbace_g2a_main__init.ae:1
package aot_arbace_g2a_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_main__init_A_Unit0__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_main__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_main__init_A_const_1) }
//line :1:1
func A_arbace_g2a_main__init_A_Unit1__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_main__init_A_Unit2__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_Init(); tmp2 = A_arbace_g2a_main_eval468000004_loading__1927001464__auto____468000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_main__init_A_Unit3__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_main__init_A_const_1)).Equals_O__Z(A_arbace_g2a_main__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_main_eval468000008_fn__468000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_main_eval468000008_fn__468000009_A_Init(); tmp2 = A_arbace_g2a_main_eval468000008_fn__468000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_main__init_A_Load__O() any { A_arbace_g2a_main__init_A_Init(); A_arbace_g2a_main__init_A_Unit0__O(); A_arbace_g2a_main__init_A_Unit1__O(); A_arbace_g2a_main__init_A_Unit2__O(); A_arbace_g2a_main__init_A_Unit3__O(); A_arbace_g2a_main__init_A_Unit4__O(); A_arbace_g2a_main__init_A_Unit5__O(); A_arbace_g2a_main__init_A_Unit6__O(); A_arbace_g2a_main__init_A_Unit7__O(); A_arbace_g2a_main__init_A_Unit8__O(); A_arbace_g2a_main__init_A_Unit9__O(); A_arbace_g2a_main__init_A_Unit10__O(); A_arbace_g2a_main__init_A_Unit11__O(); A_arbace_g2a_main__init_A_Unit12__O(); A_arbace_g2a_main__init_A_Unit13__O(); A_arbace_g2a_main__init_A_Unit14__O(); A_arbace_g2a_main__init_A_Unit15__O(); A_arbace_g2a_main__init_A_Unit16__O(); A_arbace_g2a_main__init_A_Unit17__O(); A_arbace_g2a_main__init_A_Unit18__O(); A_arbace_g2a_main__init_A_Unit19__O(); return nil }



















func A_arbace_g2a_main__init_A_Unit4__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_4; var tmp2 any = A_arbace_g2a_main_data_of_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_data_of_A_Init(); tmp3 = A_arbace_g2a_main_data_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_5)); return A_arbace_g2a_main__init_A_const_4.Ref() }











func A_arbace_g2a_main__init_A_Unit5__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_6; var tmp2 any = A_arbace_g2a_main_expected_meta_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_expected_meta_A_Init(); tmp3 = A_arbace_g2a_main_expected_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_7)); return A_arbace_g2a_main__init_A_const_6.Ref() }





func A_arbace_g2a_main__init_A_Unit6__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_8; var tmp2 any = A_arbace_g2a_main_read_meta_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_read_meta_A_Init(); tmp3 = A_arbace_g2a_main_read_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_9)); return A_arbace_g2a_main__init_A_const_8.Ref() }



func A_arbace_g2a_main__init_A_Unit7__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_10; var tmp2 any = A_arbace_g2a_main_diff_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_diff_A_Init(); tmp3 = A_arbace_g2a_main_diff_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_11)); return A_arbace_g2a_main__init_A_const_10.Ref() }






















func A_arbace_g2a_main__init_A_Unit8__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_12; var tmp2 any = A_arbace_g2a_main_read_all_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_read_all_A_Init(); tmp3 = A_arbace_g2a_main_read_all_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_13)); return A_arbace_g2a_main__init_A_const_12.Ref() }







func A_arbace_g2a_main__init_A_Unit9__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_14; var tmp2 any = A_arbace_g2a_main_check_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_check_text_A_Init(); tmp3 = A_arbace_g2a_main_check_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_15)); return A_arbace_g2a_main__init_A_const_14.Ref() }












func A_arbace_g2a_main__init_A_Unit10__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_16; var tmp2 any = A_arbace_g2a_main_munge_seg_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_munge_seg_A_Init(); tmp3 = A_arbace_g2a_main_munge_seg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_17)); return A_arbace_g2a_main__init_A_const_16.Ref() }

func A_arbace_g2a_main__init_A_Unit11__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(93, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_18; var tmp2 any = A_arbace_g2a_main_program_ns_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_program_ns_A_Init(); tmp3 = A_arbace_g2a_main_program_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_19)); return A_arbace_g2a_main__init_A_const_18.Ref() }






func A_arbace_g2a_main__init_A_Unit12__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_20; var tmp2 any = A_arbace_g2a_main_ns_dir_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_ns_dir_A_Init(); tmp3 = A_arbace_g2a_main_ns_dir_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_21)); return A_arbace_g2a_main__init_A_const_20.Ref() }


func A_arbace_g2a_main__init_A_Unit13__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(103, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_22; var tmp2 any = A_arbace_g2a_main_spit_file_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_spit_file_A_Init(); tmp3 = A_arbace_g2a_main_spit_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_23)); return A_arbace_g2a_main__init_A_const_22.Ref() }



func A_arbace_g2a_main__init_A_Unit14__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_24; var tmp2 any = A_arbace_g2a_main_candidate_dir_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_candidate_dir_A_Init(); tmp3 = A_arbace_g2a_main_candidate_dir_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_25)); return A_arbace_g2a_main__init_A_const_24.Ref() }







func A_arbace_g2a_main__init_A_Unit15__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_26; var tmp2 any = A_arbace_g2a_main_print_candidate_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_print_candidate_A_Init(); tmp3 = A_arbace_g2a_main_print_candidate_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_27)); return A_arbace_g2a_main__init_A_const_26.Ref() }








func A_arbace_g2a_main__init_A_Unit16__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_28; var tmp2 any = A_arbace_g2a_main_convert_dump_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_convert_dump_A_Init(); tmp3 = A_arbace_g2a_main_convert_dump_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_29)); return A_arbace_g2a_main__init_A_const_28.Ref() }













































func A_arbace_g2a_main__init_A_Unit17__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(170, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_30; var tmp2 any = A_arbace_g2a_main_dump_files_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_dump_files_A_Init(); tmp3 = A_arbace_g2a_main_dump_files_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_31)); return A_arbace_g2a_main__init_A_const_30.Ref() }












func A_arbace_g2a_main__init_A_Unit18__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_32; var tmp2 any = A_arbace_g2a_main_merge_counts_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main_merge_counts_A_Init(); tmp3 = A_arbace_g2a_main_merge_counts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_33)); return A_arbace_g2a_main__init_A_const_32.Ref() }

func A_arbace_g2a_main__init_A_Unit19__O() any { A_arbace_g2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.Var = A_arbace_g2a_main__init_A_const_34; var tmp2 any = A_arbace_g2a_main__main_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_main__main_A_Init(); tmp3 = A_arbace_g2a_main__main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_g2a_main__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_main__init_A_const_35)); return A_arbace_g2a_main__init_A_const_34.Ref() }



type A_arbace_g2a_main__init_A struct{ jrt.Object }

var A_arbace_g2a_main__init_A_const_0 *lang.Var

var A_arbace_g2a_main__init_A_const_1 any

var A_arbace_g2a_main__init_A_const_2 any

var A_arbace_g2a_main__init_A_const_3 any

var A_arbace_g2a_main__init_A_const_4 *lang.Var

var A_arbace_g2a_main__init_A_const_5 any

var A_arbace_g2a_main__init_A_const_6 *lang.Var

var A_arbace_g2a_main__init_A_const_7 any

var A_arbace_g2a_main__init_A_const_8 *lang.Var

var A_arbace_g2a_main__init_A_const_9 any

var A_arbace_g2a_main__init_A_const_10 *lang.Var

var A_arbace_g2a_main__init_A_const_11 any

var A_arbace_g2a_main__init_A_const_12 *lang.Var

var A_arbace_g2a_main__init_A_const_13 any

var A_arbace_g2a_main__init_A_const_14 *lang.Var

var A_arbace_g2a_main__init_A_const_15 any

var A_arbace_g2a_main__init_A_const_16 *lang.Var

var A_arbace_g2a_main__init_A_const_17 any

var A_arbace_g2a_main__init_A_const_18 *lang.Var

var A_arbace_g2a_main__init_A_const_19 any

var A_arbace_g2a_main__init_A_const_20 *lang.Var

var A_arbace_g2a_main__init_A_const_21 any

var A_arbace_g2a_main__init_A_const_22 *lang.Var

var A_arbace_g2a_main__init_A_const_23 any

var A_arbace_g2a_main__init_A_const_24 *lang.Var

var A_arbace_g2a_main__init_A_const_25 any

var A_arbace_g2a_main__init_A_const_26 *lang.Var

var A_arbace_g2a_main__init_A_const_27 any

var A_arbace_g2a_main__init_A_const_28 *lang.Var

var A_arbace_g2a_main__init_A_const_29 any

var A_arbace_g2a_main__init_A_const_30 *lang.Var

var A_arbace_g2a_main__init_A_const_31 any

var A_arbace_g2a_main__init_A_const_32 *lang.Var

var A_arbace_g2a_main__init_A_const_33 any

var A_arbace_g2a_main__init_A_const_34 *lang.Var

var A_arbace_g2a_main__init_A_const_35 any

var A_arbace_g2a_main__init_A_init jrt.ClassInit

func A_arbace_g2a_main__init_A_Init() { if !A_arbace_g2a_main__init_A_init.Done() { A_arbace_g2a_main__init_A_init.Run(A_arbace_g2a_main__init_A_clinit) } }

func A_arbace_g2a_main__init_A_clinit() { A_arbace_g2a_main__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_g2a_main__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_21))); A_arbace_g2a_main__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_21)); A_arbace_g2a_main__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_main__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_19, Lit_37); A_arbace_g2a_main__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_269).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_270, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_19, Lit_44); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_273).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_main__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_269).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_274, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_19, Lit_45); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_273).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_g2a_main__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_269).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_19, Lit_51); A_arbace_g2a_main__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_269).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_275).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_276, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_19, Lit_64); A_arbace_g2a_main__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_277).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_19, Lit_107); A_arbace_g2a_main__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_278).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_279, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_19, Lit_74); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_273).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_g2a_main__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_280)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_277).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_19, Lit_95); A_arbace_g2a_main__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_281)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_277).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_282, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(93).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_19, Lit_98); A_arbace_g2a_main__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_19, Lit_134); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_273).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_g2a_main__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_284)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_285).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_277).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(103).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_19, Lit_137); A_arbace_g2a_main__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_286).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_287).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_288, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(107).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_19, Lit_121); A_arbace_g2a_main__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_290, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_19, Lit_162); A_arbace_g2a_main__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_281).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_171).Ref(), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_291, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_19, Lit_157); A_arbace_g2a_main__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_292).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_293, lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(170).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_19, Lit_160); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_273).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_g2a_main__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(183).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)); A_arbace_g2a_main__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_19, Lit_294); A_arbace_g2a_main__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_295).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_296).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), jrt.Integer_ValueOf_I__Integer(185).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), Lit_272)) }

func A_arbace_g2a_main__init_A_New() *A_arbace_g2a_main__init_A { A_arbace_g2a_main__init_A_Init(); t := &A_arbace_g2a_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_main__init_A) Ctor() {}

func (t *A_arbace_g2a_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_main__init_A_class }

func (t *A_arbace_g2a_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_main__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_main__init_A); return ok }

func A_arbace_g2a_main__init_A_Cast(x any) *A_arbace_g2a_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_main__init_A_class)) }; return v }
