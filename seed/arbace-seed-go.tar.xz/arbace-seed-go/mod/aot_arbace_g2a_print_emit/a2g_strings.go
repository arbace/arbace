//line a2g_strings.ae:1
package aot_arbace_g2a_print_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn21,arbace.g2a.print-textkn2,asyn4,textyn13,arbace.stringyn3,strkn3,dockn2,sbkn4,linekn3,bolkn6,indentkn10,cur-indentkn4,lastkn4,semikn2,wskn5,openskn4,markkn8,min-linekn6,lines?kn11,directives?kn16,line-directives?ys21,arbace.g2a.print-emit3,*p*ys11,arbace.core5,derefys11,arbace.core4,whenys21,arbace.g2a.print-emit6,lines?ys11,arbace.core3,letyn21,l__1256000046__auto__ys11,arbace.core4,metays11,arbace.core8,integer?ys11,arbace.core4,longkn4,elsekn4,textkn5,breakv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn21,arbace.g2a.print-emitm2,R6,s431,The emitter of g2a's printer (doc/go/PRINTER-NOTES.md): writes Go tokens, tracks the\n  line, indentation and Go's semicolon rule, and places tokens on the lines the forms record\n  (doc/go/SPEC.md §10.1, §12.3).\n\n  The state is one map of volatiles bound to *p* while a file is printed. Text is written\n  with tabs for indentation and vertical tabs between aligned cells; print-text/align turns\n  it into gofmt's spacing at the end.v11,arbace.core13,*loaded-libs*R7,R8,v11,arbace.core9,volatile!R9,R10,R11,R12,R13,R14,R15,R16,R17,R18,R19,R20,l1,l0,v21,arbace.g2a.print-emit3,*p*v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR21,R22,R21,R21,v11,arbace.core8,integer?R23,R24,R25,v11,arbace.core5,applyv11,arbace.core6,vectorR26,R27,R23,R28,R29,v11,arbace.core3,notv21,arbace.g2a.print-emit6,*next*S9,s1,]s1,)s2,++s6,returns11,fallthroughs5,breaks2,--s8,continues1,}v21,arbace.g2a.print-emit8,keywordsR30,c95,c34,c39,c96,c43,c45,c47,c42,c60,c38,c94,c46,v11,arbace.core10,re-matchesp6,[0-9]+v11,arbace.core7,vreset!c9,v21,arbace.g2a.print-emit11,start-line!v21,arbace.g2a.print-emit12,may-combine?c32,v21,arbace.g2a.print-emit11,semi-after?v21,arbace.g2a.print-emit3,tokv11,arbace.core6,filterv21,arbace.g2a.print-text6,escapec10,c11,v21,arbace.g2a.print-emit2,nlR21,v21,arbace.g2a.print-emit10,push-open!v11,arbace.core4,peekv11,arbace.core3,popv13,arbace.string12,starts-with?R31,v11,arbace.core6,empty?v21,arbace.g2a.print-emit9,set-line!v21,arbace.g2a.print-emit12,comment-linev11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv21,arbace.g2a.print-emit9,new-statem4,R18,FR20,FR32,v21,arbace.g2a.print-emit21,line-directive-inlinev21,arbace.g2a.print-emit11,cont-indentv21,arbace.g2a.print-emit2,spv21,arbace.g2a.print-emit5,room?v21,arbace.g2a.print-emit18,line-directive-ownv13,arbace.string7,replacev21,arbace.g2a.print-text5,alignp10,[ \\x0B]+\\nv13,arbace.string10,ends-with?")

var Lit_1 *jrt.String = jrt.Intern("//line ")

var Lit_2 *jrt.String = jrt.Intern("")

var Lit_3 *jrt.String = jrt.Intern("/*line :")

var Lit_4 *jrt.String = jrt.Intern(":1*/")

var Lit_5 *jrt.String = jrt.Intern("//line :")

var Lit_6 *jrt.String = jrt.Intern(":1")

var Lit_7 *jrt.String = jrt.Intern("+")

var Lit_8 *jrt.String = jrt.Intern("-")

var Lit_9 *jrt.String = jrt.Intern("<")

var Lit_10 *jrt.String = jrt.Intern("&")

var Lit_11 *jrt.String = jrt.Intern("arbace.g2a.print_emit$raw_tok$fn__1256000064")

var Lit_12 *jrt.String = jrt.Intern("\n")

var Lit_13 *jrt.String = jrt.Intern("arbace.g2a.print_emit$stmt_break_BANG_$newline_BANG___1256000093")

var Lit_14 *jrt.String = jrt.Intern("arbace.g2a.print_emit$stmt_break_BANG_$same_BANG___1256000095")

var Lit_15 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn4,optskn6,inlineyn1,fyn1,nkn7,privatekn3,tagyn6,Stringyn6,indentyn10,form-feed?yn1,lyn1,cyn1,tyn6,first?yn3,sepyn3,endyn10,multiline?yn7,always?v11,arbace.core5,in-nsMyn21,arbace.g2a.print-emitm2,R0,s431,The emitter of g2a's printer (doc/go/PRINTER-NOTES.md): writes Go tokens, tracks the\n  line, indentation and Go's semicolon rule, and places tokens on the lines the forms record\n  (doc/go/SPEC.md §10.1, §12.3).\n\n  The state is one map of volatiles bound to *p* while a file is printed. Text is written\n  with tabs for indentation and vertical tabs between aligned cells; print-text/align turns\n  it into gofmt's spacing at the end.m2,R0,s431,The emitter of g2a's printer (doc/go/PRINTER-NOTES.md): writes Go tokens, tracks the\n  line, indentation and Go's semicolon rule, and places tokens on the lines the forms record\n  (doc/go/SPEC.md §10.1, §12.3).\n\n  The state is one map of volatiles bound to *p* while a file is printed. Text is written\n  with tabs for indentation and vertical tabs between aligned cells; print-text/align turns\n  it into gofmt's spacing at the end.R1,v21,arbace.g2a.print-emit3,*p*m8,R2,TR3,i12,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit6,*next*m10,R2,TR3,i14,R4,i1,R5,s24,arbace/g2a/print_emit.aeR0,s155,The line of what follows the construct being printed, when known: the room a closing\n  brace or a statement without a recorded line may take (mode :lines).v21,arbace.g2a.print-emit9,new-statem10,R6,L1,V1,R7,R0,s161,opts: :lines? (place forms on their recorded lines), :line-directives? (write //line or\n  /*line*/ directives where a recorded line cannot be reached by layout).R3,i19,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit6,lines?m8,R6,L1,V0,R3,i37,R4,i1,R5,s24,arbace/g2a/print_emit.aev11,arbace.core11,alter-meta!v11,arbace.core5,assocR8,v21,arbace.g2a.print-emit4,linem8,R6,L1,V0,R3,i38,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit4,bol?m8,R6,L1,V0,R3,i39,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit6,targetm10,R6,L1,V1,R9,R0,s118,The recorded line of a form (mode :lines): :line metadata on lists, and on symbols and\n  vectors that begin a Go line.R3,i41,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit5,room?m10,R6,L1,V1,R10,R0,s92,Whether n more lines fit before *next* (always, when it is unknown or out of mode\n  :lines).R3,i49,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit8,keywordsS25,s4,elses4,funcs3,maps5,ranges4,chans7,packages9,interfaces5,defers3,vars6,returns3,fors11,fallthroughs2,ifs6,imports2,gos6,switchs5,consts6,selects4,cases5,breaks8,continues4,types6,structs7,defaults4,gotom6,R3,i58,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit11,semi-after?m12,R11,TR6,L1,V1,Myn1,sm2,R12,R13,R0,s67,Go's semicolon rule: a newline after this token ends the statement.R3,i63,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit12,may-combine?m12,R11,TR6,L1,V2,Myn4,prevm2,R12,R13,Myn4,nextm2,R12,R13,R0,s96,go/printer's mayCombine, extended: the two tokens would scan as other tokens unless\n  separated.R3,i74,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit11,start-line!m10,R11,TR6,L1,V0,R3,i90,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit3,tokm10,R6,L1,V1,Myn1,sm2,R12,R13,R0,s15,Writes a token.R3,i100,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit7,raw-tokm10,R6,L1,V1,Myn1,sm2,R12,R13,R0,s106,Writes a token that may span lines (a raw string): its line breaks count, and alignment\n  leaves it whole.R3,i117,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit2,spm10,R6,L1,V0,R0,s43,A blank before the next token on this line.R3,i125,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit4,vtabm10,R6,L1,V0,R0,s60,An alignment separator before the next token (gofmt's vtab).R3,i131,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit2,nlm10,R6,L2,V1,R14,V2,R14,R15,R0,s97,Ends the line; the next line is indented by indent. form-feed? ends the alignment\n  sections too.R3,i139,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit10,cur-indentm8,R6,L1,V0,R3,i152,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit10,push-open!m10,R6,L2,V0,V1,R14,R0,s119,Records an open bracket (or a statement) whose continuation lines indent one more than\n  indent (default: this line's).R3,i154,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit9,pop-open!m8,R6,L1,V0,R3,i160,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit11,cont-indentm10,R6,L1,V0,R0,s39,The indentation of a continuation line.R3,i165,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit12,comment-linem10,R6,L1,V2,Myn1,sm2,R12,R13,R14,R0,s141,Writes a whole-line comment (doc comment line, directive) at indent and ends the line.\n  //line directives start at column 1, as gc requires.R3,i171,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit9,set-line!m10,R6,L1,V1,R16,R0,s73,Sets the line of the cursor as gc will see it (after a //line directive).R3,i184,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit9,start-at!m10,R6,L1,V1,R16,R0,s66,Starts a chunk's state at line l (start of a line, indentation 0).R3,i204,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit11,chunk-statem10,R6,L1,V0,R0,s94,The state after a chunk was printed (in its own state, *p*): its text and its emitter\n  state.R3,i210,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit5,join!m10,R6,L1,V2,R17,R16,R0,s198,Appends the chunk c (chunk-state), printed from line l (start-at!), to *p* when *p*'s state\n  is where c's printing assumed it: true when joined, false when the chunk must be printed\n  again in *p*.R3,i220,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit21,line-directive-inlinem10,R6,L1,V1,R10,R0,s89,/*line :N:1*/ before the next token: gc puts it on line N (a column keeps the file name).R3,i242,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit18,line-directive-ownm10,R6,L1,V1,R10,R0,s81,//line :N:1 on a line of its own, at the start of a line: the line after it is N.R3,i252,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit6,renderm10,R6,L1,V1,R9,R0,s119,The text f (a function of no arguments that prints) writes on a fresh line, without\n  positions: go/printer's nodeSize.R3,i262,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit9,break-to!m10,R6,L1,V1,R18,R0,s142,Inside an expression, before a form recorded at line t (or :break, a new line): line\n  breaks where Go allows them, else a /*line*/ directive.R3,i271,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit11,stmt-break!m10,R6,L1,V4,R18,R19,R20,R14,R0,s298,Before a statement, a declaration or another element of a list whose elements may be\n  separated by a line break or by sep (\";\" or \",\"): moves to its line t (nil: unknown).\n  first? when it follows the opening bracket. indent is the element's indentation. Returns\n  true when a line break was made.R3,i292,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit12,close-break!m10,R6,L1,V4,R21,R22,R23,R14,R0,s277,Before a closing bracket: end, its recorded line (or nil); multiline?, whether the\n  construct already spans lines; always?, whether gofmt's layout puts it on a line of its\n  own. Returns true when the bracket goes on a new line (indented as the line of its\n  opening, indent).R3,i312,R4,i1,R5,s24,arbace/g2a/print_emit.aev21,arbace.g2a.print-emit6,resultm10,R6,L1,V0,R0,s26,The text written, aligned.R3,i328,R4,i1,R5,s24,arbace/g2a/print_emit.ae")

var Lit_16 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000004$loading__1927001464__auto____1256000005")

var Lit_17 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000008$fn__1256000009")

var Lit_18 *jrt.String = jrt.Intern("arbace.g2a.print_emit$new_state")

var Lit_19 *jrt.String = jrt.Intern("arbace.g2a.print_emit$lines_QMARK_")

var Lit_20 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000018$lines_QMARK___1256000019")

var Lit_21 *jrt.String = jrt.Intern("arbace.g2a.print_emit$line")

var Lit_22 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000029$line__1256000030")

var Lit_23 *jrt.String = jrt.Intern("arbace.g2a.print_emit$bol_QMARK_")

var Lit_24 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000040$bol_QMARK___1256000041")

var Lit_25 *jrt.String = jrt.Intern("arbace.g2a.print_emit$target")

var Lit_26 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000052$target__1256000053")

var Lit_27 *jrt.String = jrt.Intern("arbace.g2a.print_emit$room_QMARK_")

var Lit_28 *jrt.String = jrt.Intern("arbace.g2a.print_emit$semi_after_QMARK_")

var Lit_29 *jrt.String = jrt.Intern("arbace.g2a.print_emit$may_combine_QMARK_")

var Lit_30 *jrt.String = jrt.Intern("arbace.g2a.print_emit$start_line_BANG_")

var Lit_31 *jrt.String = jrt.Intern("arbace.g2a.print_emit$tok")

var Lit_32 *jrt.String = jrt.Intern("arbace.g2a.print_emit$raw_tok")

var Lit_33 *jrt.String = jrt.Intern("arbace.g2a.print_emit$sp")

var Lit_34 *jrt.String = jrt.Intern("arbace.g2a.print_emit$vtab")

var Lit_35 *jrt.String = jrt.Intern("arbace.g2a.print_emit$nl")

var Lit_36 *jrt.String = jrt.Intern("arbace.g2a.print_emit$cur_indent")

var Lit_37 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000075$cur_indent__1256000076")

var Lit_38 *jrt.String = jrt.Intern("arbace.g2a.print_emit$push_open_BANG_")

var Lit_39 *jrt.String = jrt.Intern("arbace.g2a.print_emit$pop_open_BANG_")

var Lit_40 *jrt.String = jrt.Intern("arbace.g2a.print_emit$cont_indent")

var Lit_41 *jrt.String = jrt.Intern("arbace.g2a.print_emit$comment_line")

var Lit_42 *jrt.String = jrt.Intern("arbace.g2a.print_emit$set_line_BANG_")

var Lit_43 *jrt.String = jrt.Intern("arbace.g2a.print_emit$start_at_BANG_")

var Lit_44 *jrt.String = jrt.Intern("arbace.g2a.print_emit$chunk_state")

var Lit_45 *jrt.String = jrt.Intern("arbace.g2a.print_emit$join_BANG_")

var Lit_46 *jrt.String = jrt.Intern("arbace.g2a.print_emit$line_directive_inline")

var Lit_47 *jrt.String = jrt.Intern("arbace.g2a.print_emit$line_directive_own")

var Lit_48 *jrt.String = jrt.Intern("arbace.g2a.print_emit$render")

var Lit_49 *jrt.String = jrt.Intern("arbace.g2a.print_emit$break_to_BANG_")

var Lit_50 *jrt.String = jrt.Intern("arbace.g2a.print_emit$stmt_break_BANG_")

var Lit_51 *jrt.String = jrt.Intern("arbace.g2a.print_emit$close_break_BANG_")

var Lit_52 *jrt.String = jrt.Intern("arbace.g2a.print_emit$result")
