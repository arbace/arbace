//line a2g_strings.ae:1
package aot_arbace_g2a_print_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.print-text")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("text")

var Lit_6 *jrt.String = jrt.Intern("arbace.string")

var Lit_7 *jrt.String = jrt.Intern("str")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.g2a.print-emit")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("The emitter of g2a's printer (doc/go/PRINTER-NOTES.md): writes Go tokens, tracks the\n  line, indentation and Go's semicolon rule, and places tokens on the lines the forms record\n  (doc/go/SPEC.md §10.1, §12.3).\n\n  The state is one map of volatiles bound to *p* while a file is printed. Text is written\n  with tabs for indentation and vertical tabs between aligned cells; print-text/align turns\n  it into gofmt's spacing at the end.")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("sb")

var Lit_16 *jrt.String = jrt.Intern("line")

var Lit_17 *jrt.String = jrt.Intern("volatile!")

var Lit_18 *jrt.String = jrt.Intern("bol")

var Lit_19 *jrt.String = jrt.Intern("indent")

var Lit_20 *jrt.String = jrt.Intern("cur-indent")

var Lit_21 *jrt.String = jrt.Intern("last")

var Lit_22 *jrt.String = jrt.Intern("semi")

var Lit_23 *jrt.String = jrt.Intern("ws")

var Lit_24 *jrt.String = jrt.Intern("opens")

var Lit_25 *jrt.String = jrt.Intern("mark")

var Lit_26 *jrt.String = jrt.Intern("min-line")

var Lit_27 *jrt.String = jrt.Intern("lines?")

var Lit_28 *jrt.String = jrt.Intern("directives?")

var Lit_29 *jrt.String = jrt.Intern("line-directives?")

var Lit_30 *jrt.String = jrt.Intern("*p*")

var Lit_31 *jrt.String = jrt.Intern("seq")

var Lit_32 *jrt.String = jrt.Intern("concat")

var Lit_33 *jrt.String = jrt.Intern("list")

var Lit_34 *jrt.String = jrt.Intern("integer?")

var Lit_35 *jrt.String = jrt.Intern("when")

var Lit_36 *jrt.String = jrt.Intern("let")

var Lit_37 *jrt.String = jrt.Intern("apply")

var Lit_38 *jrt.String = jrt.Intern("vector")

var Lit_39 *jrt.String = jrt.Intern("l__1256000046__auto__")

var Lit_40 *jrt.String = jrt.Intern("meta")

var Lit_41 *jrt.String = jrt.Intern("long")

var Lit_42 *jrt.String = jrt.Intern("not")

var Lit_43 *jrt.String = jrt.Intern("*next*")

var Lit_44 *jrt.String = jrt.Intern("keywords")

var Lit_45 *jrt.String = jrt.Intern("else")

var Lit_46 *jrt.String = jrt.Intern("re-matches")

var Lit_47 *jrt.String = jrt.Intern("[0-9]+")

var Lit_48 *jrt.String = jrt.Intern("vreset!")

var Lit_49 *jrt.String = jrt.Intern("start-line!")

var Lit_50 *jrt.String = jrt.Intern("may-combine?")

var Lit_51 *jrt.String = jrt.Intern("semi-after?")

var Lit_52 *jrt.String = jrt.Intern("tok")

var Lit_53 *jrt.String = jrt.Intern("filter")

var Lit_54 *jrt.String = jrt.Intern("escape")

var Lit_55 *jrt.String = jrt.Intern("nl")

var Lit_56 *jrt.String = jrt.Intern("push-open!")

var Lit_57 *jrt.String = jrt.Intern("peek")

var Lit_58 *jrt.String = jrt.Intern("pop")

var Lit_59 *jrt.String = jrt.Intern("starts-with?")

var Lit_60 *jrt.String = jrt.Intern("empty?")

var Lit_61 *jrt.String = jrt.Intern("set-line!")

var Lit_62 *jrt.String = jrt.Intern("comment-line")

var Lit_63 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_64 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_65 *jrt.String = jrt.Intern("hash-map")

var Lit_66 *jrt.String = jrt.Intern("new-state")

var Lit_67 *jrt.String = jrt.Intern("break")

var Lit_68 *jrt.String = jrt.Intern("line-directive-inline")

var Lit_69 *jrt.String = jrt.Intern("cont-indent")

var Lit_70 *jrt.String = jrt.Intern("sp")

var Lit_71 *jrt.String = jrt.Intern("room?")

var Lit_72 *jrt.String = jrt.Intern("line-directive-own")

var Lit_73 *jrt.String = jrt.Intern("replace")

var Lit_74 *jrt.String = jrt.Intern("align")

var Lit_75 *jrt.String = jrt.Intern("[ \\x0B]+\\n")

var Lit_76 *jrt.String = jrt.Intern("ends-with?")

var Lit_77 *jrt.String = jrt.Intern("arbace.g2a.print_emit$bol_QMARK_")

var Lit_78 *jrt.String = jrt.Intern("arbace.g2a.print_emit$break_to_BANG_")

var Lit_79 *jrt.String = jrt.Intern("arbace.g2a.print_emit$chunk_state")

var Lit_80 *jrt.String = jrt.Intern("arbace.g2a.print_emit$close_break_BANG_")

var Lit_81 *jrt.String = jrt.Intern("arbace.g2a.print_emit$comment_line")

var Lit_82 *jrt.String = jrt.Intern("//line ")

var Lit_83 *jrt.String = jrt.Intern("")

var Lit_84 *jrt.String = jrt.Intern("arbace.g2a.print_emit$cont_indent")

var Lit_85 *jrt.String = jrt.Intern("arbace.g2a.print_emit$cur_indent")

var Lit_86 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000004$loading__1927001464__auto____1256000005")

var Lit_87 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000008$fn__1256000009")

var Lit_88 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000018$lines_QMARK___1256000019")

var Lit_89 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000029$line__1256000030")

var Lit_90 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000040$bol_QMARK___1256000041")

var Lit_91 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000052$target__1256000053")

var Lit_92 *jrt.String = jrt.Intern("arbace.g2a.print_emit$eval1256000075$cur_indent__1256000076")

var Lit_93 *jrt.String = jrt.Intern("arbace.g2a.print_emit$join_BANG_")

var Lit_94 *jrt.String = jrt.Intern("arbace.g2a.print_emit$line")

var Lit_95 *jrt.String = jrt.Intern("arbace.g2a.print_emit$line_directive_inline")

var Lit_96 *jrt.String = jrt.Intern("/*line :")

var Lit_97 *jrt.String = jrt.Intern(":1*/")

var Lit_98 *jrt.String = jrt.Intern("arbace.g2a.print_emit$line_directive_own")

var Lit_99 *jrt.String = jrt.Intern("//line :")

var Lit_100 *jrt.String = jrt.Intern(":1")

var Lit_101 *jrt.String = jrt.Intern("arbace.g2a.print_emit$lines_QMARK_")

var Lit_102 *jrt.String = jrt.Intern("arbace.g2a.print_emit$may_combine_QMARK_")

var Lit_103 *jrt.String = jrt.Intern("+")

var Lit_104 *jrt.String = jrt.Intern("-")

var Lit_105 *jrt.String = jrt.Intern("<")

var Lit_106 *jrt.String = jrt.Intern("&")

var Lit_107 *jrt.String = jrt.Intern("arbace.g2a.print_emit$new_state")

var Lit_108 *jrt.String = jrt.Intern("arbace.g2a.print_emit$nl")

var Lit_109 *jrt.String = jrt.Intern("arbace.g2a.print_emit$pop_open_BANG_")

var Lit_110 *jrt.String = jrt.Intern("arbace.g2a.print_emit$push_open_BANG_")

var Lit_111 *jrt.String = jrt.Intern("arbace.g2a.print_emit$raw_tok")

var Lit_112 *jrt.String = jrt.Intern("arbace.g2a.print_emit$raw_tok$fn__1256000064")

var Lit_113 *jrt.String = jrt.Intern("arbace.g2a.print_emit$render")

var Lit_114 *jrt.String = jrt.Intern("arbace.g2a.print_emit$result")

var Lit_115 *jrt.String = jrt.Intern("\n")

var Lit_116 *jrt.String = jrt.Intern("arbace.g2a.print_emit$room_QMARK_")

var Lit_117 *jrt.String = jrt.Intern("arbace.g2a.print_emit$semi_after_QMARK_")

var Lit_118 *jrt.String = jrt.Intern("arbace.g2a.print_emit$set_line_BANG_")

var Lit_119 *jrt.String = jrt.Intern("arbace.g2a.print_emit$sp")

var Lit_120 *jrt.String = jrt.Intern("arbace.g2a.print_emit$start_at_BANG_")

var Lit_121 *jrt.String = jrt.Intern("arbace.g2a.print_emit$start_line_BANG_")

var Lit_122 *jrt.String = jrt.Intern("arbace.g2a.print_emit$stmt_break_BANG_")

var Lit_123 *jrt.String = jrt.Intern("arbace.g2a.print_emit$stmt_break_BANG_$newline_BANG___1256000093")

var Lit_124 *jrt.String = jrt.Intern("arbace.g2a.print_emit$stmt_break_BANG_$same_BANG___1256000095")

var Lit_125 *jrt.String = jrt.Intern("arbace.g2a.print_emit$target")

var Lit_126 *jrt.String = jrt.Intern("arbace.g2a.print_emit$tok")

var Lit_127 *jrt.String = jrt.Intern("arbace.g2a.print_emit$vtab")

var Lit_128 *jrt.String = jrt.Intern("in-ns")

var Lit_129 *jrt.String = jrt.Intern("dynamic")

var Lit_130 *jrt.String = jrt.Intern("column")

var Lit_131 *jrt.String = jrt.Intern("file")

var Lit_132 *jrt.String = jrt.Intern("arbace/g2a/print_emit.ae")

var Lit_133 *jrt.String = jrt.Intern("The line of what follows the construct being printed, when known: the room a closing\n  brace or a statement without a recorded line may take (mode :lines).")

var Lit_134 *jrt.String = jrt.Intern("arglists")

var Lit_135 *jrt.String = jrt.Intern("opts")

var Lit_136 *jrt.String = jrt.Intern("opts: :lines? (place forms on their recorded lines), :line-directives? (write //line or\n  /*line*/ directives where a recorded line cannot be reached by layout).")

var Lit_137 *jrt.String = jrt.Intern("alter-meta!")

var Lit_138 *jrt.String = jrt.Intern("assoc")

var Lit_139 *jrt.String = jrt.Intern("inline")

var Lit_140 *jrt.String = jrt.Intern("bol?")

var Lit_141 *jrt.String = jrt.Intern("target")

var Lit_142 *jrt.String = jrt.Intern("f")

var Lit_143 *jrt.String = jrt.Intern("The recorded line of a form (mode :lines): :line metadata on lists, and on symbols and\n  vectors that begin a Go line.")

var Lit_144 *jrt.String = jrt.Intern("n")

var Lit_145 *jrt.String = jrt.Intern("Whether n more lines fit before *next* (always, when it is unknown or out of mode\n  :lines).")

var Lit_146 *jrt.String = jrt.Intern("private")

var Lit_147 *jrt.String = jrt.Intern("s")

var Lit_148 *jrt.String = jrt.Intern("tag")

var Lit_149 *jrt.String = jrt.Intern("String")

var Lit_150 *jrt.String = jrt.Intern("Go's semicolon rule: a newline after this token ends the statement.")

var Lit_151 *jrt.String = jrt.Intern("prev")

var Lit_152 *jrt.String = jrt.Intern("next")

var Lit_153 *jrt.String = jrt.Intern("go/printer's mayCombine, extended: the two tokens would scan as other tokens unless\n  separated.")

var Lit_154 *jrt.String = jrt.Intern("Writes a token.")

var Lit_155 *jrt.String = jrt.Intern("raw-tok")

var Lit_156 *jrt.String = jrt.Intern("Writes a token that may span lines (a raw string): its line breaks count, and alignment\n  leaves it whole.")

var Lit_157 *jrt.String = jrt.Intern("A blank before the next token on this line.")

var Lit_158 *jrt.String = jrt.Intern("vtab")

var Lit_159 *jrt.String = jrt.Intern("An alignment separator before the next token (gofmt's vtab).")

var Lit_160 *jrt.String = jrt.Intern("form-feed?")

var Lit_161 *jrt.String = jrt.Intern("Ends the line; the next line is indented by indent. form-feed? ends the alignment\n  sections too.")

var Lit_162 *jrt.String = jrt.Intern("Records an open bracket (or a statement) whose continuation lines indent one more than\n  indent (default: this line's).")

var Lit_163 *jrt.String = jrt.Intern("pop-open!")

var Lit_164 *jrt.String = jrt.Intern("The indentation of a continuation line.")

var Lit_165 *jrt.String = jrt.Intern("Writes a whole-line comment (doc comment line, directive) at indent and ends the line.\n  //line directives start at column 1, as gc requires.")

var Lit_166 *jrt.String = jrt.Intern("l")

var Lit_167 *jrt.String = jrt.Intern("Sets the line of the cursor as gc will see it (after a //line directive).")

var Lit_168 *jrt.String = jrt.Intern("start-at!")

var Lit_169 *jrt.String = jrt.Intern("Starts a chunk's state at line l (start of a line, indentation 0).")

var Lit_170 *jrt.String = jrt.Intern("chunk-state")

var Lit_171 *jrt.String = jrt.Intern("The state after a chunk was printed (in its own state, *p*): its text and its emitter\n  state.")

var Lit_172 *jrt.String = jrt.Intern("join!")

var Lit_173 *jrt.String = jrt.Intern("c")

var Lit_174 *jrt.String = jrt.Intern("Appends the chunk c (chunk-state), printed from line l (start-at!), to *p* when *p*'s state\n  is where c's printing assumed it: true when joined, false when the chunk must be printed\n  again in *p*.")

var Lit_175 *jrt.String = jrt.Intern("/*line :N:1*/ before the next token: gc puts it on line N (a column keeps the file name).")

var Lit_176 *jrt.String = jrt.Intern("//line :N:1 on a line of its own, at the start of a line: the line after it is N.")

var Lit_177 *jrt.String = jrt.Intern("render")

var Lit_178 *jrt.String = jrt.Intern("The text f (a function of no arguments that prints) writes on a fresh line, without\n  positions: go/printer's nodeSize.")

var Lit_179 *jrt.String = jrt.Intern("break-to!")

var Lit_180 *jrt.String = jrt.Intern("t")

var Lit_181 *jrt.String = jrt.Intern("Inside an expression, before a form recorded at line t (or :break, a new line): line\n  breaks where Go allows them, else a /*line*/ directive.")

var Lit_182 *jrt.String = jrt.Intern("stmt-break!")

var Lit_183 *jrt.String = jrt.Intern("first?")

var Lit_184 *jrt.String = jrt.Intern("sep")

var Lit_185 *jrt.String = jrt.Intern("Before a statement, a declaration or another element of a list whose elements may be\n  separated by a line break or by sep (\";\" or \",\"): moves to its line t (nil: unknown).\n  first? when it follows the opening bracket. indent is the element's indentation. Returns\n  true when a line break was made.")

var Lit_186 *jrt.String = jrt.Intern("close-break!")

var Lit_187 *jrt.String = jrt.Intern("end")

var Lit_188 *jrt.String = jrt.Intern("multiline?")

var Lit_189 *jrt.String = jrt.Intern("always?")

var Lit_190 *jrt.String = jrt.Intern("Before a closing bracket: end, its recorded line (or nil); multiline?, whether the\n  construct already spans lines; always?, whether gofmt's layout puts it on a line of its\n  own. Returns true when the bracket goes on a new line (indented as the line of its\n  opening, indent).")

var Lit_191 *jrt.String = jrt.Intern("result")

var Lit_192 *jrt.String = jrt.Intern("The text written, aligned.")
