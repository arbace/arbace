//line aot_arbace_g2a_print_emit__init.ae:1
package aot_arbace_g2a_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_emit__init_A_Unit0__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_print_emit__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit__init_A_const_1) }
//line :1:1
func A_arbace_g2a_print_emit__init_A_Unit1__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_print_emit__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_print_emit__init_A_Unit2__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_Init(); tmp2 = A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_print_emit__init_A_Unit3__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_print_emit__init_A_const_1)).Equals_O__Z(A_arbace_g2a_print_emit__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_Init(); tmp2 = A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_print_emit__init_A_Load__O() any { A_arbace_g2a_print_emit__init_A_Init(); A_arbace_g2a_print_emit__init_A_Unit0__O(); A_arbace_g2a_print_emit__init_A_Unit1__O(); A_arbace_g2a_print_emit__init_A_Unit2__O(); A_arbace_g2a_print_emit__init_A_Unit3__O(); A_arbace_g2a_print_emit__init_A_Unit4__O(); A_arbace_g2a_print_emit__init_A_Unit5__O(); A_arbace_g2a_print_emit__init_A_Unit6__O(); A_arbace_g2a_print_emit__init_A_Unit7__O(); A_arbace_g2a_print_emit__init_A_Unit8__O(); A_arbace_g2a_print_emit__init_A_Unit9__O(); A_arbace_g2a_print_emit__init_A_Unit10__O(); A_arbace_g2a_print_emit__init_A_Unit11__O(); A_arbace_g2a_print_emit__init_A_Unit12__O(); A_arbace_g2a_print_emit__init_A_Unit13__O(); A_arbace_g2a_print_emit__init_A_Unit14__O(); A_arbace_g2a_print_emit__init_A_Unit15__O(); A_arbace_g2a_print_emit__init_A_Unit16__O(); A_arbace_g2a_print_emit__init_A_Unit17__O(); A_arbace_g2a_print_emit__init_A_Unit18__O(); A_arbace_g2a_print_emit__init_A_Unit19__O(); A_arbace_g2a_print_emit__init_A_Unit20__O(); A_arbace_g2a_print_emit__init_A_Unit21__O(); A_arbace_g2a_print_emit__init_A_Unit22__O(); A_arbace_g2a_print_emit__init_A_Unit23__O(); A_arbace_g2a_print_emit__init_A_Unit24__O(); A_arbace_g2a_print_emit__init_A_Unit25__O(); A_arbace_g2a_print_emit__init_A_Unit26__O(); A_arbace_g2a_print_emit__init_A_Unit27__O(); A_arbace_g2a_print_emit__init_A_Unit28__O(); A_arbace_g2a_print_emit__init_A_Unit29__O(); A_arbace_g2a_print_emit__init_A_Unit30__O(); A_arbace_g2a_print_emit__init_A_Unit31__O(); A_arbace_g2a_print_emit__init_A_Unit32__O(); A_arbace_g2a_print_emit__init_A_Unit33__O(); A_arbace_g2a_print_emit__init_A_Unit34__O(); A_arbace_g2a_print_emit__init_A_Unit35__O(); A_arbace_g2a_print_emit__init_A_Unit36__O(); A_arbace_g2a_print_emit__init_A_Unit37__O(); A_arbace_g2a_print_emit__init_A_Unit38__O(); A_arbace_g2a_print_emit__init_A_Unit39__O(); A_arbace_g2a_print_emit__init_A_Unit40__O(); A_arbace_g2a_print_emit__init_A_Unit41__O(); A_arbace_g2a_print_emit__init_A_Unit42__O(); A_arbace_g2a_print_emit__init_A_Unit43__O(); A_arbace_g2a_print_emit__init_A_Unit44__O(); A_arbace_g2a_print_emit__init_A_Unit45__O(); A_arbace_g2a_print_emit__init_A_Unit46__O(); return nil }






func A_arbace_g2a_print_emit__init_A_Unit4__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); jrt.NN(A_arbace_g2a_print_emit__init_A_const_4).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_5)); return jrt.NN(A_arbace_g2a_print_emit__init_A_const_4).SetDynamic_Z__Var(true).Ref() }

func A_arbace_g2a_print_emit__init_A_Unit5__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); jrt.NN(A_arbace_g2a_print_emit__init_A_const_6).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_7)); return jrt.NN(A_arbace_g2a_print_emit__init_A_const_6).SetDynamic_Z__Var(true).Ref() }




func A_arbace_g2a_print_emit__init_A_Unit6__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_8; var tmp2 any = A_arbace_g2a_print_emit_new_state_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_new_state_A_Init(); tmp3 = A_arbace_g2a_print_emit_new_state_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_9)); return A_arbace_g2a_print_emit__init_A_const_8.Ref() }

















func A_arbace_g2a_print_emit__init_A_Unit7__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_10; var tmp2 any = A_arbace_g2a_print_emit_lines_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_lines_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_emit_lines_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_11)); return A_arbace_g2a_print_emit__init_A_const_10.Ref() }
//line :37:1
func A_arbace_g2a_print_emit__init_A_Unit8__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_g2a_print_emit__init_A_const_12).GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_emit__init_A_const_10.Ref(); var tmp3 any = jrt.NN(A_arbace_g2a_print_emit__init_A_const_13).GetRawRoot__O(); var tmp4 any = A_arbace_g2a_print_emit__init_A_const_14.Ref(); var tmp5 any = A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_New(); var tmp6 *jrt.Class; A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_Init(); tmp6 = A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_fn_class; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :37:1
func A_arbace_g2a_print_emit__init_A_Unit9__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); return A_arbace_g2a_print_emit__init_A_const_10.Ref() }
func A_arbace_g2a_print_emit__init_A_Unit10__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_15; var tmp2 any = A_arbace_g2a_print_emit_line_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_line_A_Init(); tmp3 = A_arbace_g2a_print_emit_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_16)); return A_arbace_g2a_print_emit__init_A_const_15.Ref() }
//line :38:1
func A_arbace_g2a_print_emit__init_A_Unit11__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_g2a_print_emit__init_A_const_12).GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_emit__init_A_const_15.Ref(); var tmp3 any = jrt.NN(A_arbace_g2a_print_emit__init_A_const_13).GetRawRoot__O(); var tmp4 any = A_arbace_g2a_print_emit__init_A_const_14.Ref(); var tmp5 any = A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_New(); var tmp6 *jrt.Class; A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_Init(); tmp6 = A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_fn_class; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :38:1
func A_arbace_g2a_print_emit__init_A_Unit12__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); return A_arbace_g2a_print_emit__init_A_const_15.Ref() }
func A_arbace_g2a_print_emit__init_A_Unit13__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_17; var tmp2 any = A_arbace_g2a_print_emit_bol_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_bol_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_emit_bol_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_18)); return A_arbace_g2a_print_emit__init_A_const_17.Ref() }
//line :39:1
func A_arbace_g2a_print_emit__init_A_Unit14__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_g2a_print_emit__init_A_const_12).GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_emit__init_A_const_17.Ref(); var tmp3 any = jrt.NN(A_arbace_g2a_print_emit__init_A_const_13).GetRawRoot__O(); var tmp4 any = A_arbace_g2a_print_emit__init_A_const_14.Ref(); var tmp5 any = A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_New(); var tmp6 *jrt.Class; A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_Init(); tmp6 = A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_fn_class; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :39:1
func A_arbace_g2a_print_emit__init_A_Unit15__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); return A_arbace_g2a_print_emit__init_A_const_17.Ref() }

func A_arbace_g2a_print_emit__init_A_Unit16__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_19; var tmp2 any = A_arbace_g2a_print_emit_target_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_target_A_Init(); tmp3 = A_arbace_g2a_print_emit_target_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_20)); return A_arbace_g2a_print_emit__init_A_const_19.Ref() }
//line :41:1
func A_arbace_g2a_print_emit__init_A_Unit17__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_g2a_print_emit__init_A_const_12).GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_emit__init_A_const_19.Ref(); var tmp3 any = jrt.NN(A_arbace_g2a_print_emit__init_A_const_13).GetRawRoot__O(); var tmp4 any = A_arbace_g2a_print_emit__init_A_const_14.Ref(); var tmp5 any = A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_New(); var tmp6 *jrt.Class; A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_Init(); tmp6 = A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_fn_class; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :41:1
func A_arbace_g2a_print_emit__init_A_Unit18__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); return A_arbace_g2a_print_emit__init_A_const_19.Ref() }







func A_arbace_g2a_print_emit__init_A_Unit19__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_21; var tmp2 any = A_arbace_g2a_print_emit_room_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_room_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_emit_room_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_22)); return A_arbace_g2a_print_emit__init_A_const_21.Ref() }








func A_arbace_g2a_print_emit__init_A_Unit20__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); jrt.NN(A_arbace_g2a_print_emit__init_A_const_23).BindRoot_O__V(A_arbace_g2a_print_emit__init_A_const_24); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_23; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_25)); return A_arbace_g2a_print_emit__init_A_const_23.Ref() }




func A_arbace_g2a_print_emit__init_A_Unit21__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_26; var tmp2 any = A_arbace_g2a_print_emit_semi_after_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_semi_after_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_emit_semi_after_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_27)); return A_arbace_g2a_print_emit__init_A_const_26.Ref() }










func A_arbace_g2a_print_emit__init_A_Unit22__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_28; var tmp2 any = A_arbace_g2a_print_emit_may_combine_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_may_combine_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_emit_may_combine_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_29)); return A_arbace_g2a_print_emit__init_A_const_28.Ref() }















func A_arbace_g2a_print_emit__init_A_Unit23__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(90, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_30; var tmp2 any = A_arbace_g2a_print_emit_start_line_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_start_line_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_start_line_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_31)); return A_arbace_g2a_print_emit__init_A_const_30.Ref() }









func A_arbace_g2a_print_emit__init_A_Unit24__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_32; var tmp2 any = A_arbace_g2a_print_emit_tok_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_tok_A_Init(); tmp3 = A_arbace_g2a_print_emit_tok_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_33)); return A_arbace_g2a_print_emit__init_A_const_32.Ref() }
















func A_arbace_g2a_print_emit__init_A_Unit25__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(117, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_34; var tmp2 any = A_arbace_g2a_print_emit_raw_tok_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_raw_tok_A_Init(); tmp3 = A_arbace_g2a_print_emit_raw_tok_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_35)); return A_arbace_g2a_print_emit__init_A_const_34.Ref() }







func A_arbace_g2a_print_emit__init_A_Unit26__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_36; var tmp2 any = A_arbace_g2a_print_emit_sp_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_sp_A_Init(); tmp3 = A_arbace_g2a_print_emit_sp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_37)); return A_arbace_g2a_print_emit__init_A_const_36.Ref() }





func A_arbace_g2a_print_emit__init_A_Unit27__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_38; var tmp2 any = A_arbace_g2a_print_emit_vtab_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_vtab_A_Init(); tmp3 = A_arbace_g2a_print_emit_vtab_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_39)); return A_arbace_g2a_print_emit__init_A_const_38.Ref() }







func A_arbace_g2a_print_emit__init_A_Unit28__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(139, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_40; var tmp2 any = A_arbace_g2a_print_emit_nl_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_nl_A_Init(); tmp3 = A_arbace_g2a_print_emit_nl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_41)); return A_arbace_g2a_print_emit__init_A_const_40.Ref() }












func A_arbace_g2a_print_emit__init_A_Unit29__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_42; var tmp2 any = A_arbace_g2a_print_emit_cur_indent_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_cur_indent_A_Init(); tmp3 = A_arbace_g2a_print_emit_cur_indent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_43)); return A_arbace_g2a_print_emit__init_A_const_42.Ref() }
//line :152:1
func A_arbace_g2a_print_emit__init_A_Unit30__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_g2a_print_emit__init_A_const_12).GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_emit__init_A_const_42.Ref(); var tmp3 any = jrt.NN(A_arbace_g2a_print_emit__init_A_const_13).GetRawRoot__O(); var tmp4 any = A_arbace_g2a_print_emit__init_A_const_14.Ref(); var tmp5 any = A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_New(); var tmp6 *jrt.Class; A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_Init(); tmp6 = A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_fn_class; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :152:1
func A_arbace_g2a_print_emit__init_A_Unit31__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); return A_arbace_g2a_print_emit__init_A_const_42.Ref() }

func A_arbace_g2a_print_emit__init_A_Unit32__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_44; var tmp2 any = A_arbace_g2a_print_emit_push_open_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_push_open_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_push_open_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_45)); return A_arbace_g2a_print_emit__init_A_const_44.Ref() }





func A_arbace_g2a_print_emit__init_A_Unit33__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_46; var tmp2 any = A_arbace_g2a_print_emit_pop_open_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_pop_open_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_pop_open_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_47)); return A_arbace_g2a_print_emit__init_A_const_46.Ref() }




func A_arbace_g2a_print_emit__init_A_Unit34__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_48; var tmp2 any = A_arbace_g2a_print_emit_cont_indent_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_cont_indent_A_Init(); tmp3 = A_arbace_g2a_print_emit_cont_indent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_49)); return A_arbace_g2a_print_emit__init_A_const_48.Ref() }





func A_arbace_g2a_print_emit__init_A_Unit35__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(171, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_50; var tmp2 any = A_arbace_g2a_print_emit_comment_line_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_comment_line_A_Init(); tmp3 = A_arbace_g2a_print_emit_comment_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_51)); return A_arbace_g2a_print_emit__init_A_const_50.Ref() }












func A_arbace_g2a_print_emit__init_A_Unit36__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(184, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_52; var tmp2 any = A_arbace_g2a_print_emit_set_line_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_set_line_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_set_line_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_53)); return A_arbace_g2a_print_emit__init_A_const_52.Ref() }



















func A_arbace_g2a_print_emit__init_A_Unit37__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(204, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_54; var tmp2 any = A_arbace_g2a_print_emit_start_at_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_start_at_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_start_at_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_55)); return A_arbace_g2a_print_emit__init_A_const_54.Ref() }





func A_arbace_g2a_print_emit__init_A_Unit38__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(210, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_56; var tmp2 any = A_arbace_g2a_print_emit_chunk_state_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_chunk_state_A_Init(); tmp3 = A_arbace_g2a_print_emit_chunk_state_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_57)); return A_arbace_g2a_print_emit__init_A_const_56.Ref() }









func A_arbace_g2a_print_emit__init_A_Unit39__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(220, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_58; var tmp2 any = A_arbace_g2a_print_emit_join_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_join_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_join_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_59)); return A_arbace_g2a_print_emit__init_A_const_58.Ref() }





















func A_arbace_g2a_print_emit__init_A_Unit40__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(242, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_60; var tmp2 any = A_arbace_g2a_print_emit_line_directive_inline_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_line_directive_inline_A_Init(); tmp3 = A_arbace_g2a_print_emit_line_directive_inline_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_61)); return A_arbace_g2a_print_emit__init_A_const_60.Ref() }









func A_arbace_g2a_print_emit__init_A_Unit41__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(252, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_62; var tmp2 any = A_arbace_g2a_print_emit_line_directive_own_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_line_directive_own_A_Init(); tmp3 = A_arbace_g2a_print_emit_line_directive_own_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_63)); return A_arbace_g2a_print_emit__init_A_const_62.Ref() }









func A_arbace_g2a_print_emit__init_A_Unit42__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(262, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_64; var tmp2 any = A_arbace_g2a_print_emit_render_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_render_A_Init(); tmp3 = A_arbace_g2a_print_emit_render_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_65)); return A_arbace_g2a_print_emit__init_A_const_64.Ref() }








func A_arbace_g2a_print_emit__init_A_Unit43__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(271, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_66; var tmp2 any = A_arbace_g2a_print_emit_break_to_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_break_to_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_break_to_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_67)); return A_arbace_g2a_print_emit__init_A_const_66.Ref() }




















func A_arbace_g2a_print_emit__init_A_Unit44__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(292, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_68; var tmp2 any = A_arbace_g2a_print_emit_stmt_break_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_stmt_break_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_stmt_break_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_69)); return A_arbace_g2a_print_emit__init_A_const_68.Ref() }



















func A_arbace_g2a_print_emit__init_A_Unit45__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(312, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_70; var tmp2 any = A_arbace_g2a_print_emit_close_break_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_close_break_BANG__A_Init(); tmp3 = A_arbace_g2a_print_emit_close_break_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_71)); return A_arbace_g2a_print_emit__init_A_const_70.Ref() }















func A_arbace_g2a_print_emit__init_A_Unit46__O() any { A_arbace_g2a_print_emit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(328, 1); var tmp1 *lang.Var = A_arbace_g2a_print_emit__init_A_const_72; var tmp2 any = A_arbace_g2a_print_emit_result_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_emit_result_A_Init(); tmp3 = A_arbace_g2a_print_emit_result_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_emit__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_emit__init_A_const_73)); return A_arbace_g2a_print_emit__init_A_const_72.Ref() }



type A_arbace_g2a_print_emit__init_A struct{ jrt.Object }

var A_arbace_g2a_print_emit__init_A_const_0 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_1 any

var A_arbace_g2a_print_emit__init_A_const_2 any

var A_arbace_g2a_print_emit__init_A_const_3 any

var A_arbace_g2a_print_emit__init_A_const_4 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_5 any

var A_arbace_g2a_print_emit__init_A_const_6 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_7 any

var A_arbace_g2a_print_emit__init_A_const_8 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_9 any

var A_arbace_g2a_print_emit__init_A_const_10 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_11 any

var A_arbace_g2a_print_emit__init_A_const_12 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_13 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_14 *lang.Keyword

var A_arbace_g2a_print_emit__init_A_const_15 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_16 any

var A_arbace_g2a_print_emit__init_A_const_17 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_18 any

var A_arbace_g2a_print_emit__init_A_const_19 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_20 any

var A_arbace_g2a_print_emit__init_A_const_21 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_22 any

var A_arbace_g2a_print_emit__init_A_const_23 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_24 any

var A_arbace_g2a_print_emit__init_A_const_25 any

var A_arbace_g2a_print_emit__init_A_const_26 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_27 any

var A_arbace_g2a_print_emit__init_A_const_28 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_29 any

var A_arbace_g2a_print_emit__init_A_const_30 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_31 any

var A_arbace_g2a_print_emit__init_A_const_32 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_33 any

var A_arbace_g2a_print_emit__init_A_const_34 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_35 any

var A_arbace_g2a_print_emit__init_A_const_36 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_37 any

var A_arbace_g2a_print_emit__init_A_const_38 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_39 any

var A_arbace_g2a_print_emit__init_A_const_40 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_41 any

var A_arbace_g2a_print_emit__init_A_const_42 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_43 any

var A_arbace_g2a_print_emit__init_A_const_44 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_45 any

var A_arbace_g2a_print_emit__init_A_const_46 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_47 any

var A_arbace_g2a_print_emit__init_A_const_48 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_49 any

var A_arbace_g2a_print_emit__init_A_const_50 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_51 any

var A_arbace_g2a_print_emit__init_A_const_52 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_53 any

var A_arbace_g2a_print_emit__init_A_const_54 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_55 any

var A_arbace_g2a_print_emit__init_A_const_56 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_57 any

var A_arbace_g2a_print_emit__init_A_const_58 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_59 any

var A_arbace_g2a_print_emit__init_A_const_60 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_61 any

var A_arbace_g2a_print_emit__init_A_const_62 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_63 any

var A_arbace_g2a_print_emit__init_A_const_64 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_65 any

var A_arbace_g2a_print_emit__init_A_const_66 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_67 any

var A_arbace_g2a_print_emit__init_A_const_68 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_69 any

var A_arbace_g2a_print_emit__init_A_const_70 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_71 any

var A_arbace_g2a_print_emit__init_A_const_72 *lang.Var

var A_arbace_g2a_print_emit__init_A_const_73 any

var A_arbace_g2a_print_emit__init_A_init jrt.ClassInit

func A_arbace_g2a_print_emit__init_A_Init() { if !A_arbace_g2a_print_emit__init_A_init.Done() { A_arbace_g2a_print_emit__init_A_init.Run(A_arbace_g2a_print_emit__init_A_clinit) } }

func A_arbace_g2a_print_emit__init_A_clinit() { A_arbace_g2a_print_emit__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_128); A_arbace_g2a_print_emit__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_g2a_print_emit__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_g2a_print_emit__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_print_emit__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_30); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_print_emit__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_g2a_print_emit__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_133)); A_arbace_g2a_print_emit__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_11, Lit_66); A_arbace_g2a_print_emit__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_136, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_27); A_arbace_g2a_print_emit__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_g2a_print_emit__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_138); A_arbace_g2a_print_emit__init_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_139); A_arbace_g2a_print_emit__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_11, Lit_16); A_arbace_g2a_print_emit__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_11, Lit_140); A_arbace_g2a_print_emit__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_11, Lit_141); A_arbace_g2a_print_emit__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_143, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_11, Lit_71); A_arbace_g2a_print_emit__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_145, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_11, Lit_44); A_arbace_g2a_print_emit__init_A_const_24 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,25,s4:elses4:funcs3:maps5:ranges4:chans7:packages9:interfaces5:defers3:vars6:returns3:fors11:fallthroughs2:ifs6:imports2:gos6:switchs5:consts6:selects4:cases5:breaks8:continues4:types6:structs7:defaults4:goto", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_g2a_print_emit__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_11, Lit_51); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_g2a_print_emit__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_147)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_150, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_11, Lit_50); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_g2a_print_emit__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_152)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_153, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(74).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_49); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_g2a_print_emit__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(90).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_11, Lit_52); A_arbace_g2a_print_emit__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_147)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_154, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_11, Lit_155); A_arbace_g2a_print_emit__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_147)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_156, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(117).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); A_arbace_g2a_print_emit__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_157, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(125).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_11, Lit_158); A_arbace_g2a_print_emit__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_159, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(131).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_11, Lit_55); A_arbace_g2a_print_emit__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_161, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(139).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); A_arbace_g2a_print_emit__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(152).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_11, Lit_56); A_arbace_g2a_print_emit__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_162, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(154).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_11, Lit_163); A_arbace_g2a_print_emit__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(160).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_11, Lit_69); A_arbace_g2a_print_emit__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_164, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(165).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_11, Lit_62); A_arbace_g2a_print_emit__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_147)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_165, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(171).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_11, Lit_61); A_arbace_g2a_print_emit__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_167, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(184).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_11, Lit_168); A_arbace_g2a_print_emit__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_169, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(204).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_11, Lit_170); A_arbace_g2a_print_emit__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_171, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(210).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_11, Lit_172); A_arbace_g2a_print_emit__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_173).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_166).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_174, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(220).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_11, Lit_68); A_arbace_g2a_print_emit__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_175, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(242).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_11, Lit_72); A_arbace_g2a_print_emit__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_176, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(252).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_11, Lit_177); A_arbace_g2a_print_emit__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_178, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(262).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_11, Lit_179); A_arbace_g2a_print_emit__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_180).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_181, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(271).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_11, Lit_182); A_arbace_g2a_print_emit__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_180).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_184).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_185, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(292).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_11, Lit_186); A_arbace_g2a_print_emit__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_188).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_190, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(312).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)); A_arbace_g2a_print_emit__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_11, Lit_191); A_arbace_g2a_print_emit__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_192, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), jrt.Integer_ValueOf_I__Integer(328).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(), Lit_132)) }

func A_arbace_g2a_print_emit__init_A_New() *A_arbace_g2a_print_emit__init_A { A_arbace_g2a_print_emit__init_A_Init(); t := &A_arbace_g2a_print_emit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit__init_A) Ctor() {}

func (t *A_arbace_g2a_print_emit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit__init_A_class }

func (t *A_arbace_g2a_print_emit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit__init_A); return ok }

func A_arbace_g2a_print_emit__init_A_Cast(x any) *A_arbace_g2a_print_emit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit__init_A_class)) }; return v }
