//line aot_arbace_g2a_print_emit.ae:1
package aot_arbace_g2a_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_New() *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A { A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_4; tmp3 = tmp8.Invoke_O_O__O(tmp10, tmp11) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :1:1
func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_New() *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A { A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }

















func A_arbace_g2a_print_emit_new_state_A_New() *A_arbace_g2a_print_emit_new_state_A { A_arbace_g2a_print_emit_new_state_A_Init(); t := &A_arbace_g2a_print_emit_new_state_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_g2a_print_emit_new_state_A) Ctor() {}
//line :19:1
func (t *A_arbace_g2a_print_emit_new_state_A) Invoke_O_O__O(self, opts__0 any) any { var tmp1 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_10; var tmp2 any = tmp1.Ref(); var tmp3 any = jrt.StringBuilder_New(); var tmp4 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_11; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_12; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_25; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_13; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_12; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp13.Invoke_O__O(tmp14.Ref()); var tmp16 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_14; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_12; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_26; var tmp21 any = tmp19.Invoke_O__O(tmp20); var tmp22 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp22 = A_arbace_g2a_print_emit_A_const_15; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp24 = A_arbace_g2a_print_emit_A_const_12; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any; A_arbace_g2a_print_emit_A_Init(); tmp26 = A_arbace_g2a_print_emit_A_const_26; var tmp27 any = tmp25.Invoke_O__O(tmp26); var tmp28 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp28 = A_arbace_g2a_print_emit_A_const_16; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp30 = A_arbace_g2a_print_emit_A_const_12; var tmp31 any = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(Lit_83); var tmp32 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp32 = A_arbace_g2a_print_emit_A_const_17; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp34 = A_arbace_g2a_print_emit_A_const_12; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *jrt.Boolean; jrt.Boolean_Init(); tmp36 = jrt.Boolean_FALSE; var tmp37 any = tmp35.Invoke_O__O(tmp36.Ref()); var tmp38 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp38 = A_arbace_g2a_print_emit_A_const_18; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp40 = A_arbace_g2a_print_emit_A_const_12; var tmp41 any = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(nil); var tmp42 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp42 = A_arbace_g2a_print_emit_A_const_19; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp44 = A_arbace_g2a_print_emit_A_const_12; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.PersistentVector; lang.PersistentVector_Init(); tmp46 = lang.PersistentVector_EMPTY; var tmp47 any = tmp45.Invoke_O__O(tmp46.Ref()); var tmp48 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp48 = A_arbace_g2a_print_emit_A_const_20; var tmp49 any = tmp48.Ref(); var tmp50 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp50 = A_arbace_g2a_print_emit_A_const_12; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any; A_arbace_g2a_print_emit_A_Init(); tmp52 = A_arbace_g2a_print_emit_A_const_26; var tmp53 any = tmp51.Invoke_O__O(tmp52); var tmp54 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp54 = A_arbace_g2a_print_emit_A_const_21; var tmp55 any = tmp54.Ref(); var tmp56 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp56 = A_arbace_g2a_print_emit_A_const_12; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 any; A_arbace_g2a_print_emit_A_Init(); tmp58 = A_arbace_g2a_print_emit_A_const_25; var tmp59 any = tmp57.Invoke_O__O(tmp58); var tmp60 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp60 = A_arbace_g2a_print_emit_A_const_22; var tmp61 any = tmp60.Ref(); var tmp62 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp62 = A_arbace_g2a_print_emit_A_const_22; var tmp63 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp62).Invoke_O__O(opts__0))).Ref(); var tmp64 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp64 = A_arbace_g2a_print_emit_A_const_23; var tmp65 any = tmp64.Ref(); var tmp66 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp66 = A_arbace_g2a_print_emit_A_const_24; var tmp67 lang.IFn = Up_Keyword_IFn(tmp66); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp5, tmp9, tmp11, tmp15, tmp17, tmp21, tmp23, tmp27, tmp29, tmp31, tmp33, tmp37, tmp39, tmp41, tmp43, tmp47, tmp49, tmp53, tmp55, tmp59, tmp61, tmp63, tmp65, tmp67.Invoke_O_O__O(opts__0, tmp68.Ref()))) }

















func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_New() *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A { A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) Ctor() {}
//line :37:1
func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_29; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_30; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_22; var tmp8 any = tmp6.Invoke_O__O(tmp7.Ref()); var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_31; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp11))) }
//line :37:1
func A_arbace_g2a_print_emit_lines_QMARK__A_New() *A_arbace_g2a_print_emit_lines_QMARK__A { A_arbace_g2a_print_emit_lines_QMARK__A_Init(); t := &A_arbace_g2a_print_emit_lines_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_g2a_print_emit_lines_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_g2a_print_emit_lines_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_22; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_27; return jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()) }
func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_New() *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A { A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) Ctor() {}
//line :38:1
func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_29; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_30; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_32; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_28; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_29; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_30; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_11; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_30; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_33; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, tmp20.Invoke_O__O(tmp21)))))) }
//line :38:1
func A_arbace_g2a_print_emit_line_A_New() *A_arbace_g2a_print_emit_line_A { A_arbace_g2a_print_emit_line_A_Init(); t := &A_arbace_g2a_print_emit_line_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_g2a_print_emit_line_A) Ctor() {}
//line :38:1
func (t *A_arbace_g2a_print_emit_line_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_11; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; return tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O())) }
func A_arbace_g2a_print_emit_bol_QMARK__A_New() *A_arbace_g2a_print_emit_bol_QMARK__A { A_arbace_g2a_print_emit_bol_QMARK__A_Init(); t := &A_arbace_g2a_print_emit_bol_QMARK__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_g2a_print_emit_bol_QMARK__A) Ctor() {}
//line :39:1
func (t *A_arbace_g2a_print_emit_bol_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_13; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; return tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O())) }
//line :39:1
func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_New() *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A { A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) Ctor() {}
//line :39:1
func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_29; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_30; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_32; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_28; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_29; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_30; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_13; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_30; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_34; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, tmp20.Invoke_O__O(tmp21)))))) }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_New() *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A { A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) Ctor() {}
//line :41:1
func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_29; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_30; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_36; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_28; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_29; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_30; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_37; var tmp18 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O__O(tmp16.Invoke_O__O(tmp17)))); var tmp19 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_30; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_28; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp23 = A_arbace_g2a_print_emit_A_const_29; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp25 = A_arbace_g2a_print_emit_A_const_30; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_g2a_print_emit_A_Init(); tmp27 = A_arbace_g2a_print_emit_A_const_38; var tmp28 any = tmp26.Invoke_O__O(tmp27); var tmp29 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp29 = A_arbace_g2a_print_emit_A_const_30; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp31 = A_arbace_g2a_print_emit_A_const_39; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp33 = A_arbace_g2a_print_emit_A_const_40; var tmp34 any = jrt.NN(tmp33).GetRawRoot__O(); var tmp35 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp35 = A_arbace_g2a_print_emit_A_const_28; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp37 = A_arbace_g2a_print_emit_A_const_29; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp39 = A_arbace_g2a_print_emit_A_const_30; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; A_arbace_g2a_print_emit_A_Init(); tmp41 = A_arbace_g2a_print_emit_A_const_41; var tmp42 any = tmp40.Invoke_O__O(tmp41); var tmp43 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp43 = A_arbace_g2a_print_emit_A_const_30; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp45 = A_arbace_g2a_print_emit_A_const_28; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp47 = A_arbace_g2a_print_emit_A_const_29; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp49 = A_arbace_g2a_print_emit_A_const_30; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp51 = A_arbace_g2a_print_emit_A_const_11; var tmp52 any = tmp50.Invoke_O__O(tmp51.Ref()); var tmp53 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp53 = A_arbace_g2a_print_emit_A_const_30; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp55 = A_arbace_g2a_print_emit_A_const_28; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp57 = A_arbace_g2a_print_emit_A_const_29; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp59 = A_arbace_g2a_print_emit_A_const_30; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_g2a_print_emit_A_Init(); tmp61 = A_arbace_g2a_print_emit_A_const_42; var tmp62 any = tmp60.Invoke_O__O(tmp61); var tmp63 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp63 = A_arbace_g2a_print_emit_A_const_30; var tmp64 any = tmp30.Invoke_O__O(tmp32.Invoke_O_O__O(tmp34, tmp36.Invoke_O__O(tmp38.Invoke_O_O__O(tmp42, tmp44.Invoke_O__O(tmp46.Invoke_O__O(tmp48.Invoke_O_O__O(tmp52, tmp54.Invoke_O__O(tmp56.Invoke_O__O(tmp58.Invoke_O_O__O(tmp62, lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(f__1))))))))))); var tmp65 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp65 = A_arbace_g2a_print_emit_A_const_30; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp67 = A_arbace_g2a_print_emit_A_const_28; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp69 = A_arbace_g2a_print_emit_A_const_29; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp71 = A_arbace_g2a_print_emit_A_const_30; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 any; A_arbace_g2a_print_emit_A_Init(); tmp73 = A_arbace_g2a_print_emit_A_const_43; var tmp74 any = tmp72.Invoke_O__O(tmp73); var tmp75 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp75 = A_arbace_g2a_print_emit_A_const_30; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp77 = A_arbace_g2a_print_emit_A_const_28; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp79 = A_arbace_g2a_print_emit_A_const_29; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp81 = A_arbace_g2a_print_emit_A_const_30; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 any; A_arbace_g2a_print_emit_A_Init(); tmp83 = A_arbace_g2a_print_emit_A_const_44; var tmp84 any = tmp82.Invoke_O__O(tmp83); var tmp85 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp85 = A_arbace_g2a_print_emit_A_const_30; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 any; A_arbace_g2a_print_emit_A_Init(); tmp87 = A_arbace_g2a_print_emit_A_const_41; var tmp88 any = tmp76.Invoke_O__O(tmp78.Invoke_O__O(tmp80.Invoke_O_O__O(tmp84, tmp86.Invoke_O__O(tmp87)))); var tmp89 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp89 = A_arbace_g2a_print_emit_A_const_30; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp91 = A_arbace_g2a_print_emit_A_const_28; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp93 = A_arbace_g2a_print_emit_A_const_29; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp95 = A_arbace_g2a_print_emit_A_const_30; var tmp96 lang.IFn = lang.IFn_Cast(jrt.NN(tmp95).GetRawRoot__O()); var tmp97 any; A_arbace_g2a_print_emit_A_Init(); tmp97 = A_arbace_g2a_print_emit_A_const_45; var tmp98 any = tmp96.Invoke_O__O(tmp97); var tmp99 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp99 = A_arbace_g2a_print_emit_A_const_30; var tmp100 lang.IFn = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()); var tmp101 any; A_arbace_g2a_print_emit_A_Init(); tmp101 = A_arbace_g2a_print_emit_A_const_41; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp18, tmp20.Invoke_O__O(tmp22.Invoke_O__O(tmp24.Invoke_O_O_O__O(tmp28, tmp64, tmp66.Invoke_O__O(tmp68.Invoke_O__O(tmp70.Invoke_O_O_O__O(tmp74, tmp88, tmp90.Invoke_O__O(tmp92.Invoke_O__O(tmp94.Invoke_O_O__O(tmp98, tmp100.Invoke_O__O(tmp101)))))))))))) }
//line :41:1
func A_arbace_g2a_print_emit_target_A_New() *A_arbace_g2a_print_emit_target_A { A_arbace_g2a_print_emit_target_A_Init(); t := &A_arbace_g2a_print_emit_target_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_g2a_print_emit_target_A) Ctor() {}
//line :41:1
func (t *A_arbace_g2a_print_emit_target_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_22; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O())) { var l__1256000046__auto____2 any; var tmp4 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_11; var tmp5 *lang.Keyword = tmp4; l__1256000046__auto____2 = jrt.NN(tmp5).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); var tmp6 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____2)) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____2)).Ref() } else { return nil } } else { return nil } }







func A_arbace_g2a_print_emit_room_QMARK__A_New() *A_arbace_g2a_print_emit_room_QMARK__A { A_arbace_g2a_print_emit_room_QMARK__A_Init(); t := &A_arbace_g2a_print_emit_room_QMARK__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_g2a_print_emit_room_QMARK__A) Ctor() {}
//line :49:1
func (t *A_arbace_g2a_print_emit_room_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var;



	A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_46; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_22; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; or__1927000174__auto____2 = tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O())); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool; var tmp6 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_47; or__1927000174__auto____3 = lang.Util_Identical_O_O__Z(jrt.NN(tmp6).Get__O(), nil); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_47; var tmp8 int64 = lang.RT_LongCast_O__J(jrt.NN(tmp7).Get__O()); var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_6; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_11; var tmp12 *lang.Keyword = tmp11; var tmp13 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_27; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(tmp8, lang.Numbers_Add_O_J__Number(tmp10.Invoke_O__O(jrt.NN(tmp12).Invoke_O__O(jrt.NN(tmp13).Get__O())), lang.RT_LongCast_O__J(n__0)))).Ref() } } }









func A_arbace_g2a_print_emit_semi_after_QMARK__A_New() *A_arbace_g2a_print_emit_semi_after_QMARK__A { A_arbace_g2a_print_emit_semi_after_QMARK__A_Init(); t := &A_arbace_g2a_print_emit_semi_after_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 any; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_48; if jrt.A2g_Truth(lang.IFn_Cast(tmp1).Invoke_O__O(s__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp2 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__0)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if lang.Numbers_IsZero_J__Z(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_50; if tmp3 != nil { var c__2 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())))); var or__1927000174__auto____3 bool = jrt.Character_IsLetterOrDigit_C__Z(c__2)




		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool; var tmp4 any; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_51; or__1927000174__auto____4 = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(tmp4)).CharValue__C()); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool; var tmp5 any; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_52; or__1927000174__auto____5 = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(tmp5)).CharValue__C()); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool; var tmp6 any; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_53; or__1927000174__auto____6 = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(tmp6)).CharValue__C()); if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool; var tmp7 any; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_54; or__1927000174__auto____7 = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(tmp7)).CharValue__C()); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else {
			return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(int64(lang.RT_IntCast_C__I(c__2)), 127)).Ref() } } } } } } else {
//line :66:1
				return nil
			}
	}
	}
	}
}


func A_arbace_g2a_print_emit_may_combine_QMARK__A_New() *A_arbace_g2a_print_emit_may_combine_QMARK__A { A_arbace_g2a_print_emit_may_combine_QMARK__A_Init(); t := &A_arbace_g2a_print_emit_may_combine_QMARK__A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) Ctor() {}
//line :74:1
func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) Invoke_O_O_O__O(self, prev__0, next__1 any) any {



	var tmp1 bool; var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())); if and__1927000168__auto____3 { tmp1 = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(next__1)).Length__I())) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { var p__3 uint16 = jrt.NN(jrt.String_Cast(prev__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())))); var n__4 uint16 = jrt.NN(jrt.String_Cast(next__1)).CharAt_I__C(lang.RT_IntCast_J__I(0)); var or__1927000174__auto____5 bool; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_103)


		if and__1927000168__auto____5 { var tmp2 any; A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_55; or__1927000174__auto____5 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp2)).CharValue__C()) } else { or__1927000174__auto____5 = and__1927000168__auto____5 }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_104)
			if and__1927000168__auto____6 { var tmp3 any; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_56; or__1927000174__auto____6 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp3)).CharValue__C()) } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :81:1
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool; var and__1927000168__auto____7 bool; var tmp4 any

				A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_57; and__1927000168__auto____7 = lang.Util_Equiv_C_C__Z(p__3, jrt.NN(jrt.Character_Cast(tmp4)).CharValue__C()); if and__1927000168__auto____7 { var or__1927000174__auto____8 bool; var tmp5 any; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_58; or__1927000174__auto____8 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp5)).CharValue__C()); if or__1927000174__auto____8 { or__1927000174__auto____7 = or__1927000174__auto____8 } else { var tmp6 any; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_57; or__1927000174__auto____7 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp6)).CharValue__C()) } } else { or__1927000174__auto____7 = and__1927000168__auto____7 }
//line :81:1
				if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8_2 bool; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_105)


					if and__1927000168__auto____8 { var or__1927000174__auto____9 bool; var tmp7 any; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_56; or__1927000174__auto____9 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp7)).CharValue__C()); if or__1927000174__auto____9 { or__1927000174__auto____8_2 = or__1927000174__auto____9 } else { var tmp8 any; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_59; or__1927000174__auto____8_2 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp8)).CharValue__C()) } } else { or__1927000174__auto____8_2 = and__1927000168__auto____8 }
//line :81:1
					if or__1927000174__auto____8_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8_2).Ref() } else { var or__1927000174__auto____9_2 bool; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_106)



						if and__1927000168__auto____9 { var or__1927000174__auto____10 bool; var tmp9 any; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_60; or__1927000174__auto____10 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp9)).CharValue__C()); if or__1927000174__auto____10 { or__1927000174__auto____9_2 = or__1927000174__auto____10 } else { var tmp10 any; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_61; or__1927000174__auto____9_2 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp10)).CharValue__C()) } } else { or__1927000174__auto____9_2 = and__1927000168__auto____9 }
//line :81:1
						if or__1927000174__auto____9_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9_2).Ref() } else { var or__1927000174__auto____10_2 any; var and__1927000168__auto____10 bool = jrt.Character_IsDigit_C__Z(p__3)




							if and__1927000168__auto____10 { var and__1927000168__auto____11 bool; var tmp11 any; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_62; and__1927000168__auto____11 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp11)).CharValue__C()); if and__1927000168__auto____11 { var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_63; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_64; or__1927000174__auto____10_2 = tmp13.Invoke_O_O__O(tmp14, prev__0) } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() }
//line :81:1
							if jrt.A2g_Truth(or__1927000174__auto____10_2) { return or__1927000174__auto____10_2 } else { var and__1927000168__auto____11_2 bool; var or__1927000174__auto____11 bool = jrt.Character_IsLetterOrDigit_C__Z(p__3)





								if or__1927000174__auto____11 { and__1927000168__auto____11_2 = or__1927000174__auto____11 } else { var tmp15 any; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_51; and__1927000168__auto____11_2 = lang.Util_Equiv_C_C__Z(p__3, jrt.NN(jrt.Character_Cast(tmp15)).CharValue__C()) }; if and__1927000168__auto____11_2 { var or__1927000174__auto____12 bool = jrt.Character_IsLetterOrDigit_C__Z(n__4)
									if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____12).Ref() } else { var tmp16 any; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_51; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(tmp16)).CharValue__C())).Ref() } } else {
//line :87:1
										return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11_2).Ref() } } } } } } } } else {
//line :78:1
											return nil
										}
}









func A_arbace_g2a_print_emit_start_line_BANG__A_New() *A_arbace_g2a_print_emit_start_line_BANG__A { A_arbace_g2a_print_emit_start_line_BANG__A_Init(); t := &A_arbace_g2a_print_emit_start_line_BANG__A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_g2a_print_emit_start_line_BANG__A) Ctor() {}
//line :90:1
func (t *A_arbace_g2a_print_emit_start_line_BANG__A) Invoke_O__O(self any) any { var p__1 any; var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_27; p__1 = jrt.NN(tmp1).Get__O(); var tmp2 /*line :92:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_6; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_13; if jrt.A2g_Truth(tmp3.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(p__1))) { var n__2 int64; var tmp5 *lang.Var
										A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_6; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_14; n__2 = lang.Numbers_Max_J_J__J(0, lang.RT_LongCast_O__J(tmp6.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(p__1))))
//line :92:1
	var sb__3 any; var tmp8 *lang.Keyword

	A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_10; sb__3 = jrt.NN(tmp8).Invoke_O__O(p__1)
//line :92:1
	var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J(n__2); var ___5 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(___5, n__1927000701__auto____4) { var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__3); var tmp10 any; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_66; jrt.NN(tmp9).Append_O__StringBuilder(tmp10); ___5 = lang.Numbers_Unchecked_inc_J__J(___5); continue L1 }
//line :92:1
		break L1
	}


	var tmp11 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_65; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_15; tmp12.Invoke_O_O__O(jrt.NN(tmp13).Invoke_O__O(p__1), jrt.Long_ValueOf_J__Long(n__2).Ref())
	var tmp14 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_65; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_13; var tmp17 any = jrt.NN(tmp16).Invoke_O__O(p__1); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_FALSE; tmp15.Invoke_O_O__O(tmp17, tmp18.Ref())
	var tmp19 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_65; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_18; return tmp20.Invoke_O_O__O(jrt.NN(tmp21).Invoke_O__O(p__1), nil) } else {
//line :92:1
		return nil } }







func A_arbace_g2a_print_emit_tok_A_New() *A_arbace_g2a_print_emit_tok_A { A_arbace_g2a_print_emit_tok_A_Init(); t := &A_arbace_g2a_print_emit_tok_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_g2a_print_emit_tok_A) Ctor() {}
//line :100:1
func (t *A_arbace_g2a_print_emit_tok_A) Invoke_O_O__O(self, s__0 any) any { var p__2 any; var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_27; p__2 = jrt.NN(tmp1).Get__O(); var sb__3 any; var tmp2 *lang.Keyword;


	A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_10; sb__3 = jrt.NN(tmp2).Invoke_O__O(p__2); var at_bol__4 any; var tmp3 /*line :100:1*/*lang.Var;


	A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_13; at_bol__4 = tmp4.Invoke_O__O(jrt.NN(tmp5).Invoke_O__O(p__2)); var tmp6 /*line :105:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_67; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); var ws__5 any; var tmp7 /*line :100:1*/*lang.Var;





	A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_6; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_18; ws__5 = tmp8.Invoke_O__O(jrt.NN(tmp9).Invoke_O__O(p__2)); if
	jrt.A2g_Truth(at_bol__4) { } else { if jrt.A2g_Truth(ws__5) {

		jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C(ws__5)) } else {
//line :107:1
			var tmp10 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_68; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_6; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_16; if jrt.A2g_Truth(tmp11.Invoke_O_O__O(tmp13.Invoke_O__O(jrt.NN(tmp14).Invoke_O__O(p__2)), s__0)) {


				var tmp15 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__3); var tmp16 any; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_69; jrt.NN(tmp15).Append_O__StringBuilder(tmp16) } } }; var tmp17 /*line :111:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_65; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_18; tmp18.Invoke_O_O__O(jrt.NN(tmp19).Invoke_O__O(p__2), nil);
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(s__0)); var tmp20 /*line :113:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_65; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp22 = A_arbace_g2a_print_emit_A_const_16; tmp21.Invoke_O_O__O(jrt.NN(tmp22).Invoke_O__O(p__2), s__0); var tmp23 /*line :114:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp23 = A_arbace_g2a_print_emit_A_const_65; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp25 = A_arbace_g2a_print_emit_A_const_17; var tmp26 any = jrt.NN(tmp25).Invoke_O__O(p__2); var tmp27 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp27 = A_arbace_g2a_print_emit_A_const_70; tmp24.Invoke_O_O__O(tmp26, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__0)); return nil }


func A_arbace_g2a_print_emit_raw_tok_A_New() *A_arbace_g2a_print_emit_raw_tok_A { A_arbace_g2a_print_emit_raw_tok_A_Init(); t := &A_arbace_g2a_print_emit_raw_tok_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_g2a_print_emit_raw_tok_A) Ctor() {}
//line :117:1
func (t *A_arbace_g2a_print_emit_raw_tok_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_71; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_73; tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__0))
	var tmp4 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_11; var tmp5 *lang.Keyword = tmp4; var tmp6 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_27; var tmp7 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp5).Invoke_O__O(jrt.NN(tmp6).Get__O())); var tmp8 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_11; var tmp9 *lang.Keyword = tmp8; var tmp10 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_27; var tmp11 any = jrt.NN(lang.Volatile_Cast(jrt.NN(tmp9).Invoke_O__O(jrt.NN(tmp10).Get__O()))).Deref__O(); var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_72; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_New(); var tmp15 *jrt.Class; A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_Init(); tmp15 = A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_fn_class; jrt.NN(tmp7).Reset_O__O(lang.Numbers_Add_O_J__Number(tmp11, int64(lang.RT_Count_O__I(tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), s__0)))))
	var tmp16 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_65; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_17; var tmp19 *lang.Keyword = tmp18; var tmp20 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_27; var tmp21 any = jrt.NN(tmp19).Invoke_O__O(jrt.NN(tmp20).Get__O()); var tmp22 *jrt.Boolean; jrt.Boolean_Init(); tmp22 = jrt.Boolean_TRUE; return tmp17.Invoke_O_O__O(tmp21, tmp22.Ref()) }
//line :122:1
func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_New() *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A { A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_Init(); t := &A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) Ctor() {}
//line :122:1
func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) Invoke_O_O__O(self, p1__1256000063_SHARP___1 any) any { var tmp1 any; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_74; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__1256000063_SHARP___1, tmp1)).Ref() }


func A_arbace_g2a_print_emit_sp_A_New() *A_arbace_g2a_print_emit_sp_A { A_arbace_g2a_print_emit_sp_A_Init(); t := &A_arbace_g2a_print_emit_sp_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_g2a_print_emit_sp_A) Ctor() {}
//line :125:1
func (t *A_arbace_g2a_print_emit_sp_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_13; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O()))) { return nil } else {
		var tmp6 any; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_75; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_6; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_18; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_27; if lang.Util_Equiv_O_O__Z(tmp7, tmp9.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(jrt.NN(tmp12).Get__O()))) { return nil } else { var tmp13 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_65; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_18; var tmp16 *lang.Keyword = tmp15; var tmp17 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_27; var tmp18 any = jrt.NN(tmp16).Invoke_O__O(jrt.NN(tmp17).Get__O()); var tmp19 any; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_69; return tmp14.Invoke_O_O__O(tmp18, tmp19)
		} } }
func A_arbace_g2a_print_emit_vtab_A_New() *A_arbace_g2a_print_emit_vtab_A { A_arbace_g2a_print_emit_vtab_A_Init(); t := &A_arbace_g2a_print_emit_vtab_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_g2a_print_emit_vtab_A) Ctor() {}
//line :131:1
func (t *A_arbace_g2a_print_emit_vtab_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_13; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O()))) { return nil } else {

		var tmp6 any; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_75; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_6; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_18; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_27; if lang.Util_Equiv_O_O__Z(tmp7, tmp9.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(jrt.NN(tmp12).Get__O()))) { var tmp13 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_10; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_27; jrt.NN(jrt.StringBuilder_Cast(jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Get__O()))).Append_C__StringBuilder(lang.RT_CharCast_J__C(11)) }
		var tmp16 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_65; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_18; var tmp19 *lang.Keyword = tmp18; var tmp20 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_27; return tmp17.Invoke_O_O__O(jrt.NN(tmp19).Invoke_O__O(jrt.NN(tmp20).Get__O()), jrt.Character_ValueOf_C__Character(lang.RT_CharCast_J__C(11)).Ref())
	} }
func A_arbace_g2a_print_emit_nl_A_New() *A_arbace_g2a_print_emit_nl_A { A_arbace_g2a_print_emit_nl_A_Init(); t := &A_arbace_g2a_print_emit_nl_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_g2a_print_emit_nl_A) Ctor() {}
//line :139:1
func (t *A_arbace_g2a_print_emit_nl_A) Invoke_O_O_O__O(self, indent__0, form_feed_QMARK___1 any) any { var p__3 any; var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_27; p__3 = jrt.NN(tmp1).Get__O(); var sb__4 any; var tmp2 *lang.Keyword;




	A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_10; sb__4 = jrt.NN(tmp2).Invoke_O__O(p__3); var tmp3 /*line :145:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_65; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_18; tmp4.Invoke_O_O__O(jrt.NN(tmp5).Invoke_O__O(p__3), nil); var tmp6 /*line :146:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp7 uint16; if jrt.A2g_Truth(form_feed_QMARK___1) { tmp7 = lang.RT_CharCast_J__C(12) } else { tmp7 = lang.RT_CharCast_J__C(10) }; jrt.NN(tmp6).Append_C__StringBuilder(tmp7); var tmp8 /*line :147:1*/*lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_11; var tmp9 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp8).Invoke_O__O(p__3)); var tmp10 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_11; jrt.NN(tmp9).Reset_O__O(lang.Numbers_Inc_O__Number(jrt.NN(lang.Volatile_Cast(jrt.NN(tmp10).Invoke_O__O(p__3))).Deref__O())); var tmp11 /*line :148:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_65; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_13; var tmp14 any = jrt.NN(tmp13).Invoke_O__O(p__3); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; tmp12.Invoke_O_O__O(tmp14, tmp15.Ref()); var tmp16 /*line :149:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_65; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_14; tmp17.Invoke_O_O__O(jrt.NN(tmp18).Invoke_O__O(p__3), indent__0); return nil }
//line :139:1
func (t *A_arbace_g2a_print_emit_nl_A) Invoke_O_O__O(self, indent__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return tmp2.Invoke_O_O__O(indent__0, tmp3.Ref())
}








func A_arbace_g2a_print_emit_cur_indent_A_New() *A_arbace_g2a_print_emit_cur_indent_A { A_arbace_g2a_print_emit_cur_indent_A_Init(); t := &A_arbace_g2a_print_emit_cur_indent_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_g2a_print_emit_cur_indent_A) Ctor() {}
//line :152:1
func (t *A_arbace_g2a_print_emit_cur_indent_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_15; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; return tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O())) }
//line :152:1
func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_New() *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A { A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) Ctor() {}
//line :152:1
func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_29; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_30; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_32; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_28; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_29; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_30; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_15; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_30; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_77; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, tmp20.Invoke_O__O(tmp21)))))) }

func A_arbace_g2a_print_emit_push_open_BANG__A_New() *A_arbace_g2a_print_emit_push_open_BANG__A { A_arbace_g2a_print_emit_push_open_BANG__A_Init(); t := &A_arbace_g2a_print_emit_push_open_BANG__A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Ctor() {}
//line :154:1
func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Invoke_O_O__O(self, indent__0 any) any {



	var tmp1 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_19; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_27; var tmp4 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O())); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_7; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_19; var tmp8 *lang.Keyword = tmp7; var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_27; jrt.NN(tmp4).Reset_O__O(tmp6.Invoke_O_O__O(jrt.NN(lang.Volatile_Cast(jrt.NN(tmp8).Invoke_O__O(jrt.NN(tmp9).Get__O()))).Deref__O(), indent__0))
//line :154:1
	return nil }
//line :154:1
func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_78; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_6; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_13; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(tmp5.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(jrt.NN(tmp8).Get__O()))) { var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_6; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_14; var tmp12 *lang.Keyword = tmp11; var tmp13 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_27; tmp3 = tmp10.Invoke_O__O(jrt.NN(tmp12).Invoke_O__O(jrt.NN(tmp13).Get__O())) } else { var tmp14 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_6; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_15; var tmp17 *lang.Keyword = tmp16; var tmp18 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_27; tmp3 = tmp15.Invoke_O__O(jrt.NN(tmp17).Invoke_O__O(jrt.NN(tmp18).Get__O())) }; return tmp2.Invoke_O__O(tmp3)
}

func A_arbace_g2a_print_emit_pop_open_BANG__A_New() *A_arbace_g2a_print_emit_pop_open_BANG__A { A_arbace_g2a_print_emit_pop_open_BANG__A_Init(); t := &A_arbace_g2a_print_emit_pop_open_BANG__A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) Ctor() {}
//line :160:1
func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) Invoke_O__O(self any) any { var o__1 any; var tmp1 *lang.Var;
										A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_79; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_19; var tmp6 *lang.Keyword = tmp5; var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_27; o__1 = tmp2.Invoke_O__O(tmp4.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(jrt.NN(tmp7).Get__O()))); var tmp8 /*line :162:1*/*lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_19; var tmp9 *lang.Keyword = tmp8; var tmp10 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_27; var tmp11 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp9).Invoke_O__O(jrt.NN(tmp10).Get__O())); var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_80; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_19; var tmp15 *lang.Keyword = tmp14; var tmp16 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_27; jrt.NN(tmp11).Reset_O__O(tmp13.Invoke_O__O(jrt.NN(lang.Volatile_Cast(jrt.NN(tmp15).Invoke_O__O(jrt.NN(tmp16).Get__O()))).Deref__O())); return o__1 }


func A_arbace_g2a_print_emit_cont_indent_A_New() *A_arbace_g2a_print_emit_cont_indent_A { A_arbace_g2a_print_emit_cont_indent_A_Init(); t := &A_arbace_g2a_print_emit_cont_indent_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_g2a_print_emit_cont_indent_A) Ctor() {}
//line :165:1
func (t *A_arbace_g2a_print_emit_cont_indent_A) Invoke_O__O(self any) any { var o__1 any; var tmp1 *lang.Var;


	A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_79; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_19; var tmp6 *lang.Keyword = tmp5; var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_27; o__1 = tmp2.Invoke_O__O(tmp4.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(jrt.NN(tmp7).Get__O()))); var tmp8 any; var or__1927000174__auto____2 any = o__1; if
	jrt.A2g_Truth(or__1927000174__auto____2) { tmp8 = or__1927000174__auto____2 } else { A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_26 }; return jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(tmp8))).Ref() }

func A_arbace_g2a_print_emit_comment_line_A_New() *A_arbace_g2a_print_emit_comment_line_A { A_arbace_g2a_print_emit_comment_line_A_Init(); t := &A_arbace_g2a_print_emit_comment_line_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_g2a_print_emit_comment_line_A) Ctor() {}
//line :171:1
func (t *A_arbace_g2a_print_emit_comment_line_A) Invoke_O_O_O__O(self, s__0, indent__1 any) any { var p__3 any; var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_27; p__3 = jrt.NN(tmp1).Get__O(); var sb__4 any; var tmp2 *lang.Keyword;



	A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_10; sb__4 = jrt.NN(tmp2).Invoke_O__O(p__3); var tmp3 /*line :176:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_13; var tmp6 *lang.Keyword = tmp5; var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(tmp4.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(jrt.NN(tmp7).Get__O()))) { } else { var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_76; lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(indent__1) }; var tmp9 /*line :177:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_65; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_14; var tmp12 any = jrt.NN(tmp11).Invoke_O__O(p__3); var tmp13 any; var tmp14 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_81; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_82)) { A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_26 } else { tmp13 = indent__1 }; tmp10.Invoke_O_O__O(tmp12, tmp13); var tmp15 /*line :178:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_67; lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O(); var tmp16 /*line :179:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp17 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_73; jrt.NN(tmp16).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(s__0))); var tmp18 /*line :180:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_65; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_16; tmp19.Invoke_O_O__O(jrt.NN(tmp20).Invoke_O__O(p__3), Lit_83); var tmp21 /*line :181:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_65; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp23 = A_arbace_g2a_print_emit_A_const_17; var tmp24 any = jrt.NN(tmp23).Invoke_O__O(p__3); var tmp25 *jrt.Boolean; jrt.Boolean_Init(); tmp25 = jrt.Boolean_FALSE; tmp22.Invoke_O_O__O(tmp24, tmp25.Ref()); var tmp26 /*line :182:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp26 = A_arbace_g2a_print_emit_A_const_76; return lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(indent__1) }

func A_arbace_g2a_print_emit_set_line_BANG__A_New() *A_arbace_g2a_print_emit_set_line_BANG__A { A_arbace_g2a_print_emit_set_line_BANG__A_Init(); t := &A_arbace_g2a_print_emit_set_line_BANG__A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_g2a_print_emit_set_line_BANG__A) Ctor() {}
//line :184:1
func (t *A_arbace_g2a_print_emit_set_line_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_65; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_11; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; tmp2.Invoke_O_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O()), l__0)
	var tmp6 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_21; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_27; var tmp9 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp7).Invoke_O__O(jrt.NN(tmp8).Get__O())); var tmp10 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_21; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_27; return jrt.NN(tmp9).Reset_O__O(lang.Numbers_Min_O_J__O(jrt.NN(lang.Volatile_Cast(jrt.NN(tmp11).Invoke_O__O(jrt.NN(tmp12).Get__O()))).Deref__O(), lang.RT_LongCast_O__J(l__0)))
}














func A_arbace_g2a_print_emit_start_at_BANG__A_New() *A_arbace_g2a_print_emit_start_at_BANG__A { A_arbace_g2a_print_emit_start_at_BANG__A_Init(); t := &A_arbace_g2a_print_emit_start_at_BANG__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_g2a_print_emit_start_at_BANG__A) Ctor() {}
//line :204:1
func (t *A_arbace_g2a_print_emit_start_at_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_65; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_11; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; tmp2.Invoke_O_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O()), l__0)
	var tmp6 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_65; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_21; var tmp9 *lang.Keyword = tmp8; var tmp10 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_27; return tmp7.Invoke_O_O__O(jrt.NN(tmp9).Invoke_O__O(jrt.NN(tmp10).Get__O()), l__0)
}
func A_arbace_g2a_print_emit_chunk_state_A_New() *A_arbace_g2a_print_emit_chunk_state_A { A_arbace_g2a_print_emit_chunk_state_A_Init(); t := &A_arbace_g2a_print_emit_chunk_state_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_g2a_print_emit_chunk_state_A) Ctor() {}
//line :210:1
func (t *A_arbace_g2a_print_emit_chunk_state_A) Invoke_O__O(self any) any { var p__1 any; var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_27; p__1 = jrt.NN(tmp1).Get__O(); var tmp2 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_82; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_10; var tmp5 any = jrt.NN(jrt.StringBuilder_Cast(jrt.NN(tmp4).Invoke_O__O(p__1))).ToString__String().Ref(); var tmp6 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_11; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_6; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_11; var tmp11 any = tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(p__1)); var tmp12 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_13; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_6; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_13; var tmp17 any = tmp15.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(p__1)); var tmp18 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_14; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_6; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp22 = A_arbace_g2a_print_emit_A_const_14; var tmp23 any = tmp21.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(p__1)); var tmp24 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp24 = A_arbace_g2a_print_emit_A_const_15; var tmp25 any = tmp24.Ref(); var tmp26 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp26 = A_arbace_g2a_print_emit_A_const_6; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp28 = A_arbace_g2a_print_emit_A_const_15; var tmp29 any = tmp27.Invoke_O__O(jrt.NN(tmp28).Invoke_O__O(p__1)); var tmp30 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp30 = A_arbace_g2a_print_emit_A_const_16; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp32 = A_arbace_g2a_print_emit_A_const_6; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp34 = A_arbace_g2a_print_emit_A_const_16; var tmp35 any = tmp33.Invoke_O__O(jrt.NN(tmp34).Invoke_O__O(p__1)); var tmp36 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp36 = A_arbace_g2a_print_emit_A_const_17; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp38 = A_arbace_g2a_print_emit_A_const_6; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp40 = A_arbace_g2a_print_emit_A_const_17; var tmp41 any = tmp39.Invoke_O__O(jrt.NN(tmp40).Invoke_O__O(p__1)); var tmp42 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp42 = A_arbace_g2a_print_emit_A_const_18; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp44 = A_arbace_g2a_print_emit_A_const_6; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp46 = A_arbace_g2a_print_emit_A_const_18; var tmp47 any = tmp45.Invoke_O__O(jrt.NN(tmp46).Invoke_O__O(p__1)); var tmp48 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp48 = A_arbace_g2a_print_emit_A_const_19; var tmp49 any = tmp48.Ref(); var tmp50 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp50 = A_arbace_g2a_print_emit_A_const_6; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp52 = A_arbace_g2a_print_emit_A_const_19; var tmp53 any = tmp51.Invoke_O__O(jrt.NN(tmp52).Invoke_O__O(p__1)); var tmp54 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp54 = A_arbace_g2a_print_emit_A_const_20; var tmp55 any = tmp54.Ref(); var tmp56 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp56 = A_arbace_g2a_print_emit_A_const_6; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp58 = A_arbace_g2a_print_emit_A_const_20; var tmp59 any = tmp57.Invoke_O__O(jrt.NN(tmp58).Invoke_O__O(p__1)); var tmp60 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp60 = A_arbace_g2a_print_emit_A_const_21; var tmp61 any = tmp60.Ref(); var tmp62 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp62 = A_arbace_g2a_print_emit_A_const_6; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp64 = A_arbace_g2a_print_emit_A_const_21; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp7, tmp11, tmp13, tmp17, tmp19, tmp23, tmp25, tmp29, tmp31, tmp35, tmp37, tmp41, tmp43, tmp47, tmp49, tmp53, tmp55, tmp59, tmp61, tmp63.Invoke_O__O(jrt.NN(tmp64).Invoke_O__O(p__1)))) }









func A_arbace_g2a_print_emit_join_BANG__A_New() *A_arbace_g2a_print_emit_join_BANG__A { A_arbace_g2a_print_emit_join_BANG__A_Init(); t := &A_arbace_g2a_print_emit_join_BANG__A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_g2a_print_emit_join_BANG__A) Ctor() {}
//line :220:1
func (t *A_arbace_g2a_print_emit_join_BANG__A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var p__3 any; var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_27; p__3 = jrt.NN(tmp1).Get__O(); var l__4 int64 = lang.RT_LongCast_O__J(l__1); var tmp2 any; var and__1927000168__auto____5 any; var tmp3 *lang.Var;





	A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_13; and__1927000168__auto____5 = tmp4.Invoke_O__O(jrt.NN(tmp5).Invoke_O__O(p__3)); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp6 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_6; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_11; and__1927000168__auto____6 = lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(p__3))), l__4); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool; var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_6; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_14; and__1927000168__auto____7 = lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(tmp10.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(p__3)))); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool; var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_6; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_18; and__1927000168__auto____8 = lang.Util_Identical_O_O__Z(tmp13.Invoke_O__O(jrt.NN(tmp14).Invoke_O__O(p__3)), nil); if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var tmp15 *lang.Var
		A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_83; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_6; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_19; and__1927000168__auto____9 = tmp16.Invoke_O__O(tmp18.Invoke_O__O(jrt.NN(tmp19).Invoke_O__O(p__3)))
//line :226:1
		if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp20 *lang.Var
			A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_6; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp22 = A_arbace_g2a_print_emit_A_const_20; and__1927000168__auto____10 = lang.Numbers_Lt_J_J__Z(lang.RT_LongCast_O__J(tmp21.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(p__3))), l__4)
//line :226:1
			if and__1927000168__auto____10 {
				var tmp23 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp23 = A_arbace_g2a_print_emit_A_const_21; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_J__Z(lang.RT_LongCast_O__J(jrt.NN(tmp23).Invoke_O__O(c__0)), l__4)).Ref() } else {
//line :226:1
					tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else { tmp2 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp2) {

						var tmp24 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp24 = A_arbace_g2a_print_emit_A_const_10; var tmp25 *jrt.StringBuilder = jrt.StringBuilder_Cast(jrt.NN(tmp24).Invoke_O__O(p__3)); var tmp26 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp26 = A_arbace_g2a_print_emit_A_const_82; jrt.NN(tmp25).Append_String__StringBuilder(jrt.String_Cast(jrt.NN(tmp26).Invoke_O__O(c__0)))
						var tmp27 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp27 = A_arbace_g2a_print_emit_A_const_65; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp29 = A_arbace_g2a_print_emit_A_const_11; var tmp30 any = jrt.NN(tmp29).Invoke_O__O(p__3); var tmp31 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp31 = A_arbace_g2a_print_emit_A_const_11; tmp28.Invoke_O_O__O(tmp30, jrt.NN(tmp31).Invoke_O__O(c__0))
						var tmp32 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp32 = A_arbace_g2a_print_emit_A_const_65; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp34 = A_arbace_g2a_print_emit_A_const_13; var tmp35 any = jrt.NN(tmp34).Invoke_O__O(p__3); var tmp36 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp36 = A_arbace_g2a_print_emit_A_const_13; tmp33.Invoke_O_O__O(tmp35, jrt.NN(tmp36).Invoke_O__O(c__0))
						var tmp37 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp37 = A_arbace_g2a_print_emit_A_const_65; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp39 = A_arbace_g2a_print_emit_A_const_14; var tmp40 any = jrt.NN(tmp39).Invoke_O__O(p__3); var tmp41 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp41 = A_arbace_g2a_print_emit_A_const_14; tmp38.Invoke_O_O__O(tmp40, jrt.NN(tmp41).Invoke_O__O(c__0))
						var tmp42 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp42 = A_arbace_g2a_print_emit_A_const_65; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp44 = A_arbace_g2a_print_emit_A_const_15; var tmp45 any = jrt.NN(tmp44).Invoke_O__O(p__3); var tmp46 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp46 = A_arbace_g2a_print_emit_A_const_15; tmp43.Invoke_O_O__O(tmp45, jrt.NN(tmp46).Invoke_O__O(c__0))
						var tmp47 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp47 = A_arbace_g2a_print_emit_A_const_65; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp49 = A_arbace_g2a_print_emit_A_const_16; var tmp50 any = jrt.NN(tmp49).Invoke_O__O(p__3); var tmp51 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp51 = A_arbace_g2a_print_emit_A_const_16; tmp48.Invoke_O_O__O(tmp50, jrt.NN(tmp51).Invoke_O__O(c__0))
						var tmp52 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp52 = A_arbace_g2a_print_emit_A_const_65; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp54 = A_arbace_g2a_print_emit_A_const_17; var tmp55 any = jrt.NN(tmp54).Invoke_O__O(p__3); var tmp56 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp56 = A_arbace_g2a_print_emit_A_const_17; tmp53.Invoke_O_O__O(tmp55, jrt.NN(tmp56).Invoke_O__O(c__0))
						var tmp57 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp57 = A_arbace_g2a_print_emit_A_const_65; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp59 = A_arbace_g2a_print_emit_A_const_18; var tmp60 any = jrt.NN(tmp59).Invoke_O__O(p__3); var tmp61 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp61 = A_arbace_g2a_print_emit_A_const_18; tmp58.Invoke_O_O__O(tmp60, jrt.NN(tmp61).Invoke_O__O(c__0))
						var tmp62 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp62 = A_arbace_g2a_print_emit_A_const_65; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp64 = A_arbace_g2a_print_emit_A_const_19; var tmp65 any = jrt.NN(tmp64).Invoke_O__O(p__3); var tmp66 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp66 = A_arbace_g2a_print_emit_A_const_19; tmp63.Invoke_O_O__O(tmp65, jrt.NN(tmp66).Invoke_O__O(c__0))
						var tmp67 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp67 = A_arbace_g2a_print_emit_A_const_20; var tmp68 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp67).Invoke_O__O(p__3)); var tmp69 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp69 = A_arbace_g2a_print_emit_A_const_20; var tmp70 any = jrt.NN(lang.Volatile_Cast(jrt.NN(tmp69).Invoke_O__O(p__3))).Deref__O(); var tmp71 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp71 = A_arbace_g2a_print_emit_A_const_20; jrt.NN(tmp68).Reset_O__O(lang.Numbers_Max_O_J__O(tmp70, lang.RT_LongCast_O__J(jrt.NN(tmp71).Invoke_O__O(c__0))))
						var tmp72 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp72 = A_arbace_g2a_print_emit_A_const_21; var tmp73 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp72).Invoke_O__O(p__3)); var tmp74 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp74 = A_arbace_g2a_print_emit_A_const_21; var tmp75 any = jrt.NN(lang.Volatile_Cast(jrt.NN(tmp74).Invoke_O__O(p__3))).Deref__O(); var tmp76 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp76 = A_arbace_g2a_print_emit_A_const_21; jrt.NN(tmp73).Reset_O__O(lang.Numbers_Min_O_J__O(tmp75, lang.RT_LongCast_O__J(jrt.NN(tmp76).Invoke_O__O(c__0))))
//line :226:1
						jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } }















func A_arbace_g2a_print_emit_line_directive_inline_A_New() *A_arbace_g2a_print_emit_line_directive_inline_A { A_arbace_g2a_print_emit_line_directive_inline_A_Init(); t := &A_arbace_g2a_print_emit_line_directive_inline_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_g2a_print_emit_line_directive_inline_A) Ctor() {}
//line :242:1
func (t *A_arbace_g2a_print_emit_line_directive_inline_A) Invoke_O_O__O(self, n__0 any) any { var p__2 any; var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_27; p__2 = jrt.NN(tmp1).Get__O(); var sb__3 any; var tmp2 *lang.Keyword;


	A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_10; sb__3 = jrt.NN(tmp2).Invoke_O__O(p__2); var tmp3 /*line :246:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_67; lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O(); var temp__1927000414__auto____4 any; var tmp4 /*line :242:1*/*lang.Var;




	A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_6; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_18; temp__1927000414__auto____4 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p__2)); if jrt.A2g_Truth(temp__1927000414__auto____4) { var ws__5 any = temp__1927000414__auto____4; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C(ws__5)) };
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_96, nil, Lit_97), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil))); var tmp7 /*line :249:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_65; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_18; tmp8.Invoke_O_O__O(jrt.NN(tmp9).Invoke_O__O(p__2), nil); var tmp10 /*line :250:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_84; return lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_g2a_print_emit_line_directive_own_A_New() *A_arbace_g2a_print_emit_line_directive_own_A { A_arbace_g2a_print_emit_line_directive_own_A_Init(); t := &A_arbace_g2a_print_emit_line_directive_own_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_g2a_print_emit_line_directive_own_A) Ctor() {}
//line :252:1
func (t *A_arbace_g2a_print_emit_line_directive_own_A) Invoke_O_O__O(self, n__0 any) any { var ind__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_14; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; ind__2 = tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O())); var tmp6 /*line :256:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_85; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(), ind__2); var tmp7 /*line :257:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_84; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(n__0) }




func A_arbace_g2a_print_emit_render_A_New() *A_arbace_g2a_print_emit_render_A { A_arbace_g2a_print_emit_render_A_Init(); t := &A_arbace_g2a_print_emit_render_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_g2a_print_emit_render_A) Ctor() {}
//line :262:1
func (t *A_arbace_g2a_print_emit_render_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_87; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_88; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_27; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_89; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_90; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_47; tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(tmp6, tmp10, tmp11.Ref(), nil))
//line :262:1
	var tmp12 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		lang.IFn_Cast(f__0).Invoke__O()
		{ var tmp13 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_10; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_27; tmp12 = jrt.NN(jrt.StringBuilder_Cast(jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Get__O()))).ToString__String().Ref() }
//line :262:1
		return nil }(); var tmp17 *lang.Var



	A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_86; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke__O()
//line :262:1
	if tmp16 != nil { panic(tmp16) }; return tmp12
}







func A_arbace_g2a_print_emit_break_to_BANG__A_New() *A_arbace_g2a_print_emit_break_to_BANG__A { A_arbace_g2a_print_emit_break_to_BANG__A_Init(); t := &A_arbace_g2a_print_emit_break_to_BANG__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_g2a_print_emit_break_to_BANG__A) Ctor() {}
//line :271:1
func (t *A_arbace_g2a_print_emit_break_to_BANG__A) Invoke_O_O__O(self, t__0 any) any {



	if jrt.A2g_Truth(t__0) { var mark__2 any; var tmp1 *lang.Keyword
		A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_20; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_27; mark__2 = jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O())
//line :275:1
		var brk_QMARK___3 bool; var tmp4 *lang.Keyword

		A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_91; brk_QMARK___3 = lang.Util_Equiv_O_O__Z(t__0, tmp4.Ref())
//line :275:1
		var t__4 any





		if brk_QMARK___3 { var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_6; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_13; var tmp8 *lang.Keyword = tmp7; var tmp9 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(tmp6.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(jrt.NN(tmp9).Get__O()))) { var tmp10 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_6; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_11; var tmp13 *lang.Keyword = tmp12; var tmp14 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_27; t__4 = tmp11.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(jrt.NN(tmp14).Get__O())) } else { var tmp15 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_6; var tmp16 int64 = lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(mark__2))); var tmp17 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_6; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_11; var tmp20 *lang.Keyword = tmp19; var tmp21 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_27; t__4 = lang.Numbers_Max_J_O__O(tmp16, tmp18.Invoke_O__O(jrt.NN(tmp20).Invoke_O__O(jrt.NN(tmp21).Get__O()))) } } else { t__4 = t__0 }
		jrt.NN(lang.Volatile_Cast(mark__2)).Reset_O__O(lang.Numbers_Max_O_O__O(jrt.NN(lang.Volatile_Cast(mark__2)).Deref__O(), t__4))
		var tmp22 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp22 = A_arbace_g2a_print_emit_A_const_6; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp24 = A_arbace_g2a_print_emit_A_const_11; var tmp25 *lang.Keyword = tmp24; var tmp26 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp26 = A_arbace_g2a_print_emit_A_const_27; if lang.Numbers_Gt_O_O__Z(t__4, tmp23.Invoke_O__O(jrt.NN(tmp25).Invoke_O__O(jrt.NN(tmp26).Get__O()))) {

			var tmp27 any; var and__1927000168__auto____5 any; var tmp28 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp28 = A_arbace_g2a_print_emit_A_const_6; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp30 = A_arbace_g2a_print_emit_A_const_17; var tmp31 *lang.Keyword = tmp30; var tmp32 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp32 = A_arbace_g2a_print_emit_A_const_27; and__1927000168__auto____5 = tmp29.Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(jrt.NN(tmp32).Get__O())); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp33 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp33 = A_arbace_g2a_print_emit_A_const_46; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp35 = A_arbace_g2a_print_emit_A_const_6; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp37 = A_arbace_g2a_print_emit_A_const_13; var tmp38 *lang.Keyword = tmp37; var tmp39 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp39 = A_arbace_g2a_print_emit_A_const_27; tmp27 = tmp34.Invoke_O__O(tmp36.Invoke_O__O(jrt.NN(tmp38).Invoke_O__O(jrt.NN(tmp39).Get__O()))) } else { tmp27 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp27) {
				var tmp40 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp40 = A_arbace_g2a_print_emit_A_const_23; var tmp41 *lang.Keyword = tmp40; var tmp42 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp42 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(jrt.NN(tmp41).Invoke_O__O(jrt.NN(tmp42).Get__O())) { var tmp43 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp43 = A_arbace_g2a_print_emit_A_const_92; return lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(t__4) } else { return nil } } else {
//line :285:1
					var ci__5 any; var tmp44 *lang.Var

					A_arbace_g2a_print_emit_A_Init(); tmp44 = A_arbace_g2a_print_emit_A_const_93; ci__5 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke__O()
//line :285:1
				L1: for {


					var tmp45 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp45 = A_arbace_g2a_print_emit_A_const_6; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp47 = A_arbace_g2a_print_emit_A_const_11; var tmp48 *lang.Keyword = tmp47; var tmp49 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp49 = A_arbace_g2a_print_emit_A_const_27; if lang.Numbers_Lt_O_O__Z(tmp46.Invoke_O__O(jrt.NN(tmp48).Invoke_O__O(jrt.NN(tmp49).Get__O())), t__4) { var tmp50 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp50 = A_arbace_g2a_print_emit_A_const_76; lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(ci__5); continue L1 } else { return nil } } } } else {
//line :283:1
						var tmp51 any; var and__1927000168__auto____5_2 bool; var tmp52 *lang.Var





						A_arbace_g2a_print_emit_A_Init(); tmp52 = A_arbace_g2a_print_emit_A_const_6; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp54 = A_arbace_g2a_print_emit_A_const_11; var tmp55 *lang.Keyword = tmp54; var tmp56 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp56 = A_arbace_g2a_print_emit_A_const_27; and__1927000168__auto____5_2 = lang.Numbers_Lt_O_O__Z(t__4, tmp53.Invoke_O__O(jrt.NN(tmp55).Invoke_O__O(jrt.NN(tmp56).Get__O()))); if and__1927000168__auto____5_2 { var tmp57 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp57 = A_arbace_g2a_print_emit_A_const_23; var tmp58 *lang.Keyword = tmp57; var tmp59 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp59 = A_arbace_g2a_print_emit_A_const_27; tmp51 = jrt.NN(tmp58).Invoke_O__O(jrt.NN(tmp59).Get__O()) } else { tmp51 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() }
//line :283:1
						if jrt.A2g_Truth(tmp51) {






							var tmp60 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp60 = A_arbace_g2a_print_emit_A_const_92; return lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(t__4) } else {
//line :283:1
								return nil } } } else {
//line :275:1
									return nil }
//line :271:1
	panic("a2g: unreachable")
}



















func A_arbace_g2a_print_emit_stmt_break_BANG__A_New() *A_arbace_g2a_print_emit_stmt_break_BANG__A { A_arbace_g2a_print_emit_stmt_break_BANG__A_Init(); t := &A_arbace_g2a_print_emit_stmt_break_BANG__A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) Ctor() {}
//line :292:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) Invoke_O_O_O_O_O__O(self, t__0, first_QMARK___1, sep__2, indent__3 any) any { var newline_BANG___5 any; var tmp1 any = A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_New_O(indent__3); var tmp2 *jrt.Class;





	A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_Init(); tmp2 = A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_fn_class; newline_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var same_BANG___6 any; var tmp3 any = /*line :292:1*/A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_New_O_O(first_QMARK___1, sep__2); var tmp4 *jrt.Class;






	A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_Init(); tmp4 = A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_fn_class; same_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 /*line :300:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t__0)) { var tmp6 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_20; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_27; var tmp9 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp7).Invoke_O__O(jrt.NN(tmp8).Get__O())); var tmp10 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_20; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_27; jrt.NN(tmp9).Reset_O__O(lang.Numbers_Max_O_J__O(jrt.NN(lang.Volatile_Cast(jrt.NN(tmp11).Invoke_O__O(jrt.NN(tmp12).Get__O()))).Deref__O(), lang.RT_LongCast_O__J(t__0))) }; var tmp13 /*line :301:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp13 = A_arbace_g2a_print_emit_A_const_6; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp15 = A_arbace_g2a_print_emit_A_const_13; var tmp16 *lang.Keyword = tmp15; var tmp17 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(tmp14.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(jrt.NN(tmp17).Get__O()))) {
		var tmp18 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp18 = A_arbace_g2a_print_emit_A_const_65; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp20 = A_arbace_g2a_print_emit_A_const_14; var tmp21 *lang.Keyword = tmp20; var tmp22 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp22 = A_arbace_g2a_print_emit_A_const_27; tmp19.Invoke_O_O__O(jrt.NN(tmp21).Invoke_O__O(jrt.NN(tmp22).Get__O()), indent__3)
//line :301:1
		jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp23 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp23 = A_arbace_g2a_print_emit_A_const_46; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp25 = A_arbace_g2a_print_emit_A_const_22; var tmp26 *lang.Keyword = tmp25; var tmp27 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp27 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(tmp24.Invoke_O__O(jrt.NN(tmp26).Invoke_O__O(jrt.NN(tmp27).Get__O()))) {

			var tmp28 lang.IFn = lang.IFn_Cast(newline_BANG___5); var tmp29 any; A_arbace_g2a_print_emit_A_Init(); tmp29 = A_arbace_g2a_print_emit_A_const_25; return tmp28.Invoke_O__O(tmp29) } else {
//line :301:1
				if lang.Util_Identical_O_O__Z(t__0, nil) {


					var tmp30 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp30 = A_arbace_g2a_print_emit_A_const_95; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any; A_arbace_g2a_print_emit_A_Init(); tmp32 = A_arbace_g2a_print_emit_A_const_25; if jrt.A2g_Truth(tmp31.Invoke_O__O(tmp32)) { var tmp33 lang.IFn = lang.IFn_Cast(newline_BANG___5); var tmp34 any; A_arbace_g2a_print_emit_A_Init(); tmp34 = A_arbace_g2a_print_emit_A_const_25; return tmp33.Invoke_O__O(tmp34) } else { return lang.IFn_Cast(same_BANG___6).Invoke__O() } } else {
//line :301:1
						var tmp35 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp35 = A_arbace_g2a_print_emit_A_const_91; if lang.Util_Equiv_O_O__Z(t__0, tmp35.Ref()) {



							var tmp36 lang.IFn = lang.IFn_Cast(newline_BANG___5); var tmp37 any; A_arbace_g2a_print_emit_A_Init(); tmp37 = A_arbace_g2a_print_emit_A_const_25; return tmp36.Invoke_O__O(tmp37) } else {
//line :301:1
								var tmp38 int64 = lang.RT_LongCast_O__J(t__0); var tmp39 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp39 = A_arbace_g2a_print_emit_A_const_6; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp41 = A_arbace_g2a_print_emit_A_const_11; var tmp42 *lang.Keyword = tmp41; var tmp43 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp43 = A_arbace_g2a_print_emit_A_const_27; if lang.Numbers_Gt_J_O__Z(tmp38, tmp40.Invoke_O__O(jrt.NN(tmp42).Invoke_O__O(jrt.NN(tmp43).Get__O()))) {




									var tmp44 lang.IFn = lang.IFn_Cast(newline_BANG___5); var tmp45 int64 = lang.RT_LongCast_O__J(t__0); var tmp46 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp46 = A_arbace_g2a_print_emit_A_const_6; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp48 = A_arbace_g2a_print_emit_A_const_11; var tmp49 *lang.Keyword = tmp48; var tmp50 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp50 = A_arbace_g2a_print_emit_A_const_27; return tmp44.Invoke_O__O(lang.Numbers_Minus_J_O__Number(tmp45, tmp47.Invoke_O__O(jrt.NN(tmp49).Invoke_O__O(jrt.NN(tmp50).Get__O())))) } else {
//line :301:1
										var tmp51 int64 = lang.RT_LongCast_O__J(t__0); var tmp52 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp52 = A_arbace_g2a_print_emit_A_const_6; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp54 = A_arbace_g2a_print_emit_A_const_11; var tmp55 *lang.Keyword = tmp54; var tmp56 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp56 = A_arbace_g2a_print_emit_A_const_27; if lang.Util_Equiv_J_O__Z(tmp51, tmp53.Invoke_O__O(jrt.NN(tmp55).Invoke_O__O(jrt.NN(tmp56).Get__O()))) {





											return lang.IFn_Cast(same_BANG___6).Invoke__O() } else {
//line :301:1
												var tmp57 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp57 = A_arbace_g2a_print_emit_A_const_50; if tmp57 != nil {






													var tmp58 lang.IFn = lang.IFn_Cast(newline_BANG___5); var tmp59 any; A_arbace_g2a_print_emit_A_Init(); tmp59 = A_arbace_g2a_print_emit_A_const_25; tmp58.Invoke_O__O(tmp59)
													var tmp60 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp60 = A_arbace_g2a_print_emit_A_const_23; var tmp61 *lang.Keyword = tmp60; var tmp62 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp62 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(jrt.NN(tmp61).Invoke_O__O(jrt.NN(tmp62).Get__O())) { var tmp63 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp63 = A_arbace_g2a_print_emit_A_const_96; lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(t__0) }
//line :301:1
													jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } } } }
//line :298:1
func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_New_O(p0 any) *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A { A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_Init(); t := &A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) Ctor_O(c__indent any) { t.F_indent = c__indent }
//line :298:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) Invoke_O_O__O(self, n__1 any) any { var n__1927000701__auto____2 int64 = lang.RT_LongCast_O__J(lang.Numbers_Max_J_O__O(1, n__1)); var ___3 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(___3, n__1927000701__auto____2) { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_76; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_indent); ___3 = lang.Numbers_Unchecked_inc_J__J(___3); continue L1 }; break L1 }; var tmp2 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_20; var tmp3 *lang.Keyword = tmp2; var tmp4 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_27; var tmp5 *lang.Volatile = lang.Volatile_Cast(jrt.NN(tmp3).Invoke_O__O(jrt.NN(tmp4).Get__O())); var tmp6 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_20; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp8 = A_arbace_g2a_print_emit_A_const_27; var tmp9 any = jrt.NN(lang.Volatile_Cast(jrt.NN(tmp7).Invoke_O__O(jrt.NN(tmp8).Get__O()))).Deref__O(); var tmp10 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_6; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_11; var tmp13 *lang.Keyword = tmp12; var tmp14 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_27; jrt.NN(tmp5).Reset_O__O(lang.Numbers_Max_O_O__O(tmp9, tmp11.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(jrt.NN(tmp14).Get__O())))); jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }
func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A { A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_Init(); t := &A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :299:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) Ctor_O_O(c__first_QMARK_, c__sep any) { t.F_first_QMARK_ = c__first_QMARK_; t.F_sep = c__sep }
//line :299:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) Invoke_O__O(self any) any { if jrt.A2g_Truth(t.F_first_QMARK_) { var tmp1 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_94; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O() } else { if jrt.A2g_Truth(t.F_sep) { var tmp2 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_71; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_sep) }; var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_94; lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O() }; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }












func A_arbace_g2a_print_emit_close_break_BANG__A_New() *A_arbace_g2a_print_emit_close_break_BANG__A { A_arbace_g2a_print_emit_close_break_BANG__A_Init(); t := &A_arbace_g2a_print_emit_close_break_BANG__A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_g2a_print_emit_close_break_BANG__A) Ctor() {}
//line :312:1
func (t *A_arbace_g2a_print_emit_close_break_BANG__A) Invoke_O_O_O_O_O__O(self, end__0, multiline_QMARK___1, always_QMARK___2, indent__3 any) any {





	var tmp1 any; var and__1927000168__auto____5 any; var tmp2 *lang.Keyword
	A_arbace_g2a_print_emit_A_Init(); tmp2 = A_arbace_g2a_print_emit_A_const_22; var tmp3 *lang.Keyword = tmp2; var tmp4 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_27; and__1927000168__auto____5 = jrt.NN(tmp3).Invoke_O__O(jrt.NN(tmp4).Get__O()); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp5 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp5 = A_arbace_g2a_print_emit_A_const_35; tmp1 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(end__0) } else { tmp1 = and__1927000168__auto____5 }
//line :318:1
	if jrt.A2g_Truth(tmp1) {

		var tmp6 int64 = lang.RT_LongCast_O__J(end__0); var tmp7 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_6; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp9 = A_arbace_g2a_print_emit_A_const_11; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp11 = A_arbace_g2a_print_emit_A_const_27; if lang.Numbers_Gt_J_O__Z(tmp6, tmp8.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Get__O()))) { L1: for {
			var tmp12 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp12 = A_arbace_g2a_print_emit_A_const_6; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp14 = A_arbace_g2a_print_emit_A_const_11; var tmp15 *lang.Keyword = tmp14; var tmp16 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp16 = A_arbace_g2a_print_emit_A_const_27; if lang.Numbers_Lt_O_J__Z(tmp13.Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(jrt.NN(tmp16).Get__O())), lang.RT_LongCast_O__J(end__0)) { var tmp17 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp17 = A_arbace_g2a_print_emit_A_const_76; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(indent__3); continue L1 }
//line :320:1
			break L1 }; jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp18 int64 = lang.RT_LongCast_O__J(end__0); var tmp19 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp19 = A_arbace_g2a_print_emit_A_const_6; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp21 = A_arbace_g2a_print_emit_A_const_11; var tmp22 *lang.Keyword = tmp21; var tmp23 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp23 = A_arbace_g2a_print_emit_A_const_27; if lang.Util_Equiv_J_O__Z(tmp18, tmp20.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(jrt.NN(tmp23).Get__O()))) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp24 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp24 = A_arbace_g2a_print_emit_A_const_50; if tmp24 != nil {


				var tmp25 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp25 = A_arbace_g2a_print_emit_A_const_23; var tmp26 *lang.Keyword = tmp25; var tmp27 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp27 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(jrt.NN(tmp26).Invoke_O__O(jrt.NN(tmp27).Get__O())) { var tmp28 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp28 = A_arbace_g2a_print_emit_A_const_92; lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(end__0) }
//line :320:1
				jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil } } } } else {
//line :318:1
					var tmp29 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp29 = A_arbace_g2a_print_emit_A_const_22; var tmp30 *lang.Keyword = tmp29; var tmp31 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp31 = A_arbace_g2a_print_emit_A_const_27; if jrt.A2g_Truth(jrt.NN(tmp30).Invoke_O__O(jrt.NN(tmp31).Get__O())) {





						var tmp32 any; var and__1927000168__auto____5_2 any; var or__1927000174__auto____5 any = multiline_QMARK___1; if jrt.A2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5_2 = or__1927000174__auto____5 } else { and__1927000168__auto____5_2 = always_QMARK___2 }; if jrt.A2g_Truth(and__1927000168__auto____5_2) { var tmp33 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp33 = A_arbace_g2a_print_emit_A_const_95; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_g2a_print_emit_A_Init(); tmp35 = A_arbace_g2a_print_emit_A_const_25; tmp32 = tmp34.Invoke_O__O(tmp35) } else { tmp32 = and__1927000168__auto____5_2 }; if jrt.A2g_Truth(tmp32) { var tmp36 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp36 = A_arbace_g2a_print_emit_A_const_76; lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(indent__3); jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } } else {
//line :318:1
							if jrt.A2g_Truth(always_QMARK___2) {






								var tmp37 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp37 = A_arbace_g2a_print_emit_A_const_76; lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(indent__3)
//line :318:1
								jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp38 *lang.Keyword; A_arbace_g2a_print_emit_A_Init(); tmp38 = A_arbace_g2a_print_emit_A_const_50; if tmp38 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
								}
								}
						}
				}
}




func A_arbace_g2a_print_emit_result_A_New() *A_arbace_g2a_print_emit_result_A { A_arbace_g2a_print_emit_result_A_Init(); t := &A_arbace_g2a_print_emit_result_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_g2a_print_emit_result_A) Ctor() {}
//line :328:1
func (t *A_arbace_g2a_print_emit_result_A) Invoke_O__O(self any) any { var s__1 any; var tmp1 *lang.Keyword;


	A_arbace_g2a_print_emit_A_Init(); tmp1 = A_arbace_g2a_print_emit_A_const_10; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp3 = A_arbace_g2a_print_emit_A_const_27; s__1 = jrt.NN(jrt.StringBuilder_Cast(jrt.NN(tmp2).Invoke_O__O(jrt.NN(tmp3).Get__O()))).ToString__String().Ref(); var s__2 any; var tmp4 /*line :328:1*/*lang.Var;



	A_arbace_g2a_print_emit_A_Init(); tmp4 = A_arbace_g2a_print_emit_A_const_97; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_print_emit_A_Init(); tmp6 = A_arbace_g2a_print_emit_A_const_99; s__2 = tmp5.Invoke_O_O_O__O(s__1, tmp6, Lit_115); var tmp7 /*line :333:1*/*lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp7 = A_arbace_g2a_print_emit_A_const_98; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var tmp10 *lang.Var; A_arbace_g2a_print_emit_A_Init(); tmp10 = A_arbace_g2a_print_emit_A_const_100; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_115)) { tmp9 = s__2 } else { tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_115), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() }; return tmp8.Invoke_O__O(tmp9) }


type A_arbace_g2a_print_emit_A struct{ jrt.Object }

var A_arbace_g2a_print_emit_A_const_0 *lang.Var

var A_arbace_g2a_print_emit_A_const_1 *lang.Var

var A_arbace_g2a_print_emit_A_const_2 any

var A_arbace_g2a_print_emit_A_const_3 any

var A_arbace_g2a_print_emit_A_const_4 any

var A_arbace_g2a_print_emit_A_const_5 *lang.Var

var A_arbace_g2a_print_emit_A_const_6 *lang.Var

var A_arbace_g2a_print_emit_A_const_7 *lang.Var

var A_arbace_g2a_print_emit_A_const_8 any

var A_arbace_g2a_print_emit_A_const_9 *lang.Var

var A_arbace_g2a_print_emit_A_const_10 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_11 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_12 *lang.Var

var A_arbace_g2a_print_emit_A_const_13 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_14 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_15 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_16 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_17 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_18 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_19 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_20 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_21 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_22 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_23 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_24 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_25 any

var A_arbace_g2a_print_emit_A_const_26 any

var A_arbace_g2a_print_emit_A_const_27 *lang.Var

var A_arbace_g2a_print_emit_A_const_28 *lang.Var

var A_arbace_g2a_print_emit_A_const_29 *lang.Var

var A_arbace_g2a_print_emit_A_const_30 *lang.Var

var A_arbace_g2a_print_emit_A_const_31 any

var A_arbace_g2a_print_emit_A_const_32 any

var A_arbace_g2a_print_emit_A_const_33 any

var A_arbace_g2a_print_emit_A_const_34 any

var A_arbace_g2a_print_emit_A_const_35 *lang.Var

var A_arbace_g2a_print_emit_A_const_36 any

var A_arbace_g2a_print_emit_A_const_37 any

var A_arbace_g2a_print_emit_A_const_38 any

var A_arbace_g2a_print_emit_A_const_39 *lang.Var

var A_arbace_g2a_print_emit_A_const_40 *lang.Var

var A_arbace_g2a_print_emit_A_const_41 any

var A_arbace_g2a_print_emit_A_const_42 any

var A_arbace_g2a_print_emit_A_const_43 any

var A_arbace_g2a_print_emit_A_const_44 any

var A_arbace_g2a_print_emit_A_const_45 any

var A_arbace_g2a_print_emit_A_const_46 *lang.Var

var A_arbace_g2a_print_emit_A_const_47 *lang.Var

var A_arbace_g2a_print_emit_A_const_48 any

var A_arbace_g2a_print_emit_A_const_49 *lang.Var

var A_arbace_g2a_print_emit_A_const_50 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_51 any

var A_arbace_g2a_print_emit_A_const_52 any

var A_arbace_g2a_print_emit_A_const_53 any

var A_arbace_g2a_print_emit_A_const_54 any

var A_arbace_g2a_print_emit_A_const_55 any

var A_arbace_g2a_print_emit_A_const_56 any

var A_arbace_g2a_print_emit_A_const_57 any

var A_arbace_g2a_print_emit_A_const_58 any

var A_arbace_g2a_print_emit_A_const_59 any

var A_arbace_g2a_print_emit_A_const_60 any

var A_arbace_g2a_print_emit_A_const_61 any

var A_arbace_g2a_print_emit_A_const_62 any

var A_arbace_g2a_print_emit_A_const_63 *lang.Var

var A_arbace_g2a_print_emit_A_const_64 any

var A_arbace_g2a_print_emit_A_const_65 *lang.Var

var A_arbace_g2a_print_emit_A_const_66 any

var A_arbace_g2a_print_emit_A_const_67 *lang.Var

var A_arbace_g2a_print_emit_A_const_68 *lang.Var

var A_arbace_g2a_print_emit_A_const_69 any

var A_arbace_g2a_print_emit_A_const_70 *lang.Var

var A_arbace_g2a_print_emit_A_const_71 *lang.Var

var A_arbace_g2a_print_emit_A_const_72 *lang.Var

var A_arbace_g2a_print_emit_A_const_73 *lang.Var

var A_arbace_g2a_print_emit_A_const_74 any

var A_arbace_g2a_print_emit_A_const_75 any

var A_arbace_g2a_print_emit_A_const_76 *lang.Var

var A_arbace_g2a_print_emit_A_const_77 any

var A_arbace_g2a_print_emit_A_const_78 *lang.Var

var A_arbace_g2a_print_emit_A_const_79 *lang.Var

var A_arbace_g2a_print_emit_A_const_80 *lang.Var

var A_arbace_g2a_print_emit_A_const_81 *lang.Var

var A_arbace_g2a_print_emit_A_const_82 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_83 *lang.Var

var A_arbace_g2a_print_emit_A_const_84 *lang.Var

var A_arbace_g2a_print_emit_A_const_85 *lang.Var

var A_arbace_g2a_print_emit_A_const_86 *lang.Var

var A_arbace_g2a_print_emit_A_const_87 *lang.Var

var A_arbace_g2a_print_emit_A_const_88 *lang.Var

var A_arbace_g2a_print_emit_A_const_89 *lang.Var

var A_arbace_g2a_print_emit_A_const_90 any

var A_arbace_g2a_print_emit_A_const_91 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_92 *lang.Var

var A_arbace_g2a_print_emit_A_const_93 *lang.Var

var A_arbace_g2a_print_emit_A_const_94 *lang.Var

var A_arbace_g2a_print_emit_A_const_95 *lang.Var

var A_arbace_g2a_print_emit_A_const_96 *lang.Var

var A_arbace_g2a_print_emit_A_const_97 *lang.Var

var A_arbace_g2a_print_emit_A_const_98 *lang.Var

var A_arbace_g2a_print_emit_A_const_99 any

var A_arbace_g2a_print_emit_A_const_100 *lang.Var

var A_arbace_g2a_print_emit_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_A_Init() { if !A_arbace_g2a_print_emit_A_init.Done() { A_arbace_g2a_print_emit_A_init.Run(A_arbace_g2a_print_emit_A_clinit) } }

func A_arbace_g2a_print_emit_A_clinit() { A_arbace_g2a_print_emit_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_g2a_print_emit_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_g2a_print_emit_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_print_emit_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_g2a_print_emit_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_g2a_print_emit_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_g2a_print_emit_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_g2a_print_emit_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_g2a_print_emit_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_g2a_print_emit_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_g2a_print_emit_A_const_10 = lang.RT_Keyword_String_String__Keyword(nil, Lit_15); A_arbace_g2a_print_emit_A_const_11 = lang.RT_Keyword_String_String__Keyword(nil, Lit_16); A_arbace_g2a_print_emit_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_g2a_print_emit_A_const_13 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_g2a_print_emit_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_g2a_print_emit_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_g2a_print_emit_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_21); A_arbace_g2a_print_emit_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_22); A_arbace_g2a_print_emit_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_23); A_arbace_g2a_print_emit_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_24); A_arbace_g2a_print_emit_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_g2a_print_emit_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_g2a_print_emit_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_g2a_print_emit_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_g2a_print_emit_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_g2a_print_emit_A_const_25 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_g2a_print_emit_A_const_26 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_g2a_print_emit_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_30); A_arbace_g2a_print_emit_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_g2a_print_emit_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_g2a_print_emit_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_g2a_print_emit_A_const_31 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_30).Ref(); A_arbace_g2a_print_emit_A_const_32 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_9).Ref(); A_arbace_g2a_print_emit_A_const_33 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_30).Ref(); A_arbace_g2a_print_emit_A_const_34 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_30).Ref(); A_arbace_g2a_print_emit_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_g2a_print_emit_A_const_36 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_35).Ref(); A_arbace_g2a_print_emit_A_const_37 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_27).Ref(); A_arbace_g2a_print_emit_A_const_38 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_36).Ref(); A_arbace_g2a_print_emit_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_g2a_print_emit_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_g2a_print_emit_A_const_41 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(); A_arbace_g2a_print_emit_A_const_42 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_40).Ref(); A_arbace_g2a_print_emit_A_const_43 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_35).Ref(); A_arbace_g2a_print_emit_A_const_44 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_34).Ref(); A_arbace_g2a_print_emit_A_const_45 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_41).Ref(); A_arbace_g2a_print_emit_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_g2a_print_emit_A_const_47 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_g2a_print_emit_A_const_48 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,9,s1:]s1:)s2:++s6:returns11:fallthroughs5:breaks2:--s8:continues1:}", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_g2a_print_emit_A_const_49 = lang.RT_Var_String_String__Var(Lit_11, Lit_44); A_arbace_g2a_print_emit_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_g2a_print_emit_A_const_51 = jrt.Character_ValueOf_C__Character(95).Ref(); A_arbace_g2a_print_emit_A_const_52 = jrt.Character_ValueOf_C__Character(34).Ref(); A_arbace_g2a_print_emit_A_const_53 = jrt.Character_ValueOf_C__Character(39).Ref(); A_arbace_g2a_print_emit_A_const_54 = jrt.Character_ValueOf_C__Character(96).Ref(); A_arbace_g2a_print_emit_A_const_55 = jrt.Character_ValueOf_C__Character(43).Ref(); A_arbace_g2a_print_emit_A_const_56 = jrt.Character_ValueOf_C__Character(45).Ref(); A_arbace_g2a_print_emit_A_const_57 = jrt.Character_ValueOf_C__Character(47).Ref(); A_arbace_g2a_print_emit_A_const_58 = jrt.Character_ValueOf_C__Character(42).Ref(); A_arbace_g2a_print_emit_A_const_59 = jrt.Character_ValueOf_C__Character(60).Ref(); A_arbace_g2a_print_emit_A_const_60 = jrt.Character_ValueOf_C__Character(38).Ref(); A_arbace_g2a_print_emit_A_const_61 = jrt.Character_ValueOf_C__Character(94).Ref(); A_arbace_g2a_print_emit_A_const_62 = jrt.Character_ValueOf_C__Character(46).Ref(); A_arbace_g2a_print_emit_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_g2a_print_emit_A_const_64 = jrt.Pattern_Compile_String__Pattern(Lit_47).Ref(); A_arbace_g2a_print_emit_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_g2a_print_emit_A_const_66 = jrt.Character_ValueOf_C__Character(9).Ref(); A_arbace_g2a_print_emit_A_const_67 = lang.RT_Var_String_String__Var(Lit_11, Lit_49); A_arbace_g2a_print_emit_A_const_68 = lang.RT_Var_String_String__Var(Lit_11, Lit_50); A_arbace_g2a_print_emit_A_const_69 = jrt.Character_ValueOf_C__Character(32).Ref(); A_arbace_g2a_print_emit_A_const_70 = lang.RT_Var_String_String__Var(Lit_11, Lit_51); A_arbace_g2a_print_emit_A_const_71 = lang.RT_Var_String_String__Var(Lit_11, Lit_52); A_arbace_g2a_print_emit_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_g2a_print_emit_A_const_73 = lang.RT_Var_String_String__Var(Lit_3, Lit_54); A_arbace_g2a_print_emit_A_const_74 = jrt.Character_ValueOf_C__Character(10).Ref(); A_arbace_g2a_print_emit_A_const_75 = jrt.Character_ValueOf_C__Character(11).Ref(); A_arbace_g2a_print_emit_A_const_76 = lang.RT_Var_String_String__Var(Lit_11, Lit_55); A_arbace_g2a_print_emit_A_const_77 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_30).Ref(); A_arbace_g2a_print_emit_A_const_78 = lang.RT_Var_String_String__Var(Lit_11, Lit_56); A_arbace_g2a_print_emit_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_g2a_print_emit_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_g2a_print_emit_A_const_81 = lang.RT_Var_String_String__Var(Lit_6, Lit_59); A_arbace_g2a_print_emit_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_5); A_arbace_g2a_print_emit_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_g2a_print_emit_A_const_84 = lang.RT_Var_String_String__Var(Lit_11, Lit_61); A_arbace_g2a_print_emit_A_const_85 = lang.RT_Var_String_String__Var(Lit_11, Lit_62); A_arbace_g2a_print_emit_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_g2a_print_emit_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_g2a_print_emit_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_g2a_print_emit_A_const_89 = lang.RT_Var_String_String__Var(Lit_11, Lit_66); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_27).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; var tmp3 any = tmp2.Ref(); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; A_arbace_g2a_print_emit_A_const_90 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp5.Ref())); A_arbace_g2a_print_emit_A_const_91 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_g2a_print_emit_A_const_92 = lang.RT_Var_String_String__Var(Lit_11, Lit_68); A_arbace_g2a_print_emit_A_const_93 = lang.RT_Var_String_String__Var(Lit_11, Lit_69); A_arbace_g2a_print_emit_A_const_94 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); A_arbace_g2a_print_emit_A_const_95 = lang.RT_Var_String_String__Var(Lit_11, Lit_71); A_arbace_g2a_print_emit_A_const_96 = lang.RT_Var_String_String__Var(Lit_11, Lit_72); A_arbace_g2a_print_emit_A_const_97 = lang.RT_Var_String_String__Var(Lit_6, Lit_73); A_arbace_g2a_print_emit_A_const_98 = lang.RT_Var_String_String__Var(Lit_3, Lit_74); A_arbace_g2a_print_emit_A_const_99 = jrt.Pattern_Compile_String__Pattern(Lit_75).Ref(); A_arbace_g2a_print_emit_A_const_100 = lang.RT_Var_String_String__Var(Lit_6, Lit_76) }

func A_arbace_g2a_print_emit_A_New() *A_arbace_g2a_print_emit_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_A_class }

func (t *A_arbace_g2a_print_emit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_A); return ok }

func A_arbace_g2a_print_emit_A_Cast(x any) *A_arbace_g2a_print_emit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_A_class)) }; return v }



type A_arbace_g2a_print_emit_bol_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_bol_QMARK__A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_bol_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_bol_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_bol_QMARK__A_Init() { if !A_arbace_g2a_print_emit_bol_QMARK__A_init.Done() { A_arbace_g2a_print_emit_bol_QMARK__A_init.Run(A_arbace_g2a_print_emit_bol_QMARK__A_clinit) } }

func A_arbace_g2a_print_emit_bol_QMARK__A_clinit() { A_arbace_g2a_print_emit_bol_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_bol_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_bol_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_bol_QMARK__A_class }

func (t *A_arbace_g2a_print_emit_bol_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_bol_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_bol_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_bol_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_bol_QMARK__A); return ok }

func A_arbace_g2a_print_emit_bol_QMARK__A_Cast(x any) *A_arbace_g2a_print_emit_bol_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_bol_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_bol_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_emit_break_to_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_break_to_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_break_to_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_break_to_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_break_to_BANG__A_Init() { if !A_arbace_g2a_print_emit_break_to_BANG__A_init.Done() { A_arbace_g2a_print_emit_break_to_BANG__A_init.Run(A_arbace_g2a_print_emit_break_to_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_break_to_BANG__A_clinit() { A_arbace_g2a_print_emit_break_to_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_break_to_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_break_to_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_break_to_BANG__A_class }

func (t *A_arbace_g2a_print_emit_break_to_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_break_to_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_break_to_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_break_to_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_break_to_BANG__A); return ok }

func A_arbace_g2a_print_emit_break_to_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_break_to_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_break_to_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_break_to_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_chunk_state_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_chunk_state_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_chunk_state_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_chunk_state_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_chunk_state_A_Init() { if !A_arbace_g2a_print_emit_chunk_state_A_init.Done() { A_arbace_g2a_print_emit_chunk_state_A_init.Run(A_arbace_g2a_print_emit_chunk_state_A_clinit) } }

func A_arbace_g2a_print_emit_chunk_state_A_clinit() { A_arbace_g2a_print_emit_chunk_state_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_chunk_state_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_chunk_state_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_chunk_state_A_class }

func (t *A_arbace_g2a_print_emit_chunk_state_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_chunk_state_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_chunk_state_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_chunk_state_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_chunk_state_A); return ok }

func A_arbace_g2a_print_emit_chunk_state_A_Cast(x any) *A_arbace_g2a_print_emit_chunk_state_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_chunk_state_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_chunk_state_A_class)) }; return v }



type A_arbace_g2a_print_emit_close_break_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_close_break_BANG__A) Is_Compiler_AOTF4() {}

var A_arbace_g2a_print_emit_close_break_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_close_break_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_close_break_BANG__A_Init() { if !A_arbace_g2a_print_emit_close_break_BANG__A_init.Done() { A_arbace_g2a_print_emit_close_break_BANG__A_init.Run(A_arbace_g2a_print_emit_close_break_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_close_break_BANG__A_clinit() { A_arbace_g2a_print_emit_close_break_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_close_break_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_close_break_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_close_break_BANG__A_class }

func (t *A_arbace_g2a_print_emit_close_break_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_close_break_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_close_break_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_close_break_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_close_break_BANG__A); return ok }

func A_arbace_g2a_print_emit_close_break_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_close_break_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_close_break_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_close_break_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_comment_line_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_comment_line_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_emit_comment_line_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_comment_line_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_comment_line_A_Init() { if !A_arbace_g2a_print_emit_comment_line_A_init.Done() { A_arbace_g2a_print_emit_comment_line_A_init.Run(A_arbace_g2a_print_emit_comment_line_A_clinit) } }

func A_arbace_g2a_print_emit_comment_line_A_clinit() { A_arbace_g2a_print_emit_comment_line_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_comment_line_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_comment_line_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_comment_line_A_class }

func (t *A_arbace_g2a_print_emit_comment_line_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_comment_line_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_comment_line_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_comment_line_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_comment_line_A); return ok }

func A_arbace_g2a_print_emit_comment_line_A_Cast(x any) *A_arbace_g2a_print_emit_comment_line_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_comment_line_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_comment_line_A_class)) }; return v }



type A_arbace_g2a_print_emit_cont_indent_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_cont_indent_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_cont_indent_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_cont_indent_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_cont_indent_A_Init() { if !A_arbace_g2a_print_emit_cont_indent_A_init.Done() { A_arbace_g2a_print_emit_cont_indent_A_init.Run(A_arbace_g2a_print_emit_cont_indent_A_clinit) } }

func A_arbace_g2a_print_emit_cont_indent_A_clinit() { A_arbace_g2a_print_emit_cont_indent_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_cont_indent_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_cont_indent_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_cont_indent_A_class }

func (t *A_arbace_g2a_print_emit_cont_indent_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_cont_indent_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_cont_indent_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_cont_indent_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_cont_indent_A); return ok }

func A_arbace_g2a_print_emit_cont_indent_A_Cast(x any) *A_arbace_g2a_print_emit_cont_indent_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_cont_indent_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_cont_indent_A_class)) }; return v }



type A_arbace_g2a_print_emit_cur_indent_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_cur_indent_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_cur_indent_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_cur_indent_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_cur_indent_A_Init() { if !A_arbace_g2a_print_emit_cur_indent_A_init.Done() { A_arbace_g2a_print_emit_cur_indent_A_init.Run(A_arbace_g2a_print_emit_cur_indent_A_clinit) } }

func A_arbace_g2a_print_emit_cur_indent_A_clinit() { A_arbace_g2a_print_emit_cur_indent_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_cur_indent_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_cur_indent_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_cur_indent_A_class }

func (t *A_arbace_g2a_print_emit_cur_indent_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_cur_indent_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_cur_indent_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_cur_indent_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_cur_indent_A); return ok }

func A_arbace_g2a_print_emit_cur_indent_A_Cast(x any) *A_arbace_g2a_print_emit_cur_indent_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_cur_indent_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_cur_indent_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000004_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000004_A_New() *A_arbace_g2a_print_emit_eval1256000004_A { t := &A_arbace_g2a_print_emit_eval1256000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000004_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000004_A); return ok }

func A_arbace_g2a_print_emit_eval1256000004_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000004_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_Init() { if !A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_init.Done() { A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_init.Run(A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_clinit) } }

func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_clinit() { A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A); return ok }

func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000008_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000008_A_New() *A_arbace_g2a_print_emit_eval1256000008_A { t := &A_arbace_g2a_print_emit_eval1256000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000008_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000008_A); return ok }

func A_arbace_g2a_print_emit_eval1256000008_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000008_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_Init() { if !A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_init.Done() { A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_init.Run(A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_clinit) } }

func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_clinit() { A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A); return ok }

func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000018_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000018_A_New() *A_arbace_g2a_print_emit_eval1256000018_A { t := &A_arbace_g2a_print_emit_eval1256000018_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000018_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000018_A); return ok }

func A_arbace_g2a_print_emit_eval1256000018_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000018_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_Init() { if !A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_init.Done() { A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_init.Run(A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_clinit) } }

func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_clinit() { A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A); return ok }

func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000029_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000029_A_New() *A_arbace_g2a_print_emit_eval1256000029_A { t := &A_arbace_g2a_print_emit_eval1256000029_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000029_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000029_A); return ok }

func A_arbace_g2a_print_emit_eval1256000029_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000029_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_Init() { if !A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_init.Done() { A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_init.Run(A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_clinit) } }

func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_clinit() { A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A); return ok }

func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000040_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000040_A_New() *A_arbace_g2a_print_emit_eval1256000040_A { t := &A_arbace_g2a_print_emit_eval1256000040_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000040_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000040_A); return ok }

func A_arbace_g2a_print_emit_eval1256000040_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000040_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_Init() { if !A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_init.Done() { A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_init.Run(A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_clinit) } }

func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_clinit() { A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A); return ok }

func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000052_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000052_A_New() *A_arbace_g2a_print_emit_eval1256000052_A { t := &A_arbace_g2a_print_emit_eval1256000052_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000052_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000052_A); return ok }

func A_arbace_g2a_print_emit_eval1256000052_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000052_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_Init() { if !A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_init.Done() { A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_init.Run(A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_clinit) } }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_clinit() { A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A); return ok }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000075_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000075_A_New() *A_arbace_g2a_print_emit_eval1256000075_A { t := &A_arbace_g2a_print_emit_eval1256000075_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000075_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000075_A); return ok }

func A_arbace_g2a_print_emit_eval1256000075_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000075_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_Init() { if !A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_init.Done() { A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_init.Run(A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_clinit) } }

func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_clinit() { A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A); return ok }

func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_class)) }; return v }



type A_arbace_g2a_print_emit_join_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_join_BANG__A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_emit_join_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_join_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_join_BANG__A_Init() { if !A_arbace_g2a_print_emit_join_BANG__A_init.Done() { A_arbace_g2a_print_emit_join_BANG__A_init.Run(A_arbace_g2a_print_emit_join_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_join_BANG__A_clinit() { A_arbace_g2a_print_emit_join_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_93, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_join_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_join_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_join_BANG__A_class }

func (t *A_arbace_g2a_print_emit_join_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_join_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_join_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_join_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_join_BANG__A); return ok }

func A_arbace_g2a_print_emit_join_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_join_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_join_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_join_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_line_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_line_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_line_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_line_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_line_A_Init() { if !A_arbace_g2a_print_emit_line_A_init.Done() { A_arbace_g2a_print_emit_line_A_init.Run(A_arbace_g2a_print_emit_line_A_clinit) } }

func A_arbace_g2a_print_emit_line_A_clinit() { A_arbace_g2a_print_emit_line_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_line_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_line_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_line_A_class }

func (t *A_arbace_g2a_print_emit_line_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_line_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_line_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_line_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_line_A); return ok }

func A_arbace_g2a_print_emit_line_A_Cast(x any) *A_arbace_g2a_print_emit_line_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_line_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_line_A_class)) }; return v }



type A_arbace_g2a_print_emit_line_directive_inline_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_line_directive_inline_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_line_directive_inline_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_line_directive_inline_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_line_directive_inline_A_Init() { if !A_arbace_g2a_print_emit_line_directive_inline_A_init.Done() { A_arbace_g2a_print_emit_line_directive_inline_A_init.Run(A_arbace_g2a_print_emit_line_directive_inline_A_clinit) } }

func A_arbace_g2a_print_emit_line_directive_inline_A_clinit() { A_arbace_g2a_print_emit_line_directive_inline_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_line_directive_inline_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_line_directive_inline_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_line_directive_inline_A_class }

func (t *A_arbace_g2a_print_emit_line_directive_inline_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_line_directive_inline_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_line_directive_inline_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_line_directive_inline_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_line_directive_inline_A); return ok }

func A_arbace_g2a_print_emit_line_directive_inline_A_Cast(x any) *A_arbace_g2a_print_emit_line_directive_inline_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_line_directive_inline_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_line_directive_inline_A_class)) }; return v }



type A_arbace_g2a_print_emit_line_directive_own_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_line_directive_own_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_line_directive_own_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_line_directive_own_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_line_directive_own_A_Init() { if !A_arbace_g2a_print_emit_line_directive_own_A_init.Done() { A_arbace_g2a_print_emit_line_directive_own_A_init.Run(A_arbace_g2a_print_emit_line_directive_own_A_clinit) } }

func A_arbace_g2a_print_emit_line_directive_own_A_clinit() { A_arbace_g2a_print_emit_line_directive_own_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_line_directive_own_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_line_directive_own_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_line_directive_own_A_class }

func (t *A_arbace_g2a_print_emit_line_directive_own_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_line_directive_own_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_line_directive_own_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_line_directive_own_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_line_directive_own_A); return ok }

func A_arbace_g2a_print_emit_line_directive_own_A_Cast(x any) *A_arbace_g2a_print_emit_line_directive_own_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_line_directive_own_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_line_directive_own_A_class)) }; return v }



type A_arbace_g2a_print_emit_lines_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_lines_QMARK__A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_lines_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_lines_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_lines_QMARK__A_Init() { if !A_arbace_g2a_print_emit_lines_QMARK__A_init.Done() { A_arbace_g2a_print_emit_lines_QMARK__A_init.Run(A_arbace_g2a_print_emit_lines_QMARK__A_clinit) } }

func A_arbace_g2a_print_emit_lines_QMARK__A_clinit() { A_arbace_g2a_print_emit_lines_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_101, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_lines_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_lines_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_lines_QMARK__A_class }

func (t *A_arbace_g2a_print_emit_lines_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_lines_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_lines_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_lines_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_lines_QMARK__A); return ok }

func A_arbace_g2a_print_emit_lines_QMARK__A_Cast(x any) *A_arbace_g2a_print_emit_lines_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_lines_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_lines_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_emit_may_combine_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_emit_may_combine_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_may_combine_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_may_combine_QMARK__A_Init() { if !A_arbace_g2a_print_emit_may_combine_QMARK__A_init.Done() { A_arbace_g2a_print_emit_may_combine_QMARK__A_init.Run(A_arbace_g2a_print_emit_may_combine_QMARK__A_clinit) } }

func A_arbace_g2a_print_emit_may_combine_QMARK__A_clinit() { A_arbace_g2a_print_emit_may_combine_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_may_combine_QMARK__A_class }

func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_may_combine_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_may_combine_QMARK__A); return ok }

func A_arbace_g2a_print_emit_may_combine_QMARK__A_Cast(x any) *A_arbace_g2a_print_emit_may_combine_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_may_combine_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_may_combine_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_emit_new_state_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_new_state_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_new_state_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_new_state_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_new_state_A_Init() { if !A_arbace_g2a_print_emit_new_state_A_init.Done() { A_arbace_g2a_print_emit_new_state_A_init.Run(A_arbace_g2a_print_emit_new_state_A_clinit) } }

func A_arbace_g2a_print_emit_new_state_A_clinit() { A_arbace_g2a_print_emit_new_state_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_new_state_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_new_state_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_new_state_A_class }

func (t *A_arbace_g2a_print_emit_new_state_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_new_state_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_new_state_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_new_state_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_new_state_A); return ok }

func A_arbace_g2a_print_emit_new_state_A_Cast(x any) *A_arbace_g2a_print_emit_new_state_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_new_state_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_new_state_A_class)) }; return v }



type A_arbace_g2a_print_emit_nl_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_nl_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_g2a_print_emit_nl_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_nl_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_nl_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_nl_A_Init() { if !A_arbace_g2a_print_emit_nl_A_init.Done() { A_arbace_g2a_print_emit_nl_A_init.Run(A_arbace_g2a_print_emit_nl_A_clinit) } }

func A_arbace_g2a_print_emit_nl_A_clinit() { A_arbace_g2a_print_emit_nl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_nl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_nl_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_nl_A_class }

func (t *A_arbace_g2a_print_emit_nl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_nl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_nl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_nl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_nl_A); return ok }

func A_arbace_g2a_print_emit_nl_A_Cast(x any) *A_arbace_g2a_print_emit_nl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_nl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_nl_A_class)) }; return v }



type A_arbace_g2a_print_emit_pop_open_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_pop_open_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_pop_open_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_pop_open_BANG__A_Init() { if !A_arbace_g2a_print_emit_pop_open_BANG__A_init.Done() { A_arbace_g2a_print_emit_pop_open_BANG__A_init.Run(A_arbace_g2a_print_emit_pop_open_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_pop_open_BANG__A_clinit() { A_arbace_g2a_print_emit_pop_open_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_pop_open_BANG__A_class }

func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_pop_open_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_pop_open_BANG__A); return ok }

func A_arbace_g2a_print_emit_pop_open_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_pop_open_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_pop_open_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_pop_open_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_push_open_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Is_Compiler_AOTF1() {}

func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_push_open_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_push_open_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_push_open_BANG__A_Init() { if !A_arbace_g2a_print_emit_push_open_BANG__A_init.Done() { A_arbace_g2a_print_emit_push_open_BANG__A_init.Run(A_arbace_g2a_print_emit_push_open_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_push_open_BANG__A_clinit() { A_arbace_g2a_print_emit_push_open_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_push_open_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_push_open_BANG__A_class }

func (t *A_arbace_g2a_print_emit_push_open_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_push_open_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_push_open_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_push_open_BANG__A); return ok }

func A_arbace_g2a_print_emit_push_open_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_push_open_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_push_open_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_push_open_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_raw_tok_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_raw_tok_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_raw_tok_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_raw_tok_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_raw_tok_A_Init() { if !A_arbace_g2a_print_emit_raw_tok_A_init.Done() { A_arbace_g2a_print_emit_raw_tok_A_init.Run(A_arbace_g2a_print_emit_raw_tok_A_clinit) } }

func A_arbace_g2a_print_emit_raw_tok_A_clinit() { A_arbace_g2a_print_emit_raw_tok_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_raw_tok_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_raw_tok_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_raw_tok_A_class }

func (t *A_arbace_g2a_print_emit_raw_tok_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_raw_tok_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_raw_tok_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_raw_tok_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_raw_tok_A); return ok }

func A_arbace_g2a_print_emit_raw_tok_A_Cast(x any) *A_arbace_g2a_print_emit_raw_tok_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_raw_tok_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_raw_tok_A_class)) }; return v }



type A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_Init() { if !A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_init.Done() { A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_init.Run(A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_clinit) } }

func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_clinit() { A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_class }

func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A); return ok }

func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_Cast(x any) *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_class)) }; return v }



type A_arbace_g2a_print_emit_render_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_render_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_render_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_render_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_render_A_Init() { if !A_arbace_g2a_print_emit_render_A_init.Done() { A_arbace_g2a_print_emit_render_A_init.Run(A_arbace_g2a_print_emit_render_A_clinit) } }

func A_arbace_g2a_print_emit_render_A_clinit() { A_arbace_g2a_print_emit_render_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_render_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_render_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_render_A_class }

func (t *A_arbace_g2a_print_emit_render_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_render_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_render_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_render_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_render_A); return ok }

func A_arbace_g2a_print_emit_render_A_Cast(x any) *A_arbace_g2a_print_emit_render_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_render_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_render_A_class)) }; return v }



type A_arbace_g2a_print_emit_result_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_result_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_result_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_result_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_result_A_Init() { if !A_arbace_g2a_print_emit_result_A_init.Done() { A_arbace_g2a_print_emit_result_A_init.Run(A_arbace_g2a_print_emit_result_A_clinit) } }

func A_arbace_g2a_print_emit_result_A_clinit() { A_arbace_g2a_print_emit_result_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_result_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_result_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_result_A_class }

func (t *A_arbace_g2a_print_emit_result_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_result_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_result_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_result_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_result_A); return ok }

func A_arbace_g2a_print_emit_result_A_Cast(x any) *A_arbace_g2a_print_emit_result_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_result_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_result_A_class)) }; return v }



type A_arbace_g2a_print_emit_room_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_room_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_room_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_room_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_room_QMARK__A_Init() { if !A_arbace_g2a_print_emit_room_QMARK__A_init.Done() { A_arbace_g2a_print_emit_room_QMARK__A_init.Run(A_arbace_g2a_print_emit_room_QMARK__A_clinit) } }

func A_arbace_g2a_print_emit_room_QMARK__A_clinit() { A_arbace_g2a_print_emit_room_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_room_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_room_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_room_QMARK__A_class }

func (t *A_arbace_g2a_print_emit_room_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_room_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_room_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_room_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_room_QMARK__A); return ok }

func A_arbace_g2a_print_emit_room_QMARK__A_Cast(x any) *A_arbace_g2a_print_emit_room_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_room_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_room_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_emit_semi_after_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_semi_after_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_semi_after_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_semi_after_QMARK__A_Init() { if !A_arbace_g2a_print_emit_semi_after_QMARK__A_init.Done() { A_arbace_g2a_print_emit_semi_after_QMARK__A_init.Run(A_arbace_g2a_print_emit_semi_after_QMARK__A_clinit) } }

func A_arbace_g2a_print_emit_semi_after_QMARK__A_clinit() { A_arbace_g2a_print_emit_semi_after_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_semi_after_QMARK__A_class }

func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_semi_after_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_semi_after_QMARK__A); return ok }

func A_arbace_g2a_print_emit_semi_after_QMARK__A_Cast(x any) *A_arbace_g2a_print_emit_semi_after_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_semi_after_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_semi_after_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_emit_set_line_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_set_line_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_set_line_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_set_line_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_set_line_BANG__A_Init() { if !A_arbace_g2a_print_emit_set_line_BANG__A_init.Done() { A_arbace_g2a_print_emit_set_line_BANG__A_init.Run(A_arbace_g2a_print_emit_set_line_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_set_line_BANG__A_clinit() { A_arbace_g2a_print_emit_set_line_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_set_line_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_set_line_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_set_line_BANG__A_class }

func (t *A_arbace_g2a_print_emit_set_line_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_set_line_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_set_line_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_set_line_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_set_line_BANG__A); return ok }

func A_arbace_g2a_print_emit_set_line_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_set_line_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_set_line_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_set_line_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_sp_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_sp_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_sp_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_sp_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_sp_A_Init() { if !A_arbace_g2a_print_emit_sp_A_init.Done() { A_arbace_g2a_print_emit_sp_A_init.Run(A_arbace_g2a_print_emit_sp_A_clinit) } }

func A_arbace_g2a_print_emit_sp_A_clinit() { A_arbace_g2a_print_emit_sp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_sp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_sp_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_sp_A_class }

func (t *A_arbace_g2a_print_emit_sp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_sp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_sp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_sp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_sp_A); return ok }

func A_arbace_g2a_print_emit_sp_A_Cast(x any) *A_arbace_g2a_print_emit_sp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_sp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_sp_A_class)) }; return v }



type A_arbace_g2a_print_emit_start_at_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_start_at_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_start_at_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_start_at_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_start_at_BANG__A_Init() { if !A_arbace_g2a_print_emit_start_at_BANG__A_init.Done() { A_arbace_g2a_print_emit_start_at_BANG__A_init.Run(A_arbace_g2a_print_emit_start_at_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_start_at_BANG__A_clinit() { A_arbace_g2a_print_emit_start_at_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_start_at_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_start_at_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_start_at_BANG__A_class }

func (t *A_arbace_g2a_print_emit_start_at_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_start_at_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_start_at_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_start_at_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_start_at_BANG__A); return ok }

func A_arbace_g2a_print_emit_start_at_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_start_at_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_start_at_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_start_at_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_start_line_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_start_line_BANG__A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_start_line_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_start_line_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_start_line_BANG__A_Init() { if !A_arbace_g2a_print_emit_start_line_BANG__A_init.Done() { A_arbace_g2a_print_emit_start_line_BANG__A_init.Run(A_arbace_g2a_print_emit_start_line_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_start_line_BANG__A_clinit() { A_arbace_g2a_print_emit_start_line_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_start_line_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_start_line_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_start_line_BANG__A_class }

func (t *A_arbace_g2a_print_emit_start_line_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_start_line_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_start_line_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_start_line_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_start_line_BANG__A); return ok }

func A_arbace_g2a_print_emit_start_line_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_start_line_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_start_line_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_start_line_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_stmt_break_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) Is_Compiler_AOTF4() {}

var A_arbace_g2a_print_emit_stmt_break_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_stmt_break_BANG__A_init jrt.ClassInit

func A_arbace_g2a_print_emit_stmt_break_BANG__A_Init() { if !A_arbace_g2a_print_emit_stmt_break_BANG__A_init.Done() { A_arbace_g2a_print_emit_stmt_break_BANG__A_init.Run(A_arbace_g2a_print_emit_stmt_break_BANG__A_clinit) } }

func A_arbace_g2a_print_emit_stmt_break_BANG__A_clinit() { A_arbace_g2a_print_emit_stmt_break_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_stmt_break_BANG__A_class }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_stmt_break_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_stmt_break_BANG__A); return ok }

func A_arbace_g2a_print_emit_stmt_break_BANG__A_Cast(x any) *A_arbace_g2a_print_emit_stmt_break_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_stmt_break_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_stmt_break_BANG__A_class)) }; return v }



type A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A struct{ jrt.Object; F_indent any }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_Init() { if !A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_init.Done() { A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_init.Run(A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_clinit) } }

func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_clinit() { A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_class }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A); return ok }

func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_Cast(x any) *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_class)) }; return v }



type A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A struct{ jrt.Object; F_first_QMARK_, F_sep any }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_Init() { if !A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_init.Done() { A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_init.Run(A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_clinit) } }

func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_clinit() { A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_class }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A); return ok }

func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_Cast(x any) *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_class)) }; return v }



type A_arbace_g2a_print_emit_target_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_target_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_target_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_target_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_target_A_Init() { if !A_arbace_g2a_print_emit_target_A_init.Done() { A_arbace_g2a_print_emit_target_A_init.Run(A_arbace_g2a_print_emit_target_A_clinit) } }

func A_arbace_g2a_print_emit_target_A_clinit() { A_arbace_g2a_print_emit_target_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_target_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_target_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_target_A_class }

func (t *A_arbace_g2a_print_emit_target_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_target_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_target_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_target_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_target_A); return ok }

func A_arbace_g2a_print_emit_target_A_Cast(x any) *A_arbace_g2a_print_emit_target_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_target_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_target_A_class)) }; return v }



type A_arbace_g2a_print_emit_tok_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_tok_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_emit_tok_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_tok_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_tok_A_Init() { if !A_arbace_g2a_print_emit_tok_A_init.Done() { A_arbace_g2a_print_emit_tok_A_init.Run(A_arbace_g2a_print_emit_tok_A_clinit) } }

func A_arbace_g2a_print_emit_tok_A_clinit() { A_arbace_g2a_print_emit_tok_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_tok_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_tok_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_tok_A_class }

func (t *A_arbace_g2a_print_emit_tok_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_tok_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_tok_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_tok_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_tok_A); return ok }

func A_arbace_g2a_print_emit_tok_A_Cast(x any) *A_arbace_g2a_print_emit_tok_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_tok_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_tok_A_class)) }; return v }



type A_arbace_g2a_print_emit_vtab_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_emit_vtab_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_emit_vtab_A_fn_class *jrt.Class

var A_arbace_g2a_print_emit_vtab_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_vtab_A_Init() { if !A_arbace_g2a_print_emit_vtab_A_init.Done() { A_arbace_g2a_print_emit_vtab_A_init.Run(A_arbace_g2a_print_emit_vtab_A_clinit) } }

func A_arbace_g2a_print_emit_vtab_A_clinit() { A_arbace_g2a_print_emit_vtab_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_emit_vtab_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_vtab_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_vtab_A_class }

func (t *A_arbace_g2a_print_emit_vtab_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_vtab_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_vtab_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_vtab_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_vtab_A); return ok }

func A_arbace_g2a_print_emit_vtab_A_Cast(x any) *A_arbace_g2a_print_emit_vtab_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_vtab_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_vtab_A_class)) }; return v }
