//line aot_arbace_g2a_print_emit.ae:1
package aot_arbace_g2a_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_New() *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_3, A_arbace_g2a_print_emit_A_const_4); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_New() *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_9), A_arbace_g2a_print_emit_A_const_7.GetRawRoot__O(), A_arbace_g2a_print_emit_A_const_8) }

















func A_arbace_g2a_print_emit_new_state_A_New() *A_arbace_g2a_print_emit_new_state_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_new_state_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_g2a_print_emit_new_state_A) Ctor() {}
//line :19:1
func (t *A_arbace_g2a_print_emit_new_state_A) Invoke_O_O__O(self, opts__0 any) any { var tmp1 any = A_arbace_g2a_print_emit_A_const_10; var tmp2 any = jrt.StringBuilder_New(); var tmp3 any = A_arbace_g2a_print_emit_A_const_11; var tmp4 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25); var tmp5 any = A_arbace_g2a_print_emit_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; var tmp8 any = tmp6.Invoke_O__O(tmp7.Ref()); var tmp9 any = A_arbace_g2a_print_emit_A_const_14; var tmp10 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_26); var tmp11 any = A_arbace_g2a_print_emit_A_const_15; var tmp12 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_26); var tmp13 any = A_arbace_g2a_print_emit_A_const_16; var tmp14 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()).Invoke_O__O(Lit_2); var tmp15 any = A_arbace_g2a_print_emit_A_const_17; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_FALSE; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 any = A_arbace_g2a_print_emit_A_const_18; var tmp20 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()).Invoke_O__O(nil); var tmp21 any = A_arbace_g2a_print_emit_A_const_19; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()); var tmp23 *lang.PersistentVector; lang.PersistentVector_Init(); tmp23 = lang.PersistentVector_EMPTY; var tmp24 any = tmp22.Invoke_O__O(tmp23.Ref()); var tmp25 any = A_arbace_g2a_print_emit_A_const_20; var tmp26 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_26); var tmp27 any = A_arbace_g2a_print_emit_A_const_21; var tmp28 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25); var tmp29 any = A_arbace_g2a_print_emit_A_const_22; var tmp30 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_g2a_print_emit_A_const_22.Invoke_O__O(opts__0))).Ref(); var tmp31 any = A_arbace_g2a_print_emit_A_const_23; var tmp32 lang.IFn = A_arbace_g2a_print_emit_A_const_24; var tmp33 *jrt.Boolean; jrt.Boolean_Init(); tmp33 = jrt.Boolean_TRUE; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp18, tmp19, tmp20, tmp21, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32.Invoke_O_O__O(opts__0, tmp33.Ref()))) }

















func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_New() *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) Ctor() {}
//line :37:1
func (t *A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_22), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_31))) }
//line :37:1
func A_arbace_g2a_print_emit_lines_QMARK__A_New() *A_arbace_g2a_print_emit_lines_QMARK__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_lines_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_g2a_print_emit_lines_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_g2a_print_emit_lines_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_22; return tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()) }
func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_New() *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) Ctor() {}
//line :38:1
func (t *A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_32), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_11), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_33)))))) }
//line :38:1
func A_arbace_g2a_print_emit_line_A_New() *A_arbace_g2a_print_emit_line_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_line_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_g2a_print_emit_line_A) Ctor() {}
//line :38:1
func (t *A_arbace_g2a_print_emit_line_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) }
func A_arbace_g2a_print_emit_bol_QMARK__A_New() *A_arbace_g2a_print_emit_bol_QMARK__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_bol_QMARK__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_g2a_print_emit_bol_QMARK__A) Ctor() {}
//line :39:1
func (t *A_arbace_g2a_print_emit_bol_QMARK__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_13; return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) }
//line :39:1
func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_New() *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) Ctor() {}
//line :39:1
func (t *A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_32), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_13), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_34)))))) }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_New() *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) Ctor() {}
//line :41:1
func (t *A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A) Invoke_O_O__O(self, f__1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_36), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_37)))), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_38), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_40.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_41), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_11), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_42), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(f__1))))))))))), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_43), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_44), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_41)))), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_45), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_41)))))))))))) }
//line :41:1
func A_arbace_g2a_print_emit_target_A_New() *A_arbace_g2a_print_emit_target_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_target_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_g2a_print_emit_target_A) Ctor() {}
//line :41:1
func (t *A_arbace_g2a_print_emit_target_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_22; if jrt.A2g_Truth(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) { var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; var l__1256000046__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__0)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(l__1256000046__auto____2)) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(l__1256000046__auto____2)).Ref() } else { return nil } } else { return nil } }







func A_arbace_g2a_print_emit_room_QMARK__A_New() *A_arbace_g2a_print_emit_room_QMARK__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_room_QMARK__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_g2a_print_emit_room_QMARK__A) Ctor() {}
//line :49:1
func (t *A_arbace_g2a_print_emit_room_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_22; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_46.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())); if



	jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z(A_arbace_g2a_print_emit_A_const_47.Get__O(), nil); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(A_arbace_g2a_print_emit_A_const_47.Get__O()), lang.Numbers_Add_O_J__Number(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())), lang.RT_LongCast_O__J(n__0)))).Ref() } } }









func A_arbace_g2a_print_emit_semi_after_QMARK__A_New() *A_arbace_g2a_print_emit_semi_after_QMARK__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_semi_after_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_g2a_print_emit_semi_after_QMARK__A) Invoke_O_O__O(self, s__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_48).Invoke_O__O(s__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_49.GetRawRoot__O()).Invoke_O__O(s__0)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if lang.Numbers_IsZero_J__Z(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if A_arbace_g2a_print_emit_A_const_50 != nil { var c__2 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())))); var or__1927000174__auto____3 bool = jrt.Character_IsLetterOrDigit_C__Z(c__2)




		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_51)).CharValue__C()); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_52)).CharValue__C()); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_53)).CharValue__C()); if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_C_C__Z(c__2, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_54)).CharValue__C()); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else {
			return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_J_J__Z(int64(lang.RT_IntCast_C__I(c__2)), 127)).Ref() } } } } } } else {
//line :66:1
				return nil
			}
	}
	}
	}
}


func A_arbace_g2a_print_emit_may_combine_QMARK__A_New() *A_arbace_g2a_print_emit_may_combine_QMARK__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_may_combine_QMARK__A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) Ctor() {}
//line :74:1
func (t *A_arbace_g2a_print_emit_may_combine_QMARK__A) Invoke_O_O_O__O(self, prev__0, next__1 any) any {



	var tmp1 bool; var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())); if and__1927000168__auto____3 { tmp1 = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(next__1)).Length__I())) } else { tmp1 = and__1927000168__auto____3 }; if tmp1 { var p__3 uint16 = jrt.NN(jrt.String_Cast(prev__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.String_Cast(prev__0)).Length__I())))); var n__4 uint16 = jrt.NN(jrt.String_Cast(next__1)).CharAt_I__C(lang.RT_IntCast_J__I(0)); var or__1927000174__auto____5 bool; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_7)


		if and__1927000168__auto____5 { or__1927000174__auto____5 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_55)).CharValue__C()) } else { or__1927000174__auto____5 = and__1927000168__auto____5 }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_8)
			if and__1927000168__auto____6 { or__1927000174__auto____6 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_56)).CharValue__C()) } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :81:1
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z(p__3, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_57)).CharValue__C())

				if and__1927000168__auto____7 { var or__1927000174__auto____8 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_58)).CharValue__C()); if or__1927000174__auto____8 { or__1927000174__auto____7 = or__1927000174__auto____8 } else { or__1927000174__auto____7 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_57)).CharValue__C()) } } else { or__1927000174__auto____7 = and__1927000168__auto____7 }
//line :81:1
				if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8_2 bool; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_9)


					if and__1927000168__auto____8 { var or__1927000174__auto____9 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_56)).CharValue__C()); if or__1927000174__auto____9 { or__1927000174__auto____8_2 = or__1927000174__auto____9 } else { or__1927000174__auto____8_2 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_59)).CharValue__C()) } } else { or__1927000174__auto____8_2 = and__1927000168__auto____8 }
//line :81:1
					if or__1927000174__auto____8_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8_2).Ref() } else { var or__1927000174__auto____9_2 bool; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(prev__0, Lit_10)



						if and__1927000168__auto____9 { var or__1927000174__auto____10 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_60)).CharValue__C()); if or__1927000174__auto____10 { or__1927000174__auto____9_2 = or__1927000174__auto____10 } else { or__1927000174__auto____9_2 = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_61)).CharValue__C()) } } else { or__1927000174__auto____9_2 = and__1927000168__auto____9 }
//line :81:1
						if or__1927000174__auto____9_2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____9_2).Ref() } else { var or__1927000174__auto____10_2 any; var and__1927000168__auto____10 bool = jrt.Character_IsDigit_C__Z(p__3)




							if and__1927000168__auto____10 { var and__1927000168__auto____11 bool = lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_62)).CharValue__C()); if and__1927000168__auto____11 { or__1927000174__auto____10_2 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_63.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_64, prev__0) } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____10_2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() }
//line :81:1
							if jrt.A2g_Truth(or__1927000174__auto____10_2) { return or__1927000174__auto____10_2 } else { var and__1927000168__auto____11_2 bool; var or__1927000174__auto____11 bool = jrt.Character_IsLetterOrDigit_C__Z(p__3)





								if or__1927000174__auto____11 { and__1927000168__auto____11_2 = or__1927000174__auto____11 } else { and__1927000168__auto____11_2 = lang.Util_Equiv_C_C__Z(p__3, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_51)).CharValue__C()) }; if and__1927000168__auto____11_2 { var or__1927000174__auto____12 bool = jrt.Character_IsLetterOrDigit_C__Z(n__4)
									if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____12).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_C_C__Z(n__4, jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_emit_A_const_51)).CharValue__C())).Ref() } } else {
//line :87:1
										return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11_2).Ref() } } } } } } } } else {
//line :78:1
											return nil
										}
}









func A_arbace_g2a_print_emit_start_line_BANG__A_New() *A_arbace_g2a_print_emit_start_line_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_start_line_BANG__A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_g2a_print_emit_start_line_BANG__A) Ctor() {}
//line :90:1
func (t *A_arbace_g2a_print_emit_start_line_BANG__A) Invoke_O__O(self any) any { var p__1 any = A_arbace_g2a_print_emit_A_const_27.Get__O(); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(p__1))) { var n__2 int64 = lang.Numbers_Max_J_J__J(0, lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_14.Invoke_O__O(p__1)))); var sb__3 any = A_arbace_g2a_print_emit_A_const_10.Invoke_O__O(p__1); var n__1927000701__auto____4 int64 = lang.RT_LongCast_J__J(n__2); var ___5 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(___5, n__1927000701__auto____4) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_g2a_print_emit_A_const_66); ___5 = lang.Numbers_Unchecked_inc_J__J(___5); continue L1 }
//line :92:1
		break L1
	}


		lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_15.Invoke_O__O(p__1), jrt.Long_ValueOf_J__Long(n__2).Ref())
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(p__1); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())
		return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__1), nil) } else {
//line :92:1
			return nil } }







func A_arbace_g2a_print_emit_tok_A_New() *A_arbace_g2a_print_emit_tok_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_tok_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_g2a_print_emit_tok_A) Ctor() {}
//line :100:1
func (t *A_arbace_g2a_print_emit_tok_A) Invoke_O_O__O(self, s__0 any) any { var p__2 any = A_arbace_g2a_print_emit_A_const_27.Get__O(); var sb__3 any = A_arbace_g2a_print_emit_A_const_10.Invoke_O__O(p__2); var at_bol__4 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(p__2));




	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_67.GetRawRoot__O()).Invoke__O(); var ws__5 any = /*line :100:1*/lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__2)); if






	jrt.A2g_Truth(at_bol__4) { } else { if jrt.A2g_Truth(ws__5) {

		jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C(ws__5)) } else {
//line :107:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_68.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_16.Invoke_O__O(p__2)), s__0)) {


				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_O__StringBuilder(A_arbace_g2a_print_emit_A_const_69) } } };
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__2), nil);
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(s__0));
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_16.Invoke_O__O(p__2), s__0);
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_17.Invoke_O__O(p__2), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_70.GetRawRoot__O()).Invoke_O__O(s__0)); return nil }


func A_arbace_g2a_print_emit_raw_tok_A_New() *A_arbace_g2a_print_emit_raw_tok_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_raw_tok_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_g2a_print_emit_raw_tok_A) Ctor() {}
//line :117:1
func (t *A_arbace_g2a_print_emit_raw_tok_A) Invoke_O_O__O(self, s__0 any) any {



	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_73.GetRawRoot__O()).Invoke_O__O(s__0))
	var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; var tmp2 *lang.Volatile = lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())); var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; var tmp4 any = jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Deref__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_72.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_New(); var tmp7 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_fn_class = fncls__1d; tmp7 = fncls__1d } else { tmp7 = fncls__1 }; jrt.NN(tmp2).Reset_O__O(lang.Numbers_Add_O_J__Number(tmp4, int64(lang.RT_Count_O__I(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), s__0)))))
	var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()); var tmp9 *lang.Keyword = A_arbace_g2a_print_emit_A_const_17; var tmp10 any = tmp9.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; return tmp8.Invoke_O_O__O(tmp10, tmp11.Ref()) }
//line :122:1
func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_New() *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) Ctor() {}
//line :122:1
func (t *A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A) Invoke_O_O__O(self, p1__1256000063_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__1256000063_SHARP___1, A_arbace_g2a_print_emit_A_const_74)).Ref() }


func A_arbace_g2a_print_emit_sp_A_New() *A_arbace_g2a_print_emit_sp_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_sp_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_g2a_print_emit_sp_A) Ctor() {}
//line :125:1
func (t *A_arbace_g2a_print_emit_sp_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { return nil } else {
		var tmp2 any = A_arbace_g2a_print_emit_A_const_75; var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_18; if lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { return nil } else { var tmp4 *lang.Keyword = A_arbace_g2a_print_emit_A_const_18; return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()), A_arbace_g2a_print_emit_A_const_69)
		} } }
func A_arbace_g2a_print_emit_vtab_A_New() *A_arbace_g2a_print_emit_vtab_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_vtab_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_g2a_print_emit_vtab_A) Ctor() {}
//line :131:1
func (t *A_arbace_g2a_print_emit_vtab_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { return nil } else {

		var tmp2 any = A_arbace_g2a_print_emit_A_const_75; var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_18; if lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { var tmp4 *lang.Keyword = A_arbace_g2a_print_emit_A_const_10; jrt.NN(jrt.StringBuilder_Cast(tmp4.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Append_C__StringBuilder(lang.RT_CharCast_J__C(11)) }
		var tmp5 *lang.Keyword = A_arbace_g2a_print_emit_A_const_18; return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()), jrt.Character_ValueOf_C__Character(lang.RT_CharCast_J__C(11)).Ref())
	} }
func A_arbace_g2a_print_emit_nl_A_New() *A_arbace_g2a_print_emit_nl_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_nl_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_g2a_print_emit_nl_A) Ctor() {}
//line :139:1
func (t *A_arbace_g2a_print_emit_nl_A) Invoke_O_O_O__O(self, indent__0, form_feed_QMARK___1 any) any { var p__3 any = A_arbace_g2a_print_emit_A_const_27.Get__O(); var sb__4 any = A_arbace_g2a_print_emit_A_const_10.Invoke_O__O(p__3);





	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__3), nil); var tmp1 /*line :146:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp2 uint16; if jrt.A2g_Truth(form_feed_QMARK___1) { tmp2 = lang.RT_CharCast_J__C(12) } else { tmp2 = lang.RT_CharCast_J__C(10) }; jrt.NN(tmp1).Append_C__StringBuilder(tmp2);
	jrt.NN(lang.Volatile_Cast(A_arbace_g2a_print_emit_A_const_11.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Inc_O__Number(jrt.NN(lang.Volatile_Cast(A_arbace_g2a_print_emit_A_const_11.Invoke_O__O(p__3))).Deref__O())); var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(p__3); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; tmp3.Invoke_O_O__O(tmp4, tmp5.Ref());
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_14.Invoke_O__O(p__3), indent__0); return nil }
//line :139:1
func (t *A_arbace_g2a_print_emit_nl_A) Invoke_O_O__O(self, indent__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(indent__0, tmp2.Ref())
}








func A_arbace_g2a_print_emit_cur_indent_A_New() *A_arbace_g2a_print_emit_cur_indent_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_cur_indent_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_g2a_print_emit_cur_indent_A) Ctor() {}
//line :152:1
func (t *A_arbace_g2a_print_emit_cur_indent_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_15; return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) }
//line :152:1
func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_New() *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) Ctor() {}
//line :152:1
func (t *A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_32), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_15), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_77)))))) }

func A_arbace_g2a_print_emit_push_open_BANG__A_New() *A_arbace_g2a_print_emit_push_open_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_push_open_BANG__A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Ctor() {}
//line :154:1
func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Invoke_O_O__O(self, indent__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_19; var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_19; jrt.NN(lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Reset_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Deref__O(), indent__0))
//line :154:1
	return nil }
//line :154:1
func (t *A_arbace_g2a_print_emit_push_open_BANG__A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_78.GetRawRoot__O()); var tmp2 any; var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { var tmp4 *lang.Keyword = A_arbace_g2a_print_emit_A_const_14; tmp2 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) } else { var tmp5 *lang.Keyword = A_arbace_g2a_print_emit_A_const_15; tmp2 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) }; return tmp1.Invoke_O__O(tmp2)
}

func A_arbace_g2a_print_emit_pop_open_BANG__A_New() *A_arbace_g2a_print_emit_pop_open_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_pop_open_BANG__A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) Ctor() {}
//line :160:1
func (t *A_arbace_g2a_print_emit_pop_open_BANG__A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_19; var o__1 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))); var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_19; var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_19;

	jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Reset_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_80.GetRawRoot__O()).Invoke_O__O(jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Deref__O())); return o__1 }


func A_arbace_g2a_print_emit_cont_indent_A_New() *A_arbace_g2a_print_emit_cont_indent_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_cont_indent_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_g2a_print_emit_cont_indent_A) Ctor() {}
//line :165:1
func (t *A_arbace_g2a_print_emit_cont_indent_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_19; var o__1 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))); var tmp2 any; var or__1927000174__auto____2 any = o__1; if



	jrt.A2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = A_arbace_g2a_print_emit_A_const_26 }; return jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(tmp2))).Ref() }

func A_arbace_g2a_print_emit_comment_line_A_New() *A_arbace_g2a_print_emit_comment_line_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_comment_line_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_g2a_print_emit_comment_line_A) Ctor() {}
//line :171:1
func (t *A_arbace_g2a_print_emit_comment_line_A) Invoke_O_O_O__O(self, s__0, indent__1 any) any { var p__3 any = A_arbace_g2a_print_emit_A_const_27.Get__O(); var sb__4 any = A_arbace_g2a_print_emit_A_const_10.Invoke_O__O(p__3); var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_13; if




	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { } else { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()).Invoke_O__O(indent__1) }; var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_emit_A_const_14.Invoke_O__O(p__3); var tmp4 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_81.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_1)) { tmp4 = A_arbace_g2a_print_emit_A_const_26 } else { tmp4 = indent__1 }; tmp2.Invoke_O_O__O(tmp3, tmp4);
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_67.GetRawRoot__O()).Invoke__O();
	jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_73.GetRawRoot__O()).Invoke_O__O(s__0)));
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_16.Invoke_O__O(p__3), Lit_2); var tmp5 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_print_emit_A_const_17.Invoke_O__O(p__3); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; tmp5.Invoke_O_O__O(tmp6, tmp7.Ref()); return /*line :182:1*/ lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()).Invoke_O__O(indent__1) }

func A_arbace_g2a_print_emit_set_line_BANG__A_New() *A_arbace_g2a_print_emit_set_line_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_set_line_BANG__A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_g2a_print_emit_set_line_BANG__A) Ctor() {}
//line :184:1
func (t *A_arbace_g2a_print_emit_set_line_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()), l__0)
	var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_21; var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_21; return jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Reset_O__O(lang.Numbers_Min_O_J__O(jrt.NN(lang.Volatile_Cast(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Deref__O(), lang.RT_LongCast_O__J(l__0)))
}














func A_arbace_g2a_print_emit_start_at_BANG__A_New() *A_arbace_g2a_print_emit_start_at_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_start_at_BANG__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_g2a_print_emit_start_at_BANG__A) Ctor() {}
//line :204:1
func (t *A_arbace_g2a_print_emit_start_at_BANG__A) Invoke_O_O__O(self, l__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()), l__0)
	var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_21; return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()), l__0)
}
func A_arbace_g2a_print_emit_chunk_state_A_New() *A_arbace_g2a_print_emit_chunk_state_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_chunk_state_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_g2a_print_emit_chunk_state_A) Ctor() {}
//line :210:1
func (t *A_arbace_g2a_print_emit_chunk_state_A) Invoke_O__O(self any) any { var p__1 any = A_arbace_g2a_print_emit_A_const_27.Get__O(); var tmp1 any = A_arbace_g2a_print_emit_A_const_82; var tmp2 any = jrt.NN(jrt.StringBuilder_Cast(A_arbace_g2a_print_emit_A_const_10.Invoke_O__O(p__1))).ToString__String().Ref(); var tmp3 any = A_arbace_g2a_print_emit_A_const_11; var tmp4 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_11.Invoke_O__O(p__1)); var tmp5 any = A_arbace_g2a_print_emit_A_const_13; var tmp6 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(p__1)); var tmp7 any = A_arbace_g2a_print_emit_A_const_14; var tmp8 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_14.Invoke_O__O(p__1)); var tmp9 any = A_arbace_g2a_print_emit_A_const_15; var tmp10 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_15.Invoke_O__O(p__1)); var tmp11 any = A_arbace_g2a_print_emit_A_const_16; var tmp12 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_16.Invoke_O__O(p__1)); var tmp13 any = A_arbace_g2a_print_emit_A_const_17; var tmp14 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_17.Invoke_O__O(p__1)); var tmp15 any = A_arbace_g2a_print_emit_A_const_18; var tmp16 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__1)); var tmp17 any = A_arbace_g2a_print_emit_A_const_19; var tmp18 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_19.Invoke_O__O(p__1)); var tmp19 any = A_arbace_g2a_print_emit_A_const_20; var tmp20 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_20.Invoke_O__O(p__1)); var tmp21 any = A_arbace_g2a_print_emit_A_const_21; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_21.Invoke_O__O(p__1)))) }









func A_arbace_g2a_print_emit_join_BANG__A_New() *A_arbace_g2a_print_emit_join_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_join_BANG__A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_g2a_print_emit_join_BANG__A) Ctor() {}
//line :220:1
func (t *A_arbace_g2a_print_emit_join_BANG__A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var p__3 any = A_arbace_g2a_print_emit_A_const_27.Get__O(); var l__4 int64 = lang.RT_LongCast_O__J(l__1); var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(p__3)); if





	jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool = lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_11.Invoke_O__O(p__3))), l__4); if and__1927000168__auto____6 { var and__1927000168__auto____7 bool = lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_14.Invoke_O__O(p__3)))); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__3)), nil); if and__1927000168__auto____8 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_19.Invoke_O__O(p__3))); if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool = lang.Numbers_Lt_J_J__Z(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_20.Invoke_O__O(p__3))), l__4); if and__1927000168__auto____10 {
		tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gte_J_J__Z(lang.RT_LongCast_O__J(A_arbace_g2a_print_emit_A_const_21.Invoke_O__O(c__0)), l__4)).Ref() } else {
//line :226:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else { tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) {

				jrt.NN(jrt.StringBuilder_Cast(A_arbace_g2a_print_emit_A_const_10.Invoke_O__O(p__3))).Append_String__StringBuilder(jrt.String_Cast(A_arbace_g2a_print_emit_A_const_82.Invoke_O__O(c__0)))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_11.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_11.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_13.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_14.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_14.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_15.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_15.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_16.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_16.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_17.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_17.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(c__0))
				lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_19.Invoke_O__O(p__3), A_arbace_g2a_print_emit_A_const_19.Invoke_O__O(c__0))
				jrt.NN(lang.Volatile_Cast(A_arbace_g2a_print_emit_A_const_20.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Max_O_J__O(jrt.NN(lang.Volatile_Cast(A_arbace_g2a_print_emit_A_const_20.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J(A_arbace_g2a_print_emit_A_const_20.Invoke_O__O(c__0))))
				jrt.NN(lang.Volatile_Cast(A_arbace_g2a_print_emit_A_const_21.Invoke_O__O(p__3))).Reset_O__O(lang.Numbers_Min_O_J__O(jrt.NN(lang.Volatile_Cast(A_arbace_g2a_print_emit_A_const_21.Invoke_O__O(p__3))).Deref__O(), lang.RT_LongCast_O__J(A_arbace_g2a_print_emit_A_const_21.Invoke_O__O(c__0))))
//line :226:1
				jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } }















func A_arbace_g2a_print_emit_line_directive_inline_A_New() *A_arbace_g2a_print_emit_line_directive_inline_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_line_directive_inline_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_g2a_print_emit_line_directive_inline_A) Ctor() {}
//line :242:1
func (t *A_arbace_g2a_print_emit_line_directive_inline_A) Invoke_O_O__O(self, n__0 any) any { var p__2 any = A_arbace_g2a_print_emit_A_const_27.Get__O(); var sb__3 any = A_arbace_g2a_print_emit_A_const_10.Invoke_O__O(p__2);



	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_67.GetRawRoot__O()).Invoke__O(); var temp__1927000414__auto____4 any = /*line :242:1*/lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__2)); if




	jrt.A2g_Truth(temp__1927000414__auto____4) { var ws__5 any = temp__1927000414__auto____4; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(lang.RT_CharCast_O__C(ws__5)) };
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)));
	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_emit_A_const_18.Invoke_O__O(p__2), nil); return /*line :250:1*/ lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_84.GetRawRoot__O()).Invoke_O__O(n__0) }

func A_arbace_g2a_print_emit_line_directive_own_A_New() *A_arbace_g2a_print_emit_line_directive_own_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_line_directive_own_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_g2a_print_emit_line_directive_own_A) Ctor() {}
//line :252:1
func (t *A_arbace_g2a_print_emit_line_directive_own_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_14; var ind__2 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()));



	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(), ind__2); return /*line :257:1*/ lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_84.GetRawRoot__O()).Invoke_O__O(n__0) }




func A_arbace_g2a_print_emit_render_A_New() *A_arbace_g2a_print_emit_render_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_render_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_g2a_print_emit_render_A) Ctor() {}
//line :262:1
func (t *A_arbace_g2a_print_emit_render_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_88.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_emit_A_const_27; lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_87.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_89.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_90), A_arbace_g2a_print_emit_A_const_47, nil))
//line :262:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		lang.IFn_Cast(f__0).Invoke__O()
		{ var tmp4 *lang.Keyword = A_arbace_g2a_print_emit_A_const_10; tmp3 = jrt.NN(jrt.StringBuilder_Cast(tmp4.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).ToString__String().Ref() }
//line :262:1
		return nil
	}()


	lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_86.GetRawRoot__O()).Invoke__O()
//line :262:1
	if tmp5 != nil { panic(tmp5) }; return tmp3
}







func A_arbace_g2a_print_emit_break_to_BANG__A_New() *A_arbace_g2a_print_emit_break_to_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_break_to_BANG__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_g2a_print_emit_break_to_BANG__A) Ctor() {}
//line :271:1
func (t *A_arbace_g2a_print_emit_break_to_BANG__A) Invoke_O_O__O(self, t__0 any) any {



	if jrt.A2g_Truth(t__0) { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_20; var mark__2 any = tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()); var brk_QMARK___3 bool = lang.Util_Equiv_O_O__Z(t__0, A_arbace_g2a_print_emit_A_const_91); var t__4 any





		if brk_QMARK___3 { var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; t__4 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) } else { var tmp4 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; t__4 = lang.Numbers_Max_J_O__O(lang.Numbers_Inc_J__J(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(mark__2))), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) } } else { t__4 = t__0 }
		jrt.NN(lang.Volatile_Cast(mark__2)).Reset_O__O(lang.Numbers_Max_O_O__O(jrt.NN(lang.Volatile_Cast(mark__2)).Deref__O(), t__4))
		var tmp5 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; if lang.Numbers_Gt_O_O__Z(t__4, lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) {

			var tmp6 any; var tmp7 *lang.Keyword = A_arbace_g2a_print_emit_A_const_17; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp8 *lang.Keyword = A_arbace_g2a_print_emit_A_const_13; tmp6 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) } else { tmp6 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp6) {
				var tmp9 *lang.Keyword = A_arbace_g2a_print_emit_A_const_23; if jrt.A2g_Truth(tmp9.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) { return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_92.GetRawRoot__O()).Invoke_O__O(t__4) } else { return nil } } else {
//line :285:1
					var ci__5 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_93.GetRawRoot__O()).Invoke__O(); L1: for {


						var tmp10 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; if lang.Numbers_Lt_O_O__Z(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())), t__4) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()).Invoke_O__O(ci__5); continue L1 } else { return nil } } } } else {
//line :283:1
							var tmp11 any; var tmp12 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; var and__1927000168__auto____5_2 bool = lang.Numbers_Lt_O_O__Z(t__4, lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())))





							if and__1927000168__auto____5_2 { var tmp13 *lang.Keyword = A_arbace_g2a_print_emit_A_const_23; tmp11 = tmp13.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()) } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() }
//line :283:1
							if jrt.A2g_Truth(tmp11) {






								return lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_92.GetRawRoot__O()).Invoke_O__O(t__4) } else {
//line :283:1
									return nil } } } else {
//line :275:1
										return nil }
//line :271:1
	panic("a2g: unreachable")
}



















func A_arbace_g2a_print_emit_stmt_break_BANG__A_New() *A_arbace_g2a_print_emit_stmt_break_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_stmt_break_BANG__A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) Ctor() {}
//line :292:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__A) Invoke_O_O_O_O_O__O(self, t__0, first_QMARK___1, sep__2, indent__3 any) any { var newline_BANG___5 any; var tmp1 any = A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_New_O(indent__3); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_fn_class; if





	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; newline_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var same_BANG___6 any; var tmp3 any = /*line :292:1*/A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_New_O_O(first_QMARK___1, sep__2); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_fn_class; if






	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; same_BANG___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(t__0)) { var tmp5 *lang.Keyword = A_arbace_g2a_print_emit_A_const_20; var tmp6 *lang.Keyword = A_arbace_g2a_print_emit_A_const_20; jrt.NN(lang.Volatile_Cast(tmp5.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Reset_O__O(lang.Numbers_Max_O_J__O(jrt.NN(lang.Volatile_Cast(tmp6.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Deref__O(), lang.RT_LongCast_O__J(t__0))) }; var tmp7 /*line :301:1*/*lang.Keyword = A_arbace_g2a_print_emit_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) {
		var tmp8 *lang.Keyword = A_arbace_g2a_print_emit_A_const_14; lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_65.GetRawRoot__O()).Invoke_O_O__O(tmp8.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()), indent__3)
//line :301:1
		jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp9 *lang.Keyword = A_arbace_g2a_print_emit_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_46.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) {

			return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25) } else {
//line :301:1
				if lang.Util_Identical_O_O__Z(t__0, nil) {


					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_95.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25)) { return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25) } else { return lang.IFn_Cast(same_BANG___6).Invoke__O() } } else {
//line :301:1
						if lang.Util_Equiv_O_O__Z(t__0, A_arbace_g2a_print_emit_A_const_91) {



							return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25) } else {
//line :301:1
								var tmp10 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; if lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(t__0), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) {




									var tmp11 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; return lang.IFn_Cast(newline_BANG___5).Invoke_O__O(lang.Numbers_Minus_J_O__Number(lang.RT_LongCast_O__J(t__0), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp11.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())))) } else {
//line :301:1
										var tmp12 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; if lang.Util_Equiv_J_O__Z(lang.RT_LongCast_O__J(t__0), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) {





											return lang.IFn_Cast(same_BANG___6).Invoke__O() } else {
//line :301:1
												if A_arbace_g2a_print_emit_A_const_50 != nil {






													lang.IFn_Cast(newline_BANG___5).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25)
													var tmp13 *lang.Keyword = A_arbace_g2a_print_emit_A_const_23; if jrt.A2g_Truth(tmp13.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_96.GetRawRoot__O()).Invoke_O__O(t__0) }
//line :301:1
													jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } } } }
//line :298:1
func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_New_O(p0 any) *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) Ctor_O(c__indent any) { t.F_indent = c__indent }
//line :298:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A) Invoke_O_O__O(self, n__1 any) any { var n__1927000701__auto____2 int64 = lang.RT_LongCast_O__J(lang.Numbers_Max_J_O__O(1, n__1)); var ___3 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(___3, n__1927000701__auto____2) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()).Invoke_O__O(t.F_indent); ___3 = lang.Numbers_Unchecked_inc_J__J(___3); continue L1 }; break L1 }; var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_20; var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_20; var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; jrt.NN(lang.Volatile_Cast(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Reset_O__O(lang.Numbers_Max_O_O__O(jrt.NN(lang.Volatile_Cast(tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).Deref__O(), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())))); jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }
func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :299:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) Ctor_O_O(c__first_QMARK_, c__sep any) { t.F_first_QMARK_ = c__first_QMARK_; t.F_sep = c__sep }
//line :299:1
func (t *A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A) Invoke_O__O(self any) any { if jrt.A2g_Truth(t.F_first_QMARK_) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_94.GetRawRoot__O()).Invoke__O() } else { if jrt.A2g_Truth(t.F_sep) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_71.GetRawRoot__O()).Invoke_O__O(t.F_sep) }; lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_94.GetRawRoot__O()).Invoke__O() }; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }












func A_arbace_g2a_print_emit_close_break_BANG__A_New() *A_arbace_g2a_print_emit_close_break_BANG__A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_close_break_BANG__A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_g2a_print_emit_close_break_BANG__A) Ctor() {}
//line :312:1
func (t *A_arbace_g2a_print_emit_close_break_BANG__A) Invoke_O_O_O_O_O__O(self, end__0, multiline_QMARK___1, always_QMARK___2, indent__3 any) any {





	var tmp1 any; var tmp2 *lang.Keyword = A_arbace_g2a_print_emit_A_const_22; var and__1927000168__auto____5 any = tmp2.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())
	if jrt.A2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(end__0) } else { tmp1 = and__1927000168__auto____5 }
//line :318:1
	if jrt.A2g_Truth(tmp1) {

		var tmp3 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; if lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(end__0), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { L1: for {
			var tmp4 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; if lang.Numbers_Lt_O_J__Z(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())), lang.RT_LongCast_O__J(end__0)) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()).Invoke_O__O(indent__3); continue L1 }
//line :320:1
			break L1 }; jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp5 *lang.Keyword = A_arbace_g2a_print_emit_A_const_11; if lang.Util_Equiv_J_O__Z(lang.RT_LongCast_O__J(end__0), lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_6.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if A_arbace_g2a_print_emit_A_const_50 != nil {


				var tmp6 *lang.Keyword = A_arbace_g2a_print_emit_A_const_23; if jrt.A2g_Truth(tmp6.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_92.GetRawRoot__O()).Invoke_O__O(end__0) }
//line :320:1
				jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil } } } } else {
//line :318:1
					var tmp7 *lang.Keyword = A_arbace_g2a_print_emit_A_const_22; if jrt.A2g_Truth(tmp7.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O())) {





						var tmp8 any; var and__1927000168__auto____5_2 any; var or__1927000174__auto____5 any = multiline_QMARK___1; if jrt.A2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5_2 = or__1927000174__auto____5 } else { and__1927000168__auto____5_2 = always_QMARK___2 }; if jrt.A2g_Truth(and__1927000168__auto____5_2) { tmp8 = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_95.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_emit_A_const_25) } else { tmp8 = and__1927000168__auto____5_2 }; if jrt.A2g_Truth(tmp8) { lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()).Invoke_O__O(indent__3); jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } } else {
//line :318:1
							if jrt.A2g_Truth(always_QMARK___2) {






								lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_76.GetRawRoot__O()).Invoke_O__O(indent__3)
//line :318:1
								jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if A_arbace_g2a_print_emit_A_const_50 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
								}
								}
						}
				}
}




func A_arbace_g2a_print_emit_result_A_New() *A_arbace_g2a_print_emit_result_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_result_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_g2a_print_emit_result_A) Ctor() {}
//line :328:1
func (t *A_arbace_g2a_print_emit_result_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_g2a_print_emit_A_const_10; var s__1 any = jrt.NN(jrt.StringBuilder_Cast(tmp1.Invoke_O__O(A_arbace_g2a_print_emit_A_const_27.Get__O()))).ToString__String().Ref(); var s__2 any = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(s__1, A_arbace_g2a_print_emit_A_const_99, Lit_12); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_98.GetRawRoot__O()); var tmp3 any; if




	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_emit_A_const_100.GetRawRoot__O()).Invoke_O_O__O(s__2, Lit_12)) { tmp3 = s__2 } else { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, s__2, nil)).Ref() }; return tmp2.Invoke_O__O(tmp3) }


type A_arbace_g2a_print_emit_A struct{ jrt.Object }

var A_arbace_g2a_print_emit_A_const_pool *jrt.RefArray

var A_arbace_g2a_print_emit_A_const_0 *lang.Var

var A_arbace_g2a_print_emit_A_const_1 *lang.Var

var A_arbace_g2a_print_emit_A_const_2 any

var A_arbace_g2a_print_emit_A_const_3 any

var A_arbace_g2a_print_emit_A_const_4 any

var A_arbace_g2a_print_emit_A_const_5 *lang.Var

var A_arbace_g2a_print_emit_A_const_6 *lang.Var

var A_arbace_g2a_print_emit_A_const_7 *lang.Var

var A_arbace_g2a_print_emit_A_const_8 any

var A_arbace_g2a_print_emit_A_const_9 *lang.Var

var A_arbace_g2a_print_emit_A_const_10 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_11 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_12 *lang.Var

var A_arbace_g2a_print_emit_A_const_13 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_14 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_15 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_16 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_17 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_18 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_19 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_20 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_21 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_22 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_23 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_24 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_25 any

var A_arbace_g2a_print_emit_A_const_26 any

var A_arbace_g2a_print_emit_A_const_27 *lang.Var

var A_arbace_g2a_print_emit_A_const_28 *lang.Var

var A_arbace_g2a_print_emit_A_const_29 *lang.Var

var A_arbace_g2a_print_emit_A_const_30 *lang.Var

var A_arbace_g2a_print_emit_A_const_31 any

var A_arbace_g2a_print_emit_A_const_32 any

var A_arbace_g2a_print_emit_A_const_33 any

var A_arbace_g2a_print_emit_A_const_34 any

var A_arbace_g2a_print_emit_A_const_35 *lang.Var

var A_arbace_g2a_print_emit_A_const_36 any

var A_arbace_g2a_print_emit_A_const_37 any

var A_arbace_g2a_print_emit_A_const_38 any

var A_arbace_g2a_print_emit_A_const_39 *lang.Var

var A_arbace_g2a_print_emit_A_const_40 *lang.Var

var A_arbace_g2a_print_emit_A_const_41 any

var A_arbace_g2a_print_emit_A_const_42 any

var A_arbace_g2a_print_emit_A_const_43 any

var A_arbace_g2a_print_emit_A_const_44 any

var A_arbace_g2a_print_emit_A_const_45 any

var A_arbace_g2a_print_emit_A_const_46 *lang.Var

var A_arbace_g2a_print_emit_A_const_47 *lang.Var

var A_arbace_g2a_print_emit_A_const_48 any

var A_arbace_g2a_print_emit_A_const_49 *lang.Var

var A_arbace_g2a_print_emit_A_const_50 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_51 any

var A_arbace_g2a_print_emit_A_const_52 any

var A_arbace_g2a_print_emit_A_const_53 any

var A_arbace_g2a_print_emit_A_const_54 any

var A_arbace_g2a_print_emit_A_const_55 any

var A_arbace_g2a_print_emit_A_const_56 any

var A_arbace_g2a_print_emit_A_const_57 any

var A_arbace_g2a_print_emit_A_const_58 any

var A_arbace_g2a_print_emit_A_const_59 any

var A_arbace_g2a_print_emit_A_const_60 any

var A_arbace_g2a_print_emit_A_const_61 any

var A_arbace_g2a_print_emit_A_const_62 any

var A_arbace_g2a_print_emit_A_const_63 *lang.Var

var A_arbace_g2a_print_emit_A_const_64 any

var A_arbace_g2a_print_emit_A_const_65 *lang.Var

var A_arbace_g2a_print_emit_A_const_66 any

var A_arbace_g2a_print_emit_A_const_67 *lang.Var

var A_arbace_g2a_print_emit_A_const_68 *lang.Var

var A_arbace_g2a_print_emit_A_const_69 any

var A_arbace_g2a_print_emit_A_const_70 *lang.Var

var A_arbace_g2a_print_emit_A_const_71 *lang.Var

var A_arbace_g2a_print_emit_A_const_72 *lang.Var

var A_arbace_g2a_print_emit_A_const_73 *lang.Var

var A_arbace_g2a_print_emit_A_const_74 any

var A_arbace_g2a_print_emit_A_const_75 any

var A_arbace_g2a_print_emit_A_const_76 *lang.Var

var A_arbace_g2a_print_emit_A_const_77 any

var A_arbace_g2a_print_emit_A_const_78 *lang.Var

var A_arbace_g2a_print_emit_A_const_79 *lang.Var

var A_arbace_g2a_print_emit_A_const_80 *lang.Var

var A_arbace_g2a_print_emit_A_const_81 *lang.Var

var A_arbace_g2a_print_emit_A_const_82 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_83 *lang.Var

var A_arbace_g2a_print_emit_A_const_84 *lang.Var

var A_arbace_g2a_print_emit_A_const_85 *lang.Var

var A_arbace_g2a_print_emit_A_const_86 *lang.Var

var A_arbace_g2a_print_emit_A_const_87 *lang.Var

var A_arbace_g2a_print_emit_A_const_88 *lang.Var

var A_arbace_g2a_print_emit_A_const_89 *lang.Var

var A_arbace_g2a_print_emit_A_const_90 any

var A_arbace_g2a_print_emit_A_const_91 *lang.Keyword

var A_arbace_g2a_print_emit_A_const_92 *lang.Var

var A_arbace_g2a_print_emit_A_const_93 *lang.Var

var A_arbace_g2a_print_emit_A_const_94 *lang.Var

var A_arbace_g2a_print_emit_A_const_95 *lang.Var

var A_arbace_g2a_print_emit_A_const_96 *lang.Var

var A_arbace_g2a_print_emit_A_const_97 *lang.Var

var A_arbace_g2a_print_emit_A_const_98 *lang.Var

var A_arbace_g2a_print_emit_A_const_99 any

var A_arbace_g2a_print_emit_A_const_100 *lang.Var

var A_arbace_g2a_print_emit_A_init jrt.ClassInit

func A_arbace_g2a_print_emit_A_Init() { if !A_arbace_g2a_print_emit_A_init.Done() { A_arbace_g2a_print_emit_A_init.Run(A_arbace_g2a_print_emit_A_clinit) } }

func A_arbace_g2a_print_emit_A_clinit() { A_arbace_g2a_print_emit_A_clinit_p0(); A_arbace_g2a_print_emit_A_clinit_p1(); A_arbace_g2a_print_emit_A_clinit_p2(); A_arbace_g2a_print_emit_A_clinit_p3(); A_arbace_g2a_print_emit_A_clinit_p4(); A_arbace_g2a_print_emit_A_clinit_p5(); A_arbace_g2a_print_emit_A_clinit_p6(); A_arbace_g2a_print_emit_A_clinit_p7() }

func A_arbace_g2a_print_emit_A_clinit_p0() { A_arbace_g2a_print_emit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 134); A_arbace_g2a_print_emit_A_const_0 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[33]); A_arbace_g2a_print_emit_A_const_1 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[34]); A_arbace_g2a_print_emit_A_const_2 = A_arbace_g2a_print_emit_A_const_pool.A[35]; A_arbace_g2a_print_emit_A_const_3 = A_arbace_g2a_print_emit_A_const_pool.A[36]; A_arbace_g2a_print_emit_A_const_4 = A_arbace_g2a_print_emit_A_const_pool.A[37]; A_arbace_g2a_print_emit_A_const_5 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[38]); A_arbace_g2a_print_emit_A_const_6 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[39]); A_arbace_g2a_print_emit_A_const_7 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[40]); A_arbace_g2a_print_emit_A_const_8 = A_arbace_g2a_print_emit_A_const_pool.A[41]; A_arbace_g2a_print_emit_A_const_9 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[42]); A_arbace_g2a_print_emit_A_const_10 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[43]); A_arbace_g2a_print_emit_A_const_11 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[44]) }

func A_arbace_g2a_print_emit_A_clinit_p1() { A_arbace_g2a_print_emit_A_const_12 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[45]); A_arbace_g2a_print_emit_A_const_13 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[46]); A_arbace_g2a_print_emit_A_const_14 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[47]); A_arbace_g2a_print_emit_A_const_15 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[48]); A_arbace_g2a_print_emit_A_const_16 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[49]); A_arbace_g2a_print_emit_A_const_17 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[50]); A_arbace_g2a_print_emit_A_const_18 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[51]); A_arbace_g2a_print_emit_A_const_19 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[52]); A_arbace_g2a_print_emit_A_const_20 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[53]); A_arbace_g2a_print_emit_A_const_21 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[54]); A_arbace_g2a_print_emit_A_const_22 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[55]); A_arbace_g2a_print_emit_A_const_23 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[56]) }

func A_arbace_g2a_print_emit_A_clinit_p2() { A_arbace_g2a_print_emit_A_const_24 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[57]); A_arbace_g2a_print_emit_A_const_25 = A_arbace_g2a_print_emit_A_const_pool.A[58]; A_arbace_g2a_print_emit_A_const_26 = A_arbace_g2a_print_emit_A_const_pool.A[59]; A_arbace_g2a_print_emit_A_const_27 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[60]); A_arbace_g2a_print_emit_A_const_28 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[61]); A_arbace_g2a_print_emit_A_const_29 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[62]); A_arbace_g2a_print_emit_A_const_30 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[63]); A_arbace_g2a_print_emit_A_const_31 = A_arbace_g2a_print_emit_A_const_pool.A[64]; A_arbace_g2a_print_emit_A_const_32 = A_arbace_g2a_print_emit_A_const_pool.A[65]; A_arbace_g2a_print_emit_A_const_33 = A_arbace_g2a_print_emit_A_const_pool.A[66]; A_arbace_g2a_print_emit_A_const_34 = A_arbace_g2a_print_emit_A_const_pool.A[67]; A_arbace_g2a_print_emit_A_const_35 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[68]); A_arbace_g2a_print_emit_A_const_36 = A_arbace_g2a_print_emit_A_const_pool.A[69]; A_arbace_g2a_print_emit_A_const_37 = A_arbace_g2a_print_emit_A_const_pool.A[70] }

func A_arbace_g2a_print_emit_A_clinit_p3() { A_arbace_g2a_print_emit_A_const_38 = A_arbace_g2a_print_emit_A_const_pool.A[71]; A_arbace_g2a_print_emit_A_const_39 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[72]); A_arbace_g2a_print_emit_A_const_40 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[73]); A_arbace_g2a_print_emit_A_const_41 = A_arbace_g2a_print_emit_A_const_pool.A[74]; A_arbace_g2a_print_emit_A_const_42 = A_arbace_g2a_print_emit_A_const_pool.A[75]; A_arbace_g2a_print_emit_A_const_43 = A_arbace_g2a_print_emit_A_const_pool.A[76]; A_arbace_g2a_print_emit_A_const_44 = A_arbace_g2a_print_emit_A_const_pool.A[77]; A_arbace_g2a_print_emit_A_const_45 = A_arbace_g2a_print_emit_A_const_pool.A[78]; A_arbace_g2a_print_emit_A_const_46 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[79]); A_arbace_g2a_print_emit_A_const_47 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[80]); A_arbace_g2a_print_emit_A_const_48 = A_arbace_g2a_print_emit_A_const_pool.A[81]; A_arbace_g2a_print_emit_A_const_49 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[82]); A_arbace_g2a_print_emit_A_const_50 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[83]); A_arbace_g2a_print_emit_A_const_51 = A_arbace_g2a_print_emit_A_const_pool.A[84] }

func A_arbace_g2a_print_emit_A_clinit_p4() { A_arbace_g2a_print_emit_A_const_52 = A_arbace_g2a_print_emit_A_const_pool.A[85]; A_arbace_g2a_print_emit_A_const_53 = A_arbace_g2a_print_emit_A_const_pool.A[86]; A_arbace_g2a_print_emit_A_const_54 = A_arbace_g2a_print_emit_A_const_pool.A[87]; A_arbace_g2a_print_emit_A_const_55 = A_arbace_g2a_print_emit_A_const_pool.A[88]; A_arbace_g2a_print_emit_A_const_56 = A_arbace_g2a_print_emit_A_const_pool.A[89]; A_arbace_g2a_print_emit_A_const_57 = A_arbace_g2a_print_emit_A_const_pool.A[90]; A_arbace_g2a_print_emit_A_const_58 = A_arbace_g2a_print_emit_A_const_pool.A[91]; A_arbace_g2a_print_emit_A_const_59 = A_arbace_g2a_print_emit_A_const_pool.A[92]; A_arbace_g2a_print_emit_A_const_60 = A_arbace_g2a_print_emit_A_const_pool.A[93]; A_arbace_g2a_print_emit_A_const_61 = A_arbace_g2a_print_emit_A_const_pool.A[94]; A_arbace_g2a_print_emit_A_const_62 = A_arbace_g2a_print_emit_A_const_pool.A[95]; A_arbace_g2a_print_emit_A_const_63 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[96]); A_arbace_g2a_print_emit_A_const_64 = A_arbace_g2a_print_emit_A_const_pool.A[97]; A_arbace_g2a_print_emit_A_const_65 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[98]); A_arbace_g2a_print_emit_A_const_66 = A_arbace_g2a_print_emit_A_const_pool.A[99] }

func A_arbace_g2a_print_emit_A_clinit_p5() { A_arbace_g2a_print_emit_A_const_67 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[100]); A_arbace_g2a_print_emit_A_const_68 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[101]); A_arbace_g2a_print_emit_A_const_69 = A_arbace_g2a_print_emit_A_const_pool.A[102]; A_arbace_g2a_print_emit_A_const_70 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[103]); A_arbace_g2a_print_emit_A_const_71 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[104]); A_arbace_g2a_print_emit_A_const_72 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[105]); A_arbace_g2a_print_emit_A_const_73 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[106]); A_arbace_g2a_print_emit_A_const_74 = A_arbace_g2a_print_emit_A_const_pool.A[107]; A_arbace_g2a_print_emit_A_const_75 = A_arbace_g2a_print_emit_A_const_pool.A[108]; A_arbace_g2a_print_emit_A_const_76 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[109]); A_arbace_g2a_print_emit_A_const_77 = A_arbace_g2a_print_emit_A_const_pool.A[110]; A_arbace_g2a_print_emit_A_const_78 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[111]); A_arbace_g2a_print_emit_A_const_79 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[112]) }

func A_arbace_g2a_print_emit_A_clinit_p6() { A_arbace_g2a_print_emit_A_const_80 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[113]); A_arbace_g2a_print_emit_A_const_81 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[114]); A_arbace_g2a_print_emit_A_const_82 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[115]); A_arbace_g2a_print_emit_A_const_83 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[116]); A_arbace_g2a_print_emit_A_const_84 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[117]); A_arbace_g2a_print_emit_A_const_85 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[118]); A_arbace_g2a_print_emit_A_const_86 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[119]); A_arbace_g2a_print_emit_A_const_87 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[120]); A_arbace_g2a_print_emit_A_const_88 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[121]); A_arbace_g2a_print_emit_A_const_89 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[122]); A_arbace_g2a_print_emit_A_const_90 = A_arbace_g2a_print_emit_A_const_pool.A[123]; A_arbace_g2a_print_emit_A_const_91 = lang.Keyword_Cast(A_arbace_g2a_print_emit_A_const_pool.A[124]) }

func A_arbace_g2a_print_emit_A_clinit_p7() { A_arbace_g2a_print_emit_A_const_92 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[125]); A_arbace_g2a_print_emit_A_const_93 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[126]); A_arbace_g2a_print_emit_A_const_94 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[127]); A_arbace_g2a_print_emit_A_const_95 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[128]); A_arbace_g2a_print_emit_A_const_96 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[129]); A_arbace_g2a_print_emit_A_const_97 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[130]); A_arbace_g2a_print_emit_A_const_98 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[131]); A_arbace_g2a_print_emit_A_const_99 = A_arbace_g2a_print_emit_A_const_pool.A[132]; A_arbace_g2a_print_emit_A_const_100 = lang.Var_Cast(A_arbace_g2a_print_emit_A_const_pool.A[133]) }

func A_arbace_g2a_print_emit_A_New() *A_arbace_g2a_print_emit_A { A_arbace_g2a_print_emit_A_Init(); t := &A_arbace_g2a_print_emit_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_A_class }

func (t *A_arbace_g2a_print_emit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_A); return ok }

func A_arbace_g2a_print_emit_A_Cast(x any) *A_arbace_g2a_print_emit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_A_class)) }; return v }



type A_arbace_g2a_print_emit_bol_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_bol_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_break_to_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_break_to_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_chunk_state_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_chunk_state_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_close_break_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_close_break_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_comment_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_comment_line_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_cont_indent_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_cont_indent_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_cur_indent_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_cur_indent_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_eval1256000004_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000004_A_New() *A_arbace_g2a_print_emit_eval1256000004_A { t := &A_arbace_g2a_print_emit_eval1256000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000004_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000004_A); return ok }

func A_arbace_g2a_print_emit_eval1256000004_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000004_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_eval1256000008_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000008_A_New() *A_arbace_g2a_print_emit_eval1256000008_A { t := &A_arbace_g2a_print_emit_eval1256000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000008_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000008_A); return ok }

func A_arbace_g2a_print_emit_eval1256000008_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000008_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_eval1256000018_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000018_A_New() *A_arbace_g2a_print_emit_eval1256000018_A { t := &A_arbace_g2a_print_emit_eval1256000018_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000018_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000018_A); return ok }

func A_arbace_g2a_print_emit_eval1256000018_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000018_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_eval1256000029_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000029_A_New() *A_arbace_g2a_print_emit_eval1256000029_A { t := &A_arbace_g2a_print_emit_eval1256000029_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000029_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000029_A); return ok }

func A_arbace_g2a_print_emit_eval1256000029_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000029_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_eval1256000040_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000040_A_New() *A_arbace_g2a_print_emit_eval1256000040_A { t := &A_arbace_g2a_print_emit_eval1256000040_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000040_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000040_A); return ok }

func A_arbace_g2a_print_emit_eval1256000040_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000040_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_eval1256000052_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000052_A_New() *A_arbace_g2a_print_emit_eval1256000052_A { t := &A_arbace_g2a_print_emit_eval1256000052_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000052_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000052_A); return ok }

func A_arbace_g2a_print_emit_eval1256000052_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000052_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_eval1256000075_A struct{ jrt.Object }

func A_arbace_g2a_print_emit_eval1256000075_A_New() *A_arbace_g2a_print_emit_eval1256000075_A { t := &A_arbace_g2a_print_emit_eval1256000075_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) Ctor() {}

func (t *A_arbace_g2a_print_emit_eval1256000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_emit_eval1256000075_A_class }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_emit_eval1256000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_emit_eval1256000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_emit_eval1256000075_A); return ok }

func A_arbace_g2a_print_emit_eval1256000075_A_Cast(x any) *A_arbace_g2a_print_emit_eval1256000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_emit_eval1256000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_emit_eval1256000075_A_class)) }; return v }



type A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_join_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_join_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_line_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_line_directive_inline_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_line_directive_inline_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_line_directive_own_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_line_directive_own_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_lines_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_lines_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_may_combine_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_may_combine_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_new_state_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_new_state_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_nl_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_nl_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_pop_open_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_pop_open_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_push_open_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_push_open_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_raw_tok_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_raw_tok_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_render_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_render_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_result_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_result_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_room_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_room_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_semi_after_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_semi_after_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_set_line_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_set_line_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_sp_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_sp_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_start_at_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_start_at_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_start_line_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_start_line_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_stmt_break_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_stmt_break_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A struct{ a2g_header uint64; F_indent any }

var A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A struct{ a2g_header uint64; F_first_QMARK_, F_sep any }

var A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_target_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_target_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_tok_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_tok_A_fn_class *jrt.Class



type A_arbace_g2a_print_emit_vtab_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_emit_vtab_A_fn_class *jrt.Class
