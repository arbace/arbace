//line a2g_classes.ae:1
package aot_arbace_g2a_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_print_emit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_A_New()}; return nil }

var A_arbace_g2a_print_emit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_A_new}

var A_arbace_g2a_print_emit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_A"})

func init() { i := A_arbace_g2a_print_emit_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_A_Init; i.Table = A_arbace_g2a_print_emit_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_A]()) }

func A_arbace_g2a_print_emit_bol_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_bol_QMARK__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_bol_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_bol_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_emit_bol_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_bol_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_bol_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_bol_QMARK__A_invoke, New: A_arbace_g2a_print_emit_bol_QMARK__A_new, Get: A_arbace_g2a_print_emit_bol_QMARK__A_get}

var A_arbace_g2a_print_emit_bol_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$bol_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "bol_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_bol_QMARK__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_bol_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_bol_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_bol_QMARK__A_Init; i.Table = A_arbace_g2a_print_emit_bol_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_bol_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_bol_QMARK__A]()) }

func A_arbace_g2a_print_emit_break_to_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_break_to_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_break_to_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_break_to_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_break_to_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_break_to_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_break_to_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_break_to_BANG__A_invoke, New: A_arbace_g2a_print_emit_break_to_BANG__A_new, Get: A_arbace_g2a_print_emit_break_to_BANG__A_get}

var A_arbace_g2a_print_emit_break_to_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$break_to_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "break_to_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_break_to_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_break_to_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_break_to_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_break_to_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_break_to_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_break_to_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_break_to_BANG__A]()) }

func A_arbace_g2a_print_emit_chunk_state_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_chunk_state_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_chunk_state_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_chunk_state_A_New()}; return nil }

func A_arbace_g2a_print_emit_chunk_state_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_chunk_state_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_chunk_state_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_chunk_state_A_invoke, New: A_arbace_g2a_print_emit_chunk_state_A_new, Get: A_arbace_g2a_print_emit_chunk_state_A_get}

var A_arbace_g2a_print_emit_chunk_state_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$chunk_state", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "chunk_state", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_chunk_state_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_chunk_state_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_chunk_state_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_chunk_state_A_Init; i.Table = A_arbace_g2a_print_emit_chunk_state_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_chunk_state_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_chunk_state_A]()) }

func A_arbace_g2a_print_emit_close_break_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_close_break_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_emit_close_break_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_close_break_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_close_break_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_close_break_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_close_break_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_close_break_BANG__A_invoke, New: A_arbace_g2a_print_emit_close_break_BANG__A_new, Get: A_arbace_g2a_print_emit_close_break_BANG__A_get}

var A_arbace_g2a_print_emit_close_break_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$close_break_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "close_break_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_close_break_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_close_break_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_close_break_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_close_break_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_close_break_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_close_break_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_close_break_BANG__A]()) }

func A_arbace_g2a_print_emit_comment_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_comment_line_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_emit_comment_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_comment_line_A_New()}; return nil }

func A_arbace_g2a_print_emit_comment_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_comment_line_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_comment_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_comment_line_A_invoke, New: A_arbace_g2a_print_emit_comment_line_A_new, Get: A_arbace_g2a_print_emit_comment_line_A_get}

var A_arbace_g2a_print_emit_comment_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$comment_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "comment_line", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_comment_line_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_comment_line_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_comment_line_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_comment_line_A_Init; i.Table = A_arbace_g2a_print_emit_comment_line_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_comment_line_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_comment_line_A]()) }

func A_arbace_g2a_print_emit_cont_indent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_cont_indent_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_cont_indent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_cont_indent_A_New()}; return nil }

func A_arbace_g2a_print_emit_cont_indent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_cont_indent_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_cont_indent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_cont_indent_A_invoke, New: A_arbace_g2a_print_emit_cont_indent_A_new, Get: A_arbace_g2a_print_emit_cont_indent_A_get}

var A_arbace_g2a_print_emit_cont_indent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$cont_indent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "cont_indent", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_cont_indent_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_cont_indent_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_cont_indent_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_cont_indent_A_Init; i.Table = A_arbace_g2a_print_emit_cont_indent_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_cont_indent_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_cont_indent_A]()) }

func A_arbace_g2a_print_emit_cur_indent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_cur_indent_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_cur_indent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_cur_indent_A_New()}; return nil }

func A_arbace_g2a_print_emit_cur_indent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_cur_indent_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_cur_indent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_cur_indent_A_invoke, New: A_arbace_g2a_print_emit_cur_indent_A_new, Get: A_arbace_g2a_print_emit_cur_indent_A_get}

var A_arbace_g2a_print_emit_cur_indent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$cur_indent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "cur_indent", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_cur_indent_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_cur_indent_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_cur_indent_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_cur_indent_A_Init; i.Table = A_arbace_g2a_print_emit_cur_indent_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_cur_indent_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_cur_indent_A]()) }

func A_arbace_g2a_print_emit_eval1256000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000004_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000004_A_new}

var A_arbace_g2a_print_emit_eval1256000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000004", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000004_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000004_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000004_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000004_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000004_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000004_A]()) }

func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_New()}; return nil }

func A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_invoke, New: A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_new, Get: A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_get}

var A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000004$loading__1927001464__auto____1256000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_eval1256000004_A_class, Simple: "loading__1927001464__auto____1256000005", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_Init; i.Table = A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A]()) }

func A_arbace_g2a_print_emit_eval1256000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000008_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000008_A_new}

var A_arbace_g2a_print_emit_eval1256000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000008", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000008_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000008_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000008_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000008_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000008_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000008_A]()) }

func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_New()}; return nil }

func A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_invoke, New: A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_new, Get: A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_get}

var A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000008$fn__1256000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_eval1256000008_A_class, Simple: "fn__1256000009", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_Init; i.Table = A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A]()) }

func A_arbace_g2a_print_emit_eval1256000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000018_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000018_A_new}

var A_arbace_g2a_print_emit_eval1256000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000018", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000018_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000018_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000018_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000018_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000018_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000018_A]()) }

func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_New()}; return nil }

func A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_invoke, New: A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_new, Get: A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_get}

var A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000018$lines_QMARK___1256000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_eval1256000018_A_class, Simple: "lines_QMARK___1256000019", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_Init; i.Table = A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A]()) }

func A_arbace_g2a_print_emit_eval1256000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000029_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000029_A_new}

var A_arbace_g2a_print_emit_eval1256000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000029", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000029_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000029_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000029_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000029_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000029_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000029_A]()) }

func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_New()}; return nil }

func A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_invoke, New: A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_new, Get: A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_get}

var A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000029$line__1256000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_eval1256000029_A_class, Simple: "line__1256000030", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_Init; i.Table = A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A]()) }

func A_arbace_g2a_print_emit_eval1256000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000040_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000040_A_new}

var A_arbace_g2a_print_emit_eval1256000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000040", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000040_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000040_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000040_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000040_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000040_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000040_A]()) }

func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_New()}; return nil }

func A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_invoke, New: A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_new, Get: A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_get}

var A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000040$bol_QMARK___1256000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_eval1256000040_A_class, Simple: "bol_QMARK___1256000041", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_Init; i.Table = A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A]()) }

func A_arbace_g2a_print_emit_eval1256000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000052_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000052_A_new}

var A_arbace_g2a_print_emit_eval1256000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000052", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000052_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000052_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000052_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000052_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000052_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000052_A]()) }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_New()}; return nil }

func A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_invoke, New: A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_new, Get: A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_get}

var A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000052$target__1256000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_eval1256000052_A_class, Simple: "target__1256000053", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_Init; i.Table = A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A]()) }

func A_arbace_g2a_print_emit_eval1256000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000075_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000075_A_new}

var A_arbace_g2a_print_emit_eval1256000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000075", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000075_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000075_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000075_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000075_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000075_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000075_A]()) }

func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_New()}; return nil }

func A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_invoke, New: A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_new, Get: A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_get}

var A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000075$cur_indent__1256000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_eval1256000075_A_class, Simple: "cur_indent__1256000076", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_Init; i.Table = A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A]()) }

func A_arbace_g2a_print_emit_join_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_join_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_emit_join_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_join_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_join_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_join_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_join_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_join_BANG__A_invoke, New: A_arbace_g2a_print_emit_join_BANG__A_new, Get: A_arbace_g2a_print_emit_join_BANG__A_get}

var A_arbace_g2a_print_emit_join_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$join_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "join_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_join_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_join_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_join_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_join_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_join_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_join_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_join_BANG__A]()) }

func A_arbace_g2a_print_emit_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_line_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_line_A_New()}; return nil }

func A_arbace_g2a_print_emit_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_line_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_line_A_invoke, New: A_arbace_g2a_print_emit_line_A_new, Get: A_arbace_g2a_print_emit_line_A_get}

var A_arbace_g2a_print_emit_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "line", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_line_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_line_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_line_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_line_A_Init; i.Table = A_arbace_g2a_print_emit_line_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_line_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_line_A]()) }

func A_arbace_g2a_print_emit_line_directive_inline_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_line_directive_inline_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_line_directive_inline_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_line_directive_inline_A_New()}; return nil }

func A_arbace_g2a_print_emit_line_directive_inline_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_line_directive_inline_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_line_directive_inline_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_line_directive_inline_A_invoke, New: A_arbace_g2a_print_emit_line_directive_inline_A_new, Get: A_arbace_g2a_print_emit_line_directive_inline_A_get}

var A_arbace_g2a_print_emit_line_directive_inline_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$line_directive_inline", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "line_directive_inline", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_line_directive_inline_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_line_directive_inline_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_line_directive_inline_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_line_directive_inline_A_Init; i.Table = A_arbace_g2a_print_emit_line_directive_inline_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_line_directive_inline_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_line_directive_inline_A]()) }

func A_arbace_g2a_print_emit_line_directive_own_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_line_directive_own_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_line_directive_own_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_line_directive_own_A_New()}; return nil }

func A_arbace_g2a_print_emit_line_directive_own_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_line_directive_own_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_line_directive_own_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_line_directive_own_A_invoke, New: A_arbace_g2a_print_emit_line_directive_own_A_new, Get: A_arbace_g2a_print_emit_line_directive_own_A_get}

var A_arbace_g2a_print_emit_line_directive_own_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$line_directive_own", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "line_directive_own", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_line_directive_own_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_line_directive_own_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_line_directive_own_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_line_directive_own_A_Init; i.Table = A_arbace_g2a_print_emit_line_directive_own_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_line_directive_own_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_line_directive_own_A]()) }

func A_arbace_g2a_print_emit_lines_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_lines_QMARK__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_lines_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_lines_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_emit_lines_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_lines_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_lines_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_lines_QMARK__A_invoke, New: A_arbace_g2a_print_emit_lines_QMARK__A_new, Get: A_arbace_g2a_print_emit_lines_QMARK__A_get}

var A_arbace_g2a_print_emit_lines_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$lines_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "lines_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_lines_QMARK__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_lines_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_lines_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_lines_QMARK__A_Init; i.Table = A_arbace_g2a_print_emit_lines_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_lines_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_lines_QMARK__A]()) }

func A_arbace_g2a_print_emit_may_combine_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_may_combine_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_emit_may_combine_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_may_combine_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_emit_may_combine_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_may_combine_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_may_combine_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_may_combine_QMARK__A_invoke, New: A_arbace_g2a_print_emit_may_combine_QMARK__A_new, Get: A_arbace_g2a_print_emit_may_combine_QMARK__A_get}

var A_arbace_g2a_print_emit_may_combine_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$may_combine_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "may_combine_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_may_combine_QMARK__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_may_combine_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_may_combine_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_may_combine_QMARK__A_Init; i.Table = A_arbace_g2a_print_emit_may_combine_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_may_combine_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_may_combine_QMARK__A]()) }

func A_arbace_g2a_print_emit_new_state_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_new_state_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_new_state_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_new_state_A_New()}; return nil }

func A_arbace_g2a_print_emit_new_state_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_new_state_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_new_state_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_new_state_A_invoke, New: A_arbace_g2a_print_emit_new_state_A_new, Get: A_arbace_g2a_print_emit_new_state_A_get}

var A_arbace_g2a_print_emit_new_state_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$new_state", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "new_state", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_new_state_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_new_state_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_new_state_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_new_state_A_Init; i.Table = A_arbace_g2a_print_emit_new_state_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_new_state_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_new_state_A]()) }

func A_arbace_g2a_print_emit_nl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_nl_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_g2a_print_emit_nl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_emit_nl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_nl_A_New()}; return nil }

func A_arbace_g2a_print_emit_nl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_nl_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_nl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_nl_A_invoke, New: A_arbace_g2a_print_emit_nl_A_new, Get: A_arbace_g2a_print_emit_nl_A_get}

var A_arbace_g2a_print_emit_nl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$nl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "nl", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_nl_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_nl_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_nl_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_nl_A_Init; i.Table = A_arbace_g2a_print_emit_nl_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_nl_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_nl_A]()) }

func A_arbace_g2a_print_emit_pop_open_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_pop_open_BANG__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_pop_open_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_pop_open_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_pop_open_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_pop_open_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_pop_open_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_pop_open_BANG__A_invoke, New: A_arbace_g2a_print_emit_pop_open_BANG__A_new, Get: A_arbace_g2a_print_emit_pop_open_BANG__A_get}

var A_arbace_g2a_print_emit_pop_open_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$pop_open_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "pop_open_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_pop_open_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_pop_open_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_pop_open_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_pop_open_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_pop_open_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_pop_open_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_pop_open_BANG__A]()) }

func A_arbace_g2a_print_emit_push_open_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_push_open_BANG__A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_g2a_print_emit_push_open_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_push_open_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_push_open_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_push_open_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_push_open_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_push_open_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_push_open_BANG__A_invoke, New: A_arbace_g2a_print_emit_push_open_BANG__A_new, Get: A_arbace_g2a_print_emit_push_open_BANG__A_get}

var A_arbace_g2a_print_emit_push_open_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$push_open_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "push_open_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_push_open_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_push_open_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_push_open_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_push_open_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_push_open_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_push_open_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_push_open_BANG__A]()) }

func A_arbace_g2a_print_emit_raw_tok_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_raw_tok_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_raw_tok_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_raw_tok_A_New()}; return nil }

func A_arbace_g2a_print_emit_raw_tok_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_raw_tok_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_raw_tok_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_raw_tok_A_invoke, New: A_arbace_g2a_print_emit_raw_tok_A_new, Get: A_arbace_g2a_print_emit_raw_tok_A_get}

var A_arbace_g2a_print_emit_raw_tok_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$raw_tok", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "raw_tok", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_raw_tok_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_raw_tok_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_raw_tok_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_raw_tok_A_Init; i.Table = A_arbace_g2a_print_emit_raw_tok_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_raw_tok_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_raw_tok_A]()) }

func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_New()}; return nil }

func A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_invoke, New: A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_new, Get: A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_get}

var A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$raw_tok$fn__1256000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_raw_tok_A_class, Simple: "fn__1256000064", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_Init; i.Table = A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A]()) }

func A_arbace_g2a_print_emit_render_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_render_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_render_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_render_A_New()}; return nil }

func A_arbace_g2a_print_emit_render_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_render_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_render_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_render_A_invoke, New: A_arbace_g2a_print_emit_render_A_new, Get: A_arbace_g2a_print_emit_render_A_get}

var A_arbace_g2a_print_emit_render_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$render", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "render", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_render_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_render_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_render_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_render_A_Init; i.Table = A_arbace_g2a_print_emit_render_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_render_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_render_A]()) }

func A_arbace_g2a_print_emit_result_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_result_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_result_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_result_A_New()}; return nil }

func A_arbace_g2a_print_emit_result_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_result_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_result_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_result_A_invoke, New: A_arbace_g2a_print_emit_result_A_new, Get: A_arbace_g2a_print_emit_result_A_get}

var A_arbace_g2a_print_emit_result_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$result", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "result", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_result_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_result_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_result_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_result_A_Init; i.Table = A_arbace_g2a_print_emit_result_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_result_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_result_A]()) }

func A_arbace_g2a_print_emit_room_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_room_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_room_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_room_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_emit_room_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_room_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_room_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_room_QMARK__A_invoke, New: A_arbace_g2a_print_emit_room_QMARK__A_new, Get: A_arbace_g2a_print_emit_room_QMARK__A_get}

var A_arbace_g2a_print_emit_room_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$room_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "room_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_room_QMARK__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_room_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_room_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_room_QMARK__A_Init; i.Table = A_arbace_g2a_print_emit_room_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_room_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_room_QMARK__A]()) }

func A_arbace_g2a_print_emit_semi_after_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_semi_after_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_semi_after_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_semi_after_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_emit_semi_after_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_semi_after_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_semi_after_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_semi_after_QMARK__A_invoke, New: A_arbace_g2a_print_emit_semi_after_QMARK__A_new, Get: A_arbace_g2a_print_emit_semi_after_QMARK__A_get}

var A_arbace_g2a_print_emit_semi_after_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$semi_after_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "semi_after_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_semi_after_QMARK__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_semi_after_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_semi_after_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_semi_after_QMARK__A_Init; i.Table = A_arbace_g2a_print_emit_semi_after_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_semi_after_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_semi_after_QMARK__A]()) }

func A_arbace_g2a_print_emit_set_line_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_set_line_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_set_line_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_set_line_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_set_line_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_set_line_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_set_line_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_set_line_BANG__A_invoke, New: A_arbace_g2a_print_emit_set_line_BANG__A_new, Get: A_arbace_g2a_print_emit_set_line_BANG__A_get}

var A_arbace_g2a_print_emit_set_line_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$set_line_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "set_line_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_set_line_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_set_line_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_set_line_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_set_line_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_set_line_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_set_line_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_set_line_BANG__A]()) }

func A_arbace_g2a_print_emit_sp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_sp_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_sp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_sp_A_New()}; return nil }

func A_arbace_g2a_print_emit_sp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_sp_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_sp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_sp_A_invoke, New: A_arbace_g2a_print_emit_sp_A_new, Get: A_arbace_g2a_print_emit_sp_A_get}

var A_arbace_g2a_print_emit_sp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$sp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "sp", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_sp_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_sp_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_sp_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_sp_A_Init; i.Table = A_arbace_g2a_print_emit_sp_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_sp_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_sp_A]()) }

func A_arbace_g2a_print_emit_start_at_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_start_at_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_start_at_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_start_at_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_start_at_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_start_at_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_start_at_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_start_at_BANG__A_invoke, New: A_arbace_g2a_print_emit_start_at_BANG__A_new, Get: A_arbace_g2a_print_emit_start_at_BANG__A_get}

var A_arbace_g2a_print_emit_start_at_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$start_at_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "start_at_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_start_at_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_start_at_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_start_at_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_start_at_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_start_at_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_start_at_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_start_at_BANG__A]()) }

func A_arbace_g2a_print_emit_start_line_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_start_line_BANG__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_start_line_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_start_line_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_start_line_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_start_line_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_start_line_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_start_line_BANG__A_invoke, New: A_arbace_g2a_print_emit_start_line_BANG__A_new, Get: A_arbace_g2a_print_emit_start_line_BANG__A_get}

var A_arbace_g2a_print_emit_start_line_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$start_line_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "start_line_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_start_line_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_start_line_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_start_line_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_start_line_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_start_line_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_start_line_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_start_line_BANG__A]()) }

func A_arbace_g2a_print_emit_stmt_break_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_stmt_break_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_emit_stmt_break_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_stmt_break_BANG__A_New()}; return nil }

func A_arbace_g2a_print_emit_stmt_break_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_stmt_break_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_stmt_break_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_stmt_break_BANG__A_invoke, New: A_arbace_g2a_print_emit_stmt_break_BANG__A_new, Get: A_arbace_g2a_print_emit_stmt_break_BANG__A_get}

var A_arbace_g2a_print_emit_stmt_break_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$stmt_break_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "stmt_break_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_stmt_break_BANG__A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_stmt_break_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_stmt_break_BANG__A_InstanceOf; i.Init = A_arbace_g2a_print_emit_stmt_break_BANG__A_Init; i.Table = A_arbace_g2a_print_emit_stmt_break_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_stmt_break_BANG__A_class, reflect.TypeFor[A_arbace_g2a_print_emit_stmt_break_BANG__A]()) }

func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_New_O(args[0])}; return nil }

func A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_invoke, New: A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_new, Get: A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_get}

var A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$stmt_break_BANG_$newline_BANG___1256000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_stmt_break_BANG__A_class, Simple: "newline_BANG___1256000093", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_Init; i.Table = A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A]()) }

func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_invoke, New: A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_new, Get: A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_get}

var A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$stmt_break_BANG_$same_BANG___1256000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_stmt_break_BANG__A_class, Simple: "same_BANG___1256000095", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_Init; i.Table = A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A]()) }

func A_arbace_g2a_print_emit_target_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_target_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_target_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_target_A_New()}; return nil }

func A_arbace_g2a_print_emit_target_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_target_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_target_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_target_A_invoke, New: A_arbace_g2a_print_emit_target_A_new, Get: A_arbace_g2a_print_emit_target_A_get}

var A_arbace_g2a_print_emit_target_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$target", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "target", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_target_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_target_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_target_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_target_A_Init; i.Table = A_arbace_g2a_print_emit_target_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_target_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_target_A]()) }

func A_arbace_g2a_print_emit_tok_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_tok_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_emit_tok_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_tok_A_New()}; return nil }

func A_arbace_g2a_print_emit_tok_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_tok_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_tok_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_tok_A_invoke, New: A_arbace_g2a_print_emit_tok_A_new, Get: A_arbace_g2a_print_emit_tok_A_get}

var A_arbace_g2a_print_emit_tok_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$tok", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "tok", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_tok_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_tok_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_tok_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_tok_A_Init; i.Table = A_arbace_g2a_print_emit_tok_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_tok_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_tok_A]()) }

func A_arbace_g2a_print_emit_vtab_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_emit_vtab_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_emit_vtab_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_vtab_A_New()}; return nil }

func A_arbace_g2a_print_emit_vtab_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_emit_vtab_A_fn_class)}; return nil }

var A_arbace_g2a_print_emit_vtab_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_emit_vtab_A_invoke, New: A_arbace_g2a_print_emit_vtab_A_new, Get: A_arbace_g2a_print_emit_vtab_A_get}

var A_arbace_g2a_print_emit_vtab_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$vtab", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "vtab", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_vtab_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit_vtab_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_vtab_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_vtab_A_Init; i.Table = A_arbace_g2a_print_emit_vtab_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit_vtab_A_class, reflect.TypeFor[A_arbace_g2a_print_emit_vtab_A]()) }

func A_arbace_g2a_print_emit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit__init_A_Load__O(); case 1: return A_arbace_g2a_print_emit__init_A_Unit0__O(); case 2: return A_arbace_g2a_print_emit__init_A_Unit1__O(); case 3: return A_arbace_g2a_print_emit__init_A_Unit10__O(); case 4: return A_arbace_g2a_print_emit__init_A_Unit11__O(); case 5: return A_arbace_g2a_print_emit__init_A_Unit12__O(); case 6: return A_arbace_g2a_print_emit__init_A_Unit13__O(); case 7: return A_arbace_g2a_print_emit__init_A_Unit14__O(); case 8: return A_arbace_g2a_print_emit__init_A_Unit15__O(); case 9: return A_arbace_g2a_print_emit__init_A_Unit16__O(); case 10: return A_arbace_g2a_print_emit__init_A_Unit17__O(); case 11: return A_arbace_g2a_print_emit__init_A_Unit18__O(); case 12: return A_arbace_g2a_print_emit__init_A_Unit19__O(); case 13: return A_arbace_g2a_print_emit__init_A_Unit2__O(); case 14: return A_arbace_g2a_print_emit__init_A_Unit20__O(); case 15: return A_arbace_g2a_print_emit__init_A_Unit21__O(); case 16: return A_arbace_g2a_print_emit__init_A_Unit22__O(); case 17: return A_arbace_g2a_print_emit__init_A_Unit23__O(); case 18: return A_arbace_g2a_print_emit__init_A_Unit24__O(); case 19: return A_arbace_g2a_print_emit__init_A_Unit25__O(); case 20: return A_arbace_g2a_print_emit__init_A_Unit26__O(); case 21: return A_arbace_g2a_print_emit__init_A_Unit27__O(); case 22: return A_arbace_g2a_print_emit__init_A_Unit28__O(); case 23: return A_arbace_g2a_print_emit__init_A_Unit29__O(); case 24: return A_arbace_g2a_print_emit__init_A_Unit3__O(); case 25: return A_arbace_g2a_print_emit__init_A_Unit30__O(); case 26: return A_arbace_g2a_print_emit__init_A_Unit31__O(); case 27: return A_arbace_g2a_print_emit__init_A_Unit32__O(); case 28: return A_arbace_g2a_print_emit__init_A_Unit33__O(); case 29: return A_arbace_g2a_print_emit__init_A_Unit34__O(); case 30: return A_arbace_g2a_print_emit__init_A_Unit35__O(); case 31: return A_arbace_g2a_print_emit__init_A_Unit36__O(); case 32: return A_arbace_g2a_print_emit__init_A_Unit37__O(); case 33: return A_arbace_g2a_print_emit__init_A_Unit38__O(); case 34: return A_arbace_g2a_print_emit__init_A_Unit39__O(); case 35: return A_arbace_g2a_print_emit__init_A_Unit4__O(); case 36: return A_arbace_g2a_print_emit__init_A_Unit40__O(); case 37: return A_arbace_g2a_print_emit__init_A_Unit41__O(); case 38: return A_arbace_g2a_print_emit__init_A_Unit42__O(); case 39: return A_arbace_g2a_print_emit__init_A_Unit43__O(); case 40: return A_arbace_g2a_print_emit__init_A_Unit44__O(); case 41: return A_arbace_g2a_print_emit__init_A_Unit45__O(); case 42: return A_arbace_g2a_print_emit__init_A_Unit46__O(); case 43: return A_arbace_g2a_print_emit__init_A_Unit5__O(); case 44: return A_arbace_g2a_print_emit__init_A_Unit6__O(); case 45: return A_arbace_g2a_print_emit__init_A_Unit7__O(); case 46: return A_arbace_g2a_print_emit__init_A_Unit8__O(); case 47: return A_arbace_g2a_print_emit__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_print_emit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit__init_A_New()}; return nil }

var A_arbace_g2a_print_emit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_print_emit__init_A_invoke, New: A_arbace_g2a_print_emit__init_A_new}

var A_arbace_g2a_print_emit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit__init_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit__init_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit__init_A_InstanceOf; i.Init = A_arbace_g2a_print_emit__init_A_Init; i.Table = A_arbace_g2a_print_emit__init_A_members; jrt.RegisterGoType(A_arbace_g2a_print_emit__init_A_class, reflect.TypeFor[A_arbace_g2a_print_emit__init_A]()) }
