//line a2g_classes.ae:1
package aot_arbace_g2a_print_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_bol_QMARK__A_class, Name: "arbace.g2a.print_emit$bol_QMARK_", Modifiers: 25, Simple: "bol_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_bol_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_break_to_BANG__A_class, Name: "arbace.g2a.print_emit$break_to_BANG_", Modifiers: 25, Simple: "break_to_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_break_to_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_chunk_state_A_class, Name: "arbace.g2a.print_emit$chunk_state", Modifiers: 25, Simple: "chunk_state", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_chunk_state_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_close_break_BANG__A_class, Name: "arbace.g2a.print_emit$close_break_BANG_", Modifiers: 25, Simple: "close_break_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_close_break_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_comment_line_A_class, Name: "arbace.g2a.print_emit$comment_line", Modifiers: 25, Simple: "comment_line", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_comment_line_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_cont_indent_A_class, Name: "arbace.g2a.print_emit$cont_indent", Modifiers: 25, Simple: "cont_indent", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_cont_indent_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_cur_indent_A_class, Name: "arbace.g2a.print_emit$cur_indent", Modifiers: 25, Simple: "cur_indent", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_cur_indent_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_class, Name: "arbace.g2a.print_emit$eval1256000004$loading__1927001464__auto____1256000005", Modifiers: 25, Simple: "loading__1927001464__auto____1256000005", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_eval1256000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_class, Name: "arbace.g2a.print_emit$eval1256000008$fn__1256000009", Modifiers: 25, Simple: "fn__1256000009", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_eval1256000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_class, Name: "arbace.g2a.print_emit$eval1256000018$lines_QMARK___1256000019", Modifiers: 25, Simple: "lines_QMARK___1256000019", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_eval1256000018_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_class, Name: "arbace.g2a.print_emit$eval1256000029$line__1256000030", Modifiers: 25, Simple: "line__1256000030", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_eval1256000029_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_class, Name: "arbace.g2a.print_emit$eval1256000040$bol_QMARK___1256000041", Modifiers: 25, Simple: "bol_QMARK___1256000041", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_eval1256000040_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_class, Name: "arbace.g2a.print_emit$eval1256000052$target__1256000053", Modifiers: 25, Simple: "target__1256000053", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_eval1256000052_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_class, Name: "arbace.g2a.print_emit$eval1256000075$cur_indent__1256000076", Modifiers: 25, Simple: "cur_indent__1256000076", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_eval1256000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_join_BANG__A_class, Name: "arbace.g2a.print_emit$join_BANG_", Modifiers: 25, Simple: "join_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_join_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_line_A_class, Name: "arbace.g2a.print_emit$line", Modifiers: 25, Simple: "line", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_line_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_line_directive_inline_A_class, Name: "arbace.g2a.print_emit$line_directive_inline", Modifiers: 25, Simple: "line_directive_inline", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_line_directive_inline_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_line_directive_own_A_class, Name: "arbace.g2a.print_emit$line_directive_own", Modifiers: 25, Simple: "line_directive_own", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_line_directive_own_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_lines_QMARK__A_class, Name: "arbace.g2a.print_emit$lines_QMARK_", Modifiers: 25, Simple: "lines_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_lines_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_may_combine_QMARK__A_class, Name: "arbace.g2a.print_emit$may_combine_QMARK_", Modifiers: 25, Simple: "may_combine_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_may_combine_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_new_state_A_class, Name: "arbace.g2a.print_emit$new_state", Modifiers: 25, Simple: "new_state", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_new_state_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_nl_A_class, Name: "arbace.g2a.print_emit$nl", Modifiers: 25, Simple: "nl", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_nl_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_pop_open_BANG__A_class, Name: "arbace.g2a.print_emit$pop_open_BANG_", Modifiers: 25, Simple: "pop_open_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_pop_open_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_push_open_BANG__A_class, Name: "arbace.g2a.print_emit$push_open_BANG_", Modifiers: 25, Simple: "push_open_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_push_open_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_raw_tok_A_class, Name: "arbace.g2a.print_emit$raw_tok", Modifiers: 25, Simple: "raw_tok", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_raw_tok_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_class, Name: "arbace.g2a.print_emit$raw_tok$fn__1256000064", Modifiers: 25, Simple: "fn__1256000064", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_raw_tok_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_render_A_class, Name: "arbace.g2a.print_emit$render", Modifiers: 25, Simple: "render", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_render_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_result_A_class, Name: "arbace.g2a.print_emit$result", Modifiers: 25, Simple: "result", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_result_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_room_QMARK__A_class, Name: "arbace.g2a.print_emit$room_QMARK_", Modifiers: 25, Simple: "room_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_room_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_semi_after_QMARK__A_class, Name: "arbace.g2a.print_emit$semi_after_QMARK_", Modifiers: 25, Simple: "semi_after_QMARK_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_semi_after_QMARK__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_set_line_BANG__A_class, Name: "arbace.g2a.print_emit$set_line_BANG_", Modifiers: 25, Simple: "set_line_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_set_line_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_sp_A_class, Name: "arbace.g2a.print_emit$sp", Modifiers: 25, Simple: "sp", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_sp_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_start_at_BANG__A_class, Name: "arbace.g2a.print_emit$start_at_BANG_", Modifiers: 25, Simple: "start_at_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_start_at_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_start_line_BANG__A_class, Name: "arbace.g2a.print_emit$start_line_BANG_", Modifiers: 25, Simple: "start_line_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_start_line_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_stmt_break_BANG__A_class, Name: "arbace.g2a.print_emit$stmt_break_BANG_", Modifiers: 25, Simple: "stmt_break_BANG_", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_stmt_break_BANG__A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_class, Name: "arbace.g2a.print_emit$stmt_break_BANG_$newline_BANG___1256000093", Modifiers: 25, Simple: "newline_BANG___1256000093", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_stmt_break_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_class, Name: "arbace.g2a.print_emit$stmt_break_BANG_$same_BANG___1256000095", Modifiers: 25, Simple: "same_BANG___1256000095", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_stmt_break_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_target_A_class, Name: "arbace.g2a.print_emit$target", Modifiers: 25, Simple: "target", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_target_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_tok_A_class, Name: "arbace.g2a.print_emit$tok", Modifiers: 25, Simple: "tok", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_tok_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_emit_vtab_A_class, Name: "arbace.g2a.print_emit$vtab", Modifiers: 25, Simple: "vtab", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_vtab_A", Source: "print_emit.ae", Declaring: &A_arbace_g2a_print_emit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_g2a_print_emit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_A_New()}; return nil }

var A_arbace_g2a_print_emit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_A_new}

var A_arbace_g2a_print_emit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_A"})

func init() { i := A_arbace_g2a_print_emit_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_A_InstanceOf; i.Init = A_arbace_g2a_print_emit_A_Init; i.Table = A_arbace_g2a_print_emit_A_members }

var A_arbace_g2a_print_emit_bol_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_emit_break_to_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_chunk_state_A_class *jrt.Class

var A_arbace_g2a_print_emit_close_break_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_comment_line_A_class *jrt.Class

var A_arbace_g2a_print_emit_cont_indent_A_class *jrt.Class

var A_arbace_g2a_print_emit_cur_indent_A_class *jrt.Class

func A_arbace_g2a_print_emit_eval1256000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000004_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000004_A_new}

var A_arbace_g2a_print_emit_eval1256000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000004", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000004_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000004_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000004_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000004_A_members }

var A_arbace_g2a_print_emit_eval1256000004_loading__1927001464__auto____1256000005_A_class *jrt.Class

func A_arbace_g2a_print_emit_eval1256000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000008_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000008_A_new}

var A_arbace_g2a_print_emit_eval1256000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000008", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000008_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000008_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000008_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000008_A_members }

var A_arbace_g2a_print_emit_eval1256000008_fn__1256000009_A_class *jrt.Class

func A_arbace_g2a_print_emit_eval1256000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000018_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000018_A_new}

var A_arbace_g2a_print_emit_eval1256000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000018", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000018_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000018_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000018_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000018_A_members }

var A_arbace_g2a_print_emit_eval1256000018_lines_QMARK___1256000019_A_class *jrt.Class

func A_arbace_g2a_print_emit_eval1256000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000029_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000029_A_new}

var A_arbace_g2a_print_emit_eval1256000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000029", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000029_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000029_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000029_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000029_A_members }

var A_arbace_g2a_print_emit_eval1256000029_line__1256000030_A_class *jrt.Class

func A_arbace_g2a_print_emit_eval1256000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000040_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000040_A_new}

var A_arbace_g2a_print_emit_eval1256000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000040", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000040_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000040_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000040_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000040_A_members }

var A_arbace_g2a_print_emit_eval1256000040_bol_QMARK___1256000041_A_class *jrt.Class

func A_arbace_g2a_print_emit_eval1256000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000052_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000052_A_new}

var A_arbace_g2a_print_emit_eval1256000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000052", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000052_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000052_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000052_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000052_A_members }

var A_arbace_g2a_print_emit_eval1256000052_target__1256000053_A_class *jrt.Class

func A_arbace_g2a_print_emit_eval1256000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit_eval1256000075_A_New()}; return nil }

var A_arbace_g2a_print_emit_eval1256000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_emit_eval1256000075_A_new}

var A_arbace_g2a_print_emit_eval1256000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit$eval1256000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_emit_A_class, Simple: "eval1256000075", Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit_eval1256000075_A"})

func init() { i := A_arbace_g2a_print_emit_eval1256000075_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit_eval1256000075_A_InstanceOf; i.Table = A_arbace_g2a_print_emit_eval1256000075_A_members }

var A_arbace_g2a_print_emit_eval1256000075_cur_indent__1256000076_A_class *jrt.Class

var A_arbace_g2a_print_emit_join_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_line_A_class *jrt.Class

var A_arbace_g2a_print_emit_line_directive_inline_A_class *jrt.Class

var A_arbace_g2a_print_emit_line_directive_own_A_class *jrt.Class

var A_arbace_g2a_print_emit_lines_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_emit_may_combine_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_emit_new_state_A_class *jrt.Class

var A_arbace_g2a_print_emit_nl_A_class *jrt.Class

var A_arbace_g2a_print_emit_pop_open_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_push_open_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_raw_tok_A_class *jrt.Class

var A_arbace_g2a_print_emit_raw_tok_fn__1256000064_A_class *jrt.Class

var A_arbace_g2a_print_emit_render_A_class *jrt.Class

var A_arbace_g2a_print_emit_result_A_class *jrt.Class

var A_arbace_g2a_print_emit_room_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_emit_semi_after_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_emit_set_line_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_sp_A_class *jrt.Class

var A_arbace_g2a_print_emit_start_at_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_start_line_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_stmt_break_BANG__A_class *jrt.Class

var A_arbace_g2a_print_emit_stmt_break_BANG__newline_BANG___1256000093_A_class *jrt.Class

var A_arbace_g2a_print_emit_stmt_break_BANG__same_BANG___1256000095_A_class *jrt.Class

var A_arbace_g2a_print_emit_target_A_class *jrt.Class

var A_arbace_g2a_print_emit_tok_A_class *jrt.Class

var A_arbace_g2a_print_emit_vtab_A_class *jrt.Class

func A_arbace_g2a_print_emit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit__init_A_Load__O()}; return nil }

func A_arbace_g2a_print_emit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_emit__init_A_New()}; return nil }

var A_arbace_g2a_print_emit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_print_emit__init_A_invoke, New: A_arbace_g2a_print_emit__init_A_new}

var A_arbace_g2a_print_emit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_emit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_emit.A_arbace_g2a_print_emit__init_A", Source: "print_emit.ae"})

func init() { i := A_arbace_g2a_print_emit__init_A_class.Info(); i.IsInstance = A_arbace_g2a_print_emit__init_A_InstanceOf; i.Init = A_arbace_g2a_print_emit__init_A_Init; i.Table = A_arbace_g2a_print_emit__init_A_members }
