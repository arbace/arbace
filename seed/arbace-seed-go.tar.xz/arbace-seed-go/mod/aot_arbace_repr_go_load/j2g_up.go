//line j2g_up.ae:1
package aot_arbace_repr_go_load

import "arbace/lang"


func Up_ArraySeq_ISeq(p *lang.ArraySeq) lang.ISeq { if p == nil { return nil }; return p }

func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }
