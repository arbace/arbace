//line j2g_strings.ae:1
package aot_arbace_repr_go_load

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn4,elsekn6,gorootkn3,cwdkn4,gooskn6,goarchkn4,tagskn7,goamd64kn7,goarm64kn9,host-gooskn11,host-goarchkn5,levelkn9,tool-tagskn12,release-tagskn9,toolchainkn12,goexperimentkn3,cgokn8,compilerkn10,go-versionkn9,word-sizekn9,max-alignkn7,moduleskn5,testskn5,xtestkn8,go-fileskn9,cgo-fileskn7,c-fileskn9,cxx-fileskn7,m-fileskn7,h-fileskn7,f-fileskn7,s-fileskn10,swig-fileskn14,swig-cxx-fileskn10,syso-fileskn16,ignored-go-fileskn19,ignored-other-fileskn14,embed-patternskn11,embed-fileskn18,x-test-embed-fileskn21,x-test-embed-patternskn15,x-test-go-fileskn16,test-embed-fileskn19,test-embed-patternskn13,test-go-fileskn4,pathkn4,langkn3,dirkn8,for-testkn6,godumpkn7,packagekn6,configkn4,argskn4,depskn6,prefixkn6,modulekn7,replacekn2,gokn8,resolvedkn3,keykn5,fileskn6,headerkn7,importskn8,dep-onlykn5,errorkn4,namekn12,test-importskn14,x-test-importskn6,statuskn3,msgkn4,filekn4,testkn6,actionkn8,mod-verskn4,pkgskn5,orderkn2,bykn4,stemkn12,local-prefixkn8,packageskn8,dir-testkn13,local-importskn9,args-filekn4,modekn4,dirsv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn19,arbace.repr.go.loadm2,R4,s1646,repr/go's native reader, its loader (doc/go/GO-PARSER-SURVEY.md §5, GP2): what the helper\n  (tools/godump) asks of the go command, in Arbace: a conversion's packages and their files for\n  one configuration, and each dump's header (doc/go/HELPER-NOTES.md, \"The package view\"): the\n  configuration, the directory, go list's file lists, the embedded files with their SHA-256,\n  the test variants (-tests), the single-file programs (-files) and the directory tests of\n  $GOROOT/test (-dirs: dirs.go's rules, as Go's test driver reads them), the language version\n  and :imports (go/types' Package.Imports: the files' imports as resolved, a path that does not\n  resolve as written). go list's part is arbace.box.plan's (S8's planner, generalized to\n  directories); no export data: nothing is compiled.\n\n    (jobs load)   the dumps of one load: [{:key K :header H :dir D :files [F ...]} ...] and\n                  results {:key K :status \"excluded\"|\"fail\" :msg M} for what has no dump\n\n  load: {:goroot DIR :goos G :goarch A :tags [T ...] :mode :packages|:files|:dirs :cwd DIR\n         :args [ARG ...] (or :args-file FILE, one per line) :tests BOOL :deps BOOL :prefix P}\n    :packages  ARGs are import paths and patterns (std, cmd, P/..., ./..., .), in the module of\n               :cwd (its go.mod, local replacements); :tests the test variants and external\n               test packages as godump -tests; :deps the dependencies too, :prefix keeping\n               those whose path begins with P\n    :files     ARGs are FILE or FILE,FILE... relative to :cwd (godump -files)\n    :dirs      ARGs are directory tests FILE.go relative to :cwd (godump -dirs)v13,arbace.string12,starts-with?v11,arbace.core6,reducev11,arbace.core3,seqv11,arbace.core4,not=v11,arbace.core4,peekv11,arbace.core3,popR5,v13,arbace.string5,splitp1,/v13,arbace.string4,joinv11,arbace.core6,empty?v19,arbace.repr.go.load5,cleanv11,arbace.core6,removev11,arbace.core4,subsv19,arbace.repr.go.load4,joinv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstR6,R7,v19,arbace.repr.go.load8,abs-pathv11,arbace.core4,somev19,arbace.repr.go.load3,rell1,v13,arbace.string10,ends-with?v13,arbace.string7,replacep3,/+$v11,arbace.core4,sortv11,arbace.core6,concatS7,s7,riscv64s7,ppc64les5,amd64s5,s390xs5,ppc64s7,loong64s5,arm64V2,s14,regabiwrapperss10,regabiargsS3,s6,darwins3,aixs3,iosV1,s6,dwarf5V4,s20,randomizedheapbase64s10,greenteagcs6,jsonv2s21,sizespecializedmallocR8,R9,R10,R11,R12,R13,R14,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core7,re-findp14,^v(\\d+)\\.(\\d+)v11,arbace.core10,parse-longv11,arbace.core5,rangel0,v11,arbace.core3,vecv11,arbace.core3,mapv19,arbace.repr.go.load11,experimentsv19,arbace.repr.go.load11,pinned-langl4,R15,v11,arbace.core8,distinctR16,R17,v11,arbace.core4,mapvR18,v13,arbace.string11,split-linesv11,arbace.core5,slurpS2,s5,amd64s5,arm64v11,arbace.core7,ex-infov11,arbace.core9,array-mapR19,R20,R21,R22,R23,l8,R24,p11,^(\\d+\\.\\d+)v15,arbace.box.plan6,go-modR25,v11,arbace.core4,intov11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core6,formatv19,arbace.repr.go.load10,sha256-hexR26,R27,v11,arbace.core5,assocv19,arbace.repr.go.load11,embed-filesV14,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R41,R44,R28,R45,R46,R47,R48,R49,R50,R51,R52,v11,arbace.core5,mergeR53,l2,R54,R55,v19,arbace.repr.go.load13,header-configv19,arbace.repr.go.load7,rel-dirR56,R57,R58,v19,arbace.repr.go.load11,find-moduleR59,R60,v19,arbace.repr.go.load11,plan-configv19,arbace.repr.go.load12,version-langR61,v15,arbace.box.plan13,list-packagesv11,arbace.core6,mapcatR62,R63,R64,R65,v19,arbace.repr.go.load6,headerv19,arbace.repr.go.load5,listsR66,v19,arbace.repr.go.load10,imports-ofR67,v11,arbace.core3,notR68,R69,R70,m2,R26,TR71,m2,R27,TR72,R73,v15,arbace.box.plan6,tag-fnp1,,v19,arbace.repr.go.load8,file-keyv15,arbace.box.plan10,match-fileC12,java.io.FileR74,m2,R72,s8,excludedv11,arbace.core6,secondv15,arbace.box.plan13,types-importsv15,arbace.box.plan14,resolve-importm2,R72,s8,excludedc34,S2,c32,c9,p2,\\nl-1,v13,arbace.string4,trimv19,arbace.repr.go.load12,split-actionv19,arbace.repr.go.load11,dir-actionsv11,arbace.core6,pr-strv11,arbace.core4,dropm2,R72,s8,excludedR75,R76,R77,v11,arbace.core7,filtervp10,(\\.[^.]*)$p10,(\\.[^.]*)$S2,s11,buildrundirs8,builddirR78,v19,arbace.repr.go.load10,package-rev11,arbace.core7,reducedR79,v11,arbace.core9,contains?R80,v11,arbace.core9,update-inv11,arbace.core8,assoc-inv11,arbace.core6,updateR81,R35,S2,s11,buildrundirs8,builddirv11,arbace.core4,lastp1,/R82,v19,arbace.repr.go.load12,local-prefixR83,p1,/v11,arbace.core6,filterm2,R57,TR84,v19,arbace.repr.go.load13,dir-test-viewv11,arbace.core6,vectorv19,arbace.repr.go.load13,read-dir-testv19,arbace.repr.go.load13,runindir-jobsv11,arbace.core3,setv11,arbace.core4,keepv11,arbace.core10,sorted-mapR85,R86,v13,arbace.string6,blank?v19,arbace.repr.go.load6,configv15,arbace.box.plan15,call-with-treesv11,arbace.core7,keywordv11,arbace.core4,nameR87,v19,arbace.repr.go.load12,package-jobsR88,v19,arbace.repr.go.load8,dir-jobsv19,arbace.repr.go.load9,file-jobs")

var Lit_1 *jrt.String = jrt.Intern("/")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.load$clean$fn__1667000020")

var Lit_3 *jrt.String = jrt.Intern(".")

var Lit_4 *jrt.String = jrt.Intern("")

var Lit_5 *jrt.String = jrt.Intern("..")

var Lit_6 *jrt.String = jrt.Intern("amd64")

var Lit_7 *jrt.String = jrt.Intern("v1")

var Lit_8 *jrt.String = jrt.Intern("v8.0")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000043__1667000047")

var Lit_10 *jrt.String = jrt.Intern("9")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000056__1667000060")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000066__1667000070")

var Lit_13 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000076__1667000080")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.go.load$config$fn__1667000086")

var Lit_15 *jrt.String = jrt.Intern("linux")

var Lit_16 *jrt.String = jrt.Intern("GOARCH=")

var Lit_17 *jrt.String = jrt.Intern(": only amd64 and arm64 are configurations of repr/go")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.load$config$fn__1667000088")

var Lit_19 *jrt.String = jrt.Intern("/VERSION")

var Lit_20 *jrt.String = jrt.Intern("goexperiment.")

var Lit_21 *jrt.String = jrt.Intern("go1.")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000043__1667000047$fn__1667000048")

var Lit_23 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000043__1667000047$fn__1667000048$fn__1667000049")

var Lit_24 *jrt.String = jrt.Intern("amd64.v")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000056__1667000060$fn__1667000061")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000056__1667000060$fn__1667000061$fn__1667000062")

var Lit_27 *jrt.String = jrt.Intern("arm64.v9.")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000066__1667000070$fn__1667000071")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000066__1667000070$fn__1667000071$fn__1667000072")

var Lit_30 *jrt.String = jrt.Intern("arm64.v8.")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000076__1667000080$fn__1667000081")

var Lit_32 *jrt.String = jrt.Intern("arbace.repr.go.load$config$iter__1667000076__1667000080$fn__1667000081$fn__1667000082")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326")

var Lit_34 *jrt.String = jrt.Intern(".dir")

var Lit_35 *jrt.String = jrt.Intern("runindir")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$fn__1667000327")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333")

var Lit_38 *jrt.String = jrt.Intern("main")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000335")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000352")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$iter__1667000354__1667000358")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000365")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000335$fn__1667000336")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000335$iter__1667000338__1667000342")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000335$fn__1667000349")

var Lit_47 *jrt.String = jrt.Intern("C")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000335$iter__1667000338__1667000342$fn__1667000343")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$fn__1667000335$iter__1667000338__1667000342$fn__1667000343$fn__1667000344")

var Lit_50 *jrt.String = jrt.Intern("./")

var Lit_51 *jrt.String = jrt.Intern("../")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$iter__1667000354__1667000358$fn__1667000359")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs$fn__1667000326$iter__1667000329__1667000333$fn__1667000334$iter__1667000354__1667000358$fn__1667000359$fn__1667000360")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_test_view$fn__1667000284")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go.load$embed_files$iter__1667000118__1667000122")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go.load$embed_files$iter__1667000118__1667000122$fn__1667000123")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go.load$embed_files$iter__1667000118__1667000122$fn__1667000123$fn__1667000124")

var Lit_58 *jrt.String = jrt.Intern("java.io.File")

var Lit_59 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_60 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201")

var Lit_62 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000203")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$iter__1667000225__1667000229")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000236")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000241")

var Lit_67 *jrt.String = jrt.Intern("command-line-arguments")

var Lit_68 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000243")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000203$iter__1667000204__1667000208")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000203$fn__1667000215")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000203$fn__1667000220")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000203$fn__1667000222")

var Lit_73 *jrt.String = jrt.Intern("fail")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000203$iter__1667000204__1667000208$fn__1667000209")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$fn__1667000203$iter__1667000204__1667000208$fn__1667000209$fn__1667000210")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$iter__1667000225__1667000229$fn__1667000230")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs$iter__1667000197__1667000201$fn__1667000202$iter__1667000225__1667000229$fn__1667000230$fn__1667000231")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go.load$file_key$fn__1667000030")

var Lit_79 *jrt.String = jrt.Intern("test")

var Lit_80 *jrt.String = jrt.Intern("/go.mod")

var Lit_81 *jrt.String = jrt.Intern("src")

var Lit_82 *jrt.String = jrt.Intern("src/cmd")

var Lit_83 *jrt.String = jrt.Intern("/..")

var Lit_84 *jrt.String = jrt.Intern("gc")

var Lit_85 *jrt.String = jrt.Intern("arbace.repr.go.load$imports_of$fn__1667000143")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.go.load$jobs$fn__1667000373")

var Lit_87 *jrt.String = jrt.Intern("arbace.repr.go.load$jobs$fn__1667000375")

var Lit_88 *jrt.String = jrt.Intern("user.dir")

var Lit_89 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_90 *jrt.String = jrt.Intern("arbace.repr.go.load$lists$l__1667000134")

var Lit_91 *jrt.String = jrt.Intern("arbace.repr.go.load$lists$e__1667000136")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.go.load$lists$fn__1667000139")

var Lit_93 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$iter__1667000158__1667000162")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$iter__1667000174__1667000178")

var Lit_95 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$fn__1667000184")

var Lit_96 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$fn__1667000184$resolve__1667000185")

var Lit_97 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$fn__1667000184$job__1667000187")

var Lit_98 *jrt.String = jrt.Intern("_test")

var Lit_99 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$fn__1667000184$job__1667000187$fn__1667000188")

var Lit_100 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$iter__1667000158__1667000162$fn__1667000163")

var Lit_101 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$iter__1667000158__1667000162$fn__1667000163$fn__1667000164")

var Lit_102 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$iter__1667000174__1667000178$fn__1667000179")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs$iter__1667000174__1667000178$fn__1667000179$fn__1667000180")

var Lit_104 *jrt.String = jrt.Intern("./...")

var Lit_105 *jrt.String = jrt.Intern("/...")

var Lit_106 *jrt.String = jrt.Intern("/src")

var Lit_107 *jrt.String = jrt.Intern("arbace.repr.go.load$plan_config$iter__1667000097__1667000101")

var Lit_108 *jrt.String = jrt.Intern("arbace.repr.go.load$plan_config$iter__1667000097__1667000101$fn__1667000102")

var Lit_109 *jrt.String = jrt.Intern("arbace.repr.go.load$plan_config$iter__1667000097__1667000101$fn__1667000102$fn__1667000103")

var Lit_110 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test$fn__1667000260")

var Lit_111 *jrt.String = jrt.Intern(": action ")

var Lit_112 *jrt.String = jrt.Intern(" is not a directory test the helper takes (compiledir, rundir, builddir, buildrundir)")

var Lit_113 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test$fn__1667000268")

var Lit_114 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test$fn__1667000271")

var Lit_115 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test$fn__1667000273")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test$fn__1667000275")

var Lit_117 *jrt.String = jrt.Intern(": no Go files")

var Lit_118 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test$fn__1667000277")

var Lit_119 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test$fn__1667000279")

var Lit_120 *jrt.String = jrt.Intern("//go:build")

var Lit_121 *jrt.String = jrt.Intern("// +build")

var Lit_122 *jrt.String = jrt.Intern("//")

var Lit_123 *jrt.String = jrt.Intern("1.14")

var Lit_124 *jrt.String = jrt.Intern("-")

var Lit_125 *jrt.String = jrt.Intern("-ldflags")

var Lit_126 *jrt.String = jrt.Intern("-0")

var Lit_127 *jrt.String = jrt.Intern("-1")

var Lit_128 *jrt.String = jrt.Intern("-s")

var Lit_129 *jrt.String = jrt.Intern("-t")

var Lit_130 *jrt.String = jrt.Intern("-gomodversion")

var Lit_131 *jrt.String = jrt.Intern("-goexperiment")

var Lit_132 *jrt.String = jrt.Intern(": needs another GOEXPERIMENT")

var Lit_133 *jrt.String = jrt.Intern("-godebug")

var Lit_134 *jrt.String = jrt.Intern(".go")

var Lit_135 *jrt.String = jrt.Intern(".s")

var Lit_136 *jrt.String = jrt.Intern(": no package clause")

var Lit_137 *jrt.String = jrt.Intern("test/")

var Lit_138 *jrt.String = jrt.Intern("$GOROOT")

var Lit_139 *jrt.String = jrt.Intern("$GOROOT/")

var Lit_140 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$fn__1667000290")

var Lit_141 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$fn__1667000292")

var Lit_142 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$fn__1667000294")

var Lit_143 *jrt.String = jrt.Intern("go list in the module ")

var Lit_144 *jrt.String = jrt.Intern(": no packages")

var Lit_145 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$iter__1667000300__1667000304")

var Lit_146 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$fn__1667000294$fn__1667000295")

var Lit_147 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$fn__1667000294$fn__1667000295$fn__1667000296")

var Lit_148 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$iter__1667000300__1667000304$fn__1667000305")

var Lit_149 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$iter__1667000300__1667000304$fn__1667000305$fn__1667000306")

var Lit_150 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$iter__1667000300__1667000304$fn__1667000305$fn__1667000316")

var Lit_151 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs$iter__1667000300__1667000304$fn__1667000305$fn__1667000306$fn__1667000310")

var Lit_152 *jrt.String = jrt.Intern("SHA-256")

var Lit_153 *jrt.String = jrt.Intern("arbace.repr.go.load$sha256_hex$fn__1667000115")

var Lit_154 *jrt.String = jrt.Intern("%02x")

var Lit_155 *jrt.String = jrt.Intern("go")

var Lit_156 *jrt.String = jrt.Intern("kn3,docyn11,arbace.coreyn15,arbace.box.planyn4,plankn4,linekn6,columnkn4,filekn8,arglistskn3,tagyn6,Stringyn16,java.lang.Stringkn7,privateyn1,&yn2,pskn4,keysyn6,gorootyn3,cwdyn4,goosyn6,goarchyn4,tagsyn7,goamd64yn7,goarm64yn9,host-goosyn11,host-goarchyn1,cyn4,langyn7,modulesyn4,Fileyn5,filesyn1,pyn5,testsyn5,xtestyn3,rawyn7,resolveyn4,pathyn3,diryn8,for-testyn4,moreyn4,argsyn4,depsyn6,prefixyn6,match?yn1,tyn3,keyyn4,loadv11,arbace.core5,in-nsMyn19,arbace.repr.go.loadm2,R0,s1646,repr/go's native reader, its loader (doc/go/GO-PARSER-SURVEY.md §5, GP2): what the helper\n  (tools/godump) asks of the go command, in Arbace: a conversion's packages and their files for\n  one configuration, and each dump's header (doc/go/HELPER-NOTES.md, \"The package view\"): the\n  configuration, the directory, go list's file lists, the embedded files with their SHA-256,\n  the test variants (-tests), the single-file programs (-files) and the directory tests of\n  $GOROOT/test (-dirs: dirs.go's rules, as Go's test driver reads them), the language version\n  and :imports (go/types' Package.Imports: the files' imports as resolved, a path that does not\n  resolve as written). go list's part is arbace.box.plan's (S8's planner, generalized to\n  directories); no export data: nothing is compiled.\n\n    (jobs load)   the dumps of one load: [{:key K :header H :dir D :files [F ...]} ...] and\n                  results {:key K :status \"excluded\"|\"fail\" :msg M} for what has no dump\n\n  load: {:goroot DIR :goos G :goarch A :tags [T ...] :mode :packages|:files|:dirs :cwd DIR\n         :args [ARG ...] (or :args-file FILE, one per line) :tests BOOL :deps BOOL :prefix P}\n    :packages  ARGs are import paths and patterns (std, cmd, P/..., ./..., .), in the module of\n               :cwd (its go.mod, local replacements); :tests the test variants and external\n               test packages as godump -tests; :deps the dependencies too, :prefix keeping\n               those whose path begins with P\n    :files     ARGs are FILE or FILE,FILE... relative to :cwd (godump -files)\n    :dirs      ARGs are directory tests FILE.go relative to :cwd (godump -dirs)m2,R0,s1646,repr/go's native reader, its loader (doc/go/GO-PARSER-SURVEY.md §5, GP2): what the helper\n  (tools/godump) asks of the go command, in Arbace: a conversion's packages and their files for\n  one configuration, and each dump's header (doc/go/HELPER-NOTES.md, \"The package view\"): the\n  configuration, the directory, go list's file lists, the embedded files with their SHA-256,\n  the test variants (-tests), the single-file programs (-files) and the directory tests of\n  $GOROOT/test (-dirs: dirs.go's rules, as Go's test driver reads them), the language version\n  and :imports (go/types' Package.Imports: the files' imports as resolved, a path that does not\n  resolve as written). go list's part is arbace.box.plan's (S8's planner, generalized to\n  directories); no export data: nothing is compiled.\n\n    (jobs load)   the dumps of one load: [{:key K :header H :dir D :files [F ...]} ...] and\n                  results {:key K :status \"excluded\"|\"fail\" :msg M} for what has no dump\n\n  load: {:goroot DIR :goos G :goarch A :tags [T ...] :mode :packages|:files|:dirs :cwd DIR\n         :args [ARG ...] (or :args-file FILE, one per line) :tests BOOL :deps BOOL :prefix P}\n    :packages  ARGs are import paths and patterns (std, cmd, P/..., ./..., .), in the module of\n               :cwd (its go.mod, local replacements); :tests the test variants and external\n               test packages as godump -tests; :deps the dependencies too, :prefix keeping\n               those whose path begins with P\n    :files     ARGs are FILE or FILE,FILE... relative to :cwd (godump -files)\n    :dirs      ARGs are directory tests FILE.go relative to :cwd (godump -dirs)R1,v11,arbace.core7,requireR2,v11,arbace.core4,somev11,arbace.core6,removev11,arbace.core6,empty?v13,arbace.string5,splitp1,:v11,arbace.core3,notv11,arbace.core9,load-filev11,arbace.core5,aliasR3,R2,v19,arbace.repr.go.load11,pinned-langm8,R4,i43,R5,i1,R6,s22,arbace/repr/go/load.aeR0,s68,The language version the helper accepts (tools/godump's pinnedLang).v19,arbace.repr.go.load5,cleanm10,R7,L1,MV1,Myn1,pm2,R8,R9,m2,R8,R10,R0,s33,path.Clean of a /-separated path.R4,i49,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load4,joinm10,R11,TR7,L1,V2,R12,R13,R4,i63,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load3,relm12,R11,TR7,L1,V2,Myn4,basem2,R8,R9,Myn1,pm2,R8,R9,R0,s83,filepath.Rel of path p (absolute) to base (absolute), nil when p is not under base.R4,i65,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load8,abs-pathm10,R11,TR7,L1,V2,Myn3,cwdm2,R8,R9,Myn1,pm2,R8,R9,R4,i73,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load8,file-keym12,R11,TR7,L1,V2,m2,R14,V2,R15,R16,Myn4,filem2,R8,R9,R0,s137,godump's fileKey: file's path relative to $GOROOT/test, $GOROOT or the working directory, else\n  its absolute path without the leading /.R4,i75,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load7,rel-dirm12,R11,TR7,L1,V2,m2,R14,V1,R15,Myn3,dirm2,R8,R9,R0,s79,godump's relDir: a directory relative to $GOROOT as $GOROOT/..., else as it is.R4,i83,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load11,experimentsm10,R7,L1,V2,R17,R18,R0,s177,go1.27.1's baseline experiments (internal/buildcfg's ParseGOEXPERIMENT) for goos/goarch, the\n  host the helper runs on: what godump's go/build gives as goexperiment.* tool tags.R4,i92,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load6,configm10,R7,L1,V1,m2,R14,V8,R15,R17,R18,R19,R20,R21,R22,R23,R0,s122,The configuration of a load (godump's config): {:goos :goarch :level :tags :tool-tags\n  :release-tags :toolchain :goroot}.R4,i101,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load13,header-configm12,R11,TR7,L1,V2,R24,R25,R0,s54,The dump's :config for a job of language version lang.R4,i123,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load12,version-langm12,R11,TR7,L1,V1,Myn1,vm2,R8,R9,R0,s57,go/version's Lang of go + v (a go line's version): go1.N.R4,i131,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load11,find-modulem12,R11,TR7,L1,V2,R15,Myn3,cwdm2,R8,R9,R0,s92,The module of directory cwd: [root go-mod], nil when none (or std's or cmd's, GOROOT/src's).R4,i138,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load11,plan-configm12,R11,TR7,L1,V2,R24,R26,R0,s71,arbace.box.plan's cfg for configuration c, modules {path dir} as Files.R4,i149,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load10,sha256-hexm10,R11,TR7,L1,V1,Myn1,fm2,R8,R27,R4,i158,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load11,embed-filesm10,R11,TR7,L1,V2,Myn3,dirm2,R8,R9,R28,R4,i163,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load5,listsm12,R11,TR7,L1,V3,R29,Myn3,dirm2,R8,R9,m2,R14,V2,R30,R31,R0,s178,godump's fileLists of package record p (arbace.box.plan/load-package's) for a job: the plain\n  package's, :tests adding the in-package tests', :xtest the external test package's.R4,i166,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load10,imports-ofm12,R11,TR7,L1,V2,R32,R33,R0,s157,go/types' Package.Imports of a job: the import paths of its files' imports (raw), each as\n  resolve gives it, or as written when it does not resolve, sorted.R4,i181,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load6,headerm12,R11,TR7,L1,V3,R24,m2,R14,V4,R34,R25,R35,R36,R37,R0,s84,A dump's header (godump's write, before :files): what the native dump carries of it.R4,i187,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load12,package-jobsm10,R11,TR7,L1,V2,R24,m2,R14,V5,R16,R38,R30,R39,R40,R4,i196,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load9,file-jobsm10,R11,TR7,L1,V2,R24,m2,R14,V2,R16,R38,R4,i244,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load11,dir-actionsS5,s11,buildrundirs8,runindirs6,rundirs8,builddirs10,compiledirm8,R11,TR4,i277,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load12,split-actionm12,R11,TR7,L1,V1,Myn1,sm2,R8,R9,R0,s62,The test driver's splitQuoted: fields, double quotes grouping.R4,i279,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load10,package-rep32,(?m)^package ([\\p{Lu}\\p{Ll}\\w]+)m8,R11,TR4,i292,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load13,read-dir-testm12,R11,TR7,L1,V4,R24,R41,Myn3,cwdm2,R8,R9,Myn4,filem2,R8,R9,R0,s147,dirs.go's readDirTest: {:test :dir :action :pkgs [{:name :path :stem :files :s-files}] :mod-vers},\n  {:status \"excluded\"} or {:status \"fail\" :msg}.R4,i294,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load12,local-prefixm10,R11,TR7,L1,V1,R42,R4,i356,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load13,dir-test-viewm10,R11,TR7,L1,V3,R24,R16,R42,R4,i358,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load13,runindir-jobsm12,R11,TR7,L1,V4,R24,R16,R42,R43,R0,s170,dirs.go's runindirJobs: the module the driver makes of the test's directory (named by its base\n  name, go line :mod-vers), its packages as go list -deps ./... lists them.R4,i364,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load8,dir-jobsm10,R11,TR7,L1,V2,R24,m2,R14,V2,R16,R38,R4,i391,R5,i1,R6,s22,arbace/repr/go/load.aev19,arbace.repr.go.load4,jobsm10,R7,L1,V1,R44,R0,s44,The dumps of load (see the namespace's doc).R4,i425,R5,i1,R6,s22,arbace/repr/go/load.ae")

var Lit_157 *jrt.String = jrt.Intern("arbace.repr.go.load$eval1667000004$loading__1927001464__auto____1667000005")

var Lit_158 *jrt.String = jrt.Intern("arbace.repr.go.load$eval1667000008$fn__1667000009")

var Lit_159 *jrt.String = jrt.Intern("arbace/box/plan.ae")

var Lit_160 *jrt.String = jrt.Intern("arbace.repr.go.load$eval1667000014$fn__1667000015")

var Lit_161 *jrt.String = jrt.Intern("ARBACE_PATH")

var Lit_162 *jrt.String = jrt.Intern("go1.27")

var Lit_163 *jrt.String = jrt.Intern("arbace.repr.go.load$clean")

var Lit_164 *jrt.String = jrt.Intern("arbace.repr.go.load$join")

var Lit_165 *jrt.String = jrt.Intern("arbace.repr.go.load$rel")

var Lit_166 *jrt.String = jrt.Intern("arbace.repr.go.load$abs_path")

var Lit_167 *jrt.String = jrt.Intern("arbace.repr.go.load$file_key")

var Lit_168 *jrt.String = jrt.Intern("arbace.repr.go.load$rel_dir")

var Lit_169 *jrt.String = jrt.Intern("arbace.repr.go.load$experiments")

var Lit_170 *jrt.String = jrt.Intern("arbace.repr.go.load$config")

var Lit_171 *jrt.String = jrt.Intern("arbace.repr.go.load$header_config")

var Lit_172 *jrt.String = jrt.Intern("arbace.repr.go.load$version_lang")

var Lit_173 *jrt.String = jrt.Intern("arbace.repr.go.load$find_module")

var Lit_174 *jrt.String = jrt.Intern("arbace.repr.go.load$plan_config")

var Lit_175 *jrt.String = jrt.Intern("arbace.repr.go.load$sha256_hex")

var Lit_176 *jrt.String = jrt.Intern("arbace.repr.go.load$embed_files")

var Lit_177 *jrt.String = jrt.Intern("arbace.repr.go.load$lists")

var Lit_178 *jrt.String = jrt.Intern("arbace.repr.go.load$imports_of")

var Lit_179 *jrt.String = jrt.Intern("arbace.repr.go.load$header")

var Lit_180 *jrt.String = jrt.Intern("arbace.repr.go.load$package_jobs")

var Lit_181 *jrt.String = jrt.Intern("arbace.repr.go.load$file_jobs")

var Lit_182 *jrt.String = jrt.Intern("arbace.repr.go.load$split_action")

var Lit_183 *jrt.String = jrt.Intern("arbace.repr.go.load$read_dir_test")

var Lit_184 *jrt.String = jrt.Intern("arbace.repr.go.load$local_prefix")

var Lit_185 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_test_view")

var Lit_186 *jrt.String = jrt.Intern("arbace.repr.go.load$runindir_jobs")

var Lit_187 *jrt.String = jrt.Intern("arbace.repr.go.load$dir_jobs")

var Lit_188 *jrt.String = jrt.Intern("arbace.repr.go.load$jobs")
