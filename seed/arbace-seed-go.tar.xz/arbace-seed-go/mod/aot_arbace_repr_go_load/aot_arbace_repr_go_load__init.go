//line aot_arbace_repr_go_load__init.ae:1
package aot_arbace_repr_go_load

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_load__init_A_Unit0__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_go_load__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_load__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_load__init_A_Unit1__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_go_load__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_load__init_A_Unit2__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_go_load_eval1667000004_loading__1927001464__auto____1667000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_load_eval1667000004_loading__1927001464__auto____1667000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_repr_go_load_eval1667000004_loading__1927001464__auto____1667000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_go_load__init_A_Unit3__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_load__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_load__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_go_load_eval1667000008_fn__1667000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_load_eval1667000008_fn__1667000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_repr_go_load_eval1667000008_fn__1667000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_go_load__init_A_Load__O() any { A_arbace_repr_go_load__init_A_Init(); jrt.StartCheck(); A_arbace_repr_go_load__init_A_Unit0__O(); A_arbace_repr_go_load__init_A_Unit1__O(); A_arbace_repr_go_load__init_A_Unit2__O(); A_arbace_repr_go_load__init_A_Unit3__O(); A_arbace_repr_go_load__init_A_Unit4__O(); A_arbace_repr_go_load__init_A_Unit5__O(); A_arbace_repr_go_load__init_A_Unit6__O(); A_arbace_repr_go_load__init_A_Unit7__O(); A_arbace_repr_go_load__init_A_Unit8__O(); A_arbace_repr_go_load__init_A_Unit9__O(); A_arbace_repr_go_load__init_A_Unit10__O(); A_arbace_repr_go_load__init_A_Unit11__O(); A_arbace_repr_go_load__init_A_Unit12__O(); A_arbace_repr_go_load__init_A_Unit13__O(); A_arbace_repr_go_load__init_A_Unit14__O(); A_arbace_repr_go_load__init_A_Unit15__O(); A_arbace_repr_go_load__init_A_Unit16__O(); A_arbace_repr_go_load__init_A_Unit17__O(); A_arbace_repr_go_load__init_A_Unit18__O(); A_arbace_repr_go_load__init_A_Unit19__O(); A_arbace_repr_go_load__init_A_Unit20__O(); A_arbace_repr_go_load__init_A_Unit21__O(); A_arbace_repr_go_load__init_A_Unit22__O(); A_arbace_repr_go_load__init_A_Unit23__O(); A_arbace_repr_go_load__init_A_Unit24__O(); A_arbace_repr_go_load__init_A_Unit25__O(); A_arbace_repr_go_load__init_A_Unit26__O(); A_arbace_repr_go_load__init_A_Unit27__O(); A_arbace_repr_go_load__init_A_Unit28__O(); A_arbace_repr_go_load__init_A_Unit29__O(); A_arbace_repr_go_load__init_A_Unit30__O(); A_arbace_repr_go_load__init_A_Unit31__O(); A_arbace_repr_go_load__init_A_Unit32__O(); A_arbace_repr_go_load__init_A_Unit33__O(); A_arbace_repr_go_load__init_A_Unit34__O(); A_arbace_repr_go_load__init_A_Unit35__O(); A_arbace_repr_go_load__init_A_Unit36__O(); return nil }


























func A_arbace_repr_go_load__init_A_Unit4__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); return lang.IFn_Cast(A_arbace_repr_go_load__init_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_load__init_A_const_5) }
func A_arbace_repr_go_load__init_A_Unit5__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var res__1 any = Lit_168; var emb__2 any; var in__2 any = lang.RT_ResourceAsStream_ClassLoader_String__InputStream_NoInit(nil, jrt.String_Cast(res__1)); if

	jrt.ByteArrayInputStream_InstanceOf(in__2) { var b__3 any = jrt.InputStream_Cast(in__2).ReadAllBytes__B1().Ref()
		jrt.InputStream_Cast(in__2).Close__V()
//line :35:1
		emb__2 = b__3 } else { emb__2 = nil }; var f__3 any; var root_7 any = /*line :33:1*/A_arbace_repr_go_load__init_A_const_6.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_9 lang.IFn; if



	linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any; var tmp1 any = A_arbace_repr_go_load_eval1667000014_fn__1667000015_A_New_O(res__1); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_load_eval1667000014_fn__1667000015_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_repr_go_load_eval1667000014_fn__1667000015_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; arg_10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_11 any; var root_13 any = A_arbace_repr_go_load__init_A_const_7.GetRawRoot__O(); var linked_14 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_13, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_15 lang.IFn; if
	linked_14 == nil { ifn_15 = lang.IFn_Cast(root_13) } else { ifn_15 = nil }; var arg_16 any = A_arbace_repr_go_load__init_A_const_8.GetRawRoot__O(); var arg_17 any; var root_18 any = A_arbace_repr_go_load__init_A_const_9.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any; var or__1927000174__auto____3 any = jrt.System_Getenv_String__String(Lit_170).Ref(); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_21 = or__1927000174__auto____3 } else { arg_21 = Lit_4 }; var arg_22 any = A_arbace_repr_go_load__init_A_const_10; if linked_19 == nil { arg_17 = ifn_20.Invoke_O_O__O(arg_21, arg_22) } else { arg_17 = linked_19.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_18, arg_21, arg_22) }; if linked_14 == nil { arg_11 = ifn_15.Invoke_O_O__O(arg_16, arg_17) } else { arg_11 = linked_14.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_13, arg_16, arg_17) }; if /*line :37:1*/ linked_8 == nil { f__3 = ifn_9.Invoke_O_O__O(arg_10, arg_11) } else { f__3 = linked_8.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_7, arg_10, arg_11) }; var tmp3 any; var and__1927000168__auto____4 any = f__3; if

	jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 bool = lang.Util_Identical_O_O__Z_NoInit(emb__2, nil); if or__1927000174__auto____5 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_23 any = A_arbace_repr_go_load__init_A_const_11.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Arrays_Equals_B1_B1__Z_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](emb__2, jrt.Prim_byte.ArrayClass()), jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__3)).ToPath__Path()))).Ref(); if linked_24 == nil { tmp3 = ifn_25.Invoke_O__O(arg_26) } else { tmp3 = linked_24.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_23, arg_26) } } } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) {
		return lang.IFn_Cast(A_arbace_repr_go_load__init_A_const_12.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(f__3)).GetPath__String().Ref()) } else {
//line :39:1
			return nil } }

func A_arbace_repr_go_load__init_A_Unit6__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var root_27 any = A_arbace_repr_go_load__init_A_const_13.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_alias_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = A_arbace_repr_go_load__init_A_const_14; var arg_31 any = A_arbace_repr_go_load__init_A_const_15; if linked_28 == nil { return ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { return linked_28.(*aot_arbace_core.A_arbace_core_alias_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) } }

func A_arbace_repr_go_load__init_A_Unit7__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); A_arbace_repr_go_load__init_A_const_16.BindRoot_O__V(Lit_171); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_17)); return A_arbace_repr_go_load__init_A_const_16 }





func A_arbace_repr_go_load__init_A_Unit8__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_18; var tmp2 any = A_arbace_repr_go_load_clean_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_repr_go_load_clean_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_172, false); A_arbace_repr_go_load_clean_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_19)); return A_arbace_repr_go_load__init_A_const_18 }













func A_arbace_repr_go_load__init_A_Unit9__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_20; var tmp2 any = A_arbace_repr_go_load_join_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_repr_go_load_join_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, true); A_arbace_repr_go_load_join_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_21)); return A_arbace_repr_go_load__init_A_const_20 }

func A_arbace_repr_go_load__init_A_Unit10__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_22; var tmp2 any = A_arbace_repr_go_load_rel_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_repr_go_load_rel_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_repr_go_load_rel_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_23)); return A_arbace_repr_go_load__init_A_const_22 }







func A_arbace_repr_go_load__init_A_Unit11__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_24; var tmp2 any = A_arbace_repr_go_load_abs_path_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_load_abs_path_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_repr_go_load_abs_path_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_25)); return A_arbace_repr_go_load__init_A_const_24 }

func A_arbace_repr_go_load__init_A_Unit12__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_26; var tmp2 any = A_arbace_repr_go_load_file_key_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_repr_go_load_file_key_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_repr_go_load_file_key_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_27)); return A_arbace_repr_go_load__init_A_const_26 }







func A_arbace_repr_go_load__init_A_Unit13__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_28; var tmp2 any = A_arbace_repr_go_load_rel_dir_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_go_load_rel_dir_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_177, false); A_arbace_repr_go_load_rel_dir_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_29)); return A_arbace_repr_go_load__init_A_const_28 }








func A_arbace_repr_go_load__init_A_Unit14__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_30; var tmp2 any = A_arbace_repr_go_load_experiments_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_go_load_experiments_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_repr_go_load_experiments_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_31)); return A_arbace_repr_go_load__init_A_const_30 }









func A_arbace_repr_go_load__init_A_Unit15__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_32; var tmp2 any = A_arbace_repr_go_load_config_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_go_load_config_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_repr_go_load_config_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_33)); return A_arbace_repr_go_load__init_A_const_32 }





















func A_arbace_repr_go_load__init_A_Unit16__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_34; var tmp2 any = A_arbace_repr_go_load_header_config_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_repr_go_load_header_config_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_repr_go_load_header_config_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_35)); return A_arbace_repr_go_load__init_A_const_34 }







func A_arbace_repr_go_load__init_A_Unit17__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_36; var tmp2 any = A_arbace_repr_go_load_version_lang_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_go_load_version_lang_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_repr_go_load_version_lang_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_37)); return A_arbace_repr_go_load__init_A_const_36 }






func A_arbace_repr_go_load__init_A_Unit18__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_38; var tmp2 any = A_arbace_repr_go_load_find_module_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_repr_go_load_find_module_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_repr_go_load_find_module_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_39)); return A_arbace_repr_go_load__init_A_const_38 }










func A_arbace_repr_go_load__init_A_Unit19__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(150, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_40; var tmp2 any = A_arbace_repr_go_load_plan_config_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_repr_go_load_plan_config_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_repr_go_load_plan_config_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_41)); return A_arbace_repr_go_load__init_A_const_40 }








func A_arbace_repr_go_load__init_A_Unit20__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_42; var tmp2 any = A_arbace_repr_go_load_sha256_hex_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_repr_go_load_sha256_hex_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_repr_go_load_sha256_hex_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_43)); return A_arbace_repr_go_load__init_A_const_42 }




func A_arbace_repr_go_load__init_A_Unit21__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_44; var tmp2 any = A_arbace_repr_go_load_embed_files_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_go_load_embed_files_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_185, false); A_arbace_repr_go_load_embed_files_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_45)); return A_arbace_repr_go_load__init_A_const_44 }


func A_arbace_repr_go_load__init_A_Unit22__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_46; var tmp2 any = A_arbace_repr_go_load_lists_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_repr_go_load_lists_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_186, false); A_arbace_repr_go_load_lists_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_47)); return A_arbace_repr_go_load__init_A_const_46 }














func A_arbace_repr_go_load__init_A_Unit23__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_48; var tmp2 any = A_arbace_repr_go_load_imports_of_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_repr_go_load_imports_of_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_187, false); A_arbace_repr_go_load_imports_of_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_49)); return A_arbace_repr_go_load__init_A_const_48 }





func A_arbace_repr_go_load__init_A_Unit24__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_50; var tmp2 any = A_arbace_repr_go_load_import_map_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_repr_go_load_import_map_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_188, false); A_arbace_repr_go_load_import_map_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_51)); return A_arbace_repr_go_load__init_A_const_50 }





func A_arbace_repr_go_load__init_A_Unit25__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(194, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_52; var tmp2 any = A_arbace_repr_go_load_header_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_go_load_header_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_189, false); A_arbace_repr_go_load_header_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_53)); return A_arbace_repr_go_load__init_A_const_52 }








func A_arbace_repr_go_load__init_A_Unit26__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_54; var tmp2 any = A_arbace_repr_go_load_package_jobs_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_repr_go_load_package_jobs_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_repr_go_load_package_jobs_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_55)); return A_arbace_repr_go_load__init_A_const_54 }


















































func A_arbace_repr_go_load__init_A_Unit27__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_56; var tmp2 any = A_arbace_repr_go_load_file_jobs_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_repr_go_load_file_jobs_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, false); A_arbace_repr_go_load_file_jobs_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_57)); return A_arbace_repr_go_load__init_A_const_56 }

































func A_arbace_repr_go_load__init_A_Unit28__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); A_arbace_repr_go_load__init_A_const_58.BindRoot_O__V(A_arbace_repr_go_load__init_A_const_59); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_60)); return A_arbace_repr_go_load__init_A_const_58 }

func A_arbace_repr_go_load__init_A_Unit29__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(290, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_61; var tmp2 any = A_arbace_repr_go_load_split_action_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_repr_go_load_split_action_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_192, false); A_arbace_repr_go_load_split_action_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_62)); return A_arbace_repr_go_load__init_A_const_61 }












func A_arbace_repr_go_load__init_A_Unit30__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); A_arbace_repr_go_load__init_A_const_63.BindRoot_O__V(A_arbace_repr_go_load__init_A_const_64); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_63; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_65)); return A_arbace_repr_go_load__init_A_const_63 }

func A_arbace_repr_go_load__init_A_Unit31__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_66; var tmp2 any = A_arbace_repr_go_load_read_dir_test_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_repr_go_load_read_dir_test_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, false); A_arbace_repr_go_load_read_dir_test_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_67)); return A_arbace_repr_go_load__init_A_const_66 }





























































func A_arbace_repr_go_load__init_A_Unit32__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_68; var tmp2 any = A_arbace_repr_go_load_local_prefix_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_repr_go_load_local_prefix_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_194, false); A_arbace_repr_go_load_local_prefix_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_69)); return A_arbace_repr_go_load__init_A_const_68 }

func A_arbace_repr_go_load__init_A_Unit33__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_70; var tmp2 any = A_arbace_repr_go_load_dir_test_view_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_repr_go_load_dir_test_view_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_195, false); A_arbace_repr_go_load_dir_test_view_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_71)); return A_arbace_repr_go_load__init_A_const_70 }





func A_arbace_repr_go_load__init_A_Unit34__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_72; var tmp2 any = A_arbace_repr_go_load_runindir_jobs_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_repr_go_load_runindir_jobs_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_196, false); A_arbace_repr_go_load_runindir_jobs_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_73)); return A_arbace_repr_go_load__init_A_const_72 }



























func A_arbace_repr_go_load__init_A_Unit35__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(403, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_74; var tmp2 any = A_arbace_repr_go_load_dir_jobs_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_repr_go_load_dir_jobs_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_197, false); A_arbace_repr_go_load_dir_jobs_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_75)); return A_arbace_repr_go_load__init_A_const_74 }





































func A_arbace_repr_go_load__init_A_Unit36__O() any { A_arbace_repr_go_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(441, 1); var tmp1 *lang.Var = A_arbace_repr_go_load__init_A_const_76; var tmp2 any = A_arbace_repr_go_load_jobs_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_repr_go_load_jobs_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_198, false); A_arbace_repr_go_load_jobs_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_load__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_load__init_A_const_77)); return A_arbace_repr_go_load__init_A_const_76 }



type A_arbace_repr_go_load__init_A struct{ jrt.Object }

var A_arbace_repr_go_load__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_load__init_A_const_0 *lang.Var

var A_arbace_repr_go_load__init_A_const_1 any

var A_arbace_repr_go_load__init_A_const_2 any

var A_arbace_repr_go_load__init_A_const_3 any

var A_arbace_repr_go_load__init_A_const_4 *lang.Var

var A_arbace_repr_go_load__init_A_const_5 any

var A_arbace_repr_go_load__init_A_const_6 *lang.Var

var A_arbace_repr_go_load__init_A_const_7 *lang.Var

var A_arbace_repr_go_load__init_A_const_8 *lang.Var

var A_arbace_repr_go_load__init_A_const_9 *lang.Var

var A_arbace_repr_go_load__init_A_const_10 any

var A_arbace_repr_go_load__init_A_const_11 *lang.Var

var A_arbace_repr_go_load__init_A_const_12 *lang.Var

var A_arbace_repr_go_load__init_A_const_13 *lang.Var

var A_arbace_repr_go_load__init_A_const_14 any

var A_arbace_repr_go_load__init_A_const_15 any

var A_arbace_repr_go_load__init_A_const_16 *lang.Var

var A_arbace_repr_go_load__init_A_const_17 any

var A_arbace_repr_go_load__init_A_const_18 *lang.Var

var A_arbace_repr_go_load__init_A_const_19 any

var A_arbace_repr_go_load__init_A_const_20 *lang.Var

var A_arbace_repr_go_load__init_A_const_21 any

var A_arbace_repr_go_load__init_A_const_22 *lang.Var

var A_arbace_repr_go_load__init_A_const_23 any

var A_arbace_repr_go_load__init_A_const_24 *lang.Var

var A_arbace_repr_go_load__init_A_const_25 any

var A_arbace_repr_go_load__init_A_const_26 *lang.Var

var A_arbace_repr_go_load__init_A_const_27 any

var A_arbace_repr_go_load__init_A_const_28 *lang.Var

var A_arbace_repr_go_load__init_A_const_29 any

var A_arbace_repr_go_load__init_A_const_30 *lang.Var

var A_arbace_repr_go_load__init_A_const_31 any

var A_arbace_repr_go_load__init_A_const_32 *lang.Var

var A_arbace_repr_go_load__init_A_const_33 any

var A_arbace_repr_go_load__init_A_const_34 *lang.Var

var A_arbace_repr_go_load__init_A_const_35 any

var A_arbace_repr_go_load__init_A_const_36 *lang.Var

var A_arbace_repr_go_load__init_A_const_37 any

var A_arbace_repr_go_load__init_A_const_38 *lang.Var

var A_arbace_repr_go_load__init_A_const_39 any

var A_arbace_repr_go_load__init_A_const_40 *lang.Var

var A_arbace_repr_go_load__init_A_const_41 any

var A_arbace_repr_go_load__init_A_const_42 *lang.Var

var A_arbace_repr_go_load__init_A_const_43 any

var A_arbace_repr_go_load__init_A_const_44 *lang.Var

var A_arbace_repr_go_load__init_A_const_45 any

var A_arbace_repr_go_load__init_A_const_46 *lang.Var

var A_arbace_repr_go_load__init_A_const_47 any

var A_arbace_repr_go_load__init_A_const_48 *lang.Var

var A_arbace_repr_go_load__init_A_const_49 any

var A_arbace_repr_go_load__init_A_const_50 *lang.Var

var A_arbace_repr_go_load__init_A_const_51 any

var A_arbace_repr_go_load__init_A_const_52 *lang.Var

var A_arbace_repr_go_load__init_A_const_53 any

var A_arbace_repr_go_load__init_A_const_54 *lang.Var

var A_arbace_repr_go_load__init_A_const_55 any

var A_arbace_repr_go_load__init_A_const_56 *lang.Var

var A_arbace_repr_go_load__init_A_const_57 any

var A_arbace_repr_go_load__init_A_const_58 *lang.Var

var A_arbace_repr_go_load__init_A_const_59 any

var A_arbace_repr_go_load__init_A_const_60 any

var A_arbace_repr_go_load__init_A_const_61 *lang.Var

var A_arbace_repr_go_load__init_A_const_62 any

var A_arbace_repr_go_load__init_A_const_63 *lang.Var

var A_arbace_repr_go_load__init_A_const_64 any

var A_arbace_repr_go_load__init_A_const_65 any

var A_arbace_repr_go_load__init_A_const_66 *lang.Var

var A_arbace_repr_go_load__init_A_const_67 any

var A_arbace_repr_go_load__init_A_const_68 *lang.Var

var A_arbace_repr_go_load__init_A_const_69 any

var A_arbace_repr_go_load__init_A_const_70 *lang.Var

var A_arbace_repr_go_load__init_A_const_71 any

var A_arbace_repr_go_load__init_A_const_72 *lang.Var

var A_arbace_repr_go_load__init_A_const_73 any

var A_arbace_repr_go_load__init_A_const_74 *lang.Var

var A_arbace_repr_go_load__init_A_const_75 any

var A_arbace_repr_go_load__init_A_const_76 *lang.Var

var A_arbace_repr_go_load__init_A_const_77 any

var A_arbace_repr_go_load__init_A_init jrt.ClassInit

func A_arbace_repr_go_load__init_A_Init() { if !A_arbace_repr_go_load__init_A_init.Done() { A_arbace_repr_go_load__init_A_init.Run(A_arbace_repr_go_load__init_A_clinit) } }

func A_arbace_repr_go_load__init_A_clinit() { A_arbace_repr_go_load__init_A_clinit_p0(); A_arbace_repr_go_load__init_A_clinit_p1(); A_arbace_repr_go_load__init_A_clinit_p2(); A_arbace_repr_go_load__init_A_clinit_p3(); A_arbace_repr_go_load__init_A_clinit_p4(); A_arbace_repr_go_load__init_A_clinit_p5() }

func A_arbace_repr_go_load__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_load__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_165, 121); A_arbace_repr_go_load__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[43]); A_arbace_repr_go_load__init_A_const_1 = A_arbace_repr_go_load__init_A_const_pool.A[44]; A_arbace_repr_go_load__init_A_const_2 = A_arbace_repr_go_load__init_A_const_pool.A[45]; A_arbace_repr_go_load__init_A_const_3 = A_arbace_repr_go_load__init_A_const_pool.A[46]; A_arbace_repr_go_load__init_A_const_4 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[47]); A_arbace_repr_go_load__init_A_const_5 = A_arbace_repr_go_load__init_A_const_pool.A[48]; A_arbace_repr_go_load__init_A_const_6 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[49]); A_arbace_repr_go_load__init_A_const_7 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[50]); A_arbace_repr_go_load__init_A_const_8 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[51]); A_arbace_repr_go_load__init_A_const_9 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[52]); A_arbace_repr_go_load__init_A_const_10 = A_arbace_repr_go_load__init_A_const_pool.A[53]; A_arbace_repr_go_load__init_A_const_11 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[54]) }

func A_arbace_repr_go_load__init_A_clinit_p1() { A_arbace_repr_go_load__init_A_const_12 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[55]); A_arbace_repr_go_load__init_A_const_13 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[56]); A_arbace_repr_go_load__init_A_const_14 = A_arbace_repr_go_load__init_A_const_pool.A[57]; A_arbace_repr_go_load__init_A_const_15 = A_arbace_repr_go_load__init_A_const_pool.A[58]; A_arbace_repr_go_load__init_A_const_16 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[59]); A_arbace_repr_go_load__init_A_const_17 = A_arbace_repr_go_load__init_A_const_pool.A[60]; A_arbace_repr_go_load__init_A_const_18 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[61]); A_arbace_repr_go_load__init_A_const_19 = A_arbace_repr_go_load__init_A_const_pool.A[62]; A_arbace_repr_go_load__init_A_const_20 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[63]); A_arbace_repr_go_load__init_A_const_21 = A_arbace_repr_go_load__init_A_const_pool.A[64]; A_arbace_repr_go_load__init_A_const_22 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[65]); A_arbace_repr_go_load__init_A_const_23 = A_arbace_repr_go_load__init_A_const_pool.A[66]; A_arbace_repr_go_load__init_A_const_24 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[67]) }

func A_arbace_repr_go_load__init_A_clinit_p2() { A_arbace_repr_go_load__init_A_const_25 = A_arbace_repr_go_load__init_A_const_pool.A[68]; A_arbace_repr_go_load__init_A_const_26 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[69]); A_arbace_repr_go_load__init_A_const_27 = A_arbace_repr_go_load__init_A_const_pool.A[70]; A_arbace_repr_go_load__init_A_const_28 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[71]); A_arbace_repr_go_load__init_A_const_29 = A_arbace_repr_go_load__init_A_const_pool.A[72]; A_arbace_repr_go_load__init_A_const_30 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[73]); A_arbace_repr_go_load__init_A_const_31 = A_arbace_repr_go_load__init_A_const_pool.A[74]; A_arbace_repr_go_load__init_A_const_32 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[75]); A_arbace_repr_go_load__init_A_const_33 = A_arbace_repr_go_load__init_A_const_pool.A[76]; A_arbace_repr_go_load__init_A_const_34 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[77]); A_arbace_repr_go_load__init_A_const_35 = A_arbace_repr_go_load__init_A_const_pool.A[78]; A_arbace_repr_go_load__init_A_const_36 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[79]); A_arbace_repr_go_load__init_A_const_37 = A_arbace_repr_go_load__init_A_const_pool.A[80] }

func A_arbace_repr_go_load__init_A_clinit_p3() { A_arbace_repr_go_load__init_A_const_38 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[81]); A_arbace_repr_go_load__init_A_const_39 = A_arbace_repr_go_load__init_A_const_pool.A[82]; A_arbace_repr_go_load__init_A_const_40 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[83]); A_arbace_repr_go_load__init_A_const_41 = A_arbace_repr_go_load__init_A_const_pool.A[84]; A_arbace_repr_go_load__init_A_const_42 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[85]); A_arbace_repr_go_load__init_A_const_43 = A_arbace_repr_go_load__init_A_const_pool.A[86]; A_arbace_repr_go_load__init_A_const_44 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[87]); A_arbace_repr_go_load__init_A_const_45 = A_arbace_repr_go_load__init_A_const_pool.A[88]; A_arbace_repr_go_load__init_A_const_46 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[89]); A_arbace_repr_go_load__init_A_const_47 = A_arbace_repr_go_load__init_A_const_pool.A[90]; A_arbace_repr_go_load__init_A_const_48 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[91]); A_arbace_repr_go_load__init_A_const_49 = A_arbace_repr_go_load__init_A_const_pool.A[92]; A_arbace_repr_go_load__init_A_const_50 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[93]) }

func A_arbace_repr_go_load__init_A_clinit_p4() { A_arbace_repr_go_load__init_A_const_51 = A_arbace_repr_go_load__init_A_const_pool.A[94]; A_arbace_repr_go_load__init_A_const_52 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[95]); A_arbace_repr_go_load__init_A_const_53 = A_arbace_repr_go_load__init_A_const_pool.A[96]; A_arbace_repr_go_load__init_A_const_54 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[97]); A_arbace_repr_go_load__init_A_const_55 = A_arbace_repr_go_load__init_A_const_pool.A[98]; A_arbace_repr_go_load__init_A_const_56 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[99]); A_arbace_repr_go_load__init_A_const_57 = A_arbace_repr_go_load__init_A_const_pool.A[100]; A_arbace_repr_go_load__init_A_const_58 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[101]); A_arbace_repr_go_load__init_A_const_59 = A_arbace_repr_go_load__init_A_const_pool.A[102]; A_arbace_repr_go_load__init_A_const_60 = A_arbace_repr_go_load__init_A_const_pool.A[103]; A_arbace_repr_go_load__init_A_const_61 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[104]); A_arbace_repr_go_load__init_A_const_62 = A_arbace_repr_go_load__init_A_const_pool.A[105]; A_arbace_repr_go_load__init_A_const_63 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[106]); A_arbace_repr_go_load__init_A_const_64 = A_arbace_repr_go_load__init_A_const_pool.A[107] }

func A_arbace_repr_go_load__init_A_clinit_p5() { A_arbace_repr_go_load__init_A_const_65 = A_arbace_repr_go_load__init_A_const_pool.A[108]; A_arbace_repr_go_load__init_A_const_66 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[109]); A_arbace_repr_go_load__init_A_const_67 = A_arbace_repr_go_load__init_A_const_pool.A[110]; A_arbace_repr_go_load__init_A_const_68 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[111]); A_arbace_repr_go_load__init_A_const_69 = A_arbace_repr_go_load__init_A_const_pool.A[112]; A_arbace_repr_go_load__init_A_const_70 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[113]); A_arbace_repr_go_load__init_A_const_71 = A_arbace_repr_go_load__init_A_const_pool.A[114]; A_arbace_repr_go_load__init_A_const_72 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[115]); A_arbace_repr_go_load__init_A_const_73 = A_arbace_repr_go_load__init_A_const_pool.A[116]; A_arbace_repr_go_load__init_A_const_74 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[117]); A_arbace_repr_go_load__init_A_const_75 = A_arbace_repr_go_load__init_A_const_pool.A[118]; A_arbace_repr_go_load__init_A_const_76 = lang.Var_Cast(A_arbace_repr_go_load__init_A_const_pool.A[119]); A_arbace_repr_go_load__init_A_const_77 = A_arbace_repr_go_load__init_A_const_pool.A[120] }

func A_arbace_repr_go_load__init_A_New() *A_arbace_repr_go_load__init_A { A_arbace_repr_go_load__init_A_Init(); t := &A_arbace_repr_go_load__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_load__init_A) Ctor() {}

func (t *A_arbace_repr_go_load__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_load__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_load__init_A_class }

func (t *A_arbace_repr_go_load__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_load__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_load__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_load__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_load__init_A); return ok }

func A_arbace_repr_go_load__init_A_Cast(x any) *A_arbace_repr_go_load__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_load__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_load__init_A_class)) }; return v }
