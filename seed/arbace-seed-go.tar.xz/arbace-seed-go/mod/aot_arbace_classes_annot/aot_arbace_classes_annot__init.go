//line aot_arbace_classes_annot__init.ae:1
package aot_arbace_classes_annot

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_annot__init_A_Unit0__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_annot__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_annot__init_A_const_1) }
//line :1:1
func A_arbace_classes_annot__init_A_Unit1__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_annot__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_2)) }
//line :1:1
func A_arbace_classes_annot__init_A_Unit2__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, nil); A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_classes_annot__init_A_Unit3__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_annot__init_A_const_1)).Equals_O__Z(A_arbace_classes_annot__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_annot_eval851000008_fn__851000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_annot_eval851000008_fn__851000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, nil); A_arbace_classes_annot_eval851000008_fn__851000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_classes_annot__init_A_Load__O() any { A_arbace_classes_annot__init_A_Init(); jrt.StartCheck(); A_arbace_classes_annot__init_A_Unit0__O(); A_arbace_classes_annot__init_A_Unit1__O(); A_arbace_classes_annot__init_A_Unit2__O(); A_arbace_classes_annot__init_A_Unit3__O(); A_arbace_classes_annot__init_A_Unit4__O(); A_arbace_classes_annot__init_A_Unit5__O(); A_arbace_classes_annot__init_A_Unit6__O(); A_arbace_classes_annot__init_A_Unit7__O(); A_arbace_classes_annot__init_A_Unit8__O(); A_arbace_classes_annot__init_A_Unit9__O(); A_arbace_classes_annot__init_A_Unit10__O(); A_arbace_classes_annot__init_A_Unit11__O(); A_arbace_classes_annot__init_A_Unit12__O(); A_arbace_classes_annot__init_A_Unit13__O(); A_arbace_classes_annot__init_A_Unit14__O(); A_arbace_classes_annot__init_A_Unit15__O(); A_arbace_classes_annot__init_A_Unit16__O(); A_arbace_classes_annot__init_A_Unit17__O(); A_arbace_classes_annot__init_A_Unit18__O(); A_arbace_classes_annot__init_A_Unit19__O(); A_arbace_classes_annot__init_A_Unit20__O(); A_arbace_classes_annot__init_A_Unit21__O(); A_arbace_classes_annot__init_A_Unit22__O(); A_arbace_classes_annot__init_A_Unit23__O(); A_arbace_classes_annot__init_A_Unit24__O(); A_arbace_classes_annot__init_A_Unit25__O(); A_arbace_classes_annot__init_A_Unit26__O(); A_arbace_classes_annot__init_A_Unit27__O(); A_arbace_classes_annot__init_A_Unit28__O(); A_arbace_classes_annot__init_A_Unit29__O(); A_arbace_classes_annot__init_A_Unit30__O(); A_arbace_classes_annot__init_A_Unit31__O(); return nil }













func A_arbace_classes_annot__init_A_Unit4__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_4; var tmp2 any; var root_5 any = A_arbace_classes_annot__init_A_const_5.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_ns_resolve_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_classes_annot__init_A_const_6; var arg_9 any = A_arbace_classes_annot__init_A_const_7; if linked_6 == nil { tmp2 = ifn_7.Invoke_O_O__O(arg_8, arg_9) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_ns_resolve_A).Invoke_O_O_O__O(root_5, arg_8, arg_9) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_classes_annot__init_A_const_4; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_8)); return A_arbace_classes_annot__init_A_const_4 }

func A_arbace_classes_annot__init_A_Unit5__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_9; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__11 any = A_arbace_classes_annot_lenient_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_annot_lenient_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, true, nil); A_arbace_classes_annot_lenient_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__11, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_10)); return A_arbace_classes_annot__init_A_const_9 }
//line :21:1
func A_arbace_classes_annot__init_A_Unit6__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); A_arbace_classes_annot__init_A_const_9.SetMacro__V(); return nil }
//line :21:1
func A_arbace_classes_annot__init_A_Unit7__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); return A_arbace_classes_annot__init_A_const_9 }



func A_arbace_classes_annot__init_A_Unit8__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__13 any = A_arbace_classes_annot_fn__851000017_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_annot_fn__851000017_A_fn_class; if
							fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, nil); A_arbace_classes_annot_fn__851000017_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__13, tmp3, nil); /*line :25:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_12)); return A_arbace_classes_annot__init_A_const_11 }


func A_arbace_classes_annot__init_A_Unit9__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__15 any = A_arbace_classes_annot_bin_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_annot_bin_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, nil); A_arbace_classes_annot_bin_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__15, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_14)); return A_arbace_classes_annot__init_A_const_13 }

func A_arbace_classes_annot__init_A_Unit10__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__17 any = A_arbace_classes_annot_enc_string_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_annot_enc_string_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, nil); A_arbace_classes_annot_enc_string_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__17, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_16)); return A_arbace_classes_annot__init_A_const_15 }














func A_arbace_classes_annot__init_A_Unit11__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_18)); return A_arbace_classes_annot__init_A_const_17 }

func A_arbace_classes_annot__init_A_Unit12__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__19 any = A_arbace_classes_annot_enc_value_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_annot_enc_value_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, nil); A_arbace_classes_annot_enc_value_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__19, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_20)); return A_arbace_classes_annot__init_A_const_19 }
























func A_arbace_classes_annot__init_A_Unit13__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__21 any = A_arbace_classes_annot_enc_annotation_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_annot_enc_annotation_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, nil); A_arbace_classes_annot_enc_annotation_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__21, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_21)); return A_arbace_classes_annot__init_A_const_17 }






func A_arbace_classes_annot__init_A_Unit14__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__23 any = A_arbace_classes_annot_visible_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_annot_visible_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, nil); A_arbace_classes_annot_visible_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__23, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_23)); return A_arbace_classes_annot__init_A_const_22 }









func A_arbace_classes_annot__init_A_Unit15__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__25 any = A_arbace_classes_annot_safe_ctor_desc_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_annot_safe_ctor_desc_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_168, false, nil); A_arbace_classes_annot_safe_ctor_desc_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__25, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_25)); return A_arbace_classes_annot__init_A_const_24 }






func A_arbace_classes_annot__init_A_Unit16__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__27 any = A_arbace_classes_annot_ctor_lead_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_annot_ctor_lead_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, false, nil); A_arbace_classes_annot_ctor_lead_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__27, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_27)); return A_arbace_classes_annot__init_A_const_26 }










func A_arbace_classes_annot__init_A_Unit17__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__29 any = A_arbace_classes_annot_reflected_member_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_classes_annot_reflected_member_QMARK__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_classes_annot_reflected_member_QMARK__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__29, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_29)); return A_arbace_classes_annot__init_A_const_28 }






func A_arbace_classes_annot__init_A_Unit18__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_31)); return A_arbace_classes_annot__init_A_const_30 }

func A_arbace_classes_annot__init_A_Unit19__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__31 any = A_arbace_classes_annot_attribute_lines_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_annot_attribute_lines_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, nil); A_arbace_classes_annot_attribute_lines_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__31, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_33)); return A_arbace_classes_annot__init_A_const_32 }









































func A_arbace_classes_annot__init_A_Unit20__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__33 any = A_arbace_classes_annot_throws_lines_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_annot_throws_lines_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_172, false, nil); A_arbace_classes_annot_throws_lines_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__33, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_34)); return A_arbace_classes_annot__init_A_const_30 }





















func A_arbace_classes_annot__init_A_Unit21__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__35 any = A_arbace_classes_annot_pool_index_BANG__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_classes_annot_pool_index_BANG__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, nil); A_arbace_classes_annot_pool_index_BANG__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__35, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_36)); return A_arbace_classes_annot__init_A_const_35 }












func A_arbace_classes_annot__init_A_Unit22__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(193, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__37 any = A_arbace_classes_annot_u1_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_classes_annot_u1_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, nil); A_arbace_classes_annot_u1_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__37, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_38)); return A_arbace_classes_annot__init_A_const_37 }
func A_arbace_classes_annot__init_A_Unit23__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(194, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__39 any = A_arbace_classes_annot_u2_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_classes_annot_u2_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, nil); A_arbace_classes_annot_u2_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__39, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_40)); return A_arbace_classes_annot__init_A_const_39 }

func A_arbace_classes_annot__init_A_Unit24__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_42)); return A_arbace_classes_annot__init_A_const_41 }

func A_arbace_classes_annot__init_A_Unit25__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__41 any = A_arbace_classes_annot_element_value_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_classes_annot_element_value_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, nil); A_arbace_classes_annot_element_value_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__41, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_44)); return A_arbace_classes_annot__init_A_const_43 }





















func A_arbace_classes_annot__init_A_Unit26__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(220, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__43 any = A_arbace_classes_annot_type_ann_body_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_classes_annot_type_ann_body_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, nil); A_arbace_classes_annot_type_ann_body_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__43, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_45)); return A_arbace_classes_annot__init_A_const_41 }








func A_arbace_classes_annot__init_A_Unit27__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__45 any = A_arbace_classes_annot_target_info_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_classes_annot_target_info_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, nil); A_arbace_classes_annot_target_info_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__45, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_47)); return A_arbace_classes_annot__init_A_const_46 }












func A_arbace_classes_annot__init_A_Unit28__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__47 any = A_arbace_classes_annot_type_path_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_classes_annot_type_path_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, nil); A_arbace_classes_annot_type_path_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_49)); return A_arbace_classes_annot__init_A_const_48 }














func A_arbace_classes_annot__init_A_Unit29__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(257, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__49 any = A_arbace_classes_annot_type_annotations_bytes_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_classes_annot_type_annotations_bytes_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_180, false, nil); A_arbace_classes_annot_type_annotations_bytes_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__49, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_51)); return A_arbace_classes_annot__init_A_const_50 }



















func A_arbace_classes_annot__init_A_Unit30__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__51 any = A_arbace_classes_annot_type_annotation_lines_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_181, false, nil); A_arbace_classes_annot_type_annotation_lines_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__51, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_53)); return A_arbace_classes_annot__init_A_const_52 }


























func A_arbace_classes_annot__init_A_Unit31__O() any { A_arbace_classes_annot__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_classes_annot__init_A_const_54; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__53 any = A_arbace_classes_annot_class_data_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_classes_annot_class_data_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_182, true, nil); A_arbace_classes_annot_class_data_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__53, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_annot__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_annot__init_A_const_55)); return A_arbace_classes_annot__init_A_const_54 }



type A_arbace_classes_annot__init_A struct{ jrt.Object }

var A_arbace_classes_annot__init_A_const_pool *jrt.RefArray

var A_arbace_classes_annot__init_A_const_0 *lang.Var

var A_arbace_classes_annot__init_A_const_1 any

var A_arbace_classes_annot__init_A_const_2 any

var A_arbace_classes_annot__init_A_const_3 any

var A_arbace_classes_annot__init_A_const_4 *lang.Var

var A_arbace_classes_annot__init_A_const_5 *lang.Var

var A_arbace_classes_annot__init_A_const_6 any

var A_arbace_classes_annot__init_A_const_7 any

var A_arbace_classes_annot__init_A_const_8 any

var A_arbace_classes_annot__init_A_const_9 *lang.Var

var A_arbace_classes_annot__init_A_const_10 any

var A_arbace_classes_annot__init_A_const_11 *lang.Var

var A_arbace_classes_annot__init_A_const_12 any

var A_arbace_classes_annot__init_A_const_13 *lang.Var

var A_arbace_classes_annot__init_A_const_14 any

var A_arbace_classes_annot__init_A_const_15 *lang.Var

var A_arbace_classes_annot__init_A_const_16 any

var A_arbace_classes_annot__init_A_const_17 *lang.Var

var A_arbace_classes_annot__init_A_const_18 any

var A_arbace_classes_annot__init_A_const_19 *lang.Var

var A_arbace_classes_annot__init_A_const_20 any

var A_arbace_classes_annot__init_A_const_21 any

var A_arbace_classes_annot__init_A_const_22 *lang.Var

var A_arbace_classes_annot__init_A_const_23 any

var A_arbace_classes_annot__init_A_const_24 *lang.Var

var A_arbace_classes_annot__init_A_const_25 any

var A_arbace_classes_annot__init_A_const_26 *lang.Var

var A_arbace_classes_annot__init_A_const_27 any

var A_arbace_classes_annot__init_A_const_28 *lang.Var

var A_arbace_classes_annot__init_A_const_29 any

var A_arbace_classes_annot__init_A_const_30 *lang.Var

var A_arbace_classes_annot__init_A_const_31 any

var A_arbace_classes_annot__init_A_const_32 *lang.Var

var A_arbace_classes_annot__init_A_const_33 any

var A_arbace_classes_annot__init_A_const_34 any

var A_arbace_classes_annot__init_A_const_35 *lang.Var

var A_arbace_classes_annot__init_A_const_36 any

var A_arbace_classes_annot__init_A_const_37 *lang.Var

var A_arbace_classes_annot__init_A_const_38 any

var A_arbace_classes_annot__init_A_const_39 *lang.Var

var A_arbace_classes_annot__init_A_const_40 any

var A_arbace_classes_annot__init_A_const_41 *lang.Var

var A_arbace_classes_annot__init_A_const_42 any

var A_arbace_classes_annot__init_A_const_43 *lang.Var

var A_arbace_classes_annot__init_A_const_44 any

var A_arbace_classes_annot__init_A_const_45 any

var A_arbace_classes_annot__init_A_const_46 *lang.Var

var A_arbace_classes_annot__init_A_const_47 any

var A_arbace_classes_annot__init_A_const_48 *lang.Var

var A_arbace_classes_annot__init_A_const_49 any

var A_arbace_classes_annot__init_A_const_50 *lang.Var

var A_arbace_classes_annot__init_A_const_51 any

var A_arbace_classes_annot__init_A_const_52 *lang.Var

var A_arbace_classes_annot__init_A_const_53 any

var A_arbace_classes_annot__init_A_const_54 *lang.Var

var A_arbace_classes_annot__init_A_const_55 any

var A_arbace_classes_annot__init_A_init jrt.ClassInit

func A_arbace_classes_annot__init_A_Init() { if !A_arbace_classes_annot__init_A_init.Done() { A_arbace_classes_annot__init_A_init.Run(A_arbace_classes_annot__init_A_clinit) } }

func A_arbace_classes_annot__init_A_clinit() { A_arbace_classes_annot__init_A_clinit_p0(); A_arbace_classes_annot__init_A_clinit_p1(); A_arbace_classes_annot__init_A_clinit_p2(); A_arbace_classes_annot__init_A_clinit_p3(); A_arbace_classes_annot__init_A_clinit_p4() }

func A_arbace_classes_annot__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_annot__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_158, 84); A_arbace_classes_annot__init_A_const_0 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[28]); A_arbace_classes_annot__init_A_const_1 = A_arbace_classes_annot__init_A_const_pool.A[29]; A_arbace_classes_annot__init_A_const_2 = A_arbace_classes_annot__init_A_const_pool.A[30]; A_arbace_classes_annot__init_A_const_3 = A_arbace_classes_annot__init_A_const_pool.A[31]; A_arbace_classes_annot__init_A_const_4 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[32]); A_arbace_classes_annot__init_A_const_5 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[33]); A_arbace_classes_annot__init_A_const_6 = A_arbace_classes_annot__init_A_const_pool.A[34]; A_arbace_classes_annot__init_A_const_7 = A_arbace_classes_annot__init_A_const_pool.A[35]; A_arbace_classes_annot__init_A_const_8 = A_arbace_classes_annot__init_A_const_pool.A[36]; A_arbace_classes_annot__init_A_const_9 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[37]); A_arbace_classes_annot__init_A_const_10 = A_arbace_classes_annot__init_A_const_pool.A[38]; A_arbace_classes_annot__init_A_const_11 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[39]); A_arbace_classes_annot__init_A_const_12 = A_arbace_classes_annot__init_A_const_pool.A[40] }

func A_arbace_classes_annot__init_A_clinit_p1() { A_arbace_classes_annot__init_A_const_13 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[41]); A_arbace_classes_annot__init_A_const_14 = A_arbace_classes_annot__init_A_const_pool.A[42]; A_arbace_classes_annot__init_A_const_15 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[43]); A_arbace_classes_annot__init_A_const_16 = A_arbace_classes_annot__init_A_const_pool.A[44]; A_arbace_classes_annot__init_A_const_17 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[45]); A_arbace_classes_annot__init_A_const_18 = A_arbace_classes_annot__init_A_const_pool.A[46]; A_arbace_classes_annot__init_A_const_19 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[47]); A_arbace_classes_annot__init_A_const_20 = A_arbace_classes_annot__init_A_const_pool.A[48]; A_arbace_classes_annot__init_A_const_21 = A_arbace_classes_annot__init_A_const_pool.A[49]; A_arbace_classes_annot__init_A_const_22 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[50]); A_arbace_classes_annot__init_A_const_23 = A_arbace_classes_annot__init_A_const_pool.A[51]; A_arbace_classes_annot__init_A_const_24 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[52]); A_arbace_classes_annot__init_A_const_25 = A_arbace_classes_annot__init_A_const_pool.A[53] }

func A_arbace_classes_annot__init_A_clinit_p2() { A_arbace_classes_annot__init_A_const_26 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[54]); A_arbace_classes_annot__init_A_const_27 = A_arbace_classes_annot__init_A_const_pool.A[55]; A_arbace_classes_annot__init_A_const_28 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[56]); A_arbace_classes_annot__init_A_const_29 = A_arbace_classes_annot__init_A_const_pool.A[57]; A_arbace_classes_annot__init_A_const_30 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[58]); A_arbace_classes_annot__init_A_const_31 = A_arbace_classes_annot__init_A_const_pool.A[59]; A_arbace_classes_annot__init_A_const_32 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[60]); A_arbace_classes_annot__init_A_const_33 = A_arbace_classes_annot__init_A_const_pool.A[61]; A_arbace_classes_annot__init_A_const_34 = A_arbace_classes_annot__init_A_const_pool.A[62]; A_arbace_classes_annot__init_A_const_35 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[63]); A_arbace_classes_annot__init_A_const_36 = A_arbace_classes_annot__init_A_const_pool.A[64]; A_arbace_classes_annot__init_A_const_37 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[65]); A_arbace_classes_annot__init_A_const_38 = A_arbace_classes_annot__init_A_const_pool.A[66] }

func A_arbace_classes_annot__init_A_clinit_p3() { A_arbace_classes_annot__init_A_const_39 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[67]); A_arbace_classes_annot__init_A_const_40 = A_arbace_classes_annot__init_A_const_pool.A[68]; A_arbace_classes_annot__init_A_const_41 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[69]); A_arbace_classes_annot__init_A_const_42 = A_arbace_classes_annot__init_A_const_pool.A[70]; A_arbace_classes_annot__init_A_const_43 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[71]); A_arbace_classes_annot__init_A_const_44 = A_arbace_classes_annot__init_A_const_pool.A[72]; A_arbace_classes_annot__init_A_const_45 = A_arbace_classes_annot__init_A_const_pool.A[73]; A_arbace_classes_annot__init_A_const_46 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[74]); A_arbace_classes_annot__init_A_const_47 = A_arbace_classes_annot__init_A_const_pool.A[75]; A_arbace_classes_annot__init_A_const_48 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[76]); A_arbace_classes_annot__init_A_const_49 = A_arbace_classes_annot__init_A_const_pool.A[77]; A_arbace_classes_annot__init_A_const_50 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[78]); A_arbace_classes_annot__init_A_const_51 = A_arbace_classes_annot__init_A_const_pool.A[79] }

func A_arbace_classes_annot__init_A_clinit_p4() { A_arbace_classes_annot__init_A_const_52 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[80]); A_arbace_classes_annot__init_A_const_53 = A_arbace_classes_annot__init_A_const_pool.A[81]; A_arbace_classes_annot__init_A_const_54 = lang.Var_Cast(A_arbace_classes_annot__init_A_const_pool.A[82]); A_arbace_classes_annot__init_A_const_55 = A_arbace_classes_annot__init_A_const_pool.A[83] }

func A_arbace_classes_annot__init_A_New() *A_arbace_classes_annot__init_A { A_arbace_classes_annot__init_A_Init(); t := &A_arbace_classes_annot__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_annot__init_A) Ctor() {}

func (t *A_arbace_classes_annot__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_annot__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_annot__init_A_class }

func (t *A_arbace_classes_annot__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_annot__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_annot__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_annot__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_annot__init_A); return ok }

func A_arbace_classes_annot__init_A_Cast(x any) *A_arbace_classes_annot__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_annot__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_annot__init_A_class)) }; return v }
