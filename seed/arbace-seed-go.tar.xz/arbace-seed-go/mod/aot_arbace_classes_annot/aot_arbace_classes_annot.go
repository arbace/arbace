//line aot_arbace_classes_annot.ae:1
package aot_arbace_classes_annot

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A_New() *A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_annot_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_annot_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_classes_annot_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_classes_annot_A_const_1, A_arbace_classes_annot_A_const_2, A_arbace_classes_annot_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_annot_eval851000008_fn__851000009_A_New() *A_arbace_classes_annot_eval851000008_fn__851000009_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_eval851000008_fn__851000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_annot_eval851000008_fn__851000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_annot_eval851000008_fn__851000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_classes_annot_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_classes_annot_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_annot_A_const_9.GetRawRoot__O(), A_arbace_classes_annot_A_const_10) }



















func A_arbace_classes_annot_lenient_A_New() *A_arbace_classes_annot_lenient_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_lenient_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_classes_annot_lenient_A) Ctor() {}
//line :21:1
func (t *A_arbace_classes_annot_lenient_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_21 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_annot_A_const_14); var tmp3 any = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_annot_A_const_15); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()); var tmp5 any; var root_32 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_annot_A_const_16); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()); var tmp9 any; var root_42 any = A_arbace_classes_annot_A_const_17.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_classes_annot_A_const_18.GetRawRoot__O(); var arg_46 any; var root_47 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any; var root_51 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_annot_A_const_19); var arg_55 any = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_TRUE.Ref()); if linked_52 == nil { arg_50 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { arg_50 = linked_52.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; if linked_48 == nil { arg_46 = ifn_49.Invoke_O__O(arg_50) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_47, arg_50) }; if linked_43 == nil { tmp9 = ifn_44.Invoke_O_O__O(arg_45, arg_46) } else { tmp9 = linked_43.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_42, arg_45, arg_46) }; arg_35 = tmp6.Invoke_O_O_O__O(tmp7, tmp8.Invoke_O__O(tmp9), body__2); if linked_33 == nil { tmp5 = ifn_34.Invoke_O__O(arg_35) } else { tmp5 = linked_33.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_32, arg_35) }; var tmp10 any = tmp4.Invoke_O__O(tmp5); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()); var tmp12 any; var root_56 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any; var root_60 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.IFn_Cast(A_arbace_classes_annot_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_annot_A_const_20); var arg_64 any = body__2; if linked_61 == nil { arg_59 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { arg_59 = linked_61.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; if linked_57 == nil { tmp12 = ifn_58.Invoke_O__O(arg_59) } else { tmp12 = linked_57.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_56, arg_59) }; arg_24 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_22 == nil { return ifn_23.Invoke_O__O(arg_24) } else { return linked_22.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_21, arg_24) } }




func A_arbace_classes_annot_fn__851000017_A_New() *A_arbace_classes_annot_fn__851000017_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_fn__851000017_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_classes_annot_fn__851000017_A) Ctor() {}
//line :26:1
func (t *A_arbace_classes_annot_fn__851000017_A) Invoke_O__O(self any) any { var temp__1927000408__auto____1 any; var root_65 any = A_arbace_classes_annot_A_const_21.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_ns_resolve_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_classes_annot_A_const_22; var arg_69 any = A_arbace_classes_annot_A_const_23; if linked_66 == nil { temp__1927000408__auto____1 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { temp__1927000408__auto____1 = linked_66.(*aot_arbace_core.A_arbace_core_ns_resolve_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; if jrt.J2g_Truth(temp__1927000408__auto____1) { var v__2 any = temp__1927000408__auto____1; var root_70 any = A_arbace_classes_annot_A_const_7.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = v__2; if linked_71 == nil { return ifn_72.Invoke_O__O(arg_73) } else { return linked_71.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_70, arg_73) } } else { var fnbody__75 any = A_arbace_classes_annot_fn__851000017_fn__851000018_A_New(); var tmp1 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_classes_annot_fn__851000017_fn__851000018_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_classes_annot_fn__851000017_fn__851000018_A_fn_class = fncls__74d; tmp1 = fncls__74d } else { tmp1 = fncls__74 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp1, nil) } }
//line :26:1
func A_arbace_classes_annot_fn__851000017_fn__851000018_A_New() *A_arbace_classes_annot_fn__851000017_fn__851000018_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_fn__851000017_fn__851000018_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_classes_annot_fn__851000017_fn__851000018_A) Ctor() {}
//line :26:1
func (t *A_arbace_classes_annot_fn__851000017_fn__851000018_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_classes_annot_bin_A_New() *A_arbace_classes_annot_bin_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_bin_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_classes_annot_bin_A) Ctor() {}
//line :28:1
func (t *A_arbace_classes_annot_bin_A) Invoke_O_O__O(self, d__0 any) any { var root_76 any = A_arbace_classes_annot_A_const_24.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = d__0; var arg_80 any = Lit_23; var arg_81 any = Lit_24; if linked_77 == nil { return ifn_78.Invoke_O_O_O__O(arg_79, arg_80, arg_81) } else { return linked_77.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_76, arg_79, arg_80, arg_81) } }

func A_arbace_classes_annot_enc_string_A_New() *A_arbace_classes_annot_enc_string_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_enc_string_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_classes_annot_enc_string_A) Ctor() {}
//line :30:1
func (t *A_arbace_classes_annot_enc_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_116); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.String_Cast(s__0)).Length__I()); var i__4 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__4)); var ci__6 int32 = lang.RT_IntCast_C__I_NoInit(c__5)


		if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_classes_annot_A_const_25)).CharValue__C()) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_117) } else {
//line :37:1
				if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_classes_annot_A_const_26)).CharValue__C()) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_118) } else {
//line :37:1
						var tmp1 bool; var and__1927000168__auto____7 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(ci__6), 32)


						if and__1927000168__auto____7 { tmp1 = lang.Numbers_Lte_J_J__Z_NoInit(int64(ci__6), 126) } else { tmp1 = and__1927000168__auto____7 }
//line :37:1
						if tmp1 {


							jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(c__5) } else {
//line :37:1
								if A_arbace_classes_annot_A_const_27 != nil {



									var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_119, nil); var tmp4 any; var root_82 any = A_arbace_classes_annot_A_const_28.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = jrt.Integer_ToHexString_I__String_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(65536, int64(ci__6)))).Ref(); var arg_86 any = A_arbace_classes_annot_A_const_29; if linked_83 == nil { tmp4 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { tmp4 = linked_83.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; jrt.NN(tmp2).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4))) } } } }
//line :34:1
		i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :30:1
	break L1 };











	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_116); return /*line :43:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }



func A_arbace_classes_annot_enc_value_A_New() *A_arbace_classes_annot_enc_value_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_enc_value_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_annot_enc_value_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_annot_enc_value_A) Invoke_O_O__O(self, v__0 any) any {


	var tmp1 any; var root_87 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_89 lang.IFn
	if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = v__0; var arg_91 any = A_arbace_classes_annot_A_const_31; if linked_88 == nil { tmp1 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { tmp1 = linked_88.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }
//line :50:1
	if jrt.J2g_Truth(tmp1) { var xs__2 any = A_arbace_classes_annot_A_const_31.Invoke_O__O(v__0); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_17.GetRawRoot__O()); var tmp3 any = A_arbace_classes_annot_A_const_32.GetRawRoot__O(); var tmp4 any; var root_101 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_classes_annot_bin_A_fn_class); var ifn_103 lang.IFn


		if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(v__0); if linked_102 == nil { tmp4 = ifn_103.Invoke_O__O(arg_104) } else { tmp4 = linked_102.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_101, arg_104) }; var tmp5 any = tmp4; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__2)).Ref(); var tmp7 any; var root_105 any = A_arbace_classes_annot_A_const_35.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var fnbody__115 any = A_arbace_classes_annot_enc_value_fn__851000024_A_New(); var tmp8 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_classes_annot_enc_value_fn__851000024_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); A_arbace_classes_annot_enc_value_fn__851000024_A_fn_class = fncls__114d; tmp8 = fncls__114d } else { tmp8 = fncls__114 }; arg_108 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__115, tmp8, nil); var arg_109 any = xs__2; if linked_106 == nil { tmp7 = ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { tmp7 = linked_106.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) }; return tmp2.Invoke_O_O_O_O_O_O__O(tmp3, Lit_120, tmp5, Lit_9, tmp6, tmp7) } else {
//line :50:1
			var tmp9 any; var root_116 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_118 lang.IFn



			if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = v__0; var arg_120 any = A_arbace_classes_annot_A_const_37; if linked_117 == nil { tmp9 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp9 = linked_117.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_116, arg_119, arg_120) }
//line :50:1
			if jrt.J2g_Truth(tmp9) {



				var root_121 any = A_arbace_classes_annot_A_const_38.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_classes_annot_enc_annotation_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = A_arbace_classes_annot_A_const_37.Invoke_O__O(v__0); if linked_122 == nil { return ifn_123.Invoke_O__O(arg_124) } else { return linked_122.(*A_arbace_classes_annot_enc_annotation_A).Invoke_O_O__O(root_121, arg_124) } } else {
//line :50:1
					var tmp10 any; var root_125 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_127 lang.IFn




					if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = v__0; var arg_129 any = A_arbace_classes_annot_A_const_39; if linked_126 == nil { tmp10 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { tmp10 = linked_126.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }
//line :50:1
					if jrt.J2g_Truth(tmp10) {




						var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_122, nil); var tmp12 any; var root_130 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_classes_annot_bin_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = A_arbace_classes_annot_A_const_39.Invoke_O__O(v__0); if linked_131 == nil { tmp12 = ifn_132.Invoke_O__O(arg_133) } else { tmp12 = linked_131.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_130, arg_133) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)).Ref() } else {
//line :50:1
							var tmp13 any; var root_134 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_136 lang.IFn





							if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = v__0; var arg_138 any = A_arbace_classes_annot_A_const_40; if linked_135 == nil { tmp13 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { tmp13 = linked_135.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_134, arg_137, arg_138) }
//line :50:1
							if jrt.J2g_Truth(tmp13) {





								var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_123, nil, nil); var tmp15 any; var root_139 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, A_arbace_classes_annot_bin_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_classes_annot_A_const_40.Invoke_O__O(v__0); if linked_140 == nil { tmp15 = ifn_141.Invoke_O__O(arg_142) } else { tmp15 = linked_140.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_139, arg_142) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, A_arbace_classes_annot_A_const_41.Invoke_O__O(v__0))).Ref() } else {
//line :50:1
									var tmp16 any; var root_143 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_145 lang.IFn






									if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = v__0; var arg_147 any = A_arbace_classes_annot_A_const_42; if linked_144 == nil { tmp16 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { tmp16 = linked_144.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }
//line :50:1
									if jrt.J2g_Truth(tmp16) { var c__2 any = A_arbace_classes_annot_A_const_42.Invoke_O__O(v__0); var x__3 any = A_arbace_classes_annot_A_const_43.Invoke_O__O(c__2); var G__851000026__4_ any = A_arbace_classes_annot_A_const_44.Invoke_O__O(c__2)









										switch lang.Util_Hash_O__I_NoInit(G__851000026__4_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_103) {

											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__3)).Ref())).Ref() }
//line :60:1
										case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_104) {



											var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_104, nil); var tmp18 any; var tmp19 any; var root_149 any = A_arbace_classes_annot_A_const_45.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = x__3; if linked_150 == nil { tmp19 = ifn_151.Invoke_O__O(arg_152) } else { tmp19 = linked_150.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_149, arg_152) }; if jrt.J2g_Truth(tmp19) { tmp18 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(x__3)).Ref() } else { tmp18 = x__3 }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(tmp18)).Ref())).Ref() }
//line :60:1
										case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_105) {







											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__3))).Ref())).Ref() }
//line :60:1
										case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_106) {






											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_106, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Float_FloatToRawIntBits_F__I_NoInit(lang.RT_FloatCast_O__F_NoInit(x__3))).Ref())).Ref() }
//line :60:1
										case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_107) {




											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_107, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__3)).Ref())).Ref() }
//line :60:1
										case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_108) {





											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_108, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__3)).Ref())).Ref() }
//line :60:1
										case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_109) {


											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_109, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__3)).Ref())).Ref() }
//line :60:1
										case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__851000026__4_, Lit_110) {
											if jrt.J2g_Truth(x__3) { return Lit_124 } else { return Lit_125 } }
//line :60:1
										default:
										}







										var root_153 any = A_arbace_classes_annot_A_const_46.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_classes_annot_enc_string_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any; var root_157 any = A_arbace_classes_annot_A_const_32.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = x__3; if linked_158 == nil { arg_156 = ifn_159.Invoke_O__O(arg_160) } else { arg_156 = linked_158.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_157, arg_160) }; if linked_154 == nil { return ifn_155.Invoke_O__O(arg_156) } else { return linked_154.(*A_arbace_classes_annot_enc_string_A).Invoke_O_O__O(root_153, arg_156) } } else {
//line :50:1
											if A_arbace_classes_annot_A_const_27 != nil { var tmp20 any; var root_161 any = A_arbace_classes_annot_A_const_47.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_163 lang.IFn



















												if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_annot_A_const_48.GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var arg_165 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_annot_A_const_49, v__0)); if linked_162 == nil { tmp20 = ifn_163.Invoke_O_O__O(arg_164, arg_165) } else { tmp20 = linked_162.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_161, arg_164, arg_165) }
//line :50:1
												panic(jrt.Thrown(jrt.Throwable_Cast(tmp20))) } else { return nil
												}
										} } } } } }
func A_arbace_classes_annot_enc_value_fn__851000024_A_New() *A_arbace_classes_annot_enc_value_fn__851000024_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_enc_value_fn__851000024_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_classes_annot_enc_value_fn__851000024_A) Ctor() {}
//line :53:1
func (t *A_arbace_classes_annot_enc_value_fn__851000024_A) Invoke_O_O__O(self, p1__851000023_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp2 any; var root_110 any = A_arbace_classes_annot_A_const_36.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, A_arbace_classes_annot_enc_value_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = p1__851000023_SHARP___1; if linked_111 == nil { tmp2 = ifn_112.Invoke_O__O(arg_113) } else { tmp2 = linked_111.(*A_arbace_classes_annot_enc_value_A).Invoke_O_O__O(root_110, arg_113) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }


















func A_arbace_classes_annot_enc_annotation_A_New() *A_arbace_classes_annot_enc_annotation_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_enc_annotation_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_classes_annot_enc_annotation_A) Ctor() {}
//line :72:1
func (t *A_arbace_classes_annot_enc_annotation_A) Invoke_O_O__O(self, an__0 any) any { var vs__2 any = A_arbace_classes_annot_A_const_50.Invoke_O__O(an__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_classes_annot_A_const_32.GetRawRoot__O(); var tmp3 any; var root_179 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_classes_annot_bin_A_fn_class); var ifn_181 lang.IFn; if



	linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = A_arbace_classes_annot_A_const_44.Invoke_O__O(an__0); if linked_180 == nil { tmp3 = ifn_181.Invoke_O__O(arg_182) } else { tmp3 = linked_180.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_179, arg_182) }; var tmp4 any = tmp3; var tmp5 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(vs__2)).Ref(); var tmp6 any; var iter__1927001039__auto____3 any; var fnbody__252 any = A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A_New(); var tmp7 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A_fn_class; if
	fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A_fn_class = fncls__251d; tmp7 = fncls__251d } else { tmp7 = fncls__251 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp7, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(vs__2); return /*line :76:1*/ tmp1.Invoke_O_O_O_O_O_O__O(tmp2, Lit_112, tmp4, Lit_9, tmp5, tmp6) }
func A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A_New() *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A) Ctor() {}
//line :77:1
func (t *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A) Invoke_O_O__O(self, s__851000029__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__250 any = A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A_New_O_O(self, s__851000029__1); var tmp2 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, fnbody__250); A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A_fn_class = fncls__249d; tmp2 = fncls__249d } else { tmp2 = fncls__249 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__250, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :77:1
func A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A{}; t.Ctor_O_O(p0, p1); return t }
//line :77:1
func (t *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A) Ctor_O_O(c__iter__851000028, c__s__851000029 any) { t.F_iter__851000028 = c__iter__851000028; t.F_s__851000029 = c__s__851000029 }
//line :77:1
func (t *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A) Invoke_O__O(self any) any { { var s__851000029__1 any; var t_ any = t.F_s__851000029; t.F_s__851000029 = nil; s__851000029__1 = t_; for { var temp__1927000414__auto____2 any; var root_183 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = s__851000029__1; if linked_184 == nil { temp__1927000414__auto____2 = ifn_185.Invoke_O__O(arg_186) } else { temp__1927000414__auto____2 = linked_184.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_183, arg_186) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000029__3 any = temp__1927000414__auto____2; var tmp1 any; var root_187 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = s__851000029__3; if linked_188 == nil { tmp1 = ifn_189.Invoke_O__O(arg_190) } else { tmp1 = linked_188.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_187, arg_190) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_191 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = s__851000029__3; if linked_192 == nil { c__1927001037__auto____4 = ifn_193.Invoke_O__O(arg_194) } else { c__1927001037__auto____4 = linked_192.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_191, arg_194) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000031__6 any; var root_195 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_196 == nil { b__851000031__6 = ifn_197.Invoke_O__O(arg_198) } else { b__851000031__6 = linked_196.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_195, arg_198) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__209 any = A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A_New_O_I_O(b__851000031__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__208 *jrt.Class = A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A_fn_class; if fncls__208 == nil { var fncls__208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, fnbody__209); A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A_fn_class = fncls__208d; tmp3 = fncls__208d } else { tmp3 = fncls__208 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__209, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_210 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any; var root_215 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = b__851000031__6; if linked_216 == nil { arg_213 = ifn_217.Invoke_O__O(arg_218) } else { arg_213 = linked_216.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_215, arg_218) }; var arg_214 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000028); var tmp5 any; var root_219 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = s__851000029__3; if linked_220 == nil { tmp5 = ifn_221.Invoke_O__O(arg_222) } else { tmp5 = linked_220.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_219, arg_222) }; arg_214 = tmp4.Invoke_O__O(tmp5); if linked_211 == nil { return ifn_212.Invoke_O_O__O(arg_213, arg_214) } else { return linked_211.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_210, arg_213, arg_214) } } else { var root_223 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any; var root_228 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = b__851000031__6; if linked_229 == nil { arg_226 = ifn_230.Invoke_O__O(arg_231) } else { arg_226 = linked_229.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_228, arg_231) }; var arg_227 any; if linked_224 == nil { return ifn_225.Invoke_O_O__O(arg_226, arg_227) } else { return linked_224.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_223, arg_226, arg_227) } } } else { var vec__851000039__4 any; var root_232 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = s__851000029__3; if linked_233 == nil { vec__851000039__4 = ifn_234.Invoke_O__O(arg_235) } else { vec__851000039__4 = linked_233.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_232, arg_235) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000039__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000039__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_236 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_9, nil); var tmp7 any; var root_241 any = A_arbace_classes_annot_A_const_36.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_classes_annot_enc_value_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = v__6; if linked_242 == nil { tmp7 = ifn_243.Invoke_O__O(arg_244) } else { tmp7 = linked_242.(*A_arbace_classes_annot_enc_value_A).Invoke_O_O__O(root_241, arg_244) }; arg_239 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, tmp7)).Ref(); var arg_240 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__851000028); var tmp9 any; var root_245 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = s__851000029__3; if linked_246 == nil { tmp9 = ifn_247.Invoke_O__O(arg_248) } else { tmp9 = linked_246.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_245, arg_248) }; arg_240 = tmp8.Invoke_O__O(tmp9); if linked_237 == nil { return ifn_238.Invoke_O_O__O(arg_239, arg_240) } else { return linked_237.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_236, arg_239, arg_240) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :77:1
func A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :77:1
func (t *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A) Ctor_O_I_O(c__b__851000031 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000031 = c__b__851000031; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :77:1
func (t *A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A) Invoke_O__O(self any) any { { var i__851000030__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000030__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__851000035__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000030__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000035__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000035__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_199 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = t.F_b__851000031; var arg_203 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_9, nil); var tmp3 any; var root_204 any = A_arbace_classes_annot_A_const_36.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_classes_annot_enc_value_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = v__4; if linked_205 == nil { tmp3 = ifn_206.Invoke_O__O(arg_207) } else { tmp3 = linked_205.(*A_arbace_classes_annot_enc_value_A).Invoke_O_O__O(root_204, arg_207) }; arg_203 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, tmp3)).Ref(); if linked_200 == nil { ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { linked_200.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; i__851000030__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000030__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_annot_visible_A_New() *A_arbace_classes_annot_visible_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_visible_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_classes_annot_visible_A) Ctor() {}
//line :79:1
func (t *A_arbace_classes_annot_visible_A) Invoke_O_O__O(self, anns__0 any) any {





	var root_253 any = A_arbace_classes_annot_A_const_61.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var fnbody__263 any = A_arbace_classes_annot_visible_fn__851000046_A_New(); var tmp1 *jrt.Class; var fncls__262 *jrt.Class = A_arbace_classes_annot_visible_fn__851000046_A_fn_class; if fncls__262 == nil { var fncls__262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, nil); A_arbace_classes_annot_visible_fn__851000046_A_fn_class = fncls__262d; tmp1 = fncls__262d } else { tmp1 = fncls__262 }; arg_256 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__263, tmp1, nil); var arg_257 any; var root_264 any = A_arbace_classes_annot_A_const_63.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_266 lang.IFn
	if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; if jrt.J2g_Truth(A_arbace_classes_annot_A_const_64.GetRawRoot__O()) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_65.GetRawRoot__O()); var tmp3 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_annot_A_const_64.GetRawRoot__O(), jrt.Boolean_TRUE.Ref())); var tmp4 *lang.Compiler_AOTFn; var fnbody__278 any = A_arbace_classes_annot_visible_fn__851000048_A_New_O(anns__0); var tmp5 *jrt.Class; var fncls__277 *jrt.Class = A_arbace_classes_annot_visible_fn__851000048_A_fn_class; if fncls__277 == nil { var fncls__277d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, fnbody__278); A_arbace_classes_annot_visible_fn__851000048_A_fn_class = fncls__277d; tmp5 = fncls__277d } else { tmp5 = fncls__277 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__278, tmp5, nil); arg_267 = tmp2.Invoke_O_O__O(tmp3, tmp4.Ref()) } else {
		var tmp6 *lang.Compiler_AOTFn; var fnbody__284 any = A_arbace_classes_annot_visible_fn__851000050_A_New_O(anns__0); var tmp7 *jrt.Class; var fncls__283 *jrt.Class = A_arbace_classes_annot_visible_fn__851000050_A_fn_class; if fncls__283 == nil { var fncls__283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, fnbody__284); A_arbace_classes_annot_visible_fn__851000050_A_fn_class = fncls__283d; tmp7 = fncls__283d } else { tmp7 = fncls__283 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__284, tmp7, nil); arg_267 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O() }
//line :86:1
	if linked_265 == nil { arg_257 = ifn_266.Invoke_O__O(arg_267) } else { arg_257 = linked_265.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_264, arg_267) }
//line :85:1
	if linked_254 == nil { return ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { return linked_254.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) } }
//line :85:1
func A_arbace_classes_annot_visible_fn__851000046_A_New() *A_arbace_classes_annot_visible_fn__851000046_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_visible_fn__851000046_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_classes_annot_visible_fn__851000046_A) Ctor() {}
//line :85:1
func (t *A_arbace_classes_annot_visible_fn__851000046_A) Invoke_O_O__O(self, p1__851000045_SHARP___1 any) any { if jrt.J2g_Truth(A_arbace_classes_annot_A_const_62.Invoke_O__O(p1__851000045_SHARP___1)) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_258 any = A_arbace_classes_annot_A_const_38.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_classes_annot_enc_annotation_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = p1__851000045_SHARP___1; if linked_259 == nil { tmp1 = ifn_260.Invoke_O__O(arg_261) } else { tmp1 = linked_259.(*A_arbace_classes_annot_enc_annotation_A).Invoke_O_O__O(root_258, arg_261) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___4 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___4; tmp1 = nil } else { panic(tmp2) } }; return tmp1 } else { return nil } }
func A_arbace_classes_annot_visible_fn__851000048_A_New_O(p0 any) *A_arbace_classes_annot_visible_fn__851000048_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_visible_fn__851000048_A{}; t.Ctor_O(p0); return t }
//line :86:1
func (t *A_arbace_classes_annot_visible_fn__851000048_A) Ctor_O(c__anns any) { t.F_anns = c__anns }
//line :86:1
func (t *A_arbace_classes_annot_visible_fn__851000048_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_273 any = A_arbace_classes_annot_A_const_66.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t.F_anns; if linked_274 == nil { tmp1 = ifn_275.Invoke_O__O(arg_276) } else { tmp1 = linked_274.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_273, arg_276) } }
//line :86:1
	return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
func A_arbace_classes_annot_visible_fn__851000050_A_New_O(p0 any) *A_arbace_classes_annot_visible_fn__851000050_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_visible_fn__851000050_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_classes_annot_visible_fn__851000050_A) Ctor_O(c__anns any) { t.F_anns = c__anns }
//line :87:1
func (t *A_arbace_classes_annot_visible_fn__851000050_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_279 any = A_arbace_classes_annot_A_const_66.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any; var t_ any = t.F_anns; t.F_anns = nil; arg_282 = t_; if linked_280 == nil { tmp1 = ifn_281.Invoke_O__O(arg_282) } else { tmp1 = linked_280.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_279, arg_282) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }

func A_arbace_classes_annot_safe_ctor_desc_A_New() *A_arbace_classes_annot_safe_ctor_desc_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_safe_ctor_desc_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_classes_annot_safe_ctor_desc_A) Ctor() {}
//line :89:1
func (t *A_arbace_classes_annot_safe_ctor_desc_A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




	{ var root_285 any = A_arbace_classes_annot_A_const_67.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = n__0; var arg_289 any = mm__1; if linked_286 == nil { tmp1 = ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { tmp1 = linked_286.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_285, arg_288, arg_289) } }
//line :89:1
	return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___5 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___5




		tmp1 = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__1) } else {
//line :89:1
			panic(tmp2) } }; return tmp1 }






func A_arbace_classes_annot_ctor_lead_A_New() *A_arbace_classes_annot_ctor_lead_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_ctor_lead_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_classes_annot_ctor_lead_A) Ctor() {}
//line :96:1
func (t *A_arbace_classes_annot_ctor_lead_A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { var d__3 any; var root_290 any = A_arbace_classes_annot_A_const_68.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_292 lang.IFn; if





	linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = n__0; if linked_291 == nil { d__3 = ifn_292.Invoke_O__O(arg_293) } else { d__3 = linked_291.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_290, arg_293) }; var cnt__4 any; var fnbody__303 any = /*line :96:1*/A_arbace_classes_annot_ctor_lead_cnt__851000055_A_New(); var tmp1 *jrt.Class; var fncls__302 *jrt.Class = A_arbace_classes_annot_ctor_lead_cnt__851000055_A_fn_class; if





	fncls__302 == nil { var fncls__302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_classes_annot_ctor_lead_cnt__851000055_A_fn_class = fncls__302d; tmp1 = fncls__302d } else { tmp1 = fncls__302 }; cnt__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__303, tmp1, nil); var caps__5 any; var tmp2 lang.IFn = /*line :96:1*/lang.IFn_Cast(A_arbace_classes_annot_A_const_70); if







	jrt.J2g_Truth(tmp2.Invoke_O__O(A_arbace_classes_annot_A_const_74.Invoke_O__O(d__3))) { var tmp3 *lang.Keyword = A_arbace_classes_annot_A_const_71; var tmp4 any; var root_304 any = A_arbace_classes_annot_A_const_7.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_classes_annot_A_const_72.Invoke_O__O(d__3); if linked_305 == nil { tmp4 = ifn_306.Invoke_O__O(arg_307) } else { tmp4 = linked_305.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_304, arg_307) }; caps__5 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp3.Invoke_O__O(tmp4))).Ref() } else { caps__5 = A_arbace_classes_annot_A_const_73 }; var tmp5 jrt.Number_I; var na_308 any; var na_310 any; var tmp6 lang.IFn =
	lang.IFn_Cast(cnt__4); var tmp7 any; var root_318 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = n__0; var arg_322 any = mm__1; if linked_319 == nil { tmp7 = ifn_320.Invoke_O_O__O(arg_321, arg_322) } else { tmp7 = linked_319.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_318, arg_321, arg_322) }; na_310 = tmp6.Invoke_O__O(tmp7); var na_311 any = lang.IFn_Cast(cnt__4).Invoke_O__O(A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__1)); var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_310); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_311) }; tmp8 = tmp9; if tmp8 { var n0_312 int64 = jrt.NN(jrt.Long_Cast(na_310)).LongValue__J(); var n1_313 int64 = jrt.NN(jrt.Long_Cast(na_311)).LongValue__J(); var nr_314 int64 = n0_312 - n1_313; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_313 == -9223372036854775808); if tmp11 { tmp11 = (n0_312^n1_313)&(n0_312^nr_314) >= 0 }; tmp10 = tmp11; if tmp10 { na_308 = jrt.Long_ValueOf_J__Long_NoInit(nr_314).Ref() } else { na_308 = lang.Numbers_Minus_O_O__Number_NoInit(na_310, na_311) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_310); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_311) }; tmp12 = tmp13; if tmp12 { var n0_312_2 float64 = jrt.NN(jrt.Double_Cast(na_310)).DoubleValue__D(); var n1_313_2 float64 = jrt.NN(jrt.Double_Cast(na_311)).DoubleValue__D(); na_308 = jrt.Double_ValueOf_D__Double_NoInit(n0_312_2 + -n1_313_2).Ref() } else { na_308 = lang.Numbers_Minus_O_O__Number_NoInit(na_310, na_311) } }; var na_309 any = caps__5; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_308); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_309) }; tmp14 = tmp15; if tmp14 { var n0_315 int64 = jrt.NN(jrt.Long_Cast(na_308)).LongValue__J(); var n1_316 int64 = jrt.NN(jrt.Long_Cast(na_309)).LongValue__J(); var nr_317 int64 = n0_315 - n1_316; var tmp16 bool; var tmp17 bool; tmp17 = !(n1_316 == -9223372036854775808); if tmp17 { tmp17 = (n0_315^n1_316)&(n0_315^nr_317) >= 0 }; tmp16 = tmp17; if tmp16 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_317)) } else { tmp5 = lang.Numbers_Minus_O_O__Number_NoInit(na_308, na_309) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_308); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_309) }; tmp18 = tmp19; if tmp18 { var n0_315_2 float64 = jrt.NN(jrt.Double_Cast(na_308)).DoubleValue__D(); var n1_316_2 float64 = jrt.NN(jrt.Double_Cast(na_309)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_315_2 + -n1_316_2)) } else { tmp5 = lang.Numbers_Minus_O_O__Number_NoInit(na_308, na_309) } }; return lang.Numbers_Max_J_O__O_NoInit(0, tmp5) }
//line :102:1
func A_arbace_classes_annot_ctor_lead_cnt__851000055_A_New() *A_arbace_classes_annot_ctor_lead_cnt__851000055_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_ctor_lead_cnt__851000055_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_classes_annot_ctor_lead_cnt__851000055_A) Ctor() {}
//line :102:1
func (t *A_arbace_classes_annot_ctor_lead_cnt__851000055_A) Invoke_O_O__O(self, p1__851000054_SHARP___1 any) any {
	var tmp1 any; var root_294 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any; var root_298 any = A_arbace_classes_annot_A_const_69.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = p1__851000054_SHARP___1; if linked_299 == nil { arg_297 = ifn_300.Invoke_O__O(arg_301) } else { arg_297 = linked_299.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_298, arg_301) }; if linked_295 == nil { tmp1 = ifn_296.Invoke_O__O(arg_297) } else { tmp1 = linked_295.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_294, arg_297) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref()
}


func A_arbace_classes_annot_reflected_member_QMARK__A_New() *A_arbace_classes_annot_reflected_member_QMARK__A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_reflected_member_QMARK__A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_classes_annot_reflected_member_QMARK__A) Ctor() {}
//line :107:1
func (t *A_arbace_classes_annot_reflected_member_QMARK__A) Invoke_O_O__O(self, mm__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_76); var or__1927000174__auto____2 any = tmp1.Invoke_O__O(A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__0)); if




	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp2 any = A_arbace_classes_annot_A_const_77; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_annot_A_const_78.Invoke_O__O(mm__0))).Ref() } }



func A_arbace_classes_annot_attribute_lines_A_New() *A_arbace_classes_annot_attribute_lines_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_classes_annot_attribute_lines_A) Ctor() {}
//line :116:1
func (t *A_arbace_classes_annot_attribute_lines_A) Invoke_O_O_O_O__O(self, n__0, d__1, members__2 any) any {






	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp2 lang.IPersistentVector; var temp__1927000414__auto____4 any = A_arbace_classes_annot_A_const_80.Invoke_O__O(d__1)
	if jrt.J2g_Truth(temp__1927000414__auto____4) { var s__5 any = temp__1927000414__auto____4; tmp2 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__5)).Ref()) } else { tmp2 = nil }
//line :123:1
	var tmp3 any = tmp2; var tmp4 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_81)

	if jrt.J2g_Truth(tmp5.Invoke_O__O(A_arbace_classes_annot_A_const_74.Invoke_O__O(d__1))) {
		var root_330 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any; var tmp6 *jrt.RefArray = jrt.ConstRefArray("[0,8,s2:K ns1: ns1: ns1: n", []*jrt.Class{jrt.String_class}); var tmp7 any; var or__1927000174__auto____12 any = A_arbace_classes_annot_A_const_82.Invoke_O__O(d__1)
		if jrt.J2g_Truth(or__1927000174__auto____12) { tmp7 = or__1927000174__auto____12 } else { tmp7 = A_arbace_classes_annot_A_const_73 }
//line :126:1
		var tmp8 any = tmp7; var tmp9 *jrt.String; var G__851000059__12_ any = A_arbace_classes_annot_A_const_74.Invoke_O__O(d__1)
	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__851000059__12_) >> 2 & 3 { case 0: if any(G__851000059__12_) == any(A_arbace_classes_annot_A_const_83) { tmp9 = Lit_2; break L1 }; case 2: if any(G__851000059__12_) == any(A_arbace_classes_annot_A_const_84) { tmp9 = Lit_3; break L1 }; case 3: if any(G__851000059__12_) == any(A_arbace_classes_annot_A_const_85) { tmp9 = Lit_4; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__851000059__12_)))))}
//line :126:1
		var tmp10 any = tmp9.Ref(); var tmp11 any; var root_336 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, A_arbace_classes_annot_bin_A_fn_class); var ifn_338 lang.IFn

		if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any; var or__1927000174__auto____12_2 any = A_arbace_classes_annot_A_const_86.Invoke_O__O(d__1); if jrt.J2g_Truth(or__1927000174__auto____12_2) { arg_339 = or__1927000174__auto____12_2 } else { arg_339 = Lit_6 }; if linked_337 == nil { tmp11 = ifn_338.Invoke_O__O(arg_339) } else { tmp11 = linked_337.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_336, arg_339) }
//line :126:1
		var tmp12 any = tmp11; var tmp13 any
		var tmp14 any = A_arbace_classes_annot_A_const_84
		if lang.Util_Equiv_O_O__Z_NoInit(tmp14, A_arbace_classes_annot_A_const_74.Invoke_O__O(d__1)) { tmp13 = Lit_6 } else { var or__1927000174__auto____12_3 any = A_arbace_classes_annot_A_const_87.Invoke_O__O(d__1); if jrt.J2g_Truth(or__1927000174__auto____12_3) { tmp13 = or__1927000174__auto____12_3 } else { tmp13 = Lit_6 } }
//line :126:1
		arg_333 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp10, nil, tmp12, nil, tmp13)).Ref()); var arg_334 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_88)


		if jrt.J2g_Truth(tmp15.Invoke_O__O(A_arbace_classes_annot_A_const_74.Invoke_O__O(d__1))) { var temp__1927000414__auto____4_2 any = A_arbace_classes_annot_A_const_89.Invoke_O__O(d__1)
			if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var em__5 any = temp__1927000414__auto____4_2; var temp__1927000414__auto____6 any = A_arbace_classes_annot_A_const_90.Invoke_O__O(em__5)
				if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_91)
					if jrt.J2g_Truth(tmp16.Invoke_O__O(A_arbace_classes_annot_A_const_41.Invoke_O__O(em__5))) { arg_334 = nil } else { var ctor__8 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_7, A_arbace_classes_annot_A_const_41.Invoke_O__O(em__5)); var desc__9 any

						if ctor__8 { var root_340 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any; var or__1927000174__auto____9 any = A_arbace_classes_annot_A_const_92.Invoke_O__O(m__7); if jrt.J2g_Truth(or__1927000174__auto____9) { arg_343 = or__1927000174__auto____9 } else { arg_343 = A_arbace_classes_annot_A_const_86.Invoke_O__O(d__1) }; var arg_344 any = m__7; if linked_341 == nil { desc__9 = ifn_342.Invoke_O_O__O(arg_343, arg_344) } else { desc__9 = linked_341.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_340, arg_343, arg_344) } } else { desc__9 = A_arbace_classes_annot_A_const_34.Invoke_O__O(m__7) }
						if jrt.J2g_Truth(desc__9) { var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_8, nil, Lit_9, nil); var tmp18 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(em__5); var tmp19 any; var root_345 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, A_arbace_classes_annot_bin_A_fn_class); var ifn_347 lang.IFn
							if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = desc__9; if linked_346 == nil { tmp19 = ifn_347.Invoke_O__O(arg_348) } else { tmp19 = linked_346.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_345, arg_348) }
//line :135:1
							arg_334 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18, nil, tmp19)).Ref()) } else { arg_334 = nil } } } else {
//line :131:1
								arg_334 = nil } } else {
//line :130:1
									arg_334 = nil } } else {
//line :129:1
										arg_334 = nil }
//line :126:1
		if linked_331 == nil { tmp4 = ifn_332.Invoke_O_O__O(arg_333, arg_334) } else { tmp4 = linked_331.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_330, arg_333, arg_334) } } else {
//line :125:1
			tmp4 = nil }
//line :123:1
	var tmp20 any = tmp4; var tmp21 any
	var tmp22 any = A_arbace_classes_annot_A_const_93















	if lang.Util_Equiv_O_O__Z_NoInit(tmp22, A_arbace_classes_annot_A_const_79.Invoke_O__O(d__1)) { var iter__1927001039__auto____4 any; var fnbody__418 any = A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A_New(); var tmp23 *jrt.Class; var fncls__417 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A_fn_class
		if fncls__417 == nil { var fncls__417d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A_fn_class = fncls__417d; tmp23 = fncls__417d } else { tmp23 = fncls__417 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__418, tmp23, nil); tmp21 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_classes_annot_A_const_95.Invoke_O__O(d__1)) } else {
//line :140:1
			tmp21 = nil }
//line :123:1
	var tmp24 any = tmp21; var tmp25 any



















	if jrt.J2g_Truth(members__2) {
		var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp27 any; var iter__1927001039__auto____4_2 any; var fnbody__528 any = A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A_New_O(n__0); var tmp28 *jrt.Class; var fncls__527 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A_fn_class
		if fncls__527 == nil { var fncls__527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__528); A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A_fn_class = fncls__527d; tmp28 = fncls__527d } else { tmp28 = fncls__527 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__528, tmp28, nil); tmp27 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(d__1))
//line :144:1
		var tmp29 any = tmp27; var tmp30 any; var iter__1927001039__auto____4_3 any; var fnbody__594 any = A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A_New(); var tmp31 *jrt.Class
		var fncls__593 /*line :144:1*/*jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A_fn_class







		if fncls__593 == nil { var fncls__593d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A_fn_class = fncls__593d; tmp31 = fncls__593d } else { tmp31 = fncls__593 }; iter__1927001039__auto____4_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__594, tmp31, nil); tmp30 = lang.IFn_Cast(iter__1927001039__auto____4_3).Invoke_O__O(A_arbace_classes_annot_A_const_99.Invoke_O__O(d__1))
//line :144:1
		var tmp32 any = tmp30; var tmp33 any; var root_595 any = A_arbace_classes_annot_A_const_100.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, A_arbace_classes_annot_throws_lines_A_fn_class); var ifn_597 lang.IFn











		if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = n__0; var arg_599 any = d__1; if linked_596 == nil { tmp33 = ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { tmp33 = linked_596.(*A_arbace_classes_annot_throws_lines_A).Invoke_O_O_O__O(root_595, arg_598, arg_599) }
//line :144:1
		tmp25 = tmp26.Invoke_O_O_O__O(tmp29, tmp32, tmp33) } else {
//line :143:1
			tmp25 = nil }
//line :123:1
	return tmp1.Invoke_O_O_O_O__O(tmp3, tmp20, tmp24, tmp25)
}
















func A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A_New() *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A) Ctor() {}
//line :141:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A) Invoke_O_O__O(self, s__851000061__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__416 any = A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A_New_O_O(self, s__851000061__1); var tmp2 *jrt.Class; var fncls__415 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A_fn_class; if fncls__415 == nil { var fncls__415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__416); A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A_fn_class = fncls__415d; tmp2 = fncls__415d } else { tmp2 = fncls__415 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__416, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :141:1
func A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A{}; t.Ctor_O_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A) Ctor_O_O(c__iter__851000060, c__s__851000061 any) { t.F_iter__851000060 = c__iter__851000060; t.F_s__851000061 = c__s__851000061 }
//line :141:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A) Invoke_O__O(self any) any { { var s__851000061__1 any; var t_ any = t.F_s__851000061; t.F_s__851000061 = nil; s__851000061__1 = t_; for { var temp__1927000414__auto____2 any; var root_349 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = s__851000061__1; if linked_350 == nil { temp__1927000414__auto____2 = ifn_351.Invoke_O__O(arg_352) } else { temp__1927000414__auto____2 = linked_350.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_349, arg_352) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000061__3 any = temp__1927000414__auto____2; var tmp1 any; var root_353 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = s__851000061__3; if linked_354 == nil { tmp1 = ifn_355.Invoke_O__O(arg_356) } else { tmp1 = linked_354.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_353, arg_356) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_357 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = s__851000061__3; if linked_358 == nil { c__1927001037__auto____4 = ifn_359.Invoke_O__O(arg_360) } else { c__1927001037__auto____4 = linked_358.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_357, arg_360) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000063__6 any; var root_361 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_362 == nil { b__851000063__6 = ifn_363.Invoke_O__O(arg_364) } else { b__851000063__6 = linked_362.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_361, arg_364) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__375 any = A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A_New_O_I_O(b__851000063__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__374 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A_fn_class; if fncls__374 == nil { var fncls__374d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__375); A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A_fn_class = fncls__374d; tmp3 = fncls__374d } else { tmp3 = fncls__374 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__375, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_376 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any; var root_381 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = b__851000063__6; if linked_382 == nil { arg_379 = ifn_383.Invoke_O__O(arg_384) } else { arg_379 = linked_382.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_381, arg_384) }; var arg_380 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000060); var tmp5 any; var root_385 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = s__851000061__3; if linked_386 == nil { tmp5 = ifn_387.Invoke_O__O(arg_388) } else { tmp5 = linked_386.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_385, arg_388) }; arg_380 = tmp4.Invoke_O__O(tmp5); if linked_377 == nil { return ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { return linked_377.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) } } else { var root_389 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var root_394 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = b__851000063__6; if linked_395 == nil { arg_392 = ifn_396.Invoke_O__O(arg_397) } else { arg_392 = linked_395.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_394, arg_397) }; var arg_393 any; if linked_390 == nil { return ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { return linked_390.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) } } } else { var c__4 any; var root_398 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = s__851000061__3; if linked_399 == nil { c__4 = ifn_400.Invoke_O__O(arg_401) } else { c__4 = linked_399.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_398, arg_401) }; var root_402 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9, nil, nil); var tmp7 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(c__4); var tmp8 any; var root_407 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_classes_annot_bin_A_fn_class); var ifn_409 lang.IFn
															if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(c__4); if linked_408 == nil { tmp8 = ifn_409.Invoke_O__O(arg_410) } else { tmp8 = linked_408.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_407, arg_410) }; var tmp9 any = tmp8; var tmp10 *jrt.String; var temp__1927000414__auto____10 any = A_arbace_classes_annot_A_const_94.Invoke_O__O(c__4); if jrt.J2g_Truth(temp__1927000414__auto____10) { var s__11 any = temp__1927000414__auto____10; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__11)) } else { tmp10 = nil }; arg_405 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp9, tmp10.Ref())).Ref()
//line :141:1
	var arg_406 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__851000060); var tmp12 any; var root_411 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = s__851000061__3; if linked_412 == nil { tmp12 = ifn_413.Invoke_O__O(arg_414) } else { tmp12 = linked_412.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_411, arg_414) }; arg_406 = tmp11.Invoke_O__O(tmp12); if linked_403 == nil { return ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { return linked_403.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :141:1
func A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :141:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A) Ctor_O_I_O(c__b__851000063 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000063 = c__b__851000063; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :141:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A) Invoke_O__O(self any) any { { var i__851000062__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000062__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000062__1)); var root_365 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = t.F_b__851000063; var arg_369 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9, nil, nil); var tmp3 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(c__2); var tmp4 any; var root_370 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_classes_annot_bin_A_fn_class); var ifn_372 lang.IFn
																	if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(c__2); if linked_371 == nil { tmp4 = ifn_372.Invoke_O__O(arg_373) } else { tmp4 = linked_371.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_370, arg_373) }; var tmp5 any = tmp4; var tmp6 *jrt.String; var temp__1927000414__auto____8 any = A_arbace_classes_annot_A_const_94.Invoke_O__O(c__2); if jrt.J2g_Truth(temp__1927000414__auto____8) { var s__9 any = temp__1927000414__auto____8; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__9)) } else { tmp6 = nil }; arg_369 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, tmp5, tmp6.Ref())).Ref()
//line :141:1
	if linked_366 == nil { ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { linked_366.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) }; i__851000062__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000062__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A_New_O(p0 any) *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :145:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A) Invoke_O_O__O(self, s__851000071__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__526 any = A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A_New_O_O_O(t.F_n, self, s__851000071__1); var tmp2 *jrt.Class; var fncls__525 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A_fn_class; if fncls__525 == nil { var fncls__525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__526); A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A_fn_class = fncls__525d; tmp2 = fncls__525d } else { tmp2 = fncls__525 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__526, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :145:1
func A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :145:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A) Ctor_O_O_O(c__n, c__iter__851000070, c__s__851000071 any) { t.F_n = c__n; t.F_iter__851000070 = c__iter__851000070; t.F_s__851000071 = c__s__851000071 }
//line :145:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A) Invoke_O__O(self any) any { { var s__851000071__1 any; var t_ any = t.F_s__851000071; t.F_s__851000071 = nil; s__851000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_425 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = s__851000071__1; if linked_426 == nil { temp__1927000414__auto____2 = ifn_427.Invoke_O__O(arg_428) } else { temp__1927000414__auto____2 = linked_426.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_425, arg_428) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_429 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = s__851000071__3; if linked_430 == nil { tmp1 = ifn_431.Invoke_O__O(arg_432) } else { tmp1 = linked_430.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_429, arg_432) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_433 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = s__851000071__3; if linked_434 == nil { c__1927001037__auto____4 = ifn_435.Invoke_O__O(arg_436) } else { c__1927001037__auto____4 = linked_434.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_433, arg_436) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000073__6 any; var root_437 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_438 == nil { b__851000073__6 = ifn_439.Invoke_O__O(arg_440) } else { b__851000073__6 = linked_438.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_437, arg_440) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__464 any = A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A_New_O_O_I_O(b__851000073__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__464); A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A_fn_class = fncls__463d; tmp3 = fncls__463d } else { tmp3 = fncls__463 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__464, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_465 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any; var root_470 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = b__851000073__6; if linked_471 == nil { arg_468 = ifn_472.Invoke_O__O(arg_473) } else { arg_468 = linked_471.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_470, arg_473) }; var arg_469 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000070); var tmp5 any; var root_474 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = s__851000071__3; if linked_475 == nil { tmp5 = ifn_476.Invoke_O__O(arg_477) } else { tmp5 = linked_475.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_474, arg_477) }; arg_469 = tmp4.Invoke_O__O(tmp5); if linked_466 == nil { return ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { return linked_466.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) } } else { var root_478 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any; var root_483 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = b__851000073__6; if linked_484 == nil { arg_481 = ifn_485.Invoke_O__O(arg_486) } else { arg_481 = linked_484.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_483, arg_486) }; var arg_482 any; if linked_479 == nil { return ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { return linked_479.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_478, arg_481, arg_482) } } } else { var mm__4 any; var root_487 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = s__851000071__3; if linked_488 == nil { mm__4 = ifn_489.Invoke_O__O(arg_490) } else { mm__4 = linked_488.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_487, arg_490) }; var tmp6 any; var root_491 any = A_arbace_classes_annot_A_const_96.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, A_arbace_classes_annot_reflected_member_QMARK__A_fn_class); var ifn_493 lang.IFn
															if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = mm__4; if linked_492 == nil { tmp6 = ifn_493.Invoke_O__O(arg_494) } else { tmp6 = linked_492.(*A_arbace_classes_annot_reflected_member_QMARK__A).Invoke_O_O__O(root_491, arg_494) }
//line :145:1
	if jrt.J2g_Truth(tmp6) { var sig__5 any = A_arbace_classes_annot_A_const_94.Invoke_O__O(mm__4); if jrt.J2g_Truth(sig__5) { var root_495 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any
		var tmp7 any = A_arbace_classes_annot_A_const_97


		if lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4)) {
			var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_9, nil); var tmp9 any; var root_500 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_classes_annot_bin_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any; var root_504 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = t.F_n; var arg_508 any = mm__4; if linked_505 == nil { arg_503 = ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { arg_503 = linked_505.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; if linked_501 == nil { tmp9 = ifn_502.Invoke_O__O(arg_503) } else { tmp9 = linked_501.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_500, arg_503) }; arg_498 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, sig__5)).Ref() } else {
				var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_9, nil, Lit_9, nil); var tmp11 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__4); var tmp12 any; var root_509 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, A_arbace_classes_annot_bin_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__4); if linked_510 == nil { tmp12 = ifn_511.Invoke_O__O(arg_512) } else { tmp12 = linked_510.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_509, arg_512) }; arg_498 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, tmp12, nil, sig__5)).Ref() }
//line :145:1
		var arg_499 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__851000070); var tmp14 any; var root_513 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = s__851000071__3; if linked_514 == nil { tmp14 = ifn_515.Invoke_O__O(arg_516) } else { tmp14 = linked_514.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_513, arg_516) }; arg_499 = tmp13.Invoke_O__O(tmp14); if linked_496 == nil { return ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { return linked_496.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) } } else { var tmp15 any; var root_517 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = s__851000071__3; if linked_518 == nil { tmp15 = ifn_519.Invoke_O__O(arg_520) } else { tmp15 = linked_518.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_517, arg_520) }; s__851000071__1 = tmp15; continue L1 } } else { var tmp16 any; var root_521 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = s__851000071__3; if linked_522 == nil { tmp16 = ifn_523.Invoke_O__O(arg_524) } else { tmp16 = linked_522.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_521, arg_524) }; s__851000071__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :145:1
func A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :145:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A) Ctor_O_O_I_O(c__b__851000073, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000073 = c__b__851000073; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :145:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A) Invoke_O__O(self any) any { { var i__851000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000072__1)); var tmp2 any; var root_441 any = A_arbace_classes_annot_A_const_96.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_classes_annot_reflected_member_QMARK__A_fn_class); var ifn_443 lang.IFn
																	if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = mm__2; if linked_442 == nil { tmp2 = ifn_443.Invoke_O__O(arg_444) } else { tmp2 = linked_442.(*A_arbace_classes_annot_reflected_member_QMARK__A).Invoke_O_O__O(root_441, arg_444) }
//line :145:1
	if jrt.J2g_Truth(tmp2) { var sig__3 any = A_arbace_classes_annot_A_const_94.Invoke_O__O(mm__2); if jrt.J2g_Truth(sig__3) { var root_445 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = t.F_b__851000073; var arg_449 any
		var tmp3 any = A_arbace_classes_annot_A_const_97


		if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__2)) {
			var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_9, nil); var tmp5 any; var root_450 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_classes_annot_bin_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var root_454 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = t.F_n; var arg_458 any = mm__2; if linked_455 == nil { arg_453 = ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { arg_453 = linked_455.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_454, arg_457, arg_458) }; if linked_451 == nil { tmp5 = ifn_452.Invoke_O__O(arg_453) } else { tmp5 = linked_451.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_450, arg_453) }; arg_449 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, sig__3)).Ref() } else {
				var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_9, nil, Lit_9, nil); var tmp7 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__2); var tmp8 any; var root_459 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, A_arbace_classes_annot_bin_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__2); if linked_460 == nil { tmp8 = ifn_461.Invoke_O__O(arg_462) } else { tmp8 = linked_460.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_459, arg_462) }; arg_449 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp8, nil, sig__3)).Ref() }
//line :145:1
		if linked_446 == nil { ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { linked_446.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }; i__851000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000072__1); continue L1 } else { i__851000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000072__1); continue L1 } } else { i__851000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A_New() *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A) Ctor() {}
//line :152:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A) Invoke_O_O__O(self, s__851000081__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__592 any = A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A_New_O_O(self, s__851000081__1); var tmp2 *jrt.Class; var fncls__591 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A_fn_class; if fncls__591 == nil { var fncls__591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__592); A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A_fn_class = fncls__591d; tmp2 = fncls__591d } else { tmp2 = fncls__591 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__592, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :152:1
func A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :152:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A) Ctor_O_O(c__iter__851000080, c__s__851000081 any) { t.F_iter__851000080 = c__iter__851000080; t.F_s__851000081 = c__s__851000081 }
//line :152:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A) Invoke_O__O(self any) any { { var s__851000081__1 any; var t_ any = t.F_s__851000081; t.F_s__851000081 = nil; s__851000081__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_529 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = s__851000081__1; if linked_530 == nil { temp__1927000414__auto____2 = ifn_531.Invoke_O__O(arg_532) } else { temp__1927000414__auto____2 = linked_530.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_529, arg_532) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000081__3 any = temp__1927000414__auto____2; var tmp1 any; var root_533 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = s__851000081__3; if linked_534 == nil { tmp1 = ifn_535.Invoke_O__O(arg_536) } else { tmp1 = linked_534.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_533, arg_536) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_537 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = s__851000081__3; if linked_538 == nil { c__1927001037__auto____4 = ifn_539.Invoke_O__O(arg_540) } else { c__1927001037__auto____4 = linked_538.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_537, arg_540) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000083__6 any; var root_541 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_542 == nil { b__851000083__6 = ifn_543.Invoke_O__O(arg_544) } else { b__851000083__6 = linked_542.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_541, arg_544) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__551 any = A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A_New_O_I_O(b__851000083__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__550 *jrt.Class = A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A_fn_class; if fncls__550 == nil { var fncls__550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__551); A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A_fn_class = fncls__550d; tmp3 = fncls__550d } else { tmp3 = fncls__550 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__551, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_552 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any; var root_557 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = b__851000083__6; if linked_558 == nil { arg_555 = ifn_559.Invoke_O__O(arg_560) } else { arg_555 = linked_558.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_557, arg_560) }; var arg_556 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000080); var tmp5 any; var root_561 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = s__851000081__3; if linked_562 == nil { tmp5 = ifn_563.Invoke_O__O(arg_564) } else { tmp5 = linked_562.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_561, arg_564) }; arg_556 = tmp4.Invoke_O__O(tmp5); if linked_553 == nil { return ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { return linked_553.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) } } else { var root_565 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any; var root_570 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = b__851000083__6; if linked_571 == nil { arg_568 = ifn_572.Invoke_O__O(arg_573) } else { arg_568 = linked_571.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_570, arg_573) }; var arg_569 any; if linked_566 == nil { return ifn_567.Invoke_O_O__O(arg_568, arg_569) } else { return linked_566.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_565, arg_568, arg_569) } } } else { var f__4 any; var root_574 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = s__851000081__3; if linked_575 == nil { f__4 = ifn_576.Invoke_O__O(arg_577) } else { f__4 = linked_575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_574, arg_577) }; var sig__5 any = A_arbace_classes_annot_A_const_94.Invoke_O__O(f__4); if jrt.J2g_Truth(sig__5) { var root_578 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(f__4), nil, sig__5)).Ref(); var arg_582 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000080); var tmp7 any; var root_583 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = s__851000081__3; if linked_584 == nil { tmp7 = ifn_585.Invoke_O__O(arg_586) } else { tmp7 = linked_584.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_583, arg_586) }; arg_582 = tmp6.Invoke_O__O(tmp7); if linked_579 == nil { return ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { return linked_579.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) } } else { var tmp8 any; var root_587 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = s__851000081__3; if linked_588 == nil { tmp8 = ifn_589.Invoke_O__O(arg_590) } else { tmp8 = linked_588.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_587, arg_590) }; s__851000081__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :152:1
func A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :152:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A) Ctor_O_I_O(c__b__851000083 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000083 = c__b__851000083; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :152:1
func (t *A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A) Invoke_O__O(self any) any { { var i__851000082__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000082__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000082__1)); var sig__3 any = A_arbace_classes_annot_A_const_94.Invoke_O__O(f__2); if jrt.J2g_Truth(sig__3) { var root_545 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = t.F_b__851000083; var arg_549 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(f__2), nil, sig__3)).Ref(); if linked_546 == nil { ifn_547.Invoke_O_O__O(arg_548, arg_549) } else { linked_546.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_545, arg_548, arg_549) }; i__851000082__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000082__1); continue L1 } else { i__851000082__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000082__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_annot_throws_lines_A_New() *A_arbace_classes_annot_throws_lines_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_throws_lines_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_classes_annot_throws_lines_A) Ctor() {}
//line :158:1
func (t *A_arbace_classes_annot_throws_lines_A) Invoke_O_O_O__O(self, n__0, d__1 any) any { var iter__1927001039__auto____3 any; var fnbody__735 any = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__734 *jrt.Class = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A_fn_class; if






	fncls__734 == nil { var fncls__734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, fnbody__735); A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A_fn_class = fncls__734d; tmp1 = fncls__734d } else { tmp1 = fncls__734 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__735, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(d__1)) }
//line :165:1
func A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A_New_O(p0 any) *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A{}; t.Ctor_O(p0); return t }
//line :165:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :165:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A) Invoke_O_O__O(self, s__851000093__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__733 any = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A_New_O_O_O(t.F_n, self, s__851000093__1); var tmp2 *jrt.Class; var fncls__732 *jrt.Class = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A_fn_class; if fncls__732 == nil { var fncls__732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, fnbody__733); A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A_fn_class = fncls__732d; tmp2 = fncls__732d } else { tmp2 = fncls__732 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__733, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :165:1
func A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :165:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A) Ctor_O_O_O(c__n, c__iter__851000092, c__s__851000093 any) { t.F_n = c__n; t.F_iter__851000092 = c__iter__851000092; t.F_s__851000093 = c__s__851000093 }
//line :165:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A) Invoke_O__O(self any) any { { var s__851000093__1 any; var t_ any = t.F_s__851000093; t.F_s__851000093 = nil; s__851000093__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_600 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = s__851000093__1; if linked_601 == nil { temp__1927000414__auto____2 = ifn_602.Invoke_O__O(arg_603) } else { temp__1927000414__auto____2 = linked_601.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_600, arg_603) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000093__3 any = temp__1927000414__auto____2; var tmp1 any; var root_604 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = s__851000093__3; if linked_605 == nil { tmp1 = ifn_606.Invoke_O__O(arg_607) } else { tmp1 = linked_605.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_604, arg_607) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_608 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = s__851000093__3; if linked_609 == nil { c__1927001037__auto____4 = ifn_610.Invoke_O__O(arg_611) } else { c__1927001037__auto____4 = linked_609.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_608, arg_611) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000095__6 any; var root_612 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_613 == nil { b__851000095__6 = ifn_614.Invoke_O__O(arg_615) } else { b__851000095__6 = linked_613.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_612, arg_615) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__655 any = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A_New_O_O_I_O(b__851000095__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__654 *jrt.Class = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A_fn_class; if fncls__654 == nil { var fncls__654d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, fnbody__655); A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A_fn_class = fncls__654d; tmp3 = fncls__654d } else { tmp3 = fncls__654 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__655, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_656 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any; var root_661 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = b__851000095__6; if linked_662 == nil { arg_659 = ifn_663.Invoke_O__O(arg_664) } else { arg_659 = linked_662.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_661, arg_664) }; var arg_660 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000092); var tmp5 any; var root_665 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = s__851000093__3; if linked_666 == nil { tmp5 = ifn_667.Invoke_O__O(arg_668) } else { tmp5 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; arg_660 = tmp4.Invoke_O__O(tmp5); if linked_657 == nil { return ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { return linked_657.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_656, arg_659, arg_660) } } else { var root_669 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any; var root_674 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = b__851000095__6; if linked_675 == nil { arg_672 = ifn_676.Invoke_O__O(arg_677) } else { arg_672 = linked_675.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_674, arg_677) }; var arg_673 any; if linked_670 == nil { return ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { return linked_670.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) } } } else { var mm__4 any; var root_678 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = s__851000093__3; if linked_679 == nil { mm__4 = ifn_680.Invoke_O__O(arg_681) } else { mm__4 = linked_679.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_678, arg_681) }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_103); if jrt.J2g_Truth(tmp6.Invoke_O__O(A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4))) { var ts__5 any; var root_682 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_684 lang.IFn

	if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = A_arbace_classes_annot_A_const_102.Invoke_O__O(mm__4); if linked_683 == nil { ts__5 = ifn_684.Invoke_O__O(arg_685) } else { ts__5 = linked_683.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_682, arg_685) }
//line :165:1
	if jrt.J2g_Truth(ts__5) { var root_686 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_133, nil, nil); var tmp8 *jrt.String
		var tmp9 any = A_arbace_classes_annot_A_const_97


		if lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4)) {
			var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil); var tmp11 any; var root_691 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, A_arbace_classes_annot_bin_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any; var root_695 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = t.F_n; var arg_699 any = mm__4; if linked_696 == nil { arg_694 = ifn_697.Invoke_O_O__O(arg_698, arg_699) } else { arg_694 = linked_696.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_695, arg_698, arg_699) }; if linked_692 == nil { tmp11 = ifn_693.Invoke_O__O(arg_694) } else { tmp11 = linked_692.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_691, arg_694) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)) } else {
				var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_9, nil); var tmp13 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__4); var tmp14 any; var root_700 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, A_arbace_classes_annot_bin_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__4); if linked_701 == nil { tmp14 = ifn_702.Invoke_O__O(arg_703) } else { tmp14 = linked_701.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_700, arg_703) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp14)) }
//line :169:1
		var tmp15 any = tmp8.Ref(); var tmp16 any; var root_704 any = A_arbace_classes_annot_A_const_17.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_706 lang.IFn


		if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = A_arbace_classes_annot_A_const_32.GetRawRoot__O(); var arg_708 any; var root_709 any = A_arbace_classes_annot_A_const_35.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any; var fnbody__719 any = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A_New(); var tmp17 *jrt.Class; var fncls__718 *jrt.Class = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A_fn_class; if fncls__718 == nil { var fncls__718d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, nil); A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A_fn_class = fncls__718d; tmp17 = fncls__718d } else { tmp17 = fncls__718 }; arg_712 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__719, tmp17, nil); var arg_713 any = ts__5; if linked_710 == nil { arg_708 = ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { arg_708 = linked_710.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) }; if linked_705 == nil { tmp16 = ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { tmp16 = linked_705.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) }
//line :169:1
		arg_689 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, tmp16)).Ref()
//line :165:1
		var arg_690 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__851000092); var tmp19 any; var root_720 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = s__851000093__3; if linked_721 == nil { tmp19 = ifn_722.Invoke_O__O(arg_723) } else { tmp19 = linked_721.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_720, arg_723) }; arg_690 = tmp18.Invoke_O__O(tmp19); if linked_687 == nil { return ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { return linked_687.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) } } else { var tmp20 any; var root_724 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = s__851000093__3; if linked_725 == nil { tmp20 = ifn_726.Invoke_O__O(arg_727) } else { tmp20 = linked_725.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_724, arg_727) }; s__851000093__1 = tmp20; continue L1 } } else { var tmp21 any; var root_728 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = s__851000093__3; if linked_729 == nil { tmp21 = ifn_730.Invoke_O__O(arg_731) } else { tmp21 = linked_729.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_728, arg_731) }; s__851000093__1 = tmp21; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :165:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A) Ctor_O_O_I_O(c__b__851000095, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000095 = c__b__851000095; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A) Invoke_O__O(self any) any { { var i__851000094__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000094__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_101); if jrt.J2g_Truth(tmp2.Invoke_O__O(A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__2))) { var ts__3 any; var root_616 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_618 lang.IFn

	if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = A_arbace_classes_annot_A_const_102.Invoke_O__O(mm__2); if linked_617 == nil { ts__3 = ifn_618.Invoke_O__O(arg_619) } else { ts__3 = linked_617.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_616, arg_619) }
//line :165:1
	if jrt.J2g_Truth(ts__3) { var root_620 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = t.F_b__851000095; var arg_624 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_133, nil, nil); var tmp4 *jrt.String
		var tmp5 any = A_arbace_classes_annot_A_const_97


		if lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__2)) {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil); var tmp7 any; var root_625 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, A_arbace_classes_annot_bin_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var root_629 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = t.F_n; var arg_633 any = mm__2; if linked_630 == nil { arg_628 = ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { arg_628 = linked_630.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_629, arg_632, arg_633) }; if linked_626 == nil { tmp7 = ifn_627.Invoke_O__O(arg_628) } else { tmp7 = linked_626.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_625, arg_628) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)) } else {
				var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_9, nil); var tmp9 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__2); var tmp10 any; var root_634 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, A_arbace_classes_annot_bin_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__2); if linked_635 == nil { tmp10 = ifn_636.Invoke_O__O(arg_637) } else { tmp10 = linked_635.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_634, arg_637) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, tmp10)) }
//line :169:1
		var tmp11 any = tmp4.Ref(); var tmp12 any; var root_638 any = A_arbace_classes_annot_A_const_17.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_640 lang.IFn


		if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = A_arbace_classes_annot_A_const_32.GetRawRoot__O(); var arg_642 any; var root_643 any = A_arbace_classes_annot_A_const_35.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any; var fnbody__653 any = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A_New(); var tmp13 *jrt.Class; var fncls__652 *jrt.Class = A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A_fn_class; if fncls__652 == nil { var fncls__652d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, nil); A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A_fn_class = fncls__652d; tmp13 = fncls__652d } else { tmp13 = fncls__652 }; arg_646 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__653, tmp13, nil); var arg_647 any = ts__3; if linked_644 == nil { arg_642 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { arg_642 = linked_644.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if linked_639 == nil { tmp12 = ifn_640.Invoke_O_O__O(arg_641, arg_642) } else { tmp12 = linked_639.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_638, arg_641, arg_642) }
//line :169:1
		arg_624 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, tmp12)).Ref()
//line :165:1
		if linked_621 == nil { ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { linked_621.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }; i__851000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000094__1); continue L1 } else { i__851000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000094__1); continue L1 } } else { i__851000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000094__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A_New() *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A) Ctor() {}
//line :172:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A) Invoke_O_O__O(self, p1__851000091_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp2 any; var root_648 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, A_arbace_classes_annot_bin_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = p1__851000091_SHARP___1; if linked_649 == nil { tmp2 = ifn_650.Invoke_O__O(arg_651) } else { tmp2 = linked_649.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_648, arg_651) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :172:1
func A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A_New() *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A) Ctor() {}
//line :172:1
func (t *A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A) Invoke_O_O__O(self, p1__851000091_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp2 any; var root_714 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, A_arbace_classes_annot_bin_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = p1__851000091_SHARP___1; if linked_715 == nil { tmp2 = ifn_716.Invoke_O__O(arg_717) } else { tmp2 = linked_715.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_714, arg_717) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }







func A_arbace_classes_annot_pool_index_BANG__A_New() *A_arbace_classes_annot_pool_index_BANG__A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_pool_index_BANG__A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_classes_annot_pool_index_BANG__A) Ctor() {}
//line :180:1
func (t *A_arbace_classes_annot_pool_index_BANG__A) Invoke_O_O_O_O__O(self, pool__0, tag__1, v__2 any) any { var or__1927000174__auto____4 any; var root_736 any = A_arbace_classes_annot_A_const_104.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_738 lang.IFn; if




	linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var root_741 any = A_arbace_classes_annot_A_const_7.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = pool__0; if linked_742 == nil { arg_739 = ifn_743.Invoke_O__O(arg_744) } else { arg_739 = linked_742.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_741, arg_744) }; var tmp1 any = A_arbace_classes_annot_A_const_105; var arg_740 any = lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.Tuple_Create_O_O__IPersistentVector(tag__1, v__2)); if linked_737 == nil { or__1927000174__auto____4 = ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { or__1927000174__auto____4 = linked_737.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var i__5 any; var tmp2 *lang.Keyword = A_arbace_classes_annot_A_const_106; var tmp3 any; var root_745 any = A_arbace_classes_annot_A_const_7.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_747 lang.IFn
		if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = pool__0; if linked_746 == nil { tmp3 = ifn_747.Invoke_O__O(arg_748) } else { tmp3 = linked_746.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_745, arg_748) }; i__5 = tmp2.Invoke_O__O(tmp3)
		var root_749 any = A_arbace_classes_annot_A_const_107.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = pool__0; var arg_753 any; var fnbody__779 any = A_arbace_classes_annot_pool_index_BANG__fn__851000108_A_New_O_O_O(i__5, v__2, tag__1); var tmp4 *jrt.Class; var fncls__778 *jrt.Class = A_arbace_classes_annot_pool_index_BANG__fn__851000108_A_fn_class; if fncls__778 == nil { var fncls__778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, fnbody__779); A_arbace_classes_annot_pool_index_BANG__fn__851000108_A_fn_class = fncls__778d; tmp4 = fncls__778d } else { tmp4 = fncls__778 }; arg_753 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__779, tmp4, nil); if linked_750 == nil { ifn_751.Invoke_O_O__O(arg_752, arg_753) } else { linked_750.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_749, arg_752, arg_753) }
//line :185:1
		return i__5 } }

func A_arbace_classes_annot_pool_index_BANG__fn__851000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_pool_index_BANG__fn__851000108_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_pool_index_BANG__fn__851000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :187:1
func (t *A_arbace_classes_annot_pool_index_BANG__fn__851000108_A) Ctor_O_O_O(c__i, c__v, c__tag any) { t.F_i = c__i; t.F_v = c__v; t.F_tag = c__tag }
//line :187:1
func (t *A_arbace_classes_annot_pool_index_BANG__fn__851000108_A) Invoke_O_O__O(self, p1__851000107_SHARP___1 any) any {


	var root_754 any = A_arbace_classes_annot_A_const_108.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any; var root_760 any = A_arbace_classes_annot_A_const_109.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_762 lang.IFn
//line :189:1
	if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var root_766 any = A_arbace_classes_annot_A_const_110.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_768 lang.IFn
//line :188:1
	if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = p1__851000107_SHARP___1; var arg_770 any = A_arbace_classes_annot_A_const_111; var arg_771 any = A_arbace_classes_annot_A_const_9.GetRawRoot__O(); var arg_772 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_tag, t.F_v); if linked_767 == nil { arg_763 = ifn_768.Invoke_O_O_O_O__O(arg_769, arg_770, arg_771, arg_772) } else { arg_763 = linked_767.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_766, arg_769, arg_770, arg_771, arg_772) }
	var tmp1 any = A_arbace_classes_annot_A_const_105; var arg_764 any = lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.Tuple_Create_O_O__IPersistentVector(t.F_tag, t.F_v)); var arg_765 any = t.F_i; if linked_761 == nil { arg_757 = ifn_762.Invoke_O_O_O__O(arg_763, arg_764, arg_765) } else { arg_757 = linked_761.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_760, arg_763, arg_764, arg_765) }
	var arg_758 any = A_arbace_classes_annot_A_const_106; var arg_759 any; var na_773 any = t.F_i; var na_774 int64; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_annot_A_const_112).Invoke_O__O(t.F_tag)) { na_774 = 2 } else { na_774 = 1 }; if jrt.Long_InstanceOf(na_773) { var n0_775 int64 = jrt.NN(jrt.Long_Cast(na_773)).LongValue__J(); var n1_776 int64 = na_774; var nr_777 int64 = n0_775 + n1_776; if (n0_775^nr_777)&(n1_776^nr_777) >= 0 { arg_759 = jrt.Long_ValueOf_J__Long_NoInit(nr_777).Ref() } else { arg_759 = lang.Numbers_Add_O_J__Number_NoInit(na_773, na_774) } } else { arg_759 = lang.Numbers_Add_O_J__Number_NoInit(na_773, na_774) }; if linked_755 == nil { return ifn_756.Invoke_O_O_O__O(arg_757, arg_758, arg_759) } else { return linked_755.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_754, arg_757, arg_758, arg_759)
	}
}
func A_arbace_classes_annot_u1_A_New() *A_arbace_classes_annot_u1_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_u1_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_classes_annot_u1_A) Ctor() {}
//line :193:1
func (t *A_arbace_classes_annot_u1_A) Invoke_O_O_O__O(self, out__0, v__1 any) any { jrt.ByteArrayOutputStream_Cast(out__0).Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(v__1), 255))); return nil }
func A_arbace_classes_annot_u2_A_New() *A_arbace_classes_annot_u2_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_u2_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_classes_annot_u2_A) Ctor() {}
//line :194:1
func (t *A_arbace_classes_annot_u2_A) Invoke_O_O_O__O(self, out__0, v__1 any) any { var root_785 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_classes_annot_u1_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = out__0; var arg_789 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(v__1), 8)).Ref(); if linked_786 == nil { ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { linked_786.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; var root_780 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, A_arbace_classes_annot_u1_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = out__0; var arg_784 any = v__1; if linked_781 == nil { return ifn_782.Invoke_O_O__O(arg_783, arg_784) } else { return linked_781.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_780, arg_783, arg_784) } }



func A_arbace_classes_annot_element_value_A_New() *A_arbace_classes_annot_element_value_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_element_value_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_classes_annot_element_value_A) Ctor() {}
//line :198:1
func (t *A_arbace_classes_annot_element_value_A) Invoke_O_O_O_O__O(self, out__0, pool__1, v__2 any) any {


	{ var tmp1 any; var root_790 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_792 lang.IFn
		if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = v__2; var arg_794 any = A_arbace_classes_annot_A_const_31; if linked_791 == nil { tmp1 = ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { tmp1 = linked_791.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_790, arg_793, arg_794) }
//line :201:1
		if jrt.J2g_Truth(tmp1) {

			var root_936 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, A_arbace_classes_annot_u1_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = out__0; var arg_940 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_121)).Ref(); if linked_937 == nil { ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { linked_937.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }; var root_941 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, A_arbace_classes_annot_u2_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = out__0; var arg_945 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_classes_annot_A_const_31.Invoke_O__O(v__2))).Ref(); if linked_942 == nil { ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { linked_942.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) }
//line :201:1
			var seq_851000113__4 any; var root_795 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_797 lang.IFn


			if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = A_arbace_classes_annot_A_const_31.Invoke_O__O(v__2); if linked_796 == nil { seq_851000113__4 = ifn_797.Invoke_O__O(arg_798) } else { seq_851000113__4 = linked_796.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_795, arg_798) }
//line :201:1
			var chunk_851000114__5 any; var count_851000115__6 int64 = 0; var i_851000116__7 int64 = 0; L1: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i_851000116__7, count_851000115__6) { var x__8 any = lang.Indexed_Cast(chunk_851000114__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_851000116__7)); var root_946 any = A_arbace_classes_annot_A_const_122.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_classes_annot_element_value_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = out__0; var arg_950 any = pool__1; var arg_951 any = x__8; if linked_947 == nil { ifn_948.Invoke_O_O_O__O(arg_949, arg_950, arg_951) } else { linked_947.(*A_arbace_classes_annot_element_value_A).Invoke_O_O_O_O__O(root_946, arg_949, arg_950, arg_951) }; seq_851000113__4, chunk_851000114__5, count_851000115__6, i_851000116__7 = seq_851000113__4, chunk_851000114__5, count_851000115__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_851000116__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_799 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = seq_851000113__4; if linked_800 == nil { temp__1927000414__auto____8 = ifn_801.Invoke_O__O(arg_802) } else { temp__1927000414__auto____8 = linked_800.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_799, arg_802) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_851000113__9 any = temp__1927000414__auto____8; var tmp2 any; var root_803 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = seq_851000113__9; if linked_804 == nil { tmp2 = ifn_805.Invoke_O__O(arg_806) } else { tmp2 = linked_804.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_803, arg_806) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____10 any; var root_807 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = seq_851000113__9; if linked_808 == nil { c__1927000678__auto____10 = ifn_809.Invoke_O__O(arg_810) } else { c__1927000678__auto____10 = linked_808.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_807, arg_810) }; var tmp3 any; var root_952 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = seq_851000113__9; if linked_953 == nil { tmp3 = ifn_954.Invoke_O__O(arg_955) } else { tmp3 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_952, arg_955) }; seq_851000113__4, chunk_851000114__5, count_851000115__6, i_851000116__7 = tmp3, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__10 any; var root_811 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = seq_851000113__9; if linked_812 == nil { x__10 = ifn_813.Invoke_O__O(arg_814) } else { x__10 = linked_812.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_811, arg_814) }; var root_956 any = A_arbace_classes_annot_A_const_122.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, A_arbace_classes_annot_element_value_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = out__0; var arg_960 any = pool__1; var arg_961 any = x__10; if linked_957 == nil { ifn_958.Invoke_O_O_O__O(arg_959, arg_960, arg_961) } else { linked_957.(*A_arbace_classes_annot_element_value_A).Invoke_O_O_O_O__O(root_956, arg_959, arg_960, arg_961) }; var tmp4 any; var root_962 any = A_arbace_classes_annot_A_const_123.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = seq_851000113__9; if linked_963 == nil { tmp4 = ifn_964.Invoke_O__O(arg_965) } else { tmp4 = linked_963.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_962, arg_965) }; seq_851000113__4, chunk_851000114__5, count_851000115__6, i_851000116__7 = tmp4, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :201:1
					var tmp5 any; var root_815 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_817 lang.IFn



					if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = v__2; var arg_819 any = A_arbace_classes_annot_A_const_37; if linked_816 == nil { tmp5 = ifn_817.Invoke_O_O__O(arg_818, arg_819) } else { tmp5 = linked_816.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_815, arg_818, arg_819) }
//line :201:1
					if jrt.J2g_Truth(tmp5) {



						var root_966 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, A_arbace_classes_annot_u1_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = out__0; var arg_970 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_124)).Ref(); if linked_967 == nil { ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { linked_967.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }; var root_820 any = A_arbace_classes_annot_A_const_114.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, A_arbace_classes_annot_type_ann_body_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = out__0; var arg_824 any = pool__1; var arg_825 any = A_arbace_classes_annot_A_const_37.Invoke_O__O(v__2); if linked_821 == nil { return ifn_822.Invoke_O_O_O__O(arg_823, arg_824, arg_825) } else { return linked_821.(*A_arbace_classes_annot_type_ann_body_A).Invoke_O_O_O_O__O(root_820, arg_823, arg_824, arg_825) } } else {
//line :201:1
							var tmp6 any; var root_826 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_828 lang.IFn




							if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = v__2; var arg_830 any = A_arbace_classes_annot_A_const_39; if linked_827 == nil { tmp6 = ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { tmp6 = linked_827.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_826, arg_829, arg_830) }
//line :201:1
							if jrt.J2g_Truth(tmp6) {




								var root_971 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, A_arbace_classes_annot_u1_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = out__0; var arg_975 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_125)).Ref(); if linked_972 == nil { ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { linked_972.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) }; var root_831 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_classes_annot_u2_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = out__0; var arg_835 any; var root_836 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = pool__1; var arg_840 any = A_arbace_classes_annot_A_const_117; var arg_841 any = A_arbace_classes_annot_A_const_39.Invoke_O__O(v__2); if linked_837 == nil { arg_835 = ifn_838.Invoke_O_O_O__O(arg_839, arg_840, arg_841) } else { arg_835 = linked_837.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_836, arg_839, arg_840, arg_841) }; if linked_832 == nil { return ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { return linked_832.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } } else {
//line :201:1
									var tmp7 any; var root_842 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_844 lang.IFn





									if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = v__2; var arg_846 any = A_arbace_classes_annot_A_const_40; if linked_843 == nil { tmp7 = ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { tmp7 = linked_843.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_842, arg_845, arg_846) }
//line :201:1
									if jrt.J2g_Truth(tmp7) {





										var root_976 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_classes_annot_u1_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = out__0; var arg_980 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_126)).Ref(); if linked_977 == nil { ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { linked_977.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_976, arg_979, arg_980) }; var root_981 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, A_arbace_classes_annot_u2_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = out__0; var arg_985 any; var root_986 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = pool__1; var arg_990 any = A_arbace_classes_annot_A_const_117; var arg_991 any = A_arbace_classes_annot_A_const_40.Invoke_O__O(v__2); if linked_987 == nil { arg_985 = ifn_988.Invoke_O_O_O__O(arg_989, arg_990, arg_991) } else { arg_985 = linked_987.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_986, arg_989, arg_990, arg_991) }; if linked_982 == nil { ifn_983.Invoke_O_O__O(arg_984, arg_985) } else { linked_982.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_981, arg_984, arg_985) }; var root_847 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, A_arbace_classes_annot_u2_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = out__0; var arg_851 any; var root_852 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = pool__1; var arg_856 any = A_arbace_classes_annot_A_const_117; var arg_857 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(v__2); if linked_853 == nil { arg_851 = ifn_854.Invoke_O_O_O__O(arg_855, arg_856, arg_857) } else { arg_851 = linked_853.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_852, arg_855, arg_856, arg_857) }; if linked_848 == nil { return ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { return linked_848.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_847, arg_850, arg_851) } } else {
//line :201:1
											var tmp8 any; var root_858 any = A_arbace_classes_annot_A_const_30.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_860 lang.IFn






											if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = v__2; var arg_862 any = A_arbace_classes_annot_A_const_42; if linked_859 == nil { tmp8 = ifn_860.Invoke_O_O__O(arg_861, arg_862) } else { tmp8 = linked_859.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_858, arg_861, arg_862) }
//line :201:1
											if jrt.J2g_Truth(tmp8) { var c__4 any = A_arbace_classes_annot_A_const_42.Invoke_O__O(v__2); var x__5 any = A_arbace_classes_annot_A_const_43.Invoke_O__O(c__4); var t__6 any = A_arbace_classes_annot_A_const_44.Invoke_O__O(c__4)
												var G__851000117__7_ any = t__6







												switch lang.Util_Hash_O__I_NoInit(G__851000117__7_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_103) {

													var root_992 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_classes_annot_u1_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = out__0; var arg_996 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(jrt.NN(jrt.String_Cast(t__6)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); if linked_993 == nil { ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { linked_993.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) }; var root_864 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_classes_annot_u2_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = out__0; var arg_868 any; var root_869 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = pool__1; var arg_873 any = A_arbace_classes_annot_A_const_118; var arg_874 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__5)).Ref(); if linked_870 == nil { arg_868 = ifn_871.Invoke_O_O_O__O(arg_872, arg_873, arg_874) } else { arg_868 = linked_870.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_869, arg_872, arg_873, arg_874) }; if linked_865 == nil { return ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { return linked_865.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) } }
//line :210:1
												case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_104) {


													var root_997 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, A_arbace_classes_annot_u1_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = out__0; var arg_1001 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_127)).Ref(); if linked_998 == nil { ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { linked_998.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) }; var root_875 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, A_arbace_classes_annot_u2_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = out__0; var arg_879 any; var root_880 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = pool__1; var arg_884 any = A_arbace_classes_annot_A_const_118; var arg_885 any; var tmp9 any; var tmp10 any; var root_886 any = A_arbace_classes_annot_A_const_45.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = x__5; if linked_887 == nil { tmp10 = ifn_888.Invoke_O__O(arg_889) } else { tmp10 = linked_887.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_886, arg_889) }; if jrt.J2g_Truth(tmp10) { tmp9 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(x__5)).Ref() } else { tmp9 = x__5 }; arg_885 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp9)).Ref(); if linked_881 == nil { arg_879 = ifn_882.Invoke_O_O_O__O(arg_883, arg_884, arg_885) } else { arg_879 = linked_881.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_880, arg_883, arg_884, arg_885) }; if linked_876 == nil { return ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { return linked_876.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) } }
//line :210:1
												case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_105) {





													var root_1002 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, A_arbace_classes_annot_u1_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = out__0; var arg_1006 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_128)).Ref(); if linked_1003 == nil { ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { linked_1003.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }; var root_890 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, A_arbace_classes_annot_u2_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = out__0; var arg_894 any; var root_895 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = pool__1; var arg_899 any = A_arbace_classes_annot_A_const_119; var arg_900 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__5))).Ref(); if linked_896 == nil { arg_894 = ifn_897.Invoke_O_O_O__O(arg_898, arg_899, arg_900) } else { arg_894 = linked_896.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_895, arg_898, arg_899, arg_900) }; if linked_891 == nil { return ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { return linked_891.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_890, arg_893, arg_894) } }
//line :210:1
												case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_106) {




													var root_1018 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_classes_annot_u1_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = out__0; var arg_1022 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_129)).Ref(); if linked_1019 == nil { ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { linked_1019.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) }; var root_901 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, A_arbace_classes_annot_u2_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = out__0; var arg_905 any; var root_906 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = pool__1; var arg_910 any = A_arbace_classes_annot_A_const_120; var arg_911 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(jrt.Float_FloatToRawIntBits_F__I_NoInit(lang.RT_FloatCast_O__F_NoInit(x__5)))).Ref(); if linked_907 == nil { arg_905 = ifn_908.Invoke_O_O_O__O(arg_909, arg_910, arg_911) } else { arg_905 = linked_907.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_906, arg_909, arg_910, arg_911) }; if linked_902 == nil { return ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { return linked_902.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_901, arg_904, arg_905) } }
//line :210:1
												case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_107) {

													var root_1034 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, A_arbace_classes_annot_u1_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = out__0; var arg_1038 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(jrt.NN(jrt.String_Cast(t__6)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); if linked_1035 == nil { ifn_1036.Invoke_O_O__O(arg_1037, arg_1038) } else { linked_1035.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1034, arg_1037, arg_1038) }; var root_1007 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, A_arbace_classes_annot_u2_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = out__0; var arg_1011 any; var root_1012 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = pool__1; var arg_1016 any = A_arbace_classes_annot_A_const_118; var arg_1017 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__5)).Ref(); if linked_1013 == nil { arg_1011 = ifn_1014.Invoke_O_O_O__O(arg_1015, arg_1016, arg_1017) } else { arg_1011 = linked_1013.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_1012, arg_1015, arg_1016, arg_1017) }; if linked_1008 == nil { return ifn_1009.Invoke_O_O__O(arg_1010, arg_1011) } else { return linked_1008.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1007, arg_1010, arg_1011) } }
//line :210:1
												case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_108) {



													var root_1050 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, A_arbace_classes_annot_u1_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = out__0; var arg_1054 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_131)).Ref(); if linked_1051 == nil { ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { linked_1051.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) }; var root_1023 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, A_arbace_classes_annot_u2_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = out__0; var arg_1027 any; var root_1028 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = pool__1; var arg_1032 any = A_arbace_classes_annot_A_const_130; var arg_1033 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__5)).Ref(); if linked_1029 == nil { arg_1027 = ifn_1030.Invoke_O_O_O__O(arg_1031, arg_1032, arg_1033) } else { arg_1027 = linked_1029.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_1028, arg_1031, arg_1032, arg_1033) }; if linked_1024 == nil { return ifn_1025.Invoke_O_O__O(arg_1026, arg_1027) } else { return linked_1024.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1023, arg_1026, arg_1027) } }
//line :210:1
												case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_109) {

													var root_1066 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, A_arbace_classes_annot_u1_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = out__0; var arg_1070 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(jrt.NN(jrt.String_Cast(t__6)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))).Ref(); if linked_1067 == nil { ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { linked_1067.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) }; var root_1039 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, A_arbace_classes_annot_u2_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = out__0; var arg_1043 any; var root_1044 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = pool__1; var arg_1048 any = A_arbace_classes_annot_A_const_118; var arg_1049 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(x__5)).Ref(); if linked_1045 == nil { arg_1043 = ifn_1046.Invoke_O_O_O__O(arg_1047, arg_1048, arg_1049) } else { arg_1043 = linked_1045.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_1044, arg_1047, arg_1048, arg_1049) }; if linked_1040 == nil { return ifn_1041.Invoke_O_O__O(arg_1042, arg_1043) } else { return linked_1040.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1039, arg_1042, arg_1043) } }
//line :210:1
												case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__851000117__7_, Lit_110) {
													var root_1071 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, A_arbace_classes_annot_u1_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = out__0; var arg_1075 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_132)).Ref(); if linked_1072 == nil { ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { linked_1072.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) }; var root_1055 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, A_arbace_classes_annot_u2_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = out__0; var arg_1059 any; var root_1060 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = pool__1; var arg_1064 any = A_arbace_classes_annot_A_const_118; var arg_1065 any; if jrt.J2g_Truth(x__5) { arg_1065 = A_arbace_classes_annot_A_const_29 } else { arg_1065 = A_arbace_classes_annot_A_const_73 }; if linked_1061 == nil { arg_1059 = ifn_1062.Invoke_O_O_O__O(arg_1063, arg_1064, arg_1065) } else { arg_1059 = linked_1061.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_1060, arg_1063, arg_1064, arg_1065) }; if linked_1056 == nil { return ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { return linked_1056.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) } }
//line :210:1
												default:
												}





												var root_1076 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, A_arbace_classes_annot_u1_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = out__0; var arg_1080 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(A_arbace_classes_annot_A_const_133)).Ref(); if linked_1077 == nil { ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { linked_1077.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) }; var root_912 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, A_arbace_classes_annot_u2_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = out__0; var arg_916 any; var root_917 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = pool__1; var arg_921 any = A_arbace_classes_annot_A_const_117; var arg_922 any; var root_923 any = A_arbace_classes_annot_A_const_32.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = x__5; if linked_924 == nil { arg_922 = ifn_925.Invoke_O__O(arg_926) } else { arg_922 = linked_924.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_923, arg_926) }; if linked_918 == nil { arg_916 = ifn_919.Invoke_O_O_O__O(arg_920, arg_921, arg_922) } else { arg_916 = linked_918.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_917, arg_920, arg_921, arg_922) }; if linked_913 == nil { return ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { return linked_913.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_912, arg_915, arg_916) } } else {
//line :201:1
													if A_arbace_classes_annot_A_const_27 != nil { var tmp11 any; var root_927 any = A_arbace_classes_annot_A_const_47.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_929 lang.IFn
















														if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_annot_A_const_48.GetRawRoot__O()).Invoke_O__O(v__2))).Ref(); var arg_931 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_annot_A_const_49, v__2)); if linked_928 == nil { tmp11 = ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { tmp11 = linked_928.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }
//line :201:1
														panic(jrt.Thrown(jrt.Throwable_Cast(tmp11))) } else { return nil } } } } } } }
//line :198:1
	panic("j2g: unreachable")
}




















func A_arbace_classes_annot_type_ann_body_A_New() *A_arbace_classes_annot_type_ann_body_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_ann_body_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_classes_annot_type_ann_body_A) Ctor() {}
//line :220:1
func (t *A_arbace_classes_annot_type_ann_body_A) Invoke_O_O_O_O__O(self, out__0, pool__1, an__2 any) any {


	{ var root_1101 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, A_arbace_classes_annot_u2_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = out__0; var arg_1105 any; var root_1106 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = pool__1; var arg_1110 any = A_arbace_classes_annot_A_const_117; var arg_1111 any = A_arbace_classes_annot_A_const_44.Invoke_O__O(an__2); if linked_1107 == nil { arg_1105 = ifn_1108.Invoke_O_O_O__O(arg_1109, arg_1110, arg_1111) } else { arg_1105 = linked_1107.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_1106, arg_1109, arg_1110, arg_1111) }; if linked_1102 == nil { ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { linked_1102.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }
		var root_1112 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, A_arbace_classes_annot_u2_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = out__0; var arg_1116 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_classes_annot_A_const_50.Invoke_O__O(an__2))).Ref(); if linked_1113 == nil { ifn_1114.Invoke_O_O__O(arg_1115, arg_1116) } else { linked_1113.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1112, arg_1115, arg_1116) }
//line :220:1
		var seq_851000119__4 any; var root_1081 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1083 lang.IFn




		if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = A_arbace_classes_annot_A_const_50.Invoke_O__O(an__2); if linked_1082 == nil { seq_851000119__4 = ifn_1083.Invoke_O__O(arg_1084) } else { seq_851000119__4 = linked_1082.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1081, arg_1084) }
//line :220:1
		var chunk_851000120__5 any; var count_851000121__6 int64 = 0; var i_851000122__7 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z_NoInit(i_851000122__7, count_851000121__6) { var vec__851000123__8 any = lang.Indexed_Cast(chunk_851000120__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_851000122__7)); var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000123__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000123__8, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1123 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, A_arbace_classes_annot_u2_A_fn_class); var ifn_1125 lang.IFn
				if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = out__0; var arg_1127 any; var root_1128 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = pool__1; var arg_1132 any = A_arbace_classes_annot_A_const_117; var arg_1133 any = k__9; if linked_1129 == nil { arg_1127 = ifn_1130.Invoke_O_O_O__O(arg_1131, arg_1132, arg_1133) } else { arg_1127 = linked_1129.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_1128, arg_1131, arg_1132, arg_1133) }; if linked_1124 == nil { ifn_1125.Invoke_O_O__O(arg_1126, arg_1127) } else { linked_1124.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1123, arg_1126, arg_1127) }
				var root_1117 any = A_arbace_classes_annot_A_const_122.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, A_arbace_classes_annot_element_value_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = out__0; var arg_1121 any = pool__1; var arg_1122 any = v__10; if linked_1118 == nil { ifn_1119.Invoke_O_O_O__O(arg_1120, arg_1121, arg_1122) } else { linked_1118.(*A_arbace_classes_annot_element_value_A).Invoke_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122) }
//line :225:1
				seq_851000119__4, chunk_851000120__5, count_851000121__6, i_851000122__7 = seq_851000119__4, chunk_851000120__5, count_851000121__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_851000122__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_1085 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = seq_851000119__4; if linked_1086 == nil { temp__1927000414__auto____8 = ifn_1087.Invoke_O__O(arg_1088) } else { temp__1927000414__auto____8 = linked_1086.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1085, arg_1088) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_851000119__9 any = temp__1927000414__auto____8; var tmp1 any; var root_1089 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = seq_851000119__9; if linked_1090 == nil { tmp1 = ifn_1091.Invoke_O__O(arg_1092) } else { tmp1 = linked_1090.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1089, arg_1092) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_1093 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = seq_851000119__9; if linked_1094 == nil { c__1927000678__auto____10 = ifn_1095.Invoke_O__O(arg_1096) } else { c__1927000678__auto____10 = linked_1094.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1093, arg_1096) }; var tmp2 any; var root_1134 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = seq_851000119__9; if linked_1135 == nil { tmp2 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp2 = linked_1135.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1134, arg_1137) }; seq_851000119__4, chunk_851000120__5, count_851000121__6, i_851000122__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__851000126__10 any; var root_1097 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = seq_851000119__9; if linked_1098 == nil { vec__851000126__10 = ifn_1099.Invoke_O__O(arg_1100) } else { vec__851000126__10 = linked_1098.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1097, arg_1100) }; var k__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000126__10, lang.RT_IntCast_J__I_NoInit(0), nil); var v__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000126__10, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1144 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, A_arbace_classes_annot_u2_A_fn_class); var ifn_1146 lang.IFn
					if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = out__0; var arg_1148 any; var root_1149 any = A_arbace_classes_annot_A_const_116.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, A_arbace_classes_annot_pool_index_BANG__A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = pool__1; var arg_1153 any = A_arbace_classes_annot_A_const_117; var arg_1154 any = k__11; if linked_1150 == nil { arg_1148 = ifn_1151.Invoke_O_O_O__O(arg_1152, arg_1153, arg_1154) } else { arg_1148 = linked_1150.(*A_arbace_classes_annot_pool_index_BANG__A).Invoke_O_O_O_O__O(root_1149, arg_1152, arg_1153, arg_1154) }; if linked_1145 == nil { ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { linked_1145.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) }
					var root_1138 any = A_arbace_classes_annot_A_const_122.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, A_arbace_classes_annot_element_value_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = out__0; var arg_1142 any = pool__1; var arg_1143 any = v__12; if linked_1139 == nil { ifn_1140.Invoke_O_O_O__O(arg_1141, arg_1142, arg_1143) } else { linked_1139.(*A_arbace_classes_annot_element_value_A).Invoke_O_O_O_O__O(root_1138, arg_1141, arg_1142, arg_1143) }
//line :225:1
					var tmp3 any; var root_1155 any = A_arbace_classes_annot_A_const_123.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = seq_851000119__9; if linked_1156 == nil { tmp3 = ifn_1157.Invoke_O__O(arg_1158) } else { tmp3 = linked_1156.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1155, arg_1158) }; seq_851000119__4, chunk_851000120__5, count_851000121__6, i_851000122__7 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
//line :220:1
	panic("j2g: unreachable")
}







func A_arbace_classes_annot_target_info_A_New() *A_arbace_classes_annot_target_info_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_target_info_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_classes_annot_target_info_A) Ctor() {}
//line :229:1
func (t *A_arbace_classes_annot_target_info_A) Invoke_O_O_O__O(self, out__0, ref__1 any) any { var ref__3 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(ref__1), 4294967295); var sort__4 int64 = lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 24); var root_1185 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, A_arbace_classes_annot_u1_A_fn_class); var ifn_1187 lang.IFn; if




	linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = out__0; var arg_1189 any = jrt.Long_ValueOf_J__Long_NoInit(sort__4).Ref(); if linked_1186 == nil { ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { linked_1186.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) }; var G__851000130__5_ int32 = /*line :229:1*/lang.RT_IntCast_J__I_NoInit(sort__4); switch G__851000130__5_ {





	case 0:
		var root_1160 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, A_arbace_classes_annot_u1_A_fn_class); var ifn_1162 lang.IFn; if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = out__0; var arg_1164 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 16), 255)).Ref(); if linked_1161 == nil { return ifn_1162.Invoke_O_O__O(arg_1163, arg_1164) } else { return linked_1161.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1160, arg_1163, arg_1164) }
//line :235:1
	case 1:
		var root_1165 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, A_arbace_classes_annot_u1_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = out__0; var arg_1169 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 16), 255)).Ref(); if linked_1166 == nil { return ifn_1167.Invoke_O_O__O(arg_1168, arg_1169) } else { return linked_1166.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1165, arg_1168, arg_1169) }
//line :235:1
	case 16:

		var root_1170 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, A_arbace_classes_annot_u2_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = out__0; var arg_1174 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 8), 65535)).Ref(); if linked_1171 == nil { return ifn_1172.Invoke_O_O__O(arg_1173, arg_1174) } else { return linked_1171.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1170, arg_1173, arg_1174) }
//line :235:1
	case 17:


		var root_1195 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, A_arbace_classes_annot_u1_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = out__0; var arg_1199 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 16), 255)).Ref(); if linked_1196 == nil { ifn_1197.Invoke_O_O__O(arg_1198, arg_1199) } else { linked_1196.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1195, arg_1198, arg_1199) }; var root_1175 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, A_arbace_classes_annot_u1_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = out__0; var arg_1179 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 8), 255)).Ref(); if linked_1176 == nil { return ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { return linked_1176.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) }
//line :235:1
	case 18:


		var root_1200 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, A_arbace_classes_annot_u1_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = out__0; var arg_1204 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 16), 255)).Ref(); if linked_1201 == nil { ifn_1202.Invoke_O_O__O(arg_1203, arg_1204) } else { linked_1201.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1200, arg_1203, arg_1204) }; var root_1190 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, A_arbace_classes_annot_u1_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = out__0; var arg_1194 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 8), 255)).Ref(); if linked_1191 == nil { return ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { return linked_1191.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) }
//line :235:1
	case 19: return nil; case 20: return nil; case 21: return nil; case 22:
		var root_1205 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, A_arbace_classes_annot_u1_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = out__0; var arg_1209 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 16), 255)).Ref(); if linked_1206 == nil { return ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { return linked_1206.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) }
//line :235:1
	case 23:

		var root_1210 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, A_arbace_classes_annot_u2_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = out__0; var arg_1214 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(ref__3, 8), 65535)).Ref(); if linked_1211 == nil { return ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { return linked_1211.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }
//line :235:1
	default:}; var tmp1 any; var root_1180 any = A_arbace_classes_annot_A_const_47.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1182 lang.IFn; if




	linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_129, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(sort__4).Ref())).Ref(); var tmp2 any = A_arbace_classes_annot_A_const_134; var arg_1184 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.Long_ValueOf_J__Long_NoInit(ref__3).Ref())); if linked_1181 == nil { tmp1 = ifn_1182.Invoke_O_O__O(arg_1183, arg_1184) } else { tmp1 = linked_1181.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1180, arg_1183, arg_1184) }; /*line :235:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }






func A_arbace_classes_annot_type_path_A_New() *A_arbace_classes_annot_type_path_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_path_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_classes_annot_type_path_A) Ctor() {}
//line :242:1
func (t *A_arbace_classes_annot_type_path_A) Invoke_O_O_O__O(self, out__0, path__1 any) any { { var steps__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__1243 any = A_arbace_classes_annot_type_path_fn__851000132_A_New_O(path__1); var tmp2 *jrt.Class
												var fncls__1242 /*line :242:1*/*jrt.Class = A_arbace_classes_annot_type_path_fn__851000132_A_fn_class


	if fncls__1242 == nil { var fncls__1242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, fnbody__1243); A_arbace_classes_annot_type_path_fn__851000132_A_fn_class = fncls__1242d; tmp2 = fncls__1242d } else { tmp2 = fncls__1242 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1243, tmp2, nil); steps__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()








	var root_1264 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, A_arbace_classes_annot_u1_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = out__0; var arg_1268 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(steps__3)).Ref(); if linked_1265 == nil { ifn_1266.Invoke_O_O__O(arg_1267, arg_1268) } else { linked_1265.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1264, arg_1267, arg_1268) }
//line :242:1
	var seq_851000135__4 any; var root_1244 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1246 lang.IFn












	if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = steps__3; if linked_1245 == nil { seq_851000135__4 = ifn_1246.Invoke_O__O(arg_1247) } else { seq_851000135__4 = linked_1245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1244, arg_1247) }
//line :242:1
	var chunk_851000136__5 any; var count_851000137__6 int64 = 0; var i_851000138__7 int64 = 0; L1: for {












		if lang.Numbers_Lt_J_J__Z_NoInit(i_851000138__7, count_851000137__6) { var vec__851000139__8 any = lang.Indexed_Cast(chunk_851000136__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_851000138__7)); var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000139__8, lang.RT_IntCast_J__I_NoInit(0), nil); var a__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000139__8, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1274 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, A_arbace_classes_annot_u1_A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = out__0; var arg_1278 any = k__9; if linked_1275 == nil { ifn_1276.Invoke_O_O__O(arg_1277, arg_1278) } else { linked_1275.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1274, arg_1277, arg_1278) }; var root_1269 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, A_arbace_classes_annot_u1_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = out__0; var arg_1273 any = a__10; if linked_1270 == nil { ifn_1271.Invoke_O_O__O(arg_1272, arg_1273) } else { linked_1270.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1269, arg_1272, arg_1273) }; seq_851000135__4, chunk_851000136__5, count_851000137__6, i_851000138__7 = seq_851000135__4, chunk_851000136__5, count_851000137__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_851000138__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_1248 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = seq_851000135__4; if linked_1249 == nil { temp__1927000414__auto____8 = ifn_1250.Invoke_O__O(arg_1251) } else { temp__1927000414__auto____8 = linked_1249.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1248, arg_1251) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_851000135__9 any = temp__1927000414__auto____8; var tmp3 any; var root_1252 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = seq_851000135__9; if linked_1253 == nil { tmp3 = ifn_1254.Invoke_O__O(arg_1255) } else { tmp3 = linked_1253.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1252, arg_1255) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_1256 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = seq_851000135__9; if linked_1257 == nil { c__1927000678__auto____10 = ifn_1258.Invoke_O__O(arg_1259) } else { c__1927000678__auto____10 = linked_1257.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1256, arg_1259) }; var tmp4 any; var root_1279 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = seq_851000135__9; if linked_1280 == nil { tmp4 = ifn_1281.Invoke_O__O(arg_1282) } else { tmp4 = linked_1280.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1279, arg_1282) }; seq_851000135__4, chunk_851000136__5, count_851000137__6, i_851000138__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__851000142__10 any; var root_1260 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = seq_851000135__9; if linked_1261 == nil { vec__851000142__10 = ifn_1262.Invoke_O__O(arg_1263) } else { vec__851000142__10 = linked_1261.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1260, arg_1263) }; var k__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000142__10, lang.RT_IntCast_J__I_NoInit(0), nil); var a__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000142__10, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1288 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, A_arbace_classes_annot_u1_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = out__0; var arg_1292 any = k__11; if linked_1289 == nil { ifn_1290.Invoke_O_O__O(arg_1291, arg_1292) } else { linked_1289.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1288, arg_1291, arg_1292) }; var root_1283 any = A_arbace_classes_annot_A_const_113.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, A_arbace_classes_annot_u1_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = out__0; var arg_1287 any = a__12; if linked_1284 == nil { ifn_1285.Invoke_O_O__O(arg_1286, arg_1287) } else { linked_1284.(*A_arbace_classes_annot_u1_A).Invoke_O_O_O__O(root_1283, arg_1286, arg_1287) }; var tmp5 any; var root_1293 any = A_arbace_classes_annot_A_const_123.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = seq_851000135__9; if linked_1294 == nil { tmp5 = ifn_1295.Invoke_O__O(arg_1296) } else { tmp5 = linked_1294.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1293, arg_1296) }; seq_851000135__4, chunk_851000136__5, count_851000137__6, i_851000138__7 = tmp5, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :242:1*/panic("j2g: unreachable") }


func A_arbace_classes_annot_type_path_fn__851000132_A_New_O(p0 any) *A_arbace_classes_annot_type_path_fn__851000132_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_path_fn__851000132_A{}; t.Ctor_O(p0); return t }
//line :245:1
func (t *A_arbace_classes_annot_type_path_fn__851000132_A) Ctor_O(c__path any) { t.F_path = c__path }
//line :245:1
func (t *A_arbace_classes_annot_type_path_fn__851000132_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var acc__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
											if lang.Numbers_Gte_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_path))) { return acc__2 } else { var tmp1 *jrt.String = jrt.String_Cast(t.F_path); var G__851000133__3_ uint16 = jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))

		switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__851000133__3_).Ref()) { case 42: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__851000133__3_).Ref(), A_arbace_classes_annot_A_const_135) {


			var tmp2 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp3 any; var root_1216 any = A_arbace_classes_annot_A_const_9.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = acc__2; var arg_1220 any = A_arbace_classes_annot_A_const_137; if linked_1217 == nil { tmp3 = ifn_1218.Invoke_O_O__O(arg_1219, arg_1220) } else { tmp3 = linked_1217.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1216, arg_1219, arg_1220) }; i__1, acc__2 = tmp2, tmp3; continue L1 }
//line :248:1
		case 46: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__851000133__3_).Ref(), A_arbace_classes_annot_A_const_136) {

			var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 any; var root_1221 any = A_arbace_classes_annot_A_const_9.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = acc__2; var arg_1225 any = A_arbace_classes_annot_A_const_138; if linked_1222 == nil { tmp5 = ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { tmp5 = linked_1222.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) }; i__1, acc__2 = tmp4, tmp5; continue L1 }
//line :248:1
		case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__851000133__3_).Ref(), A_arbace_classes_annot_A_const_121) {
			var tmp6 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp7 any; var root_1226 any = A_arbace_classes_annot_A_const_9.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = acc__2; var arg_1230 any = A_arbace_classes_annot_A_const_139; if linked_1227 == nil { tmp7 = ifn_1228.Invoke_O_O__O(arg_1229, arg_1230) } else { tmp7 = linked_1227.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1226, arg_1229, arg_1230) }; i__1, acc__2 = tmp6, tmp7; continue L1 }
//line :248:1
		default:}; var tmp8 *jrt.String = jrt.String_Cast(t.F_path); var j__4 int32 = jrt.NN(tmp8).IndexOf_String_I__I(Lit_154, lang.RT_IntCast_J__I_NoInit(i__1)); var tmp9 int64 = lang.Numbers_Inc_J__J_NoInit(int64(j__4)); var tmp10 any; var root_1231 any = A_arbace_classes_annot_A_const_9.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1233 lang.IFn




		if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = acc__2; var arg_1235 any; var tmp11 any = A_arbace_classes_annot_A_const_140; var tmp12 any; var root_1236 any = A_arbace_classes_annot_A_const_28.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = t.F_path; var arg_1240 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); var arg_1241 any = jrt.Integer_ValueOf_I__Integer_NoInit(j__4).Ref(); if linked_1237 == nil { tmp12 = ifn_1238.Invoke_O_O_O__O(arg_1239, arg_1240, arg_1241) } else { tmp12 = linked_1237.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1236, arg_1239, arg_1240, arg_1241) }; arg_1235 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp12))).Ref()); if linked_1232 == nil { tmp10 = ifn_1233.Invoke_O_O__O(arg_1234, arg_1235) } else { tmp10 = linked_1232.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1231, arg_1234, arg_1235) }; i__1, acc__2 = tmp9, tmp10; continue L1 } } }; /*line :245:1*/panic("j2g: unreachable") }











func A_arbace_classes_annot_type_annotations_bytes_A_New() *A_arbace_classes_annot_type_annotations_bytes_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotations_bytes_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_classes_annot_type_annotations_bytes_A) Ctor() {}
//line :257:1
func (t *A_arbace_classes_annot_type_annotations_bytes_A) Invoke_O_O_O__O(self, pool__0, anns__1 any) any { var vs__3 any; var root_1297 any = A_arbace_classes_annot_A_const_141.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1299 lang.IFn; if





	linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = A_arbace_classes_annot_A_const_62; var arg_1301 any; if jrt.J2g_Truth(A_arbace_classes_annot_A_const_64.GetRawRoot__O()) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_65.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_annot_A_const_64.GetRawRoot__O(), jrt.Boolean_TRUE.Ref())); var tmp3 *lang.Compiler_AOTFn; var fnbody__1312 any = A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A_New_O(anns__1); var tmp4 *jrt.Class; var fncls__1311 *jrt.Class = A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A_fn_class; if fncls__1311 == nil { var fncls__1311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, fnbody__1312); A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A_fn_class = fncls__1311d; tmp4 = fncls__1311d } else { tmp4 = fncls__1311 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1312, tmp4, nil); arg_1301 = tmp1.Invoke_O_O__O(tmp2, tmp3.Ref()) } else { var tmp5 *lang.Compiler_AOTFn; var fnbody__1318 any = A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A_New_O(anns__1); var tmp6 *jrt.Class; var fncls__1317 *jrt.Class = A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A_fn_class; if fncls__1317 == nil { var fncls__1317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, fnbody__1318); A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A_fn_class = fncls__1317d; tmp6 = fncls__1317d } else { tmp6 = fncls__1317 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1318, tmp6, nil); arg_1301 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O() }; if linked_1298 == nil { vs__3 = ifn_1299.Invoke_O_O__O(arg_1300, arg_1301) } else { vs__3 = linked_1298.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1297, arg_1300, arg_1301) }; var tmp7 any; var root_1319 any =
	A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = vs__3; if linked_1320 == nil { tmp7 = ifn_1321.Invoke_O__O(arg_1322) } else { tmp7 = linked_1320.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1319, arg_1322) }; if jrt.J2g_Truth(tmp7) { var tmp8 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__6 any = jrt.ByteArrayOutputStream_New(); var root_1323 any = A_arbace_classes_annot_A_const_115.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, A_arbace_classes_annot_u2_A_fn_class); var ifn_1325 lang.IFn


		if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = out__6; var arg_1327 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(vs__3)).Ref(); if linked_1324 == nil { ifn_1325.Invoke_O_O__O(arg_1326, arg_1327) } else { linked_1324.(*A_arbace_classes_annot_u2_A).Invoke_O_O_O__O(root_1323, arg_1326, arg_1327) }
//line :264:1
		var seq_851000150__7 any; var root_1328 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1330 lang.IFn



		if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = vs__3; if linked_1329 == nil { seq_851000150__7 = ifn_1330.Invoke_O__O(arg_1331) } else { seq_851000150__7 = linked_1329.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1328, arg_1331) }
//line :264:1
		var chunk_851000151__8 any; var count_851000152__9 int64 = 0; var i_851000153__10 int64 = 0; L1: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(i_851000153__10, count_851000152__9) { var an__11 any = lang.Indexed_Cast(chunk_851000151__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_851000153__10)); var root_1354 any = A_arbace_classes_annot_A_const_142.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, A_arbace_classes_annot_target_info_A_fn_class); var ifn_1356 lang.IFn
				if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = out__6; var arg_1358 any = A_arbace_classes_annot_A_const_134.Invoke_O__O(an__11); if linked_1355 == nil { ifn_1356.Invoke_O_O__O(arg_1357, arg_1358) } else { linked_1355.(*A_arbace_classes_annot_target_info_A).Invoke_O_O_O__O(root_1354, arg_1357, arg_1358) }
				var root_1359 any = A_arbace_classes_annot_A_const_143.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, A_arbace_classes_annot_type_path_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = out__6; var arg_1363 any; var or__1927000174__auto____12 any = A_arbace_classes_annot_A_const_144.Invoke_O__O(an__11); if jrt.J2g_Truth(or__1927000174__auto____12) { arg_1363 = or__1927000174__auto____12 } else { arg_1363 = Lit_152 }; if linked_1360 == nil { ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { linked_1360.(*A_arbace_classes_annot_type_path_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) }
				var root_1348 any = A_arbace_classes_annot_A_const_114.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, A_arbace_classes_annot_type_ann_body_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = out__6; var arg_1352 any = pool__0; var arg_1353 any = an__11; if linked_1349 == nil { ifn_1350.Invoke_O_O_O__O(arg_1351, arg_1352, arg_1353) } else { linked_1349.(*A_arbace_classes_annot_type_ann_body_A).Invoke_O_O_O_O__O(root_1348, arg_1351, arg_1352, arg_1353) }
//line :268:1
				seq_851000150__7, chunk_851000151__8, count_851000152__9, i_851000153__10 = seq_851000150__7, chunk_851000151__8, count_851000152__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_851000153__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1332 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = seq_851000150__7; if linked_1333 == nil { temp__1927000414__auto____11 = ifn_1334.Invoke_O__O(arg_1335) } else { temp__1927000414__auto____11 = linked_1333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1332, arg_1335) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_851000150__12 any = temp__1927000414__auto____11; var tmp9 any; var root_1336 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = seq_851000150__12; if linked_1337 == nil { tmp9 = ifn_1338.Invoke_O__O(arg_1339) } else { tmp9 = linked_1337.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1336, arg_1339) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____13 any; var root_1340 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = seq_851000150__12; if linked_1341 == nil { c__1927000678__auto____13 = ifn_1342.Invoke_O__O(arg_1343) } else { c__1927000678__auto____13 = linked_1341.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1340, arg_1343) }; var tmp10 any; var root_1364 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = seq_851000150__12; if linked_1365 == nil { tmp10 = ifn_1366.Invoke_O__O(arg_1367) } else { tmp10 = linked_1365.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1364, arg_1367) }; seq_851000150__7, chunk_851000151__8, count_851000152__9, i_851000153__10 = tmp10, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var an__13 any; var root_1344 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1346 lang.IFn; if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any = seq_851000150__12; if linked_1345 == nil { an__13 = ifn_1346.Invoke_O__O(arg_1347) } else { an__13 = linked_1345.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1344, arg_1347) }
					var root_1374 any = A_arbace_classes_annot_A_const_142.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, A_arbace_classes_annot_target_info_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = out__6; var arg_1378 any = A_arbace_classes_annot_A_const_134.Invoke_O__O(an__13); if linked_1375 == nil { ifn_1376.Invoke_O_O__O(arg_1377, arg_1378) } else { linked_1375.(*A_arbace_classes_annot_target_info_A).Invoke_O_O_O__O(root_1374, arg_1377, arg_1378) }
					var root_1379 any = A_arbace_classes_annot_A_const_143.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, A_arbace_classes_annot_type_path_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = out__6; var arg_1383 any; var or__1927000174__auto____14 any = A_arbace_classes_annot_A_const_144.Invoke_O__O(an__13); if jrt.J2g_Truth(or__1927000174__auto____14) { arg_1383 = or__1927000174__auto____14 } else { arg_1383 = Lit_152 }; if linked_1380 == nil { ifn_1381.Invoke_O_O__O(arg_1382, arg_1383) } else { linked_1380.(*A_arbace_classes_annot_type_path_A).Invoke_O_O_O__O(root_1379, arg_1382, arg_1383) }
					var root_1368 any = A_arbace_classes_annot_A_const_114.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, A_arbace_classes_annot_type_ann_body_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = out__6; var arg_1372 any = pool__0; var arg_1373 any = an__13; if linked_1369 == nil { ifn_1370.Invoke_O_O_O__O(arg_1371, arg_1372, arg_1373) } else { linked_1369.(*A_arbace_classes_annot_type_ann_body_A).Invoke_O_O_O_O__O(root_1368, arg_1371, arg_1372, arg_1373) }
//line :268:1
					var tmp11 any; var root_1384 any = A_arbace_classes_annot_A_const_123.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = seq_851000150__12; if linked_1385 == nil { tmp11 = ifn_1386.Invoke_O__O(arg_1387) } else { tmp11 = linked_1385.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1384, arg_1387) }; seq_851000150__7, chunk_851000151__8, count_851000152__9, i_851000153__10 = tmp11, nil, 0, 0; continue L1 } } }
//line :264:1
			break L1 }; var bs__7 any = jrt.ByteArrayOutputStream_Cast(out__6).ToByteArray__B1().Ref(); var sb__8 any = jrt.StringBuilder_New(); var seq_851000154__9 any; var root_1388 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1390 lang.IFn








		if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = bs__7; if linked_1389 == nil { seq_851000154__9 = ifn_1390.Invoke_O__O(arg_1391) } else { seq_851000154__9 = linked_1389.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1388, arg_1391) }
//line :264:1
		var chunk_851000155__10 any; var count_851000156__11 int64 = 0; var i_851000157__12 int64 = 0; L2: for {








			if lang.Numbers_Lt_J_J__Z_NoInit(i_851000157__12, count_851000156__11) { var b__13 any = lang.Indexed_Cast(chunk_851000155__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_851000157__12)); var tmp12 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__8); var tmp13 any; var root_1408 any = A_arbace_classes_annot_A_const_28.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = jrt.Integer_ToHexString_I__String_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(256, lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(b__13), 255)))).Ref(); var arg_1412 any = A_arbace_classes_annot_A_const_29; if linked_1409 == nil { tmp13 = ifn_1410.Invoke_O_O__O(arg_1411, arg_1412) } else { tmp13 = linked_1409.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1408, arg_1411, arg_1412) }; jrt.NN(tmp12).Append_String__StringBuilder(jrt.String_Cast(tmp13)); seq_851000154__9, chunk_851000155__10, count_851000156__11, i_851000157__12 = seq_851000154__9, chunk_851000155__10, count_851000156__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_851000157__12); continue L2 } else { var temp__1927000414__auto____13 any; var root_1392 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = seq_851000154__9; if linked_1393 == nil { temp__1927000414__auto____13 = ifn_1394.Invoke_O__O(arg_1395) } else { temp__1927000414__auto____13 = linked_1393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1392, arg_1395) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_851000154__14 any = temp__1927000414__auto____13; var tmp14 any; var root_1396 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = seq_851000154__14; if linked_1397 == nil { tmp14 = ifn_1398.Invoke_O__O(arg_1399) } else { tmp14 = linked_1397.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1396, arg_1399) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____15 any; var root_1400 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = seq_851000154__14; if linked_1401 == nil { c__1927000678__auto____15 = ifn_1402.Invoke_O__O(arg_1403) } else { c__1927000678__auto____15 = linked_1401.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1400, arg_1403) }; var tmp15 any; var root_1413 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = seq_851000154__14; if linked_1414 == nil { tmp15 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp15 = linked_1414.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1413, arg_1416) }; seq_851000154__9, chunk_851000155__10, count_851000156__11, i_851000157__12 = tmp15, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var b__15 any; var root_1404 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = seq_851000154__14; if linked_1405 == nil { b__15 = ifn_1406.Invoke_O__O(arg_1407) } else { b__15 = linked_1405.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1404, arg_1407) }; var tmp16 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__8); var tmp17 any; var root_1417 any = A_arbace_classes_annot_A_const_28.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = jrt.Integer_ToHexString_I__String_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(256, lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(b__15), 255)))).Ref(); var arg_1421 any = A_arbace_classes_annot_A_const_29; if linked_1418 == nil { tmp17 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { tmp17 = linked_1418.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; jrt.NN(tmp16).Append_String__StringBuilder(jrt.String_Cast(tmp17)); var tmp18 any; var root_1422 any = A_arbace_classes_annot_A_const_123.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = seq_851000154__14; if linked_1423 == nil { tmp18 = ifn_1424.Invoke_O__O(arg_1425) } else { tmp18 = linked_1423.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1422, arg_1425) }; seq_851000154__9, chunk_851000155__10, count_851000156__11, i_851000157__12 = tmp18, nil, 0, 0; continue L2 } } }
//line :264:1
			break L2
		}








		tmp8 = jrt.NN(jrt.StringBuilder_Cast(sb__8)).ToString__String().Ref() }; return nil }()
//line :264:1
		if tmp19 != nil { if jrt.Exception_InstanceOf(tmp19) { var ___6 jrt.Exception_I = jrt.Exception_Cast(tmp19); _ = ___6; tmp8 = nil } else { panic(tmp19) } }; return tmp8 } else { return nil } }
//line :263:1
func A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A_New_O(p0 any) *A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A) Ctor_O(c__anns any) { t.F_anns = c__anns }
//line :263:1
func (t *A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1307 any = A_arbace_classes_annot_A_const_66.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = t.F_anns; if linked_1308 == nil { tmp1 = ifn_1309.Invoke_O__O(arg_1310) } else { tmp1 = linked_1308.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_1307, arg_1310) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :263:1
func A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A_New_O(p0 any) *A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A) Ctor_O(c__anns any) { t.F_anns = c__anns }
//line :263:1
func (t *A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1313 any = A_arbace_classes_annot_A_const_66.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var t_ any = t.F_anns; t.F_anns = nil; arg_1316 = t_; if linked_1314 == nil { tmp1 = ifn_1315.Invoke_O__O(arg_1316) } else { tmp1 = linked_1314.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_1313, arg_1316) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }













func A_arbace_classes_annot_type_annotation_lines_A_New() *A_arbace_classes_annot_type_annotation_lines_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_classes_annot_type_annotation_lines_A) Ctor() {}
//line :277:1
func (t *A_arbace_classes_annot_type_annotation_lines_A) Invoke_O_O_O_O__O(self, n__0, d__1, members__2 any) any { var pool__4 any; var root_1426 any = A_arbace_classes_annot_A_const_145.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1428 lang.IFn; if



	linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_annot_A_const_106, A_arbace_classes_annot_A_const_29, A_arbace_classes_annot_A_const_105, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_classes_annot_A_const_111, lang.PersistentVector_EMPTY.Ref())); if linked_1427 == nil { pool__4 = ifn_1428.Invoke_O__O(arg_1429) } else { pool__4 = linked_1427.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1426, arg_1429) }; var ys__5 any; var root_1430 any = /*line :277:1*/A_arbace_classes_annot_A_const_146.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1432 lang.IFn; if




	linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any; var root_1434 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1436 lang.IFn; if
	linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any; var temp__1927000414__auto____5 any; var root_1439 any = A_arbace_classes_annot_A_const_147.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, A_arbace_classes_annot_type_annotations_bytes_A_fn_class); var ifn_1441 lang.IFn; if
	linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = pool__4; var arg_1443 any = A_arbace_classes_annot_A_const_148.Invoke_O__O(d__1); if linked_1440 == nil { temp__1927000414__auto____5 = ifn_1441.Invoke_O_O__O(arg_1442, arg_1443) } else { temp__1927000414__auto____5 = linked_1440.(*A_arbace_classes_annot_type_annotations_bytes_A).Invoke_O_O_O__O(root_1439, arg_1442, arg_1443) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; arg_1437 = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil), jrt.RefArrayOf(jrt.Object_class, nil, h__6)).Ref()) } else { arg_1437 = nil }; var arg_1438 any; if
	jrt.J2g_Truth(members__2) {
		var root_1444 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any; var iter__1927001039__auto____5 any; var fnbody__1554 any = A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A_New_O_O(n__0, pool__4); var tmp1 *jrt.Class; var fncls__1553 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A_fn_class
		if fncls__1553 == nil { var fncls__1553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, fnbody__1554); A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A_fn_class = fncls__1553d; tmp1 = fncls__1553d } else { tmp1 = fncls__1553 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1554, tmp1, nil); arg_1447 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(d__1))
//line :286:1
		var arg_1448 any; var iter__1927001039__auto____5_2 any; var fnbody__1630 any = A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A_New_O(pool__4); var tmp2 *jrt.Class
		var fncls__1629 /*line :286:1*/*jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A_fn_class







		if fncls__1629 == nil { var fncls__1629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, fnbody__1630); A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A_fn_class = fncls__1629d; tmp2 = fncls__1629d } else { tmp2 = fncls__1629 }; iter__1927001039__auto____5_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1630, tmp2, nil); arg_1448 = lang.IFn_Cast(iter__1927001039__auto____5_2).Invoke_O__O(A_arbace_classes_annot_A_const_99.Invoke_O__O(d__1))
//line :286:1
		if linked_1445 == nil { arg_1438 = ifn_1446.Invoke_O_O__O(arg_1447, arg_1448) } else { arg_1438 = linked_1445.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1444, arg_1447, arg_1448) } } else {
//line :285:1
			arg_1438 = nil }; if /*line :283:1*/ linked_1435 == nil { arg_1433 = ifn_1436.Invoke_O_O__O(arg_1437, arg_1438) } else { arg_1433 = linked_1435.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1434, arg_1437, arg_1438) }; if /*line :282:1*/ linked_1431 == nil { ys__5 = ifn_1432.Invoke_O__O(arg_1433) } else { ys__5 = linked_1431.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1430, arg_1433) }; var tmp3 any; var root_1631 any =















	A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = ys__5; if linked_1632 == nil { tmp3 = ifn_1633.Invoke_O__O(arg_1634) } else { tmp3 = linked_1632.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1631, arg_1634) }; if jrt.J2g_Truth(tmp3) {
		var root_1635 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any; var iter__1927001039__auto____6 any; var fnbody__1717 any = A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A_New(); var tmp4 *jrt.Class; var fncls__1716 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A_fn_class
		if fncls__1716 == nil { var fncls__1716d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, nil); A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A_fn_class = fncls__1716d; tmp4 = fncls__1716d } else { tmp4 = fncls__1716 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1717, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp6 *lang.Keyword = A_arbace_classes_annot_A_const_111; var tmp7 any; var root_1718 any = A_arbace_classes_annot_A_const_7.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = pool__4; if linked_1719 == nil { tmp7 = ifn_1720.Invoke_O__O(arg_1721) } else { tmp7 = linked_1719.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1718, arg_1721) }; arg_1638 = tmp5.Invoke_O__O(tmp6.Invoke_O__O(tmp7))
//line :299:1
		var arg_1639 any = ys__5; if linked_1636 == nil { return ifn_1637.Invoke_O_O__O(arg_1638, arg_1639) } else { return linked_1636.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1635, arg_1638, arg_1639) } } else {
//line :298:1
			return nil } }
//line :287:1
func A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A{}; t.Ctor_O_O(p0, p1); return t }
//line :287:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A) Ctor_O_O(c__n, c__pool any) { t.F_n = c__n; t.F_pool = c__pool }
//line :287:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A) Invoke_O_O__O(self, s__851000160__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1552 any = A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A_New_O_O_O_O(self, t.F_n, t.F_pool, s__851000160__1); var tmp2 *jrt.Class; var fncls__1551 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A_fn_class; if fncls__1551 == nil { var fncls__1551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, fnbody__1552); A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A_fn_class = fncls__1551d; tmp2 = fncls__1551d } else { tmp2 = fncls__1551 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1552, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :287:1
func A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :287:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A) Ctor_O_O_O_O(c__iter__851000159, c__n, c__pool, c__s__851000160 any) { t.F_iter__851000159 = c__iter__851000159; t.F_n = c__n; t.F_pool = c__pool; t.F_s__851000160 = c__s__851000160 }
//line :287:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A) Invoke_O__O(self any) any { { var s__851000160__1 any; var t_ any = t.F_s__851000160; t.F_s__851000160 = nil; s__851000160__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1449 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = s__851000160__1; if linked_1450 == nil { temp__1927000414__auto____2 = ifn_1451.Invoke_O__O(arg_1452) } else { temp__1927000414__auto____2 = linked_1450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1449, arg_1452) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000160__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1453 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = s__851000160__3; if linked_1454 == nil { tmp1 = ifn_1455.Invoke_O__O(arg_1456) } else { tmp1 = linked_1454.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1453, arg_1456) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1457 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = s__851000160__3; if linked_1458 == nil { c__1927001037__auto____4 = ifn_1459.Invoke_O__O(arg_1460) } else { c__1927001037__auto____4 = linked_1458.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1457, arg_1460) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000162__6 any; var root_1461 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1462 == nil { b__851000162__6 = ifn_1463.Invoke_O__O(arg_1464) } else { b__851000162__6 = linked_1462.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1461, arg_1464) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1489 any = A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A_New_O_O_O_I_O(b__851000162__6, t.F_n, t.F_pool, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1488 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A_fn_class; if fncls__1488 == nil { var fncls__1488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, fnbody__1489); A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A_fn_class = fncls__1488d; tmp3 = fncls__1488d } else { tmp3 = fncls__1488 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1489, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1490 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any; var root_1495 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = b__851000162__6; if linked_1496 == nil { arg_1493 = ifn_1497.Invoke_O__O(arg_1498) } else { arg_1493 = linked_1496.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1495, arg_1498) }; var arg_1494 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000159); var tmp5 any; var root_1499 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = s__851000160__3; if linked_1500 == nil { tmp5 = ifn_1501.Invoke_O__O(arg_1502) } else { tmp5 = linked_1500.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1499, arg_1502) }; arg_1494 = tmp4.Invoke_O__O(tmp5); if linked_1491 == nil { return ifn_1492.Invoke_O_O__O(arg_1493, arg_1494) } else { return linked_1491.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1490, arg_1493, arg_1494) } } else { var root_1503 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any; var root_1508 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = b__851000162__6; if linked_1509 == nil { arg_1506 = ifn_1510.Invoke_O__O(arg_1511) } else { arg_1506 = linked_1509.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1508, arg_1511) }; var arg_1507 any; if linked_1504 == nil { return ifn_1505.Invoke_O_O__O(arg_1506, arg_1507) } else { return linked_1504.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1503, arg_1506, arg_1507) } } } else { var mm__4 any; var root_1512 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = s__851000160__3; if linked_1513 == nil { mm__4 = ifn_1514.Invoke_O__O(arg_1515) } else { mm__4 = linked_1513.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1512, arg_1515) }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_150); if jrt.J2g_Truth(tmp6.Invoke_O__O(A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4))) { var h__5 any; var root_1516 any = A_arbace_classes_annot_A_const_147.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, A_arbace_classes_annot_type_annotations_bytes_A_fn_class); var ifn_1518 lang.IFn

	if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = t.F_pool; var arg_1520 any = A_arbace_classes_annot_A_const_148.Invoke_O__O(mm__4); if linked_1517 == nil { h__5 = ifn_1518.Invoke_O_O__O(arg_1519, arg_1520) } else { h__5 = linked_1517.(*A_arbace_classes_annot_type_annotations_bytes_A).Invoke_O_O_O__O(root_1516, arg_1519, arg_1520) }
//line :287:1
	if jrt.J2g_Truth(h__5) { var root_1521 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any
		var tmp7 any = A_arbace_classes_annot_A_const_97


		if lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4)) {
			var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_142, nil, Lit_9, nil); var tmp9 any; var root_1526 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, A_arbace_classes_annot_bin_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any; var root_1530 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = t.F_n; var arg_1534 any = mm__4; if linked_1531 == nil { arg_1529 = ifn_1532.Invoke_O_O__O(arg_1533, arg_1534) } else { arg_1529 = linked_1531.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_1530, arg_1533, arg_1534) }; if linked_1527 == nil { tmp9 = ifn_1528.Invoke_O__O(arg_1529) } else { tmp9 = linked_1527.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_1526, arg_1529) }; arg_1524 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, h__5)).Ref() } else {
				var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_143, nil, Lit_9, nil, Lit_9, nil); var tmp11 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__4); var tmp12 any; var root_1535 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, A_arbace_classes_annot_bin_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__4); if linked_1536 == nil { tmp12 = ifn_1537.Invoke_O__O(arg_1538) } else { tmp12 = linked_1536.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_1535, arg_1538) }; arg_1524 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, tmp12, nil, h__5)).Ref() }
//line :287:1
		var arg_1525 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__851000159); var tmp14 any; var root_1539 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = s__851000160__3; if linked_1540 == nil { tmp14 = ifn_1541.Invoke_O__O(arg_1542) } else { tmp14 = linked_1540.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1539, arg_1542) }; arg_1525 = tmp13.Invoke_O__O(tmp14); if linked_1522 == nil { return ifn_1523.Invoke_O_O__O(arg_1524, arg_1525) } else { return linked_1522.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1521, arg_1524, arg_1525) } } else { var tmp15 any; var root_1543 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = s__851000160__3; if linked_1544 == nil { tmp15 = ifn_1545.Invoke_O__O(arg_1546) } else { tmp15 = linked_1544.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1543, arg_1546) }; s__851000160__1 = tmp15; continue L1 } } else { var tmp16 any; var root_1547 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = s__851000160__3; if linked_1548 == nil { tmp16 = ifn_1549.Invoke_O__O(arg_1550) } else { tmp16 = linked_1548.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1547, arg_1550) }; s__851000160__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :287:1
func A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :287:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A) Ctor_O_O_O_I_O(c__b__851000162, c__n, c__pool any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000162 = c__b__851000162; t.F_n = c__n; t.F_pool = c__pool; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :287:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A) Invoke_O__O(self any) any { { var i__851000161__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000161__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000161__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_149); if jrt.J2g_Truth(tmp2.Invoke_O__O(A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__2))) { var h__3 any; var root_1465 any = A_arbace_classes_annot_A_const_147.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, A_arbace_classes_annot_type_annotations_bytes_A_fn_class); var ifn_1467 lang.IFn

	if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = t.F_pool; var arg_1469 any = A_arbace_classes_annot_A_const_148.Invoke_O__O(mm__2); if linked_1466 == nil { h__3 = ifn_1467.Invoke_O_O__O(arg_1468, arg_1469) } else { h__3 = linked_1466.(*A_arbace_classes_annot_type_annotations_bytes_A).Invoke_O_O_O__O(root_1465, arg_1468, arg_1469) }
//line :287:1
	if jrt.J2g_Truth(h__3) { var root_1470 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = t.F_b__851000162; var arg_1474 any
		var tmp3 any = A_arbace_classes_annot_A_const_97


		if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__2)) {
			var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_142, nil, Lit_9, nil); var tmp5 any; var root_1475 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, A_arbace_classes_annot_bin_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any; var root_1479 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = t.F_n; var arg_1483 any = mm__2; if linked_1480 == nil { arg_1478 = ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { arg_1478 = linked_1480.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) }; if linked_1476 == nil { tmp5 = ifn_1477.Invoke_O__O(arg_1478) } else { tmp5 = linked_1476.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_1475, arg_1478) }; arg_1474 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, h__3)).Ref() } else {
				var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_143, nil, Lit_9, nil, Lit_9, nil); var tmp7 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__2); var tmp8 any; var root_1484 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, A_arbace_classes_annot_bin_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__2); if linked_1485 == nil { tmp8 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp8 = linked_1485.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_1484, arg_1487) }; arg_1474 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp8, nil, h__3)).Ref() }
//line :287:1
		if linked_1471 == nil { ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { linked_1471.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) }; i__851000161__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000161__1); continue L1 } else { i__851000161__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000161__1); continue L1 } } else { i__851000161__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000161__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A_New_O(p0 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A{}; t.Ctor_O(p0); return t }
//line :294:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A) Ctor_O(c__pool any) { t.F_pool = c__pool }
//line :294:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A) Invoke_O_O__O(self, s__851000170__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1628 any = A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A_New_O_O_O(self, t.F_pool, s__851000170__1); var tmp2 *jrt.Class; var fncls__1627 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A_fn_class; if fncls__1627 == nil { var fncls__1627d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, fnbody__1628); A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A_fn_class = fncls__1627d; tmp2 = fncls__1627d } else { tmp2 = fncls__1627 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1628, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :294:1
func A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :294:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A) Ctor_O_O_O(c__iter__851000169, c__pool, c__s__851000170 any) { t.F_iter__851000169 = c__iter__851000169; t.F_pool = c__pool; t.F_s__851000170 = c__s__851000170 }
//line :294:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A) Invoke_O__O(self any) any { { var s__851000170__1 any; var t_ any = t.F_s__851000170; t.F_s__851000170 = nil; s__851000170__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1555 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = s__851000170__1; if linked_1556 == nil { temp__1927000414__auto____2 = ifn_1557.Invoke_O__O(arg_1558) } else { temp__1927000414__auto____2 = linked_1556.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1555, arg_1558) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000170__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1559 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = s__851000170__3; if linked_1560 == nil { tmp1 = ifn_1561.Invoke_O__O(arg_1562) } else { tmp1 = linked_1560.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1559, arg_1562) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1563 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = s__851000170__3; if linked_1564 == nil { c__1927001037__auto____4 = ifn_1565.Invoke_O__O(arg_1566) } else { c__1927001037__auto____4 = linked_1564.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1563, arg_1566) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000172__6 any; var root_1567 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1568 == nil { b__851000172__6 = ifn_1569.Invoke_O__O(arg_1570) } else { b__851000172__6 = linked_1568.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1567, arg_1570) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1582 any = A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A_New_O_O_I_O(b__851000172__6, t.F_pool, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1581 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A_fn_class; if fncls__1581 == nil { var fncls__1581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, fnbody__1582); A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A_fn_class = fncls__1581d; tmp3 = fncls__1581d } else { tmp3 = fncls__1581 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1582, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1583 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any; var root_1588 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = b__851000172__6; if linked_1589 == nil { arg_1586 = ifn_1590.Invoke_O__O(arg_1591) } else { arg_1586 = linked_1589.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1588, arg_1591) }; var arg_1587 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000169); var tmp5 any; var root_1592 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = s__851000170__3; if linked_1593 == nil { tmp5 = ifn_1594.Invoke_O__O(arg_1595) } else { tmp5 = linked_1593.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1592, arg_1595) }; arg_1587 = tmp4.Invoke_O__O(tmp5); if linked_1584 == nil { return ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { return linked_1584.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) } } else { var root_1596 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any; var root_1601 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = b__851000172__6; if linked_1602 == nil { arg_1599 = ifn_1603.Invoke_O__O(arg_1604) } else { arg_1599 = linked_1602.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1601, arg_1604) }; var arg_1600 any; if linked_1597 == nil { return ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { return linked_1597.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) } } } else { var f__4 any; var root_1605 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = s__851000170__3; if linked_1606 == nil { f__4 = ifn_1607.Invoke_O__O(arg_1608) } else { f__4 = linked_1606.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1605, arg_1608) }; var h__5 any; var root_1609 any = A_arbace_classes_annot_A_const_147.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, A_arbace_classes_annot_type_annotations_bytes_A_fn_class); var ifn_1611 lang.IFn
																if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = t.F_pool; var arg_1613 any = A_arbace_classes_annot_A_const_148.Invoke_O__O(f__4); if linked_1610 == nil { h__5 = ifn_1611.Invoke_O_O__O(arg_1612, arg_1613) } else { h__5 = linked_1610.(*A_arbace_classes_annot_type_annotations_bytes_A).Invoke_O_O_O__O(root_1609, arg_1612, arg_1613) }
//line :294:1
	if jrt.J2g_Truth(h__5) { var root_1614 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_146, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(f__4), nil, h__5)).Ref(); var arg_1618 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000169); var tmp7 any; var root_1619 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = s__851000170__3; if linked_1620 == nil { tmp7 = ifn_1621.Invoke_O__O(arg_1622) } else { tmp7 = linked_1620.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1619, arg_1622) }; arg_1618 = tmp6.Invoke_O__O(tmp7); if linked_1615 == nil { return ifn_1616.Invoke_O_O__O(arg_1617, arg_1618) } else { return linked_1615.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1614, arg_1617, arg_1618) } } else { var tmp8 any; var root_1623 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = s__851000170__3; if linked_1624 == nil { tmp8 = ifn_1625.Invoke_O__O(arg_1626) } else { tmp8 = linked_1624.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1623, arg_1626) }; s__851000170__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :294:1
func A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :294:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A) Ctor_O_O_I_O(c__b__851000172, c__pool any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000172 = c__b__851000172; t.F_pool = c__pool; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :294:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A) Invoke_O__O(self any) any { { var i__851000171__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000171__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000171__1)); var h__3 any; var root_1571 any = A_arbace_classes_annot_A_const_147.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, A_arbace_classes_annot_type_annotations_bytes_A_fn_class); var ifn_1573 lang.IFn
																		if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = t.F_pool; var arg_1575 any = A_arbace_classes_annot_A_const_148.Invoke_O__O(f__2); if linked_1572 == nil { h__3 = ifn_1573.Invoke_O_O__O(arg_1574, arg_1575) } else { h__3 = linked_1572.(*A_arbace_classes_annot_type_annotations_bytes_A).Invoke_O_O_O__O(root_1571, arg_1574, arg_1575) }
//line :294:1
	if jrt.J2g_Truth(h__3) { var root_1576 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = t.F_b__851000172; var arg_1580 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_146, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(f__2), nil, h__3)).Ref(); if linked_1577 == nil { ifn_1578.Invoke_O_O__O(arg_1579, arg_1580) } else { linked_1577.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1576, arg_1579, arg_1580) }; i__851000171__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000171__1); continue L1 } else { i__851000171__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000171__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A_New() *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A) Ctor() {}
//line :300:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A) Invoke_O_O__O(self, s__851000180__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1715 any = A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A_New_O_O(s__851000180__1, self); var tmp2 *jrt.Class; var fncls__1714 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A_fn_class; if fncls__1714 == nil { var fncls__1714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__1715); A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A_fn_class = fncls__1714d; tmp2 = fncls__1714d } else { tmp2 = fncls__1714 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1715, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :300:1
func A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A{}; t.Ctor_O_O(p0, p1); return t }
//line :300:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A) Ctor_O_O(c__s__851000180, c__iter__851000179 any) { t.F_s__851000180 = c__s__851000180; t.F_iter__851000179 = c__iter__851000179 }
//line :300:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A) Invoke_O__O(self any) any { { var s__851000180__1 any; var t_ any = t.F_s__851000180; t.F_s__851000180 = nil; s__851000180__1 = t_; for { var temp__1927000414__auto____2 any; var root_1640 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = s__851000180__1; if linked_1641 == nil { temp__1927000414__auto____2 = ifn_1642.Invoke_O__O(arg_1643) } else { temp__1927000414__auto____2 = linked_1641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1640, arg_1643) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000180__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1644 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = s__851000180__3; if linked_1645 == nil { tmp1 = ifn_1646.Invoke_O__O(arg_1647) } else { tmp1 = linked_1645.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1644, arg_1647) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1648 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = s__851000180__3; if linked_1649 == nil { c__1927001037__auto____4 = ifn_1650.Invoke_O__O(arg_1651) } else { c__1927001037__auto____4 = linked_1649.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1648, arg_1651) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000182__6 any; var root_1652 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1653 == nil { b__851000182__6 = ifn_1654.Invoke_O__O(arg_1655) } else { b__851000182__6 = linked_1653.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1652, arg_1655) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1670 any = A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A_New_O_I_O(b__851000182__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1669 *jrt.Class = A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A_fn_class; if fncls__1669 == nil { var fncls__1669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, fnbody__1670); A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A_fn_class = fncls__1669d; tmp3 = fncls__1669d } else { tmp3 = fncls__1669 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1670, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1671 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any; var root_1676 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = b__851000182__6; if linked_1677 == nil { arg_1674 = ifn_1678.Invoke_O__O(arg_1679) } else { arg_1674 = linked_1677.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1676, arg_1679) }; var arg_1675 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000179); var tmp5 any; var root_1680 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = s__851000180__3; if linked_1681 == nil { tmp5 = ifn_1682.Invoke_O__O(arg_1683) } else { tmp5 = linked_1681.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1680, arg_1683) }; arg_1675 = tmp4.Invoke_O__O(tmp5); if linked_1672 == nil { return ifn_1673.Invoke_O_O__O(arg_1674, arg_1675) } else { return linked_1672.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1671, arg_1674, arg_1675) } } else { var root_1684 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any; var root_1689 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = b__851000182__6; if linked_1690 == nil { arg_1687 = ifn_1691.Invoke_O__O(arg_1692) } else { arg_1687 = linked_1690.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1689, arg_1692) }; var arg_1688 any; if linked_1685 == nil { return ifn_1686.Invoke_O_O__O(arg_1687, arg_1688) } else { return linked_1685.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1684, arg_1687, arg_1688) } } } else { var vec__851000190__4 any; var root_1693 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = s__851000180__3; if linked_1694 == nil { vec__851000190__4 = ifn_1695.Invoke_O__O(arg_1696) } else { vec__851000190__4 = linked_1694.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1693, arg_1696) }; var tag__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000190__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000190__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1697 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_149, nil, Lit_9, nil); var tmp7 any; var root_1702 any = A_arbace_classes_annot_A_const_151.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1704 lang.IFn
																if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any = tag__5; if linked_1703 == nil { tmp7 = ifn_1704.Invoke_O__O(arg_1705) } else { tmp7 = linked_1703.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1702, arg_1705) }; var tmp8 any = tmp7; var tmp9 any; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_annot_A_const_117, tag__5) { var root_1706 any = A_arbace_classes_annot_A_const_46.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, A_arbace_classes_annot_enc_string_A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = v__6; if linked_1707 == nil { tmp9 = ifn_1708.Invoke_O__O(arg_1709) } else { tmp9 = linked_1707.(*A_arbace_classes_annot_enc_string_A).Invoke_O_O__O(root_1706, arg_1709) } } else { tmp9 = v__6 }; arg_1700 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp9)).Ref()
//line :300:1
	var arg_1701 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__851000179); var tmp11 any; var root_1710 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = s__851000180__3; if linked_1711 == nil { tmp11 = ifn_1712.Invoke_O__O(arg_1713) } else { tmp11 = linked_1711.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1710, arg_1713) }; arg_1701 = tmp10.Invoke_O__O(tmp11); if linked_1698 == nil { return ifn_1699.Invoke_O_O__O(arg_1700, arg_1701) } else { return linked_1698.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1697, arg_1700, arg_1701) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :300:1
func A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :300:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A) Ctor_O_I_O(c__b__851000182 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000182 = c__b__851000182; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :300:1
func (t *A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A) Invoke_O__O(self any) any { { var i__851000181__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000181__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__851000186__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000181__1)); var tag__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000186__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000186__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1656 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = t.F_b__851000182; var arg_1660 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_149, nil, Lit_9, nil); var tmp3 any; var root_1661 any = A_arbace_classes_annot_A_const_151.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1663 lang.IFn
																		if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = tag__3; if linked_1662 == nil { tmp3 = ifn_1663.Invoke_O__O(arg_1664) } else { tmp3 = linked_1662.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1661, arg_1664) }; var tmp4 any = tmp3; var tmp5 any; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_annot_A_const_117, tag__3) { var root_1665 any = A_arbace_classes_annot_A_const_46.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, A_arbace_classes_annot_enc_string_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = v__4; if linked_1666 == nil { tmp5 = ifn_1667.Invoke_O__O(arg_1668) } else { tmp5 = linked_1666.(*A_arbace_classes_annot_enc_string_A).Invoke_O_O__O(root_1665, arg_1668) } } else { tmp5 = v__4 }; arg_1660 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5)).Ref()
//line :300:1
	if linked_1657 == nil { ifn_1658.Invoke_O_O__O(arg_1659, arg_1660) } else { linked_1657.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1656, arg_1659, arg_1660) }; i__851000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000181__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_classes_annot_class_data_A_New() *A_arbace_classes_annot_class_data_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_classes_annot_class_data_A) Ctor() {}
//line :304:1
func (t *A_arbace_classes_annot_class_data_A) DoInvoke_O_O_O__O(self, n__0, p__851000196__1 any) any { var map__851000197__3 any = p__851000196__1; var map__851000197__4 any; if lang.ISeq_InstanceOf(map__851000197__3) { var tmp1 any; var root_1722 any = A_arbace_classes_annot_A_const_123.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1724 lang.IFn; if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = map__851000197__3; if linked_1723 == nil { tmp1 = ifn_1724.Invoke_O__O(arg_1725) } else { tmp1 = linked_1723.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1722, arg_1725) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1726 any = A_arbace_classes_annot_A_const_152.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = map__851000197__3; if linked_1727 == nil { tmp2 = ifn_1728.Invoke_O__O(arg_1729) } else { tmp2 = linked_1727.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1726, arg_1729) }; map__851000197__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1730 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = map__851000197__3; if linked_1731 == nil { tmp3 = ifn_1732.Invoke_O__O(arg_1733) } else { tmp3 = linked_1731.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1730, arg_1733) }; if jrt.J2g_Truth(tmp3) { var root_1734 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = map__851000197__3; if linked_1735 == nil { map__851000197__4 = ifn_1736.Invoke_O__O(arg_1737) } else { map__851000197__4 = linked_1735.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1734, arg_1737) } } else { map__851000197__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__851000197__4 = map__851000197__3 }; var members__5 any = lang.RT_Get_O_O__O_NoInit(map__851000197__4, A_arbace_classes_annot_A_const_153); var throws__6 any = lang.RT_Get_O_O__O_NoInit(map__851000197__4, A_arbace_classes_annot_A_const_102); var temp__1927000414__auto____7 any; var root_1738 any = A_arbace_classes_annot_A_const_68.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1740 lang.IFn; if






	linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = n__0; if linked_1739 == nil { temp__1927000414__auto____7 = ifn_1740.Invoke_O__O(arg_1741) } else { temp__1927000414__auto____7 = linked_1739.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1738, arg_1741) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var d__8 any = temp__1927000414__auto____7
		if jrt.J2g_Truth(A_arbace_classes_annot_A_const_64.GetRawRoot__O()) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_65.GetRawRoot__O()); var tmp5 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_annot_A_const_64.GetRawRoot__O(), jrt.Boolean_TRUE.Ref())); var tmp6 *lang.Compiler_AOTFn; var fnbody__2442 any = A_arbace_classes_annot_class_data_fn__851000199_A_New_O_O_O_O(throws__6, n__0, members__5, d__8); var tmp7 *jrt.Class; var fncls__2441 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_A_fn_class; if fncls__2441 == nil { var fncls__2441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__2442); A_arbace_classes_annot_class_data_fn__851000199_A_fn_class = fncls__2441d; tmp7 = fncls__2441d } else { tmp7 = fncls__2441 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2442, tmp7, nil); return tmp4.Invoke_O_O__O(tmp5, tmp6.Ref()) } else { var lines__9 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp9 *lang.Compiler_AOTFn; var fnbody__2463 any = A_arbace_classes_annot_class_data_fn__851000306_A_New_O_O_O(n__0, members__5, d__8); var tmp10 *jrt.Class
			var fncls__2462 /*line :312:1*/*jrt.Class = A_arbace_classes_annot_class_data_fn__851000306_A_fn_class

			if fncls__2462 == nil { var fncls__2462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__2463); A_arbace_classes_annot_class_data_fn__851000306_A_fn_class = fncls__2462d; tmp10 = fncls__2462d } else { tmp10 = fncls__2462 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2463, tmp10, nil)
//line :313:1
			var tmp11 any = Up_Compiler_AOTFn_IFn(tmp9).Invoke__O(); var tmp12 any; var tmp13 any
			var and__1927000168__auto____9 any = throws__6
			if jrt.J2g_Truth(and__1927000168__auto____9) { var root_2464 any = A_arbace_classes_annot_A_const_155.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2464, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2466 lang.IFn; if linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any = members__5; if linked_2465 == nil { tmp13 = ifn_2466.Invoke_O__O(arg_2467) } else { tmp13 = linked_2465.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2464, arg_2467) } } else { tmp13 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp13) {
				var tmp14 *lang.Compiler_AOTFn; var fnbody__2478 any = A_arbace_classes_annot_class_data_fn__851000308_A_New_O_O(n__0, d__8); var tmp15 *jrt.Class; var fncls__2477 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000308_A_fn_class; if fncls__2477 == nil { var fncls__2477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__2478); A_arbace_classes_annot_class_data_fn__851000308_A_fn_class = fncls__2477d; tmp15 = fncls__2477d } else { tmp15 = fncls__2477 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2478, tmp15, nil); tmp12 = Up_Compiler_AOTFn_IFn(tmp14).Invoke__O() } else {
//line :315:1
					tmp12 = nil }
//line :313:1
			var tmp16 any = tmp12; var tmp17 *lang.Compiler_AOTFn; var fnbody__2490 any = A_arbace_classes_annot_class_data_fn__851000310_A_New_O_O_O(n__0, members__5, d__8); var tmp18 *jrt.Class
			var fncls__2489 /*line :313:1*/*jrt.Class = A_arbace_classes_annot_class_data_fn__851000310_A_fn_class



			if fncls__2489 == nil { var fncls__2489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__2490); A_arbace_classes_annot_class_data_fn__851000310_A_fn_class = fncls__2489d; tmp18 = fncls__2489d } else { tmp18 = fncls__2489 }; tmp17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2490, tmp18, nil)
//line :313:1
			var tmp19 any = Up_Compiler_AOTFn_IFn(tmp17).Invoke__O(); var tmp20 any; var iter__1927001039__auto____9 any; var fnbody__2552 any = A_arbace_classes_annot_class_data_iter__851000312__851000316_A_New(); var tmp21 *jrt.Class
			var fncls__2551 /*line :313:1*/*jrt.Class = A_arbace_classes_annot_class_data_iter__851000312__851000316_A_fn_class




			if fncls__2551 == nil { var fncls__2551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_classes_annot_class_data_iter__851000312__851000316_A_fn_class = fncls__2551d; tmp21 = fncls__2551d } else { tmp21 = fncls__2551 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2552, tmp21, nil); var tmp22 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp23 any; var root_2553 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_2554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2553, A_arbace_classes_annot_visible_A_fn_class); var ifn_2555 lang.IFn; if linked_2554 == nil { ifn_2555 = lang.IFn_Cast(root_2553) } else { ifn_2555 = nil }; var arg_2556 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(d__8); if linked_2554 == nil { tmp23 = ifn_2555.Invoke_O__O(arg_2556) } else { tmp23 = linked_2554.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_2553, arg_2556) }; tmp20 = tmp22.Invoke_O__O(tmp23)
//line :313:1
			var tmp24 any = tmp20; var tmp25 any
			var tmp26 any = A_arbace_classes_annot_A_const_37




			if lang.Util_Equiv_O_O__Z_NoInit(tmp26, A_arbace_classes_annot_A_const_79.Invoke_O__O(d__8)) { var iter__1927001039__auto____9_2 any; var fnbody__2646 any = A_arbace_classes_annot_class_data_iter__851000322__851000326_A_New(); var tmp27 *jrt.Class; var fncls__2645 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000322__851000326_A_fn_class
				if fncls__2645 == nil { var fncls__2645d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_classes_annot_class_data_iter__851000322__851000326_A_fn_class = fncls__2645d; tmp27 = fncls__2645d } else { tmp27 = fncls__2645 }; iter__1927001039__auto____9_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2646, tmp27, nil); tmp25 = lang.IFn_Cast(iter__1927001039__auto____9_2).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(d__8)) } else {
//line :319:1
					tmp25 = nil }
//line :313:1
			var tmp28 any = tmp25; var tmp29 any











			if jrt.J2g_Truth(members__5) {
				var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp31 any; var iter__1927001039__auto____9_3 any; var fnbody__2769 any = A_arbace_classes_annot_class_data_iter__851000336__851000342_A_New_O(n__0); var tmp32 *jrt.Class; var fncls__2768 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000336__851000342_A_fn_class
				if fncls__2768 == nil { var fncls__2768d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__2769); A_arbace_classes_annot_class_data_iter__851000336__851000342_A_fn_class = fncls__2768d; tmp32 = fncls__2768d } else { tmp32 = fncls__2768 }; iter__1927001039__auto____9_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2769, tmp32, nil); tmp31 = lang.IFn_Cast(iter__1927001039__auto____9_3).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(d__8))
//line :326:1
				var tmp33 any = tmp31; var tmp34 any; var iter__1927001039__auto____9_4 any; var fnbody__2932 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_A_New_O(n__0); var tmp35 *jrt.Class
				var fncls__2931 /*line :326:1*/*jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_A_fn_class









				if fncls__2931 == nil { var fncls__2931d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__2932); A_arbace_classes_annot_class_data_iter__851000352__851000360_A_fn_class = fncls__2931d; tmp35 = fncls__2931d } else { tmp35 = fncls__2931 }; iter__1927001039__auto____9_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2932, tmp35, nil); tmp34 = lang.IFn_Cast(iter__1927001039__auto____9_4).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(d__8))
//line :326:1
				var tmp36 any = tmp34; var tmp37 any; var iter__1927001039__auto____9_5 any; var fnbody__3027 any = A_arbace_classes_annot_class_data_iter__851000379__851000385_A_New(); var tmp38 *jrt.Class
				var fncls__3026 /*line :326:1*/*jrt.Class = A_arbace_classes_annot_class_data_iter__851000379__851000385_A_fn_class



















				if fncls__3026 == nil { var fncls__3026d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_classes_annot_class_data_iter__851000379__851000385_A_fn_class = fncls__3026d; tmp38 = fncls__3026d } else { tmp38 = fncls__3026 }; iter__1927001039__auto____9_5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3027, tmp38, nil); tmp37 = lang.IFn_Cast(iter__1927001039__auto____9_5).Invoke_O__O(A_arbace_classes_annot_A_const_99.Invoke_O__O(d__8))
//line :326:1
				var tmp39 any = tmp37; var tmp40 any
				var tmp41 any = A_arbace_classes_annot_A_const_93























				if lang.Util_Equiv_O_O__Z_NoInit(tmp41, A_arbace_classes_annot_A_const_79.Invoke_O__O(d__8)) { var iter__1927001039__auto____9_6 any; var fnbody__3127 any = A_arbace_classes_annot_class_data_iter__851000395__851000401_A_New(); var tmp42 *jrt.Class; var fncls__3126 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000395__851000401_A_fn_class
					if fncls__3126 == nil { var fncls__3126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_classes_annot_class_data_iter__851000395__851000401_A_fn_class = fncls__3126d; tmp42 = fncls__3126d } else { tmp42 = fncls__3126 }; iter__1927001039__auto____9_6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3127, tmp42, nil); tmp40 = lang.IFn_Cast(iter__1927001039__auto____9_6).Invoke_O__O(A_arbace_classes_annot_A_const_95.Invoke_O__O(d__8)) } else {
//line :351:1
						tmp40 = nil }
//line :326:1
				tmp29 = tmp30.Invoke_O_O_O_O__O(tmp33, tmp36, tmp39, tmp40) } else {
//line :325:1
					tmp29 = nil }
//line :313:1
			lines__9 = tmp8.Invoke_O_O_O_O_O_O__O(tmp11, tmp16, tmp19, tmp24, tmp28, tmp29)









































			var tmp43 any; var root_3128 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_3129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3128, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3130 lang.IFn; if linked_3129 == nil { ifn_3130 = lang.IFn_Cast(root_3128) } else { ifn_3130 = nil }; var arg_3131 any = lines__9; if linked_3129 == nil { tmp43 = ifn_3130.Invoke_O__O(arg_3131) } else { tmp43 = linked_3129.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3128, arg_3131) }; if jrt.J2g_Truth(tmp43) {
				var root_3132 any = A_arbace_classes_annot_A_const_167.GetRawRoot__O(); var linked_3133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3132, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3134 lang.IFn; if linked_3133 == nil { ifn_3134 = lang.IFn_Cast(root_3132) } else { ifn_3134 = nil }; var arg_3135 any = Lit_35; var arg_3136 any = lines__9; if linked_3133 == nil { return ifn_3134.Invoke_O_O__O(arg_3135, arg_3136) } else { return linked_3133.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3132, arg_3135, arg_3136) } } else {
//line :355:1
					return nil } } } else {
//line :311:1
						return nil } }
func A_arbace_classes_annot_class_data_fn__851000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_annot_class_data_fn__851000199_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :312:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_A) Ctor_O_O_O_O(c__throws, c__n, c__members, c__d any) { t.F_throws = c__throws; t.F_n = c__n; t.F_members = c__members; t.F_d = c__d }
//line :312:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_A) Invoke_O__O(self any) any { var lines__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__1767 any = A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A_New_O_O_O(t.F_n, t.F_members, t.F_d); var tmp3 *jrt.Class; var fncls__1766 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A_fn_class; if

	fncls__1766 == nil { var fncls__1766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__1767); A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A_fn_class = fncls__1766d; tmp3 = fncls__1766d } else { tmp3 = fncls__1766 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1767, tmp3, nil); var tmp4 any = /*line :313:1*/Up_Compiler_AOTFn_IFn(tmp2).Invoke__O(); var tmp5 any; var tmp6 any; var and__1927000168__auto____1 any = t.F_throws; if

	jrt.J2g_Truth(and__1927000168__auto____1) { var root_1768 any = A_arbace_classes_annot_A_const_155.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = t.F_members; if linked_1769 == nil { tmp6 = ifn_1770.Invoke_O__O(arg_1771) } else { tmp6 = linked_1769.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1768, arg_1771) } } else { tmp6 = and__1927000168__auto____1 }; if jrt.J2g_Truth(tmp6) {
		var tmp7 *lang.Compiler_AOTFn; var fnbody__1782 any = A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A_New_O_O(t.F_n, t.F_d); var tmp8 *jrt.Class; var fncls__1781 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A_fn_class; if fncls__1781 == nil { var fncls__1781d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__1782); A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A_fn_class = fncls__1781d; tmp8 = fncls__1781d } else { tmp8 = fncls__1781 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1782, tmp8, nil); tmp5 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O() } else {
//line :315:1
			tmp5 = nil }; var tmp9 any = tmp5; var tmp10 /*line :313:1*/*lang.Compiler_AOTFn; var fnbody__1794 any = A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A_New_O_O_O(t.F_n, t.F_members, t.F_d); var tmp11 *jrt.Class; var fncls__1793 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A_fn_class; if



	fncls__1793 == nil { var fncls__1793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__1794); A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A_fn_class = fncls__1793d; tmp11 = fncls__1793d } else { tmp11 = fncls__1793 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1794, tmp11, nil); var tmp12 any = /*line :313:1*/Up_Compiler_AOTFn_IFn(tmp10).Invoke__O(); var tmp13 any; var iter__1927001039__auto____1 any; var fnbody__1856 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A_New(); var tmp14 *jrt.Class; var fncls__1855 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A_fn_class; if




	fncls__1855 == nil { var fncls__1855d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A_fn_class = fncls__1855d; tmp14 = fncls__1855d } else { tmp14 = fncls__1855 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1856, tmp14, nil); var tmp15 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp16 any; var root_1857 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, A_arbace_classes_annot_visible_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(t.F_d); if linked_1858 == nil { tmp16 = ifn_1859.Invoke_O__O(arg_1860) } else { tmp16 = linked_1858.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_1857, arg_1860) }; tmp13 = tmp15.Invoke_O__O(tmp16); var tmp17 any = tmp13; var tmp18 any; var tmp19 any = A_arbace_classes_annot_A_const_37; if
	lang.Util_Equiv_O_O__Z_NoInit(tmp19, A_arbace_classes_annot_A_const_79.Invoke_O__O(t.F_d)) { var iter__1927001039__auto____1_2 any; var fnbody__1950 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A_New(); var tmp20 *jrt.Class; var fncls__1949 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A_fn_class
		if fncls__1949 == nil { var fncls__1949d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A_fn_class = fncls__1949d; tmp20 = fncls__1949d } else { tmp20 = fncls__1949 }; iter__1927001039__auto____1_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1950, tmp20, nil); tmp18 = lang.IFn_Cast(iter__1927001039__auto____1_2).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(t.F_d)) } else {
//line :319:1
			tmp18 = nil }; var tmp21 any = tmp18; var tmp22 any; if





	jrt.J2g_Truth(t.F_members) {
		var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_12.GetRawRoot__O()); var tmp24 any; var iter__1927001039__auto____1_3 any; var fnbody__2073 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A_New_O(t.F_n); var tmp25 *jrt.Class; var fncls__2072 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A_fn_class
		if fncls__2072 == nil { var fncls__2072d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__2073); A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A_fn_class = fncls__2072d; tmp25 = fncls__2072d } else { tmp25 = fncls__2072 }; iter__1927001039__auto____1_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2073, tmp25, nil); tmp24 = lang.IFn_Cast(iter__1927001039__auto____1_3).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(t.F_d))
//line :326:1
		var tmp26 any = tmp24; var tmp27 any; var iter__1927001039__auto____1_4 any; var fnbody__2236 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A_New_O(t.F_n); var tmp28 *jrt.Class
		var fncls__2235 /*line :326:1*/*jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A_fn_class









		if fncls__2235 == nil { var fncls__2235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__2236); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A_fn_class = fncls__2235d; tmp28 = fncls__2235d } else { tmp28 = fncls__2235 }; iter__1927001039__auto____1_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2236, tmp28, nil); tmp27 = lang.IFn_Cast(iter__1927001039__auto____1_4).Invoke_O__O(A_arbace_classes_annot_A_const_98.Invoke_O__O(t.F_d))
//line :326:1
		var tmp29 any = tmp27; var tmp30 any; var iter__1927001039__auto____1_5 any; var fnbody__2331 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A_New(); var tmp31 *jrt.Class
		var fncls__2330 /*line :326:1*/*jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A_fn_class



















		if fncls__2330 == nil { var fncls__2330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A_fn_class = fncls__2330d; tmp31 = fncls__2330d } else { tmp31 = fncls__2330 }; iter__1927001039__auto____1_5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2331, tmp31, nil); tmp30 = lang.IFn_Cast(iter__1927001039__auto____1_5).Invoke_O__O(A_arbace_classes_annot_A_const_99.Invoke_O__O(t.F_d))
//line :326:1
		var tmp32 any = tmp30; var tmp33 any
		var tmp34 any = A_arbace_classes_annot_A_const_93























		if lang.Util_Equiv_O_O__Z_NoInit(tmp34, A_arbace_classes_annot_A_const_79.Invoke_O__O(t.F_d)) { var iter__1927001039__auto____1_6 any; var fnbody__2431 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A_New(); var tmp35 *jrt.Class; var fncls__2430 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A_fn_class
			if fncls__2430 == nil { var fncls__2430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A_fn_class = fncls__2430d; tmp35 = fncls__2430d } else { tmp35 = fncls__2430 }; iter__1927001039__auto____1_6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2431, tmp35, nil); tmp33 = lang.IFn_Cast(iter__1927001039__auto____1_6).Invoke_O__O(A_arbace_classes_annot_A_const_95.Invoke_O__O(t.F_d)) } else {
//line :351:1
				tmp33 = nil }
//line :326:1
		tmp22 = tmp23.Invoke_O_O_O_O__O(tmp26, tmp29, tmp32, tmp33) } else {
//line :325:1
			tmp22 = nil }; lines__1 = /*line :313:1*/tmp1.Invoke_O_O_O_O_O_O__O(tmp4, tmp9, tmp12, tmp17, tmp21, tmp22); var tmp36 any; var root_2432 any =









































	A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2432, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2434 lang.IFn; if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var arg_2435 any = lines__1; if linked_2433 == nil { tmp36 = ifn_2434.Invoke_O__O(arg_2435) } else { tmp36 = linked_2433.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2432, arg_2435) }; if jrt.J2g_Truth(tmp36) {
		var root_2436 any = A_arbace_classes_annot_A_const_167.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2438 lang.IFn; if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = Lit_35; var arg_2440 any = lines__1; if linked_2437 == nil { return ifn_2438.Invoke_O_O__O(arg_2439, arg_2440) } else { return linked_2437.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2436, arg_2439, arg_2440) } } else {
//line :355:1
			return nil } }
//line :314:1
func A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :314:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A) Ctor_O_O_O(c__n, c__members, c__d any) { t.F_n = c__n; t.F_members = c__members; t.F_d = c__d }
//line :314:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1756 any = A_arbace_classes_annot_A_const_146.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any; var root_1760 any = A_arbace_classes_annot_A_const_154.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, A_arbace_classes_annot_attribute_lines_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any; var t_ any = t.F_n; t.F_n = nil; arg_1763 = t_; var arg_1764 any; var t__2 any = t.F_d; t.F_d = nil; arg_1764 = t__2; var arg_1765 any; var t__3 any = t.F_members; t.F_members = nil; arg_1765 = t__3; if linked_1761 == nil { arg_1759 = ifn_1762.Invoke_O_O_O__O(arg_1763, arg_1764, arg_1765) } else { arg_1759 = linked_1761.(*A_arbace_classes_annot_attribute_lines_A).Invoke_O_O_O_O__O(root_1760, arg_1763, arg_1764, arg_1765) }; if linked_1757 == nil { tmp1 = ifn_1758.Invoke_O__O(arg_1759) } else { tmp1 = linked_1757.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1756, arg_1759) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :314:1
func A_arbace_classes_annot_class_data_fn__851000306_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000306_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000306_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :314:1
func (t *A_arbace_classes_annot_class_data_fn__851000306_A) Ctor_O_O_O(c__n, c__members, c__d any) { t.F_n = c__n; t.F_members = c__members; t.F_d = c__d }
//line :314:1
func (t *A_arbace_classes_annot_class_data_fn__851000306_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2452 any = A_arbace_classes_annot_A_const_146.GetRawRoot__O(); var linked_2453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2452, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2454 lang.IFn; if linked_2453 == nil { ifn_2454 = lang.IFn_Cast(root_2452) } else { ifn_2454 = nil }; var arg_2455 any; var root_2456 any = A_arbace_classes_annot_A_const_154.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2456, A_arbace_classes_annot_attribute_lines_A_fn_class); var ifn_2458 lang.IFn; if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any; var t_ any = t.F_n; t.F_n = nil; arg_2459 = t_; var arg_2460 any; var t__2 any = t.F_d; t.F_d = nil; arg_2460 = t__2; var arg_2461 any; var t__3 any = t.F_members; t.F_members = nil; arg_2461 = t__3; if linked_2457 == nil { arg_2455 = ifn_2458.Invoke_O_O_O__O(arg_2459, arg_2460, arg_2461) } else { arg_2455 = linked_2457.(*A_arbace_classes_annot_attribute_lines_A).Invoke_O_O_O_O__O(root_2456, arg_2459, arg_2460, arg_2461) }; if linked_2453 == nil { tmp1 = ifn_2454.Invoke_O__O(arg_2455) } else { tmp1 = linked_2453.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2452, arg_2455) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }

func A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A{}; t.Ctor_O_O(p0, p1); return t }
//line :316:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A) Ctor_O_O(c__n, c__d any) { t.F_n = c__n; t.F_d = c__d }
//line :316:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1772 any = A_arbace_classes_annot_A_const_146.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1774 lang.IFn; if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any; var root_1776 any = A_arbace_classes_annot_A_const_100.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, A_arbace_classes_annot_throws_lines_A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any; var t_ any = t.F_n; t.F_n = nil; arg_1779 = t_; var arg_1780 any; var t__2 any = t.F_d; t.F_d = nil; arg_1780 = t__2; if linked_1777 == nil { arg_1775 = ifn_1778.Invoke_O_O__O(arg_1779, arg_1780) } else { arg_1775 = linked_1777.(*A_arbace_classes_annot_throws_lines_A).Invoke_O_O_O__O(root_1776, arg_1779, arg_1780) }; if linked_1773 == nil { tmp1 = ifn_1774.Invoke_O__O(arg_1775) } else { tmp1 = linked_1773.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1772, arg_1775) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :316:1
func A_arbace_classes_annot_class_data_fn__851000308_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_fn__851000308_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000308_A{}; t.Ctor_O_O(p0, p1); return t }
//line :316:1
func (t *A_arbace_classes_annot_class_data_fn__851000308_A) Ctor_O_O(c__n, c__d any) { t.F_n = c__n; t.F_d = c__d }
//line :316:1
func (t *A_arbace_classes_annot_class_data_fn__851000308_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2468 any = A_arbace_classes_annot_A_const_146.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2470 lang.IFn; if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any; var root_2472 any = A_arbace_classes_annot_A_const_100.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, A_arbace_classes_annot_throws_lines_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any; var t_ any = t.F_n; t.F_n = nil; arg_2475 = t_; var arg_2476 any; var t__2 any = t.F_d; t.F_d = nil; arg_2476 = t__2; if linked_2473 == nil { arg_2471 = ifn_2474.Invoke_O_O__O(arg_2475, arg_2476) } else { arg_2471 = linked_2473.(*A_arbace_classes_annot_throws_lines_A).Invoke_O_O_O__O(root_2472, arg_2475, arg_2476) }; if linked_2469 == nil { tmp1 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp1 = linked_2469.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2468, arg_2471) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
func A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :317:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A) Ctor_O_O_O(c__n, c__members, c__d any) { t.F_n = c__n; t.F_members = c__members; t.F_d = c__d }
//line :317:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1783 any = A_arbace_classes_annot_A_const_146.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any; var root_1787 any = A_arbace_classes_annot_A_const_156.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, A_arbace_classes_annot_type_annotation_lines_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any; var t_ any = t.F_n; t.F_n = nil; arg_1790 = t_; var arg_1791 any; var t__2 any = t.F_d; t.F_d = nil; arg_1791 = t__2; var arg_1792 any; var t__3 any = t.F_members; t.F_members = nil; arg_1792 = t__3; if linked_1788 == nil { arg_1786 = ifn_1789.Invoke_O_O_O__O(arg_1790, arg_1791, arg_1792) } else { arg_1786 = linked_1788.(*A_arbace_classes_annot_type_annotation_lines_A).Invoke_O_O_O_O__O(root_1787, arg_1790, arg_1791, arg_1792) }; if linked_1784 == nil { tmp1 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp1 = linked_1784.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1783, arg_1786) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :317:1
func A_arbace_classes_annot_class_data_fn__851000310_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000310_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000310_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :317:1
func (t *A_arbace_classes_annot_class_data_fn__851000310_A) Ctor_O_O_O(c__n, c__members, c__d any) { t.F_n = c__n; t.F_members = c__members; t.F_d = c__d }
//line :317:1
func (t *A_arbace_classes_annot_class_data_fn__851000310_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2479 any = A_arbace_classes_annot_A_const_146.GetRawRoot__O(); var linked_2480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2479, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2481 lang.IFn; if linked_2480 == nil { ifn_2481 = lang.IFn_Cast(root_2479) } else { ifn_2481 = nil }; var arg_2482 any; var root_2483 any = A_arbace_classes_annot_A_const_156.GetRawRoot__O(); var linked_2484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2483, A_arbace_classes_annot_type_annotation_lines_A_fn_class); var ifn_2485 lang.IFn; if linked_2484 == nil { ifn_2485 = lang.IFn_Cast(root_2483) } else { ifn_2485 = nil }; var arg_2486 any; var t_ any = t.F_n; t.F_n = nil; arg_2486 = t_; var arg_2487 any; var t__2 any = t.F_d; t.F_d = nil; arg_2487 = t__2; var arg_2488 any; var t__3 any = t.F_members; t.F_members = nil; arg_2488 = t__3; if linked_2484 == nil { arg_2482 = ifn_2485.Invoke_O_O_O__O(arg_2486, arg_2487, arg_2488) } else { arg_2482 = linked_2484.(*A_arbace_classes_annot_type_annotation_lines_A).Invoke_O_O_O_O__O(root_2483, arg_2486, arg_2487, arg_2488) }; if linked_2480 == nil { tmp1 = ifn_2481.Invoke_O__O(arg_2482) } else { tmp1 = linked_2480.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2479, arg_2482) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A_New() *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A) Ctor() {}
//line :318:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A) Invoke_O_O__O(self, s__851000207__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1854 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A_New_O_O(self, s__851000207__1); var tmp2 *jrt.Class; var fncls__1853 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A_fn_class; if fncls__1853 == nil { var fncls__1853d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__1854); A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A_fn_class = fncls__1853d; tmp2 = fncls__1853d } else { tmp2 = fncls__1853 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1854, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :318:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A{}; t.Ctor_O_O(p0, p1); return t }
//line :318:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A) Ctor_O_O(c__iter__851000206, c__s__851000207 any) { t.F_iter__851000206 = c__iter__851000206; t.F_s__851000207 = c__s__851000207 }
//line :318:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A) Invoke_O__O(self any) any { { var s__851000207__1 any; var t_ any = t.F_s__851000207; t.F_s__851000207 = nil; s__851000207__1 = t_; for { var temp__1927000414__auto____2 any; var root_1795 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = s__851000207__1; if linked_1796 == nil { temp__1927000414__auto____2 = ifn_1797.Invoke_O__O(arg_1798) } else { temp__1927000414__auto____2 = linked_1796.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1795, arg_1798) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000207__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1799 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = s__851000207__3; if linked_1800 == nil { tmp1 = ifn_1801.Invoke_O__O(arg_1802) } else { tmp1 = linked_1800.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1799, arg_1802) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1803 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = s__851000207__3; if linked_1804 == nil { c__1927001037__auto____4 = ifn_1805.Invoke_O__O(arg_1806) } else { c__1927001037__auto____4 = linked_1804.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1803, arg_1806) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000209__6 any; var root_1807 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1808 == nil { b__851000209__6 = ifn_1809.Invoke_O__O(arg_1810) } else { b__851000209__6 = linked_1808.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1807, arg_1810) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1817 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A_New_O_I_O(b__851000209__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1816 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A_fn_class; if fncls__1816 == nil { var fncls__1816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1817); A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A_fn_class = fncls__1816d; tmp3 = fncls__1816d } else { tmp3 = fncls__1816 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1817, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1818 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any; var root_1823 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = b__851000209__6; if linked_1824 == nil { arg_1821 = ifn_1825.Invoke_O__O(arg_1826) } else { arg_1821 = linked_1824.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1823, arg_1826) }; var arg_1822 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000206); var tmp5 any; var root_1827 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = s__851000207__3; if linked_1828 == nil { tmp5 = ifn_1829.Invoke_O__O(arg_1830) } else { tmp5 = linked_1828.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1827, arg_1830) }; arg_1822 = tmp4.Invoke_O__O(tmp5); if linked_1819 == nil { return ifn_1820.Invoke_O_O__O(arg_1821, arg_1822) } else { return linked_1819.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1818, arg_1821, arg_1822) } } else { var root_1831 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1833 lang.IFn; if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any; var root_1836 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = b__851000209__6; if linked_1837 == nil { arg_1834 = ifn_1838.Invoke_O__O(arg_1839) } else { arg_1834 = linked_1837.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1836, arg_1839) }; var arg_1835 any; if linked_1832 == nil { return ifn_1833.Invoke_O_O__O(arg_1834, arg_1835) } else { return linked_1832.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1831, arg_1834, arg_1835) } } } else { var x__4 any; var root_1840 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = s__851000207__3; if linked_1841 == nil { x__4 = ifn_1842.Invoke_O__O(arg_1843) } else { x__4 = linked_1841.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1840, arg_1843) }; var root_1844 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, x__4)).Ref(); var arg_1848 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000206); var tmp7 any; var root_1849 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = s__851000207__3; if linked_1850 == nil { tmp7 = ifn_1851.Invoke_O__O(arg_1852) } else { tmp7 = linked_1850.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1849, arg_1852) }; arg_1848 = tmp6.Invoke_O__O(tmp7); if linked_1845 == nil { return ifn_1846.Invoke_O_O__O(arg_1847, arg_1848) } else { return linked_1845.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1844, arg_1847, arg_1848) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :318:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :318:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A) Ctor_O_I_O(c__b__851000209 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000209 = c__b__851000209; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :318:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A) Invoke_O__O(self any) any { { var i__851000208__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000208__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000208__1)); var root_1811 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = t.F_b__851000209; var arg_1815 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, x__2)).Ref(); if linked_1812 == nil { ifn_1813.Invoke_O_O__O(arg_1814, arg_1815) } else { linked_1812.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1811, arg_1814, arg_1815) }; i__851000208__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000208__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :318:1
func A_arbace_classes_annot_class_data_iter__851000312__851000316_A_New() *A_arbace_classes_annot_class_data_iter__851000312__851000316_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000312__851000316_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_classes_annot_class_data_iter__851000312__851000316_A) Ctor() {}
//line :318:1
func (t *A_arbace_classes_annot_class_data_iter__851000312__851000316_A) Invoke_O_O__O(self, s__851000313__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2550 any = A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A_New_O_O(self, s__851000313__1); var tmp2 *jrt.Class; var fncls__2549 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A_fn_class; if fncls__2549 == nil { var fncls__2549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__2550); A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A_fn_class = fncls__2549d; tmp2 = fncls__2549d } else { tmp2 = fncls__2549 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2550, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :318:1
func A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A{}; t.Ctor_O_O(p0, p1); return t }
//line :318:1
func (t *A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A) Ctor_O_O(c__iter__851000312, c__s__851000313 any) { t.F_iter__851000312 = c__iter__851000312; t.F_s__851000313 = c__s__851000313 }
//line :318:1
func (t *A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A) Invoke_O__O(self any) any { { var s__851000313__1 any; var t_ any = t.F_s__851000313; t.F_s__851000313 = nil; s__851000313__1 = t_; for { var temp__1927000414__auto____2 any; var root_2491 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2493 lang.IFn; if linked_2492 == nil { ifn_2493 = lang.IFn_Cast(root_2491) } else { ifn_2493 = nil }; var arg_2494 any = s__851000313__1; if linked_2492 == nil { temp__1927000414__auto____2 = ifn_2493.Invoke_O__O(arg_2494) } else { temp__1927000414__auto____2 = linked_2492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2491, arg_2494) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000313__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2495 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2495, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2497 lang.IFn; if linked_2496 == nil { ifn_2497 = lang.IFn_Cast(root_2495) } else { ifn_2497 = nil }; var arg_2498 any = s__851000313__3; if linked_2496 == nil { tmp1 = ifn_2497.Invoke_O__O(arg_2498) } else { tmp1 = linked_2496.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2495, arg_2498) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2499 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any = s__851000313__3; if linked_2500 == nil { c__1927001037__auto____4 = ifn_2501.Invoke_O__O(arg_2502) } else { c__1927001037__auto____4 = linked_2500.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2499, arg_2502) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000315__6 any; var root_2503 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2504 == nil { b__851000315__6 = ifn_2505.Invoke_O__O(arg_2506) } else { b__851000315__6 = linked_2504.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2503, arg_2506) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2513 any = A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A_New_O_I_O(b__851000315__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2512 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A_fn_class; if fncls__2512 == nil { var fncls__2512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__2513); A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A_fn_class = fncls__2512d; tmp3 = fncls__2512d } else { tmp3 = fncls__2512 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2513, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2514 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any; var root_2519 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = b__851000315__6; if linked_2520 == nil { arg_2517 = ifn_2521.Invoke_O__O(arg_2522) } else { arg_2517 = linked_2520.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2519, arg_2522) }; var arg_2518 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000312); var tmp5 any; var root_2523 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = s__851000313__3; if linked_2524 == nil { tmp5 = ifn_2525.Invoke_O__O(arg_2526) } else { tmp5 = linked_2524.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2523, arg_2526) }; arg_2518 = tmp4.Invoke_O__O(tmp5); if linked_2515 == nil { return ifn_2516.Invoke_O_O__O(arg_2517, arg_2518) } else { return linked_2515.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2514, arg_2517, arg_2518) } } else { var root_2527 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any; var root_2532 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2532, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any = b__851000315__6; if linked_2533 == nil { arg_2530 = ifn_2534.Invoke_O__O(arg_2535) } else { arg_2530 = linked_2533.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2532, arg_2535) }; var arg_2531 any; if linked_2528 == nil { return ifn_2529.Invoke_O_O__O(arg_2530, arg_2531) } else { return linked_2528.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2527, arg_2530, arg_2531) } } } else { var x__4 any; var root_2536 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = s__851000313__3; if linked_2537 == nil { x__4 = ifn_2538.Invoke_O__O(arg_2539) } else { x__4 = linked_2537.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2536, arg_2539) }; var root_2540 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, x__4)).Ref(); var arg_2544 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000312); var tmp7 any; var root_2545 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any = s__851000313__3; if linked_2546 == nil { tmp7 = ifn_2547.Invoke_O__O(arg_2548) } else { tmp7 = linked_2546.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2545, arg_2548) }; arg_2544 = tmp6.Invoke_O__O(tmp7); if linked_2541 == nil { return ifn_2542.Invoke_O_O__O(arg_2543, arg_2544) } else { return linked_2541.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2540, arg_2543, arg_2544) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :318:1
func A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :318:1
func (t *A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A) Ctor_O_I_O(c__b__851000315 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000315 = c__b__851000315; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :318:1
func (t *A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A) Invoke_O__O(self any) any { { var i__851000314__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000314__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000314__1)); var root_2507 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any = t.F_b__851000315; var arg_2511 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, x__2)).Ref(); if linked_2508 == nil { ifn_2509.Invoke_O_O__O(arg_2510, arg_2511) } else { linked_2508.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2507, arg_2510, arg_2511) }; i__851000314__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000314__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A_New() *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A) Ctor() {}
//line :320:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A) Invoke_O_O__O(self, s__851000217__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1948 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A_New_O_O(self, s__851000217__1); var tmp2 *jrt.Class; var fncls__1947 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A_fn_class; if fncls__1947 == nil { var fncls__1947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1948); A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A_fn_class = fncls__1947d; tmp2 = fncls__1947d } else { tmp2 = fncls__1947 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1948, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :320:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A{}; t.Ctor_O_O(p0, p1); return t }
//line :320:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A) Ctor_O_O(c__iter__851000216, c__s__851000217 any) { t.F_iter__851000216 = c__iter__851000216; t.F_s__851000217 = c__s__851000217 }
//line :320:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A) Invoke_O__O(self any) any { { var s__851000217__1 any; var t_ any = t.F_s__851000217; t.F_s__851000217 = nil; s__851000217__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1861 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = s__851000217__1; if linked_1862 == nil { temp__1927000414__auto____2 = ifn_1863.Invoke_O__O(arg_1864) } else { temp__1927000414__auto____2 = linked_1862.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1861, arg_1864) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000217__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1865 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = s__851000217__3; if linked_1866 == nil { tmp1 = ifn_1867.Invoke_O__O(arg_1868) } else { tmp1 = linked_1866.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1865, arg_1868) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1869 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = s__851000217__3; if linked_1870 == nil { c__1927001037__auto____4 = ifn_1871.Invoke_O__O(arg_1872) } else { c__1927001037__auto____4 = linked_1870.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1869, arg_1872) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000219__6 any; var root_1873 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1874 == nil { b__851000219__6 = ifn_1875.Invoke_O__O(arg_1876) } else { b__851000219__6 = linked_1874.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1873, arg_1876) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1893 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A_New_O_I_O(b__851000219__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1892 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A_fn_class; if fncls__1892 == nil { var fncls__1892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__1893); A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A_fn_class = fncls__1892d; tmp3 = fncls__1892d } else { tmp3 = fncls__1892 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1893, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1894 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any; var root_1899 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = b__851000219__6; if linked_1900 == nil { arg_1897 = ifn_1901.Invoke_O__O(arg_1902) } else { arg_1897 = linked_1900.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1899, arg_1902) }; var arg_1898 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000216); var tmp5 any; var root_1903 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = s__851000217__3; if linked_1904 == nil { tmp5 = ifn_1905.Invoke_O__O(arg_1906) } else { tmp5 = linked_1904.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1903, arg_1906) }; arg_1898 = tmp4.Invoke_O__O(tmp5); if linked_1895 == nil { return ifn_1896.Invoke_O_O__O(arg_1897, arg_1898) } else { return linked_1895.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1894, arg_1897, arg_1898) } } else { var root_1907 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any; var root_1912 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1914 lang.IFn; if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = b__851000219__6; if linked_1913 == nil { arg_1910 = ifn_1914.Invoke_O__O(arg_1915) } else { arg_1910 = linked_1913.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1912, arg_1915) }; var arg_1911 any; if linked_1908 == nil { return ifn_1909.Invoke_O_O__O(arg_1910, arg_1911) } else { return linked_1908.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1907, arg_1910, arg_1911) } } } else { var mm__4 any; var root_1916 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1916, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1918 lang.IFn; if linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any = s__851000217__3; if linked_1917 == nil { mm__4 = ifn_1918.Invoke_O__O(arg_1919) } else { mm__4 = linked_1917.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1916, arg_1919) }; var tmp6 any; var tmp7 any = A_arbace_classes_annot_A_const_90; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4))
																if and__1927000168__auto____5 { tmp6 = A_arbace_classes_annot_A_const_159.Invoke_O__O(mm__4) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :320:1
	if jrt.J2g_Truth(tmp6) { var v__5 any; var tmp8 *lang.Compiler_AOTFn; var fnbody__1929 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A_New_O(mm__4); var tmp9 *jrt.Class
		var fncls__1928 /*line :320:1*/*jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A_fn_class

		if fncls__1928 == nil { var fncls__1928d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__1929); A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A_fn_class = fncls__1928d; tmp9 = fncls__1928d } else { tmp9 = fncls__1928 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1929, tmp9, nil); v__5 = Up_Compiler_AOTFn_IFn(tmp8).Invoke__O()
//line :320:1
		if jrt.J2g_Truth(v__5) { var root_1930 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__4), nil, v__5)).Ref(); var arg_1934 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__851000216); var tmp11 any; var root_1935 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = s__851000217__3; if linked_1936 == nil { tmp11 = ifn_1937.Invoke_O__O(arg_1938) } else { tmp11 = linked_1936.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1935, arg_1938) }; arg_1934 = tmp10.Invoke_O__O(tmp11); if linked_1931 == nil { return ifn_1932.Invoke_O_O__O(arg_1933, arg_1934) } else { return linked_1931.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1930, arg_1933, arg_1934) } } else { var tmp12 any; var root_1939 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = s__851000217__3; if linked_1940 == nil { tmp12 = ifn_1941.Invoke_O__O(arg_1942) } else { tmp12 = linked_1940.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1939, arg_1942) }; s__851000217__1 = tmp12; continue L1 } } else { var tmp13 any; var root_1943 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = s__851000217__3; if linked_1944 == nil { tmp13 = ifn_1945.Invoke_O__O(arg_1946) } else { tmp13 = linked_1944.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1943, arg_1946) }; s__851000217__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :320:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :320:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A) Ctor_O_I_O(c__b__851000219 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000219 = c__b__851000219; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :320:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A) Invoke_O__O(self any) any { { var i__851000218__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000218__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000218__1)); var tmp2 any; var tmp3 any = A_arbace_classes_annot_A_const_90; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__2))
																		if and__1927000168__auto____3 { tmp2 = A_arbace_classes_annot_A_const_159.Invoke_O__O(mm__2) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :320:1
	if jrt.J2g_Truth(tmp2) { var v__3 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__1886 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A_New_O(mm__2); var tmp5 *jrt.Class
		var fncls__1885 /*line :320:1*/*jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A_fn_class

		if fncls__1885 == nil { var fncls__1885d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__1886); A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A_fn_class = fncls__1885d; tmp5 = fncls__1885d } else { tmp5 = fncls__1885 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1886, tmp5, nil); v__3 = Up_Compiler_AOTFn_IFn(tmp4).Invoke__O()
//line :320:1
		if jrt.J2g_Truth(v__3) { var root_1887 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = t.F_b__851000219; var arg_1891 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__2), nil, v__3)).Ref(); if linked_1888 == nil { ifn_1889.Invoke_O_O__O(arg_1890, arg_1891) } else { linked_1888.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1887, arg_1890, arg_1891) }; i__851000218__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000218__1); continue L1 } else { i__851000218__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000218__1); continue L1 } } else { i__851000218__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000218__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :320:1
func A_arbace_classes_annot_class_data_iter__851000322__851000326_A_New() *A_arbace_classes_annot_class_data_iter__851000322__851000326_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000322__851000326_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_A) Ctor() {}
//line :320:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_A) Invoke_O_O__O(self, s__851000323__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2644 any = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A_New_O_O(s__851000323__1, self); var tmp2 *jrt.Class; var fncls__2643 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A_fn_class; if fncls__2643 == nil { var fncls__2643d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__2644); A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A_fn_class = fncls__2643d; tmp2 = fncls__2643d } else { tmp2 = fncls__2643 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2644, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :320:1
func A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A{}; t.Ctor_O_O(p0, p1); return t }
//line :320:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A) Ctor_O_O(c__s__851000323, c__iter__851000322 any) { t.F_s__851000323 = c__s__851000323; t.F_iter__851000322 = c__iter__851000322 }
//line :320:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A) Invoke_O__O(self any) any { { var s__851000323__1 any; var t_ any = t.F_s__851000323; t.F_s__851000323 = nil; s__851000323__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2557 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2559 lang.IFn; if linked_2558 == nil { ifn_2559 = lang.IFn_Cast(root_2557) } else { ifn_2559 = nil }; var arg_2560 any = s__851000323__1; if linked_2558 == nil { temp__1927000414__auto____2 = ifn_2559.Invoke_O__O(arg_2560) } else { temp__1927000414__auto____2 = linked_2558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2557, arg_2560) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000323__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2561 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2561, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2563 lang.IFn; if linked_2562 == nil { ifn_2563 = lang.IFn_Cast(root_2561) } else { ifn_2563 = nil }; var arg_2564 any = s__851000323__3; if linked_2562 == nil { tmp1 = ifn_2563.Invoke_O__O(arg_2564) } else { tmp1 = linked_2562.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2561, arg_2564) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2565 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2567 lang.IFn; if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any = s__851000323__3; if linked_2566 == nil { c__1927001037__auto____4 = ifn_2567.Invoke_O__O(arg_2568) } else { c__1927001037__auto____4 = linked_2566.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2565, arg_2568) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000325__6 any; var root_2569 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2571 lang.IFn; if linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2570 == nil { b__851000325__6 = ifn_2571.Invoke_O__O(arg_2572) } else { b__851000325__6 = linked_2570.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2569, arg_2572) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2589 any = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A_New_O_I_O(b__851000325__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2588 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A_fn_class; if fncls__2588 == nil { var fncls__2588d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__2589); A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A_fn_class = fncls__2588d; tmp3 = fncls__2588d } else { tmp3 = fncls__2588 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2589, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2590 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any; var root_2595 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = b__851000325__6; if linked_2596 == nil { arg_2593 = ifn_2597.Invoke_O__O(arg_2598) } else { arg_2593 = linked_2596.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2595, arg_2598) }; var arg_2594 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000322); var tmp5 any; var root_2599 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2601 lang.IFn; if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = s__851000323__3; if linked_2600 == nil { tmp5 = ifn_2601.Invoke_O__O(arg_2602) } else { tmp5 = linked_2600.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2599, arg_2602) }; arg_2594 = tmp4.Invoke_O__O(tmp5); if linked_2591 == nil { return ifn_2592.Invoke_O_O__O(arg_2593, arg_2594) } else { return linked_2591.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2590, arg_2593, arg_2594) } } else { var root_2603 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2605 lang.IFn; if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any; var root_2608 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = b__851000325__6; if linked_2609 == nil { arg_2606 = ifn_2610.Invoke_O__O(arg_2611) } else { arg_2606 = linked_2609.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2608, arg_2611) }; var arg_2607 any; if linked_2604 == nil { return ifn_2605.Invoke_O_O__O(arg_2606, arg_2607) } else { return linked_2604.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2603, arg_2606, arg_2607) } } } else { var mm__4 any; var root_2612 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = s__851000323__3; if linked_2613 == nil { mm__4 = ifn_2614.Invoke_O__O(arg_2615) } else { mm__4 = linked_2613.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2612, arg_2615) }; var tmp6 any; var tmp7 any = A_arbace_classes_annot_A_const_90; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4))
															if and__1927000168__auto____5 { tmp6 = A_arbace_classes_annot_A_const_159.Invoke_O__O(mm__4) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :320:1
	if jrt.J2g_Truth(tmp6) { var v__5 any; var tmp8 *lang.Compiler_AOTFn; var fnbody__2625 any = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A_New_O(mm__4); var tmp9 *jrt.Class
		var fncls__2624 /*line :320:1*/*jrt.Class = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A_fn_class

		if fncls__2624 == nil { var fncls__2624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__2625); A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A_fn_class = fncls__2624d; tmp9 = fncls__2624d } else { tmp9 = fncls__2624 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2625, tmp9, nil); v__5 = Up_Compiler_AOTFn_IFn(tmp8).Invoke__O()
//line :320:1
		if jrt.J2g_Truth(v__5) { var root_2626 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2628 lang.IFn; if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__4), nil, v__5)).Ref(); var arg_2630 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__851000322); var tmp11 any; var root_2631 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = s__851000323__3; if linked_2632 == nil { tmp11 = ifn_2633.Invoke_O__O(arg_2634) } else { tmp11 = linked_2632.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2631, arg_2634) }; arg_2630 = tmp10.Invoke_O__O(tmp11); if linked_2627 == nil { return ifn_2628.Invoke_O_O__O(arg_2629, arg_2630) } else { return linked_2627.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2626, arg_2629, arg_2630) } } else { var tmp12 any; var root_2635 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any = s__851000323__3; if linked_2636 == nil { tmp12 = ifn_2637.Invoke_O__O(arg_2638) } else { tmp12 = linked_2636.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2635, arg_2638) }; s__851000323__1 = tmp12; continue L1 } } else { var tmp13 any; var root_2639 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2641 lang.IFn; if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any = s__851000323__3; if linked_2640 == nil { tmp13 = ifn_2641.Invoke_O__O(arg_2642) } else { tmp13 = linked_2640.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2639, arg_2642) }; s__851000323__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :320:1
func A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :320:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A) Ctor_O_I_O(c__b__851000325 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000325 = c__b__851000325; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :320:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A) Invoke_O__O(self any) any { { var i__851000324__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000324__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000324__1)); var tmp2 any; var tmp3 any = A_arbace_classes_annot_A_const_90; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { tmp2 = A_arbace_classes_annot_A_const_159.Invoke_O__O(mm__2) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :320:1
	if jrt.J2g_Truth(tmp2) { var v__3 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__2582 any = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A_New_O(mm__2); var tmp5 *jrt.Class
		var fncls__2581 /*line :320:1*/*jrt.Class = A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A_fn_class

		if fncls__2581 == nil { var fncls__2581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__2582); A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A_fn_class = fncls__2581d; tmp5 = fncls__2581d } else { tmp5 = fncls__2581 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2582, tmp5, nil); v__3 = Up_Compiler_AOTFn_IFn(tmp4).Invoke__O()
//line :320:1
		if jrt.J2g_Truth(v__3) { var root_2583 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2583, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2585 lang.IFn; if linked_2584 == nil { ifn_2585 = lang.IFn_Cast(root_2583) } else { ifn_2585 = nil }; var arg_2586 any = t.F_b__851000325; var arg_2587 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__2), nil, v__3)).Ref(); if linked_2584 == nil { ifn_2585.Invoke_O_O__O(arg_2586, arg_2587) } else { linked_2584.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2583, arg_2586, arg_2587) }; i__851000324__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000324__1); continue L1 } else { i__851000324__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000324__1); continue L1 } } else { i__851000324__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000324__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A_New_O(p0 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A{}; t.Ctor_O(p0); return t }
//line :322:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A) Ctor_O(c__mm any) { t.F_mm = c__mm }
//line :322:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1877 any = A_arbace_classes_annot_A_const_36.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, A_arbace_classes_annot_enc_value_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any; var root_1881 any = A_arbace_classes_annot_A_const_160.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any; var t_ any = t.F_mm; t.F_mm = nil; arg_1884 = t_; if linked_1882 == nil { arg_1880 = ifn_1883.Invoke_O__O(arg_1884) } else { arg_1880 = linked_1882.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A).Invoke_O_O__O(root_1881, arg_1884) }; if linked_1878 == nil { tmp1 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp1 = linked_1878.(*A_arbace_classes_annot_enc_value_A).Invoke_O_O__O(root_1877, arg_1880) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :322:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A_New_O(p0 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A{}; t.Ctor_O(p0); return t }
//line :322:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A) Ctor_O(c__mm any) { t.F_mm = c__mm }
//line :322:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1920 any = A_arbace_classes_annot_A_const_36.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, A_arbace_classes_annot_enc_value_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any; var root_1924 any = A_arbace_classes_annot_A_const_160.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any; var t_ any = t.F_mm; t.F_mm = nil; arg_1927 = t_; if linked_1925 == nil { arg_1923 = ifn_1926.Invoke_O__O(arg_1927) } else { arg_1923 = linked_1925.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A).Invoke_O_O__O(root_1924, arg_1927) }; if linked_1921 == nil { tmp1 = ifn_1922.Invoke_O__O(arg_1923) } else { tmp1 = linked_1921.(*A_arbace_classes_annot_enc_value_A).Invoke_O_O__O(root_1920, arg_1923) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :322:1
func A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A_New_O(p0 any) *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A{}; t.Ctor_O(p0); return t }
//line :322:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A) Ctor_O(c__mm any) { t.F_mm = c__mm }
//line :322:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2573 any = A_arbace_classes_annot_A_const_36.GetRawRoot__O(); var linked_2574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2573, A_arbace_classes_annot_enc_value_A_fn_class); var ifn_2575 lang.IFn; if linked_2574 == nil { ifn_2575 = lang.IFn_Cast(root_2573) } else { ifn_2575 = nil }; var arg_2576 any; var root_2577 any = A_arbace_classes_annot_A_const_160.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2577, aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A_fn_class); var ifn_2579 lang.IFn; if linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any; var t_ any = t.F_mm; t.F_mm = nil; arg_2580 = t_; if linked_2578 == nil { arg_2576 = ifn_2579.Invoke_O__O(arg_2580) } else { arg_2576 = linked_2578.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A).Invoke_O_O__O(root_2577, arg_2580) }; if linked_2574 == nil { tmp1 = ifn_2575.Invoke_O__O(arg_2576) } else { tmp1 = linked_2574.(*A_arbace_classes_annot_enc_value_A).Invoke_O_O__O(root_2573, arg_2576) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }
//line :322:1
func A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A_New_O(p0 any) *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A{}; t.Ctor_O(p0); return t }
//line :322:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A) Ctor_O(c__mm any) { t.F_mm = c__mm }
//line :322:1
func (t *A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2616 any = A_arbace_classes_annot_A_const_36.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, A_arbace_classes_annot_enc_value_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any; var root_2620 any = A_arbace_classes_annot_A_const_160.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any; var t_ any = t.F_mm; t.F_mm = nil; arg_2623 = t_; if linked_2621 == nil { arg_2619 = ifn_2622.Invoke_O__O(arg_2623) } else { arg_2619 = linked_2621.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_element_default_A).Invoke_O_O__O(root_2620, arg_2623) }; if linked_2617 == nil { tmp1 = ifn_2618.Invoke_O__O(arg_2619) } else { tmp1 = linked_2617.(*A_arbace_classes_annot_enc_value_A).Invoke_O_O__O(root_2616, arg_2619) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }




func A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A_New_O(p0 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A{}; t.Ctor_O(p0); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A) Invoke_O_O__O(self, s__851000231__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2071 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A_New_O_O_O(s__851000231__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__2070 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A_fn_class; if fncls__2070 == nil { var fncls__2070d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__2071); A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A_fn_class = fncls__2070d; tmp2 = fncls__2070d } else { tmp2 = fncls__2070 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2071, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :327:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A) Ctor_O_O_O(c__s__851000231, c__n, c__iter__851000230 any) { t.F_s__851000231 = c__s__851000231; t.F_n = c__n; t.F_iter__851000230 = c__iter__851000230 }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A) Invoke_O__O(self any) any { { var s__851000231__1 any; var t_ any = t.F_s__851000231; t.F_s__851000231 = nil; s__851000231__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1958 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = s__851000231__1; if linked_1959 == nil { temp__1927000414__auto____2 = ifn_1960.Invoke_O__O(arg_1961) } else { temp__1927000414__auto____2 = linked_1959.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1958, arg_1961) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var mm__4 any; var root_1962 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = xs__1927001018__auto____3; if linked_1963 == nil { mm__4 = ifn_1964.Invoke_O__O(arg_1965) } else { mm__4 = linked_1963.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1962, arg_1965) }; var tmp1 any; var root_1966 any = A_arbace_classes_annot_A_const_96.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, A_arbace_classes_annot_reflected_member_QMARK__A_fn_class); var ifn_1968 lang.IFn
																if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = mm__4; if linked_1967 == nil { tmp1 = ifn_1968.Invoke_O__O(arg_1969) } else { tmp1 = linked_1967.(*A_arbace_classes_annot_reflected_member_QMARK__A).Invoke_O_O__O(root_1966, arg_1969) }
//line :327:1
	if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_annot_A_const_97; var ctor__5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4)); var head__6 any


		if ctor__5 {

			var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil); var tmp4 any; var root_1970 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, A_arbace_classes_annot_bin_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any; var root_1974 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = t.F_n; var arg_1978 any = mm__4; if linked_1975 == nil { arg_1973 = ifn_1976.Invoke_O_O__O(arg_1977, arg_1978) } else { arg_1973 = linked_1975.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_1974, arg_1977, arg_1978) }; if linked_1971 == nil { tmp4 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp4 = linked_1971.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_1970, arg_1973) }; head__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref() } else {
				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_9, nil); var tmp6 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__4); var tmp7 any; var root_1979 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, A_arbace_classes_annot_bin_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__4); if linked_1980 == nil { tmp7 = ifn_1981.Invoke_O__O(arg_1982) } else { tmp7 = linked_1980.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_1979, arg_1982) }; head__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref() }
//line :327:1
		var iterys__1927001035__auto____7 any; var fnbody__2044 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A_New_O(head__6); var tmp8 *jrt.Class; var fncls__2043 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A_fn_class; if fncls__2043 == nil { var fncls__2043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__2044); A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A_fn_class = fncls__2043d; tmp8 = fncls__2043d } else { tmp8 = fncls__2043 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2044, tmp8, nil); var fs__1927001036__auto____8 any; var root_2045 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2047 lang.IFn; if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any; var tmp9 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp10 any; var root_2049 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, A_arbace_classes_annot_visible_A_fn_class); var ifn_2051 lang.IFn






		if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(mm__4); if linked_2050 == nil { tmp10 = ifn_2051.Invoke_O__O(arg_2052) } else { tmp10 = linked_2050.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_2049, arg_2052) }
//line :327:1
		arg_2048 = tmp9.Invoke_O__O(tmp10); if linked_2046 == nil { fs__1927001036__auto____8 = ifn_2047.Invoke_O__O(arg_2048) } else { fs__1927001036__auto____8 = linked_2046.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2045, arg_2048) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2053 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = fs__1927001036__auto____8; var arg_2057 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__851000230); var tmp12 any; var root_2058 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = s__851000231__1; if linked_2059 == nil { tmp12 = ifn_2060.Invoke_O__O(arg_2061) } else { tmp12 = linked_2059.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2058, arg_2061) }; arg_2057 = tmp11.Invoke_O__O(tmp12); if linked_2054 == nil { return ifn_2055.Invoke_O_O__O(arg_2056, arg_2057) } else { return linked_2054.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2053, arg_2056, arg_2057) } } else { var tmp13 any; var root_2062 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = s__851000231__1; if linked_2063 == nil { tmp13 = ifn_2064.Invoke_O__O(arg_2065) } else { tmp13 = linked_2063.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2062, arg_2065) }; s__851000231__1 = tmp13; continue L1 } } else { var tmp14 any; var root_2066 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2068 lang.IFn; if linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var arg_2069 any = s__851000231__1; if linked_2067 == nil { tmp14 = ifn_2068.Invoke_O__O(arg_2069) } else { tmp14 = linked_2067.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2066, arg_2069) }; s__851000231__1 = tmp14; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :327:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A_New_O(p0 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A{}; t.Ctor_O(p0); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A) Ctor_O(c__head any) { t.F_head = c__head }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A) Invoke_O_O__O(self, s__851000233__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2042 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A_New_O_O_O(s__851000233__1, t.F_head, self); var tmp2 *jrt.Class; var fncls__2041 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A_fn_class; if fncls__2041 == nil { var fncls__2041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__2042); A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A_fn_class = fncls__2041d; tmp2 = fncls__2041d } else { tmp2 = fncls__2041 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2042, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :327:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A) Ctor_O_O_O(c__s__851000233, c__head, c__iter__851000232 any) { t.F_s__851000233 = c__s__851000233; t.F_head = c__head; t.F_iter__851000232 = c__iter__851000232 }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A) Invoke_O__O(self any) any { { var s__851000233__1 any; var t_ any = t.F_s__851000233; t.F_s__851000233 = nil; s__851000233__1 = t_; for { var temp__1927000414__auto____2 any; var root_1983 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = s__851000233__1; if linked_1984 == nil { temp__1927000414__auto____2 = ifn_1985.Invoke_O__O(arg_1986) } else { temp__1927000414__auto____2 = linked_1984.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1983, arg_1986) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000233__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1987 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = s__851000233__3; if linked_1988 == nil { tmp1 = ifn_1989.Invoke_O__O(arg_1990) } else { tmp1 = linked_1988.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1987, arg_1990) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1991 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1993 lang.IFn; if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any = s__851000233__3; if linked_1992 == nil { c__1927001037__auto____4 = ifn_1993.Invoke_O__O(arg_1994) } else { c__1927001037__auto____4 = linked_1992.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1991, arg_1994) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000235__6 any; var root_1995 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1996 == nil { b__851000235__6 = ifn_1997.Invoke_O__O(arg_1998) } else { b__851000235__6 = linked_1996.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1995, arg_1998) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2005 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A_New_O_O_I_O(b__851000235__6, t.F_head, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2004 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A_fn_class; if fncls__2004 == nil { var fncls__2004d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__2005); A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A_fn_class = fncls__2004d; tmp3 = fncls__2004d } else { tmp3 = fncls__2004 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2005, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2006 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any; var root_2011 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = b__851000235__6; if linked_2012 == nil { arg_2009 = ifn_2013.Invoke_O__O(arg_2014) } else { arg_2009 = linked_2012.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2011, arg_2014) }; var arg_2010 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000232); var tmp5 any; var root_2015 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2017 lang.IFn; if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = s__851000233__3; if linked_2016 == nil { tmp5 = ifn_2017.Invoke_O__O(arg_2018) } else { tmp5 = linked_2016.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2015, arg_2018) }; arg_2010 = tmp4.Invoke_O__O(tmp5); if linked_2007 == nil { return ifn_2008.Invoke_O_O__O(arg_2009, arg_2010) } else { return linked_2007.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2006, arg_2009, arg_2010) } } else { var root_2019 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any; var root_2024 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = b__851000235__6; if linked_2025 == nil { arg_2022 = ifn_2026.Invoke_O__O(arg_2027) } else { arg_2022 = linked_2025.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2024, arg_2027) }; var arg_2023 any; if linked_2020 == nil { return ifn_2021.Invoke_O_O__O(arg_2022, arg_2023) } else { return linked_2020.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2019, arg_2022, arg_2023) } } } else { var x__4 any; var root_2028 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = s__851000233__3; if linked_2029 == nil { x__4 = ifn_2030.Invoke_O__O(arg_2031) } else { x__4 = linked_2029.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2028, arg_2031) }; var root_2032 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, t.F_head, nil, x__4)).Ref(); var arg_2036 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000232); var tmp7 any; var root_2037 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = s__851000233__3; if linked_2038 == nil { tmp7 = ifn_2039.Invoke_O__O(arg_2040) } else { tmp7 = linked_2038.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2037, arg_2040) }; arg_2036 = tmp6.Invoke_O__O(tmp7); if linked_2033 == nil { return ifn_2034.Invoke_O_O__O(arg_2035, arg_2036) } else { return linked_2033.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2032, arg_2035, arg_2036) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :327:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A) Ctor_O_O_I_O(c__b__851000235, c__head any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000235 = c__b__851000235; t.F_head = c__head; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :327:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A) Invoke_O__O(self any) any { { var i__851000234__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000234__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000234__1)); var root_1999 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = t.F_b__851000235; var arg_2003 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, t.F_head, nil, x__2)).Ref(); if linked_2000 == nil { ifn_2001.Invoke_O_O__O(arg_2002, arg_2003) } else { linked_2000.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1999, arg_2002, arg_2003) }; i__851000234__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000234__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :327:1
func A_arbace_classes_annot_class_data_iter__851000336__851000342_A_New_O(p0 any) *A_arbace_classes_annot_class_data_iter__851000336__851000342_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000336__851000342_A{}; t.Ctor_O(p0); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_A) Invoke_O_O__O(self, s__851000337__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2767 any = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A_New_O_O_O(self, s__851000337__1, t.F_n); var tmp2 *jrt.Class; var fncls__2766 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A_fn_class; if fncls__2766 == nil { var fncls__2766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__2767); A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A_fn_class = fncls__2766d; tmp2 = fncls__2766d } else { tmp2 = fncls__2766 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2767, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :327:1
func A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A) Ctor_O_O_O(c__iter__851000336, c__s__851000337, c__n any) { t.F_iter__851000336 = c__iter__851000336; t.F_s__851000337 = c__s__851000337; t.F_n = c__n }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A) Invoke_O__O(self any) any { { var s__851000337__1 any; var t_ any = t.F_s__851000337; t.F_s__851000337 = nil; s__851000337__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2654 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2654, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2656 lang.IFn; if linked_2655 == nil { ifn_2656 = lang.IFn_Cast(root_2654) } else { ifn_2656 = nil }; var arg_2657 any = s__851000337__1; if linked_2655 == nil { temp__1927000414__auto____2 = ifn_2656.Invoke_O__O(arg_2657) } else { temp__1927000414__auto____2 = linked_2655.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2654, arg_2657) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var mm__4 any; var root_2658 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2660 lang.IFn; if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any = xs__1927001018__auto____3; if linked_2659 == nil { mm__4 = ifn_2660.Invoke_O__O(arg_2661) } else { mm__4 = linked_2659.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2658, arg_2661) }; var tmp1 any; var root_2662 any = A_arbace_classes_annot_A_const_96.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, A_arbace_classes_annot_reflected_member_QMARK__A_fn_class); var ifn_2664 lang.IFn
															if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = mm__4; if linked_2663 == nil { tmp1 = ifn_2664.Invoke_O__O(arg_2665) } else { tmp1 = linked_2663.(*A_arbace_classes_annot_reflected_member_QMARK__A).Invoke_O_O__O(root_2662, arg_2665) }
//line :327:1
	if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_annot_A_const_97; var ctor__5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4)); var head__6 any


		if ctor__5 {

			var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_54, nil); var tmp4 any; var root_2666 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_2667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2666, A_arbace_classes_annot_bin_A_fn_class); var ifn_2668 lang.IFn; if linked_2667 == nil { ifn_2668 = lang.IFn_Cast(root_2666) } else { ifn_2668 = nil }; var arg_2669 any; var root_2670 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = t.F_n; var arg_2674 any = mm__4; if linked_2671 == nil { arg_2669 = ifn_2672.Invoke_O_O__O(arg_2673, arg_2674) } else { arg_2669 = linked_2671.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_2670, arg_2673, arg_2674) }; if linked_2667 == nil { tmp4 = ifn_2668.Invoke_O__O(arg_2669) } else { tmp4 = linked_2667.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_2666, arg_2669) }; head__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref() } else {
				var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_9, nil); var tmp6 any = A_arbace_classes_annot_A_const_41.Invoke_O__O(mm__4); var tmp7 any; var root_2675 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_2676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2675, A_arbace_classes_annot_bin_A_fn_class); var ifn_2677 lang.IFn; if linked_2676 == nil { ifn_2677 = lang.IFn_Cast(root_2675) } else { ifn_2677 = nil }; var arg_2678 any = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__4); if linked_2676 == nil { tmp7 = ifn_2677.Invoke_O__O(arg_2678) } else { tmp7 = linked_2676.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_2675, arg_2678) }; head__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7)).Ref() }
//line :327:1
		var iterys__1927001035__auto____7 any; var fnbody__2740 any = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A_New_O(head__6); var tmp8 *jrt.Class; var fncls__2739 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A_fn_class; if fncls__2739 == nil { var fncls__2739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__2740); A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A_fn_class = fncls__2739d; tmp8 = fncls__2739d } else { tmp8 = fncls__2739 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2740, tmp8, nil); var fs__1927001036__auto____8 any; var root_2741 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2741, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2743 lang.IFn; if linked_2742 == nil { ifn_2743 = lang.IFn_Cast(root_2741) } else { ifn_2743 = nil }; var arg_2744 any; var tmp9 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp10 any; var root_2745 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_2746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2745, A_arbace_classes_annot_visible_A_fn_class); var ifn_2747 lang.IFn






		if linked_2746 == nil { ifn_2747 = lang.IFn_Cast(root_2745) } else { ifn_2747 = nil }; var arg_2748 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(mm__4); if linked_2746 == nil { tmp10 = ifn_2747.Invoke_O__O(arg_2748) } else { tmp10 = linked_2746.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_2745, arg_2748) }
//line :327:1
		arg_2744 = tmp9.Invoke_O__O(tmp10); if linked_2742 == nil { fs__1927001036__auto____8 = ifn_2743.Invoke_O__O(arg_2744) } else { fs__1927001036__auto____8 = linked_2742.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2741, arg_2744) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2749 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2749, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2751 lang.IFn; if linked_2750 == nil { ifn_2751 = lang.IFn_Cast(root_2749) } else { ifn_2751 = nil }; var arg_2752 any = fs__1927001036__auto____8; var arg_2753 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__851000336); var tmp12 any; var root_2754 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2754, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2756 lang.IFn; if linked_2755 == nil { ifn_2756 = lang.IFn_Cast(root_2754) } else { ifn_2756 = nil }; var arg_2757 any = s__851000337__1; if linked_2755 == nil { tmp12 = ifn_2756.Invoke_O__O(arg_2757) } else { tmp12 = linked_2755.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2754, arg_2757) }; arg_2753 = tmp11.Invoke_O__O(tmp12); if linked_2750 == nil { return ifn_2751.Invoke_O_O__O(arg_2752, arg_2753) } else { return linked_2750.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2749, arg_2752, arg_2753) } } else { var tmp13 any; var root_2758 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2758, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2760 lang.IFn; if linked_2759 == nil { ifn_2760 = lang.IFn_Cast(root_2758) } else { ifn_2760 = nil }; var arg_2761 any = s__851000337__1; if linked_2759 == nil { tmp13 = ifn_2760.Invoke_O__O(arg_2761) } else { tmp13 = linked_2759.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2758, arg_2761) }; s__851000337__1 = tmp13; continue L1 } } else { var tmp14 any; var root_2762 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = s__851000337__1; if linked_2763 == nil { tmp14 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp14 = linked_2763.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2762, arg_2765) }; s__851000337__1 = tmp14; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :327:1
func A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A_New_O(p0 any) *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A{}; t.Ctor_O(p0); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A) Ctor_O(c__head any) { t.F_head = c__head }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A) Invoke_O_O__O(self, s__851000339__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2738 any = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A_New_O_O_O(self, s__851000339__1, t.F_head); var tmp2 *jrt.Class; var fncls__2737 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A_fn_class; if fncls__2737 == nil { var fncls__2737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__2738); A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A_fn_class = fncls__2737d; tmp2 = fncls__2737d } else { tmp2 = fncls__2737 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2738, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :327:1
func A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A) Ctor_O_O_O(c__iter__851000338, c__s__851000339, c__head any) { t.F_iter__851000338 = c__iter__851000338; t.F_s__851000339 = c__s__851000339; t.F_head = c__head }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A) Invoke_O__O(self any) any { { var s__851000339__1 any; var t_ any = t.F_s__851000339; t.F_s__851000339 = nil; s__851000339__1 = t_; for { var temp__1927000414__auto____2 any; var root_2679 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2681 lang.IFn; if linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any = s__851000339__1; if linked_2680 == nil { temp__1927000414__auto____2 = ifn_2681.Invoke_O__O(arg_2682) } else { temp__1927000414__auto____2 = linked_2680.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2679, arg_2682) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000339__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2683 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2683, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2685 lang.IFn; if linked_2684 == nil { ifn_2685 = lang.IFn_Cast(root_2683) } else { ifn_2685 = nil }; var arg_2686 any = s__851000339__3; if linked_2684 == nil { tmp1 = ifn_2685.Invoke_O__O(arg_2686) } else { tmp1 = linked_2684.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2683, arg_2686) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2687 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = s__851000339__3; if linked_2688 == nil { c__1927001037__auto____4 = ifn_2689.Invoke_O__O(arg_2690) } else { c__1927001037__auto____4 = linked_2688.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2687, arg_2690) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000341__6 any; var root_2691 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2693 lang.IFn; if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2692 == nil { b__851000341__6 = ifn_2693.Invoke_O__O(arg_2694) } else { b__851000341__6 = linked_2692.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2691, arg_2694) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2701 any = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A_New_O_O_I_O(b__851000341__6, t.F_head, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2700 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A_fn_class; if fncls__2700 == nil { var fncls__2700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__2701); A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A_fn_class = fncls__2700d; tmp3 = fncls__2700d } else { tmp3 = fncls__2700 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2701, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2702 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any; var root_2707 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = b__851000341__6; if linked_2708 == nil { arg_2705 = ifn_2709.Invoke_O__O(arg_2710) } else { arg_2705 = linked_2708.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2707, arg_2710) }; var arg_2706 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000338); var tmp5 any; var root_2711 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = s__851000339__3; if linked_2712 == nil { tmp5 = ifn_2713.Invoke_O__O(arg_2714) } else { tmp5 = linked_2712.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2711, arg_2714) }; arg_2706 = tmp4.Invoke_O__O(tmp5); if linked_2703 == nil { return ifn_2704.Invoke_O_O__O(arg_2705, arg_2706) } else { return linked_2703.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2702, arg_2705, arg_2706) } } else { var root_2715 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2715, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2717 lang.IFn; if linked_2716 == nil { ifn_2717 = lang.IFn_Cast(root_2715) } else { ifn_2717 = nil }; var arg_2718 any; var root_2720 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2720, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2722 lang.IFn; if linked_2721 == nil { ifn_2722 = lang.IFn_Cast(root_2720) } else { ifn_2722 = nil }; var arg_2723 any = b__851000341__6; if linked_2721 == nil { arg_2718 = ifn_2722.Invoke_O__O(arg_2723) } else { arg_2718 = linked_2721.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2720, arg_2723) }; var arg_2719 any; if linked_2716 == nil { return ifn_2717.Invoke_O_O__O(arg_2718, arg_2719) } else { return linked_2716.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2715, arg_2718, arg_2719) } } } else { var x__4 any; var root_2724 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2726 lang.IFn; if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any = s__851000339__3; if linked_2725 == nil { x__4 = ifn_2726.Invoke_O__O(arg_2727) } else { x__4 = linked_2725.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2724, arg_2727) }; var root_2728 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2728, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2730 lang.IFn; if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, t.F_head, nil, x__4)).Ref(); var arg_2732 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000338); var tmp7 any; var root_2733 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2733, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2735 lang.IFn; if linked_2734 == nil { ifn_2735 = lang.IFn_Cast(root_2733) } else { ifn_2735 = nil }; var arg_2736 any = s__851000339__3; if linked_2734 == nil { tmp7 = ifn_2735.Invoke_O__O(arg_2736) } else { tmp7 = linked_2734.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2733, arg_2736) }; arg_2732 = tmp6.Invoke_O__O(tmp7); if linked_2729 == nil { return ifn_2730.Invoke_O_O__O(arg_2731, arg_2732) } else { return linked_2729.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2728, arg_2731, arg_2732) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :327:1
func A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A) Ctor_O_O_I_O(c__b__851000341, c__head any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__851000341 = c__b__851000341; t.F_head = c__head; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :327:1
func (t *A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A) Invoke_O__O(self any) any { { var i__851000340__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000340__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000340__1)); var root_2695 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2695, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2697 lang.IFn; if linked_2696 == nil { ifn_2697 = lang.IFn_Cast(root_2695) } else { ifn_2697 = nil }; var arg_2698 any = t.F_b__851000341; var arg_2699 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, t.F_head, nil, x__2)).Ref(); if linked_2696 == nil { ifn_2697.Invoke_O_O__O(arg_2698, arg_2699) } else { linked_2696.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2695, arg_2698, arg_2699) }; i__851000340__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000340__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A_New_O(p0 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A{}; t.Ctor_O(p0); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A) Invoke_O_O__O(self, s__851000247__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2234 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A_New_O_O_O(self, s__851000247__1, t.F_n); var tmp2 *jrt.Class; var fncls__2233 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A_fn_class; if fncls__2233 == nil { var fncls__2233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__2234); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A_fn_class = fncls__2233d; tmp2 = fncls__2233d } else { tmp2 = fncls__2233 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2234, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :336:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A) Ctor_O_O_O(c__iter__851000246, c__s__851000247, c__n any) { t.F_iter__851000246 = c__iter__851000246; t.F_s__851000247 = c__s__851000247; t.F_n = c__n }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A) Invoke_O__O(self any) any { { var s__851000247__1 any; var t_ any = t.F_s__851000247; t.F_s__851000247 = nil; s__851000247__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2074 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2076 lang.IFn; if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = s__851000247__1; if linked_2075 == nil { temp__1927000414__auto____2 = ifn_2076.Invoke_O__O(arg_2077) } else { temp__1927000414__auto____2 = linked_2075.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2074, arg_2077) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var mm__4 any; var root_2078 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = xs__1927001018__auto____3; if linked_2079 == nil { mm__4 = ifn_2080.Invoke_O__O(arg_2081) } else { mm__4 = linked_2079.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2078, arg_2081) }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_161); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4))) { var tmp2 any = A_arbace_classes_annot_A_const_97; var ctor__5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4)); var desc__6 any




	if ctor__5 { var root_2082 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = t.F_n; var arg_2086 any = mm__4; if linked_2083 == nil { desc__6 = ifn_2084.Invoke_O_O__O(arg_2085, arg_2086) } else { desc__6 = linked_2083.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_2082, arg_2085, arg_2086) } } else { desc__6 = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__4) }
//line :336:1
	var lead__7 any





	if ctor__5 { var tmp3 *lang.Compiler_AOTFn; var fnbody__2093 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A_New_O_O(t.F_n, mm__4); var tmp4 *jrt.Class; var fncls__2092 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A_fn_class; if fncls__2092 == nil { var fncls__2092d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__2093); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A_fn_class = fncls__2092d; tmp4 = fncls__2092d } else { tmp4 = fncls__2092 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2093, tmp4, nil); lead__7 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O() } else { lead__7 = A_arbace_classes_annot_A_const_73 }
//line :336:1
	var iterys__1927001035__auto____8 any; var fnbody__2206 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A_New_O_Z_O_O(desc__6, ctor__5, lead__7, mm__4); var tmp5 *jrt.Class; var fncls__2205 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A_fn_class; if fncls__2205 == nil { var fncls__2205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__2206); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A_fn_class = fncls__2205d; tmp5 = fncls__2205d } else { tmp5 = fncls__2205 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2206, tmp5, nil); var fs__1927001036__auto____9 any; var root_2207 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp7 any; var root_2211 any = A_arbace_classes_annot_A_const_163.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2213 lang.IFn






	if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = A_arbace_classes_annot_A_const_164.GetRawRoot__O(); var arg_2215 any = A_arbace_classes_annot_A_const_165.Invoke_O__O(mm__4); if linked_2212 == nil { tmp7 = ifn_2213.Invoke_O_O__O(arg_2214, arg_2215) } else { tmp7 = linked_2212.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2211, arg_2214, arg_2215) }
//line :336:1
	arg_2210 = tmp6.Invoke_O__O(tmp7); if linked_2208 == nil { fs__1927001036__auto____9 = ifn_2209.Invoke_O__O(arg_2210) } else { fs__1927001036__auto____9 = linked_2208.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2207, arg_2210) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_2216 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = fs__1927001036__auto____9; var arg_2220 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__851000246); var tmp9 any; var root_2221 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = s__851000247__1; if linked_2222 == nil { tmp9 = ifn_2223.Invoke_O__O(arg_2224) } else { tmp9 = linked_2222.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2221, arg_2224) }; arg_2220 = tmp8.Invoke_O__O(tmp9); if linked_2217 == nil { return ifn_2218.Invoke_O_O__O(arg_2219, arg_2220) } else { return linked_2217.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2216, arg_2219, arg_2220) } } else { var tmp10 any; var root_2225 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = s__851000247__1; if linked_2226 == nil { tmp10 = ifn_2227.Invoke_O__O(arg_2228) } else { tmp10 = linked_2226.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2225, arg_2228) }; s__851000247__1 = tmp10; continue L1 } } else { var tmp11 any; var root_2229 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = s__851000247__1; if linked_2230 == nil { tmp11 = ifn_2231.Invoke_O__O(arg_2232) } else { tmp11 = linked_2230.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2229, arg_2232) }; s__851000247__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :336:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A_New_O_Z_O_O(p0 any, p1 bool, p2, p3 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A{}; t.Ctor_O_Z_O_O(p0, p1, p2, p3); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A) Ctor_O_Z_O_O(c__desc any, c__ctor bool, c__lead, c__mm any) { t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A) Invoke_O_O__O(self, s__851000249__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2204 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A_New_O_O_O_Z_O_O(self, s__851000249__1, t.F_desc, t.F_ctor, t.F_lead, t.F_mm); var tmp2 *jrt.Class; var fncls__2203 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A_fn_class; if fncls__2203 == nil { var fncls__2203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__2204); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A_fn_class = fncls__2203d; tmp2 = fncls__2203d } else { tmp2 = fncls__2203 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2204, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :336:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A_New_O_O_O_Z_O_O(p0, p1, p2 any, p3 bool, p4, p5 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A{}; t.Ctor_O_O_O_Z_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A) Ctor_O_O_O_Z_O_O(c__iter__851000248, c__s__851000249, c__desc any, c__ctor bool, c__lead, c__mm any) { t.F_iter__851000248 = c__iter__851000248; t.F_s__851000249 = c__s__851000249; t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A) Invoke_O__O(self any) any { { var s__851000249__1 any; var t_ any = t.F_s__851000249; t.F_s__851000249 = nil; s__851000249__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2094 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = s__851000249__1; if linked_2095 == nil { temp__1927000414__auto____2 = ifn_2096.Invoke_O__O(arg_2097) } else { temp__1927000414__auto____2 = linked_2095.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2094, arg_2097) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__851000260__4 any; var root_2098 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = xs__1927001018__auto____3; if linked_2099 == nil { vec__851000260__4 = ifn_2100.Invoke_O__O(arg_2101) } else { vec__851000260__4 = linked_2099.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2098, arg_2101) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000260__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pa__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000260__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__2181 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A_New_O_O_Z_O_O(i__5, t.F_desc, t.F_ctor, t.F_lead, t.F_mm); var tmp1 *jrt.Class; var fncls__2180 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A_fn_class; if fncls__2180 == nil { var fncls__2180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__2181); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A_fn_class = fncls__2180d; tmp1 = fncls__2180d } else { tmp1 = fncls__2180 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2181, tmp1, nil); var fs__1927001036__auto____8 any; var root_2182 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp3 any; var root_2186 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, A_arbace_classes_annot_visible_A_fn_class); var ifn_2188 lang.IFn







	if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = pa__6; if linked_2187 == nil { tmp3 = ifn_2188.Invoke_O__O(arg_2189) } else { tmp3 = linked_2187.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_2186, arg_2189) }
//line :336:1
	arg_2185 = tmp2.Invoke_O__O(tmp3); if linked_2183 == nil { fs__1927001036__auto____8 = ifn_2184.Invoke_O__O(arg_2185) } else { fs__1927001036__auto____8 = linked_2183.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2182, arg_2185) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2190 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = fs__1927001036__auto____8; var arg_2194 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000248); var tmp5 any; var root_2195 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = s__851000249__1; if linked_2196 == nil { tmp5 = ifn_2197.Invoke_O__O(arg_2198) } else { tmp5 = linked_2196.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2195, arg_2198) }; arg_2194 = tmp4.Invoke_O__O(tmp5); if linked_2191 == nil { return ifn_2192.Invoke_O_O__O(arg_2193, arg_2194) } else { return linked_2191.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2190, arg_2193, arg_2194) } } else { var tmp6 any; var root_2199 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = s__851000249__1; if linked_2200 == nil { tmp6 = ifn_2201.Invoke_O__O(arg_2202) } else { tmp6 = linked_2200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2199, arg_2202) }; s__851000249__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :336:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A_New_O_O_Z_O_O(p0, p1 any, p2 bool, p3, p4 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A{}; t.Ctor_O_O_Z_O_O(p0, p1, p2, p3, p4); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A) Ctor_O_O_Z_O_O(c__i, c__desc any, c__ctor bool, c__lead, c__mm any) { t.F_i = c__i; t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A) Invoke_O_O__O(self, s__851000251__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2179 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A_New_O_O_Z_O_O_O_O(t.F_i, t.F_desc, t.F_ctor, t.F_lead, self, t.F_mm, s__851000251__1); var tmp2 *jrt.Class; var fncls__2178 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A_fn_class; if fncls__2178 == nil { var fncls__2178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__2179); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A_fn_class = fncls__2178d; tmp2 = fncls__2178d } else { tmp2 = fncls__2178 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2179, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :336:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A_New_O_O_Z_O_O_O_O(p0, p1 any, p2 bool, p3, p4, p5, p6 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A{}; t.Ctor_O_O_Z_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A) Ctor_O_O_Z_O_O_O_O(c__i, c__desc any, c__ctor bool, c__lead, c__iter__851000250, c__mm, c__s__851000251 any) { t.F_i = c__i; t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_iter__851000250 = c__iter__851000250; t.F_mm = c__mm; t.F_s__851000251 = c__s__851000251 }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A) Invoke_O__O(self any) any { { var s__851000251__1 any; var t_ any = t.F_s__851000251; t.F_s__851000251 = nil; s__851000251__1 = t_; for { var temp__1927000414__auto____2 any; var root_2102 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = s__851000251__1; if linked_2103 == nil { temp__1927000414__auto____2 = ifn_2104.Invoke_O__O(arg_2105) } else { temp__1927000414__auto____2 = linked_2103.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2102, arg_2105) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000251__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2106 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = s__851000251__3; if linked_2107 == nil { tmp1 = ifn_2108.Invoke_O__O(arg_2109) } else { tmp1 = linked_2107.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2106, arg_2109) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2110 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2112 lang.IFn; if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = s__851000251__3; if linked_2111 == nil { c__1927001037__auto____4 = ifn_2112.Invoke_O__O(arg_2113) } else { c__1927001037__auto____4 = linked_2111.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2110, arg_2113) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000253__6 any; var root_2114 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2115 == nil { b__851000253__6 = ifn_2116.Invoke_O__O(arg_2117) } else { b__851000253__6 = linked_2115.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2114, arg_2117) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2133 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A_New_O_O_O_Z_O_O_I_O(t.F_i, t.F_desc, b__851000253__6, t.F_ctor, t.F_lead, t.F_mm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2132 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A_fn_class; if fncls__2132 == nil { var fncls__2132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__2133); A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A_fn_class = fncls__2132d; tmp3 = fncls__2132d } else { tmp3 = fncls__2132 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2133, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2134 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var root_2139 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = b__851000253__6; if linked_2140 == nil { arg_2137 = ifn_2141.Invoke_O__O(arg_2142) } else { arg_2137 = linked_2140.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2139, arg_2142) }; var arg_2138 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000250); var tmp5 any; var root_2143 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = s__851000251__3; if linked_2144 == nil { tmp5 = ifn_2145.Invoke_O__O(arg_2146) } else { tmp5 = linked_2144.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2143, arg_2146) }; arg_2138 = tmp4.Invoke_O__O(tmp5); if linked_2135 == nil { return ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { return linked_2135.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) } } else { var root_2147 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var root_2152 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = b__851000253__6; if linked_2153 == nil { arg_2150 = ifn_2154.Invoke_O__O(arg_2155) } else { arg_2150 = linked_2153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2152, arg_2155) }; var arg_2151 any; if linked_2148 == nil { return ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { return linked_2148.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) } } } else { var x__4 any; var root_2156 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = s__851000251__3; if linked_2157 == nil { x__4 = ifn_2158.Invoke_O__O(arg_2159) } else { x__4 = linked_2157.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2156, arg_2159) }; var root_2160 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any; var tmp6 *jrt.RefArray = jrt.ConstRefArray("[0,8,s2:P ns1: ns1: ns1: n", []*jrt.Class{jrt.String_class}); var tmp7 any








	if t.F_ctor { tmp7 = Lit_7 } else { tmp7 = A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_mm) }; var tmp8 any = tmp7; var tmp9 any; var root_2165 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_2166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2165, A_arbace_classes_annot_bin_A_fn_class); var ifn_2167 lang.IFn; if linked_2166 == nil { ifn_2167 = lang.IFn_Cast(root_2165) } else { ifn_2167 = nil }; var arg_2168 any = t.F_desc; if linked_2166 == nil { tmp9 = ifn_2167.Invoke_O__O(arg_2168) } else { tmp9 = linked_2166.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_2165, arg_2168) }; var tmp10 any = tmp9; var tmp11 jrt.Number_I; var na_2169 any = t.F_lead; var na_2170 any = t.F_i; var tmp12 bool; var tmp13 bool; tmp13 = jrt.Long_InstanceOf(na_2169); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_2170) }; tmp12 = tmp13; if tmp12 { var n0_2171 int64 = jrt.NN(jrt.Long_Cast(na_2169)).LongValue__J(); var n1_2172 int64 = jrt.NN(jrt.Long_Cast(na_2170)).LongValue__J(); var nr_2173 int64 = n0_2171 + n1_2172; if (n0_2171^nr_2173)&(n1_2172^nr_2173) >= 0 { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2173)) } else { tmp11 = lang.Numbers_Add_O_O__Number_NoInit(na_2169, na_2170) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_2169); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_2170) }; tmp14 = tmp15; if tmp14 { var n0_2171_2 float64 = jrt.NN(jrt.Double_Cast(na_2169)).DoubleValue__D(); var n1_2172_2 float64 = jrt.NN(jrt.Double_Cast(na_2170)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2171_2 + n1_2172_2)) } else { tmp11 = lang.Numbers_Add_O_O__Number_NoInit(na_2169, na_2170) } }; arg_2163 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp10, nil, tmp11, nil, x__4)).Ref()
//line :336:1
	var arg_2164 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__851000250); var tmp17 any; var root_2174 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2174, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2176 lang.IFn; if linked_2175 == nil { ifn_2176 = lang.IFn_Cast(root_2174) } else { ifn_2176 = nil }; var arg_2177 any = s__851000251__3; if linked_2175 == nil { tmp17 = ifn_2176.Invoke_O__O(arg_2177) } else { tmp17 = linked_2175.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2174, arg_2177) }; arg_2164 = tmp16.Invoke_O__O(tmp17); if linked_2161 == nil { return ifn_2162.Invoke_O_O__O(arg_2163, arg_2164) } else { return linked_2161.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2160, arg_2163, arg_2164) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :336:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A_New_O_O_O_Z_O_O_I_O(p0, p1, p2 any, p3 bool, p4, p5 any, p6 int32, p7 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A{}; t.Ctor_O_O_O_Z_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A) Ctor_O_O_O_Z_O_O_I_O(c__i, c__desc, c__b__851000253 any, c__ctor bool, c__lead, c__mm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_i = c__i; t.F_desc = c__desc; t.F_b__851000253 = c__b__851000253; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :336:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A) Invoke_O__O(self any) any { { var i__851000252__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000252__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000252__1)); var root_2118 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = t.F_b__851000253; var arg_2122 any; var tmp2 *jrt.RefArray = jrt.ConstRefArray("[0,8,s2:P ns1: ns1: ns1: n", []*jrt.Class{jrt.String_class}); var tmp3 any








	if t.F_ctor { tmp3 = Lit_7 } else { tmp3 = A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_mm) }; var tmp4 any = tmp3; var tmp5 any; var root_2123 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, A_arbace_classes_annot_bin_A_fn_class); var ifn_2125 lang.IFn; if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = t.F_desc; if linked_2124 == nil { tmp5 = ifn_2125.Invoke_O__O(arg_2126) } else { tmp5 = linked_2124.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_2123, arg_2126) }; var tmp6 any = tmp5; var tmp7 jrt.Number_I; var na_2127 any = t.F_lead; var na_2128 any = t.F_i; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_2127); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_2128) }; tmp8 = tmp9; if tmp8 { var n0_2129 int64 = jrt.NN(jrt.Long_Cast(na_2127)).LongValue__J(); var n1_2130 int64 = jrt.NN(jrt.Long_Cast(na_2128)).LongValue__J(); var nr_2131 int64 = n0_2129 + n1_2130; if (n0_2129^nr_2131)&(n1_2130^nr_2131) >= 0 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2131)) } else { tmp7 = lang.Numbers_Add_O_O__Number_NoInit(na_2127, na_2128) } } else { var tmp10 bool; var tmp11 bool; tmp11 = jrt.Double_InstanceOf(na_2127); if tmp11 { tmp11 = jrt.Double_InstanceOf(na_2128) }; tmp10 = tmp11; if tmp10 { var n0_2129_2 float64 = jrt.NN(jrt.Double_Cast(na_2127)).DoubleValue__D(); var n1_2130_2 float64 = jrt.NN(jrt.Double_Cast(na_2128)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2129_2 + n1_2130_2)) } else { tmp7 = lang.Numbers_Add_O_O__Number_NoInit(na_2127, na_2128) } }; arg_2122 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp6, nil, tmp7, nil, x__2)).Ref()
//line :336:1
	if linked_2119 == nil { ifn_2120.Invoke_O_O__O(arg_2121, arg_2122) } else { linked_2119.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2118, arg_2121, arg_2122) }; i__851000252__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000252__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :336:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_A_New_O(p0 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_A{}; t.Ctor_O(p0); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_A) Invoke_O_O__O(self, s__851000353__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2930 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A_New_O_O_O(s__851000353__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__2929 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A_fn_class; if fncls__2929 == nil { var fncls__2929d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__2930); A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A_fn_class = fncls__2929d; tmp2 = fncls__2929d } else { tmp2 = fncls__2929 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2930, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :336:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A) Ctor_O_O_O(c__s__851000353, c__n, c__iter__851000352 any) { t.F_s__851000353 = c__s__851000353; t.F_n = c__n; t.F_iter__851000352 = c__iter__851000352 }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A) Invoke_O__O(self any) any { { var s__851000353__1 any; var t_ any = t.F_s__851000353; t.F_s__851000353 = nil; s__851000353__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2770 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = s__851000353__1; if linked_2771 == nil { temp__1927000414__auto____2 = ifn_2772.Invoke_O__O(arg_2773) } else { temp__1927000414__auto____2 = linked_2771.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2770, arg_2773) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var mm__4 any; var root_2774 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2774, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2776 lang.IFn; if linked_2775 == nil { ifn_2776 = lang.IFn_Cast(root_2774) } else { ifn_2776 = nil }; var arg_2777 any = xs__1927001018__auto____3; if linked_2775 == nil { mm__4 = ifn_2776.Invoke_O__O(arg_2777) } else { mm__4 = linked_2775.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2774, arg_2777) }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_annot_A_const_168); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4))) { var tmp2 any = A_arbace_classes_annot_A_const_97; var ctor__5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_annot_A_const_79.Invoke_O__O(mm__4)); var desc__6 any




	if ctor__5 { var root_2778 any = A_arbace_classes_annot_A_const_75.GetRawRoot__O(); var linked_2779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2778, A_arbace_classes_annot_safe_ctor_desc_A_fn_class); var ifn_2780 lang.IFn; if linked_2779 == nil { ifn_2780 = lang.IFn_Cast(root_2778) } else { ifn_2780 = nil }; var arg_2781 any = t.F_n; var arg_2782 any = mm__4; if linked_2779 == nil { desc__6 = ifn_2780.Invoke_O_O__O(arg_2781, arg_2782) } else { desc__6 = linked_2779.(*A_arbace_classes_annot_safe_ctor_desc_A).Invoke_O_O_O__O(root_2778, arg_2781, arg_2782) } } else { desc__6 = A_arbace_classes_annot_A_const_34.Invoke_O__O(mm__4) }
//line :336:1
	var lead__7 any





	if ctor__5 { var tmp3 *lang.Compiler_AOTFn; var fnbody__2789 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A_New_O_O(t.F_n, mm__4); var tmp4 *jrt.Class; var fncls__2788 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A_fn_class; if fncls__2788 == nil { var fncls__2788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__2789); A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A_fn_class = fncls__2788d; tmp4 = fncls__2788d } else { tmp4 = fncls__2788 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2789, tmp4, nil); lead__7 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O() } else { lead__7 = A_arbace_classes_annot_A_const_73 }
//line :336:1
	var iterys__1927001035__auto____8 any; var fnbody__2902 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A_New_O_Z_O_O(desc__6, ctor__5, lead__7, mm__4); var tmp5 *jrt.Class; var fncls__2901 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A_fn_class; if fncls__2901 == nil { var fncls__2901d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__2902); A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A_fn_class = fncls__2901d; tmp5 = fncls__2901d } else { tmp5 = fncls__2901 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2902, tmp5, nil); var fs__1927001036__auto____9 any; var root_2903 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2903, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2905 lang.IFn; if linked_2904 == nil { ifn_2905 = lang.IFn_Cast(root_2903) } else { ifn_2905 = nil }; var arg_2906 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp7 any; var root_2907 any = A_arbace_classes_annot_A_const_163.GetRawRoot__O(); var linked_2908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2907, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2909 lang.IFn






	if linked_2908 == nil { ifn_2909 = lang.IFn_Cast(root_2907) } else { ifn_2909 = nil }; var arg_2910 any = A_arbace_classes_annot_A_const_164.GetRawRoot__O(); var arg_2911 any = A_arbace_classes_annot_A_const_165.Invoke_O__O(mm__4); if linked_2908 == nil { tmp7 = ifn_2909.Invoke_O_O__O(arg_2910, arg_2911) } else { tmp7 = linked_2908.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2907, arg_2910, arg_2911) }
//line :336:1
	arg_2906 = tmp6.Invoke_O__O(tmp7); if linked_2904 == nil { fs__1927001036__auto____9 = ifn_2905.Invoke_O__O(arg_2906) } else { fs__1927001036__auto____9 = linked_2904.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2903, arg_2906) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_2912 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2913 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2912, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2914 lang.IFn; if linked_2913 == nil { ifn_2914 = lang.IFn_Cast(root_2912) } else { ifn_2914 = nil }; var arg_2915 any = fs__1927001036__auto____9; var arg_2916 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__851000352); var tmp9 any; var root_2917 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2917, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2919 lang.IFn; if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any = s__851000353__1; if linked_2918 == nil { tmp9 = ifn_2919.Invoke_O__O(arg_2920) } else { tmp9 = linked_2918.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2917, arg_2920) }; arg_2916 = tmp8.Invoke_O__O(tmp9); if linked_2913 == nil { return ifn_2914.Invoke_O_O__O(arg_2915, arg_2916) } else { return linked_2913.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2912, arg_2915, arg_2916) } } else { var tmp10 any; var root_2921 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2921, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2923 lang.IFn; if linked_2922 == nil { ifn_2923 = lang.IFn_Cast(root_2921) } else { ifn_2923 = nil }; var arg_2924 any = s__851000353__1; if linked_2922 == nil { tmp10 = ifn_2923.Invoke_O__O(arg_2924) } else { tmp10 = linked_2922.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2921, arg_2924) }; s__851000353__1 = tmp10; continue L1 } } else { var tmp11 any; var root_2925 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any = s__851000353__1; if linked_2926 == nil { tmp11 = ifn_2927.Invoke_O__O(arg_2928) } else { tmp11 = linked_2926.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2925, arg_2928) }; s__851000353__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :336:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A_New_O_Z_O_O(p0 any, p1 bool, p2, p3 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A{}; t.Ctor_O_Z_O_O(p0, p1, p2, p3); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A) Ctor_O_Z_O_O(c__desc any, c__ctor bool, c__lead, c__mm any) { t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A) Invoke_O_O__O(self, s__851000355__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2900 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A_New_O_O_Z_O_O_O(s__851000355__1, t.F_desc, t.F_ctor, t.F_lead, t.F_mm, self); var tmp2 *jrt.Class; var fncls__2899 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A_fn_class; if fncls__2899 == nil { var fncls__2899d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__2900); A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A_fn_class = fncls__2899d; tmp2 = fncls__2899d } else { tmp2 = fncls__2899 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2900, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :336:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A_New_O_O_Z_O_O_O(p0, p1 any, p2 bool, p3, p4, p5 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A{}; t.Ctor_O_O_Z_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A) Ctor_O_O_Z_O_O_O(c__s__851000355, c__desc any, c__ctor bool, c__lead, c__mm, c__iter__851000354 any) { t.F_s__851000355 = c__s__851000355; t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm; t.F_iter__851000354 = c__iter__851000354 }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A) Invoke_O__O(self any) any { { var s__851000355__1 any; var t_ any = t.F_s__851000355; t.F_s__851000355 = nil; s__851000355__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2790 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any = s__851000355__1; if linked_2791 == nil { temp__1927000414__auto____2 = ifn_2792.Invoke_O__O(arg_2793) } else { temp__1927000414__auto____2 = linked_2791.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2790, arg_2793) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__851000366__4 any; var root_2794 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2794, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2796 lang.IFn; if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any = xs__1927001018__auto____3; if linked_2795 == nil { vec__851000366__4 = ifn_2796.Invoke_O__O(arg_2797) } else { vec__851000366__4 = linked_2795.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2794, arg_2797) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000366__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pa__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__851000366__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__2877 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A_New_O_O_Z_O_O(i__5, t.F_desc, t.F_ctor, t.F_lead, t.F_mm); var tmp1 *jrt.Class; var fncls__2876 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A_fn_class; if fncls__2876 == nil { var fncls__2876d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__2877); A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A_fn_class = fncls__2876d; tmp1 = fncls__2876d } else { tmp1 = fncls__2876 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2877, tmp1, nil); var fs__1927001036__auto____8 any; var root_2878 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2878, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2880 lang.IFn; if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp3 any; var root_2882 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_2883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2882, A_arbace_classes_annot_visible_A_fn_class); var ifn_2884 lang.IFn







	if linked_2883 == nil { ifn_2884 = lang.IFn_Cast(root_2882) } else { ifn_2884 = nil }; var arg_2885 any = pa__6; if linked_2883 == nil { tmp3 = ifn_2884.Invoke_O__O(arg_2885) } else { tmp3 = linked_2883.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_2882, arg_2885) }
//line :336:1
	arg_2881 = tmp2.Invoke_O__O(tmp3); if linked_2879 == nil { fs__1927001036__auto____8 = ifn_2880.Invoke_O__O(arg_2881) } else { fs__1927001036__auto____8 = linked_2879.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2878, arg_2881) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2886 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2886, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2888 lang.IFn; if linked_2887 == nil { ifn_2888 = lang.IFn_Cast(root_2886) } else { ifn_2888 = nil }; var arg_2889 any = fs__1927001036__auto____8; var arg_2890 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000354); var tmp5 any; var root_2891 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2891, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any = s__851000355__1; if linked_2892 == nil { tmp5 = ifn_2893.Invoke_O__O(arg_2894) } else { tmp5 = linked_2892.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2891, arg_2894) }; arg_2890 = tmp4.Invoke_O__O(tmp5); if linked_2887 == nil { return ifn_2888.Invoke_O_O__O(arg_2889, arg_2890) } else { return linked_2887.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2886, arg_2889, arg_2890) } } else { var tmp6 any; var root_2895 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = s__851000355__1; if linked_2896 == nil { tmp6 = ifn_2897.Invoke_O__O(arg_2898) } else { tmp6 = linked_2896.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2895, arg_2898) }; s__851000355__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :336:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A_New_O_O_Z_O_O(p0, p1 any, p2 bool, p3, p4 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A{}; t.Ctor_O_O_Z_O_O(p0, p1, p2, p3, p4); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A) Ctor_O_O_Z_O_O(c__i, c__desc any, c__ctor bool, c__lead, c__mm any) { t.F_i = c__i; t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A) Invoke_O_O__O(self, s__851000357__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2875 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A_New_O_O_O_O_Z_O_O(self, t.F_i, s__851000357__1, t.F_desc, t.F_ctor, t.F_lead, t.F_mm); var tmp2 *jrt.Class; var fncls__2874 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A_fn_class; if fncls__2874 == nil { var fncls__2874d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__2875); A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A_fn_class = fncls__2874d; tmp2 = fncls__2874d } else { tmp2 = fncls__2874 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2875, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :336:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A_New_O_O_O_O_Z_O_O(p0, p1, p2, p3 any, p4 bool, p5, p6 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A{}; t.Ctor_O_O_O_O_Z_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A) Ctor_O_O_O_O_Z_O_O(c__iter__851000356, c__i, c__s__851000357, c__desc any, c__ctor bool, c__lead, c__mm any) { t.F_iter__851000356 = c__iter__851000356; t.F_i = c__i; t.F_s__851000357 = c__s__851000357; t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_lead = c__lead; t.F_mm = c__mm }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A) Invoke_O__O(self any) any { { var s__851000357__1 any; var t_ any = t.F_s__851000357; t.F_s__851000357 = nil; s__851000357__1 = t_; for { var temp__1927000414__auto____2 any; var root_2798 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2798, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2800 lang.IFn; if linked_2799 == nil { ifn_2800 = lang.IFn_Cast(root_2798) } else { ifn_2800 = nil }; var arg_2801 any = s__851000357__1; if linked_2799 == nil { temp__1927000414__auto____2 = ifn_2800.Invoke_O__O(arg_2801) } else { temp__1927000414__auto____2 = linked_2799.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2798, arg_2801) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000357__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2802 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2804 lang.IFn; if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any = s__851000357__3; if linked_2803 == nil { tmp1 = ifn_2804.Invoke_O__O(arg_2805) } else { tmp1 = linked_2803.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2802, arg_2805) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2806 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2806, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2808 lang.IFn; if linked_2807 == nil { ifn_2808 = lang.IFn_Cast(root_2806) } else { ifn_2808 = nil }; var arg_2809 any = s__851000357__3; if linked_2807 == nil { c__1927001037__auto____4 = ifn_2808.Invoke_O__O(arg_2809) } else { c__1927001037__auto____4 = linked_2807.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2806, arg_2809) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000359__6 any; var root_2810 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2810, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2812 lang.IFn; if linked_2811 == nil { ifn_2812 = lang.IFn_Cast(root_2810) } else { ifn_2812 = nil }; var arg_2813 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2811 == nil { b__851000359__6 = ifn_2812.Invoke_O__O(arg_2813) } else { b__851000359__6 = linked_2811.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2810, arg_2813) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2829 any = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A_New_O_O_Z_O_O_O_I_O(t.F_i, t.F_desc, t.F_ctor, b__851000359__6, t.F_lead, t.F_mm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2828 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A_fn_class; if fncls__2828 == nil { var fncls__2828d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__2829); A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A_fn_class = fncls__2828d; tmp3 = fncls__2828d } else { tmp3 = fncls__2828 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2829, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2830 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2830, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2832 lang.IFn; if linked_2831 == nil { ifn_2832 = lang.IFn_Cast(root_2830) } else { ifn_2832 = nil }; var arg_2833 any; var root_2835 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2837 lang.IFn; if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = b__851000359__6; if linked_2836 == nil { arg_2833 = ifn_2837.Invoke_O__O(arg_2838) } else { arg_2833 = linked_2836.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2835, arg_2838) }; var arg_2834 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000356); var tmp5 any; var root_2839 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2839, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2841 lang.IFn; if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var arg_2842 any = s__851000357__3; if linked_2840 == nil { tmp5 = ifn_2841.Invoke_O__O(arg_2842) } else { tmp5 = linked_2840.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2839, arg_2842) }; arg_2834 = tmp4.Invoke_O__O(tmp5); if linked_2831 == nil { return ifn_2832.Invoke_O_O__O(arg_2833, arg_2834) } else { return linked_2831.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2830, arg_2833, arg_2834) } } else { var root_2843 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2843, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2845 lang.IFn; if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any; var root_2848 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2848, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2850 lang.IFn; if linked_2849 == nil { ifn_2850 = lang.IFn_Cast(root_2848) } else { ifn_2850 = nil }; var arg_2851 any = b__851000359__6; if linked_2849 == nil { arg_2846 = ifn_2850.Invoke_O__O(arg_2851) } else { arg_2846 = linked_2849.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2848, arg_2851) }; var arg_2847 any; if linked_2844 == nil { return ifn_2845.Invoke_O_O__O(arg_2846, arg_2847) } else { return linked_2844.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2843, arg_2846, arg_2847) } } } else { var x__4 any; var root_2852 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2852, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2854 lang.IFn; if linked_2853 == nil { ifn_2854 = lang.IFn_Cast(root_2852) } else { ifn_2854 = nil }; var arg_2855 any = s__851000357__3; if linked_2853 == nil { x__4 = ifn_2854.Invoke_O__O(arg_2855) } else { x__4 = linked_2853.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2852, arg_2855) }; var root_2856 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2856, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2858 lang.IFn; if linked_2857 == nil { ifn_2858 = lang.IFn_Cast(root_2856) } else { ifn_2858 = nil }; var arg_2859 any; var tmp6 *jrt.RefArray = jrt.ConstRefArray("[0,8,s2:P ns1: ns1: ns1: n", []*jrt.Class{jrt.String_class}); var tmp7 any








	if t.F_ctor { tmp7 = Lit_7 } else { tmp7 = A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_mm) }; var tmp8 any = tmp7; var tmp9 any; var root_2861 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, A_arbace_classes_annot_bin_A_fn_class); var ifn_2863 lang.IFn; if linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any = t.F_desc; if linked_2862 == nil { tmp9 = ifn_2863.Invoke_O__O(arg_2864) } else { tmp9 = linked_2862.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_2861, arg_2864) }; var tmp10 any = tmp9; var tmp11 jrt.Number_I; var na_2865 any = t.F_lead; var na_2866 any = t.F_i; var tmp12 bool; var tmp13 bool; tmp13 = jrt.Long_InstanceOf(na_2865); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_2866) }; tmp12 = tmp13; if tmp12 { var n0_2867 int64 = jrt.NN(jrt.Long_Cast(na_2865)).LongValue__J(); var n1_2868 int64 = jrt.NN(jrt.Long_Cast(na_2866)).LongValue__J(); var nr_2869 int64 = n0_2867 + n1_2868; if (n0_2867^nr_2869)&(n1_2868^nr_2869) >= 0 { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2869)) } else { tmp11 = lang.Numbers_Add_O_O__Number_NoInit(na_2865, na_2866) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_2865); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_2866) }; tmp14 = tmp15; if tmp14 { var n0_2867_2 float64 = jrt.NN(jrt.Double_Cast(na_2865)).DoubleValue__D(); var n1_2868_2 float64 = jrt.NN(jrt.Double_Cast(na_2866)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2867_2 + n1_2868_2)) } else { tmp11 = lang.Numbers_Add_O_O__Number_NoInit(na_2865, na_2866) } }; arg_2859 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp10, nil, tmp11, nil, x__4)).Ref()
//line :336:1
	var arg_2860 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__851000356); var tmp17 any; var root_2870 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2870, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2872 lang.IFn; if linked_2871 == nil { ifn_2872 = lang.IFn_Cast(root_2870) } else { ifn_2872 = nil }; var arg_2873 any = s__851000357__3; if linked_2871 == nil { tmp17 = ifn_2872.Invoke_O__O(arg_2873) } else { tmp17 = linked_2871.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2870, arg_2873) }; arg_2860 = tmp16.Invoke_O__O(tmp17); if linked_2857 == nil { return ifn_2858.Invoke_O_O__O(arg_2859, arg_2860) } else { return linked_2857.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2856, arg_2859, arg_2860) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :336:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A_New_O_O_Z_O_O_O_I_O(p0, p1 any, p2 bool, p3, p4, p5 any, p6 int32, p7 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A{}; t.Ctor_O_O_Z_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A) Ctor_O_O_Z_O_O_O_I_O(c__i, c__desc any, c__ctor bool, c__b__851000359, c__lead, c__mm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_i = c__i; t.F_desc = c__desc; t.F_ctor = c__ctor; t.F_b__851000359 = c__b__851000359; t.F_lead = c__lead; t.F_mm = c__mm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :336:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A) Invoke_O__O(self any) any { { var i__851000358__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000358__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000358__1)); var root_2814 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2814, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2816 lang.IFn; if linked_2815 == nil { ifn_2816 = lang.IFn_Cast(root_2814) } else { ifn_2816 = nil }; var arg_2817 any = t.F_b__851000359; var arg_2818 any; var tmp2 *jrt.RefArray = jrt.ConstRefArray("[0,8,s2:P ns1: ns1: ns1: n", []*jrt.Class{jrt.String_class}); var tmp3 any








	if t.F_ctor { tmp3 = Lit_7 } else { tmp3 = A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_mm) }; var tmp4 any = tmp3; var tmp5 any; var root_2819 any = A_arbace_classes_annot_A_const_33.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2819, A_arbace_classes_annot_bin_A_fn_class); var ifn_2821 lang.IFn; if linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any = t.F_desc; if linked_2820 == nil { tmp5 = ifn_2821.Invoke_O__O(arg_2822) } else { tmp5 = linked_2820.(*A_arbace_classes_annot_bin_A).Invoke_O_O__O(root_2819, arg_2822) }; var tmp6 any = tmp5; var tmp7 jrt.Number_I; var na_2823 any = t.F_lead; var na_2824 any = t.F_i; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_2823); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_2824) }; tmp8 = tmp9; if tmp8 { var n0_2825 int64 = jrt.NN(jrt.Long_Cast(na_2823)).LongValue__J(); var n1_2826 int64 = jrt.NN(jrt.Long_Cast(na_2824)).LongValue__J(); var nr_2827 int64 = n0_2825 + n1_2826; if (n0_2825^nr_2827)&(n1_2826^nr_2827) >= 0 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2827)) } else { tmp7 = lang.Numbers_Add_O_O__Number_NoInit(na_2823, na_2824) } } else { var tmp10 bool; var tmp11 bool; tmp11 = jrt.Double_InstanceOf(na_2823); if tmp11 { tmp11 = jrt.Double_InstanceOf(na_2824) }; tmp10 = tmp11; if tmp10 { var n0_2825_2 float64 = jrt.NN(jrt.Double_Cast(na_2823)).DoubleValue__D(); var n1_2826_2 float64 = jrt.NN(jrt.Double_Cast(na_2824)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2825_2 + n1_2826_2)) } else { tmp7 = lang.Numbers_Add_O_O__Number_NoInit(na_2823, na_2824) } }; arg_2818 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp6, nil, tmp7, nil, x__2)).Ref()
//line :336:1
	if linked_2815 == nil { ifn_2816.Invoke_O_O__O(arg_2817, arg_2818) } else { linked_2815.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2814, arg_2817, arg_2818) }; i__851000358__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000358__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A{}; t.Ctor_O_O(p0, p1); return t }
//line :342:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A) Ctor_O_O(c__n, c__mm any) { t.F_n = c__n; t.F_mm = c__mm }
//line :342:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2087 any = A_arbace_classes_annot_A_const_162.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, A_arbace_classes_annot_ctor_lead_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any; var t_ any = t.F_n; t.F_n = nil; arg_2090 = t_; var arg_2091 any; var t__2 any = t.F_mm; t.F_mm = nil; arg_2091 = t__2; if linked_2088 == nil { tmp1 = ifn_2089.Invoke_O_O__O(arg_2090, arg_2091) } else { tmp1 = linked_2088.(*A_arbace_classes_annot_ctor_lead_A).Invoke_O_O_O__O(root_2087, arg_2090, arg_2091) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = A_arbace_classes_annot_A_const_73 } else { panic(tmp2) } }; return tmp1 }
//line :342:1
func A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A{}; t.Ctor_O_O(p0, p1); return t }
//line :342:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A) Ctor_O_O(c__n, c__mm any) { t.F_n = c__n; t.F_mm = c__mm }
//line :342:1
func (t *A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2783 any = A_arbace_classes_annot_A_const_162.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, A_arbace_classes_annot_ctor_lead_A_fn_class); var ifn_2785 lang.IFn; if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; var arg_2786 any; var t_ any = t.F_n; t.F_n = nil; arg_2786 = t_; var arg_2787 any; var t__2 any = t.F_mm; t.F_mm = nil; arg_2787 = t__2; if linked_2784 == nil { tmp1 = ifn_2785.Invoke_O_O__O(arg_2786, arg_2787) } else { tmp1 = linked_2784.(*A_arbace_classes_annot_ctor_lead_A).Invoke_O_O_O__O(root_2783, arg_2786, arg_2787) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp2); _ = ___3; tmp1 = A_arbace_classes_annot_A_const_73 } else { panic(tmp2) } }; return tmp1 }



func A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A_New() *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A) Ctor() {}
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A) Invoke_O_O__O(self, s__851000274__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2329 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A_New_O_O(self, s__851000274__1); var tmp2 *jrt.Class; var fncls__2328 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A_fn_class; if fncls__2328 == nil { var fncls__2328d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__2329); A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A_fn_class = fncls__2328d; tmp2 = fncls__2328d } else { tmp2 = fncls__2328 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2329, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :346:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A{}; t.Ctor_O_O(p0, p1); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A) Ctor_O_O(c__iter__851000273, c__s__851000274 any) { t.F_iter__851000273 = c__iter__851000273; t.F_s__851000274 = c__s__851000274 }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A) Invoke_O__O(self any) any { { var s__851000274__1 any; var t_ any = t.F_s__851000274; t.F_s__851000274 = nil; s__851000274__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2237 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = s__851000274__1; if linked_2238 == nil { temp__1927000414__auto____2 = ifn_2239.Invoke_O__O(arg_2240) } else { temp__1927000414__auto____2 = linked_2238.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2237, arg_2240) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_2241 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = xs__1927001018__auto____3; if linked_2242 == nil { f__4 = ifn_2243.Invoke_O__O(arg_2244) } else { f__4 = linked_2242.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2241, arg_2244) }; var iterys__1927001035__auto____5 any; var fnbody__2306 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A_New_O(f__4); var tmp1 *jrt.Class; var fncls__2305 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A_fn_class; if fncls__2305 == nil { var fncls__2305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__2306); A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A_fn_class = fncls__2305d; tmp1 = fncls__2305d } else { tmp1 = fncls__2305 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2306, tmp1, nil); var fs__1927001036__auto____6 any; var root_2307 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_2311 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, A_arbace_classes_annot_visible_A_fn_class); var ifn_2313 lang.IFn
																if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(f__4); if linked_2312 == nil { tmp3 = ifn_2313.Invoke_O__O(arg_2314) } else { tmp3 = linked_2312.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_2311, arg_2314) }
//line :346:1
	arg_2310 = tmp2.Invoke_O__O(tmp3); if linked_2308 == nil { fs__1927001036__auto____6 = ifn_2309.Invoke_O__O(arg_2310) } else { fs__1927001036__auto____6 = linked_2308.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2307, arg_2310) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2315 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2315, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = fs__1927001036__auto____6; var arg_2319 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000273); var tmp5 any; var root_2320 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = s__851000274__1; if linked_2321 == nil { tmp5 = ifn_2322.Invoke_O__O(arg_2323) } else { tmp5 = linked_2321.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2320, arg_2323) }; arg_2319 = tmp4.Invoke_O__O(tmp5); if linked_2316 == nil { return ifn_2317.Invoke_O_O__O(arg_2318, arg_2319) } else { return linked_2316.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2315, arg_2318, arg_2319) } } else { var tmp6 any; var root_2324 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2324, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2326 lang.IFn; if linked_2325 == nil { ifn_2326 = lang.IFn_Cast(root_2324) } else { ifn_2326 = nil }; var arg_2327 any = s__851000274__1; if linked_2325 == nil { tmp6 = ifn_2326.Invoke_O__O(arg_2327) } else { tmp6 = linked_2325.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2324, arg_2327) }; s__851000274__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :346:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A_New_O(p0 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A{}; t.Ctor_O(p0); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A) Invoke_O_O__O(self, s__851000276__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2304 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A_New_O_O_O(s__851000276__1, t.F_f, self); var tmp2 *jrt.Class; var fncls__2303 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A_fn_class; if fncls__2303 == nil { var fncls__2303d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__2304); A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A_fn_class = fncls__2303d; tmp2 = fncls__2303d } else { tmp2 = fncls__2303 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2304, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :346:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A) Ctor_O_O_O(c__s__851000276, c__f, c__iter__851000275 any) { t.F_s__851000276 = c__s__851000276; t.F_f = c__f; t.F_iter__851000275 = c__iter__851000275 }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A) Invoke_O__O(self any) any { { var s__851000276__1 any; var t_ any = t.F_s__851000276; t.F_s__851000276 = nil; s__851000276__1 = t_; for { var temp__1927000414__auto____2 any; var root_2245 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = s__851000276__1; if linked_2246 == nil { temp__1927000414__auto____2 = ifn_2247.Invoke_O__O(arg_2248) } else { temp__1927000414__auto____2 = linked_2246.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2245, arg_2248) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000276__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2249 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = s__851000276__3; if linked_2250 == nil { tmp1 = ifn_2251.Invoke_O__O(arg_2252) } else { tmp1 = linked_2250.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2249, arg_2252) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2253 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = s__851000276__3; if linked_2254 == nil { c__1927001037__auto____4 = ifn_2255.Invoke_O__O(arg_2256) } else { c__1927001037__auto____4 = linked_2254.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2253, arg_2256) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000278__6 any; var root_2257 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2258 == nil { b__851000278__6 = ifn_2259.Invoke_O__O(arg_2260) } else { b__851000278__6 = linked_2258.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2257, arg_2260) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2267 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A_New_O_O_I_O(t.F_f, b__851000278__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2266 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A_fn_class; if fncls__2266 == nil { var fncls__2266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__2267); A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A_fn_class = fncls__2266d; tmp3 = fncls__2266d } else { tmp3 = fncls__2266 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2267, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2268 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any; var root_2273 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2275 lang.IFn; if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any = b__851000278__6; if linked_2274 == nil { arg_2271 = ifn_2275.Invoke_O__O(arg_2276) } else { arg_2271 = linked_2274.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2273, arg_2276) }; var arg_2272 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000275); var tmp5 any; var root_2277 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = s__851000276__3; if linked_2278 == nil { tmp5 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp5 = linked_2278.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2277, arg_2280) }; arg_2272 = tmp4.Invoke_O__O(tmp5); if linked_2269 == nil { return ifn_2270.Invoke_O_O__O(arg_2271, arg_2272) } else { return linked_2269.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2268, arg_2271, arg_2272) } } else { var root_2281 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any; var root_2286 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = b__851000278__6; if linked_2287 == nil { arg_2284 = ifn_2288.Invoke_O__O(arg_2289) } else { arg_2284 = linked_2287.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2286, arg_2289) }; var arg_2285 any; if linked_2282 == nil { return ifn_2283.Invoke_O_O__O(arg_2284, arg_2285) } else { return linked_2282.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2281, arg_2284, arg_2285) } } } else { var x__4 any; var root_2290 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = s__851000276__3; if linked_2291 == nil { x__4 = ifn_2292.Invoke_O__O(arg_2293) } else { x__4 = linked_2291.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2290, arg_2293) }; var root_2294 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2294, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2296 lang.IFn; if linked_2295 == nil { ifn_2296 = lang.IFn_Cast(root_2294) } else { ifn_2296 = nil }; var arg_2297 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_f), nil, x__4)).Ref(); var arg_2298 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000275); var tmp7 any; var root_2299 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = s__851000276__3; if linked_2300 == nil { tmp7 = ifn_2301.Invoke_O__O(arg_2302) } else { tmp7 = linked_2300.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2299, arg_2302) }; arg_2298 = tmp6.Invoke_O__O(tmp7); if linked_2295 == nil { return ifn_2296.Invoke_O_O__O(arg_2297, arg_2298) } else { return linked_2295.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2294, arg_2297, arg_2298) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :346:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A) Ctor_O_O_I_O(c__f, c__b__851000278 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_b__851000278 = c__b__851000278; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :346:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A) Invoke_O__O(self any) any { { var i__851000277__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000277__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000277__1)); var root_2261 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = t.F_b__851000278; var arg_2265 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_f), nil, x__2)).Ref(); if linked_2262 == nil { ifn_2263.Invoke_O_O__O(arg_2264, arg_2265) } else { linked_2262.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2261, arg_2264, arg_2265) }; i__851000277__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000277__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :346:1
func A_arbace_classes_annot_class_data_iter__851000379__851000385_A_New() *A_arbace_classes_annot_class_data_iter__851000379__851000385_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000379__851000385_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_A) Ctor() {}
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_A) Invoke_O_O__O(self, s__851000380__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3025 any = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A_New_O_O(self, s__851000380__1); var tmp2 *jrt.Class; var fncls__3024 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A_fn_class; if fncls__3024 == nil { var fncls__3024d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__3025); A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A_fn_class = fncls__3024d; tmp2 = fncls__3024d } else { tmp2 = fncls__3024 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3025, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :346:1
func A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A{}; t.Ctor_O_O(p0, p1); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A) Ctor_O_O(c__iter__851000379, c__s__851000380 any) { t.F_iter__851000379 = c__iter__851000379; t.F_s__851000380 = c__s__851000380 }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A) Invoke_O__O(self any) any { { var s__851000380__1 any; var t_ any = t.F_s__851000380; t.F_s__851000380 = nil; s__851000380__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2933 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2933, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2935 lang.IFn; if linked_2934 == nil { ifn_2935 = lang.IFn_Cast(root_2933) } else { ifn_2935 = nil }; var arg_2936 any = s__851000380__1; if linked_2934 == nil { temp__1927000414__auto____2 = ifn_2935.Invoke_O__O(arg_2936) } else { temp__1927000414__auto____2 = linked_2934.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2933, arg_2936) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_2937 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2937, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2939 lang.IFn; if linked_2938 == nil { ifn_2939 = lang.IFn_Cast(root_2937) } else { ifn_2939 = nil }; var arg_2940 any = xs__1927001018__auto____3; if linked_2938 == nil { f__4 = ifn_2939.Invoke_O__O(arg_2940) } else { f__4 = linked_2938.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2937, arg_2940) }; var iterys__1927001035__auto____5 any; var fnbody__3002 any = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A_New_O(f__4); var tmp1 *jrt.Class; var fncls__3001 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A_fn_class; if fncls__3001 == nil { var fncls__3001d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__3002); A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A_fn_class = fncls__3001d; tmp1 = fncls__3001d } else { tmp1 = fncls__3001 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3002, tmp1, nil); var fs__1927001036__auto____6 any; var root_3003 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_3007 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_3008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3007, A_arbace_classes_annot_visible_A_fn_class); var ifn_3009 lang.IFn
															if linked_3008 == nil { ifn_3009 = lang.IFn_Cast(root_3007) } else { ifn_3009 = nil }; var arg_3010 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(f__4); if linked_3008 == nil { tmp3 = ifn_3009.Invoke_O__O(arg_3010) } else { tmp3 = linked_3008.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_3007, arg_3010) }
//line :346:1
	arg_3006 = tmp2.Invoke_O__O(tmp3); if linked_3004 == nil { fs__1927001036__auto____6 = ifn_3005.Invoke_O__O(arg_3006) } else { fs__1927001036__auto____6 = linked_3004.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3003, arg_3006) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3011 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_3012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3011, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3013 lang.IFn; if linked_3012 == nil { ifn_3013 = lang.IFn_Cast(root_3011) } else { ifn_3013 = nil }; var arg_3014 any = fs__1927001036__auto____6; var arg_3015 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000379); var tmp5 any; var root_3016 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any = s__851000380__1; if linked_3017 == nil { tmp5 = ifn_3018.Invoke_O__O(arg_3019) } else { tmp5 = linked_3017.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3016, arg_3019) }; arg_3015 = tmp4.Invoke_O__O(tmp5); if linked_3012 == nil { return ifn_3013.Invoke_O_O__O(arg_3014, arg_3015) } else { return linked_3012.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3011, arg_3014, arg_3015) } } else { var tmp6 any; var root_3020 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3022 lang.IFn; if linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any = s__851000380__1; if linked_3021 == nil { tmp6 = ifn_3022.Invoke_O__O(arg_3023) } else { tmp6 = linked_3021.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3020, arg_3023) }; s__851000380__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :346:1
func A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A_New_O(p0 any) *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A{}; t.Ctor_O(p0); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A) Invoke_O_O__O(self, s__851000382__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3000 any = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A_New_O_O_O(t.F_f, self, s__851000382__1); var tmp2 *jrt.Class; var fncls__2999 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A_fn_class; if fncls__2999 == nil { var fncls__2999d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__3000); A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A_fn_class = fncls__2999d; tmp2 = fncls__2999d } else { tmp2 = fncls__2999 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3000, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :346:1
func A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A) Ctor_O_O_O(c__f, c__iter__851000381, c__s__851000382 any) { t.F_f = c__f; t.F_iter__851000381 = c__iter__851000381; t.F_s__851000382 = c__s__851000382 }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A) Invoke_O__O(self any) any { { var s__851000382__1 any; var t_ any = t.F_s__851000382; t.F_s__851000382 = nil; s__851000382__1 = t_; for { var temp__1927000414__auto____2 any; var root_2941 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2941, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2943 lang.IFn; if linked_2942 == nil { ifn_2943 = lang.IFn_Cast(root_2941) } else { ifn_2943 = nil }; var arg_2944 any = s__851000382__1; if linked_2942 == nil { temp__1927000414__auto____2 = ifn_2943.Invoke_O__O(arg_2944) } else { temp__1927000414__auto____2 = linked_2942.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2941, arg_2944) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000382__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2945 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2945, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2947 lang.IFn; if linked_2946 == nil { ifn_2947 = lang.IFn_Cast(root_2945) } else { ifn_2947 = nil }; var arg_2948 any = s__851000382__3; if linked_2946 == nil { tmp1 = ifn_2947.Invoke_O__O(arg_2948) } else { tmp1 = linked_2946.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2945, arg_2948) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2949 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2951 lang.IFn; if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; var arg_2952 any = s__851000382__3; if linked_2950 == nil { c__1927001037__auto____4 = ifn_2951.Invoke_O__O(arg_2952) } else { c__1927001037__auto____4 = linked_2950.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2949, arg_2952) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000384__6 any; var root_2953 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2953, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2955 lang.IFn; if linked_2954 == nil { ifn_2955 = lang.IFn_Cast(root_2953) } else { ifn_2955 = nil }; var arg_2956 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2954 == nil { b__851000384__6 = ifn_2955.Invoke_O__O(arg_2956) } else { b__851000384__6 = linked_2954.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2953, arg_2956) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2963 any = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A_New_O_O_I_O(t.F_f, b__851000384__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2962 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A_fn_class; if fncls__2962 == nil { var fncls__2962d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__2963); A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A_fn_class = fncls__2962d; tmp3 = fncls__2962d } else { tmp3 = fncls__2962 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2963, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2964 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2964, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2966 lang.IFn; if linked_2965 == nil { ifn_2966 = lang.IFn_Cast(root_2964) } else { ifn_2966 = nil }; var arg_2967 any; var root_2969 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2969, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2971 lang.IFn; if linked_2970 == nil { ifn_2971 = lang.IFn_Cast(root_2969) } else { ifn_2971 = nil }; var arg_2972 any = b__851000384__6; if linked_2970 == nil { arg_2967 = ifn_2971.Invoke_O__O(arg_2972) } else { arg_2967 = linked_2970.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2969, arg_2972) }; var arg_2968 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000381); var tmp5 any; var root_2973 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2973, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2975 lang.IFn; if linked_2974 == nil { ifn_2975 = lang.IFn_Cast(root_2973) } else { ifn_2975 = nil }; var arg_2976 any = s__851000382__3; if linked_2974 == nil { tmp5 = ifn_2975.Invoke_O__O(arg_2976) } else { tmp5 = linked_2974.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2973, arg_2976) }; arg_2968 = tmp4.Invoke_O__O(tmp5); if linked_2965 == nil { return ifn_2966.Invoke_O_O__O(arg_2967, arg_2968) } else { return linked_2965.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2964, arg_2967, arg_2968) } } else { var root_2977 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any; var root_2982 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2984 lang.IFn; if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any = b__851000384__6; if linked_2983 == nil { arg_2980 = ifn_2984.Invoke_O__O(arg_2985) } else { arg_2980 = linked_2983.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2982, arg_2985) }; var arg_2981 any; if linked_2978 == nil { return ifn_2979.Invoke_O_O__O(arg_2980, arg_2981) } else { return linked_2978.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2977, arg_2980, arg_2981) } } } else { var x__4 any; var root_2986 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any = s__851000382__3; if linked_2987 == nil { x__4 = ifn_2988.Invoke_O__O(arg_2989) } else { x__4 = linked_2987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2986, arg_2989) }; var root_2990 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2990, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2992 lang.IFn; if linked_2991 == nil { ifn_2992 = lang.IFn_Cast(root_2990) } else { ifn_2992 = nil }; var arg_2993 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_f), nil, x__4)).Ref(); var arg_2994 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000381); var tmp7 any; var root_2995 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2995, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any = s__851000382__3; if linked_2996 == nil { tmp7 = ifn_2997.Invoke_O__O(arg_2998) } else { tmp7 = linked_2996.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2995, arg_2998) }; arg_2994 = tmp6.Invoke_O__O(tmp7); if linked_2991 == nil { return ifn_2992.Invoke_O_O__O(arg_2993, arg_2994) } else { return linked_2991.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2990, arg_2993, arg_2994) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :346:1
func A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A) Ctor_O_O_I_O(c__f, c__b__851000384 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_b__851000384 = c__b__851000384; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :346:1
func (t *A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A) Invoke_O__O(self any) any { { var i__851000383__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000383__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000383__1)); var root_2957 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2957, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2959 lang.IFn; if linked_2958 == nil { ifn_2959 = lang.IFn_Cast(root_2957) } else { ifn_2959 = nil }; var arg_2960 any = t.F_b__851000384; var arg_2961 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_f), nil, x__2)).Ref(); if linked_2958 == nil { ifn_2959.Invoke_O_O__O(arg_2960, arg_2961) } else { linked_2958.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2957, arg_2960, arg_2961) }; i__851000383__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000383__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A_New() *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A) Ctor() {}
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A) Invoke_O_O__O(self, s__851000290__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2429 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A_New_O_O(s__851000290__1, self); var tmp2 *jrt.Class; var fncls__2428 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A_fn_class; if fncls__2428 == nil { var fncls__2428d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__2429); A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A_fn_class = fncls__2428d; tmp2 = fncls__2428d } else { tmp2 = fncls__2428 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2429, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :352:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A) Ctor_O_O(c__s__851000290, c__iter__851000289 any) { t.F_s__851000290 = c__s__851000290; t.F_iter__851000289 = c__iter__851000289 }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A) Invoke_O__O(self any) any { { var s__851000290__1 any; var t_ any = t.F_s__851000290; t.F_s__851000290 = nil; s__851000290__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2332 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2334 lang.IFn; if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = s__851000290__1; if linked_2333 == nil { temp__1927000414__auto____2 = ifn_2334.Invoke_O__O(arg_2335) } else { temp__1927000414__auto____2 = linked_2333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2332, arg_2335) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2336 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2338 lang.IFn; if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any = xs__1927001018__auto____3; if linked_2337 == nil { c__4 = ifn_2338.Invoke_O__O(arg_2339) } else { c__4 = linked_2337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2336, arg_2339) }; var iterys__1927001035__auto____5 any; var fnbody__2401 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A_New_O(c__4); var tmp1 *jrt.Class; var fncls__2400 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A_fn_class; if fncls__2400 == nil { var fncls__2400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__2401); A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A_fn_class = fncls__2400d; tmp1 = fncls__2400d } else { tmp1 = fncls__2400 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2401, tmp1, nil); var fs__1927001036__auto____6 any; var root_2402 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_2406 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, A_arbace_classes_annot_visible_A_fn_class); var ifn_2408 lang.IFn
																if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any; var root_2410 any = A_arbace_classes_annot_A_const_166.GetRawRoot__O(); var linked_2411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2410, aot_arbace_classes_analyze.A_arbace_classes_analyze_for_target_A_fn_class); var ifn_2412 lang.IFn; if linked_2411 == nil { ifn_2412 = lang.IFn_Cast(root_2410) } else { ifn_2412 = nil }; var arg_2413 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(c__4); var arg_2414 any = Lit_73; if linked_2411 == nil { arg_2409 = ifn_2412.Invoke_O_O__O(arg_2413, arg_2414) } else { arg_2409 = linked_2411.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_for_target_A).Invoke_O_O_O__O(root_2410, arg_2413, arg_2414) }; if linked_2407 == nil { tmp3 = ifn_2408.Invoke_O__O(arg_2409) } else { tmp3 = linked_2407.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_2406, arg_2409) }
//line :352:1
	arg_2405 = tmp2.Invoke_O__O(tmp3); if linked_2403 == nil { fs__1927001036__auto____6 = ifn_2404.Invoke_O__O(arg_2405) } else { fs__1927001036__auto____6 = linked_2403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2402, arg_2405) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2415 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = fs__1927001036__auto____6; var arg_2419 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000289); var tmp5 any; var root_2420 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2422 lang.IFn; if linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any = s__851000290__1; if linked_2421 == nil { tmp5 = ifn_2422.Invoke_O__O(arg_2423) } else { tmp5 = linked_2421.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2420, arg_2423) }; arg_2419 = tmp4.Invoke_O__O(tmp5); if linked_2416 == nil { return ifn_2417.Invoke_O_O__O(arg_2418, arg_2419) } else { return linked_2416.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2415, arg_2418, arg_2419) } } else { var tmp6 any; var root_2424 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2426 lang.IFn; if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = s__851000290__1; if linked_2425 == nil { tmp6 = ifn_2426.Invoke_O__O(arg_2427) } else { tmp6 = linked_2425.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2424, arg_2427) }; s__851000290__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A_New_O(p0 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A{}; t.Ctor_O(p0); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A) Invoke_O_O__O(self, s__851000292__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2399 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A_New_O_O_O(self, s__851000292__1, t.F_c); var tmp2 *jrt.Class; var fncls__2398 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A_fn_class; if fncls__2398 == nil { var fncls__2398d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__2399); A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A_fn_class = fncls__2398d; tmp2 = fncls__2398d } else { tmp2 = fncls__2398 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2399, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :352:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A) Ctor_O_O_O(c__iter__851000291, c__s__851000292, c__c any) { t.F_iter__851000291 = c__iter__851000291; t.F_s__851000292 = c__s__851000292; t.F_c = c__c }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A) Invoke_O__O(self any) any { { var s__851000292__1 any; var t_ any = t.F_s__851000292; t.F_s__851000292 = nil; s__851000292__1 = t_; for { var temp__1927000414__auto____2 any; var root_2340 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_2341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2340, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2342 lang.IFn; if linked_2341 == nil { ifn_2342 = lang.IFn_Cast(root_2340) } else { ifn_2342 = nil }; var arg_2343 any = s__851000292__1; if linked_2341 == nil { temp__1927000414__auto____2 = ifn_2342.Invoke_O__O(arg_2343) } else { temp__1927000414__auto____2 = linked_2341.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2340, arg_2343) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000292__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2344 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = s__851000292__3; if linked_2345 == nil { tmp1 = ifn_2346.Invoke_O__O(arg_2347) } else { tmp1 = linked_2345.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2344, arg_2347) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2348 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = s__851000292__3; if linked_2349 == nil { c__1927001037__auto____4 = ifn_2350.Invoke_O__O(arg_2351) } else { c__1927001037__auto____4 = linked_2349.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2348, arg_2351) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000294__6 any; var root_2352 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2353 == nil { b__851000294__6 = ifn_2354.Invoke_O__O(arg_2355) } else { b__851000294__6 = linked_2353.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2352, arg_2355) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2362 any = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A_New_O_I_O_O(b__851000294__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__2361 *jrt.Class = A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A_fn_class; if fncls__2361 == nil { var fncls__2361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__2362); A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A_fn_class = fncls__2361d; tmp3 = fncls__2361d } else { tmp3 = fncls__2361 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2362, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2363 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any; var root_2368 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = b__851000294__6; if linked_2369 == nil { arg_2366 = ifn_2370.Invoke_O__O(arg_2371) } else { arg_2366 = linked_2369.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2368, arg_2371) }; var arg_2367 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000291); var tmp5 any; var root_2372 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = s__851000292__3; if linked_2373 == nil { tmp5 = ifn_2374.Invoke_O__O(arg_2375) } else { tmp5 = linked_2373.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2372, arg_2375) }; arg_2367 = tmp4.Invoke_O__O(tmp5); if linked_2364 == nil { return ifn_2365.Invoke_O_O__O(arg_2366, arg_2367) } else { return linked_2364.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2363, arg_2366, arg_2367) } } else { var root_2376 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any; var root_2381 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = b__851000294__6; if linked_2382 == nil { arg_2379 = ifn_2383.Invoke_O__O(arg_2384) } else { arg_2379 = linked_2382.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2381, arg_2384) }; var arg_2380 any; if linked_2377 == nil { return ifn_2378.Invoke_O_O__O(arg_2379, arg_2380) } else { return linked_2377.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2376, arg_2379, arg_2380) } } } else { var x__4 any; var root_2385 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any = s__851000292__3; if linked_2386 == nil { x__4 = ifn_2387.Invoke_O__O(arg_2388) } else { x__4 = linked_2386.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2385, arg_2388) }; var root_2389 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_76, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_c), nil, x__4)).Ref(); var arg_2393 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000291); var tmp7 any; var root_2394 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2396 lang.IFn; if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = s__851000292__3; if linked_2395 == nil { tmp7 = ifn_2396.Invoke_O__O(arg_2397) } else { tmp7 = linked_2395.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2394, arg_2397) }; arg_2393 = tmp6.Invoke_O__O(tmp7); if linked_2390 == nil { return ifn_2391.Invoke_O_O__O(arg_2392, arg_2393) } else { return linked_2390.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2389, arg_2392, arg_2393) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A) Ctor_O_I_O_O(c__b__851000294 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__c any) { t.F_b__851000294 = c__b__851000294; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :352:1
func (t *A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A) Invoke_O__O(self any) any { { var i__851000293__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000293__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000293__1)); var root_2356 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = t.F_b__851000294; var arg_2360 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_76, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_c), nil, x__2)).Ref(); if linked_2357 == nil { ifn_2358.Invoke_O_O__O(arg_2359, arg_2360) } else { linked_2357.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2356, arg_2359, arg_2360) }; i__851000293__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000293__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_classes_annot_class_data_iter__851000395__851000401_A_New() *A_arbace_classes_annot_class_data_iter__851000395__851000401_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000395__851000401_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_A) Ctor() {}
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_A) Invoke_O_O__O(self, s__851000396__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3125 any = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A_New_O_O(s__851000396__1, self); var tmp2 *jrt.Class; var fncls__3124 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A_fn_class; if fncls__3124 == nil { var fncls__3124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__3125); A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A_fn_class = fncls__3124d; tmp2 = fncls__3124d } else { tmp2 = fncls__3124 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3125, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :352:1
func A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A_New_O_O(p0, p1 any) *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A) Ctor_O_O(c__s__851000396, c__iter__851000395 any) { t.F_s__851000396 = c__s__851000396; t.F_iter__851000395 = c__iter__851000395 }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A) Invoke_O__O(self any) any { { var s__851000396__1 any; var t_ any = t.F_s__851000396; t.F_s__851000396 = nil; s__851000396__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3028 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_3029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3028, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3030 lang.IFn; if linked_3029 == nil { ifn_3030 = lang.IFn_Cast(root_3028) } else { ifn_3030 = nil }; var arg_3031 any = s__851000396__1; if linked_3029 == nil { temp__1927000414__auto____2 = ifn_3030.Invoke_O__O(arg_3031) } else { temp__1927000414__auto____2 = linked_3029.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3028, arg_3031) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_3032 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_3033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3032, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3034 lang.IFn; if linked_3033 == nil { ifn_3034 = lang.IFn_Cast(root_3032) } else { ifn_3034 = nil }; var arg_3035 any = xs__1927001018__auto____3; if linked_3033 == nil { c__4 = ifn_3034.Invoke_O__O(arg_3035) } else { c__4 = linked_3033.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3032, arg_3035) }; var iterys__1927001035__auto____5 any; var fnbody__3097 any = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A_New_O(c__4); var tmp1 *jrt.Class; var fncls__3096 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A_fn_class; if fncls__3096 == nil { var fncls__3096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, fnbody__3097); A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A_fn_class = fncls__3096d; tmp1 = fncls__3096d } else { tmp1 = fncls__3096 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3097, tmp1, nil); var fs__1927001036__auto____6 any; var root_3098 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_3099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3098, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3100 lang.IFn; if linked_3099 == nil { ifn_3100 = lang.IFn_Cast(root_3098) } else { ifn_3100 = nil }; var arg_3101 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_3102 any = A_arbace_classes_annot_A_const_157.GetRawRoot__O(); var linked_3103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3102, A_arbace_classes_annot_visible_A_fn_class); var ifn_3104 lang.IFn
															if linked_3103 == nil { ifn_3104 = lang.IFn_Cast(root_3102) } else { ifn_3104 = nil }; var arg_3105 any; var root_3106 any = A_arbace_classes_annot_A_const_166.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, aot_arbace_classes_analyze.A_arbace_classes_analyze_for_target_A_fn_class); var ifn_3108 lang.IFn; if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any = A_arbace_classes_annot_A_const_158.Invoke_O__O(c__4); var arg_3110 any = Lit_73; if linked_3107 == nil { arg_3105 = ifn_3108.Invoke_O_O__O(arg_3109, arg_3110) } else { arg_3105 = linked_3107.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_for_target_A).Invoke_O_O_O__O(root_3106, arg_3109, arg_3110) }; if linked_3103 == nil { tmp3 = ifn_3104.Invoke_O__O(arg_3105) } else { tmp3 = linked_3103.(*A_arbace_classes_annot_visible_A).Invoke_O_O__O(root_3102, arg_3105) }
//line :352:1
	arg_3101 = tmp2.Invoke_O__O(tmp3); if linked_3099 == nil { fs__1927001036__auto____6 = ifn_3100.Invoke_O__O(arg_3101) } else { fs__1927001036__auto____6 = linked_3099.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3098, arg_3101) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3111 any = A_arbace_classes_annot_A_const_12.GetRawRoot__O(); var linked_3112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3111, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3113 lang.IFn; if linked_3112 == nil { ifn_3113 = lang.IFn_Cast(root_3111) } else { ifn_3113 = nil }; var arg_3114 any = fs__1927001036__auto____6; var arg_3115 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000395); var tmp5 any; var root_3116 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_3117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3116, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3118 lang.IFn; if linked_3117 == nil { ifn_3118 = lang.IFn_Cast(root_3116) } else { ifn_3118 = nil }; var arg_3119 any = s__851000396__1; if linked_3117 == nil { tmp5 = ifn_3118.Invoke_O__O(arg_3119) } else { tmp5 = linked_3117.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3116, arg_3119) }; arg_3115 = tmp4.Invoke_O__O(tmp5); if linked_3112 == nil { return ifn_3113.Invoke_O_O__O(arg_3114, arg_3115) } else { return linked_3112.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3111, arg_3114, arg_3115) } } else { var tmp6 any; var root_3120 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_3121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3120, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3122 lang.IFn; if linked_3121 == nil { ifn_3122 = lang.IFn_Cast(root_3120) } else { ifn_3122 = nil }; var arg_3123 any = s__851000396__1; if linked_3121 == nil { tmp6 = ifn_3122.Invoke_O__O(arg_3123) } else { tmp6 = linked_3121.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3120, arg_3123) }; s__851000396__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A_New_O(p0 any) *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A{}; t.Ctor_O(p0); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A) Invoke_O_O__O(self, s__851000398__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3095 any = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A_New_O_O_O(s__851000398__1, self, t.F_c); var tmp2 *jrt.Class; var fncls__3094 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A_fn_class; if fncls__3094 == nil { var fncls__3094d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__3095); A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A_fn_class = fncls__3094d; tmp2 = fncls__3094d } else { tmp2 = fncls__3094 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3095, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :352:1
func A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A) Ctor_O_O_O(c__s__851000398, c__iter__851000397, c__c any) { t.F_s__851000398 = c__s__851000398; t.F_iter__851000397 = c__iter__851000397; t.F_c = c__c }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A) Invoke_O__O(self any) any { { var s__851000398__1 any; var t_ any = t.F_s__851000398; t.F_s__851000398 = nil; s__851000398__1 = t_; for { var temp__1927000414__auto____2 any; var root_3036 any = A_arbace_classes_annot_A_const_11.GetRawRoot__O(); var linked_3037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3036, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3038 lang.IFn; if linked_3037 == nil { ifn_3038 = lang.IFn_Cast(root_3036) } else { ifn_3038 = nil }; var arg_3039 any = s__851000398__1; if linked_3037 == nil { temp__1927000414__auto____2 = ifn_3038.Invoke_O__O(arg_3039) } else { temp__1927000414__auto____2 = linked_3037.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3036, arg_3039) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__851000398__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3040 any = A_arbace_classes_annot_A_const_51.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = s__851000398__3; if linked_3041 == nil { tmp1 = ifn_3042.Invoke_O__O(arg_3043) } else { tmp1 = linked_3041.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3040, arg_3043) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3044 any = A_arbace_classes_annot_A_const_52.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3046 lang.IFn; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = s__851000398__3; if linked_3045 == nil { c__1927001037__auto____4 = ifn_3046.Invoke_O__O(arg_3047) } else { c__1927001037__auto____4 = linked_3045.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3044, arg_3047) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__851000400__6 any; var root_3048 any = A_arbace_classes_annot_A_const_53.GetRawRoot__O(); var linked_3049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3048, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3050 lang.IFn; if linked_3049 == nil { ifn_3050 = lang.IFn_Cast(root_3048) } else { ifn_3050 = nil }; var arg_3051 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3049 == nil { b__851000400__6 = ifn_3050.Invoke_O__O(arg_3051) } else { b__851000400__6 = linked_3049.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3048, arg_3051) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3058 any = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A_New_O_I_O_O(b__851000400__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__3057 *jrt.Class = A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A_fn_class; if fncls__3057 == nil { var fncls__3057d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__3058); A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A_fn_class = fncls__3057d; tmp3 = fncls__3057d } else { tmp3 = fncls__3057 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3058, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3059 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_3060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3059, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3061 lang.IFn; if linked_3060 == nil { ifn_3061 = lang.IFn_Cast(root_3059) } else { ifn_3061 = nil }; var arg_3062 any; var root_3064 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_3065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3064, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3066 lang.IFn; if linked_3065 == nil { ifn_3066 = lang.IFn_Cast(root_3064) } else { ifn_3066 = nil }; var arg_3067 any = b__851000400__6; if linked_3065 == nil { arg_3062 = ifn_3066.Invoke_O__O(arg_3067) } else { arg_3062 = linked_3065.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3064, arg_3067) }; var arg_3063 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__851000397); var tmp5 any; var root_3068 any = A_arbace_classes_annot_A_const_57.GetRawRoot__O(); var linked_3069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3068, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3070 lang.IFn; if linked_3069 == nil { ifn_3070 = lang.IFn_Cast(root_3068) } else { ifn_3070 = nil }; var arg_3071 any = s__851000398__3; if linked_3069 == nil { tmp5 = ifn_3070.Invoke_O__O(arg_3071) } else { tmp5 = linked_3069.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3068, arg_3071) }; arg_3063 = tmp4.Invoke_O__O(tmp5); if linked_3060 == nil { return ifn_3061.Invoke_O_O__O(arg_3062, arg_3063) } else { return linked_3060.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3059, arg_3062, arg_3063) } } else { var root_3072 any = A_arbace_classes_annot_A_const_55.GetRawRoot__O(); var linked_3073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3072, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3074 lang.IFn; if linked_3073 == nil { ifn_3074 = lang.IFn_Cast(root_3072) } else { ifn_3074 = nil }; var arg_3075 any; var root_3077 any = A_arbace_classes_annot_A_const_56.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3079 lang.IFn; if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = b__851000400__6; if linked_3078 == nil { arg_3075 = ifn_3079.Invoke_O__O(arg_3080) } else { arg_3075 = linked_3078.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3077, arg_3080) }; var arg_3076 any; if linked_3073 == nil { return ifn_3074.Invoke_O_O__O(arg_3075, arg_3076) } else { return linked_3073.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3072, arg_3075, arg_3076) } } } else { var x__4 any; var root_3081 any = A_arbace_classes_annot_A_const_58.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = s__851000398__3; if linked_3082 == nil { x__4 = ifn_3083.Invoke_O__O(arg_3084) } else { x__4 = linked_3082.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3081, arg_3084) }; var root_3085 any = A_arbace_classes_annot_A_const_59.GetRawRoot__O(); var linked_3086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3085, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3087 lang.IFn; if linked_3086 == nil { ifn_3087 = lang.IFn_Cast(root_3085) } else { ifn_3087 = nil }; var arg_3088 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_76, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_c), nil, x__4)).Ref(); var arg_3089 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__851000397); var tmp7 any; var root_3090 any = A_arbace_classes_annot_A_const_60.GetRawRoot__O(); var linked_3091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3090, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3092 lang.IFn; if linked_3091 == nil { ifn_3092 = lang.IFn_Cast(root_3090) } else { ifn_3092 = nil }; var arg_3093 any = s__851000398__3; if linked_3091 == nil { tmp7 = ifn_3092.Invoke_O__O(arg_3093) } else { tmp7 = linked_3091.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3090, arg_3093) }; arg_3089 = tmp6.Invoke_O__O(tmp7); if linked_3086 == nil { return ifn_3087.Invoke_O_O__O(arg_3088, arg_3089) } else { return linked_3086.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3085, arg_3088, arg_3089) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A) Ctor_O_I_O_O(c__b__851000400 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__c any) { t.F_b__851000400 = c__b__851000400; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :352:1
func (t *A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A) Invoke_O__O(self any) any { { var i__851000399__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__851000399__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__851000399__1)); var root_3052 any = A_arbace_classes_annot_A_const_54.GetRawRoot__O(); var linked_3053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3052, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3054 lang.IFn; if linked_3053 == nil { ifn_3054 = lang.IFn_Cast(root_3052) } else { ifn_3054 = nil }; var arg_3055 any = t.F_b__851000400; var arg_3056 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_76, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_annot_A_const_41.Invoke_O__O(t.F_c), nil, x__2)).Ref(); if linked_3053 == nil { ifn_3054.Invoke_O_O__O(arg_3055, arg_3056) } else { linked_3053.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3052, arg_3055, arg_3056) }; i__851000399__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__851000399__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
























































































































































































































































































































































































































































type A_arbace_classes_annot_A struct{ jrt.Object }

var A_arbace_classes_annot_A_const_pool *jrt.RefArray

var A_arbace_classes_annot_A_const_0 *lang.Var

var A_arbace_classes_annot_A_const_1 any

var A_arbace_classes_annot_A_const_2 any

var A_arbace_classes_annot_A_const_3 any

var A_arbace_classes_annot_A_const_4 *lang.Var

var A_arbace_classes_annot_A_const_5 any

var A_arbace_classes_annot_A_const_6 *lang.Var

var A_arbace_classes_annot_A_const_7 *lang.Var

var A_arbace_classes_annot_A_const_8 *lang.Var

var A_arbace_classes_annot_A_const_9 *lang.Var

var A_arbace_classes_annot_A_const_10 any

var A_arbace_classes_annot_A_const_11 *lang.Var

var A_arbace_classes_annot_A_const_12 *lang.Var

var A_arbace_classes_annot_A_const_13 *lang.Var

var A_arbace_classes_annot_A_const_14 any

var A_arbace_classes_annot_A_const_15 any

var A_arbace_classes_annot_A_const_16 any

var A_arbace_classes_annot_A_const_17 *lang.Var

var A_arbace_classes_annot_A_const_18 *lang.Var

var A_arbace_classes_annot_A_const_19 any

var A_arbace_classes_annot_A_const_20 any

var A_arbace_classes_annot_A_const_21 *lang.Var

var A_arbace_classes_annot_A_const_22 any

var A_arbace_classes_annot_A_const_23 any

var A_arbace_classes_annot_A_const_24 *lang.Var

var A_arbace_classes_annot_A_const_25 any

var A_arbace_classes_annot_A_const_26 any

var A_arbace_classes_annot_A_const_27 *lang.Keyword

var A_arbace_classes_annot_A_const_28 *lang.Var

var A_arbace_classes_annot_A_const_29 any

var A_arbace_classes_annot_A_const_30 *lang.Var

var A_arbace_classes_annot_A_const_31 *lang.Keyword

var A_arbace_classes_annot_A_const_32 *lang.Var

var A_arbace_classes_annot_A_const_33 *lang.Var

var A_arbace_classes_annot_A_const_34 *lang.Keyword

var A_arbace_classes_annot_A_const_35 *lang.Var

var A_arbace_classes_annot_A_const_36 *lang.Var

var A_arbace_classes_annot_A_const_37 *lang.Keyword

var A_arbace_classes_annot_A_const_38 *lang.Var

var A_arbace_classes_annot_A_const_39 *lang.Keyword

var A_arbace_classes_annot_A_const_40 *lang.Keyword

var A_arbace_classes_annot_A_const_41 *lang.Keyword

var A_arbace_classes_annot_A_const_42 *lang.Keyword

var A_arbace_classes_annot_A_const_43 *lang.Keyword

var A_arbace_classes_annot_A_const_44 *lang.Keyword

var A_arbace_classes_annot_A_const_45 *lang.Var

var A_arbace_classes_annot_A_const_46 *lang.Var

var A_arbace_classes_annot_A_const_47 *lang.Var

var A_arbace_classes_annot_A_const_48 *lang.Var

var A_arbace_classes_annot_A_const_49 *lang.Keyword

var A_arbace_classes_annot_A_const_50 *lang.Keyword

var A_arbace_classes_annot_A_const_51 *lang.Var

var A_arbace_classes_annot_A_const_52 *lang.Var

var A_arbace_classes_annot_A_const_53 *lang.Var

var A_arbace_classes_annot_A_const_54 *lang.Var

var A_arbace_classes_annot_A_const_55 *lang.Var

var A_arbace_classes_annot_A_const_56 *lang.Var

var A_arbace_classes_annot_A_const_57 *lang.Var

var A_arbace_classes_annot_A_const_58 *lang.Var

var A_arbace_classes_annot_A_const_59 *lang.Var

var A_arbace_classes_annot_A_const_60 *lang.Var

var A_arbace_classes_annot_A_const_61 *lang.Var

var A_arbace_classes_annot_A_const_62 *lang.Keyword

var A_arbace_classes_annot_A_const_63 *lang.Var

var A_arbace_classes_annot_A_const_64 *lang.Var

var A_arbace_classes_annot_A_const_65 *lang.Var

var A_arbace_classes_annot_A_const_66 *lang.Var

var A_arbace_classes_annot_A_const_67 *lang.Var

var A_arbace_classes_annot_A_const_68 *lang.Var

var A_arbace_classes_annot_A_const_69 *lang.Var

var A_arbace_classes_annot_A_const_70 any

var A_arbace_classes_annot_A_const_71 *lang.Keyword

var A_arbace_classes_annot_A_const_72 *lang.Keyword

var A_arbace_classes_annot_A_const_73 any

var A_arbace_classes_annot_A_const_74 *lang.Keyword

var A_arbace_classes_annot_A_const_75 *lang.Var

var A_arbace_classes_annot_A_const_76 any

var A_arbace_classes_annot_A_const_77 *lang.Keyword

var A_arbace_classes_annot_A_const_78 *lang.Keyword

var A_arbace_classes_annot_A_const_79 *lang.Keyword

var A_arbace_classes_annot_A_const_80 *lang.Keyword

var A_arbace_classes_annot_A_const_81 any

var A_arbace_classes_annot_A_const_82 *lang.Keyword

var A_arbace_classes_annot_A_const_83 *lang.Keyword

var A_arbace_classes_annot_A_const_84 *lang.Keyword

var A_arbace_classes_annot_A_const_85 *lang.Keyword

var A_arbace_classes_annot_A_const_86 *lang.Keyword

var A_arbace_classes_annot_A_const_87 *lang.Keyword

var A_arbace_classes_annot_A_const_88 any

var A_arbace_classes_annot_A_const_89 *lang.Keyword

var A_arbace_classes_annot_A_const_90 *lang.Keyword

var A_arbace_classes_annot_A_const_91 any

var A_arbace_classes_annot_A_const_92 *lang.Keyword

var A_arbace_classes_annot_A_const_93 *lang.Keyword

var A_arbace_classes_annot_A_const_94 *lang.Keyword

var A_arbace_classes_annot_A_const_95 *lang.Keyword

var A_arbace_classes_annot_A_const_96 *lang.Var

var A_arbace_classes_annot_A_const_97 *lang.Keyword

var A_arbace_classes_annot_A_const_98 *lang.Keyword

var A_arbace_classes_annot_A_const_99 *lang.Keyword

var A_arbace_classes_annot_A_const_100 *lang.Var

var A_arbace_classes_annot_A_const_101 any

var A_arbace_classes_annot_A_const_102 *lang.Keyword

var A_arbace_classes_annot_A_const_103 any

var A_arbace_classes_annot_A_const_104 *lang.Var

var A_arbace_classes_annot_A_const_105 *lang.Keyword

var A_arbace_classes_annot_A_const_106 *lang.Keyword

var A_arbace_classes_annot_A_const_107 *lang.Var

var A_arbace_classes_annot_A_const_108 *lang.Var

var A_arbace_classes_annot_A_const_109 *lang.Var

var A_arbace_classes_annot_A_const_110 *lang.Var

var A_arbace_classes_annot_A_const_111 *lang.Keyword

var A_arbace_classes_annot_A_const_112 any

var A_arbace_classes_annot_A_const_113 *lang.Var

var A_arbace_classes_annot_A_const_114 *lang.Var

var A_arbace_classes_annot_A_const_115 *lang.Var

var A_arbace_classes_annot_A_const_116 *lang.Var

var A_arbace_classes_annot_A_const_117 *lang.Keyword

var A_arbace_classes_annot_A_const_118 *lang.Keyword

var A_arbace_classes_annot_A_const_119 *lang.Keyword

var A_arbace_classes_annot_A_const_120 *lang.Keyword

var A_arbace_classes_annot_A_const_121 any

var A_arbace_classes_annot_A_const_122 *lang.Var

var A_arbace_classes_annot_A_const_123 *lang.Var

var A_arbace_classes_annot_A_const_124 any

var A_arbace_classes_annot_A_const_125 any

var A_arbace_classes_annot_A_const_126 any

var A_arbace_classes_annot_A_const_127 any

var A_arbace_classes_annot_A_const_128 any

var A_arbace_classes_annot_A_const_129 any

var A_arbace_classes_annot_A_const_130 *lang.Keyword

var A_arbace_classes_annot_A_const_131 any

var A_arbace_classes_annot_A_const_132 any

var A_arbace_classes_annot_A_const_133 any

var A_arbace_classes_annot_A_const_134 *lang.Keyword

var A_arbace_classes_annot_A_const_135 any

var A_arbace_classes_annot_A_const_136 any

var A_arbace_classes_annot_A_const_137 any

var A_arbace_classes_annot_A_const_138 any

var A_arbace_classes_annot_A_const_139 any

var A_arbace_classes_annot_A_const_140 any

var A_arbace_classes_annot_A_const_141 *lang.Var

var A_arbace_classes_annot_A_const_142 *lang.Var

var A_arbace_classes_annot_A_const_143 *lang.Var

var A_arbace_classes_annot_A_const_144 *lang.Keyword

var A_arbace_classes_annot_A_const_145 *lang.Var

var A_arbace_classes_annot_A_const_146 *lang.Var

var A_arbace_classes_annot_A_const_147 *lang.Var

var A_arbace_classes_annot_A_const_148 *lang.Keyword

var A_arbace_classes_annot_A_const_149 any

var A_arbace_classes_annot_A_const_150 any

var A_arbace_classes_annot_A_const_151 *lang.Var

var A_arbace_classes_annot_A_const_152 *lang.Var

var A_arbace_classes_annot_A_const_153 *lang.Keyword

var A_arbace_classes_annot_A_const_154 *lang.Var

var A_arbace_classes_annot_A_const_155 *lang.Var

var A_arbace_classes_annot_A_const_156 *lang.Var

var A_arbace_classes_annot_A_const_157 *lang.Var

var A_arbace_classes_annot_A_const_158 *lang.Keyword

var A_arbace_classes_annot_A_const_159 *lang.Keyword

var A_arbace_classes_annot_A_const_160 *lang.Var

var A_arbace_classes_annot_A_const_161 any

var A_arbace_classes_annot_A_const_162 *lang.Var

var A_arbace_classes_annot_A_const_163 *lang.Var

var A_arbace_classes_annot_A_const_164 *lang.Var

var A_arbace_classes_annot_A_const_165 *lang.Keyword

var A_arbace_classes_annot_A_const_166 *lang.Var

var A_arbace_classes_annot_A_const_167 *lang.Var

var A_arbace_classes_annot_A_const_168 any

var A_arbace_classes_annot_A_init jrt.ClassInit

func A_arbace_classes_annot_A_Init() { if !A_arbace_classes_annot_A_init.Done() { A_arbace_classes_annot_A_init.Run(A_arbace_classes_annot_A_clinit) } }

func A_arbace_classes_annot_A_clinit() { A_arbace_classes_annot_A_clinit_p0(); A_arbace_classes_annot_A_clinit_p1(); A_arbace_classes_annot_A_clinit_p2(); A_arbace_classes_annot_A_clinit_p3(); A_arbace_classes_annot_A_clinit_p4(); A_arbace_classes_annot_A_clinit_p5(); A_arbace_classes_annot_A_clinit_p6(); A_arbace_classes_annot_A_clinit_p7(); A_arbace_classes_annot_A_clinit_p8(); A_arbace_classes_annot_A_clinit_p9(); A_arbace_classes_annot_A_clinit_p10(); A_arbace_classes_annot_A_clinit_p11(); A_arbace_classes_annot_A_clinit_p12(); A_arbace_classes_annot_A_clinit_p13() }

func A_arbace_classes_annot_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_annot_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 234); A_arbace_classes_annot_A_const_0 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[65]); A_arbace_classes_annot_A_const_1 = A_arbace_classes_annot_A_const_pool.A[66]; A_arbace_classes_annot_A_const_2 = A_arbace_classes_annot_A_const_pool.A[67]; A_arbace_classes_annot_A_const_3 = A_arbace_classes_annot_A_const_pool.A[68]; A_arbace_classes_annot_A_const_4 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[69]); A_arbace_classes_annot_A_const_5 = A_arbace_classes_annot_A_const_pool.A[70]; A_arbace_classes_annot_A_const_6 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[71]); A_arbace_classes_annot_A_const_7 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[72]); A_arbace_classes_annot_A_const_8 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[73]); A_arbace_classes_annot_A_const_9 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[74]); A_arbace_classes_annot_A_const_10 = A_arbace_classes_annot_A_const_pool.A[75]; A_arbace_classes_annot_A_const_11 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[76]) }

func A_arbace_classes_annot_A_clinit_p1() { A_arbace_classes_annot_A_const_12 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[77]); A_arbace_classes_annot_A_const_13 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[78]); A_arbace_classes_annot_A_const_14 = A_arbace_classes_annot_A_const_pool.A[79]; A_arbace_classes_annot_A_const_15 = A_arbace_classes_annot_A_const_pool.A[80]; A_arbace_classes_annot_A_const_16 = A_arbace_classes_annot_A_const_pool.A[81]; A_arbace_classes_annot_A_const_17 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[82]); A_arbace_classes_annot_A_const_18 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[83]); A_arbace_classes_annot_A_const_19 = A_arbace_classes_annot_A_const_pool.A[84]; A_arbace_classes_annot_A_const_20 = A_arbace_classes_annot_A_const_pool.A[85]; A_arbace_classes_annot_A_const_21 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[86]); A_arbace_classes_annot_A_const_22 = A_arbace_classes_annot_A_const_pool.A[87]; A_arbace_classes_annot_A_const_23 = A_arbace_classes_annot_A_const_pool.A[88]; A_arbace_classes_annot_A_const_24 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[89]); A_arbace_classes_annot_A_const_25 = A_arbace_classes_annot_A_const_pool.A[90] }

func A_arbace_classes_annot_A_clinit_p2() { A_arbace_classes_annot_A_const_26 = A_arbace_classes_annot_A_const_pool.A[91]; A_arbace_classes_annot_A_const_27 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[92]); A_arbace_classes_annot_A_const_28 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[93]); A_arbace_classes_annot_A_const_29 = A_arbace_classes_annot_A_const_pool.A[94]; A_arbace_classes_annot_A_const_30 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[95]); A_arbace_classes_annot_A_const_31 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[96]); A_arbace_classes_annot_A_const_32 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[97]); A_arbace_classes_annot_A_const_33 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[98]); A_arbace_classes_annot_A_const_34 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[99]); A_arbace_classes_annot_A_const_35 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[100]); A_arbace_classes_annot_A_const_36 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[101]); A_arbace_classes_annot_A_const_37 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[102]) }

func A_arbace_classes_annot_A_clinit_p3() { A_arbace_classes_annot_A_const_38 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[103]); A_arbace_classes_annot_A_const_39 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[104]); A_arbace_classes_annot_A_const_40 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[105]); A_arbace_classes_annot_A_const_41 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[106]); A_arbace_classes_annot_A_const_42 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[107]); A_arbace_classes_annot_A_const_43 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[108]); A_arbace_classes_annot_A_const_44 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[109]); A_arbace_classes_annot_A_const_45 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[110]); A_arbace_classes_annot_A_const_46 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[111]); A_arbace_classes_annot_A_const_47 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[112]); A_arbace_classes_annot_A_const_48 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[113]); A_arbace_classes_annot_A_const_49 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[114]) }

func A_arbace_classes_annot_A_clinit_p4() { A_arbace_classes_annot_A_const_50 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[115]); A_arbace_classes_annot_A_const_51 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[116]); A_arbace_classes_annot_A_const_52 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[117]); A_arbace_classes_annot_A_const_53 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[118]); A_arbace_classes_annot_A_const_54 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[119]); A_arbace_classes_annot_A_const_55 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[120]); A_arbace_classes_annot_A_const_56 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[121]); A_arbace_classes_annot_A_const_57 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[122]); A_arbace_classes_annot_A_const_58 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[123]); A_arbace_classes_annot_A_const_59 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[124]); A_arbace_classes_annot_A_const_60 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[125]); A_arbace_classes_annot_A_const_61 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[126]) }

func A_arbace_classes_annot_A_clinit_p5() { A_arbace_classes_annot_A_const_62 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[127]); A_arbace_classes_annot_A_const_63 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[128]); A_arbace_classes_annot_A_const_64 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[129]); A_arbace_classes_annot_A_const_65 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[130]); A_arbace_classes_annot_A_const_66 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[131]); A_arbace_classes_annot_A_const_67 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[132]); A_arbace_classes_annot_A_const_68 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[133]); A_arbace_classes_annot_A_const_69 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[134]); A_arbace_classes_annot_A_const_70 = A_arbace_classes_annot_A_const_pool.A[135]; A_arbace_classes_annot_A_const_71 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[136]); A_arbace_classes_annot_A_const_72 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[137]); A_arbace_classes_annot_A_const_73 = A_arbace_classes_annot_A_const_pool.A[138] }

func A_arbace_classes_annot_A_clinit_p6() { A_arbace_classes_annot_A_const_74 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[139]); A_arbace_classes_annot_A_const_75 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[140]); A_arbace_classes_annot_A_const_76 = A_arbace_classes_annot_A_const_pool.A[141]; A_arbace_classes_annot_A_const_77 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[142]); A_arbace_classes_annot_A_const_78 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[143]); A_arbace_classes_annot_A_const_79 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[144]); A_arbace_classes_annot_A_const_80 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[145]); A_arbace_classes_annot_A_const_81 = A_arbace_classes_annot_A_const_pool.A[146]; A_arbace_classes_annot_A_const_82 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[147]); A_arbace_classes_annot_A_const_83 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[148]); A_arbace_classes_annot_A_const_84 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[149]); A_arbace_classes_annot_A_const_85 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[150]) }

func A_arbace_classes_annot_A_clinit_p7() { A_arbace_classes_annot_A_const_86 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[151]); A_arbace_classes_annot_A_const_87 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[152]); A_arbace_classes_annot_A_const_88 = A_arbace_classes_annot_A_const_pool.A[153]; A_arbace_classes_annot_A_const_89 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[154]); A_arbace_classes_annot_A_const_90 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[155]); A_arbace_classes_annot_A_const_91 = A_arbace_classes_annot_A_const_pool.A[156]; A_arbace_classes_annot_A_const_92 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[157]); A_arbace_classes_annot_A_const_93 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[158]); A_arbace_classes_annot_A_const_94 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[159]); A_arbace_classes_annot_A_const_95 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[160]); A_arbace_classes_annot_A_const_96 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[161]); A_arbace_classes_annot_A_const_97 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[162]) }

func A_arbace_classes_annot_A_clinit_p8() { A_arbace_classes_annot_A_const_98 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[163]); A_arbace_classes_annot_A_const_99 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[164]); A_arbace_classes_annot_A_const_100 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[165]); A_arbace_classes_annot_A_const_101 = A_arbace_classes_annot_A_const_pool.A[166]; A_arbace_classes_annot_A_const_102 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[167]); A_arbace_classes_annot_A_const_103 = A_arbace_classes_annot_A_const_pool.A[168]; A_arbace_classes_annot_A_const_104 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[169]); A_arbace_classes_annot_A_const_105 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[170]); A_arbace_classes_annot_A_const_106 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[171]); A_arbace_classes_annot_A_const_107 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[172]); A_arbace_classes_annot_A_const_108 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[173]); A_arbace_classes_annot_A_const_109 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[174]) }

func A_arbace_classes_annot_A_clinit_p9() { A_arbace_classes_annot_A_const_110 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[175]); A_arbace_classes_annot_A_const_111 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[176]); A_arbace_classes_annot_A_const_112 = A_arbace_classes_annot_A_const_pool.A[177]; A_arbace_classes_annot_A_const_113 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[178]); A_arbace_classes_annot_A_const_114 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[179]); A_arbace_classes_annot_A_const_115 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[180]); A_arbace_classes_annot_A_const_116 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[181]); A_arbace_classes_annot_A_const_117 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[182]); A_arbace_classes_annot_A_const_118 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[183]); A_arbace_classes_annot_A_const_119 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[184]); A_arbace_classes_annot_A_const_120 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[185]); A_arbace_classes_annot_A_const_121 = A_arbace_classes_annot_A_const_pool.A[186] }

func A_arbace_classes_annot_A_clinit_p10() { A_arbace_classes_annot_A_const_122 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[187]); A_arbace_classes_annot_A_const_123 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[188]); A_arbace_classes_annot_A_const_124 = A_arbace_classes_annot_A_const_pool.A[189]; A_arbace_classes_annot_A_const_125 = A_arbace_classes_annot_A_const_pool.A[190]; A_arbace_classes_annot_A_const_126 = A_arbace_classes_annot_A_const_pool.A[191]; A_arbace_classes_annot_A_const_127 = A_arbace_classes_annot_A_const_pool.A[192]; A_arbace_classes_annot_A_const_128 = A_arbace_classes_annot_A_const_pool.A[193]; A_arbace_classes_annot_A_const_129 = A_arbace_classes_annot_A_const_pool.A[194]; A_arbace_classes_annot_A_const_130 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[195]); A_arbace_classes_annot_A_const_131 = A_arbace_classes_annot_A_const_pool.A[196]; A_arbace_classes_annot_A_const_132 = A_arbace_classes_annot_A_const_pool.A[197]; A_arbace_classes_annot_A_const_133 = A_arbace_classes_annot_A_const_pool.A[198]; A_arbace_classes_annot_A_const_134 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[199]); A_arbace_classes_annot_A_const_135 = A_arbace_classes_annot_A_const_pool.A[200] }

func A_arbace_classes_annot_A_clinit_p11() { A_arbace_classes_annot_A_const_136 = A_arbace_classes_annot_A_const_pool.A[201]; A_arbace_classes_annot_A_const_137 = A_arbace_classes_annot_A_const_pool.A[202]; A_arbace_classes_annot_A_const_138 = A_arbace_classes_annot_A_const_pool.A[203]; A_arbace_classes_annot_A_const_139 = A_arbace_classes_annot_A_const_pool.A[204]; A_arbace_classes_annot_A_const_140 = A_arbace_classes_annot_A_const_pool.A[205]; A_arbace_classes_annot_A_const_141 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[206]); A_arbace_classes_annot_A_const_142 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[207]); A_arbace_classes_annot_A_const_143 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[208]); A_arbace_classes_annot_A_const_144 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[209]); A_arbace_classes_annot_A_const_145 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[210]); A_arbace_classes_annot_A_const_146 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[211]); A_arbace_classes_annot_A_const_147 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[212]); A_arbace_classes_annot_A_const_148 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[213]) }

func A_arbace_classes_annot_A_clinit_p12() { A_arbace_classes_annot_A_const_149 = A_arbace_classes_annot_A_const_pool.A[214]; A_arbace_classes_annot_A_const_150 = A_arbace_classes_annot_A_const_pool.A[215]; A_arbace_classes_annot_A_const_151 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[216]); A_arbace_classes_annot_A_const_152 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[217]); A_arbace_classes_annot_A_const_153 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[218]); A_arbace_classes_annot_A_const_154 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[219]); A_arbace_classes_annot_A_const_155 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[220]); A_arbace_classes_annot_A_const_156 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[221]); A_arbace_classes_annot_A_const_157 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[222]); A_arbace_classes_annot_A_const_158 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[223]); A_arbace_classes_annot_A_const_159 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[224]); A_arbace_classes_annot_A_const_160 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[225]) }

func A_arbace_classes_annot_A_clinit_p13() { A_arbace_classes_annot_A_const_161 = A_arbace_classes_annot_A_const_pool.A[226]; A_arbace_classes_annot_A_const_162 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[227]); A_arbace_classes_annot_A_const_163 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[228]); A_arbace_classes_annot_A_const_164 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[229]); A_arbace_classes_annot_A_const_165 = lang.Keyword_Cast(A_arbace_classes_annot_A_const_pool.A[230]); A_arbace_classes_annot_A_const_166 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[231]); A_arbace_classes_annot_A_const_167 = lang.Var_Cast(A_arbace_classes_annot_A_const_pool.A[232]); A_arbace_classes_annot_A_const_168 = A_arbace_classes_annot_A_const_pool.A[233] }

func A_arbace_classes_annot_A_New() *A_arbace_classes_annot_A { A_arbace_classes_annot_A_Init(); t := &A_arbace_classes_annot_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_annot_A) Ctor() {}

func (t *A_arbace_classes_annot_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_annot_A) GetClass__Class() *jrt.Class { return A_arbace_classes_annot_A_class }

func (t *A_arbace_classes_annot_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_annot_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_annot_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_annot_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_annot_A); return ok }

func A_arbace_classes_annot_A_Cast(x any) *A_arbace_classes_annot_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_annot_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_annot_A_class)) }; return v }



type A_arbace_classes_annot_attribute_lines_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_attribute_lines_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A struct{ j2g_header uint64; F_iter__851000060, F_s__851000061 any }

var A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A struct{ j2g_header uint64; F_b__851000063 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_attribute_lines_iter__851000060__851000064_fn__851000065_fn__851000066_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A struct{ j2g_header uint64; F_n, F_iter__851000070, F_s__851000071 any }

var A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A struct{ j2g_header uint64; F_b__851000073, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_attribute_lines_iter__851000070__851000074_fn__851000075_fn__851000076_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A struct{ j2g_header uint64; F_iter__851000080, F_s__851000081 any }

var A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_A_fn_class *jrt.Class



type A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A struct{ j2g_header uint64; F_b__851000083 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_attribute_lines_iter__851000080__851000084_fn__851000085_fn__851000086_A_fn_class *jrt.Class



type A_arbace_classes_annot_bin_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_bin_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_A struct{ j2g_header uint64; F_throws, F_n, F_members, F_d any }

var A_arbace_classes_annot_class_data_fn__851000199_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A struct{ j2g_header uint64; F_n, F_members, F_d any }

var A_arbace_classes_annot_class_data_fn__851000199_fn__851000200_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A struct{ j2g_header uint64; F_n, F_d any }

var A_arbace_classes_annot_class_data_fn__851000199_fn__851000202_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A struct{ j2g_header uint64; F_n, F_members, F_d any }

var A_arbace_classes_annot_class_data_fn__851000199_fn__851000204_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A struct{ j2g_header uint64; F_iter__851000206, F_s__851000207 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A struct{ j2g_header uint64; F_b__851000209 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000206__851000210_fn__851000211_fn__851000212_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A struct{ j2g_header uint64; F_iter__851000216, F_s__851000217 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A struct{ j2g_header uint64; F_b__851000219 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A struct{ j2g_header uint64; F_mm any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000222_fn__851000223_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A struct{ j2g_header uint64; F_mm any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000216__851000220_fn__851000221_fn__851000226_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A struct{ j2g_header uint64; F_s__851000231, F_n, F_iter__851000230 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A struct{ j2g_header uint64; F_head any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A struct{ j2g_header uint64; F_s__851000233, F_head, F_iter__851000232 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A struct{ j2g_header uint64; F_b__851000235, F_head any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000230__851000236_fn__851000237_iter__851000232__851000238_fn__851000239_fn__851000240_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A struct{ j2g_header uint64; F_iter__851000246, F_s__851000247, F_n any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A struct{ j2g_header uint64; F_n, F_mm any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_fn__851000256_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A struct{ j2g_header uint64; F_desc any; F_ctor bool; F_lead, F_mm any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A struct{ j2g_header uint64; F_iter__851000248, F_s__851000249, F_desc any; F_ctor bool; F_lead, F_mm any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A struct{ j2g_header uint64; F_i, F_desc any; F_ctor bool; F_lead, F_mm any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A struct{ j2g_header uint64; F_i, F_desc any; F_ctor bool; F_lead, F_iter__851000250, F_mm, F_s__851000251 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A struct{ j2g_header uint64; F_i, F_desc, F_b__851000253 any; F_ctor bool; F_lead, F_mm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000246__851000254_fn__851000255_iter__851000248__851000258_fn__851000259_iter__851000250__851000263_fn__851000264_fn__851000265_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A struct{ j2g_header uint64; F_iter__851000273, F_s__851000274 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A struct{ j2g_header uint64; F_f any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A struct{ j2g_header uint64; F_s__851000276, F_f, F_iter__851000275 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A struct{ j2g_header uint64; F_f, F_b__851000278 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000273__851000279_fn__851000280_iter__851000275__851000281_fn__851000282_fn__851000283_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A struct{ j2g_header uint64; F_s__851000290, F_iter__851000289 any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A struct{ j2g_header uint64; F_iter__851000291, F_s__851000292, F_c any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A struct{ j2g_header uint64; F_b__851000294 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_c any }

var A_arbace_classes_annot_class_data_fn__851000199_iter__851000289__851000295_fn__851000296_iter__851000291__851000297_fn__851000298_fn__851000299_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000306_A struct{ j2g_header uint64; F_n, F_members, F_d any }

var A_arbace_classes_annot_class_data_fn__851000306_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000308_A struct{ j2g_header uint64; F_n, F_d any }

var A_arbace_classes_annot_class_data_fn__851000308_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_fn__851000310_A struct{ j2g_header uint64; F_n, F_members, F_d any }

var A_arbace_classes_annot_class_data_fn__851000310_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000312__851000316_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_iter__851000312__851000316_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A struct{ j2g_header uint64; F_iter__851000312, F_s__851000313 any }

var A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A struct{ j2g_header uint64; F_b__851000315 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_iter__851000312__851000316_fn__851000317_fn__851000318_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000322__851000326_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_iter__851000322__851000326_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A struct{ j2g_header uint64; F_s__851000323, F_iter__851000322 any }

var A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A struct{ j2g_header uint64; F_b__851000325 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A struct{ j2g_header uint64; F_mm any }

var A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000328_fn__851000329_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A struct{ j2g_header uint64; F_mm any }

var A_arbace_classes_annot_class_data_iter__851000322__851000326_fn__851000327_fn__851000332_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000336__851000342_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_annot_class_data_iter__851000336__851000342_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A struct{ j2g_header uint64; F_iter__851000336, F_s__851000337, F_n any }

var A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A struct{ j2g_header uint64; F_head any }

var A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A struct{ j2g_header uint64; F_iter__851000338, F_s__851000339, F_head any }

var A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A struct{ j2g_header uint64; F_b__851000341, F_head any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_iter__851000336__851000342_fn__851000343_iter__851000338__851000344_fn__851000345_fn__851000346_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A struct{ j2g_header uint64; F_s__851000353, F_n, F_iter__851000352 any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A struct{ j2g_header uint64; F_n, F_mm any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_fn__851000362_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A struct{ j2g_header uint64; F_desc any; F_ctor bool; F_lead, F_mm any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A struct{ j2g_header uint64; F_s__851000355, F_desc any; F_ctor bool; F_lead, F_mm, F_iter__851000354 any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A struct{ j2g_header uint64; F_i, F_desc any; F_ctor bool; F_lead, F_mm any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A struct{ j2g_header uint64; F_iter__851000356, F_i, F_s__851000357, F_desc any; F_ctor bool; F_lead, F_mm any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A struct{ j2g_header uint64; F_i, F_desc any; F_ctor bool; F_b__851000359, F_lead, F_mm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_iter__851000352__851000360_fn__851000361_iter__851000354__851000364_fn__851000365_iter__851000356__851000369_fn__851000370_fn__851000371_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000379__851000385_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_iter__851000379__851000385_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A struct{ j2g_header uint64; F_iter__851000379, F_s__851000380 any }

var A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A struct{ j2g_header uint64; F_f any }

var A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A struct{ j2g_header uint64; F_f, F_iter__851000381, F_s__851000382 any }

var A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A struct{ j2g_header uint64; F_f, F_b__851000384 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_class_data_iter__851000379__851000385_fn__851000386_iter__851000381__851000387_fn__851000388_fn__851000389_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000395__851000401_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_class_data_iter__851000395__851000401_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A struct{ j2g_header uint64; F_s__851000396, F_iter__851000395 any }

var A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A struct{ j2g_header uint64; F_s__851000398, F_iter__851000397, F_c any }

var A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_A_fn_class *jrt.Class



type A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A struct{ j2g_header uint64; F_b__851000400 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_c any }

var A_arbace_classes_annot_class_data_iter__851000395__851000401_fn__851000402_iter__851000397__851000403_fn__851000404_fn__851000405_A_fn_class *jrt.Class



type A_arbace_classes_annot_ctor_lead_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_ctor_lead_A_fn_class *jrt.Class



type A_arbace_classes_annot_ctor_lead_cnt__851000055_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_ctor_lead_cnt__851000055_A_fn_class *jrt.Class



type A_arbace_classes_annot_element_value_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_element_value_A_fn_class *jrt.Class



type A_arbace_classes_annot_enc_annotation_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_enc_annotation_A_fn_class *jrt.Class



type A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_A_fn_class *jrt.Class



type A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A struct{ j2g_header uint64; F_iter__851000028, F_s__851000029 any }

var A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_A_fn_class *jrt.Class



type A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A struct{ j2g_header uint64; F_b__851000031 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_enc_annotation_iter__851000028__851000032_fn__851000033_fn__851000034_A_fn_class *jrt.Class



type A_arbace_classes_annot_enc_string_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_enc_string_A_fn_class *jrt.Class



type A_arbace_classes_annot_enc_value_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_enc_value_A_fn_class *jrt.Class



type A_arbace_classes_annot_enc_value_fn__851000024_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_enc_value_fn__851000024_A_fn_class *jrt.Class



type A_arbace_classes_annot_eval851000004_A struct{ jrt.Object }

func A_arbace_classes_annot_eval851000004_A_New() *A_arbace_classes_annot_eval851000004_A { t := &A_arbace_classes_annot_eval851000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_annot_eval851000004_A) Ctor() {}

func (t *A_arbace_classes_annot_eval851000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_annot_eval851000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_annot_eval851000004_A_class }

func (t *A_arbace_classes_annot_eval851000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_annot_eval851000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_annot_eval851000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_annot_eval851000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_annot_eval851000004_A); return ok }

func A_arbace_classes_annot_eval851000004_A_Cast(x any) *A_arbace_classes_annot_eval851000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_annot_eval851000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_annot_eval851000004_A_class)) }; return v }



type A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_eval851000004_loading__1927001464__auto____851000005_A_fn_class *jrt.Class



type A_arbace_classes_annot_eval851000008_A struct{ jrt.Object }

func A_arbace_classes_annot_eval851000008_A_New() *A_arbace_classes_annot_eval851000008_A { t := &A_arbace_classes_annot_eval851000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_annot_eval851000008_A) Ctor() {}

func (t *A_arbace_classes_annot_eval851000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_annot_eval851000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_annot_eval851000008_A_class }

func (t *A_arbace_classes_annot_eval851000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_annot_eval851000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_annot_eval851000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_annot_eval851000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_annot_eval851000008_A); return ok }

func A_arbace_classes_annot_eval851000008_A_Cast(x any) *A_arbace_classes_annot_eval851000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_annot_eval851000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_annot_eval851000008_A_class)) }; return v }



type A_arbace_classes_annot_eval851000008_fn__851000009_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_eval851000008_fn__851000009_A_fn_class *jrt.Class



type A_arbace_classes_annot_fn__851000017_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_fn__851000017_A_fn_class *jrt.Class



type A_arbace_classes_annot_fn__851000017_fn__851000018_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_fn__851000017_fn__851000018_A_fn_class *jrt.Class



type A_arbace_classes_annot_lenient_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_lenient_A_fn_class *jrt.Class



type A_arbace_classes_annot_pool_index_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_annot_pool_index_BANG__A_fn_class *jrt.Class



type A_arbace_classes_annot_pool_index_BANG__fn__851000108_A struct{ j2g_header uint64; F_i, F_v, F_tag any }

var A_arbace_classes_annot_pool_index_BANG__fn__851000108_A_fn_class *jrt.Class



type A_arbace_classes_annot_reflected_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_annot_reflected_member_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_annot_safe_ctor_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_safe_ctor_desc_A_fn_class *jrt.Class



type A_arbace_classes_annot_target_info_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_target_info_A_fn_class *jrt.Class



type A_arbace_classes_annot_throws_lines_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_throws_lines_A_fn_class *jrt.Class



type A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_annot_throws_lines_iter__851000092__851000096_A_fn_class *jrt.Class



type A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A struct{ j2g_header uint64; F_n, F_iter__851000092, F_s__851000093 any }

var A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_A_fn_class *jrt.Class



type A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A struct{ j2g_header uint64; F_b__851000095, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_A_fn_class *jrt.Class



type A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000098_fn__851000099_A_fn_class *jrt.Class



type A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_throws_lines_iter__851000092__851000096_fn__851000097_fn__851000102_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_ann_body_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_type_ann_body_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_type_annotation_lines_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A struct{ j2g_header uint64; F_n, F_pool any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A struct{ j2g_header uint64; F_iter__851000159, F_n, F_pool, F_s__851000160 any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A struct{ j2g_header uint64; F_b__851000162, F_n, F_pool any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000159__851000163_fn__851000164_fn__851000165_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A struct{ j2g_header uint64; F_pool any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A struct{ j2g_header uint64; F_iter__851000169, F_pool, F_s__851000170 any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A struct{ j2g_header uint64; F_b__851000172, F_pool any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000169__851000173_fn__851000174_fn__851000175_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A struct{ j2g_header uint64; F_s__851000180, F_iter__851000179 any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A struct{ j2g_header uint64; F_b__851000182 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_annot_type_annotation_lines_iter__851000179__851000183_fn__851000184_fn__851000185_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotations_bytes_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_type_annotations_bytes_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A struct{ j2g_header uint64; F_anns any }

var A_arbace_classes_annot_type_annotations_bytes_fn__851000146_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A struct{ j2g_header uint64; F_anns any }

var A_arbace_classes_annot_type_annotations_bytes_fn__851000148_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_path_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_type_path_A_fn_class *jrt.Class



type A_arbace_classes_annot_type_path_fn__851000132_A struct{ j2g_header uint64; F_path any }

var A_arbace_classes_annot_type_path_fn__851000132_A_fn_class *jrt.Class



type A_arbace_classes_annot_u1_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_u1_A_fn_class *jrt.Class



type A_arbace_classes_annot_u2_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_u2_A_fn_class *jrt.Class



type A_arbace_classes_annot_visible_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_visible_A_fn_class *jrt.Class



type A_arbace_classes_annot_visible_fn__851000046_A struct{ j2g_header uint64 }

var A_arbace_classes_annot_visible_fn__851000046_A_fn_class *jrt.Class



type A_arbace_classes_annot_visible_fn__851000048_A struct{ j2g_header uint64; F_anns any }

var A_arbace_classes_annot_visible_fn__851000048_A_fn_class *jrt.Class



type A_arbace_classes_annot_visible_fn__851000050_A struct{ j2g_header uint64; F_anns any }

var A_arbace_classes_annot_visible_fn__851000050_A_fn_class *jrt.Class
