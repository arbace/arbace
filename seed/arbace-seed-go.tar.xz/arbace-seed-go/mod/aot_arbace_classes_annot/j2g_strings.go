//line j2g_strings.ae:1
package aot_arbace_classes_annot

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn22,arbace.classes.analyzeyn1,ayn11,arbace.corekn3,docyn2,ifys20,arbace.classes.annot11,lenient-varys11,arbace.core13,with-bindingsyn2,doyn15,element-defaultkn4,elsekn5,arraykn4,desckn10,annotationkn5,classkn4,enumkn4,namekn5,constkn3,valkn4,typekn5,valuekn6,valueskn7,visiblekn4,anonkn5,localkn8,captureskn5,statekn7,nestingkn4,ctorkn6,methodkn15,record-accessorkn7,derivedkn4,kindkn9,signaturekn6,memberkn11,inner-flagskn5,outerkn6,simplekn16,enclosing-methodkn5,ownerkn6,recordkn3,sigkn10,componentskn7,methodskn6,fieldskn6,throwskn5,indexkn4,nextkn7,entrieskn1,jkn1,dkn1,ukn1,ikn1,fkn3,refkn4,pathkn16,type-annotationskn7,memberskn11,annotationskn11,has-defaultkn17,param-annotationsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,v11,arbace.core5,referR7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn20,arbace.classes.annotm2,R8,s795,The run-time annotations' data (F14's first slice; doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As\n  built: F14 (first slice, write-ahead)\"; J2G-SPEC §12, amendment R16's note): a class's\n  RUNTIME-visible declaration annotations, its members' and its parameters', and an annotation\n  type's element defaults, as the text jrt decodes (go/arbace/jrt/annotation.ae, its format in the\n  header there). Its two writers: j2g for the classes it translates (ClassInfo.Annots, j2g's\n  out/class-registration), the interpreter for the classes it makes (Compiler$CF$Host.annotations,\n  arbace.classes.interp). Each annotation is resolved alone (arbace.classes.analyze/*lenient*):\n  one whose type or values the world cannot resolve is left out, as AnnotationParser skips an\n  annotation of a type it cannot load.v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR9,R10,R11,v11,arbace.core5,applyv11,arbace.core8,hash-mapR10,R12,v11,arbace.core10,ns-resolveR5,R13,v13,arbace.string7,replacec34,c92,R14,v11,arbace.core4,subsl1,v11,arbace.core9,contains?R15,v11,arbace.core3,strv20,arbace.classes.annot3,binR16,v11,arbace.core3,mapv20,arbace.classes.annot9,enc-valueR17,v20,arbace.classes.annot14,enc-annotationR18,R19,R20,R21,R22,R23,v11,arbace.core5,char?v20,arbace.classes.annot10,enc-stringv11,arbace.core7,ex-infov11,arbace.core6,pr-strR24,R25,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core4,keepR26,v11,arbace.core7,reversev20,arbace.classes.annot11,lenient-varv11,arbace.core14,with-bindings*v11,arbace.core5,forcev22,arbace.classes.analyze14,ctor-real-descv22,arbace.classes.analyze4,declv20,arbace.classes.types17,parse-method-descS2,R27,R28,R29,R30,l0,R31,v20,arbace.classes.annot14,safe-ctor-descS2,R32,R33,R34,R35,R36,R37,S3,R38,R27,R28,R39,R28,R27,R38,R40,R41,S2,R27,R28,R42,R33,S1,s8,<clinit>R43,R44,R45,R46,v20,arbace.classes.annot17,reflected-member?R32,R47,R48,v20,arbace.classes.annot12,throws-linesS2,R32,R33,R49,S2,R32,R33,v11,arbace.core6,get-inR50,R51,v11,arbace.core5,swap!v11,arbace.core5,assocv11,arbace.core8,assoc-inv11,arbace.core6,updateR52,S2,R53,R54,v20,arbace.classes.annot2,u1v20,arbace.classes.annot13,type-ann-bodyv20,arbace.classes.annot2,u2v20,arbace.classes.annot11,pool-index!R55,R56,R54,R57,c91,v20,arbace.classes.annot13,element-valuev11,arbace.core4,nextc64,c99,c101,c67,c68,c70,R53,c74,c90,c115,R58,c42,c46,V2,l2,l0,V2,l1,l0,V2,l0,l0,l3,v11,arbace.core6,filterv20,arbace.classes.annot11,target-infov20,arbace.classes.annot9,type-pathR59,v11,arbace.core4,atomv11,arbace.core5,doallv20,arbace.classes.annot22,type-annotations-bytesR60,S2,R32,R33,S2,R32,R33,v11,arbace.core4,namev11,arbace.core8,to-arrayR61,v20,arbace.classes.annot15,attribute-linesv11,arbace.core3,notv20,arbace.classes.annot21,type-annotation-linesv20,arbace.classes.annot7,visibleR62,R63,v20,arbace.classes.annot15,element-defaultS2,R32,R33,v20,arbace.classes.annot9,ctor-leadv11,arbace.core11,map-indexedv11,arbace.core6,vectorR64,v22,arbace.classes.analyze10,for-targetv13,arbace.string4,joinS2,R32,R33,")

var Lit_1 *jrt.String = jrt.Intern("S ")

var Lit_2 *jrt.String = jrt.Intern("l")

var Lit_3 *jrt.String = jrt.Intern("a")

var Lit_4 *jrt.String = jrt.Intern("m")

var Lit_5 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_6 *jrt.String = jrt.Intern("-")

var Lit_7 *jrt.String = jrt.Intern("<init>")

var Lit_8 *jrt.String = jrt.Intern("Q ")

var Lit_9 *jrt.String = jrt.Intern(" ")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000060__851000064")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000070__851000074")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000080__851000084")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000060__851000064$fn__851000065")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000060__851000064$fn__851000065$fn__851000066")

var Lit_15 *jrt.String = jrt.Intern("R ")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000070__851000074$fn__851000075")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000070__851000074$fn__851000075$fn__851000076")

var Lit_18 *jrt.String = jrt.Intern("G C ")

var Lit_19 *jrt.String = jrt.Intern("G M ")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000080__851000084$fn__851000085")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines$iter__851000080__851000084$fn__851000085$fn__851000086")

var Lit_22 *jrt.String = jrt.Intern("G F ")

var Lit_23 *jrt.String = jrt.Intern("/")

var Lit_24 *jrt.String = jrt.Intern(".")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000306")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000308")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000310")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000312__851000316")

var Lit_30 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000322__851000326")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000336__851000342")

var Lit_32 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000379__851000385")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000395__851000401")

var Lit_35 *jrt.String = jrt.Intern("\n")

var Lit_36 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$fn__851000200")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$fn__851000202")

var Lit_38 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$fn__851000204")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000206__851000210")

var Lit_40 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000216__851000220")

var Lit_41 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000230__851000236")

var Lit_42 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254")

var Lit_43 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000273__851000279")

var Lit_44 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000289__851000295")

var Lit_45 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000206__851000210$fn__851000211")

var Lit_46 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000206__851000210$fn__851000211$fn__851000212")

var Lit_47 *jrt.String = jrt.Intern("T ")

var Lit_48 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000216__851000220$fn__851000221")

var Lit_49 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000216__851000220$fn__851000221$fn__851000222")

var Lit_50 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000216__851000220$fn__851000221$fn__851000226")

var Lit_51 *jrt.String = jrt.Intern("D ")

var Lit_52 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000216__851000220$fn__851000221$fn__851000222$fn__851000223")

var Lit_53 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000230__851000236$fn__851000237")

var Lit_54 *jrt.String = jrt.Intern("C ")

var Lit_55 *jrt.String = jrt.Intern("M ")

var Lit_56 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000230__851000236$fn__851000237$iter__851000232__851000238")

var Lit_57 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000230__851000236$fn__851000237$iter__851000232__851000238$fn__851000239")

var Lit_58 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000230__851000236$fn__851000237$iter__851000232__851000238$fn__851000239$fn__851000240")

var Lit_59 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254$fn__851000255")

var Lit_60 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254$fn__851000255$fn__851000256")

var Lit_61 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254$fn__851000255$iter__851000248__851000258")

var Lit_62 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254$fn__851000255$iter__851000248__851000258$fn__851000259")

var Lit_63 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254$fn__851000255$iter__851000248__851000258$fn__851000259$iter__851000250__851000263")

var Lit_64 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254$fn__851000255$iter__851000248__851000258$fn__851000259$iter__851000250__851000263$fn__851000264")

var Lit_65 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000246__851000254$fn__851000255$iter__851000248__851000258$fn__851000259$iter__851000250__851000263$fn__851000264$fn__851000265")

var Lit_66 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000273__851000279$fn__851000280")

var Lit_67 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000273__851000279$fn__851000280$iter__851000275__851000281")

var Lit_68 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000273__851000279$fn__851000280$iter__851000275__851000281$fn__851000282")

var Lit_69 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000273__851000279$fn__851000280$iter__851000275__851000281$fn__851000282$fn__851000283")

var Lit_70 *jrt.String = jrt.Intern("F ")

var Lit_71 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000289__851000295$fn__851000296")

var Lit_72 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000289__851000295$fn__851000296$iter__851000291__851000297")

var Lit_73 *jrt.String = jrt.Intern("RECORD_COMPONENT")

var Lit_74 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000289__851000295$fn__851000296$iter__851000291__851000297$fn__851000298")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$fn__851000199$iter__851000289__851000295$fn__851000296$iter__851000291__851000297$fn__851000298$fn__851000299")

var Lit_76 *jrt.String = jrt.Intern("A ")

var Lit_77 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000312__851000316$fn__851000317")

var Lit_78 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000312__851000316$fn__851000317$fn__851000318")

var Lit_79 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000322__851000326$fn__851000327")

var Lit_80 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000322__851000326$fn__851000327$fn__851000328")

var Lit_81 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000322__851000326$fn__851000327$fn__851000332")

var Lit_82 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000322__851000326$fn__851000327$fn__851000328$fn__851000329")

var Lit_83 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000336__851000342$fn__851000343")

var Lit_84 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000336__851000342$fn__851000343$iter__851000338__851000344")

var Lit_85 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000336__851000342$fn__851000343$iter__851000338__851000344$fn__851000345")

var Lit_86 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000336__851000342$fn__851000343$iter__851000338__851000344$fn__851000345$fn__851000346")

var Lit_87 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360$fn__851000361")

var Lit_88 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360$fn__851000361$fn__851000362")

var Lit_89 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360$fn__851000361$iter__851000354__851000364")

var Lit_90 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360$fn__851000361$iter__851000354__851000364$fn__851000365")

var Lit_91 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360$fn__851000361$iter__851000354__851000364$fn__851000365$iter__851000356__851000369")

var Lit_92 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360$fn__851000361$iter__851000354__851000364$fn__851000365$iter__851000356__851000369$fn__851000370")

var Lit_93 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000352__851000360$fn__851000361$iter__851000354__851000364$fn__851000365$iter__851000356__851000369$fn__851000370$fn__851000371")

var Lit_94 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000379__851000385$fn__851000386")

var Lit_95 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000379__851000385$fn__851000386$iter__851000381__851000387")

var Lit_96 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000379__851000385$fn__851000386$iter__851000381__851000387$fn__851000388")

var Lit_97 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000379__851000385$fn__851000386$iter__851000381__851000387$fn__851000388$fn__851000389")

var Lit_98 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000395__851000401$fn__851000402")

var Lit_99 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000395__851000401$fn__851000402$iter__851000397__851000403")

var Lit_100 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000395__851000401$fn__851000402$iter__851000397__851000403$fn__851000404")

var Lit_101 *jrt.String = jrt.Intern("arbace.classes.annot$class_data$iter__851000395__851000401$fn__851000402$iter__851000397__851000403$fn__851000404$fn__851000405")

var Lit_102 *jrt.String = jrt.Intern("arbace.classes.annot$ctor_lead$cnt__851000055")

var Lit_103 *jrt.String = jrt.Intern("B")

var Lit_104 *jrt.String = jrt.Intern("C")

var Lit_105 *jrt.String = jrt.Intern("D")

var Lit_106 *jrt.String = jrt.Intern("F")

var Lit_107 *jrt.String = jrt.Intern("I")

var Lit_108 *jrt.String = jrt.Intern("J")

var Lit_109 *jrt.String = jrt.Intern("S")

var Lit_110 *jrt.String = jrt.Intern("Z")

var Lit_111 *jrt.String = jrt.Intern("annot: no element value ")

var Lit_112 *jrt.String = jrt.Intern("@")

var Lit_113 *jrt.String = jrt.Intern("arbace.classes.annot$enc_annotation$iter__851000028__851000032")

var Lit_114 *jrt.String = jrt.Intern("arbace.classes.annot$enc_annotation$iter__851000028__851000032$fn__851000033")

var Lit_115 *jrt.String = jrt.Intern("arbace.classes.annot$enc_annotation$iter__851000028__851000032$fn__851000033$fn__851000034")

var Lit_116 *jrt.String = jrt.Intern("\"")

var Lit_117 *jrt.String = jrt.Intern("\\\"")

var Lit_118 *jrt.String = jrt.Intern("\\\\")

var Lit_119 *jrt.String = jrt.Intern("\\u")

var Lit_120 *jrt.String = jrt.Intern("[")

var Lit_121 *jrt.String = jrt.Intern("arbace.classes.annot$enc_value$fn__851000024")

var Lit_122 *jrt.String = jrt.Intern("c")

var Lit_123 *jrt.String = jrt.Intern("e")

var Lit_124 *jrt.String = jrt.Intern("Z1")

var Lit_125 *jrt.String = jrt.Intern("Z0")

var Lit_126 *jrt.String = jrt.Intern("annot: no value ")

var Lit_127 *jrt.String = jrt.Intern("arbace.classes.annot$fn__851000017$fn__851000018")

var Lit_128 *jrt.String = jrt.Intern("arbace.classes.annot$pool_index_BANG_$fn__851000108")

var Lit_129 *jrt.String = jrt.Intern("annot: no declaration target ")

var Lit_130 *jrt.String = jrt.Intern("arbace.classes.annot$throws_lines$iter__851000092__851000096")

var Lit_131 *jrt.String = jrt.Intern("arbace.classes.annot$throws_lines$iter__851000092__851000096$fn__851000097")

var Lit_132 *jrt.String = jrt.Intern("arbace.classes.annot$throws_lines$iter__851000092__851000096$fn__851000097$fn__851000098")

var Lit_133 *jrt.String = jrt.Intern("E ")

var Lit_134 *jrt.String = jrt.Intern("arbace.classes.annot$throws_lines$iter__851000092__851000096$fn__851000097$fn__851000102")

var Lit_135 *jrt.String = jrt.Intern("arbace.classes.annot$throws_lines$iter__851000092__851000096$fn__851000097$fn__851000098$fn__851000099")

var Lit_136 *jrt.String = jrt.Intern("Y T ")

var Lit_137 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000159__851000163")

var Lit_138 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000169__851000173")

var Lit_139 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000179__851000183")

var Lit_140 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000159__851000163$fn__851000164")

var Lit_141 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000159__851000163$fn__851000164$fn__851000165")

var Lit_142 *jrt.String = jrt.Intern("Y C ")

var Lit_143 *jrt.String = jrt.Intern("Y M ")

var Lit_144 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000169__851000173$fn__851000174")

var Lit_145 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000169__851000173$fn__851000174$fn__851000175")

var Lit_146 *jrt.String = jrt.Intern("Y F ")

var Lit_147 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000179__851000183$fn__851000184")

var Lit_148 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines$iter__851000179__851000183$fn__851000184$fn__851000185")

var Lit_149 *jrt.String = jrt.Intern("N ")

var Lit_150 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotations_bytes$fn__851000146")

var Lit_151 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotations_bytes$fn__851000148")

var Lit_152 *jrt.String = jrt.Intern("")

var Lit_153 *jrt.String = jrt.Intern("arbace.classes.annot$type_path$fn__851000132")

var Lit_154 *jrt.String = jrt.Intern(";")

var Lit_155 *jrt.String = jrt.Intern("arbace.classes.annot$visible$fn__851000046")

var Lit_156 *jrt.String = jrt.Intern("arbace.classes.annot$visible$fn__851000048")

var Lit_157 *jrt.String = jrt.Intern("arbace.classes.annot$visible$fn__851000050")

var Lit_158 *jrt.String = jrt.Intern("kn3,docyn11,arbace.coreyn22,arbace.classes.analyzeyn9,*lenient*kn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,&yn4,bodyyn1,dkn3,tagyn6,Stringkn8,declaredyn1,vyn2,anyn4,annsyn1,nyn2,mmyn7,membersyn4,poolyn3,tagyn29,java.io.ByteArrayOutputStreamyn3,outyn3,refkn4,keysyn6,throwsv11,arbace.core5,in-nsMyn20,arbace.classes.annotm2,R0,s795,The run-time annotations' data (F14's first slice; doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As\n  built: F14 (first slice, write-ahead)\"; J2G-SPEC §12, amendment R16's note): a class's\n  RUNTIME-visible declaration annotations, its members' and its parameters', and an annotation\n  type's element defaults, as the text jrt decodes (go/arbace/jrt/annotation.ae, its format in the\n  header there). Its two writers: j2g for the classes it translates (ClassInfo.Annots, j2g's\n  out/class-registration), the interpreter for the classes it makes (Compiler$CF$Host.annotations,\n  arbace.classes.interp). Each annotation is resolved alone (arbace.classes.analyze/*lenient*):\n  one whose type or values the world cannot resolve is left out, as AnnotationParser skips an\n  annotation of a type it cannot load.m2,R0,s795,The run-time annotations' data (F14's first slice; doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As\n  built: F14 (first slice, write-ahead)\"; J2G-SPEC §12, amendment R16's note): a class's\n  RUNTIME-visible declaration annotations, its members' and its parameters', and an annotation\n  type's element defaults, as the text jrt decodes (go/arbace/jrt/annotation.ae, its format in the\n  header there). Its two writers: j2g for the classes it translates (ClassInfo.Annots, j2g's\n  out/class-registration), the interpreter for the classes it makes (Compiler$CF$Host.annotations,\n  arbace.classes.interp). Each annotation is resolved alone (arbace.classes.analyze/*lenient*):\n  one whose type or values the world cannot resolve is left out, as AnnotationParser skips an\n  annotation of a type it cannot load.R1,v20,arbace.classes.annot11,lenient-varv11,arbace.core10,ns-resolveR2,R3,m8,R4,TR5,i19,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot7,lenientm10,R4,TR8,L1,V2,R9,R10,R5,i21,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot15,element-defaultm8,R4,TR5,i25,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot3,binm12,R4,TR8,L1,V1,R11,R0,s31,A descriptor with binary names.R5,i28,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot10,enc-stringm10,R8,L1,V1,Myn1,sm2,R12,R13,R0,s77,\"TEXT\": \\\" and \\\\ escaped, every code unit outside printable ASCII as \\uXXXX.R5,i30,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot14,enc-annotationm8,R14,TR5,i45,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot9,enc-valuem10,R8,L1,V1,R15,R0,s70,A VALUE of the data: v as arbace.classes.analyze's ann-value gives it.R5,i47,R6,i1,R7,s23,arbace/classes/annot.aem10,R8,L1,V1,R16,R0,s30,An ANN: @DESC N NAME VALUE ...R5,i72,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot7,visiblem12,R4,TR8,L1,V1,R17,R0,s372,The RUNTIME-visible annotations of an analyzed list (a delay), each encoded, in the source's\n  order; an annotation that does not encode is left out. The source's order is the list's\n  reversed: repr/java writes one ^{A ...} a declaration annotation, and the reader assocs each\n  outer ^ map onto the inner one's (LispReader's MetaReader), so the last written comes first.R5,i79,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot14,safe-ctor-descm12,R4,TR8,L1,V2,R18,R19,R0,s200,The descriptor of constructor mm of class n with its implicit parameters (the class file's,\n  which jrt's Constructor has: an inner class's outer instance, an enum's name and ordinal), else\n  its own.R5,i89,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot9,ctor-leadm12,R4,TR8,L1,V2,R18,R19,R0,s388,JCS351 (a): the count of constructor mm's leading implicit parameters (the outer instance, a superclass's outer\n  instance, an enum's name and ordinal), by which the JDK's Constructor.getParameterAnnotations shifts the class\n  file's (handleParameterNumberMismatch: a member class's one, an enum's two); the trailing captured values come\n  after the declared parameters and shift nothing.R5,i96,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot17,reflected-member?m12,R4,TR8,L1,V1,R19,R0,s276,A method or constructor whose Signature and annotations the class file keeps: a declared one, or a record's derived\n  accessor (JCS383 (a): javac writes the accessor it derives with its Signature and the component's METHOD\n  annotations, as arbace.classes.analyze derives it).R5,i107,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot12,throws-linesm8,R14,TR5,i114,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot15,attribute-linesm10,R8,L1,V3,R18,R11,R20,R0,s463,F25 (doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As built: F25 (write-ahead)\"): the class file\n  attributes reflection reads, as data lines beside the annotations' (go/arbace/jrt/classdata.ae\n  decodes them; jdk26u's Class, Method, Constructor and Field read the same attributes through\n  the VM): the class's Signature (S), its InnerClasses entry and EnclosingMethod (K, Q), and with\n  members its methods', constructors' and fields' Signatures (G) and Exceptions (E).R5,i116,R6,i1,R7,s23,arbace/classes/annot.aem10,R8,L1,V2,R18,R11,R0,s572,The E records of class n (analyzed: d): its methods' and constructors' Exceptions attributes. Written with the\n  members' data (attribute-lines) and, since F27 (JCS240 (a), doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As built: F27\n  (write-ahead)\"), alone for every other class j2g translates (class-data's :throws): RMI's remote interfaces are the\n  JDK's (Registry, DGC, JMX's RMIServer and RMIConnection), and sun.rmi.server.Util.checkMethod requires each of their\n  methods to declare RemoteException, as RemoteObjectInvocationHandler rethrows only what the method declares.R5,i158,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot11,pool-index!m12,R4,TR8,L1,V3,R21,R22,R15,R0,s290,The index of constant pool entry [tag value] in pool (an atom: {:next i :index {} :entries []}), added when\n  new: tag :u (CONSTANT_Utf8), :i (Integer), :j (Long), :f (Float, raw int bits), :d (Double, raw long bits);\n  a Long or a Double takes two indices, as in a class file (JVMS 4.4.5).R5,i180,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot2,u1m10,R4,TR8,L1,V2,Myn3,outm2,R12,R23,R15,R5,i193,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot2,u2m10,R4,TR8,L1,V2,R24,R15,R5,i194,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot13,type-ann-bodym8,R14,TR5,i196,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot13,element-valuem12,R4,TR8,L1,V3,R24,R21,R15,R0,s88,element_value (JVMS 4.7.16.1) of value v as arbace.classes.analyze's ann-value gives it.R5,i198,R6,i1,R7,s23,arbace/classes/annot.aem12,R4,TR8,L1,V3,R24,R21,R16,R0,s65,An annotation's type_index and element_value_pairs (JVMS 4.7.16).R5,i220,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot11,target-infom12,R4,TR8,L1,V2,R24,R25,R0,s99,target_type and target_info (JVMS 4.7.20.1) of an ASM type reference value ref (arbace.classes.go).R5,i229,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot9,type-pathm12,R4,TR8,L1,V2,R24,Myn4,pathm2,R12,R13,R0,s110,type_path (JVMS 4.7.20.2) of an ASM type path string: [ array, . nested, * wildcard bound, N; type argument N.R5,i242,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot22,type-annotations-bytesm10,R8,L1,V2,R21,R17,R0,s401,The RuntimeVisibleTypeAnnotations attribute's info (num_annotations, then each type_annotation) of the analyzed\n  type annotations anns (a delay of [{:type :visible :values :ref :path}]), its constants in pool, as hex; nil when\n  none is RUNTIME-visible or one does not encode (an annotation the world cannot resolve is left out, as\n  analyze's *lenient* leaves it out of the declaration annotations).R5,i257,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot21,type-annotation-linesm10,R8,L1,V3,R18,R11,R20,R0,s202,JCS271 (b): the Y records (a class's, its methods', constructors' and fields' RuntimeVisibleTypeAnnotations, as\n  hex) and the N records of the constant pool entries they index (in index order, from 1).R5,i277,R6,i1,R7,s23,arbace/classes/annot.aev20,arbace.classes.annot10,class-datam10,R8,L1,V3,R18,R9,m2,R26,V2,R20,R27,R0,s425,The data of class n (internal name, analyzed: arbace.classes.analyze/decl): its own\n  annotations and its element defaults (an annotation type's), and with :members its methods',\n  constructors', fields' and parameters'; since F25 the reflected attributes beside them\n  (attribute-lines); with :throws (F27, JCS240 (a)) the Exceptions records (E) of a class whose other members' data is\n  not written. nil when there is none.R5,i304,R6,i1,R7,s23,arbace/classes/annot.ae")

var Lit_159 *jrt.String = jrt.Intern("arbace.classes.annot$eval851000004$loading__1927001464__auto____851000005")

var Lit_160 *jrt.String = jrt.Intern("arbace.classes.annot$eval851000008$fn__851000009")

var Lit_161 *jrt.String = jrt.Intern("arbace.classes.annot$lenient")

var Lit_162 *jrt.String = jrt.Intern("arbace.classes.annot$fn__851000017")

var Lit_163 *jrt.String = jrt.Intern("arbace.classes.annot$bin")

var Lit_164 *jrt.String = jrt.Intern("arbace.classes.annot$enc_string")

var Lit_165 *jrt.String = jrt.Intern("arbace.classes.annot$enc_value")

var Lit_166 *jrt.String = jrt.Intern("arbace.classes.annot$enc_annotation")

var Lit_167 *jrt.String = jrt.Intern("arbace.classes.annot$visible")

var Lit_168 *jrt.String = jrt.Intern("arbace.classes.annot$safe_ctor_desc")

var Lit_169 *jrt.String = jrt.Intern("arbace.classes.annot$ctor_lead")

var Lit_170 *jrt.String = jrt.Intern("arbace.classes.annot$reflected_member_QMARK_")

var Lit_171 *jrt.String = jrt.Intern("arbace.classes.annot$attribute_lines")

var Lit_172 *jrt.String = jrt.Intern("arbace.classes.annot$throws_lines")

var Lit_173 *jrt.String = jrt.Intern("arbace.classes.annot$pool_index_BANG_")

var Lit_174 *jrt.String = jrt.Intern("arbace.classes.annot$u1")

var Lit_175 *jrt.String = jrt.Intern("arbace.classes.annot$u2")

var Lit_176 *jrt.String = jrt.Intern("arbace.classes.annot$element_value")

var Lit_177 *jrt.String = jrt.Intern("arbace.classes.annot$type_ann_body")

var Lit_178 *jrt.String = jrt.Intern("arbace.classes.annot$target_info")

var Lit_179 *jrt.String = jrt.Intern("arbace.classes.annot$type_path")

var Lit_180 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotations_bytes")

var Lit_181 *jrt.String = jrt.Intern("arbace.classes.annot$type_annotation_lines")

var Lit_182 *jrt.String = jrt.Intern("arbace.classes.annot$class_data")
