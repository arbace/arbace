//line j2g_classes.ae:1
package aot_arbace_classes_native

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_classes_native_compile_and_load_BANG__A_class, Name: "arbace.classes.native$compile_and_load_BANG_", Modifiers: 25, Simple: "compile_and_load_BANG_", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_and_load_BANG__A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_class, Name: "arbace.classes.native$compile_and_load_BANG_$iter__1078000015__1078000019", Modifiers: 25, Simple: "iter__1078000015__1078000019", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_and_load_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_class, Name: "arbace.classes.native$compile_and_load_BANG_$iter__1078000015__1078000019$fn__1078000020", Modifiers: 25, Simple: "fn__1078000020", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_class, Name: "arbace.classes.native$compile_and_load_BANG_$iter__1078000015__1078000019$fn__1078000020$fn__1078000021", Modifiers: 25, Simple: "fn__1078000021", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_deftype_A_class, Name: "arbace.classes.native$compile_deftype", Modifiers: 25, Simple: "compile_deftype", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_deftype_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_deftype_fn__1078000049_A_class, Name: "arbace.classes.native$compile_deftype$fn__1078000049", Modifiers: 25, Simple: "fn__1078000049", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_deftype_fn__1078000049_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_deftype_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_A_class, Name: "arbace.classes.native$compile_fn", Modifiers: 25, Simple: "compile_fn", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000138_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000138", Modifiers: 25, Simple: "fn__1078000138", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000138_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000140_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000140", Modifiers: 25, Simple: "fn__1078000140", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000140_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000142_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000142", Modifiers: 25, Simple: "fn__1078000142", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000142_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000142$fn__1078000143", Modifiers: 25, Simple: "fn__1078000143", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_fn__1078000142_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000142$fn__1078000145", Modifiers: 25, Simple: "fn__1078000145", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_fn__1078000142_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_class, Name: "arbace.classes.native$compile_fn$iter__1078000122__1078000126", Modifiers: 25, Simple: "iter__1078000122__1078000126", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_class, Name: "arbace.classes.native$compile_fn$iter__1078000122__1078000126$fn__1078000127", Modifiers: 25, Simple: "fn__1078000127", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_class, Name: "arbace.classes.native$compile_fn$iter__1078000122__1078000126$fn__1078000127$fn__1078000128", Modifiers: 25, Simple: "fn__1078000128", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_A_class, Name: "arbace.classes.native$compile_top", Modifiers: 25, Simple: "compile_top", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_class, Name: "arbace.classes.native$compile_top$iter__1078000032__1078000036", Modifiers: 25, Simple: "iter__1078000032__1078000036", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_class, Name: "arbace.classes.native$compile_top$iter__1078000032__1078000036$fn__1078000037", Modifiers: 25, Simple: "fn__1078000037", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_class, Name: "arbace.classes.native$compile_top$iter__1078000032__1078000036$fn__1078000037$fn__1078000038", Modifiers: 25, Simple: "fn__1078000038", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class, Name: "arbace.classes.native$eval1078000004$loading__1927001464__auto____1078000005", Modifiers: 25, Simple: "loading__1927001464__auto____1078000005", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A", Source: "native.ae", Declaring: &A_arbace_classes_native_eval1078000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_eval1078000008_fn__1078000009_A_class, Name: "arbace.classes.native$eval1078000008$fn__1078000009", Modifiers: 25, Simple: "fn__1078000009", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000008_fn__1078000009_A", Source: "native.ae", Declaring: &A_arbace_classes_native_eval1078000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_field_names_A_class, Name: "arbace.classes.native$field_names", Modifiers: 25, Simple: "field_names", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_field_names_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_A_class, Name: "arbace.classes.native$fn_class_form", Modifiers: 25, Simple: "fn_class_form", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_fn__1078000097_A_class, Name: "arbace.classes.native$fn_class_form$fn__1078000097", Modifiers: 25, Simple: "fn__1078000097", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_fn__1078000097_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_fn__1078000113_A_class, Name: "arbace.classes.native$fn_class_form$fn__1078000113", Modifiers: 25, Simple: "fn__1078000113", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_fn__1078000113_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000074__1078000078", Modifiers: 25, Simple: "iter__1078000074__1078000078", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000074__1078000078$fn__1078000079", Modifiers: 25, Simple: "fn__1078000079", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000074__1078000078$fn__1078000079$fn__1078000080", Modifiers: 25, Simple: "fn__1078000080", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000102__1078000106", Modifiers: 25, Simple: "iter__1078000102__1078000106", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000102__1078000106$fn__1078000107", Modifiers: 25, Simple: "fn__1078000107", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000102__1078000106$fn__1078000107$fn__1078000108", Modifiers: 25, Simple: "fn__1078000108", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_typed__1078000072_A_class, Name: "arbace.classes.native$fn_class_form$typed__1078000072", Modifiers: 25, Simple: "typed__1078000072", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_typed__1078000072_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_local_class_A_class, Name: "arbace.classes.native$local_class", Modifiers: 25, Simple: "local_class", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_local_class_fn__1078000054_A_class, Name: "arbace.classes.native$local_class$fn__1078000054", Modifiers: 25, Simple: "fn__1078000054", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_fn__1078000054_A", Source: "native.ae", Declaring: &A_arbace_classes_native_local_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_local_class_fn__1078000056_A_class, Name: "arbace.classes.native$local_class$fn__1078000056", Modifiers: 25, Simple: "fn__1078000056", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_fn__1078000056_A", Source: "native.ae", Declaring: &A_arbace_classes_native_local_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_public_class_QMARK__A_class, Name: "arbace.classes.native$public_class_QMARK_", Modifiers: 25, Simple: "public_class_QMARK_", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_public_class_QMARK__A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_type_form_A_class, Name: "arbace.classes.native$type_form", Modifiers: 25, Simple: "type_form", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_type_form_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_classes_native_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_A_New()}; return nil }

var A_arbace_classes_native_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_A_new}

var A_arbace_classes_native_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_A"})

func init() { i := A_arbace_classes_native_A_class.Info(); i.IsInstance = A_arbace_classes_native_A_InstanceOf; i.Init = A_arbace_classes_native_A_Init; i.Table = A_arbace_classes_native_A_members }

var A_arbace_classes_native_compile_and_load_BANG__A_class *jrt.Class

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_class *jrt.Class

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_class *jrt.Class

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_class *jrt.Class

var A_arbace_classes_native_compile_deftype_A_class *jrt.Class

var A_arbace_classes_native_compile_deftype_fn__1078000049_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000138_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000140_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000142_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_class *jrt.Class

var A_arbace_classes_native_compile_top_A_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_class *jrt.Class

func A_arbace_classes_native_eval1078000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000004_A_New()}; return nil }

var A_arbace_classes_native_eval1078000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_eval1078000004_A_new}

var A_arbace_classes_native_eval1078000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_native_A_class, Simple: "eval1078000004", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000004_A"})

func init() { i := A_arbace_classes_native_eval1078000004_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000004_A_InstanceOf; i.Table = A_arbace_classes_native_eval1078000004_A_members }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class *jrt.Class

func A_arbace_classes_native_eval1078000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000008_A_New()}; return nil }

var A_arbace_classes_native_eval1078000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_eval1078000008_A_new}

var A_arbace_classes_native_eval1078000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_native_A_class, Simple: "eval1078000008", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000008_A"})

func init() { i := A_arbace_classes_native_eval1078000008_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000008_A_InstanceOf; i.Table = A_arbace_classes_native_eval1078000008_A_members }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_class *jrt.Class

var A_arbace_classes_native_field_names_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_fn__1078000097_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_fn__1078000113_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_typed__1078000072_A_class *jrt.Class

var A_arbace_classes_native_local_class_A_class *jrt.Class

var A_arbace_classes_native_local_class_fn__1078000054_A_class *jrt.Class

var A_arbace_classes_native_local_class_fn__1078000056_A_class *jrt.Class

var A_arbace_classes_native_public_class_QMARK__A_class *jrt.Class

var A_arbace_classes_native_type_form_A_class *jrt.Class

func A_arbace_classes_native__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_native__init_A_Load__O()}; return nil }

func A_arbace_classes_native__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native__init_A_New()}; return nil }

var A_arbace_classes_native__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_native__init_A_invoke, New: A_arbace_classes_native__init_A_new}

var A_arbace_classes_native__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native__init_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native__init_A_class.Info(); i.IsInstance = A_arbace_classes_native__init_A_InstanceOf; i.Init = A_arbace_classes_native__init_A_Init; i.Table = A_arbace_classes_native__init_A_members }
