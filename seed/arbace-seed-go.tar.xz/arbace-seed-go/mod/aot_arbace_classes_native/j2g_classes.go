//line j2g_classes.ae:1
package aot_arbace_classes_native

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_classes_native_compile_deftype_A_class, Name: "arbace.classes.native$compile_deftype", Modifiers: 25, Simple: "compile_deftype", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_deftype_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_deftype_fn__1078000029_A_class, Name: "arbace.classes.native$compile_deftype$fn__1078000029", Modifiers: 25, Simple: "fn__1078000029", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_deftype_fn__1078000029_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_deftype_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_A_class, Name: "arbace.classes.native$compile_fn", Modifiers: 25, Simple: "compile_fn", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000118_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000118", Modifiers: 25, Simple: "fn__1078000118", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000118_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000120_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000120", Modifiers: 25, Simple: "fn__1078000120", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000120_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000122_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000122", Modifiers: 25, Simple: "fn__1078000122", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000122_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000122$fn__1078000123", Modifiers: 25, Simple: "fn__1078000123", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_fn__1078000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_class, Name: "arbace.classes.native$compile_fn$fn__1078000122$fn__1078000125", Modifiers: 25, Simple: "fn__1078000125", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_fn__1078000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class, Name: "arbace.classes.native$compile_fn$iter__1078000102__1078000106", Modifiers: 25, Simple: "iter__1078000102__1078000106", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class, Name: "arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107", Modifiers: 25, Simple: "fn__1078000107", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class, Name: "arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107$fn__1078000108", Modifiers: 25, Simple: "fn__1078000108", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_A_class, Name: "arbace.classes.native$compile_top", Modifiers: 25, Simple: "compile_top", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class, Name: "arbace.classes.native$compile_top$iter__1078000012__1078000016", Modifiers: 25, Simple: "iter__1078000012__1078000016", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class, Name: "arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017", Modifiers: 25, Simple: "fn__1078000017", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_class, Name: "arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017$fn__1078000018", Modifiers: 25, Simple: "fn__1078000018", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A", Source: "native.ae", Declaring: &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class, Name: "arbace.classes.native$eval1078000004$loading__1927001464__auto____1078000005", Modifiers: 25, Simple: "loading__1927001464__auto____1078000005", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A", Source: "native.ae", Declaring: &A_arbace_classes_native_eval1078000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_eval1078000008_fn__1078000009_A_class, Name: "arbace.classes.native$eval1078000008$fn__1078000009", Modifiers: 25, Simple: "fn__1078000009", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000008_fn__1078000009_A", Source: "native.ae", Declaring: &A_arbace_classes_native_eval1078000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_field_names_A_class, Name: "arbace.classes.native$field_names", Modifiers: 25, Simple: "field_names", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_field_names_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_A_class, Name: "arbace.classes.native$fn_class_form", Modifiers: 25, Simple: "fn_class_form", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_fn__1078000077_A_class, Name: "arbace.classes.native$fn_class_form$fn__1078000077", Modifiers: 25, Simple: "fn__1078000077", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_fn__1078000077_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_fn__1078000093_A_class, Name: "arbace.classes.native$fn_class_form$fn__1078000093", Modifiers: 25, Simple: "fn__1078000093", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_fn__1078000093_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000054__1078000058", Modifiers: 25, Simple: "iter__1078000054__1078000058", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059", Modifiers: 25, Simple: "fn__1078000059", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059$fn__1078000060", Modifiers: 25, Simple: "fn__1078000060", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000082__1078000086", Modifiers: 25, Simple: "iter__1078000082__1078000086", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087", Modifiers: 25, Simple: "fn__1078000087", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_class, Name: "arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087$fn__1078000088", Modifiers: 25, Simple: "fn__1078000088", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_fn_class_form_typed__1078000052_A_class, Name: "arbace.classes.native$fn_class_form$typed__1078000052", Modifiers: 25, Simple: "typed__1078000052", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_typed__1078000052_A", Source: "native.ae", Declaring: &A_arbace_classes_native_fn_class_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_local_class_A_class, Name: "arbace.classes.native$local_class", Modifiers: 25, Simple: "local_class", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_local_class_fn__1078000034_A_class, Name: "arbace.classes.native$local_class$fn__1078000034", Modifiers: 25, Simple: "fn__1078000034", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_fn__1078000034_A", Source: "native.ae", Declaring: &A_arbace_classes_native_local_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_local_class_fn__1078000036_A_class, Name: "arbace.classes.native$local_class$fn__1078000036", Modifiers: 25, Simple: "fn__1078000036", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_fn__1078000036_A", Source: "native.ae", Declaring: &A_arbace_classes_native_local_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_public_class_QMARK__A_class, Name: "arbace.classes.native$public_class_QMARK_", Modifiers: 25, Simple: "public_class_QMARK_", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_public_class_QMARK__A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_native_type_form_A_class, Name: "arbace.classes.native$type_form", Modifiers: 25, Simple: "type_form", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_type_form_A", Source: "native.ae", Declaring: &A_arbace_classes_native_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_classes_native_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_A_New()}; return nil }

var A_arbace_classes_native_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_A_new}

var A_arbace_classes_native_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_A"})

func init() { i := A_arbace_classes_native_A_class.Info(); i.IsInstance = A_arbace_classes_native_A_InstanceOf; i.Init = A_arbace_classes_native_A_Init; i.Table = A_arbace_classes_native_A_members }

var A_arbace_classes_native_compile_deftype_A_class *jrt.Class

var A_arbace_classes_native_compile_deftype_fn__1078000029_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000118_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000120_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000122_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class *jrt.Class

var A_arbace_classes_native_compile_top_A_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_class *jrt.Class

func A_arbace_classes_native_eval1078000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000004_A_New()}; return nil }

var A_arbace_classes_native_eval1078000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_eval1078000004_A_new}

var A_arbace_classes_native_eval1078000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_native_A_class, Simple: "eval1078000004", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000004_A"})

func init() { i := A_arbace_classes_native_eval1078000004_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000004_A_InstanceOf; i.Table = A_arbace_classes_native_eval1078000004_A_members }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class *jrt.Class

func A_arbace_classes_native_eval1078000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000008_A_New()}; return nil }

var A_arbace_classes_native_eval1078000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_eval1078000008_A_new}

var A_arbace_classes_native_eval1078000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_native_A_class, Simple: "eval1078000008", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000008_A"})

func init() { i := A_arbace_classes_native_eval1078000008_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000008_A_InstanceOf; i.Table = A_arbace_classes_native_eval1078000008_A_members }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_class *jrt.Class

var A_arbace_classes_native_field_names_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_fn__1078000077_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_fn__1078000093_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_class *jrt.Class

var A_arbace_classes_native_fn_class_form_typed__1078000052_A_class *jrt.Class

var A_arbace_classes_native_local_class_A_class *jrt.Class

var A_arbace_classes_native_local_class_fn__1078000034_A_class *jrt.Class

var A_arbace_classes_native_local_class_fn__1078000036_A_class *jrt.Class

var A_arbace_classes_native_public_class_QMARK__A_class *jrt.Class

var A_arbace_classes_native_type_form_A_class *jrt.Class

func A_arbace_classes_native__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_native__init_A_Load__O()}; return nil }

func A_arbace_classes_native__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native__init_A_New()}; return nil }

var A_arbace_classes_native__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_native__init_A_invoke, New: A_arbace_classes_native__init_A_new}

var A_arbace_classes_native__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native__init_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native__init_A_class.Info(); i.IsInstance = A_arbace_classes_native__init_A_InstanceOf; i.Init = A_arbace_classes_native__init_A_Init; i.Table = A_arbace_classes_native__init_A_members }
