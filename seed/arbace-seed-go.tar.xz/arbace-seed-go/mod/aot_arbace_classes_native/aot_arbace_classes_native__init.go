//line aot_arbace_classes_native__init.ae:1
package aot_arbace_classes_native

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_native__init_A_Unit0__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_native__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native__init_A_const_1) }
//line :1:1
func A_arbace_classes_native__init_A_Unit1__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_native__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_2)) }
//line :1:1
func A_arbace_classes_native__init_A_Unit2__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_native__init_A_Unit3__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_native__init_A_const_1)).Equals_O__Z(A_arbace_classes_native__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_native_eval1078000008_fn__1078000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_native__init_A_Load__O() any { A_arbace_classes_native__init_A_Init(); jrt.StartCheck(); A_arbace_classes_native__init_A_Unit0__O(); A_arbace_classes_native__init_A_Unit1__O(); A_arbace_classes_native__init_A_Unit2__O(); A_arbace_classes_native__init_A_Unit3__O(); A_arbace_classes_native__init_A_Unit4__O(); A_arbace_classes_native__init_A_Unit5__O(); A_arbace_classes_native__init_A_Unit6__O(); A_arbace_classes_native__init_A_Unit7__O(); A_arbace_classes_native__init_A_Unit8__O(); A_arbace_classes_native__init_A_Unit9__O(); A_arbace_classes_native__init_A_Unit10__O(); A_arbace_classes_native__init_A_Unit11__O(); A_arbace_classes_native__init_A_Unit12__O(); A_arbace_classes_native__init_A_Unit13__O(); A_arbace_classes_native__init_A_Unit14__O(); A_arbace_classes_native__init_A_Unit15__O(); return nil }




















func A_arbace_classes_native__init_A_Unit4__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_4; var tmp2 any; if








	jrt.System_Getenv_String__String(Lit_42) != nil { var root_3 any = A_arbace_classes_native__init_A_const_5.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_5 lang.IFn; if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = lang.PersistentVector_EMPTY.Ref(); if linked_4 == nil { tmp2 = ifn_5.Invoke_O__O(arg_6) } else { tmp2 = linked_4.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3, arg_6) } } else { tmp2 = nil }; /*line :26:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_classes_native__init_A_const_4; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_6)); return A_arbace_classes_native__init_A_const_4 }










func A_arbace_classes_native__init_A_Unit5__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_7; var tmp2 any = A_arbace_classes_native_symbols_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_native_symbols_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_classes_native_symbols_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_8)); return A_arbace_classes_native__init_A_const_7 }








func A_arbace_classes_native__init_A_Unit6__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_9; var tmp2 any = A_arbace_classes_native_form_vars_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_native_form_vars_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_classes_native_form_vars_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_10)); return A_arbace_classes_native__init_A_const_9 }





















func A_arbace_classes_native__init_A_Unit7__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_11; var tmp2 any = A_arbace_classes_native_compile_and_load_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, true); A_arbace_classes_native_compile_and_load_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_12)); return A_arbace_classes_native__init_A_const_11 }















func A_arbace_classes_native__init_A_Unit8__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_13; var tmp2 any = A_arbace_classes_native_compile_top_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_native_compile_top_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_classes_native_compile_top_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_14)); return A_arbace_classes_native__init_A_const_13 }















func A_arbace_classes_native__init_A_Unit9__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_15; var tmp2 any = A_arbace_classes_native_compile_deftype_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_native_compile_deftype_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_classes_native_compile_deftype_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_16)); return A_arbace_classes_native__init_A_const_15 }











func A_arbace_classes_native__init_A_Unit10__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_17; var tmp2 any = A_arbace_classes_native_public_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_native_public_class_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_native_public_class_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_18)); return A_arbace_classes_native__init_A_const_17 }





func A_arbace_classes_native__init_A_Unit11__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_19; var tmp2 any = A_arbace_classes_native_type_form_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_native_type_form_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_native_type_form_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_20)); return A_arbace_classes_native__init_A_const_19 }







func A_arbace_classes_native__init_A_Unit12__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_21; var tmp2 any = A_arbace_classes_native_local_class_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_native_local_class_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_native_local_class_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_22)); return A_arbace_classes_native__init_A_const_21 }













func A_arbace_classes_native__init_A_Unit13__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(140, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_23; var tmp2 any = A_arbace_classes_native_field_names_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_native_field_names_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_native_field_names_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_24)); return A_arbace_classes_native__init_A_const_23 }









func A_arbace_classes_native__init_A_Unit14__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(150, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_25; var tmp2 any = A_arbace_classes_native_fn_class_form_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_native_fn_class_form_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_classes_native_fn_class_form_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_26)); return A_arbace_classes_native__init_A_const_25 }

























func A_arbace_classes_native__init_A_Unit15__O() any { A_arbace_classes_native__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_classes_native__init_A_const_27; var tmp2 any = A_arbace_classes_native_compile_fn_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_native_compile_fn_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_native_compile_fn_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_native__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_native__init_A_const_28)); return A_arbace_classes_native__init_A_const_27 }



type A_arbace_classes_native__init_A struct{ jrt.Object }

var A_arbace_classes_native__init_A_const_pool *jrt.RefArray

var A_arbace_classes_native__init_A_const_0 *lang.Var

var A_arbace_classes_native__init_A_const_1 any

var A_arbace_classes_native__init_A_const_2 any

var A_arbace_classes_native__init_A_const_3 any

var A_arbace_classes_native__init_A_const_4 *lang.Var

var A_arbace_classes_native__init_A_const_5 *lang.Var

var A_arbace_classes_native__init_A_const_6 any

var A_arbace_classes_native__init_A_const_7 *lang.Var

var A_arbace_classes_native__init_A_const_8 any

var A_arbace_classes_native__init_A_const_9 *lang.Var

var A_arbace_classes_native__init_A_const_10 any

var A_arbace_classes_native__init_A_const_11 *lang.Var

var A_arbace_classes_native__init_A_const_12 any

var A_arbace_classes_native__init_A_const_13 *lang.Var

var A_arbace_classes_native__init_A_const_14 any

var A_arbace_classes_native__init_A_const_15 *lang.Var

var A_arbace_classes_native__init_A_const_16 any

var A_arbace_classes_native__init_A_const_17 *lang.Var

var A_arbace_classes_native__init_A_const_18 any

var A_arbace_classes_native__init_A_const_19 *lang.Var

var A_arbace_classes_native__init_A_const_20 any

var A_arbace_classes_native__init_A_const_21 *lang.Var

var A_arbace_classes_native__init_A_const_22 any

var A_arbace_classes_native__init_A_const_23 *lang.Var

var A_arbace_classes_native__init_A_const_24 any

var A_arbace_classes_native__init_A_const_25 *lang.Var

var A_arbace_classes_native__init_A_const_26 any

var A_arbace_classes_native__init_A_const_27 *lang.Var

var A_arbace_classes_native__init_A_const_28 any

var A_arbace_classes_native__init_A_init jrt.ClassInit

func A_arbace_classes_native__init_A_Init() { if !A_arbace_classes_native__init_A_init.Done() { A_arbace_classes_native__init_A_init.Run(A_arbace_classes_native__init_A_clinit) } }

func A_arbace_classes_native__init_A_clinit() { A_arbace_classes_native__init_A_clinit_p0(); A_arbace_classes_native__init_A_clinit_p1(); A_arbace_classes_native__init_A_clinit_p2() }

func A_arbace_classes_native__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_native__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_39, 50); A_arbace_classes_native__init_A_const_0 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[21]); A_arbace_classes_native__init_A_const_1 = A_arbace_classes_native__init_A_const_pool.A[22]; A_arbace_classes_native__init_A_const_2 = A_arbace_classes_native__init_A_const_pool.A[23]; A_arbace_classes_native__init_A_const_3 = A_arbace_classes_native__init_A_const_pool.A[24]; A_arbace_classes_native__init_A_const_4 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[25]); A_arbace_classes_native__init_A_const_5 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[26]); A_arbace_classes_native__init_A_const_6 = A_arbace_classes_native__init_A_const_pool.A[27]; A_arbace_classes_native__init_A_const_7 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[28]); A_arbace_classes_native__init_A_const_8 = A_arbace_classes_native__init_A_const_pool.A[29]; A_arbace_classes_native__init_A_const_9 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[30]); A_arbace_classes_native__init_A_const_10 = A_arbace_classes_native__init_A_const_pool.A[31]; A_arbace_classes_native__init_A_const_11 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[32]); A_arbace_classes_native__init_A_const_12 = A_arbace_classes_native__init_A_const_pool.A[33] }

func A_arbace_classes_native__init_A_clinit_p1() { A_arbace_classes_native__init_A_const_13 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[34]); A_arbace_classes_native__init_A_const_14 = A_arbace_classes_native__init_A_const_pool.A[35]; A_arbace_classes_native__init_A_const_15 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[36]); A_arbace_classes_native__init_A_const_16 = A_arbace_classes_native__init_A_const_pool.A[37]; A_arbace_classes_native__init_A_const_17 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[38]); A_arbace_classes_native__init_A_const_18 = A_arbace_classes_native__init_A_const_pool.A[39]; A_arbace_classes_native__init_A_const_19 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[40]); A_arbace_classes_native__init_A_const_20 = A_arbace_classes_native__init_A_const_pool.A[41]; A_arbace_classes_native__init_A_const_21 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[42]); A_arbace_classes_native__init_A_const_22 = A_arbace_classes_native__init_A_const_pool.A[43]; A_arbace_classes_native__init_A_const_23 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[44]); A_arbace_classes_native__init_A_const_24 = A_arbace_classes_native__init_A_const_pool.A[45]; A_arbace_classes_native__init_A_const_25 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[46]) }

func A_arbace_classes_native__init_A_clinit_p2() { A_arbace_classes_native__init_A_const_26 = A_arbace_classes_native__init_A_const_pool.A[47]; A_arbace_classes_native__init_A_const_27 = lang.Var_Cast(A_arbace_classes_native__init_A_const_pool.A[48]); A_arbace_classes_native__init_A_const_28 = A_arbace_classes_native__init_A_const_pool.A[49] }

func A_arbace_classes_native__init_A_New() *A_arbace_classes_native__init_A { A_arbace_classes_native__init_A_Init(); t := &A_arbace_classes_native__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native__init_A) Ctor() {}

func (t *A_arbace_classes_native__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native__init_A_class }

func (t *A_arbace_classes_native__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native__init_A); return ok }

func A_arbace_classes_native__init_A_Cast(x any) *A_arbace_classes_native__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native__init_A_class)) }; return v }
