//line aot_arbace_classes_native.ae:1
package aot_arbace_classes_native

import (
	"arbace/aot_arbace_classes_lower"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New() *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_native_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_classes_native_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_native_A_const_1, A_arbace_classes_native_A_const_2, A_arbace_classes_native_A_const_3, A_arbace_classes_native_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_native_eval1078000008_fn__1078000009_A_New() *A_arbace_classes_native_eval1078000008_fn__1078000009_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000008_fn__1078000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_classes_native_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_classes_native_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_native_A_const_10.GetRawRoot__O(), A_arbace_classes_native_A_const_11) }



































func A_arbace_classes_native_symbols_A_New() *A_arbace_classes_native_symbols_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_symbols_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_native_symbols_A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_native_symbols_A) Invoke_O_O__O(self, form__0 any) any {


	var tmp1 any; var root_22 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_24 lang.IFn
	if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = form__0; if linked_23 == nil { tmp1 = ifn_24.Invoke_O__O(arg_25) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_22, arg_25) }
//line :40:1
	if jrt.J2g_Truth(tmp1) { return lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, form__0)) } else { var tmp2 any; var or__1927000174__auto____2 any; var root_26 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_28 lang.IFn

		if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = form__0; if linked_27 == nil { or__1927000174__auto____2 = ifn_28.Invoke_O__O(arg_29) } else { or__1927000174__auto____2 = linked_27.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_26, arg_29) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_30 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = form__0; if linked_31 == nil { or__1927000174__auto____3 = ifn_32.Invoke_O__O(arg_33) } else { or__1927000174__auto____3 = linked_31.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_30, arg_33) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_34 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = form__0; if linked_35 == nil { tmp2 = ifn_36.Invoke_O__O(arg_37) } else { tmp2 = linked_35.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_34, arg_37) } } }
//line :40:1
		if jrt.J2g_Truth(tmp2) {

			var root_38 any = A_arbace_classes_native_A_const_16.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var arg_42 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_43 any; var root_44 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var arg_48 any = form__0; if linked_45 == nil { arg_43 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { arg_43 = linked_45.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }; if linked_39 == nil { return ifn_40.Invoke_O_O_O__O(arg_41, arg_42, arg_43) } else { return linked_39.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_38, arg_41, arg_42, arg_43) } } else {
//line :40:1
				var tmp3 any; var root_49 any = A_arbace_classes_native_A_const_20.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_51 lang.IFn


				if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = form__0; if linked_50 == nil { tmp3 = ifn_51.Invoke_O__O(arg_52) } else { tmp3 = linked_50.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_49, arg_52) }
//line :40:1
				if jrt.J2g_Truth(tmp3) {


					var root_53 any = A_arbace_classes_native_A_const_16.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var arg_57 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_58 any; var root_59 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var arg_63 any = lang.IFn_Cast(A_arbace_classes_native_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_22.GetRawRoot__O(), form__0); if linked_60 == nil { arg_58 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { arg_58 = linked_60.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; if linked_54 == nil { return ifn_55.Invoke_O_O_O__O(arg_56, arg_57, arg_58) } else { return linked_54.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_53, arg_56, arg_57, arg_58) } } else {
//line :40:1
						if A_arbace_classes_native_A_const_23 != nil { return lang.PersistentHashSet_EMPTY.Ref() } else { return nil
						}
					}
			}
	}
}
func A_arbace_classes_native_form_vars_A_New() *A_arbace_classes_native_form_vars_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_native_form_vars_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_native_form_vars_A) Invoke_O_O_O__O(self, ns__0, forms__1 any) any {






	var root_69 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var root_78 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var arg_82 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); if linked_79 == nil { arg_76 = ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { arg_76 = linked_79.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_78, arg_81, arg_82) }; var arg_77 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_New_O(ns__0); var tmp2 *jrt.Class; var fncls__329 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_fn_class
	if fncls__329 == nil { var fncls__329d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_fn_class = fncls__329d; tmp2 = fncls__329d } else { tmp2 = fncls__329 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_330 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_classes_native_symbols_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = forms__1; if linked_331 == nil { tmp4 = ifn_332.Invoke_O__O(arg_333) } else { tmp4 = linked_331.(*A_arbace_classes_native_symbols_A).Invoke_O_O__O(root_330, arg_333) }; arg_77 = tmp3.Invoke_O__O(tmp4)
//line :53:1
	if linked_74 == nil { arg_72 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { arg_72 = linked_74.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_69, arg_72) } }
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_New_O(p0 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A{}; t.Ctor_O(p0); return t }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A) Invoke_O_O__O(self, s__1078000014__1 any) any { var tmp1 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_New_O_O_O(t.F_ns, s__1078000014__1, self); var tmp2 *jrt.Class; var fncls__328 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_fn_class; if fncls__328 == nil { var fncls__328d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_fn_class = fncls__328d; tmp2 = fncls__328d } else { tmp2 = fncls__328 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :54:1
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A) Ctor_O_O_O(c__ns, c__s__1078000014, c__iter__1078000013 any) { t.F_ns = c__ns; t.F_s__1078000014 = c__s__1078000014; t.F_iter__1078000013 = c__iter__1078000013 }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A) Invoke_O__O(self any) any { { var s__1078000014__1 any; var t_ any = t.F_s__1078000014; t.F_s__1078000014 = nil; s__1078000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_83 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = s__1078000014__1; if linked_84 == nil { temp__1927000414__auto____2 = ifn_85.Invoke_O__O(arg_86) } else { temp__1927000414__auto____2 = linked_84.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_83, arg_86) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_87 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__1078000014__3; if linked_88 == nil { tmp1 = ifn_89.Invoke_O__O(arg_90) } else { tmp1 = linked_88.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_91 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = s__1078000014__3; if linked_92 == nil { c__1927001037__auto____4 = ifn_93.Invoke_O__O(arg_94) } else { c__1927001037__auto____4 = linked_92.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_91, arg_94) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000016__6 any; var root_95 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_96 == nil { b__1078000016__6 = ifn_97.Invoke_O__O(arg_98) } else { b__1078000016__6 = linked_96.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_95, arg_98) }; var tmp2 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_New_O_O_I_O(b__1078000016__6, t.F_ns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_fn_class = fncls__196d; tmp3 = fncls__196d } else { tmp3 = fncls__196 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_197 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any; var root_202 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = b__1078000016__6; if linked_203 == nil { arg_200 = ifn_204.Invoke_O__O(arg_205) } else { arg_200 = linked_203.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_202, arg_205) }; var arg_201 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000013); var tmp5 any; var root_206 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = s__1078000014__3; if linked_207 == nil { tmp5 = ifn_208.Invoke_O__O(arg_209) } else { tmp5 = linked_207.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_206, arg_209) }; arg_201 = tmp4.Invoke_O__O(tmp5); if linked_198 == nil { return ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { return linked_198.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) } } else { var root_210 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any; var root_215 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = b__1078000016__6; if linked_216 == nil { arg_213 = ifn_217.Invoke_O__O(arg_218) } else { arg_213 = linked_216.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_215, arg_218) }; var arg_214 any; if linked_211 == nil { return ifn_212.Invoke_O_O__O(arg_213, arg_214) } else { return linked_211.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_210, arg_213, arg_214) } } } else { var s__4 any; var root_219 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = s__1078000014__3; if linked_220 == nil { s__4 = ifn_221.Invoke_O__O(arg_222) } else { s__4 = linked_220.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_219, arg_222) }; var v__5 any; var tmp6 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_New_O_O(t.F_ns, s__4); var tmp7 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_fn_class
															if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_fn_class = fncls__228d; tmp7 = fncls__228d } else { tmp7 = fncls__228 }; v__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :54:1
	var tmp8 any; var and__1927000168__auto____6 any; var root_229 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_231 lang.IFn


	if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = v__5; if linked_230 == nil { and__1927000168__auto____6 = ifn_231.Invoke_O__O(arg_232) } else { and__1927000168__auto____6 = linked_230.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_229, arg_232) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_233 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var and__1927000168__auto____7 bool; var tmp9 any; var root_237 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any; var root_241 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = lang.Var_Cast(v__5).F_ns.Ref(); if linked_242 == nil { arg_240 = ifn_243.Invoke_O__O(arg_244) } else { arg_240 = linked_242.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_241, arg_244) }; if linked_238 == nil { tmp9 = ifn_239.Invoke_O__O(arg_240) } else { tmp9 = linked_238.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_237, arg_240) }; and__1927000168__auto____7 = lang.Util_Equiv_O_O__Z_NoInit(Lit_34, tmp9); if and__1927000168__auto____7 {
			var root_245 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = A_arbace_classes_native_A_const_53; var arg_249 any; var root_250 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = s__4; if linked_251 == nil { arg_249 = ifn_252.Invoke_O__O(arg_253) } else { arg_249 = linked_251.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_250, arg_253) }; if linked_246 == nil { arg_236 = ifn_247.Invoke_O_O__O(arg_248, arg_249) } else { arg_236 = linked_246.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_245, arg_248, arg_249) } } else {
//line :58:1
				arg_236 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if linked_234 == nil { tmp8 = ifn_235.Invoke_O__O(arg_236) } else { tmp8 = linked_234.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_233, arg_236) } } else {
//line :57:1
					tmp8 = and__1927000168__auto____6 }
//line :54:1
	if jrt.J2g_Truth(tmp8) { var m__6 any = lang.RT_Meta_O__IPersistentMap_NoInit(v__5); var tag__7 any = A_arbace_classes_native_A_const_40.Invoke_O__O(m__6); var root_254 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var tmp10 any; var root_259 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_261 lang.IFn







		if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__4; var arg_263 any; if linked_260 == nil { tmp10 = ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { tmp10 = linked_260.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) }
//line :54:1
		var tmp11 any = tmp10; var tmp12 any; var root_264 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_266 lang.IFn







		if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_268 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = lang.Var_Cast(v__5).F_ns.Ref(); if linked_269 == nil { arg_267 = ifn_270.Invoke_O__O(arg_271) } else { arg_267 = linked_269.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_268, arg_271) }; if linked_265 == nil { tmp12 = ifn_266.Invoke_O__O(arg_267) } else { tmp12 = linked_265.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_264, arg_267) }
//line :54:1
		var tmp13 any = tmp12; var tmp14 any; var root_272 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_274 lang.IFn







		if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = lang.Var_Cast(v__5).F_sym.Ref(); if linked_273 == nil { tmp14 = ifn_274.Invoke_O__O(arg_275) } else { tmp14 = linked_273.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_272, arg_275) }
//line :54:1
		var tmp15 any = tmp14; var tmp16 any; var G__1078000026__8_ any; var root_276 any = A_arbace_classes_native_A_const_43.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_278 lang.IFn








		if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = m__6; var arg_280 any = A_arbace_classes_native_A_const_55; if linked_277 == nil { G__1078000026__8_ = ifn_278.Invoke_O_O__O(arg_279, arg_280) } else { G__1078000026__8_ = linked_277.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_276, arg_279, arg_280) }
//line :54:1
		var G__1078000026__9_ any; var tmp17 any; var or__1927000174__auto____9 any; var root_281 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_283 lang.IFn









		if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = tag__7; if linked_282 == nil { or__1927000174__auto____9 = ifn_283.Invoke_O__O(arg_284) } else { or__1927000174__auto____9 = linked_282.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_281, arg_284) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp17 = or__1927000174__auto____9 } else { var root_285 any = A_arbace_classes_native_A_const_45.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = tag__7; if linked_286 == nil { tmp17 = ifn_287.Invoke_O__O(arg_288) } else { tmp17 = linked_286.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_285, arg_288) } }
//line :63:1
		if jrt.J2g_Truth(tmp17) {
			var root_289 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = G__1078000026__8_; var arg_293 any = A_arbace_classes_native_A_const_40; var arg_294 any = tag__7; if linked_290 == nil { G__1078000026__9_ = ifn_291.Invoke_O_O_O__O(arg_292, arg_293, arg_294) } else { G__1078000026__9_ = linked_290.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_289, arg_292, arg_293, arg_294) } } else {
//line :63:1
				G__1078000026__9_ = G__1078000026__8_ }
//line :54:1
		var G__1078000026__10_ any








		if jrt.Class_InstanceOf(tag__7) {

			var root_295 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = G__1078000026__9_; var arg_299 any = A_arbace_classes_native_A_const_40; var arg_300 any; var root_301 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = jrt.NN(jrt.Class_Cast(tag__7)).GetName__String().Ref(); if linked_302 == nil { arg_300 = ifn_303.Invoke_O__O(arg_304) } else { arg_300 = linked_302.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_301, arg_304) }; if linked_296 == nil { G__1078000026__10_ = ifn_297.Invoke_O_O_O__O(arg_298, arg_299, arg_300) } else { G__1078000026__10_ = linked_296.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_295, arg_298, arg_299, arg_300) } } else {
//line :63:1
				G__1078000026__10_ = G__1078000026__9_ }; var tmp18 any; var and__1927000168__auto____11 any; var root_305 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_307 lang.IFn


		if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__6); if linked_306 == nil { and__1927000168__auto____11 = ifn_307.Invoke_O__O(arg_308) } else { and__1927000168__auto____11 = linked_306.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_305, arg_308) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_309 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var arg_313 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__6); if linked_310 == nil { tmp18 = ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { tmp18 = linked_310.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_309, arg_312, arg_313) } } else { tmp18 = and__1927000168__auto____11 }
//line :63:1
		if jrt.J2g_Truth(tmp18) {


			var root_314 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = G__1078000026__10_; var arg_318 any = A_arbace_classes_native_A_const_48; var arg_319 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__6); if linked_315 == nil { tmp16 = ifn_316.Invoke_O_O_O__O(arg_317, arg_318, arg_319) } else { tmp16 = linked_315.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_314, arg_317, arg_318, arg_319) } } else {
//line :63:1
				tmp16 = G__1078000026__10_ }
//line :54:1
		arg_257 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp11, tmp13, tmp15, tmp16); var arg_258 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__1078000013); var tmp20 any; var root_320 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = s__1078000014__3; if linked_321 == nil { tmp20 = ifn_322.Invoke_O__O(arg_323) } else { tmp20 = linked_321.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_320, arg_323) }; arg_258 = tmp19.Invoke_O__O(tmp20); if linked_255 == nil { return ifn_256.Invoke_O_O__O(arg_257, arg_258) } else { return linked_255.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_254, arg_257, arg_258) } } else { var tmp21 any; var root_324 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = s__1078000014__3; if linked_325 == nil { tmp21 = ifn_326.Invoke_O__O(arg_327) } else { tmp21 = linked_325.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_324, arg_327) }; s__1078000014__1 = tmp21; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :54:1
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A) Ctor_O_O_I_O(c__b__1078000016, c__ns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000016 = c__b__1078000016; t.F_ns = c__ns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A) Invoke_O__O(self any) any { { var i__1078000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000015__1)); var v__3 any; var tmp2 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_New_O_O(t.F_ns, s__2); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_fn_class
																	if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; v__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :54:1
	var tmp4 any; var and__1927000168__auto____4 any; var root_105 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_107 lang.IFn


	if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = v__3; if linked_106 == nil { and__1927000168__auto____4 = ifn_107.Invoke_O__O(arg_108) } else { and__1927000168__auto____4 = linked_106.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_109 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var and__1927000168__auto____5 bool; var tmp5 any; var root_113 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any; var root_117 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = lang.Var_Cast(v__3).F_ns.Ref(); if linked_118 == nil { arg_116 = ifn_119.Invoke_O__O(arg_120) } else { arg_116 = linked_118.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_117, arg_120) }; if linked_114 == nil { tmp5 = ifn_115.Invoke_O__O(arg_116) } else { tmp5 = linked_114.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_113, arg_116) }; and__1927000168__auto____5 = lang.Util_Equiv_O_O__Z_NoInit(Lit_34, tmp5); if and__1927000168__auto____5 {
			var root_121 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = A_arbace_classes_native_A_const_38; var arg_125 any; var root_126 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = s__2; if linked_127 == nil { arg_125 = ifn_128.Invoke_O__O(arg_129) } else { arg_125 = linked_127.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_126, arg_129) }; if linked_122 == nil { arg_112 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { arg_112 = linked_122.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } } else {
//line :58:1
				arg_112 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if linked_110 == nil { tmp4 = ifn_111.Invoke_O__O(arg_112) } else { tmp4 = linked_110.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_109, arg_112) } } else {
//line :57:1
					tmp4 = and__1927000168__auto____4 }
//line :54:1
	if jrt.J2g_Truth(tmp4) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(v__3); var tag__5 any = A_arbace_classes_native_A_const_40.Invoke_O__O(m__4); var root_130 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = t.F_b__1078000016; var arg_134 any; var tmp6 any; var root_135 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_137 lang.IFn







		if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = s__2; var arg_139 any; if linked_136 == nil { tmp6 = ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { tmp6 = linked_136.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) }
//line :54:1
		var tmp7 any = tmp6; var tmp8 any; var root_140 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_142 lang.IFn







		if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_144 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = lang.Var_Cast(v__3).F_ns.Ref(); if linked_145 == nil { arg_143 = ifn_146.Invoke_O__O(arg_147) } else { arg_143 = linked_145.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_144, arg_147) }; if linked_141 == nil { tmp8 = ifn_142.Invoke_O__O(arg_143) } else { tmp8 = linked_141.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_140, arg_143) }
//line :54:1
		var tmp9 any = tmp8; var tmp10 any; var root_148 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_150 lang.IFn







		if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = lang.Var_Cast(v__3).F_sym.Ref(); if linked_149 == nil { tmp10 = ifn_150.Invoke_O__O(arg_151) } else { tmp10 = linked_149.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_148, arg_151) }
//line :54:1
		var tmp11 any = tmp10; var tmp12 any; var G__1078000022__6_ any; var root_152 any = A_arbace_classes_native_A_const_43.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_154 lang.IFn








		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = m__4; var arg_156 any = A_arbace_classes_native_A_const_44; if linked_153 == nil { G__1078000022__6_ = ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { G__1078000022__6_ = linked_153.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) }
//line :54:1
		var G__1078000022__7_ any; var tmp13 any; var or__1927000174__auto____7 any; var root_157 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_159 lang.IFn









		if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = tag__5; if linked_158 == nil { or__1927000174__auto____7 = ifn_159.Invoke_O__O(arg_160) } else { or__1927000174__auto____7 = linked_158.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_157, arg_160) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp13 = or__1927000174__auto____7 } else { var root_161 any = A_arbace_classes_native_A_const_45.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = tag__5; if linked_162 == nil { tmp13 = ifn_163.Invoke_O__O(arg_164) } else { tmp13 = linked_162.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_161, arg_164) } }
//line :63:1
		if jrt.J2g_Truth(tmp13) {
			var root_165 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = G__1078000022__6_; var arg_169 any = A_arbace_classes_native_A_const_40; var arg_170 any = tag__5; if linked_166 == nil { G__1078000022__7_ = ifn_167.Invoke_O_O_O__O(arg_168, arg_169, arg_170) } else { G__1078000022__7_ = linked_166.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_165, arg_168, arg_169, arg_170) } } else {
//line :63:1
				G__1078000022__7_ = G__1078000022__6_ }
//line :54:1
		var G__1078000022__8_ any








		if jrt.Class_InstanceOf(tag__5) {

			var root_171 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = G__1078000022__7_; var arg_175 any = A_arbace_classes_native_A_const_40; var arg_176 any; var root_177 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = jrt.NN(jrt.Class_Cast(tag__5)).GetName__String().Ref(); if linked_178 == nil { arg_176 = ifn_179.Invoke_O__O(arg_180) } else { arg_176 = linked_178.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_177, arg_180) }; if linked_172 == nil { G__1078000022__8_ = ifn_173.Invoke_O_O_O__O(arg_174, arg_175, arg_176) } else { G__1078000022__8_ = linked_172.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_171, arg_174, arg_175, arg_176) } } else {
//line :63:1
				G__1078000022__8_ = G__1078000022__7_ }; var tmp14 any; var and__1927000168__auto____9 any; var root_181 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_183 lang.IFn


		if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__4); if linked_182 == nil { and__1927000168__auto____9 = ifn_183.Invoke_O__O(arg_184) } else { and__1927000168__auto____9 = linked_182.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_181, arg_184) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_185 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var arg_189 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__4); if linked_186 == nil { tmp14 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { tmp14 = linked_186.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_185, arg_188, arg_189) } } else { tmp14 = and__1927000168__auto____9 }
//line :63:1
		if jrt.J2g_Truth(tmp14) {


			var root_190 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = G__1078000022__8_; var arg_194 any = A_arbace_classes_native_A_const_48; var arg_195 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__4); if linked_191 == nil { tmp12 = ifn_192.Invoke_O_O_O__O(arg_193, arg_194, arg_195) } else { tmp12 = linked_191.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_190, arg_193, arg_194, arg_195) } } else {
//line :63:1
				tmp12 = G__1078000022__8_ }
//line :54:1
		arg_134 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp7, tmp9, tmp11, tmp12); if linked_131 == nil { ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { linked_131.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }; i__1078000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000015__1); continue L1 } else { i__1078000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000015__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_New_O_O(p0, p1 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A) Ctor_O_O(c__ns, c__s any) { t.F_ns = c__ns; t.F_s = c__s }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_99 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_ns_resolve_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var t_ any = t.F_ns; t.F_ns = nil; arg_102 = t_; var arg_103 any; var t__2 any = t.F_s; t.F_s = nil; arg_103 = t__2; if linked_100 == nil { tmp1 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { tmp1 = linked_100.(*aot_arbace_core.A_arbace_core_ns_resolve_A).Invoke_O_O_O__O(root_99, arg_102, arg_103) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :55:1
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_New_O_O(p0, p1 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A) Ctor_O_O(c__ns, c__s any) { t.F_ns = c__ns; t.F_s = c__s }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_223 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_ns_resolve_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any; var t_ any = t.F_ns; t.F_ns = nil; arg_226 = t_; var arg_227 any; var t__2 any = t.F_s; t.F_s = nil; arg_227 = t__2; if linked_224 == nil { tmp1 = ifn_225.Invoke_O_O__O(arg_226, arg_227) } else { tmp1 = linked_224.(*aot_arbace_core.A_arbace_core_ns_resolve_A).Invoke_O_O_O__O(root_223, arg_226, arg_227) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }












func A_arbace_classes_native_compile_and_load_BANG__A_New() *A_arbace_classes_native_compile_and_load_BANG__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) Ctor() {}
//line :68:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) DoInvoke_O_O_O_O__O(self, ns__0, forms__1, p__1078000030__2 any) any { var map__1078000031__4 any = p__1078000030__2; var map__1078000031__5 any; if lang.ISeq_InstanceOf(map__1078000031__4) { var tmp1 any; var root_334 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = map__1078000031__4; if linked_335 == nil { tmp1 = ifn_336.Invoke_O__O(arg_337) } else { tmp1 = linked_335.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_338 any = A_arbace_classes_native_A_const_58.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = map__1078000031__4; if linked_339 == nil { tmp2 = ifn_340.Invoke_O__O(arg_341) } else { tmp2 = linked_339.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_338, arg_341) }; map__1078000031__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_342 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = map__1078000031__4; if linked_343 == nil { tmp3 = ifn_344.Invoke_O__O(arg_345) } else { tmp3 = linked_343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_342, arg_345) }; if jrt.J2g_Truth(tmp3) { var root_346 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = map__1078000031__4; if linked_347 == nil { map__1078000031__5 = ifn_348.Invoke_O__O(arg_349) } else { map__1078000031__5 = linked_347.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_346, arg_349) } } else { map__1078000031__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000031__5 = map__1078000031__4 }; var siblings__6 any = lang.RT_Get_O_O__O_NoInit(map__1078000031__5, A_arbace_classes_native_A_const_59); var loaded__7 any = lang.IFn_Cast(A_arbace_classes_native_A_const_60.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__1, A_arbace_classes_native_A_const_59, siblings__6); if



	jrt.J2g_Truth(A_arbace_classes_native_A_const_61.GetRawRoot__O()) {
		var root_357 any = A_arbace_classes_native_A_const_62.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = A_arbace_classes_native_A_const_61.GetRawRoot__O(); var arg_361 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var arg_362 any; var tmp4 any = A_arbace_classes_native_A_const_63; var tmp5 any; var root_363 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_365 lang.IFn
		if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = ns__0; if linked_364 == nil { tmp5 = ifn_365.Invoke_O__O(arg_366) } else { tmp5 = linked_364.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_363, arg_366) }
//line :73:1
		var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_native_A_const_64; var tmp8 any; var root_367 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_369 lang.IFn

		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = lang.IFn_Cast(A_arbace_classes_native_A_const_65.GetRawRoot__O()).Invoke__O(); var arg_371 any; var iter__1927001039__auto____8 any; var tmp9 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_New(); var tmp10 *jrt.Class; var fncls__445 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_fn_class
		if fncls__445 == nil { var fncls__445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_fn_class = fncls__445d; tmp10 = fncls__445d } else { tmp10 = fncls__445 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp12 any; var root_446 any = A_arbace_classes_native_A_const_66.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_ns_imports_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = ns__0; if linked_447 == nil { tmp12 = ifn_448.Invoke_O__O(arg_449) } else { tmp12 = linked_447.(*aot_arbace_core.A_arbace_core_ns_imports_A).Invoke_O_O__O(root_446, arg_449) }; arg_371 = tmp11.Invoke_O__O(tmp12)
//line :75:1
		if linked_368 == nil { tmp8 = ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { tmp8 = linked_368.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) }
//line :73:1
		var tmp13 any = tmp8; var tmp14 any = A_arbace_classes_native_A_const_67; var tmp15 any; var root_450 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_452 lang.IFn





		if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = forms__1; if linked_451 == nil { tmp15 = ifn_452.Invoke_O__O(arg_453) } else { tmp15 = linked_451.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_450, arg_453) }
//line :73:1
		var tmp16 any = tmp15; var tmp17 any = A_arbace_classes_native_A_const_68; var tmp18 any; var root_454 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_456 lang.IFn






		if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var arg_458 any = loaded__7; if linked_455 == nil { tmp18 = ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { tmp18 = linked_455.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_454, arg_457, arg_458) }
//line :73:1
		var tmp19 any = tmp18; var tmp20 any = A_arbace_classes_native_A_const_70; var tmp21 any; var root_459 any = A_arbace_classes_native_A_const_71.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, A_arbace_classes_native_form_vars_A_fn_class); var ifn_461 lang.IFn







		if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = ns__0; var arg_463 any = forms__1; if linked_460 == nil { tmp21 = ifn_461.Invoke_O_O__O(arg_462, arg_463) } else { tmp21 = linked_460.(*A_arbace_classes_native_form_vars_A).Invoke_O_O_O__O(root_459, arg_462, arg_463) }
//line :73:1
		arg_362 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp13, tmp14, tmp16, tmp17, tmp19, tmp20, tmp21)); if linked_358 == nil { ifn_359.Invoke_O_O_O__O(arg_360, arg_361, arg_362) } else { linked_358.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_357, arg_360, arg_361, arg_362) } }; return loaded__7 }


func A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_New() *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A) Ctor() {}
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A) Invoke_O_O__O(self, s__1078000034__1 any) any { var tmp1 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_New_O_O(s__1078000034__1, self); var tmp2 *jrt.Class; var fncls__444 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_fn_class; if fncls__444 == nil { var fncls__444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_fn_class = fncls__444d; tmp2 = fncls__444d } else { tmp2 = fncls__444 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A{}; t.Ctor_O_O(p0, p1); return t }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A) Ctor_O_O(c__s__1078000034, c__iter__1078000033 any) { t.F_s__1078000034 = c__s__1078000034; t.F_iter__1078000033 = c__iter__1078000033 }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A) Invoke_O__O(self any) any { { var s__1078000034__1 any; var t_ any = t.F_s__1078000034; t.F_s__1078000034 = nil; s__1078000034__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_375 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = s__1078000034__1; if linked_376 == nil { temp__1927000414__auto____2 = ifn_377.Invoke_O__O(arg_378) } else { temp__1927000414__auto____2 = linked_376.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_375, arg_378) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000034__3 any = temp__1927000414__auto____2; var tmp1 any; var root_379 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = s__1078000034__3; if linked_380 == nil { tmp1 = ifn_381.Invoke_O__O(arg_382) } else { tmp1 = linked_380.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_379, arg_382) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_383 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = s__1078000034__3; if linked_384 == nil { c__1927001037__auto____4 = ifn_385.Invoke_O__O(arg_386) } else { c__1927001037__auto____4 = linked_384.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_383, arg_386) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000036__6 any; var root_387 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_388 == nil { b__1078000036__6 = ifn_389.Invoke_O__O(arg_390) } else { b__1078000036__6 = linked_388.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_387, arg_390) }; var tmp2 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1078000036__6); var tmp3 *jrt.Class; var fncls__400 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_fn_class; if fncls__400 == nil { var fncls__400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_fn_class = fncls__400d; tmp3 = fncls__400d } else { tmp3 = fncls__400 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_401 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any; var root_406 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = b__1078000036__6; if linked_407 == nil { arg_404 = ifn_408.Invoke_O__O(arg_409) } else { arg_404 = linked_407.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_406, arg_409) }; var arg_405 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000033); var tmp5 any; var root_410 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = s__1078000034__3; if linked_411 == nil { tmp5 = ifn_412.Invoke_O__O(arg_413) } else { tmp5 = linked_411.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_410, arg_413) }; arg_405 = tmp4.Invoke_O__O(tmp5); if linked_402 == nil { return ifn_403.Invoke_O_O__O(arg_404, arg_405) } else { return linked_402.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_401, arg_404, arg_405) } } else { var root_414 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any; var root_419 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = b__1078000036__6; if linked_420 == nil { arg_417 = ifn_421.Invoke_O__O(arg_422) } else { arg_417 = linked_420.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_419, arg_422) }; var arg_418 any; if linked_415 == nil { return ifn_416.Invoke_O_O__O(arg_417, arg_418) } else { return linked_415.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_414, arg_417, arg_418) } } } else { var vec__1078000044__4 any; var root_423 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = s__1078000034__3; if linked_424 == nil { vec__1078000044__4 = ifn_425.Invoke_O__O(arg_426) } else { vec__1078000044__4 = linked_424.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_423, arg_426) }; var sym__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000044__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000044__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_427 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_429 lang.IFn
																	if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__6, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__5))).Ref(); if linked_428 == nil { tmp6 = ifn_429.Invoke_O__O(arg_430) } else { tmp6 = linked_428.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_427, arg_430) }
//line :76:1
	if jrt.J2g_Truth(tmp6) { var root_431 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = lang.Tuple_Create_O_O__IPersistentVector(sym__5, jrt.NN(jrt.Class_Cast(c__6)).GetName__String().Ref()); var arg_435 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000033); var tmp8 any; var root_436 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = s__1078000034__3; if linked_437 == nil { tmp8 = ifn_438.Invoke_O__O(arg_439) } else { tmp8 = linked_437.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_436, arg_439) }; arg_435 = tmp7.Invoke_O__O(tmp8); if linked_432 == nil { return ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { return linked_432.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_431, arg_434, arg_435) } } else { var tmp9 any; var root_440 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = s__1078000034__3; if linked_441 == nil { tmp9 = ifn_442.Invoke_O__O(arg_443) } else { tmp9 = linked_441.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_440, arg_443) }; s__1078000034__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1078000036 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1078000036 = c__b__1078000036 }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A) Invoke_O__O(self any) any { { var i__1078000035__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000035__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000040__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000035__1)); var sym__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000040__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000040__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_391 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_393 lang.IFn
																		if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__4, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__3))).Ref(); if linked_392 == nil { tmp2 = ifn_393.Invoke_O__O(arg_394) } else { tmp2 = linked_392.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_391, arg_394) }
//line :76:1
	if jrt.J2g_Truth(tmp2) { var root_395 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = t.F_b__1078000036; var arg_399 any = lang.Tuple_Create_O_O__IPersistentVector(sym__3, jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref()); if linked_396 == nil { ifn_397.Invoke_O_O__O(arg_398, arg_399) } else { linked_396.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_395, arg_398, arg_399) }; i__1078000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000035__1); continue L1 } else { i__1078000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000035__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_classes_native_compile_top_A_New() *A_arbace_classes_native_compile_top_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_classes_native_compile_top_A) Ctor() {}
//line :84:1
func (t *A_arbace_classes_native_compile_top_A) Invoke_O_O_O_O_O__O(self, ns__0, kind__1, forms__2, siblings__3 any) any { var forms__5 any; if






	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_72, kind__1) { forms__5 = lang.Tuple_Create_O__IPersistentVector(forms__2) } else { var root_464 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = forms__2; if linked_465 == nil { forms__5 = ifn_466.Invoke_O__O(arg_467) } else { forms__5 = linked_465.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_464, arg_467) } }; var loaded__6 any = /*line :84:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__5, A_arbace_classes_native_A_const_59, siblings__3); var root_475 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_477 lang.IFn; if






	linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_74.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_76); var tmp3 any; var iter__1927001039__auto____7 any; var tmp4 any = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_New(); var tmp5 *jrt.Class; var fncls__543 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_fn_class; if


	fncls__543 == nil { var fncls__543d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_fn_class = fncls__543d; tmp5 = fncls__543d } else { tmp5 = fncls__543 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(loaded__6); var tmp6 any = tmp3; var tmp7 lang.IFn = /*line :91:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp8 any; if



	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_72, kind__1) { var root_544 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any; var root_548 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = loaded__6; if linked_549 == nil { arg_547 = ifn_550.Invoke_O__O(arg_551) } else { arg_547 = linked_549.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_548, arg_551) }; if linked_545 == nil { tmp8 = ifn_546.Invoke_O__O(arg_547) } else { tmp8 = linked_545.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_544, arg_547) } } else { var root_552 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var arg_556 any = loaded__6; if linked_553 == nil { tmp8 = ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { tmp8 = linked_553.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) } }; arg_478 = /*line :91:1*/tmp1.Invoke_O_O_O__O(tmp2, tmp6, tmp7.Invoke_O__O(tmp8)); if linked_476 == nil { return ifn_477.Invoke_O__O(arg_478) } else { return linked_476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_475, arg_478) } }


func A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_New() *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A) Ctor() {}
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A) Invoke_O_O__O(self, s__1078000051__1 any) any { var tmp1 any = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_New_O_O(s__1078000051__1, self); var tmp2 *jrt.Class; var fncls__542 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_fn_class; if fncls__542 == nil { var fncls__542d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_fn_class = fncls__542d; tmp2 = fncls__542d } else { tmp2 = fncls__542 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :94:1
func A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A) Ctor_O_O(c__s__1078000051, c__iter__1078000050 any) { t.F_s__1078000051 = c__s__1078000051; t.F_iter__1078000050 = c__iter__1078000050 }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A) Invoke_O__O(self any) any { { var s__1078000051__1 any; var t_ any = t.F_s__1078000051; t.F_s__1078000051 = nil; s__1078000051__1 = t_; for { var temp__1927000414__auto____2 any; var root_485 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__1078000051__1; if linked_486 == nil { temp__1927000414__auto____2 = ifn_487.Invoke_O__O(arg_488) } else { temp__1927000414__auto____2 = linked_486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_485, arg_488) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000051__3 any = temp__1927000414__auto____2; var tmp1 any; var root_489 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = s__1078000051__3; if linked_490 == nil { tmp1 = ifn_491.Invoke_O__O(arg_492) } else { tmp1 = linked_490.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_489, arg_492) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_493 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = s__1078000051__3; if linked_494 == nil { c__1927001037__auto____4 = ifn_495.Invoke_O__O(arg_496) } else { c__1927001037__auto____4 = linked_494.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_493, arg_496) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000053__6 any; var root_497 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_498 == nil { b__1078000053__6 = ifn_499.Invoke_O__O(arg_500) } else { b__1078000053__6 = linked_498.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_497, arg_500) }; var tmp2 any = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_New_O_I_O(b__1078000053__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__506 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_fn_class; if fncls__506 == nil { var fncls__506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_fn_class = fncls__506d; tmp3 = fncls__506d } else { tmp3 = fncls__506 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_507 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any; var root_512 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = b__1078000053__6; if linked_513 == nil { arg_510 = ifn_514.Invoke_O__O(arg_515) } else { arg_510 = linked_513.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_512, arg_515) }; var arg_511 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000050); var tmp5 any; var root_516 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = s__1078000051__3; if linked_517 == nil { tmp5 = ifn_518.Invoke_O__O(arg_519) } else { tmp5 = linked_517.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_516, arg_519) }; arg_511 = tmp4.Invoke_O__O(tmp5); if linked_508 == nil { return ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { return linked_508.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) } } else { var root_520 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var root_525 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = b__1078000053__6; if linked_526 == nil { arg_523 = ifn_527.Invoke_O__O(arg_528) } else { arg_523 = linked_526.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_525, arg_528) }; var arg_524 any; if linked_521 == nil { return ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { return linked_521.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) } } } else { var vec__1078000061__4 any; var root_529 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = s__1078000051__3; if linked_530 == nil { vec__1078000061__4 = ifn_531.Invoke_O__O(arg_532) } else { vec__1078000061__4 = linked_530.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_529, arg_532) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_533 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_77, n__5); var arg_537 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1078000050); var tmp7 any; var root_538 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = s__1078000051__3; if linked_539 == nil { tmp7 = ifn_540.Invoke_O__O(arg_541) } else { tmp7 = linked_539.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_538, arg_541) }; arg_537 = tmp6.Invoke_O__O(tmp7); if linked_534 == nil { return ifn_535.Invoke_O_O__O(arg_536, arg_537) } else { return linked_534.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_533, arg_536, arg_537) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :94:1
func A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A) Ctor_O_I_O(c__b__1078000053 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000053 = c__b__1078000053; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A) Invoke_O__O(self any) any { { var i__1078000052__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000052__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000057__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000052__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_501 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = t.F_b__1078000053; var arg_505 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_77, n__3); if linked_502 == nil { ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { linked_502.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) }; i__1078000052__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000052__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_native_compile_deftype_A_New() *A_arbace_classes_native_compile_deftype_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_classes_native_compile_deftype_A) Ctor() {}
//line :100:1
func (t *A_arbace_classes_native_compile_deftype_A) Invoke_O_O_O__O(self, ns__0, form__1 any) any {




	var root_570 any = A_arbace_classes_native_A_const_81.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = lang.IFn_Cast(A_arbace_classes_native_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_83, ns__0); if linked_571 == nil { ifn_572.Invoke_O__O(arg_573) } else { linked_571.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_570, arg_573) }; var tmp1 any = A_arbace_classes_native_compile_deftype_fn__1078000067_A_New_O_O(form__1, ns__0); var tmp2 *jrt.Class; var fncls__569 *jrt.Class = A_arbace_classes_native_compile_deftype_fn__1078000067_A_fn_class; if fncls__569 == nil { var fncls__569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_classes_native_compile_deftype_fn__1078000067_A_fn_class = fncls__569d; tmp2 = fncls__569d } else { tmp2 = fncls__569 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :100:1
	return nil
}



func A_arbace_classes_native_compile_deftype_fn__1078000067_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_deftype_fn__1078000067_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_fn__1078000067_A{}; t.Ctor_O_O(p0, p1); return t }
//line :105:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000067_A) Ctor_O_O(c__form, c__ns any) { t.F_form = c__form; t.F_ns = c__ns }
//line :105:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000067_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_562 any = A_arbace_classes_native_A_const_79.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any; var t__2 any = t.F_form; t.F_form = nil; arg_565 = t__2; if linked_563 == nil { tmp5 = ifn_564.Invoke_O__O(arg_565) } else { tmp5 = linked_563.(*aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A).Invoke_O_O__O(root_562, arg_565) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :105:1
	return nil }(); var root_566 any = A_arbace_classes_native_A_const_80.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; if linked_567 == nil { ifn_568.Invoke__O() } else { linked_567.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_566) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }






func A_arbace_classes_native_public_class_QMARK__A_New() *A_arbace_classes_native_public_class_QMARK__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_public_class_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Invoke_O_O__O(self, c__0 any) any { { var c__2 any = c__0; L1: for {

	if lang.Util_Identical_O_O__Z_NoInit(c__2, nil) { return jrt.Boolean_TRUE.Ref() } else { var tmp1 any; var root_579 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_581 lang.IFn
		if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__2)).GetModifiers__I())).Ref(); if linked_580 == nil { tmp1 = ifn_581.Invoke_O__O(arg_582) } else { tmp1 = linked_580.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_579, arg_582) }
//line :114:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_native_A_const_23 != nil {

			c__2 = jrt.NN(jrt.Class_Cast(c__2)).GetDeclaringClass__Class().Ref(); continue L1 } else {
//line :114:1
				return nil } } } } }; /*line :112:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_type_form_A_New() *A_arbace_classes_native_type_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_type_form_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_native_type_form_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_native_type_form_A) Invoke_O_O__O(self, c__0 any) any {


	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var c__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(c__2)).IsArray__Z() { c__2, n__3 = jrt.NN(jrt.Class_Cast(c__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J_NoInit(n__3); continue L1 } else { var root_583 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); var arg_587 any; var root_588 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); if linked_589 == nil { arg_587 = ifn_590.Invoke_O__O(arg_591) } else { arg_587 = linked_589.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_588, arg_591) }; if linked_584 == nil { return ifn_585.Invoke_O_O__O(arg_586, arg_587) } else { return linked_584.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_583, arg_586, arg_587) } } } } else {
			var root_592 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); if linked_593 == nil { return ifn_594.Invoke_O__O(arg_595) } else { return linked_593.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_592, arg_595) } }
//line :118:1
	panic("j2g: unreachable")
}






func A_arbace_classes_native_local_class_A_New() *A_arbace_classes_native_local_class_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_classes_native_local_class_A) Ctor() {}
//line :126:1
func (t *A_arbace_classes_native_local_class_A) Invoke_O_O__O(self, lb__0 any) any { var prim__2 any; var tmp1 any = A_arbace_classes_native_local_class_fn__1078000072_A_New_O(lb__0); var tmp2 *jrt.Class; var fncls__596 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000072_A_fn_class; if



	fncls__596 == nil { var fncls__596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_classes_native_local_class_fn__1078000072_A_fn_class = fncls__596d; tmp2 = fncls__596d } else { tmp2 = fncls__596 }; prim__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var or__1927000174__auto____3 any = prim__2; if
	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var c__4 any; var tmp3 any = A_arbace_classes_native_local_class_fn__1078000074_A_New_O(lb__0); var tmp4 *jrt.Class; var fncls__597 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000074_A_fn_class
		if fncls__597 == nil { var fncls__597d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_classes_native_local_class_fn__1078000074_A_fn_class = fncls__597d; tmp4 = fncls__597d } else { tmp4 = fncls__597 }; c__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


		var tmp5 any; var and__1927000168__auto____5 bool = jrt.Class_InstanceOf(c__4); if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_598 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__4)).IsPrimitive__Z()).Ref(); if linked_599 == nil { and__1927000168__auto____6 = ifn_600.Invoke_O__O(arg_601) } else { and__1927000168__auto____6 = linked_599.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_602 any = A_arbace_classes_native_A_const_84.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, A_arbace_classes_native_public_class_QMARK__A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = c__4; if linked_603 == nil { and__1927000168__auto____7 = ifn_604.Invoke_O__O(arg_605) } else { and__1927000168__auto____7 = linked_603.(*A_arbace_classes_native_public_class_QMARK__A).Invoke_O_O__O(root_602, arg_605) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
			var root_606 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_610 any = A_arbace_classes_native_A_const_85.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref(); var arg_614 any = Lit_38; if linked_611 == nil { arg_609 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { arg_609 = linked_611.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }; if linked_607 == nil { tmp5 = ifn_608.Invoke_O__O(arg_609) } else { tmp5 = linked_607.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_606, arg_609) } } else {
//line :135:1
				tmp5 = and__1927000168__auto____7 } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp5) { return c__4 } else { return A_arbace_classes_native_A_const_86 } } }
//line :130:1
func A_arbace_classes_native_local_class_fn__1078000072_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000072_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000072_A{}; t.Ctor_O(p0); return t }
//line :130:1
func (t *A_arbace_classes_native_local_class_fn__1078000072_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :130:1
func (t *A_arbace_classes_native_local_class_fn__1078000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetPrimitiveType__Class().Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_classes_native_local_class_fn__1078000074_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000074_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000074_A{}; t.Ctor_O(p0); return t }
//line :132:1
func (t *A_arbace_classes_native_local_class_fn__1078000074_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :132:1
func (t *A_arbace_classes_native_local_class_fn__1078000074_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); if jrt.NN(lang.Compiler_LocalBinding_Cast(t.F_lb)).HasJavaClass__Z() {
												var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetJavaClass__Class().Ref() } else {
//line :132:1
		tmp1 = nil }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_classes_native_field_names_A_New() *A_arbace_classes_native_field_names_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_field_names_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_classes_native_field_names_A) Ctor() {}
//line :140:1
func (t *A_arbace_classes_native_field_names_A) Invoke_O_O__O(self, syms__0 any) any { { var G__1078000080__2_ any = syms__0; var vec__1078000081__3 any = G__1078000080__2_; var seq__1078000082__4 any; var root_615 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_617 lang.IFn


	if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = vec__1078000081__3; if linked_616 == nil { seq__1078000082__4 = ifn_617.Invoke_O__O(arg_618) } else { seq__1078000082__4 = linked_616.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_615, arg_618) }
//line :140:1
	var first__1078000083__5 any; var root_619 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_621 lang.IFn


	if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = seq__1078000082__4; if linked_620 == nil { first__1078000083__5 = ifn_621.Invoke_O__O(arg_622) } else { first__1078000083__5 = linked_620.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_619, arg_622) }
//line :140:1
	var seq__1078000082__6 any; var root_623 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_625 lang.IFn


	if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = seq__1078000082__4; if linked_624 == nil { seq__1078000082__6 = ifn_625.Invoke_O__O(arg_626) } else { seq__1078000082__6 = linked_624.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_623, arg_626) }
//line :140:1
	var s__7 any = first__1078000083__5; var more__8 any = seq__1078000082__6; var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); var out__10 any = lang.PersistentVector_EMPTY.Ref(); var G__1078000080__11_ any = G__1078000080__2_; var seen__12 any = seen__9; var out__13 any = out__10; _ = s__7; _ = more__8; L1: for { var vec__1078000084__14 any = G__1078000080__11_; var seq__1078000085__15 any; var root_627 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_629 lang.IFn


		if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = vec__1078000084__14; if linked_628 == nil { seq__1078000085__15 = ifn_629.Invoke_O__O(arg_630) } else { seq__1078000085__15 = linked_628.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_627, arg_630) }
//line :140:1
		var first__1078000086__16 any; var root_631 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_633 lang.IFn


		if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = seq__1078000085__15; if linked_632 == nil { first__1078000086__16 = ifn_633.Invoke_O__O(arg_634) } else { first__1078000086__16 = linked_632.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_631, arg_634) }
//line :140:1
		var seq__1078000085__17 any; var root_635 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_637 lang.IFn


		if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = seq__1078000085__15; if linked_636 == nil { seq__1078000085__17 = ifn_637.Invoke_O__O(arg_638) } else { seq__1078000085__17 = linked_636.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_635, arg_638) }
//line :140:1
		var s__18 any = first__1078000086__16; var more__19 any = seq__1078000085__17; var seen__20 any = seen__12; var out__21 any = out__13; var tmp1 any; var root_639 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_641 lang.IFn



		if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = s__18; if linked_640 == nil { tmp1 = ifn_641.Invoke_O__O(arg_642) } else { tmp1 = linked_640.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(tmp1) { return out__21 } else { var base__22 any; var root_643 any = A_arbace_classes_native_A_const_87.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_645 lang.IFn

			if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any; var root_647 any = A_arbace_classes_native_A_const_88.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = s__18; if linked_648 == nil { arg_646 = ifn_649.Invoke_O__O(arg_650) } else { arg_646 = linked_648.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_647, arg_650) }; if linked_644 == nil { base__22 = ifn_645.Invoke_O__O(arg_646) } else { base__22 = linked_644.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_643, arg_646) }
//line :144:1
			var n__23 any


			if jrt.J2g_Truth(lang.IFn_Cast(seen__20).Invoke_O__O(base__22)) { n__23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, base__22, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(out__21)).Ref())).Ref() } else { n__23 = base__22 }
			var tmp2 any; var root_651 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = seen__20; var arg_655 any = n__23; if linked_652 == nil { tmp2 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { tmp2 = linked_652.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_651, arg_654, arg_655) }; var tmp3 any = tmp2; var tmp4 any; var root_656 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = out__21; var arg_660 any = n__23; if linked_657 == nil { tmp4 = ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { tmp4 = linked_657.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_656, arg_659, arg_660) }; G__1078000080__11_, seen__12, out__13 = more__19, tmp3, tmp4; continue L1 } } }; /*line :140:1*/panic("j2g: unreachable") }









func A_arbace_classes_native_fn_class_form_A_New() *A_arbace_classes_native_fn_class_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_classes_native_fn_class_form_A) Ctor() {}
//line :150:1
func (t *A_arbace_classes_native_fn_class_form_A) Invoke_O_O_O_O__O(self, cname__0, form__1, captured__2 any) any { var map__1078000088__4 any; var root_661 any = A_arbace_classes_native_A_const_89.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A_fn_class); var ifn_663 lang.IFn; if



	linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = form__1; if linked_662 == nil { map__1078000088__4 = ifn_663.Invoke_O__O(arg_664) } else { map__1078000088__4 = linked_662.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A).Invoke_O_O__O(root_661, arg_664) }; var map__1078000088__5 any; if lang.ISeq_InstanceOf(map__1078000088__4) { var tmp1 any; var root_665 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = map__1078000088__4; if linked_666 == nil { tmp1 = ifn_667.Invoke_O__O(arg_668) } else { tmp1 = linked_666.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_665, arg_668) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_669 any = A_arbace_classes_native_A_const_58.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = map__1078000088__4; if linked_670 == nil { tmp2 = ifn_671.Invoke_O__O(arg_672) } else { tmp2 = linked_670.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_669, arg_672) }; map__1078000088__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_673 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = map__1078000088__4; if linked_674 == nil { tmp3 = ifn_675.Invoke_O__O(arg_676) } else { tmp3 = linked_674.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_673, arg_676) }; if jrt.J2g_Truth(tmp3) { var root_677 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = map__1078000088__4; if linked_678 == nil { map__1078000088__5 = ifn_679.Invoke_O__O(arg_680) } else { map__1078000088__5 = linked_678.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_677, arg_680) } } else { map__1078000088__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000088__5 = map__1078000088__4 }; var nm__6 any = /*line :150:1*/lang.RT_Get_O_O__O_NoInit(map__1078000088__5, A_arbace_classes_native_A_const_90); var arities__7 any = lang.RT_Get_O_O__O_NoInit(map__1078000088__5, A_arbace_classes_native_A_const_91); var i__8 int32 = jrt.NN(jrt.String_Cast(cname__0)).LastIndexOf_String__I(Lit_17); var pkg__9 any; if





	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__8)) { pkg__9 = Lit_18 } else { var root_681 any = A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = cname__0; var arg_685 any = A_arbace_classes_native_A_const_93; var arg_686 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__8).Ref(); if linked_682 == nil { pkg__9 = ifn_683.Invoke_O_O_O__O(arg_684, arg_685, arg_686) } else { pkg__9 = linked_682.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_681, arg_684, arg_685, arg_686) } }; var simple__10 any; var root_687 any = /*line :150:1*/A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_689 lang.IFn; if






	linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = cname__0; var arg_691 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__8))).Ref(); if linked_688 == nil { simple__10 = ifn_689.Invoke_O_O__O(arg_690, arg_691) } else { simple__10 = linked_688.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_687, arg_690, arg_691) }; var rcv__11 any; var root_692 any = /*line :150:1*/A_arbace_classes_native_A_const_94.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_694 lang.IFn; if







	linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = Lit_19; if linked_693 == nil { rcv__11 = ifn_694.Invoke_O__O(arg_695) } else { rcv__11 = linked_693.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_692, arg_695) }; var fields__12 any; var root_696 any = /*line :150:1*/A_arbace_classes_native_A_const_95.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, A_arbace_classes_native_field_names_A_fn_class); var ifn_698 lang.IFn; if








	linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var root_700 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var arg_704 any = captured__2; if linked_701 == nil { arg_699 = ifn_702.Invoke_O_O__O(arg_703, arg_704) } else { arg_699 = linked_701.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_700, arg_703, arg_704) }; if linked_697 == nil { fields__12 = ifn_698.Invoke_O__O(arg_699) } else { fields__12 = linked_697.(*A_arbace_classes_native_field_names_A).Invoke_O_O__O(root_696, arg_699) }; var super__13 any; var tmp4 any; var root_705 any = /*line :150:1*/A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_707 lang.IFn; if









	linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = A_arbace_classes_native_A_const_97.GetRawRoot__O(); var arg_709 any = arities__7; if linked_706 == nil { tmp4 = ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { tmp4 = linked_706.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) }; if jrt.J2g_Truth(tmp4) { super__13 = A_arbace_classes_native_A_const_98 } else { super__13 = A_arbace_classes_native_A_const_99 }; var typed__14 any; var tmp5 any = /*line :150:1*/A_arbace_classes_native_fn_class_form_typed__1078000090_A_New(); var tmp6 *jrt.Class; var fncls__719 *jrt.Class = A_arbace_classes_native_fn_class_form_typed__1078000090_A_fn_class; if










	fncls__719 == nil { var fncls__719d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_native_fn_class_form_typed__1078000090_A_fn_class = fncls__719d; tmp6 = fncls__719d } else { tmp6 = fncls__719 }; typed__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_classes_native_A_const_74.GetRawRoot__O()); var tmp8 any; var root_727 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_729 lang.IFn; if
	linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any; var root_732 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = simple__10; if linked_733 == nil { arg_730 = ifn_734.Invoke_O__O(arg_735) } else { arg_730 = linked_733.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_732, arg_735) }; var arg_731 any = A_arbace_classes_native_A_const_101; if linked_728 == nil { tmp8 = ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { tmp8 = linked_728.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_727, arg_730, arg_731) }; var tmp9 any = tmp8; var tmp10 any = A_arbace_classes_native_A_const_102; var tmp11 any = A_arbace_classes_native_A_const_103; var tmp12 any = A_arbace_classes_native_A_const_104; var tmp13 any; var root_736 any = /*line :162:1*/A_arbace_classes_native_A_const_105.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A_fn_class); var ifn_738 lang.IFn; if



	linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = arities__7; if linked_737 == nil { tmp13 = ifn_738.Invoke_O__O(arg_739) } else { tmp13 = linked_737.(*aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A).Invoke_O_O__O(root_736, arg_739) }; var tmp14 any = /*line :162:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, pkg__9, tmp11, super__13, tmp12, tmp13)); var tmp15 any; var iter__1927001039__auto____15 any; var tmp16 any = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_New_O(typed__14); var tmp17 *jrt.Class; var fncls__820 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_fn_class; if




	fncls__820 == nil { var fncls__820d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_fn_class = fncls__820d; tmp17 = fncls__820d } else { tmp17 = fncls__820 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var tmp18 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp19 any; var root_821 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = A_arbace_classes_native_A_const_109.GetRawRoot__O(); var arg_825 any = fields__12; var arg_826 any = captured__2; if linked_822 == nil { tmp19 = ifn_823.Invoke_O_O_O__O(arg_824, arg_825, arg_826) } else { tmp19 = linked_822.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_821, arg_824, arg_825, arg_826) }; tmp15 = tmp18.Invoke_O__O(tmp19); var tmp20 any = tmp15; var tmp21 any; var root_827 any = /*line :162:1*/A_arbace_classes_native_A_const_110.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_829 lang.IFn; if






	linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = A_arbace_classes_native_A_const_111; var arg_831 any; var root_834 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any; var root_839 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var root_843 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = rcv__11; var arg_847 any; var root_848 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var tmp22 any = A_arbace_classes_native_fn_class_form_fn__1078000115_A_New_O(typed__14); var tmp23 *jrt.Class; var fncls__858 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000115_A_fn_class; if fncls__858 == nil { var fncls__858d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_native_fn_class_form_fn__1078000115_A_fn_class = fncls__858d; tmp23 = fncls__858d } else { tmp23 = fncls__858 }; arg_851 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_852 any = fields__12; var arg_853 any = captured__2; if linked_849 == nil { arg_847 = ifn_850.Invoke_O_O_O__O(arg_851, arg_852, arg_853) } else { arg_847 = linked_849.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_848, arg_851, arg_852, arg_853) }; if linked_844 == nil { arg_842 = ifn_845.Invoke_O_O__O(arg_846, arg_847) } else { arg_842 = linked_844.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_843, arg_846, arg_847) }; if linked_840 == nil { arg_837 = ifn_841.Invoke_O__O(arg_842) } else { arg_837 = linked_840.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_839, arg_842) }; var arg_838 any = A_arbace_classes_native_A_const_112; if linked_835 == nil { arg_831 = ifn_836.Invoke_O_O__O(arg_837, arg_838) } else { arg_831 = linked_835.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_834, arg_837, arg_838) }; var arg_832 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_113); var arg_833 any; var iter__1927001039__auto____15_2 any; var tmp24 any = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_New_O(rcv__11); var tmp25 *jrt.Class; var fncls__933 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_fn_class; if


	fncls__933 == nil { var fncls__933d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_fn_class = fncls__933d; tmp25 = fncls__933d } else { tmp25 = fncls__933 }; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); arg_833 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(fields__12); if /*line :169:1*/ linked_828 == nil { tmp21 = ifn_829.Invoke_O_O_O_O__O(arg_830, arg_831, arg_832, arg_833) } else { tmp21 = linked_828.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_827, arg_830, arg_831, arg_832, arg_833) }; var tmp26 any = /*line :162:1*/lang.Tuple_Create_O__IPersistentVector(tmp21); var tmp27 any; var root_934 any = A_arbace_classes_native_A_const_115.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A_fn_class); var ifn_936 lang.IFn; if










	linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = rcv__11; var arg_938 any = nm__6; var arg_939 any = arities__7; var arg_940 any; var root_941 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_943 lang.IFn; if
	linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_21.GetRawRoot__O()); var tmp29 any = A_arbace_classes_native_fn_class_form_fn__1078000131_A_New_O(rcv__11); var tmp30 *jrt.Class; var fncls__955 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000131_A_fn_class; if fncls__955 == nil { var fncls__955d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_native_fn_class_form_fn__1078000131_A_fn_class = fncls__955d; tmp30 = fncls__955d } else { tmp30 = fncls__955 }; arg_944 = tmp28.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), fields__12, captured__2); if linked_942 == nil { arg_940 = ifn_943.Invoke_O__O(arg_944) } else { arg_940 = linked_942.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_941, arg_944) }; if /*line :173:1*/ linked_935 == nil { tmp27 = ifn_936.Invoke_O_O_O_O__O(arg_937, arg_938, arg_939, arg_940) } else { tmp27 = linked_935.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A).Invoke_O_O_O_O_O__O(root_934, arg_937, arg_938, arg_939, arg_940) }; return /*line :162:1*/ tmp7.Invoke_O_O_O_O__O(tmp14, tmp20, tmp26, tmp27) }
//line :161:1
func A_arbace_classes_native_fn_class_form_typed__1078000090_A_New() *A_arbace_classes_native_fn_class_form_typed__1078000090_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_typed__1078000090_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000090_A) Ctor() {}
//line :161:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000090_A) Invoke_O_O_O__O(self, s__1, c__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__2, A_arbace_classes_native_A_const_86) { return s__1 } else { var root_710 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = s__1; var arg_714 any; var tmp1 any = A_arbace_classes_native_A_const_40; var tmp2 any; var root_715 any = A_arbace_classes_native_A_const_100.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, A_arbace_classes_native_type_form_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = c__2; if linked_716 == nil { tmp2 = ifn_717.Invoke_O__O(arg_718) } else { tmp2 = linked_716.(*A_arbace_classes_native_type_form_A).Invoke_O_O__O(root_715, arg_718) }; arg_714 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2)); if linked_711 == nil { return ifn_712.Invoke_O_O__O(arg_713, arg_714) } else { return linked_711.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_710, arg_713, arg_714) } } }





func A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A) Invoke_O_O__O(self, s__1078000093__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_New_O_O_O(s__1078000093__1, self, t.F_typed); var tmp2 *jrt.Class; var fncls__819 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_fn_class; if fncls__819 == nil { var fncls__819d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_fn_class = fncls__819d; tmp2 = fncls__819d } else { tmp2 = fncls__819 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :167:1
func A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A) Ctor_O_O_O(c__s__1078000093, c__iter__1078000092, c__typed any) { t.F_s__1078000093 = c__s__1078000093; t.F_iter__1078000092 = c__iter__1078000092; t.F_typed = c__typed }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A) Invoke_O__O(self any) any { { var s__1078000093__1 any; var t_ any = t.F_s__1078000093; t.F_s__1078000093 = nil; s__1078000093__1 = t_; for { var temp__1927000414__auto____2 any; var root_740 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = s__1078000093__1; if linked_741 == nil { temp__1927000414__auto____2 = ifn_742.Invoke_O__O(arg_743) } else { temp__1927000414__auto____2 = linked_741.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_740, arg_743) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000093__3 any = temp__1927000414__auto____2; var tmp1 any; var root_744 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = s__1078000093__3; if linked_745 == nil { tmp1 = ifn_746.Invoke_O__O(arg_747) } else { tmp1 = linked_745.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_744, arg_747) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_748 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = s__1078000093__3; if linked_749 == nil { c__1927001037__auto____4 = ifn_750.Invoke_O__O(arg_751) } else { c__1927001037__auto____4 = linked_749.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_748, arg_751) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000095__6 any; var root_752 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_753 == nil { b__1078000095__6 = ifn_754.Invoke_O__O(arg_755) } else { b__1078000095__6 = linked_753.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_752, arg_755) }; var tmp2 any = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_New_O_O_I_O(b__1078000095__6, t.F_typed, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__772 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_fn_class; if fncls__772 == nil { var fncls__772d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_fn_class = fncls__772d; tmp3 = fncls__772d } else { tmp3 = fncls__772 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_773 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any; var root_778 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = b__1078000095__6; if linked_779 == nil { arg_776 = ifn_780.Invoke_O__O(arg_781) } else { arg_776 = linked_779.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_778, arg_781) }; var arg_777 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000092); var tmp5 any; var root_782 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = s__1078000093__3; if linked_783 == nil { tmp5 = ifn_784.Invoke_O__O(arg_785) } else { tmp5 = linked_783.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_782, arg_785) }; arg_777 = tmp4.Invoke_O__O(tmp5); if linked_774 == nil { return ifn_775.Invoke_O_O__O(arg_776, arg_777) } else { return linked_774.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_773, arg_776, arg_777) } } else { var root_786 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var root_791 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = b__1078000095__6; if linked_792 == nil { arg_789 = ifn_793.Invoke_O__O(arg_794) } else { arg_789 = linked_792.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_791, arg_794) }; var arg_790 any; if linked_787 == nil { return ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { return linked_787.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) } } } else { var vec__1078000106__4 any; var root_795 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = s__1078000093__3; if linked_796 == nil { vec__1078000106__4 = ifn_797.Invoke_O__O(arg_798) } else { vec__1078000106__4 = linked_796.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_795, arg_798) }; var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000106__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000109__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000106__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000109__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000109__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_799 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_801 lang.IFn; _ = ___7; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_106; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_107.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp10 any; var root_811 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_813 lang.IFn
															if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = f__5; if linked_812 == nil { tmp10 = ifn_813.Invoke_O__O(arg_814) } else { tmp10 = linked_812.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_811, arg_814) }; arg_802 = tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O_O__O(tmp9.Invoke_O_O__O(tmp10, c__8), A_arbace_classes_native_A_const_46.GetRawRoot__O(), A_arbace_classes_native_A_const_108, jrt.Boolean_TRUE.Ref()))
//line :167:1
	var arg_803 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000092); var tmp12 any; var root_815 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = s__1078000093__3; if linked_816 == nil { tmp12 = ifn_817.Invoke_O__O(arg_818) } else { tmp12 = linked_816.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_815, arg_818) }; arg_803 = tmp11.Invoke_O__O(tmp12); if linked_800 == nil { return ifn_801.Invoke_O_O__O(arg_802, arg_803) } else { return linked_800.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_799, arg_802, arg_803) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :167:1
func A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A) Ctor_O_O_I_O(c__b__1078000095, c__typed any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000095 = c__b__1078000095; t.F_typed = c__typed; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A) Invoke_O__O(self any) any { { var i__1078000094__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000099__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000094__1)); var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000099__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000102__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000099__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000102__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000102__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_756 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_758 lang.IFn; _ = ___5; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = t.F_b__1078000095; var arg_760 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_106; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_107.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp6 any; var root_768 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_770 lang.IFn
																	if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = f__3; if linked_769 == nil { tmp6 = ifn_770.Invoke_O__O(arg_771) } else { tmp6 = linked_769.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_768, arg_771) }; arg_760 = tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5.Invoke_O_O__O(tmp6, c__6), A_arbace_classes_native_A_const_46.GetRawRoot__O(), A_arbace_classes_native_A_const_108, jrt.Boolean_TRUE.Ref()))
//line :167:1
	if linked_757 == nil { ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { linked_757.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; i__1078000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000094__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000115_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000115_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000115_A{}; t.Ctor_O(p0); return t }
//line :169:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000115_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :169:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000115_A) Invoke_O_O_O__O(self, f__1, p__1078000114__2 any) any { var vec__1078000116__3 any = p__1078000114__2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000116__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000116__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp2 any; var root_854 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_856 lang.IFn; _ = ___4; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = f__1; if linked_855 == nil { tmp2 = ifn_856.Invoke_O__O(arg_857) } else { tmp2 = linked_855.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_854, arg_857) }; return tmp1.Invoke_O_O__O(tmp2, c__5) }


func A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A) Invoke_O_O__O(self, s__1078000121__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_New_O_O_O(s__1078000121__1, self, t.F_rcv); var tmp2 *jrt.Class; var fncls__932 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_fn_class; if fncls__932 == nil { var fncls__932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_fn_class = fncls__932d; tmp2 = fncls__932d } else { tmp2 = fncls__932 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A) Ctor_O_O_O(c__s__1078000121, c__iter__1078000120, c__rcv any) { t.F_s__1078000121 = c__s__1078000121; t.F_iter__1078000120 = c__iter__1078000120; t.F_rcv = c__rcv }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A) Invoke_O__O(self any) any { { var s__1078000121__1 any; var t_ any = t.F_s__1078000121; t.F_s__1078000121 = nil; s__1078000121__1 = t_; for { var temp__1927000414__auto____2 any; var root_859 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = s__1078000121__1; if linked_860 == nil { temp__1927000414__auto____2 = ifn_861.Invoke_O__O(arg_862) } else { temp__1927000414__auto____2 = linked_860.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_859, arg_862) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000121__3 any = temp__1927000414__auto____2; var tmp1 any; var root_863 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_865 lang.IFn; if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = s__1078000121__3; if linked_864 == nil { tmp1 = ifn_865.Invoke_O__O(arg_866) } else { tmp1 = linked_864.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_863, arg_866) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_867 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = s__1078000121__3; if linked_868 == nil { c__1927001037__auto____4 = ifn_869.Invoke_O__O(arg_870) } else { c__1927001037__auto____4 = linked_868.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_867, arg_870) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000123__6 any; var root_871 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_872 == nil { b__1078000123__6 = ifn_873.Invoke_O__O(arg_874) } else { b__1078000123__6 = linked_872.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_871, arg_874) }; var tmp2 any = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_New_O_I_O_O(t.F_rcv, size__1927001038__auto____5, b__1078000123__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__888 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_fn_class; if fncls__888 == nil { var fncls__888d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_fn_class = fncls__888d; tmp3 = fncls__888d } else { tmp3 = fncls__888 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_889 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var root_894 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = b__1078000123__6; if linked_895 == nil { arg_892 = ifn_896.Invoke_O__O(arg_897) } else { arg_892 = linked_895.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_894, arg_897) }; var arg_893 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000120); var tmp5 any; var root_898 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = s__1078000121__3; if linked_899 == nil { tmp5 = ifn_900.Invoke_O__O(arg_901) } else { tmp5 = linked_899.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_898, arg_901) }; arg_893 = tmp4.Invoke_O__O(tmp5); if linked_890 == nil { return ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { return linked_890.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) } } else { var root_902 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any; var root_907 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = b__1078000123__6; if linked_908 == nil { arg_905 = ifn_909.Invoke_O__O(arg_910) } else { arg_905 = linked_908.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_907, arg_910) }; var arg_906 any; if linked_903 == nil { return ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { return linked_903.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) } } } else { var f__4 any; var root_911 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = s__1078000121__3; if linked_912 == nil { f__4 = ifn_913.Invoke_O__O(arg_914) } else { f__4 = linked_912.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_911, arg_914) }; var root_915 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_114; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp9 any; var root_924 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref(); if linked_925 == nil { tmp9 = ifn_926.Invoke_O__O(arg_927) } else { tmp9 = linked_925.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_924, arg_927) }; var tmp10 any = tmp8.Invoke_O_O__O(tmp9, t.F_rcv); var tmp11 any; var root_920 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = f__4; if linked_921 == nil { tmp11 = ifn_922.Invoke_O__O(arg_923) } else { tmp11 = linked_921.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_920, arg_923) }; arg_918 = tmp6.Invoke_O_O_O__O(tmp7, tmp10, tmp11); var arg_919 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1078000120); var tmp13 any; var root_928 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = s__1078000121__3; if linked_929 == nil { tmp13 = ifn_930.Invoke_O__O(arg_931) } else { tmp13 = linked_929.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_928, arg_931) }; arg_919 = tmp12.Invoke_O__O(tmp13); if linked_916 == nil { return ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { return linked_916.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_915, arg_918, arg_919) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A) Ctor_O_I_O_O(c__rcv any, c__size__1927001038__auto__ int32, c__b__1078000123, c__c__1927001037__auto__ any) { t.F_rcv = c__rcv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1078000123 = c__b__1078000123; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A) Invoke_O__O(self any) any { { var i__1078000122__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000122__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000122__1)); var root_875 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = t.F_b__1078000123; var arg_879 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_114; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp5 any; var root_884 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref(); if linked_885 == nil { tmp5 = ifn_886.Invoke_O__O(arg_887) } else { tmp5 = linked_885.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_884, arg_887) }; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, t.F_rcv); var tmp7 any; var root_880 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = f__2; if linked_881 == nil { tmp7 = ifn_882.Invoke_O__O(arg_883) } else { tmp7 = linked_881.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_880, arg_883) }; arg_879 = tmp2.Invoke_O_O_O__O(tmp3, tmp6, tmp7); if linked_876 == nil { ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { linked_876.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) }; i__1078000122__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000122__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000131_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000131_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000131_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000131_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :174:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000131_A) Invoke_O_O_O__O(self, f__1, p__1078000130__2 any) any { var vec__1078000132__3 any = p__1078000130__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000132__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000132__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp2 any; var root_951 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_953 lang.IFn; _ = ___5; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref(); if linked_952 == nil { tmp2 = ifn_953.Invoke_O__O(arg_954) } else { tmp2 = linked_952.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_951, arg_954) }; return lang.Tuple_Create_O_O__IPersistentVector(s__4, tmp1.Invoke_O_O__O(tmp2, t.F_rcv)) }

func A_arbace_classes_native_compile_fn_A_New() *A_arbace_classes_native_compile_fn_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_classes_native_compile_fn_A) Ctor() {}
//line :176:1
func (t *A_arbace_classes_native_compile_fn_A) Invoke_O_O_O_O_O__O(self, ns__0, cname__1, form__2, env__3 any) any { { var host__5 any; var root_956 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_958 lang.IFn





	if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_960 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_New(); var tmp2 *jrt.Class; var fncls__1027 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_fn_class; if fncls__1027 == nil { var fncls__1027d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_fn_class = fncls__1027d; tmp2 = fncls__1027d } else { tmp2 = fncls__1027 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_960 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(env__3); if linked_957 == nil { host__5 = ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { host__5 = linked_957.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }
//line :176:1
	var mentioned__6 any; var root_1028 any = A_arbace_classes_native_A_const_117.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A_fn_class); var ifn_1030 lang.IFn






	if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = form__2; if linked_1029 == nil { mentioned__6 = ifn_1030.Invoke_O__O(arg_1031) } else { mentioned__6 = linked_1029.(*aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A).Invoke_O_O__O(root_1028, arg_1031) }
//line :176:1
	var syms__7 any; var root_1032 any = A_arbace_classes_native_A_const_118.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_1034 lang.IFn







	if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any; var tmp3 any = A_arbace_classes_native_compile_fn_fn__1078000156_A_New_O(host__5); var tmp4 *jrt.Class; var fncls__1042 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000156_A_fn_class; if fncls__1042 == nil { var fncls__1042d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_classes_native_compile_fn_fn__1078000156_A_fn_class = fncls__1042d; tmp4 = fncls__1042d } else { tmp4 = fncls__1042 }; arg_1035 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1036 any; var root_1043 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var arg_1047 any = mentioned__6; if linked_1044 == nil { arg_1036 = ifn_1045.Invoke_O_O__O(arg_1046, arg_1047) } else { arg_1036 = linked_1044.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1043, arg_1046, arg_1047) }; if linked_1033 == nil { syms__7 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { syms__7 = linked_1033.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }
//line :176:1
L1: for { var captured__8 any; var root_1048 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1050 lang.IFn








	if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any; var tmp5 any = A_arbace_classes_native_compile_fn_fn__1078000158_A_New_O(host__5); var tmp6 *jrt.Class; var fncls__1053 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000158_A_fn_class; if fncls__1053 == nil { var fncls__1053d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_classes_native_compile_fn_fn__1078000158_A_fn_class = fncls__1053d; tmp6 = fncls__1053d } else { tmp6 = fncls__1053 }; arg_1051 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1052 any = syms__7; if linked_1049 == nil { captured__8 = ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { captured__8 = linked_1049.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) }
//line :176:1
	var r__9 any; var tmp7 any = A_arbace_classes_native_compile_fn_fn__1078000160_A_New_O_O_O_O_O_O(form__2, host__5, ns__0, syms__7, cname__1, captured__8); var tmp8 *jrt.Class
	var fncls__1112 /*line :176:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000160_A_fn_class









	if fncls__1112 == nil { var fncls__1112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_classes_native_compile_fn_fn__1078000160_A_fn_class = fncls__1112d; tmp8 = fncls__1112d } else { tmp8 = fncls__1112 }; r__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()









	var tmp9 any = A_arbace_classes_native_A_const_125; var tmp10 any; var root_1113 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = r__9; if linked_1114 == nil { tmp10 = ifn_1115.Invoke_O__O(arg_1116) } else { tmp10 = linked_1114.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1113, arg_1116) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10) {
		var tmp11 any; var root_1135 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = syms__7; var arg_1139 any; var root_1140 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = r__9; if linked_1141 == nil { arg_1139 = ifn_1142.Invoke_O__O(arg_1143) } else { arg_1139 = linked_1141.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1140, arg_1143) }; if linked_1136 == nil { tmp11 = ifn_1137.Invoke_O_O__O(arg_1138, arg_1139) } else { tmp11 = linked_1136.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1135, arg_1138, arg_1139) }; syms__7 = tmp11; continue L1 } else {
//line :196:1
			var new__10 any; var root_1117 any = A_arbace_classes_native_A_const_110.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1119 lang.IFn


			if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = A_arbace_classes_native_A_const_126; var arg_1121 any; var root_1123 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any; var root_1127 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = r__9; if linked_1128 == nil { arg_1126 = ifn_1129.Invoke_O__O(arg_1130) } else { arg_1126 = linked_1128.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1127, arg_1130) }; if linked_1124 == nil { arg_1121 = ifn_1125.Invoke_O__O(arg_1126) } else { arg_1121 = linked_1124.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1123, arg_1126) }; var arg_1122 any = syms__7; if linked_1118 == nil { new__10 = ifn_1119.Invoke_O_O_O__O(arg_1120, arg_1121, arg_1122) } else { new__10 = linked_1118.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122) }
//line :196:1
			var temp__1927000408__auto____11 any; var root_1131 any = A_arbace_classes_native_A_const_127.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A_fn_class); var ifn_1133 lang.IFn



			if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = form__2; if linked_1132 == nil { temp__1927000408__auto____11 = ifn_1133.Invoke_O__O(arg_1134) } else { temp__1927000408__auto____11 = linked_1132.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A).Invoke_O_O__O(root_1131, arg_1134) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11
				return lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_classes_native_A_const_128, new__10, m__12) } else {
//line :200:1
					return new__10 } } } }; /*line :176:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_New() *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A) Ctor() {}
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A) Invoke_O_O__O(self, s__1078000141__1 any) any { var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_New_O_O(s__1078000141__1, self); var tmp2 *jrt.Class; var fncls__1026 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_fn_class; if fncls__1026 == nil { var fncls__1026d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_fn_class = fncls__1026d; tmp2 = fncls__1026d } else { tmp2 = fncls__1026 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A) Ctor_O_O(c__s__1078000141, c__iter__1078000140 any) { t.F_s__1078000141 = c__s__1078000141; t.F_iter__1078000140 = c__iter__1078000140 }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A) Invoke_O__O(self any) any { { var s__1078000141__1 any; var t_ any = t.F_s__1078000141; t.F_s__1078000141 = nil; s__1078000141__1 = t_; for { var temp__1927000414__auto____2 any; var root_961 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = s__1078000141__1; if linked_962 == nil { temp__1927000414__auto____2 = ifn_963.Invoke_O__O(arg_964) } else { temp__1927000414__auto____2 = linked_962.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_961, arg_964) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000141__3 any = temp__1927000414__auto____2; var tmp1 any; var root_965 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = s__1078000141__3; if linked_966 == nil { tmp1 = ifn_967.Invoke_O__O(arg_968) } else { tmp1 = linked_966.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_965, arg_968) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_969 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = s__1078000141__3; if linked_970 == nil { c__1927001037__auto____4 = ifn_971.Invoke_O__O(arg_972) } else { c__1927001037__auto____4 = linked_970.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_969, arg_972) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000143__6 any; var root_973 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_974 == nil { b__1078000143__6 = ifn_975.Invoke_O__O(arg_976) } else { b__1078000143__6 = linked_974.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_973, arg_976) }; var tmp2 any = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_New_O_I_O(b__1078000143__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__986 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_fn_class; if fncls__986 == nil { var fncls__986d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_fn_class = fncls__986d; tmp3 = fncls__986d } else { tmp3 = fncls__986 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_987 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any; var root_992 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = b__1078000143__6; if linked_993 == nil { arg_990 = ifn_994.Invoke_O__O(arg_995) } else { arg_990 = linked_993.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_992, arg_995) }; var arg_991 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000140); var tmp5 any; var root_996 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = s__1078000141__3; if linked_997 == nil { tmp5 = ifn_998.Invoke_O__O(arg_999) } else { tmp5 = linked_997.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_996, arg_999) }; arg_991 = tmp4.Invoke_O__O(tmp5); if linked_988 == nil { return ifn_989.Invoke_O_O__O(arg_990, arg_991) } else { return linked_988.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_987, arg_990, arg_991) } } else { var root_1000 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any; var root_1005 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = b__1078000143__6; if linked_1006 == nil { arg_1003 = ifn_1007.Invoke_O__O(arg_1008) } else { arg_1003 = linked_1006.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1005, arg_1008) }; var arg_1004 any; if linked_1001 == nil { return ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { return linked_1001.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) } } } else { var vec__1078000151__4 any; var root_1009 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = s__1078000141__3; if linked_1010 == nil { vec__1078000151__4 = ifn_1011.Invoke_O__O(arg_1012) } else { vec__1078000151__4 = linked_1010.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1009, arg_1012) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000151__4, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000151__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1013 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any; var tmp6 any; var root_1018 any = A_arbace_classes_native_A_const_116.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_classes_native_local_class_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = lb__6; if linked_1019 == nil { tmp6 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp6 = linked_1019.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_1018, arg_1021) }; arg_1016 = lang.Tuple_Create_O_O__IPersistentVector(s__5, tmp6); var arg_1017 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000140); var tmp8 any; var root_1022 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = s__1078000141__3; if linked_1023 == nil { tmp8 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp8 = linked_1023.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1022, arg_1025) }; arg_1017 = tmp7.Invoke_O__O(tmp8); if linked_1014 == nil { return ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { return linked_1014.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A) Ctor_O_I_O(c__b__1078000143 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000143 = c__b__1078000143; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A) Invoke_O__O(self any) any { { var i__1078000142__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000142__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000147__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000142__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000147__2, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000147__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_977 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = t.F_b__1078000143; var arg_981 any; var tmp2 any; var root_982 any = A_arbace_classes_native_A_const_116.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, A_arbace_classes_native_local_class_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = lb__4; if linked_983 == nil { tmp2 = ifn_984.Invoke_O__O(arg_985) } else { tmp2 = linked_983.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_982, arg_985) }; arg_981 = lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp2); if linked_978 == nil { ifn_979.Invoke_O_O__O(arg_980, arg_981) } else { linked_978.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_977, arg_980, arg_981) }; i__1078000142__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000142__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_compile_fn_fn__1078000156_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000156_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000156_A{}; t.Ctor_O(p0); return t }
//line :184:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000156_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :184:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000156_A) Invoke_O_O__O(self, p1__1078000137_SHARP___1 any) any { var root_1037 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = t.F_host; var arg_1041 any = p1__1078000137_SHARP___1; if linked_1038 == nil { return ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { return linked_1038.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) } }
func A_arbace_classes_native_compile_fn_fn__1078000158_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000158_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000158_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000158_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :185:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000158_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(s__1, lang.IFn_Cast(t.F_host).Invoke_O__O(s__1)) }
func A_arbace_classes_native_compile_fn_fn__1078000160_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_native_compile_fn_fn__1078000160_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000160_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :186:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_A) Ctor_O_O_O_O_O_O(c__form, c__host, c__ns, c__syms, c__cname, c__captured any) { t.F_form = c__form; t.F_host = c__host; t.F_ns = c__ns; t.F_syms = c__syms; t.F_cname = c__cname; t.F_captured = c__captured }
//line :186:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1068 any = A_arbace_classes_native_A_const_81.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = lang.IFn_Cast(A_arbace_classes_native_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_83, t.F_ns); if linked_1069 == nil { ifn_1070.Invoke_O__O(arg_1071) } else { linked_1069.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1068, arg_1071) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_1059 any = A_arbace_classes_native_A_const_119.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, A_arbace_classes_native_fn_class_form_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any; var t__2 any = t.F_cname; t.F_cname = nil; arg_1062 = t__2; var arg_1063 any; var t__3 any = t.F_form; t.F_form = nil; arg_1063 = t__3; var arg_1064 any; var t__4 any = t.F_captured; t.F_captured = nil; arg_1064 = t__4; if linked_1060 == nil { tmp5 = ifn_1061.Invoke_O_O_O__O(arg_1062, arg_1063, arg_1064) } else { tmp5 = linked_1060.(*A_arbace_classes_native_fn_class_form_A).Invoke_O_O_O_O__O(root_1059, arg_1062, arg_1063, arg_1064) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :187:1
		return nil }(); var root_1065 any = A_arbace_classes_native_A_const_80.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; if linked_1066 == nil { ifn_1067.Invoke__O() } else { linked_1066.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1065) }
//line :186:1
		if tmp6 != nil { panic(tmp6) } }; return nil }(); if tmp7 != nil { if lang.ExceptionInfo_InstanceOf(tmp7) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp7); var u__4 any; var root_1077 any = A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1079 lang.IFn





			if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any; var tmp8 any = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_New(); var tmp9 *jrt.Class; var fncls__1086 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_fn_class; if fncls__1086 == nil { var fncls__1086d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_fn_class = fncls__1086d; tmp9 = fncls__1086d } else { tmp9 = fncls__1086 }; arg_1080 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_1081 any; var root_1087 any = A_arbace_classes_native_A_const_122.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = A_arbace_classes_native_A_const_123.GetRawRoot__O(); var arg_1091 any; var root_1092 any = A_arbace_classes_native_A_const_124.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any; var tmp10 any = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_New(); var tmp11 *jrt.Class; var fncls__1097 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_fn_class; if fncls__1097 == nil { var fncls__1097d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_fn_class = fncls__1097d; tmp11 = fncls__1097d } else { tmp11 = fncls__1097 }; arg_1095 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1096 any = e__3; if linked_1093 == nil { arg_1091 = ifn_1094.Invoke_O_O__O(arg_1095, arg_1096) } else { arg_1091 = linked_1093.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1092, arg_1095, arg_1096) }; if linked_1088 == nil { arg_1081 = ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { arg_1081 = linked_1088.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) }; if linked_1078 == nil { u__4 = ifn_1079.Invoke_O_O__O(arg_1080, arg_1081) } else { u__4 = linked_1078.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1077, arg_1080, arg_1081) }
			var tmp12 any; var and__1927000168__auto____5 any = u__4; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1098 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any; var t__5 any = t.F_host; t.F_host = nil; arg_1101 = t__5; var arg_1102 any = u__4; if linked_1099 == nil { and__1927000168__auto____6 = ifn_1100.Invoke_O_O__O(arg_1101, arg_1102) } else { and__1927000168__auto____6 = linked_1099.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1098, arg_1101, arg_1102) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1103 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any; var root_1107 any = A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, u__4)); var arg_1111 any; var t__6 any = t.F_syms; t.F_syms = nil; arg_1111 = t__6; if linked_1108 == nil { arg_1106 = ifn_1109.Invoke_O_O__O(arg_1110, arg_1111) } else { arg_1106 = linked_1108.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1107, arg_1110, arg_1111) }; if linked_1104 == nil { tmp12 = ifn_1105.Invoke_O__O(arg_1106) } else { tmp12 = linked_1104.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1103, arg_1106) } } else { tmp12 = and__1927000168__auto____6 } } else { tmp12 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp12) { tmp1 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_classes_native_A_const_125, u__4) } else { panic(jrt.Thrown(e__3)) } } else {
//line :186:1
				panic(tmp7) } }; return tmp1 }





func A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_New() *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A) Ctor() {}
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A) Invoke_O_O__O(self, p1__1078000138_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_native_A_const_120; var tmp2 any; var root_1082 any = A_arbace_classes_native_A_const_121.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = p1__1078000138_SHARP___1; if linked_1083 == nil { tmp2 = ifn_1084.Invoke_O__O(arg_1085) } else { tmp2 = linked_1083.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1082, arg_1085) }; return tmp1.Invoke_O__O(tmp2) }
//line :192:1
func A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_New() *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A) Ctor() {}
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A) Invoke_O_O__O(self, p1__1078000139_SHARP___1 any) any { return jrt.Throwable_Cast(p1__1078000139_SHARP___1).GetCause__Throwable() }







































































































type A_arbace_classes_native_A struct{ jrt.Object }

var A_arbace_classes_native_A_const_pool *jrt.RefArray

var A_arbace_classes_native_A_const_0 *lang.Var

var A_arbace_classes_native_A_const_1 any

var A_arbace_classes_native_A_const_2 any

var A_arbace_classes_native_A_const_3 any

var A_arbace_classes_native_A_const_4 any

var A_arbace_classes_native_A_const_5 *lang.Var

var A_arbace_classes_native_A_const_6 any

var A_arbace_classes_native_A_const_7 *lang.Var

var A_arbace_classes_native_A_const_8 *lang.Var

var A_arbace_classes_native_A_const_9 *lang.Var

var A_arbace_classes_native_A_const_10 *lang.Var

var A_arbace_classes_native_A_const_11 any

var A_arbace_classes_native_A_const_12 *lang.Var

var A_arbace_classes_native_A_const_13 *lang.Var

var A_arbace_classes_native_A_const_14 *lang.Var

var A_arbace_classes_native_A_const_15 *lang.Var

var A_arbace_classes_native_A_const_16 *lang.Var

var A_arbace_classes_native_A_const_17 *lang.Var

var A_arbace_classes_native_A_const_18 *lang.Var

var A_arbace_classes_native_A_const_19 *lang.Var

var A_arbace_classes_native_A_const_20 *lang.Var

var A_arbace_classes_native_A_const_21 *lang.Var

var A_arbace_classes_native_A_const_22 *lang.Var

var A_arbace_classes_native_A_const_23 *lang.Keyword

var A_arbace_classes_native_A_const_24 *lang.Var

var A_arbace_classes_native_A_const_25 *lang.Var

var A_arbace_classes_native_A_const_26 *lang.Var

var A_arbace_classes_native_A_const_27 *lang.Var

var A_arbace_classes_native_A_const_28 *lang.Var

var A_arbace_classes_native_A_const_29 *lang.Var

var A_arbace_classes_native_A_const_30 *lang.Var

var A_arbace_classes_native_A_const_31 *lang.Var

var A_arbace_classes_native_A_const_32 *lang.Var

var A_arbace_classes_native_A_const_33 *lang.Var

var A_arbace_classes_native_A_const_34 *lang.Var

var A_arbace_classes_native_A_const_35 *lang.Var

var A_arbace_classes_native_A_const_36 *lang.Var

var A_arbace_classes_native_A_const_37 *lang.Var

var A_arbace_classes_native_A_const_38 any

var A_arbace_classes_native_A_const_39 *lang.Var

var A_arbace_classes_native_A_const_40 *lang.Keyword

var A_arbace_classes_native_A_const_41 *lang.Var

var A_arbace_classes_native_A_const_42 *lang.Var

var A_arbace_classes_native_A_const_43 *lang.Var

var A_arbace_classes_native_A_const_44 any

var A_arbace_classes_native_A_const_45 *lang.Var

var A_arbace_classes_native_A_const_46 *lang.Var

var A_arbace_classes_native_A_const_47 *lang.Var

var A_arbace_classes_native_A_const_48 *lang.Keyword

var A_arbace_classes_native_A_const_49 *lang.Var

var A_arbace_classes_native_A_const_50 *lang.Var

var A_arbace_classes_native_A_const_51 *lang.Var

var A_arbace_classes_native_A_const_52 *lang.Var

var A_arbace_classes_native_A_const_53 any

var A_arbace_classes_native_A_const_54 *lang.Var

var A_arbace_classes_native_A_const_55 any

var A_arbace_classes_native_A_const_56 *lang.Var

var A_arbace_classes_native_A_const_57 *lang.Var

var A_arbace_classes_native_A_const_58 *lang.Var

var A_arbace_classes_native_A_const_59 *lang.Keyword

var A_arbace_classes_native_A_const_60 *lang.Var

var A_arbace_classes_native_A_const_61 *lang.Var

var A_arbace_classes_native_A_const_62 *lang.Var

var A_arbace_classes_native_A_const_63 *lang.Keyword

var A_arbace_classes_native_A_const_64 *lang.Keyword

var A_arbace_classes_native_A_const_65 *lang.Var

var A_arbace_classes_native_A_const_66 *lang.Var

var A_arbace_classes_native_A_const_67 *lang.Keyword

var A_arbace_classes_native_A_const_68 *lang.Keyword

var A_arbace_classes_native_A_const_69 *lang.Var

var A_arbace_classes_native_A_const_70 *lang.Keyword

var A_arbace_classes_native_A_const_71 *lang.Var

var A_arbace_classes_native_A_const_72 *lang.Keyword

var A_arbace_classes_native_A_const_73 *lang.Var

var A_arbace_classes_native_A_const_74 *lang.Var

var A_arbace_classes_native_A_const_75 *lang.Var

var A_arbace_classes_native_A_const_76 any

var A_arbace_classes_native_A_const_77 any

var A_arbace_classes_native_A_const_78 *lang.Var

var A_arbace_classes_native_A_const_79 *lang.Var

var A_arbace_classes_native_A_const_80 *lang.Var

var A_arbace_classes_native_A_const_81 *lang.Var

var A_arbace_classes_native_A_const_82 *lang.Var

var A_arbace_classes_native_A_const_83 *lang.Var

var A_arbace_classes_native_A_const_84 *lang.Var

var A_arbace_classes_native_A_const_85 *lang.Var

var A_arbace_classes_native_A_const_86 *jrt.Class

var A_arbace_classes_native_A_const_87 *lang.Var

var A_arbace_classes_native_A_const_88 *lang.Var

var A_arbace_classes_native_A_const_89 *lang.Var

var A_arbace_classes_native_A_const_90 *lang.Keyword

var A_arbace_classes_native_A_const_91 *lang.Keyword

var A_arbace_classes_native_A_const_92 *lang.Var

var A_arbace_classes_native_A_const_93 any

var A_arbace_classes_native_A_const_94 *lang.Var

var A_arbace_classes_native_A_const_95 *lang.Var

var A_arbace_classes_native_A_const_96 *lang.Var

var A_arbace_classes_native_A_const_97 *lang.Var

var A_arbace_classes_native_A_const_98 any

var A_arbace_classes_native_A_const_99 any

var A_arbace_classes_native_A_const_100 *lang.Var

var A_arbace_classes_native_A_const_101 any

var A_arbace_classes_native_A_const_102 *lang.Keyword

var A_arbace_classes_native_A_const_103 *lang.Keyword

var A_arbace_classes_native_A_const_104 *lang.Keyword

var A_arbace_classes_native_A_const_105 *lang.Var

var A_arbace_classes_native_A_const_106 any

var A_arbace_classes_native_A_const_107 *lang.Var

var A_arbace_classes_native_A_const_108 *lang.Keyword

var A_arbace_classes_native_A_const_109 *lang.Var

var A_arbace_classes_native_A_const_110 *lang.Var

var A_arbace_classes_native_A_const_111 any

var A_arbace_classes_native_A_const_112 any

var A_arbace_classes_native_A_const_113 any

var A_arbace_classes_native_A_const_114 any

var A_arbace_classes_native_A_const_115 *lang.Var

var A_arbace_classes_native_A_const_116 *lang.Var

var A_arbace_classes_native_A_const_117 *lang.Var

var A_arbace_classes_native_A_const_118 *lang.Var

var A_arbace_classes_native_A_const_119 *lang.Var

var A_arbace_classes_native_A_const_120 *lang.Keyword

var A_arbace_classes_native_A_const_121 *lang.Var

var A_arbace_classes_native_A_const_122 *lang.Var

var A_arbace_classes_native_A_const_123 *lang.Var

var A_arbace_classes_native_A_const_124 *lang.Var

var A_arbace_classes_native_A_const_125 *lang.Keyword

var A_arbace_classes_native_A_const_126 any

var A_arbace_classes_native_A_const_127 *lang.Var

var A_arbace_classes_native_A_const_128 any

var A_arbace_classes_native_A_init jrt.ClassInit

func A_arbace_classes_native_A_Init() { if !A_arbace_classes_native_A_init.Done() { A_arbace_classes_native_A_init.Run(A_arbace_classes_native_A_clinit) } }

func A_arbace_classes_native_A_clinit() { A_arbace_classes_native_A_clinit_p0(); A_arbace_classes_native_A_clinit_p1(); A_arbace_classes_native_A_clinit_p2(); A_arbace_classes_native_A_clinit_p3(); A_arbace_classes_native_A_clinit_p4(); A_arbace_classes_native_A_clinit_p5(); A_arbace_classes_native_A_clinit_p6(); A_arbace_classes_native_A_clinit_p7(); A_arbace_classes_native_A_clinit_p8(); A_arbace_classes_native_A_clinit_p9(); A_arbace_classes_native_A_clinit_p10() }

func A_arbace_classes_native_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_native_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 175); A_arbace_classes_native_A_const_0 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[46]); A_arbace_classes_native_A_const_1 = A_arbace_classes_native_A_const_pool.A[47]; A_arbace_classes_native_A_const_2 = A_arbace_classes_native_A_const_pool.A[48]; A_arbace_classes_native_A_const_3 = A_arbace_classes_native_A_const_pool.A[49]; A_arbace_classes_native_A_const_4 = A_arbace_classes_native_A_const_pool.A[50]; A_arbace_classes_native_A_const_5 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[51]); A_arbace_classes_native_A_const_6 = A_arbace_classes_native_A_const_pool.A[52]; A_arbace_classes_native_A_const_7 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[53]); A_arbace_classes_native_A_const_8 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[54]); A_arbace_classes_native_A_const_9 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[55]); A_arbace_classes_native_A_const_10 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[56]); A_arbace_classes_native_A_const_11 = A_arbace_classes_native_A_const_pool.A[57] }

func A_arbace_classes_native_A_clinit_p1() { A_arbace_classes_native_A_const_12 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[58]); A_arbace_classes_native_A_const_13 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[59]); A_arbace_classes_native_A_const_14 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[60]); A_arbace_classes_native_A_const_15 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[61]); A_arbace_classes_native_A_const_16 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[62]); A_arbace_classes_native_A_const_17 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[63]); A_arbace_classes_native_A_const_18 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[64]); A_arbace_classes_native_A_const_19 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[65]); A_arbace_classes_native_A_const_20 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[66]); A_arbace_classes_native_A_const_21 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[67]); A_arbace_classes_native_A_const_22 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[68]); A_arbace_classes_native_A_const_23 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[69]) }

func A_arbace_classes_native_A_clinit_p2() { A_arbace_classes_native_A_const_24 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[70]); A_arbace_classes_native_A_const_25 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[71]); A_arbace_classes_native_A_const_26 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[72]); A_arbace_classes_native_A_const_27 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[73]); A_arbace_classes_native_A_const_28 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[74]); A_arbace_classes_native_A_const_29 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[75]); A_arbace_classes_native_A_const_30 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[76]); A_arbace_classes_native_A_const_31 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[77]); A_arbace_classes_native_A_const_32 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[78]); A_arbace_classes_native_A_const_33 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[79]); A_arbace_classes_native_A_const_34 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[80]); A_arbace_classes_native_A_const_35 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[81]) }

func A_arbace_classes_native_A_clinit_p3() { A_arbace_classes_native_A_const_36 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[82]); A_arbace_classes_native_A_const_37 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[83]); A_arbace_classes_native_A_const_38 = A_arbace_classes_native_A_const_pool.A[84]; A_arbace_classes_native_A_const_39 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[85]); A_arbace_classes_native_A_const_40 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[86]); A_arbace_classes_native_A_const_41 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[87]); A_arbace_classes_native_A_const_42 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[88]); A_arbace_classes_native_A_const_43 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[89]); A_arbace_classes_native_A_const_44 = A_arbace_classes_native_A_const_pool.A[90]; A_arbace_classes_native_A_const_45 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[91]); A_arbace_classes_native_A_const_46 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[92]); A_arbace_classes_native_A_const_47 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[93]) }

func A_arbace_classes_native_A_clinit_p4() { A_arbace_classes_native_A_const_48 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[94]); A_arbace_classes_native_A_const_49 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[95]); A_arbace_classes_native_A_const_50 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[96]); A_arbace_classes_native_A_const_51 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[97]); A_arbace_classes_native_A_const_52 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[98]); A_arbace_classes_native_A_const_53 = A_arbace_classes_native_A_const_pool.A[99]; A_arbace_classes_native_A_const_54 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[100]); A_arbace_classes_native_A_const_55 = A_arbace_classes_native_A_const_pool.A[101]; A_arbace_classes_native_A_const_56 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[102]); A_arbace_classes_native_A_const_57 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[103]); A_arbace_classes_native_A_const_58 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[104]); A_arbace_classes_native_A_const_59 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[105]) }

func A_arbace_classes_native_A_clinit_p5() { A_arbace_classes_native_A_const_60 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[106]); A_arbace_classes_native_A_const_61 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[107]); A_arbace_classes_native_A_const_62 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[108]); A_arbace_classes_native_A_const_63 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[109]); A_arbace_classes_native_A_const_64 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[110]); A_arbace_classes_native_A_const_65 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[111]); A_arbace_classes_native_A_const_66 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[112]); A_arbace_classes_native_A_const_67 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[113]); A_arbace_classes_native_A_const_68 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[114]); A_arbace_classes_native_A_const_69 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[115]); A_arbace_classes_native_A_const_70 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[116]); A_arbace_classes_native_A_const_71 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[117]) }

func A_arbace_classes_native_A_clinit_p6() { A_arbace_classes_native_A_const_72 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[118]); A_arbace_classes_native_A_const_73 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[119]); A_arbace_classes_native_A_const_74 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[120]); A_arbace_classes_native_A_const_75 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[121]); A_arbace_classes_native_A_const_76 = A_arbace_classes_native_A_const_pool.A[122]; A_arbace_classes_native_A_const_77 = A_arbace_classes_native_A_const_pool.A[123]; A_arbace_classes_native_A_const_78 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[124]); A_arbace_classes_native_A_const_79 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[125]); A_arbace_classes_native_A_const_80 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[126]); A_arbace_classes_native_A_const_81 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[127]); A_arbace_classes_native_A_const_82 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[128]); A_arbace_classes_native_A_const_83 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[129]) }

func A_arbace_classes_native_A_clinit_p7() { A_arbace_classes_native_A_const_84 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[130]); A_arbace_classes_native_A_const_85 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[131]); A_arbace_classes_native_A_const_86 = jrt.Class_Cast(A_arbace_classes_native_A_const_pool.A[132]); A_arbace_classes_native_A_const_87 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[133]); A_arbace_classes_native_A_const_88 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[134]); A_arbace_classes_native_A_const_89 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[135]); A_arbace_classes_native_A_const_90 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[136]); A_arbace_classes_native_A_const_91 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[137]); A_arbace_classes_native_A_const_92 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[138]); A_arbace_classes_native_A_const_93 = A_arbace_classes_native_A_const_pool.A[139]; A_arbace_classes_native_A_const_94 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[140]); A_arbace_classes_native_A_const_95 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[141]) }

func A_arbace_classes_native_A_clinit_p8() { A_arbace_classes_native_A_const_96 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[142]); A_arbace_classes_native_A_const_97 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[143]); A_arbace_classes_native_A_const_98 = A_arbace_classes_native_A_const_pool.A[144]; A_arbace_classes_native_A_const_99 = A_arbace_classes_native_A_const_pool.A[145]; A_arbace_classes_native_A_const_100 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[146]); A_arbace_classes_native_A_const_101 = A_arbace_classes_native_A_const_pool.A[147]; A_arbace_classes_native_A_const_102 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[148]); A_arbace_classes_native_A_const_103 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[149]); A_arbace_classes_native_A_const_104 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[150]); A_arbace_classes_native_A_const_105 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[151]); A_arbace_classes_native_A_const_106 = A_arbace_classes_native_A_const_pool.A[152]; A_arbace_classes_native_A_const_107 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[153]); A_arbace_classes_native_A_const_108 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[154]) }

func A_arbace_classes_native_A_clinit_p9() { A_arbace_classes_native_A_const_109 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[155]); A_arbace_classes_native_A_const_110 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[156]); A_arbace_classes_native_A_const_111 = A_arbace_classes_native_A_const_pool.A[157]; A_arbace_classes_native_A_const_112 = A_arbace_classes_native_A_const_pool.A[158]; A_arbace_classes_native_A_const_113 = A_arbace_classes_native_A_const_pool.A[159]; A_arbace_classes_native_A_const_114 = A_arbace_classes_native_A_const_pool.A[160]; A_arbace_classes_native_A_const_115 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[161]); A_arbace_classes_native_A_const_116 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[162]); A_arbace_classes_native_A_const_117 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[163]); A_arbace_classes_native_A_const_118 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[164]); A_arbace_classes_native_A_const_119 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[165]); A_arbace_classes_native_A_const_120 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[166]); A_arbace_classes_native_A_const_121 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[167]) }

func A_arbace_classes_native_A_clinit_p10() { A_arbace_classes_native_A_const_122 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[168]); A_arbace_classes_native_A_const_123 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[169]); A_arbace_classes_native_A_const_124 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[170]); A_arbace_classes_native_A_const_125 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[171]); A_arbace_classes_native_A_const_126 = A_arbace_classes_native_A_const_pool.A[172]; A_arbace_classes_native_A_const_127 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[173]); A_arbace_classes_native_A_const_128 = A_arbace_classes_native_A_const_pool.A[174] }

func A_arbace_classes_native_A_New() *A_arbace_classes_native_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_A) Ctor() {}

func (t *A_arbace_classes_native_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_A_class }

func (t *A_arbace_classes_native_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_A); return ok }

func A_arbace_classes_native_A_Cast(x any) *A_arbace_classes_native_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_A_class)) }; return v }



type A_arbace_classes_native_compile_and_load_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A struct{ j2g_header uint64; F_s__1078000034, F_iter__1078000033 any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1078000036 any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_deftype_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_fn__1078000067_A struct{ j2g_header uint64; F_form, F_ns any }

var A_arbace_classes_native_compile_deftype_fn__1078000067_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000156_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000156_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000158_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000158_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000160_A struct{ j2g_header uint64; F_form, F_host, F_ns, F_syms, F_cname, F_captured any }

var A_arbace_classes_native_compile_fn_fn__1078000160_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A struct{ j2g_header uint64; F_s__1078000141, F_iter__1078000140 any }

var A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A struct{ j2g_header uint64; F_b__1078000143 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A struct{ j2g_header uint64; F_s__1078000051, F_iter__1078000050 any }

var A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A struct{ j2g_header uint64; F_b__1078000053 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000004_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000004_A_New() *A_arbace_classes_native_eval1078000004_A { t := &A_arbace_classes_native_eval1078000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000004_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000004_A_class }

func (t *A_arbace_classes_native_eval1078000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000004_A); return ok }

func A_arbace_classes_native_eval1078000004_A_Cast(x any) *A_arbace_classes_native_eval1078000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000004_A_class)) }; return v }



type A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000008_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000008_A_New() *A_arbace_classes_native_eval1078000008_A { t := &A_arbace_classes_native_eval1078000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000008_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000008_A_class }

func (t *A_arbace_classes_native_eval1078000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000008_A); return ok }

func A_arbace_classes_native_eval1078000008_A_Cast(x any) *A_arbace_classes_native_eval1078000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000008_A_class)) }; return v }



type A_arbace_classes_native_eval1078000008_fn__1078000009_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class *jrt.Class



type A_arbace_classes_native_field_names_A struct{ j2g_header uint64 }

var A_arbace_classes_native_field_names_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000115_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_fn__1078000115_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000131_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_fn__1078000131_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A struct{ j2g_header uint64; F_s__1078000093, F_iter__1078000092, F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A struct{ j2g_header uint64; F_b__1078000095, F_typed any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A struct{ j2g_header uint64; F_s__1078000121, F_iter__1078000120, F_rcv any }

var A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A struct{ j2g_header uint64; F_rcv any; F_size__1927001038__auto__ int32; F_b__1078000123, F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_typed__1078000090_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_typed__1078000090_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_A struct{ j2g_header uint64 }

var A_arbace_classes_native_form_vars_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A struct{ j2g_header uint64; F_ns any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A struct{ j2g_header uint64; F_ns, F_s__1078000014, F_iter__1078000013 any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A struct{ j2g_header uint64; F_b__1078000016, F_ns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A struct{ j2g_header uint64; F_ns, F_s any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A struct{ j2g_header uint64; F_ns, F_s any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_A struct{ j2g_header uint64 }

var A_arbace_classes_native_local_class_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000072_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000072_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000074_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000074_A_fn_class *jrt.Class



type A_arbace_classes_native_public_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_native_public_class_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_native_symbols_A struct{ j2g_header uint64 }

var A_arbace_classes_native_symbols_A_fn_class *jrt.Class



type A_arbace_classes_native_type_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_type_form_A_fn_class *jrt.Class
