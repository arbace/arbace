//line aot_arbace_classes_native.ae:1
package aot_arbace_classes_native

import (
	"arbace/aot_arbace_classes_lower"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New() *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_native_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_classes_native_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_native_A_const_1, A_arbace_classes_native_A_const_2, A_arbace_classes_native_A_const_3, A_arbace_classes_native_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_native_eval1078000008_fn__1078000009_A_New() *A_arbace_classes_native_eval1078000008_fn__1078000009_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000008_fn__1078000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_7.GetRawRoot__O()); var tmp2 any; var root_12 any = A_arbace_classes_native_A_const_8.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = A_arbace_classes_native_A_const_9; if linked_13 == nil { tmp2 = ifn_14.Invoke_O__O(arg_15) } else { tmp2 = linked_13.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_12, arg_15) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_native_A_const_10.GetRawRoot__O(), A_arbace_classes_native_A_const_11) }



































func A_arbace_classes_native_compile_and_load_BANG__A_New() *A_arbace_classes_native_compile_and_load_BANG__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) DoInvoke_O_O_O_O__O(self, ns__0, forms__1, p__1078000012__2 any) any { var map__1078000013__4 any = p__1078000012__2; var map__1078000013__5 any; if lang.ISeq_InstanceOf(map__1078000013__4) { var tmp1 any; var root_22 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = map__1078000013__4; if linked_23 == nil { tmp1 = ifn_24.Invoke_O__O(arg_25) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_22, arg_25) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_26 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = map__1078000013__4; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_26, arg_29) }; map__1078000013__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_30 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = map__1078000013__4; if linked_31 == nil { tmp3 = ifn_32.Invoke_O__O(arg_33) } else { tmp3 = linked_31.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_30, arg_33) }; if jrt.J2g_Truth(tmp3) { var root_34 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = map__1078000013__4; if linked_35 == nil { map__1078000013__5 = ifn_36.Invoke_O__O(arg_37) } else { map__1078000013__5 = linked_35.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_34, arg_37) } } else { map__1078000013__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000013__5 = map__1078000013__4 }; var siblings__6 any = lang.RT_Get_O_O__O_NoInit(map__1078000013__5, A_arbace_classes_native_A_const_16); var loaded__7 any = lang.IFn_Cast(A_arbace_classes_native_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__1, A_arbace_classes_native_A_const_16, siblings__6); if



	jrt.J2g_Truth(A_arbace_classes_native_A_const_18.GetRawRoot__O()) {
		var root_141 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var arg_145 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var arg_146 any; var tmp4 any = A_arbace_classes_native_A_const_20; var tmp5 any; var root_45 any = A_arbace_classes_native_A_const_21.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_47 lang.IFn
		if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = ns__0; if linked_46 == nil { tmp5 = ifn_47.Invoke_O__O(arg_48) } else { tmp5 = linked_46.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_45, arg_48) }
//line :42:1
		var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_native_A_const_22; var tmp8 any; var root_127 any = A_arbace_classes_native_A_const_23.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_129 lang.IFn

		if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = lang.IFn_Cast(A_arbace_classes_native_A_const_24.GetRawRoot__O()).Invoke__O(); var arg_131 any; var iter__1927001039__auto____8 any; var tmp9 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_New(); var tmp10 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class
		if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class = fncls__122d; tmp10 = fncls__122d } else { tmp10 = fncls__122 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp12 any; var root_123 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_ns_imports_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = ns__0; if linked_124 == nil { tmp12 = ifn_125.Invoke_O__O(arg_126) } else { tmp12 = linked_124.(*aot_arbace_core.A_arbace_core_ns_imports_A).Invoke_O_O__O(root_123, arg_126) }; arg_131 = tmp11.Invoke_O__O(tmp12)
//line :44:1
		if linked_128 == nil { tmp8 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp8 = linked_128.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }
//line :42:1
		var tmp13 any = tmp8; var tmp14 any = A_arbace_classes_native_A_const_36; var tmp15 any; var root_132 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_134 lang.IFn





		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = forms__1; if linked_133 == nil { tmp15 = ifn_134.Invoke_O__O(arg_135) } else { tmp15 = linked_133.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_132, arg_135) }
//line :42:1
		var tmp16 any = tmp15; var tmp17 any = A_arbace_classes_native_A_const_38; var tmp18 any; var root_136 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_138 lang.IFn






		if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var arg_140 any = loaded__7; if linked_137 == nil { tmp18 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { tmp18 = linked_137.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }
//line :42:1
		arg_146 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp13, tmp14, tmp16, tmp17, tmp18)); if linked_142 == nil { ifn_143.Invoke_O_O_O__O(arg_144, arg_145, arg_146) } else { linked_142.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_141, arg_144, arg_145, arg_146) } }; return loaded__7 }


func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_New() *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A) Ctor() {}
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A) Invoke_O_O__O(self, s__1078000016__1 any) any { var tmp1 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_New_O_O(s__1078000016__1, self); var tmp2 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class = fncls__121d; tmp2 = fncls__121d } else { tmp2 = fncls__121 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :45:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A) Ctor_O_O(c__s__1078000016, c__iter__1078000015 any) { t.F_s__1078000016 = c__s__1078000016; t.F_iter__1078000015 = c__iter__1078000015 }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A) Invoke_O__O(self any) any { { var s__1078000016__1 any; var t_ any = t.F_s__1078000016; t.F_s__1078000016 = nil; s__1078000016__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_52 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = s__1078000016__1; if linked_53 == nil { temp__1927000414__auto____2 = ifn_54.Invoke_O__O(arg_55) } else { temp__1927000414__auto____2 = linked_53.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_52, arg_55) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000016__3 any = temp__1927000414__auto____2; var tmp1 any; var root_56 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = s__1078000016__3; if linked_57 == nil { tmp1 = ifn_58.Invoke_O__O(arg_59) } else { tmp1 = linked_57.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_56, arg_59) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_60 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = s__1078000016__3; if linked_61 == nil { c__1927001037__auto____4 = ifn_62.Invoke_O__O(arg_63) } else { c__1927001037__auto____4 = linked_61.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_60, arg_63) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000018__6 any; var root_64 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_65 == nil { b__1078000018__6 = ifn_66.Invoke_O__O(arg_67) } else { b__1078000018__6 = linked_65.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_64, arg_67) }; var tmp2 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_New_O_I_O(b__1078000018__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_86 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_78 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = b__1078000018__6; if linked_79 == nil { arg_89 = ifn_80.Invoke_O__O(arg_81) } else { arg_89 = linked_79.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_78, arg_81) }; var arg_90 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000015); var tmp5 any; var root_82 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = s__1078000016__3; if linked_83 == nil { tmp5 = ifn_84.Invoke_O__O(arg_85) } else { tmp5 = linked_83.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_82, arg_85) }; arg_90 = tmp4.Invoke_O__O(tmp5); if linked_87 == nil { return ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { return linked_87.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_86, arg_89, arg_90) } } else { var root_95 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_91 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = b__1078000018__6; if linked_92 == nil { arg_98 = ifn_93.Invoke_O__O(arg_94) } else { arg_98 = linked_92.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_91, arg_94) }; var arg_99 any; if linked_96 == nil { return ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { return linked_96.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_95, arg_98, arg_99) } } } else { var vec__1078000026__4 any; var root_100 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = s__1078000016__3; if linked_101 == nil { vec__1078000026__4 = ifn_102.Invoke_O__O(arg_103) } else { vec__1078000026__4 = linked_101.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_100, arg_103) }; var sym__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000026__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000026__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_104 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_106 lang.IFn
																	if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__6, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__5))).Ref(); if linked_105 == nil { tmp6 = ifn_106.Invoke_O__O(arg_107) } else { tmp6 = linked_105.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_104, arg_107) }
//line :45:1
	if jrt.J2g_Truth(tmp6) { var root_112 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = lang.Tuple_Create_O_O__IPersistentVector(sym__5, jrt.NN(jrt.Class_Cast(c__6)).GetName__String().Ref()); var arg_116 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000015); var tmp8 any; var root_108 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = s__1078000016__3; if linked_109 == nil { tmp8 = ifn_110.Invoke_O__O(arg_111) } else { tmp8 = linked_109.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_108, arg_111) }; arg_116 = tmp7.Invoke_O__O(tmp8); if linked_113 == nil { return ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { return linked_113.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) } } else { var tmp9 any; var root_117 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = s__1078000016__3; if linked_118 == nil { tmp9 = ifn_119.Invoke_O__O(arg_120) } else { tmp9 = linked_118.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_117, arg_120) }; s__1078000016__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :45:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A) Ctor_O_I_O(c__b__1078000018 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000018 = c__b__1078000018; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A) Invoke_O__O(self any) any { { var i__1078000017__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000022__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000017__1)); var sym__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000022__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000022__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_68 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_70 lang.IFn
																		if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__4, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__3))).Ref(); if linked_69 == nil { tmp2 = ifn_70.Invoke_O__O(arg_71) } else { tmp2 = linked_69.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_68, arg_71) }
//line :45:1
	if jrt.J2g_Truth(tmp2) { var root_72 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = t.F_b__1078000018; var arg_76 any = lang.Tuple_Create_O_O__IPersistentVector(sym__3, jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref()); if linked_73 == nil { ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { linked_73.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_72, arg_75, arg_76) }; i__1078000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000017__1); continue L1 } else { i__1078000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000017__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_native_compile_top_A_New() *A_arbace_classes_native_compile_top_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_native_compile_top_A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_native_compile_top_A) Invoke_O_O_O_O_O__O(self, ns__0, kind__1, forms__2, siblings__3 any) any { var forms__5 any; if






	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_40, kind__1) { forms__5 = lang.Tuple_Create_O__IPersistentVector(forms__2) } else { var root_147 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = forms__2; if linked_148 == nil { forms__5 = ifn_149.Invoke_O__O(arg_150) } else { forms__5 = linked_148.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_147, arg_150) } }; var loaded__6 any = /*line :52:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__5, A_arbace_classes_native_A_const_16, siblings__3); var root_236 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_238 lang.IFn; if






	linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_42.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_44); var tmp3 any; var iter__1927001039__auto____7 any; var tmp4 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_New(); var tmp5 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class; if


	fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class = fncls__216d; tmp5 = fncls__216d } else { tmp5 = fncls__216 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(loaded__6); var tmp6 any = tmp3; var tmp7 lang.IFn = /*line :59:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp8 any; if



	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_40, kind__1) { var root_221 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var root_217 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = loaded__6; if linked_218 == nil { arg_224 = ifn_219.Invoke_O__O(arg_220) } else { arg_224 = linked_218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_217, arg_220) }; if linked_222 == nil { tmp8 = ifn_223.Invoke_O__O(arg_224) } else { tmp8 = linked_222.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_221, arg_224) } } else { var root_225 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var arg_229 any = loaded__6; if linked_226 == nil { tmp8 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { tmp8 = linked_226.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } }; arg_239 = /*line :59:1*/tmp1.Invoke_O_O_O__O(tmp2, tmp6, tmp7.Invoke_O__O(tmp8)); if linked_237 == nil { return ifn_238.Invoke_O__O(arg_239) } else { return linked_237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_236, arg_239) } }


func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_New() *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A) Invoke_O_O__O(self, s__1078000033__1 any) any { var tmp1 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_New_O_O(s__1078000033__1, self); var tmp2 *jrt.Class; var fncls__215 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class; if fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class = fncls__215d; tmp2 = fncls__215d } else { tmp2 = fncls__215 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :62:1
func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A{}; t.Ctor_O_O(p0, p1); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A) Ctor_O_O(c__s__1078000033, c__iter__1078000032 any) { t.F_s__1078000033 = c__s__1078000033; t.F_iter__1078000032 = c__iter__1078000032 }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A) Invoke_O__O(self any) any { { var s__1078000033__1 any; var t_ any = t.F_s__1078000033; t.F_s__1078000033 = nil; s__1078000033__1 = t_; for { var temp__1927000414__auto____2 any; var root_158 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = s__1078000033__1; if linked_159 == nil { temp__1927000414__auto____2 = ifn_160.Invoke_O__O(arg_161) } else { temp__1927000414__auto____2 = linked_159.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_158, arg_161) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000033__3 any = temp__1927000414__auto____2; var tmp1 any; var root_162 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = s__1078000033__3; if linked_163 == nil { tmp1 = ifn_164.Invoke_O__O(arg_165) } else { tmp1 = linked_163.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_166 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = s__1078000033__3; if linked_167 == nil { c__1927001037__auto____4 = ifn_168.Invoke_O__O(arg_169) } else { c__1927001037__auto____4 = linked_167.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_166, arg_169) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000035__6 any; var root_170 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_171 == nil { b__1078000035__6 = ifn_172.Invoke_O__O(arg_173) } else { b__1078000035__6 = linked_171.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_170, arg_173) }; var tmp2 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_New_I_O_O(size__1927001038__auto____5, b__1078000035__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class = fncls__179d; tmp3 = fncls__179d } else { tmp3 = fncls__179 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_188 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var root_180 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = b__1078000035__6; if linked_181 == nil { arg_191 = ifn_182.Invoke_O__O(arg_183) } else { arg_191 = linked_181.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_180, arg_183) }; var arg_192 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000032); var tmp5 any; var root_184 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__1078000033__3; if linked_185 == nil { tmp5 = ifn_186.Invoke_O__O(arg_187) } else { tmp5 = linked_185.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_184, arg_187) }; arg_192 = tmp4.Invoke_O__O(tmp5); if linked_189 == nil { return ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { return linked_189.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_188, arg_191, arg_192) } } else { var root_197 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any; var root_193 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = b__1078000035__6; if linked_194 == nil { arg_200 = ifn_195.Invoke_O__O(arg_196) } else { arg_200 = linked_194.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_193, arg_196) }; var arg_201 any; if linked_198 == nil { return ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { return linked_198.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) } } } else { var vec__1078000043__4 any; var root_202 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = s__1078000033__3; if linked_203 == nil { vec__1078000043__4 = ifn_204.Invoke_O__O(arg_205) } else { vec__1078000043__4 = linked_203.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_202, arg_205) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000043__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_210 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_45, n__5); var arg_214 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1078000032); var tmp7 any; var root_206 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = s__1078000033__3; if linked_207 == nil { tmp7 = ifn_208.Invoke_O__O(arg_209) } else { tmp7 = linked_207.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_206, arg_209) }; arg_214 = tmp6.Invoke_O__O(tmp7); if linked_211 == nil { return ifn_212.Invoke_O_O__O(arg_213, arg_214) } else { return linked_211.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_210, arg_213, arg_214) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :62:1
func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1078000035, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1078000035 = c__b__1078000035; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A) Invoke_O__O(self any) any { { var i__1078000034__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000034__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000039__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000034__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_174 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = t.F_b__1078000035; var arg_178 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_45, n__3); if linked_175 == nil { ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { linked_175.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; i__1078000034__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000034__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_native_compile_deftype_A_New() *A_arbace_classes_native_compile_deftype_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_classes_native_compile_deftype_A) Ctor() {}
//line :68:1
func (t *A_arbace_classes_native_compile_deftype_A) Invoke_O_O_O__O(self, ns__0, form__1 any) any {




	var root_258 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = lang.IFn_Cast(A_arbace_classes_native_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_51, ns__0); if linked_259 == nil { ifn_260.Invoke_O__O(arg_261) } else { linked_259.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_258, arg_261) }; var tmp1 any = A_arbace_classes_native_compile_deftype_fn__1078000049_A_New_O_O(form__1, ns__0); var tmp2 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class = fncls__252d; tmp2 = fncls__252d } else { tmp2 = fncls__252 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :68:1
	return nil
}



func A_arbace_classes_native_compile_deftype_fn__1078000049_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_deftype_fn__1078000049_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_fn__1078000049_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000049_A) Ctor_O_O(c__form, c__ns any) { t.F_form = c__form; t.F_ns = c__ns }
//line :73:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_240 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var t__2 any = t.F_form; t.F_form = nil; arg_243 = t__2; if linked_241 == nil { tmp5 = ifn_242.Invoke_O__O(arg_243) } else { tmp5 = linked_241.(*aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A).Invoke_O_O__O(root_240, arg_243) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :73:1
	return nil }(); var root_249 any = A_arbace_classes_native_A_const_48.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; if linked_250 == nil { ifn_251.Invoke__O() } else { linked_250.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_249) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }






func A_arbace_classes_native_public_class_QMARK__A_New() *A_arbace_classes_native_public_class_QMARK__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_public_class_QMARK__A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Invoke_O_O__O(self, c__0 any) any { { var c__2 any = c__0; L1: for {

	if lang.Util_Identical_O_O__Z_NoInit(c__2, nil) { return jrt.Boolean_TRUE.Ref() } else { var tmp1 any; var root_262 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_264 lang.IFn
		if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__2)).GetModifiers__I())).Ref(); if linked_263 == nil { tmp1 = ifn_264.Invoke_O__O(arg_265) } else { tmp1 = linked_263.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_262, arg_265) }
//line :82:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_native_A_const_52 != nil {

			c__2 = jrt.NN(jrt.Class_Cast(c__2)).GetDeclaringClass__Class().Ref(); continue L1 } else {
//line :82:1
				return nil } } } } }; /*line :80:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_type_form_A_New() *A_arbace_classes_native_type_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_type_form_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_classes_native_type_form_A) Ctor() {}
//line :86:1
func (t *A_arbace_classes_native_type_form_A) Invoke_O_O__O(self, c__0 any) any {


	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var c__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(c__2)).IsArray__Z() { c__2, n__3 = jrt.NN(jrt.Class_Cast(c__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J_NoInit(n__3); continue L1 } else { var root_270 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); var arg_274 any; var root_266 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); if linked_267 == nil { arg_274 = ifn_268.Invoke_O__O(arg_269) } else { arg_274 = linked_267.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_266, arg_269) }; if linked_271 == nil { return ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { return linked_271.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } } } } else {
			var root_275 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); if linked_276 == nil { return ifn_277.Invoke_O__O(arg_278) } else { return linked_276.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_275, arg_278) } }
//line :86:1
	panic("j2g: unreachable")
}






func A_arbace_classes_native_local_class_A_New() *A_arbace_classes_native_local_class_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_classes_native_local_class_A) Ctor() {}
//line :94:1
func (t *A_arbace_classes_native_local_class_A) Invoke_O_O__O(self, lb__0 any) any { var prim__2 any; var tmp1 any = A_arbace_classes_native_local_class_fn__1078000054_A_New_O(lb__0); var tmp2 *jrt.Class; var fncls__279 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000054_A_fn_class; if



	fncls__279 == nil { var fncls__279d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_classes_native_local_class_fn__1078000054_A_fn_class = fncls__279d; tmp2 = fncls__279d } else { tmp2 = fncls__279 }; prim__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var or__1927000174__auto____3 any = prim__2; if
	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var c__4 any; var tmp3 any = A_arbace_classes_native_local_class_fn__1078000056_A_New_O(lb__0); var tmp4 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000056_A_fn_class
		if fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_native_local_class_fn__1078000056_A_fn_class = fncls__280d; tmp4 = fncls__280d } else { tmp4 = fncls__280 }; c__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


		var tmp5 any; var and__1927000168__auto____5 bool = jrt.Class_InstanceOf(c__4); if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_281 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__4)).IsPrimitive__Z()).Ref(); if linked_282 == nil { and__1927000168__auto____6 = ifn_283.Invoke_O__O(arg_284) } else { and__1927000168__auto____6 = linked_282.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_281, arg_284) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_285 any = A_arbace_classes_native_A_const_55.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, A_arbace_classes_native_public_class_QMARK__A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = c__4; if linked_286 == nil { and__1927000168__auto____7 = ifn_287.Invoke_O__O(arg_288) } else { and__1927000168__auto____7 = linked_286.(*A_arbace_classes_native_public_class_QMARK__A).Invoke_O_O__O(root_285, arg_288) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
			var root_294 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any; var root_289 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref(); var arg_293 any = Lit_32; if linked_290 == nil { arg_297 = ifn_291.Invoke_O_O__O(arg_292, arg_293) } else { arg_297 = linked_290.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_289, arg_292, arg_293) }; if linked_295 == nil { tmp5 = ifn_296.Invoke_O__O(arg_297) } else { tmp5 = linked_295.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_294, arg_297) } } else {
//line :103:1
				tmp5 = and__1927000168__auto____7 } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp5) { return c__4 } else { return A_arbace_classes_native_A_const_57 } } }
//line :98:1
func A_arbace_classes_native_local_class_fn__1078000054_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000054_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000054_A{}; t.Ctor_O(p0); return t }
//line :98:1
func (t *A_arbace_classes_native_local_class_fn__1078000054_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :98:1
func (t *A_arbace_classes_native_local_class_fn__1078000054_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetPrimitiveType__Class().Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_classes_native_local_class_fn__1078000056_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000056_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000056_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_classes_native_local_class_fn__1078000056_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :100:1
func (t *A_arbace_classes_native_local_class_fn__1078000056_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); if jrt.NN(lang.Compiler_LocalBinding_Cast(t.F_lb)).HasJavaClass__Z() {
												var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetJavaClass__Class().Ref() } else {
//line :100:1
		tmp1 = nil }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_classes_native_field_names_A_New() *A_arbace_classes_native_field_names_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_field_names_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_classes_native_field_names_A) Ctor() {}
//line :108:1
func (t *A_arbace_classes_native_field_names_A) Invoke_O_O__O(self, syms__0 any) any { { var G__1078000062__2_ any = syms__0; var vec__1078000063__3 any = G__1078000062__2_; var seq__1078000064__4 any; var root_298 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_300 lang.IFn


	if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = vec__1078000063__3; if linked_299 == nil { seq__1078000064__4 = ifn_300.Invoke_O__O(arg_301) } else { seq__1078000064__4 = linked_299.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_298, arg_301) }
//line :108:1
	var first__1078000065__5 any; var root_302 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_304 lang.IFn


	if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = seq__1078000064__4; if linked_303 == nil { first__1078000065__5 = ifn_304.Invoke_O__O(arg_305) } else { first__1078000065__5 = linked_303.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_302, arg_305) }
//line :108:1
	var seq__1078000064__6 any; var root_306 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_308 lang.IFn


	if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = seq__1078000064__4; if linked_307 == nil { seq__1078000064__6 = ifn_308.Invoke_O__O(arg_309) } else { seq__1078000064__6 = linked_307.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_306, arg_309) }
//line :108:1
	var s__7 any = first__1078000065__5; var more__8 any = seq__1078000064__6; var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); var out__10 any = lang.PersistentVector_EMPTY.Ref(); var G__1078000062__11_ any = G__1078000062__2_; var seen__12 any = seen__9; var out__13 any = out__10; _ = s__7; _ = more__8; L1: for { var vec__1078000066__14 any = G__1078000062__11_; var seq__1078000067__15 any; var root_310 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_312 lang.IFn


		if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = vec__1078000066__14; if linked_311 == nil { seq__1078000067__15 = ifn_312.Invoke_O__O(arg_313) } else { seq__1078000067__15 = linked_311.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_310, arg_313) }
//line :108:1
		var first__1078000068__16 any; var root_314 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_316 lang.IFn


		if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = seq__1078000067__15; if linked_315 == nil { first__1078000068__16 = ifn_316.Invoke_O__O(arg_317) } else { first__1078000068__16 = linked_315.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_314, arg_317) }
//line :108:1
		var seq__1078000067__17 any; var root_318 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_320 lang.IFn


		if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = seq__1078000067__15; if linked_319 == nil { seq__1078000067__17 = ifn_320.Invoke_O__O(arg_321) } else { seq__1078000067__17 = linked_319.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_318, arg_321) }
//line :108:1
		var s__18 any = first__1078000068__16; var more__19 any = seq__1078000067__17; var seen__20 any = seen__12; var out__21 any = out__13; var tmp1 any; var root_322 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_324 lang.IFn



		if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = s__18; if linked_323 == nil { tmp1 = ifn_324.Invoke_O__O(arg_325) } else { tmp1 = linked_323.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_322, arg_325) }; if jrt.J2g_Truth(tmp1) { return out__21 } else { var base__22 any; var root_330 any = A_arbace_classes_native_A_const_58.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_332 lang.IFn

			if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any; var root_326 any = A_arbace_classes_native_A_const_59.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = s__18; if linked_327 == nil { arg_333 = ifn_328.Invoke_O__O(arg_329) } else { arg_333 = linked_327.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_326, arg_329) }; if linked_331 == nil { base__22 = ifn_332.Invoke_O__O(arg_333) } else { base__22 = linked_331.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_330, arg_333) }
//line :112:1
			var n__23 any


			if jrt.J2g_Truth(lang.IFn_Cast(seen__20).Invoke_O__O(base__22)) { n__23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, base__22, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(out__21)).Ref())).Ref() } else { n__23 = base__22 }
			var tmp2 any; var root_334 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = seen__20; var arg_338 any = n__23; if linked_335 == nil { tmp2 = ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { tmp2 = linked_335.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) }; var tmp3 any = tmp2; var tmp4 any; var root_339 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = out__21; var arg_343 any = n__23; if linked_340 == nil { tmp4 = ifn_341.Invoke_O_O__O(arg_342, arg_343) } else { tmp4 = linked_340.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_339, arg_342, arg_343) }; G__1078000062__11_, seen__12, out__13 = more__19, tmp3, tmp4; continue L1 } } }; /*line :108:1*/panic("j2g: unreachable") }









func A_arbace_classes_native_fn_class_form_A_New() *A_arbace_classes_native_fn_class_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_native_fn_class_form_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_native_fn_class_form_A) Invoke_O_O_O_O__O(self, cname__0, form__1, captured__2 any) any { var map__1078000070__4 any; var root_344 any = A_arbace_classes_native_A_const_60.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A_fn_class); var ifn_346 lang.IFn; if



	linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = form__1; if linked_345 == nil { map__1078000070__4 = ifn_346.Invoke_O__O(arg_347) } else { map__1078000070__4 = linked_345.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A).Invoke_O_O__O(root_344, arg_347) }; var map__1078000070__5 any; if lang.ISeq_InstanceOf(map__1078000070__4) { var tmp1 any; var root_348 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = map__1078000070__4; if linked_349 == nil { tmp1 = ifn_350.Invoke_O__O(arg_351) } else { tmp1 = linked_349.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_348, arg_351) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_352 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = map__1078000070__4; if linked_353 == nil { tmp2 = ifn_354.Invoke_O__O(arg_355) } else { tmp2 = linked_353.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_352, arg_355) }; map__1078000070__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_356 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = map__1078000070__4; if linked_357 == nil { tmp3 = ifn_358.Invoke_O__O(arg_359) } else { tmp3 = linked_357.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(tmp3) { var root_360 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = map__1078000070__4; if linked_361 == nil { map__1078000070__5 = ifn_362.Invoke_O__O(arg_363) } else { map__1078000070__5 = linked_361.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_360, arg_363) } } else { map__1078000070__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000070__5 = map__1078000070__4 }; var nm__6 any = /*line :118:1*/lang.RT_Get_O_O__O_NoInit(map__1078000070__5, A_arbace_classes_native_A_const_61); var arities__7 any = lang.RT_Get_O_O__O_NoInit(map__1078000070__5, A_arbace_classes_native_A_const_62); var i__8 int32 = jrt.NN(jrt.String_Cast(cname__0)).LastIndexOf_String__I(Lit_17); var pkg__9 any; if





	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__8)) { pkg__9 = Lit_18 } else { var root_364 any = A_arbace_classes_native_A_const_63.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = cname__0; var arg_368 any = A_arbace_classes_native_A_const_64; var arg_369 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__8).Ref(); if linked_365 == nil { pkg__9 = ifn_366.Invoke_O_O_O__O(arg_367, arg_368, arg_369) } else { pkg__9 = linked_365.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_364, arg_367, arg_368, arg_369) } }; var simple__10 any; var root_370 any = /*line :118:1*/A_arbace_classes_native_A_const_63.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_372 lang.IFn; if






	linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = cname__0; var arg_374 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__8))).Ref(); if linked_371 == nil { simple__10 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { simple__10 = linked_371.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; var rcv__11 any; var root_375 any = /*line :118:1*/A_arbace_classes_native_A_const_65.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_377 lang.IFn; if







	linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = Lit_19; if linked_376 == nil { rcv__11 = ifn_377.Invoke_O__O(arg_378) } else { rcv__11 = linked_376.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_375, arg_378) }; var fields__12 any; var root_384 any = /*line :118:1*/A_arbace_classes_native_A_const_66.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_classes_native_field_names_A_fn_class); var ifn_386 lang.IFn; if








	linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any; var root_379 any = A_arbace_classes_native_A_const_67.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var arg_383 any = captured__2; if linked_380 == nil { arg_387 = ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { arg_387 = linked_380.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) }; if linked_385 == nil { fields__12 = ifn_386.Invoke_O__O(arg_387) } else { fields__12 = linked_385.(*A_arbace_classes_native_field_names_A).Invoke_O_O__O(root_384, arg_387) }; var super__13 any; var tmp4 any; var root_388 any = /*line :118:1*/A_arbace_classes_native_A_const_68.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_390 lang.IFn; if









	linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var arg_392 any = arities__7; if linked_389 == nil { tmp4 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { tmp4 = linked_389.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }; if jrt.J2g_Truth(tmp4) { super__13 = A_arbace_classes_native_A_const_70 } else { super__13 = A_arbace_classes_native_A_const_71 }; var typed__14 any; var tmp5 any = /*line :118:1*/A_arbace_classes_native_fn_class_form_typed__1078000072_A_New(); var tmp6 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class; if










	fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class = fncls__402d; tmp6 = fncls__402d } else { tmp6 = fncls__402 }; typed__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_classes_native_A_const_42.GetRawRoot__O()); var tmp8 any; var root_407 any = A_arbace_classes_native_A_const_72.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_409 lang.IFn; if
	linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var root_403 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = simple__10; if linked_404 == nil { arg_410 = ifn_405.Invoke_O__O(arg_406) } else { arg_410 = linked_404.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_403, arg_406) }; var arg_411 any = A_arbace_classes_native_A_const_75; if linked_408 == nil { tmp8 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { tmp8 = linked_408.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) }; var tmp9 any = tmp8; var tmp10 any = A_arbace_classes_native_A_const_76; var tmp11 any = A_arbace_classes_native_A_const_77; var tmp12 any = A_arbace_classes_native_A_const_78; var tmp13 any; var root_412 any = /*line :130:1*/A_arbace_classes_native_A_const_79.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A_fn_class); var ifn_414 lang.IFn; if



	linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = arities__7; if linked_413 == nil { tmp13 = ifn_414.Invoke_O__O(arg_415) } else { tmp13 = linked_413.(*aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A).Invoke_O_O__O(root_412, arg_415) }; var tmp14 any = /*line :130:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, pkg__9, tmp11, super__13, tmp12, tmp13)); var tmp15 any; var iter__1927001039__auto____15 any; var tmp16 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_New_O(typed__14); var tmp17 *jrt.Class; var fncls__496 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class; if




	fncls__496 == nil { var fncls__496d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class = fncls__496d; tmp17 = fncls__496d } else { tmp17 = fncls__496 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var tmp18 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp19 any; var root_497 any = A_arbace_classes_native_A_const_67.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = A_arbace_classes_native_A_const_84.GetRawRoot__O(); var arg_501 any = fields__12; var arg_502 any = captured__2; if linked_498 == nil { tmp19 = ifn_499.Invoke_O_O_O__O(arg_500, arg_501, arg_502) } else { tmp19 = linked_498.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_497, arg_500, arg_501, arg_502) }; tmp15 = tmp18.Invoke_O__O(tmp19); var tmp20 any = tmp15; var tmp21 any; var root_603 any = /*line :130:1*/A_arbace_classes_native_A_const_85.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_605 lang.IFn; if






	linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = A_arbace_classes_native_A_const_86; var arg_607 any; var root_523 any = A_arbace_classes_native_A_const_72.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_519 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var root_514 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = rcv__11; var arg_518 any; var root_508 any = A_arbace_classes_native_A_const_67.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any; var tmp22 any = A_arbace_classes_native_fn_class_form_fn__1078000097_A_New_O(typed__14); var tmp23 *jrt.Class; var fncls__507 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class; if fncls__507 == nil { var fncls__507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class = fncls__507d; tmp23 = fncls__507d } else { tmp23 = fncls__507 }; arg_511 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_512 any = fields__12; var arg_513 any = captured__2; if linked_509 == nil { arg_518 = ifn_510.Invoke_O_O_O__O(arg_511, arg_512, arg_513) } else { arg_518 = linked_509.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_508, arg_511, arg_512, arg_513) }; if linked_515 == nil { arg_522 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { arg_522 = linked_515.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }; if linked_520 == nil { arg_526 = ifn_521.Invoke_O__O(arg_522) } else { arg_526 = linked_520.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_519, arg_522) }; var arg_527 any = A_arbace_classes_native_A_const_87; if linked_524 == nil { arg_607 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { arg_607 = linked_524.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; var arg_608 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_88); var arg_609 any; var iter__1927001039__auto____15_2 any; var tmp24 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_New_O(rcv__11); var tmp25 *jrt.Class; var fncls__602 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class; if


	fncls__602 == nil { var fncls__602d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class = fncls__602d; tmp25 = fncls__602d } else { tmp25 = fncls__602 }; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); arg_609 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(fields__12); if /*line :137:1*/ linked_604 == nil { tmp21 = ifn_605.Invoke_O_O_O_O__O(arg_606, arg_607, arg_608, arg_609) } else { tmp21 = linked_604.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_603, arg_606, arg_607, arg_608, arg_609) }; var tmp26 any = /*line :130:1*/lang.Tuple_Create_O__IPersistentVector(tmp21); var tmp27 any; var root_625 any = A_arbace_classes_native_A_const_90.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A_fn_class); var ifn_627 lang.IFn; if










	linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = rcv__11; var arg_629 any = nm__6; var arg_630 any = arities__7; var arg_631 any; var root_621 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_623 lang.IFn; if
	linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_91.GetRawRoot__O()); var tmp29 any = A_arbace_classes_native_fn_class_form_fn__1078000113_A_New_O(rcv__11); var tmp30 *jrt.Class; var fncls__614 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class; if fncls__614 == nil { var fncls__614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class = fncls__614d; tmp30 = fncls__614d } else { tmp30 = fncls__614 }; arg_624 = tmp28.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), fields__12, captured__2); if linked_622 == nil { arg_631 = ifn_623.Invoke_O__O(arg_624) } else { arg_631 = linked_622.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_621, arg_624) }; if /*line :141:1*/ linked_626 == nil { tmp27 = ifn_627.Invoke_O_O_O_O__O(arg_628, arg_629, arg_630, arg_631) } else { tmp27 = linked_626.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A).Invoke_O_O_O_O_O__O(root_625, arg_628, arg_629, arg_630, arg_631) }; return /*line :130:1*/ tmp7.Invoke_O_O_O_O__O(tmp14, tmp20, tmp26, tmp27) }
//line :129:1
func A_arbace_classes_native_fn_class_form_typed__1078000072_A_New() *A_arbace_classes_native_fn_class_form_typed__1078000072_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_typed__1078000072_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000072_A) Ctor() {}
//line :129:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000072_A) Invoke_O_O_O__O(self, s__1, c__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__2, A_arbace_classes_native_A_const_57) { return s__1 } else { var root_397 any = A_arbace_classes_native_A_const_72.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = s__1; var arg_401 any; var tmp1 any = A_arbace_classes_native_A_const_73; var tmp2 any; var root_393 any = A_arbace_classes_native_A_const_74.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_classes_native_type_form_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = c__2; if linked_394 == nil { tmp2 = ifn_395.Invoke_O__O(arg_396) } else { tmp2 = linked_394.(*A_arbace_classes_native_type_form_A).Invoke_O_O__O(root_393, arg_396) }; arg_401 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2)); if linked_398 == nil { return ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { return linked_398.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) } } }





func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A) Invoke_O_O__O(self, s__1078000075__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_New_O_O_O(s__1078000075__1, self, t.F_typed); var tmp2 *jrt.Class; var fncls__495 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class; if fncls__495 == nil { var fncls__495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class = fncls__495d; tmp2 = fncls__495d } else { tmp2 = fncls__495 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :135:1
func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A) Ctor_O_O_O(c__s__1078000075, c__iter__1078000074, c__typed any) { t.F_s__1078000075 = c__s__1078000075; t.F_iter__1078000074 = c__iter__1078000074; t.F_typed = c__typed }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A) Invoke_O__O(self any) any { { var s__1078000075__1 any; var t_ any = t.F_s__1078000075; t.F_s__1078000075 = nil; s__1078000075__1 = t_; for { var temp__1927000414__auto____2 any; var root_416 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = s__1078000075__1; if linked_417 == nil { temp__1927000414__auto____2 = ifn_418.Invoke_O__O(arg_419) } else { temp__1927000414__auto____2 = linked_417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_416, arg_419) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000075__3 any = temp__1927000414__auto____2; var tmp1 any; var root_420 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = s__1078000075__3; if linked_421 == nil { tmp1 = ifn_422.Invoke_O__O(arg_423) } else { tmp1 = linked_421.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_420, arg_423) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_424 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = s__1078000075__3; if linked_425 == nil { c__1927001037__auto____4 = ifn_426.Invoke_O__O(arg_427) } else { c__1927001037__auto____4 = linked_425.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_424, arg_427) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000077__6 any; var root_428 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_429 == nil { b__1078000077__6 = ifn_430.Invoke_O__O(arg_431) } else { b__1078000077__6 = linked_429.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_428, arg_431) }; var tmp2 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_New_O_O_I_O(b__1078000077__6, t.F_typed, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__448 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class; if fncls__448 == nil { var fncls__448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class = fncls__448d; tmp3 = fncls__448d } else { tmp3 = fncls__448 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_457 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var root_449 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = b__1078000077__6; if linked_450 == nil { arg_460 = ifn_451.Invoke_O__O(arg_452) } else { arg_460 = linked_450.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_449, arg_452) }; var arg_461 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000074); var tmp5 any; var root_453 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = s__1078000075__3; if linked_454 == nil { tmp5 = ifn_455.Invoke_O__O(arg_456) } else { tmp5 = linked_454.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_453, arg_456) }; arg_461 = tmp4.Invoke_O__O(tmp5); if linked_458 == nil { return ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { return linked_458.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) } } else { var root_466 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any; var root_462 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = b__1078000077__6; if linked_463 == nil { arg_469 = ifn_464.Invoke_O__O(arg_465) } else { arg_469 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_462, arg_465) }; var arg_470 any; if linked_467 == nil { return ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { return linked_467.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) } } } else { var vec__1078000088__4 any; var root_471 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = s__1078000075__3; if linked_472 == nil { vec__1078000088__4 = ifn_473.Invoke_O__O(arg_474) } else { vec__1078000088__4 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000088__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000091__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000088__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000091__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000091__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_490 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_492 lang.IFn; _ = ___7; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_80; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_81.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp10 any; var root_475 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_477 lang.IFn
															if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = f__5; if linked_476 == nil { tmp10 = ifn_477.Invoke_O__O(arg_478) } else { tmp10 = linked_476.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_475, arg_478) }; arg_493 = tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O_O__O(tmp9.Invoke_O_O__O(tmp10, c__8), A_arbace_classes_native_A_const_82.GetRawRoot__O(), A_arbace_classes_native_A_const_83, jrt.Boolean_TRUE.Ref()))
//line :135:1
	var arg_494 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000074); var tmp12 any; var root_486 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = s__1078000075__3; if linked_487 == nil { tmp12 = ifn_488.Invoke_O__O(arg_489) } else { tmp12 = linked_487.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_486, arg_489) }; arg_494 = tmp11.Invoke_O__O(tmp12); if linked_491 == nil { return ifn_492.Invoke_O_O__O(arg_493, arg_494) } else { return linked_491.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_490, arg_493, arg_494) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :135:1
func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A) Ctor_O_O_I_O(c__b__1078000077, c__typed any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000077 = c__b__1078000077; t.F_typed = c__typed; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A) Invoke_O__O(self any) any { { var i__1078000076__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000076__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000081__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000076__1)); var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000081__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000084__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000081__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000084__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000084__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_443 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_445 lang.IFn; _ = ___5; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = t.F_b__1078000077; var arg_447 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_80; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_81.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp6 any; var root_432 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_434 lang.IFn
																	if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = f__3; if linked_433 == nil { tmp6 = ifn_434.Invoke_O__O(arg_435) } else { tmp6 = linked_433.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_432, arg_435) }; arg_447 = tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5.Invoke_O_O__O(tmp6, c__6), A_arbace_classes_native_A_const_82.GetRawRoot__O(), A_arbace_classes_native_A_const_83, jrt.Boolean_TRUE.Ref()))
//line :135:1
	if linked_444 == nil { ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { linked_444.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; i__1078000076__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000076__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000097_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000097_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000097_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000097_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :137:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000097_A) Invoke_O_O_O__O(self, f__1, p__1078000096__2 any) any { var vec__1078000098__3 any = p__1078000096__2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000098__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000098__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp2 any; var root_503 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_505 lang.IFn; _ = ___4; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = f__1; if linked_504 == nil { tmp2 = ifn_505.Invoke_O__O(arg_506) } else { tmp2 = linked_504.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_503, arg_506) }; return tmp1.Invoke_O_O__O(tmp2, c__5) }


func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A{}; t.Ctor_O(p0); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A) Invoke_O_O__O(self, s__1078000103__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_New_O_O_O(s__1078000103__1, t.F_rcv, self); var tmp2 *jrt.Class; var fncls__601 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class; if fncls__601 == nil { var fncls__601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class = fncls__601d; tmp2 = fncls__601d } else { tmp2 = fncls__601 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :140:1
func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A) Ctor_O_O_O(c__s__1078000103, c__rcv, c__iter__1078000102 any) { t.F_s__1078000103 = c__s__1078000103; t.F_rcv = c__rcv; t.F_iter__1078000102 = c__iter__1078000102 }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A) Invoke_O__O(self any) any { { var s__1078000103__1 any; var t_ any = t.F_s__1078000103; t.F_s__1078000103 = nil; s__1078000103__1 = t_; for { var temp__1927000414__auto____2 any; var root_528 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = s__1078000103__1; if linked_529 == nil { temp__1927000414__auto____2 = ifn_530.Invoke_O__O(arg_531) } else { temp__1927000414__auto____2 = linked_529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_528, arg_531) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000103__3 any = temp__1927000414__auto____2; var tmp1 any; var root_532 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = s__1078000103__3; if linked_533 == nil { tmp1 = ifn_534.Invoke_O__O(arg_535) } else { tmp1 = linked_533.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_532, arg_535) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_536 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = s__1078000103__3; if linked_537 == nil { c__1927001037__auto____4 = ifn_538.Invoke_O__O(arg_539) } else { c__1927001037__auto____4 = linked_537.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_536, arg_539) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000105__6 any; var root_540 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_541 == nil { b__1078000105__6 = ifn_542.Invoke_O__O(arg_543) } else { b__1078000105__6 = linked_541.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_540, arg_543) }; var tmp2 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_O_I_O(b__1078000105__6, t.F_rcv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__557 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class; if fncls__557 == nil { var fncls__557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class = fncls__557d; tmp3 = fncls__557d } else { tmp3 = fncls__557 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_566 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var root_558 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = b__1078000105__6; if linked_559 == nil { arg_569 = ifn_560.Invoke_O__O(arg_561) } else { arg_569 = linked_559.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_558, arg_561) }; var arg_570 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); var tmp5 any; var root_562 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = s__1078000103__3; if linked_563 == nil { tmp5 = ifn_564.Invoke_O__O(arg_565) } else { tmp5 = linked_563.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_562, arg_565) }; arg_570 = tmp4.Invoke_O__O(tmp5); if linked_567 == nil { return ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { return linked_567.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) } } else { var root_575 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var root_571 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = b__1078000105__6; if linked_572 == nil { arg_578 = ifn_573.Invoke_O__O(arg_574) } else { arg_578 = linked_572.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_571, arg_574) }; var arg_579 any; if linked_576 == nil { return ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { return linked_576.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) } } } else { var f__4 any; var root_580 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = s__1078000103__3; if linked_581 == nil { f__4 = ifn_582.Invoke_O__O(arg_583) } else { f__4 = linked_581.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_580, arg_583) }; var root_596 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_89; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp9 any; var root_588 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref(); if linked_589 == nil { tmp9 = ifn_590.Invoke_O__O(arg_591) } else { tmp9 = linked_589.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_588, arg_591) }; var tmp10 any = tmp8.Invoke_O_O__O(tmp9, t.F_rcv); var tmp11 any; var root_584 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = f__4; if linked_585 == nil { tmp11 = ifn_586.Invoke_O__O(arg_587) } else { tmp11 = linked_585.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_584, arg_587) }; arg_599 = tmp6.Invoke_O_O_O__O(tmp7, tmp10, tmp11); var arg_600 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); var tmp13 any; var root_592 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = s__1078000103__3; if linked_593 == nil { tmp13 = ifn_594.Invoke_O__O(arg_595) } else { tmp13 = linked_593.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_592, arg_595) }; arg_600 = tmp12.Invoke_O__O(tmp13); if linked_597 == nil { return ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { return linked_597.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :140:1
func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Ctor_O_O_I_O(c__b__1078000105, c__rcv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000105 = c__b__1078000105; t.F_rcv = c__rcv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Invoke_O__O(self any) any { { var i__1078000104__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000104__1)); var root_552 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = t.F_b__1078000105; var arg_556 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_89; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp5 any; var root_548 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref(); if linked_549 == nil { tmp5 = ifn_550.Invoke_O__O(arg_551) } else { tmp5 = linked_549.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_548, arg_551) }; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, t.F_rcv); var tmp7 any; var root_544 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = f__2; if linked_545 == nil { tmp7 = ifn_546.Invoke_O__O(arg_547) } else { tmp7 = linked_545.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_544, arg_547) }; arg_556 = tmp2.Invoke_O_O_O__O(tmp3, tmp6, tmp7); if linked_553 == nil { ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { linked_553.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) }; i__1078000104__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000104__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000113_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000113_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000113_A{}; t.Ctor_O(p0); return t }
//line :142:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000113_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :142:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000113_A) Invoke_O_O_O__O(self, f__1, p__1078000112__2 any) any { var vec__1078000114__3 any = p__1078000112__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000114__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000114__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp2 any; var root_610 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_612 lang.IFn; _ = ___5; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref(); if linked_611 == nil { tmp2 = ifn_612.Invoke_O__O(arg_613) } else { tmp2 = linked_611.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_610, arg_613) }; return lang.Tuple_Create_O_O__IPersistentVector(s__4, tmp1.Invoke_O_O__O(tmp2, t.F_rcv)) }

func A_arbace_classes_native_compile_fn_A_New() *A_arbace_classes_native_compile_fn_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_classes_native_compile_fn_A) Ctor() {}
//line :144:1
func (t *A_arbace_classes_native_compile_fn_A) Invoke_O_O_O_O_O__O(self, ns__0, cname__1, form__2, env__3 any) any { { var host__5 any; var root_706 any = A_arbace_classes_native_A_const_23.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_708 lang.IFn





	if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_710 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_New(); var tmp2 *jrt.Class; var fncls__705 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class; if fncls__705 == nil { var fncls__705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class = fncls__705d; tmp2 = fncls__705d } else { tmp2 = fncls__705 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_710 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(env__3); if linked_707 == nil { host__5 = ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { host__5 = linked_707.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) }
//line :144:1
	var mentioned__6 any; var root_711 any = A_arbace_classes_native_A_const_93.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A_fn_class); var ifn_713 lang.IFn






	if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = form__2; if linked_712 == nil { mentioned__6 = ifn_713.Invoke_O__O(arg_714) } else { mentioned__6 = linked_712.(*aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A).Invoke_O_O__O(root_711, arg_714) }
//line :144:1
	var syms__7 any; var root_726 any = A_arbace_classes_native_A_const_94.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_728 lang.IFn







	if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any; var tmp3 any = A_arbace_classes_native_compile_fn_fn__1078000138_A_New_O(host__5); var tmp4 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class = fncls__720d; tmp4 = fncls__720d } else { tmp4 = fncls__720 }; arg_729 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_730 any; var root_721 any = A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var arg_725 any = mentioned__6; if linked_722 == nil { arg_730 = ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { arg_730 = linked_722.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) }; if linked_727 == nil { syms__7 = ifn_728.Invoke_O_O__O(arg_729, arg_730) } else { syms__7 = linked_727.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_726, arg_729, arg_730) }
//line :144:1
L1: for { var captured__8 any; var root_732 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_734 lang.IFn








	if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any; var tmp5 any = A_arbace_classes_native_compile_fn_fn__1078000140_A_New_O(host__5); var tmp6 *jrt.Class; var fncls__731 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class; if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class = fncls__731d; tmp6 = fncls__731d } else { tmp6 = fncls__731 }; arg_735 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_736 any = syms__7; if linked_733 == nil { captured__8 = ifn_734.Invoke_O_O__O(arg_735, arg_736) } else { captured__8 = linked_733.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_732, arg_735, arg_736) }
//line :144:1
	var r__9 any; var tmp7 any = A_arbace_classes_native_compile_fn_fn__1078000142_A_New_O_O_O_O_O_O(form__2, host__5, ns__0, syms__7, cname__1, captured__8); var tmp8 *jrt.Class
	var fncls__795 /*line :144:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class









	if fncls__795 == nil { var fncls__795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class = fncls__795d; tmp8 = fncls__795d } else { tmp8 = fncls__795 }; r__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()









	var tmp9 any = A_arbace_classes_native_A_const_103; var tmp10 any; var root_796 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = r__9; if linked_797 == nil { tmp10 = ifn_798.Invoke_O__O(arg_799) } else { tmp10 = linked_797.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_796, arg_799) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10) {
		var tmp11 any; var root_822 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = syms__7; var arg_826 any; var root_818 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = r__9; if linked_819 == nil { arg_826 = ifn_820.Invoke_O__O(arg_821) } else { arg_826 = linked_819.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_818, arg_821) }; if linked_823 == nil { tmp11 = ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { tmp11 = linked_823.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_822, arg_825, arg_826) }; syms__7 = tmp11; continue L1 } else {
//line :164:1
			var new__10 any; var root_808 any = A_arbace_classes_native_A_const_85.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_810 lang.IFn


			if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = A_arbace_classes_native_A_const_104; var arg_812 any; var root_804 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any; var root_800 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = r__9; if linked_801 == nil { arg_807 = ifn_802.Invoke_O__O(arg_803) } else { arg_807 = linked_801.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_800, arg_803) }; if linked_805 == nil { arg_812 = ifn_806.Invoke_O__O(arg_807) } else { arg_812 = linked_805.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_804, arg_807) }; var arg_813 any = syms__7; if linked_809 == nil { new__10 = ifn_810.Invoke_O_O_O__O(arg_811, arg_812, arg_813) } else { new__10 = linked_809.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_808, arg_811, arg_812, arg_813) }
//line :164:1
			var temp__1927000408__auto____11 any; var root_814 any = A_arbace_classes_native_A_const_105.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A_fn_class); var ifn_816 lang.IFn



			if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = form__2; if linked_815 == nil { temp__1927000408__auto____11 = ifn_816.Invoke_O__O(arg_817) } else { temp__1927000408__auto____11 = linked_815.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A).Invoke_O_O__O(root_814, arg_817) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11
				return lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_classes_native_A_const_106, new__10, m__12) } else {
//line :168:1
					return new__10 } } } }; /*line :144:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_New() *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A) Ctor() {}
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A) Invoke_O_O__O(self, s__1078000123__1 any) any { var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_New_O_O(s__1078000123__1, self); var tmp2 *jrt.Class; var fncls__704 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class; if fncls__704 == nil { var fncls__704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class = fncls__704d; tmp2 = fncls__704d } else { tmp2 = fncls__704 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A) Ctor_O_O(c__s__1078000123, c__iter__1078000122 any) { t.F_s__1078000123 = c__s__1078000123; t.F_iter__1078000122 = c__iter__1078000122 }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A) Invoke_O__O(self any) any { { var s__1078000123__1 any; var t_ any = t.F_s__1078000123; t.F_s__1078000123 = nil; s__1078000123__1 = t_; for { var temp__1927000414__auto____2 any; var root_639 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = s__1078000123__1; if linked_640 == nil { temp__1927000414__auto____2 = ifn_641.Invoke_O__O(arg_642) } else { temp__1927000414__auto____2 = linked_640.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_643 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = s__1078000123__3; if linked_644 == nil { tmp1 = ifn_645.Invoke_O__O(arg_646) } else { tmp1 = linked_644.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_643, arg_646) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_647 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = s__1078000123__3; if linked_648 == nil { c__1927001037__auto____4 = ifn_649.Invoke_O__O(arg_650) } else { c__1927001037__auto____4 = linked_648.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_647, arg_650) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000125__6 any; var root_651 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_652 == nil { b__1078000125__6 = ifn_653.Invoke_O__O(arg_654) } else { b__1078000125__6 = linked_652.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_651, arg_654) }; var tmp2 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_New_O_I_O(b__1078000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class = fncls__664d; tmp3 = fncls__664d } else { tmp3 = fncls__664 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_673 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any; var root_665 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = b__1078000125__6; if linked_666 == nil { arg_676 = ifn_667.Invoke_O__O(arg_668) } else { arg_676 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_665, arg_668) }; var arg_677 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000122); var tmp5 any; var root_669 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = s__1078000123__3; if linked_670 == nil { tmp5 = ifn_671.Invoke_O__O(arg_672) } else { tmp5 = linked_670.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_669, arg_672) }; arg_677 = tmp4.Invoke_O__O(tmp5); if linked_674 == nil { return ifn_675.Invoke_O_O__O(arg_676, arg_677) } else { return linked_674.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_673, arg_676, arg_677) } } else { var root_682 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any; var root_678 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = b__1078000125__6; if linked_679 == nil { arg_685 = ifn_680.Invoke_O__O(arg_681) } else { arg_685 = linked_679.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_678, arg_681) }; var arg_686 any; if linked_683 == nil { return ifn_684.Invoke_O_O__O(arg_685, arg_686) } else { return linked_683.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_682, arg_685, arg_686) } } } else { var vec__1078000133__4 any; var root_687 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = s__1078000123__3; if linked_688 == nil { vec__1078000133__4 = ifn_689.Invoke_O__O(arg_690) } else { vec__1078000133__4 = linked_688.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_687, arg_690) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000133__4, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000133__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_699 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var tmp6 any; var root_691 any = A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, A_arbace_classes_native_local_class_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = lb__6; if linked_692 == nil { tmp6 = ifn_693.Invoke_O__O(arg_694) } else { tmp6 = linked_692.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_691, arg_694) }; arg_702 = lang.Tuple_Create_O_O__IPersistentVector(s__5, tmp6); var arg_703 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000122); var tmp8 any; var root_695 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__1078000123__3; if linked_696 == nil { tmp8 = ifn_697.Invoke_O__O(arg_698) } else { tmp8 = linked_696.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_695, arg_698) }; arg_703 = tmp7.Invoke_O__O(tmp8); if linked_700 == nil { return ifn_701.Invoke_O_O__O(arg_702, arg_703) } else { return linked_700.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_699, arg_702, arg_703) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A) Ctor_O_I_O(c__b__1078000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000125 = c__b__1078000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A) Invoke_O__O(self any) any { { var i__1078000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000129__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000124__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000129__2, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000129__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_659 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = t.F_b__1078000125; var arg_663 any; var tmp2 any; var root_655 any = A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, A_arbace_classes_native_local_class_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = lb__4; if linked_656 == nil { tmp2 = ifn_657.Invoke_O__O(arg_658) } else { tmp2 = linked_656.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_655, arg_658) }; arg_663 = lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp2); if linked_660 == nil { ifn_661.Invoke_O_O__O(arg_662, arg_663) } else { linked_660.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_659, arg_662, arg_663) }; i__1078000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000124__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_compile_fn_fn__1078000138_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000138_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000138_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000138_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :152:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000138_A) Invoke_O_O__O(self, p1__1078000119_SHARP___1 any) any { var root_715 any = A_arbace_classes_native_A_const_95.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = t.F_host; var arg_719 any = p1__1078000119_SHARP___1; if linked_716 == nil { return ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { return linked_716.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_715, arg_718, arg_719) } }
func A_arbace_classes_native_compile_fn_fn__1078000140_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000140_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000140_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000140_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :153:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000140_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(s__1, lang.IFn_Cast(t.F_host).Invoke_O__O(s__1)) }
func A_arbace_classes_native_compile_fn_fn__1078000142_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_native_compile_fn_fn__1078000142_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :154:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_A) Ctor_O_O_O_O_O_O(c__form, c__host, c__ns, c__syms, c__cname, c__captured any) { t.F_form = c__form; t.F_host = c__host; t.F_ns = c__ns; t.F_syms = c__syms; t.F_cname = c__cname; t.F_captured = c__captured }
//line :154:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_756 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = lang.IFn_Cast(A_arbace_classes_native_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_51, t.F_ns); if linked_757 == nil { ifn_758.Invoke_O__O(arg_759) } else { linked_757.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_756, arg_759) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_737 any = A_arbace_classes_native_A_const_97.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, A_arbace_classes_native_fn_class_form_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any; var t__2 any = t.F_cname; t.F_cname = nil; arg_740 = t__2; var arg_741 any; var t__3 any = t.F_form; t.F_form = nil; arg_741 = t__3; var arg_742 any; var t__4 any = t.F_captured; t.F_captured = nil; arg_742 = t__4; if linked_738 == nil { tmp5 = ifn_739.Invoke_O_O_O__O(arg_740, arg_741, arg_742) } else { tmp5 = linked_738.(*A_arbace_classes_native_fn_class_form_A).Invoke_O_O_O_O__O(root_737, arg_740, arg_741, arg_742) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :155:1
		return nil }(); var root_748 any = A_arbace_classes_native_A_const_48.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; if linked_749 == nil { ifn_750.Invoke__O() } else { linked_749.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_748) }
//line :154:1
		if tmp6 != nil { panic(tmp6) } }; return nil }(); if tmp7 != nil { if lang.ExceptionInfo_InstanceOf(tmp7) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp7); var u__4 any; var root_776 any = A_arbace_classes_native_A_const_68.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_778 lang.IFn





			if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var tmp8 any = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_New(); var tmp9 *jrt.Class; var fncls__764 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class; if fncls__764 == nil { var fncls__764d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class = fncls__764d; tmp9 = fncls__764d } else { tmp9 = fncls__764 }; arg_779 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_780 any; var root_771 any = A_arbace_classes_native_A_const_100.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = A_arbace_classes_native_A_const_101.GetRawRoot__O(); var arg_775 any; var root_766 any = A_arbace_classes_native_A_const_102.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any; var tmp10 any = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_New(); var tmp11 *jrt.Class; var fncls__765 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class; if fncls__765 == nil { var fncls__765d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class = fncls__765d; tmp11 = fncls__765d } else { tmp11 = fncls__765 }; arg_769 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_770 any = e__3; if linked_767 == nil { arg_775 = ifn_768.Invoke_O_O__O(arg_769, arg_770) } else { arg_775 = linked_767.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_766, arg_769, arg_770) }; if linked_772 == nil { arg_780 = ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { arg_780 = linked_772.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) }; if linked_777 == nil { u__4 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { u__4 = linked_777.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }
			var tmp12 any; var and__1927000168__auto____5 any = u__4; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_781 any = A_arbace_classes_native_A_const_95.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var t__5 any = t.F_host; t.F_host = nil; arg_784 = t__5; var arg_785 any = u__4; if linked_782 == nil { and__1927000168__auto____6 = ifn_783.Invoke_O_O__O(arg_784, arg_785) } else { and__1927000168__auto____6 = linked_782.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_781, arg_784, arg_785) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_791 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any; var root_786 any = A_arbace_classes_native_A_const_68.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, u__4)); var arg_790 any; var t__6 any = t.F_syms; t.F_syms = nil; arg_790 = t__6; if linked_787 == nil { arg_794 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { arg_794 = linked_787.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; if linked_792 == nil { tmp12 = ifn_793.Invoke_O__O(arg_794) } else { tmp12 = linked_792.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_791, arg_794) } } else { tmp12 = and__1927000168__auto____6 } } else { tmp12 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp12) { tmp1 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_classes_native_A_const_103, u__4) } else { panic(jrt.Thrown(e__3)) } } else {
//line :154:1
				panic(tmp7) } }; return tmp1 }





func A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_New() *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A) Ctor() {}
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A) Invoke_O_O__O(self, p1__1078000120_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_native_A_const_98; var tmp2 any; var root_760 any = A_arbace_classes_native_A_const_99.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = p1__1078000120_SHARP___1; if linked_761 == nil { tmp2 = ifn_762.Invoke_O__O(arg_763) } else { tmp2 = linked_761.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_760, arg_763) }; return tmp1.Invoke_O__O(tmp2) }
//line :160:1
func A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_New() *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A) Ctor() {}
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A) Invoke_O_O__O(self, p1__1078000121_SHARP___1 any) any { return jrt.Throwable_Cast(p1__1078000121_SHARP___1).GetCause__Throwable() }


























































































type A_arbace_classes_native_A struct{ jrt.Object }

var A_arbace_classes_native_A_const_pool *jrt.RefArray

var A_arbace_classes_native_A_const_0 *lang.Var

var A_arbace_classes_native_A_const_1 any

var A_arbace_classes_native_A_const_2 any

var A_arbace_classes_native_A_const_3 any

var A_arbace_classes_native_A_const_4 any

var A_arbace_classes_native_A_const_5 *lang.Var

var A_arbace_classes_native_A_const_6 any

var A_arbace_classes_native_A_const_7 *lang.Var

var A_arbace_classes_native_A_const_8 *lang.Var

var A_arbace_classes_native_A_const_9 *lang.Var

var A_arbace_classes_native_A_const_10 *lang.Var

var A_arbace_classes_native_A_const_11 any

var A_arbace_classes_native_A_const_12 *lang.Var

var A_arbace_classes_native_A_const_13 *lang.Var

var A_arbace_classes_native_A_const_14 *lang.Var

var A_arbace_classes_native_A_const_15 *lang.Var

var A_arbace_classes_native_A_const_16 *lang.Keyword

var A_arbace_classes_native_A_const_17 *lang.Var

var A_arbace_classes_native_A_const_18 *lang.Var

var A_arbace_classes_native_A_const_19 *lang.Var

var A_arbace_classes_native_A_const_20 *lang.Keyword

var A_arbace_classes_native_A_const_21 *lang.Var

var A_arbace_classes_native_A_const_22 *lang.Keyword

var A_arbace_classes_native_A_const_23 *lang.Var

var A_arbace_classes_native_A_const_24 *lang.Var

var A_arbace_classes_native_A_const_25 *lang.Var

var A_arbace_classes_native_A_const_26 *lang.Var

var A_arbace_classes_native_A_const_27 *lang.Var

var A_arbace_classes_native_A_const_28 *lang.Var

var A_arbace_classes_native_A_const_29 *lang.Var

var A_arbace_classes_native_A_const_30 *lang.Var

var A_arbace_classes_native_A_const_31 *lang.Var

var A_arbace_classes_native_A_const_32 *lang.Var

var A_arbace_classes_native_A_const_33 *lang.Var

var A_arbace_classes_native_A_const_34 *lang.Var

var A_arbace_classes_native_A_const_35 *lang.Var

var A_arbace_classes_native_A_const_36 *lang.Keyword

var A_arbace_classes_native_A_const_37 *lang.Var

var A_arbace_classes_native_A_const_38 *lang.Keyword

var A_arbace_classes_native_A_const_39 *lang.Var

var A_arbace_classes_native_A_const_40 *lang.Keyword

var A_arbace_classes_native_A_const_41 *lang.Var

var A_arbace_classes_native_A_const_42 *lang.Var

var A_arbace_classes_native_A_const_43 *lang.Var

var A_arbace_classes_native_A_const_44 any

var A_arbace_classes_native_A_const_45 any

var A_arbace_classes_native_A_const_46 *lang.Var

var A_arbace_classes_native_A_const_47 *lang.Var

var A_arbace_classes_native_A_const_48 *lang.Var

var A_arbace_classes_native_A_const_49 *lang.Var

var A_arbace_classes_native_A_const_50 *lang.Var

var A_arbace_classes_native_A_const_51 *lang.Var

var A_arbace_classes_native_A_const_52 *lang.Keyword

var A_arbace_classes_native_A_const_53 *lang.Var

var A_arbace_classes_native_A_const_54 *lang.Var

var A_arbace_classes_native_A_const_55 *lang.Var

var A_arbace_classes_native_A_const_56 *lang.Var

var A_arbace_classes_native_A_const_57 *jrt.Class

var A_arbace_classes_native_A_const_58 *lang.Var

var A_arbace_classes_native_A_const_59 *lang.Var

var A_arbace_classes_native_A_const_60 *lang.Var

var A_arbace_classes_native_A_const_61 *lang.Keyword

var A_arbace_classes_native_A_const_62 *lang.Keyword

var A_arbace_classes_native_A_const_63 *lang.Var

var A_arbace_classes_native_A_const_64 any

var A_arbace_classes_native_A_const_65 *lang.Var

var A_arbace_classes_native_A_const_66 *lang.Var

var A_arbace_classes_native_A_const_67 *lang.Var

var A_arbace_classes_native_A_const_68 *lang.Var

var A_arbace_classes_native_A_const_69 *lang.Var

var A_arbace_classes_native_A_const_70 any

var A_arbace_classes_native_A_const_71 any

var A_arbace_classes_native_A_const_72 *lang.Var

var A_arbace_classes_native_A_const_73 *lang.Keyword

var A_arbace_classes_native_A_const_74 *lang.Var

var A_arbace_classes_native_A_const_75 any

var A_arbace_classes_native_A_const_76 *lang.Keyword

var A_arbace_classes_native_A_const_77 *lang.Keyword

var A_arbace_classes_native_A_const_78 *lang.Keyword

var A_arbace_classes_native_A_const_79 *lang.Var

var A_arbace_classes_native_A_const_80 any

var A_arbace_classes_native_A_const_81 *lang.Var

var A_arbace_classes_native_A_const_82 *lang.Var

var A_arbace_classes_native_A_const_83 *lang.Keyword

var A_arbace_classes_native_A_const_84 *lang.Var

var A_arbace_classes_native_A_const_85 *lang.Var

var A_arbace_classes_native_A_const_86 any

var A_arbace_classes_native_A_const_87 any

var A_arbace_classes_native_A_const_88 any

var A_arbace_classes_native_A_const_89 any

var A_arbace_classes_native_A_const_90 *lang.Var

var A_arbace_classes_native_A_const_91 *lang.Var

var A_arbace_classes_native_A_const_92 *lang.Var

var A_arbace_classes_native_A_const_93 *lang.Var

var A_arbace_classes_native_A_const_94 *lang.Var

var A_arbace_classes_native_A_const_95 *lang.Var

var A_arbace_classes_native_A_const_96 *lang.Var

var A_arbace_classes_native_A_const_97 *lang.Var

var A_arbace_classes_native_A_const_98 *lang.Keyword

var A_arbace_classes_native_A_const_99 *lang.Var

var A_arbace_classes_native_A_const_100 *lang.Var

var A_arbace_classes_native_A_const_101 *lang.Var

var A_arbace_classes_native_A_const_102 *lang.Var

var A_arbace_classes_native_A_const_103 *lang.Keyword

var A_arbace_classes_native_A_const_104 any

var A_arbace_classes_native_A_const_105 *lang.Var

var A_arbace_classes_native_A_const_106 any

var A_arbace_classes_native_A_init jrt.ClassInit

func A_arbace_classes_native_A_Init() { if !A_arbace_classes_native_A_init.Done() { A_arbace_classes_native_A_init.Run(A_arbace_classes_native_A_clinit) } }

func A_arbace_classes_native_A_clinit() { A_arbace_classes_native_A_clinit_p0(); A_arbace_classes_native_A_clinit_p1(); A_arbace_classes_native_A_clinit_p2(); A_arbace_classes_native_A_clinit_p3(); A_arbace_classes_native_A_clinit_p4(); A_arbace_classes_native_A_clinit_p5(); A_arbace_classes_native_A_clinit_p6(); A_arbace_classes_native_A_clinit_p7(); A_arbace_classes_native_A_clinit_p8() }

func A_arbace_classes_native_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_native_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 148); A_arbace_classes_native_A_const_0 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[41]); A_arbace_classes_native_A_const_1 = A_arbace_classes_native_A_const_pool.A[42]; A_arbace_classes_native_A_const_2 = A_arbace_classes_native_A_const_pool.A[43]; A_arbace_classes_native_A_const_3 = A_arbace_classes_native_A_const_pool.A[44]; A_arbace_classes_native_A_const_4 = A_arbace_classes_native_A_const_pool.A[45]; A_arbace_classes_native_A_const_5 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[46]); A_arbace_classes_native_A_const_6 = A_arbace_classes_native_A_const_pool.A[47]; A_arbace_classes_native_A_const_7 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[48]); A_arbace_classes_native_A_const_8 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[49]); A_arbace_classes_native_A_const_9 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[50]); A_arbace_classes_native_A_const_10 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[51]); A_arbace_classes_native_A_const_11 = A_arbace_classes_native_A_const_pool.A[52] }

func A_arbace_classes_native_A_clinit_p1() { A_arbace_classes_native_A_const_12 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[53]); A_arbace_classes_native_A_const_13 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[54]); A_arbace_classes_native_A_const_14 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[55]); A_arbace_classes_native_A_const_15 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[56]); A_arbace_classes_native_A_const_16 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[57]); A_arbace_classes_native_A_const_17 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[58]); A_arbace_classes_native_A_const_18 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[59]); A_arbace_classes_native_A_const_19 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[60]); A_arbace_classes_native_A_const_20 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[61]); A_arbace_classes_native_A_const_21 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[62]); A_arbace_classes_native_A_const_22 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[63]); A_arbace_classes_native_A_const_23 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[64]) }

func A_arbace_classes_native_A_clinit_p2() { A_arbace_classes_native_A_const_24 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[65]); A_arbace_classes_native_A_const_25 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[66]); A_arbace_classes_native_A_const_26 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[67]); A_arbace_classes_native_A_const_27 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[68]); A_arbace_classes_native_A_const_28 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[69]); A_arbace_classes_native_A_const_29 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[70]); A_arbace_classes_native_A_const_30 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[71]); A_arbace_classes_native_A_const_31 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[72]); A_arbace_classes_native_A_const_32 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[73]); A_arbace_classes_native_A_const_33 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[74]); A_arbace_classes_native_A_const_34 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[75]); A_arbace_classes_native_A_const_35 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[76]) }

func A_arbace_classes_native_A_clinit_p3() { A_arbace_classes_native_A_const_36 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[77]); A_arbace_classes_native_A_const_37 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[78]); A_arbace_classes_native_A_const_38 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[79]); A_arbace_classes_native_A_const_39 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[80]); A_arbace_classes_native_A_const_40 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[81]); A_arbace_classes_native_A_const_41 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[82]); A_arbace_classes_native_A_const_42 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[83]); A_arbace_classes_native_A_const_43 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[84]); A_arbace_classes_native_A_const_44 = A_arbace_classes_native_A_const_pool.A[85]; A_arbace_classes_native_A_const_45 = A_arbace_classes_native_A_const_pool.A[86]; A_arbace_classes_native_A_const_46 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[87]); A_arbace_classes_native_A_const_47 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[88]) }

func A_arbace_classes_native_A_clinit_p4() { A_arbace_classes_native_A_const_48 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[89]); A_arbace_classes_native_A_const_49 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[90]); A_arbace_classes_native_A_const_50 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[91]); A_arbace_classes_native_A_const_51 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[92]); A_arbace_classes_native_A_const_52 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[93]); A_arbace_classes_native_A_const_53 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[94]); A_arbace_classes_native_A_const_54 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[95]); A_arbace_classes_native_A_const_55 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[96]); A_arbace_classes_native_A_const_56 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[97]); A_arbace_classes_native_A_const_57 = jrt.Class_Cast(A_arbace_classes_native_A_const_pool.A[98]); A_arbace_classes_native_A_const_58 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[99]); A_arbace_classes_native_A_const_59 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[100]) }

func A_arbace_classes_native_A_clinit_p5() { A_arbace_classes_native_A_const_60 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[101]); A_arbace_classes_native_A_const_61 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[102]); A_arbace_classes_native_A_const_62 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[103]); A_arbace_classes_native_A_const_63 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[104]); A_arbace_classes_native_A_const_64 = A_arbace_classes_native_A_const_pool.A[105]; A_arbace_classes_native_A_const_65 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[106]); A_arbace_classes_native_A_const_66 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[107]); A_arbace_classes_native_A_const_67 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[108]); A_arbace_classes_native_A_const_68 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[109]); A_arbace_classes_native_A_const_69 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[110]); A_arbace_classes_native_A_const_70 = A_arbace_classes_native_A_const_pool.A[111]; A_arbace_classes_native_A_const_71 = A_arbace_classes_native_A_const_pool.A[112] }

func A_arbace_classes_native_A_clinit_p6() { A_arbace_classes_native_A_const_72 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[113]); A_arbace_classes_native_A_const_73 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[114]); A_arbace_classes_native_A_const_74 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[115]); A_arbace_classes_native_A_const_75 = A_arbace_classes_native_A_const_pool.A[116]; A_arbace_classes_native_A_const_76 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[117]); A_arbace_classes_native_A_const_77 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[118]); A_arbace_classes_native_A_const_78 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[119]); A_arbace_classes_native_A_const_79 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[120]); A_arbace_classes_native_A_const_80 = A_arbace_classes_native_A_const_pool.A[121]; A_arbace_classes_native_A_const_81 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[122]); A_arbace_classes_native_A_const_82 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[123]); A_arbace_classes_native_A_const_83 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[124]) }

func A_arbace_classes_native_A_clinit_p7() { A_arbace_classes_native_A_const_84 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[125]); A_arbace_classes_native_A_const_85 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[126]); A_arbace_classes_native_A_const_86 = A_arbace_classes_native_A_const_pool.A[127]; A_arbace_classes_native_A_const_87 = A_arbace_classes_native_A_const_pool.A[128]; A_arbace_classes_native_A_const_88 = A_arbace_classes_native_A_const_pool.A[129]; A_arbace_classes_native_A_const_89 = A_arbace_classes_native_A_const_pool.A[130]; A_arbace_classes_native_A_const_90 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[131]); A_arbace_classes_native_A_const_91 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[132]); A_arbace_classes_native_A_const_92 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[133]); A_arbace_classes_native_A_const_93 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[134]); A_arbace_classes_native_A_const_94 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[135]); A_arbace_classes_native_A_const_95 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[136]); A_arbace_classes_native_A_const_96 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[137]) }

func A_arbace_classes_native_A_clinit_p8() { A_arbace_classes_native_A_const_97 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[138]); A_arbace_classes_native_A_const_98 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[139]); A_arbace_classes_native_A_const_99 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[140]); A_arbace_classes_native_A_const_100 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[141]); A_arbace_classes_native_A_const_101 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[142]); A_arbace_classes_native_A_const_102 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[143]); A_arbace_classes_native_A_const_103 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[144]); A_arbace_classes_native_A_const_104 = A_arbace_classes_native_A_const_pool.A[145]; A_arbace_classes_native_A_const_105 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[146]); A_arbace_classes_native_A_const_106 = A_arbace_classes_native_A_const_pool.A[147] }

func A_arbace_classes_native_A_New() *A_arbace_classes_native_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_A) Ctor() {}

func (t *A_arbace_classes_native_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_A_class }

func (t *A_arbace_classes_native_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_A); return ok }

func A_arbace_classes_native_A_Cast(x any) *A_arbace_classes_native_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_A_class)) }; return v }



type A_arbace_classes_native_compile_and_load_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A struct{ j2g_header uint64; F_s__1078000016, F_iter__1078000015 any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A struct{ j2g_header uint64; F_b__1078000018 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_deftype_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_fn__1078000049_A struct{ j2g_header uint64; F_form, F_ns any }

var A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000138_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000140_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_A struct{ j2g_header uint64; F_form, F_host, F_ns, F_syms, F_cname, F_captured any }

var A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A struct{ j2g_header uint64; F_s__1078000123, F_iter__1078000122 any }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A struct{ j2g_header uint64; F_b__1078000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A struct{ j2g_header uint64; F_s__1078000033, F_iter__1078000032 any }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1078000035, F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000004_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000004_A_New() *A_arbace_classes_native_eval1078000004_A { t := &A_arbace_classes_native_eval1078000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000004_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000004_A_class }

func (t *A_arbace_classes_native_eval1078000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000004_A); return ok }

func A_arbace_classes_native_eval1078000004_A_Cast(x any) *A_arbace_classes_native_eval1078000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000004_A_class)) }; return v }



type A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000008_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000008_A_New() *A_arbace_classes_native_eval1078000008_A { t := &A_arbace_classes_native_eval1078000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000008_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000008_A_class }

func (t *A_arbace_classes_native_eval1078000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000008_A); return ok }

func A_arbace_classes_native_eval1078000008_A_Cast(x any) *A_arbace_classes_native_eval1078000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000008_A_class)) }; return v }



type A_arbace_classes_native_eval1078000008_fn__1078000009_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class *jrt.Class



type A_arbace_classes_native_field_names_A struct{ j2g_header uint64 }

var A_arbace_classes_native_field_names_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000097_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000113_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A struct{ j2g_header uint64; F_s__1078000075, F_iter__1078000074, F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A struct{ j2g_header uint64; F_b__1078000077, F_typed any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A struct{ j2g_header uint64; F_s__1078000103, F_rcv, F_iter__1078000102 any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A struct{ j2g_header uint64; F_b__1078000105, F_rcv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_typed__1078000072_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_A struct{ j2g_header uint64 }

var A_arbace_classes_native_local_class_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000054_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000054_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000056_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000056_A_fn_class *jrt.Class



type A_arbace_classes_native_public_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_native_public_class_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_native_type_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_type_form_A_fn_class *jrt.Class
