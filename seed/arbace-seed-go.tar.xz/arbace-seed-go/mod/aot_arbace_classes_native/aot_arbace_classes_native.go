//line aot_arbace_classes_native.ae:1
package aot_arbace_classes_native

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New() *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_native_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_classes_native_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_native_A_const_3, A_arbace_classes_native_A_const_4, A_arbace_classes_native_A_const_5, A_arbace_classes_native_A_const_6); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_native_eval1078000008_fn__1078000009_A_New() *A_arbace_classes_native_eval1078000008_fn__1078000009_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000008_fn__1078000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_classes_native_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_11), A_arbace_classes_native_A_const_9.GetRawRoot__O(), A_arbace_classes_native_A_const_10) }



































func A_arbace_classes_native_compile_and_load_BANG__A_New() *A_arbace_classes_native_compile_and_load_BANG__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) DoInvoke_O_O_O_O__O(self, ns__0, forms__1, p__1078000012__2 any) any { var map__1078000013__4 any = p__1078000012__2; var map__1078000013__5 any; if lang.ISeq_InstanceOf(map__1078000013__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_12.GetRawRoot__O()).Invoke_O__O(map__1078000013__4)) { map__1078000013__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_native_A_const_13.GetRawRoot__O()).Invoke_O__O(map__1078000013__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(map__1078000013__4)) { map__1078000013__5 = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1078000013__4) } else { map__1078000013__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000013__5 = map__1078000013__4 }; var siblings__6 any = lang.RT_Get_O_O__O_NoInit(map__1078000013__5, A_arbace_classes_native_A_const_16); var loaded__7 any = lang.IFn_Cast(A_arbace_classes_native_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__1, A_arbace_classes_native_A_const_16, siblings__6); if



	jrt.J2g_Truth(A_arbace_classes_native_A_const_18.GetRawRoot__O()) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var tmp3 any = A_arbace_classes_native_A_const_9.GetRawRoot__O(); var tmp4 any = A_arbace_classes_native_A_const_20; var tmp5 any = lang.IFn_Cast(A_arbace_classes_native_A_const_21.GetRawRoot__O()).Invoke_O__O(ns__0); var tmp6 any = A_arbace_classes_native_A_const_22; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_23.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_classes_native_A_const_28.GetRawRoot__O()).Invoke__O(); var tmp9 any; var iter__1927001039__auto____8 any; var tmp10 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_New(); var tmp11 *jrt.Class
		var fncls__3 /*line :42:1*/*jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class


		if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class = fncls__3d; tmp11 = fncls__3d } else { tmp11 = fncls__3 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_39.GetRawRoot__O()).Invoke_O__O(ns__0))
//line :42:1
		var tmp12 any = tmp7.Invoke_O_O__O(tmp8, tmp9); var tmp13 any = A_arbace_classes_native_A_const_24; var tmp14 any = lang.IFn_Cast(A_arbace_classes_native_A_const_25.GetRawRoot__O()).Invoke_O__O(forms__1); var tmp15 any = A_arbace_classes_native_A_const_26; tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp12, tmp13, tmp14, tmp15, lang.IFn_Cast(A_arbace_classes_native_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_15.GetRawRoot__O(), loaded__7)))) }; return loaded__7 }


func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_New() *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A) Ctor() {}
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A) Invoke_O_O__O(self, s__1078000016__1 any) any { var tmp1 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_New_O_O(s__1078000016__1, self); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :45:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A) Ctor_O_O(c__s__1078000016, c__iter__1078000015 any) { t.F_s__1078000016 = c__s__1078000016; t.F_iter__1078000015 = c__iter__1078000015 }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A) Invoke_O__O(self any) any { { var s__1078000016__1 any; var t_ any = t.F_s__1078000016; t.F_s__1078000016 = nil; s__1078000016__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1078000016__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000016__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1078000016__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1078000016__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000018__6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_New_O_I_O(b__1078000018__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1078000015); return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000018__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_37.GetRawRoot__O()).Invoke_O__O(s__1078000016__3))) } else { return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000018__6), nil) } } else { var vec__1078000026__4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1078000016__3); var sym__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000026__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000026__4, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__6, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__5))).Ref())) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000015); return lang.IFn_Cast(A_arbace_classes_native_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(sym__5, jrt.NN(jrt.Class_Cast(c__6)).GetName__String().Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_38.GetRawRoot__O()).Invoke_O__O(s__1078000016__3))) } else { s__1078000016__1 = lang.IFn_Cast(A_arbace_classes_native_A_const_38.GetRawRoot__O()).Invoke_O__O(s__1078000016__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :45:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A) Ctor_O_I_O(c__b__1078000018 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000018 = c__b__1078000018; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A) Invoke_O__O(self any) any { { var i__1078000017__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000022__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000017__1)); var sym__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000022__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000022__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__4, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__3))).Ref())) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_33.GetRawRoot__O()); var tmp3 any = t.F_b__1078000018; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(sym__3, jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref())); i__1078000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000017__1); continue L1 } else { i__1078000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000017__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_native_compile_top_A_New() *A_arbace_classes_native_compile_top_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_native_compile_top_A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_native_compile_top_A) Invoke_O_O_O_O_O__O(self, ns__0, kind__1, forms__2, siblings__3 any) any { var forms__5 any; if






	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_40, kind__1) { forms__5 = lang.Tuple_Create_O__IPersistentVector(forms__2) } else { forms__5 = lang.IFn_Cast(A_arbace_classes_native_A_const_25.GetRawRoot__O()).Invoke_O__O(forms__2) }; var loaded__6 any = /*line :52:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__5, A_arbace_classes_native_A_const_16, siblings__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_42.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_45); var tmp4 any; var iter__1927001039__auto____7 any; var tmp5 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_New(); var tmp6 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class; if









	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class = fncls__6d; tmp6 = fncls__6d } else { tmp6 = fncls__6 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(loaded__6); var tmp7 any = tmp4; var tmp8 lang.IFn = /*line :59:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp9 any; if



	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_40, kind__1) { tmp9 = lang.IFn_Cast(A_arbace_classes_native_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(loaded__6)) } else { tmp9 = lang.IFn_Cast(A_arbace_classes_native_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_46.GetRawRoot__O(), loaded__6) }; return /*line :59:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp7, tmp8.Invoke_O__O(tmp9))) }


func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_New() *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A) Invoke_O_O__O(self, s__1078000033__1 any) any { var tmp1 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_New_O_O(s__1078000033__1, self); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :62:1
func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A{}; t.Ctor_O_O(p0, p1); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A) Ctor_O_O(c__s__1078000033, c__iter__1078000032 any) { t.F_s__1078000033 = c__s__1078000033; t.F_iter__1078000032 = c__iter__1078000032 }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A) Invoke_O__O(self any) any { { var s__1078000033__1 any; var t_ any = t.F_s__1078000033; t.F_s__1078000033 = nil; s__1078000033__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1078000033__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000033__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1078000033__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1078000033__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000035__6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_New_I_O_O(size__1927001038__auto____5, b__1078000035__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1078000032); return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000035__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_37.GetRawRoot__O()).Invoke_O__O(s__1078000033__3))) } else { return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000035__6), nil) } } else { var vec__1078000043__4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1078000033__3); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000043__4, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000032); return lang.IFn_Cast(A_arbace_classes_native_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_44, n__5), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_38.GetRawRoot__O()).Invoke_O__O(s__1078000033__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :62:1
func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1078000035, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1078000035 = c__b__1078000035; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A) Invoke_O__O(self any) any { { var i__1078000034__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000034__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000039__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000034__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_33.GetRawRoot__O()); var tmp3 any = t.F_b__1078000035; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_44, n__3)); i__1078000034__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000034__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_native_compile_deftype_A_New() *A_arbace_classes_native_compile_deftype_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_classes_native_compile_deftype_A) Ctor() {}
//line :68:1
func (t *A_arbace_classes_native_compile_deftype_A) Invoke_O_O_O__O(self, ns__0, form__1 any) any {




	lang.IFn_Cast(A_arbace_classes_native_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_51, ns__0)); var tmp1 any = A_arbace_classes_native_compile_deftype_fn__1078000049_A_New_O_O(form__1, ns__0); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :68:1
	return nil
}



func A_arbace_classes_native_compile_deftype_fn__1078000049_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_deftype_fn__1078000049_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_fn__1078000049_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000049_A) Ctor_O_O(c__form, c__ns any) { t.F_form = c__form; t.F_ns = c__ns }
//line :73:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_48.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_form; t.F_form = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O__O(tmp6))) }
//line :73:1
	return nil }(); lang.IFn_Cast(A_arbace_classes_native_A_const_47.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }






func A_arbace_classes_native_public_class_QMARK__A_New() *A_arbace_classes_native_public_class_QMARK__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_public_class_QMARK__A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Invoke_O_O__O(self, c__0 any) any { { var c__2 any = c__0; L1: for {

	if lang.Util_Identical_O_O__Z_NoInit(c__2, nil) { return jrt.Boolean_TRUE.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__2)).GetModifiers__I())).Ref())) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_native_A_const_52 != nil {

		c__2 = jrt.NN(jrt.Class_Cast(c__2)).GetDeclaringClass__Class().Ref(); continue L1 } else {
//line :82:1
			return nil } } } } }; /*line :80:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_type_form_A_New() *A_arbace_classes_native_type_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_type_form_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_classes_native_type_form_A) Ctor() {}
//line :86:1
func (t *A_arbace_classes_native_type_form_A) Invoke_O_O__O(self, c__0 any) any {


	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var c__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(c__2)).IsArray__Z() { c__2, n__3 = jrt.NN(jrt.Class_Cast(c__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J_NoInit(n__3); continue L1 } else { return lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(), lang.IFn_Cast(A_arbace_classes_native_A_const_54.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref())) } } } else {
			return lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref()) }
//line :86:1
	panic("j2g: unreachable")
}






func A_arbace_classes_native_local_class_A_New() *A_arbace_classes_native_local_class_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_classes_native_local_class_A) Ctor() {}
//line :94:1
func (t *A_arbace_classes_native_local_class_A) Invoke_O_O__O(self, lb__0 any) any { var prim__2 any; var tmp1 any = A_arbace_classes_native_local_class_fn__1078000054_A_New_O(lb__0); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000054_A_fn_class; if



	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_classes_native_local_class_fn__1078000054_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; prim__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var or__1927000174__auto____3 any = prim__2; if
	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var c__4 any; var tmp3 any = A_arbace_classes_native_local_class_fn__1078000056_A_New_O(lb__0); var tmp4 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000056_A_fn_class
		if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_native_local_class_fn__1078000056_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; c__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


		var tmp5 any; var and__1927000168__auto____5 bool = jrt.Class_InstanceOf(c__4); if and__1927000168__auto____5 { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__4)).IsPrimitive__Z()).Ref()); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_classes_native_A_const_55.GetRawRoot__O()).Invoke_O__O(c__4); if jrt.J2g_Truth(and__1927000168__auto____7) {
			tmp5 = lang.IFn_Cast(A_arbace_classes_native_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_57.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref(), Lit_32)) } else {
//line :103:1
				tmp5 = and__1927000168__auto____7 } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp5) { return c__4 } else { return A_arbace_classes_native_A_const_56 } } }
//line :98:1
func A_arbace_classes_native_local_class_fn__1078000054_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000054_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000054_A{}; t.Ctor_O(p0); return t }
//line :98:1
func (t *A_arbace_classes_native_local_class_fn__1078000054_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :98:1
func (t *A_arbace_classes_native_local_class_fn__1078000054_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetPrimitiveType__Class().Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_classes_native_local_class_fn__1078000056_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000056_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000056_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_classes_native_local_class_fn__1078000056_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :100:1
func (t *A_arbace_classes_native_local_class_fn__1078000056_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); if jrt.NN(lang.Compiler_LocalBinding_Cast(t.F_lb)).HasJavaClass__Z() {
												var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetJavaClass__Class().Ref() } else {
//line :100:1
		tmp1 = nil }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_classes_native_field_names_A_New() *A_arbace_classes_native_field_names_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_field_names_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_classes_native_field_names_A) Ctor() {}
//line :108:1
func (t *A_arbace_classes_native_field_names_A) Invoke_O_O__O(self, syms__0 any) any { { var G__1078000062__2_ any = syms__0; var vec__1078000063__3 any = G__1078000062__2_; var seq__1078000064__4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(vec__1078000063__3); var first__1078000065__5 any = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1078000064__4); var seq__1078000064__6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__1078000064__4); var s__7 any = first__1078000065__5; var more__8 any = seq__1078000064__6; var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); var out__10 any = lang.PersistentVector_EMPTY.Ref(); var G__1078000062__11_ any = G__1078000062__2_; var seen__12 any = seen__9; var out__13 any = out__10; _ = s__7; _ = more__8; L1: for { var vec__1078000066__14 any = G__1078000062__11_; var seq__1078000067__15 any = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(vec__1078000066__14); var first__1078000068__16 any = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(seq__1078000067__15); var seq__1078000067__17 any = lang.IFn_Cast(A_arbace_classes_native_A_const_12.GetRawRoot__O()).Invoke_O__O(seq__1078000067__15)
											var s__18 any = first__1078000068__16
											var more__19 any = seq__1078000067__17
											var seen__20 any = seen__12; var out__21 any = out__13
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_32.GetRawRoot__O()).Invoke_O__O(s__18)) { return out__21 } else { var base__22 any = lang.IFn_Cast(A_arbace_classes_native_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_59.GetRawRoot__O()).Invoke_O__O(s__18)); var n__23 any


		if jrt.J2g_Truth(lang.IFn_Cast(seen__20).Invoke_O__O(base__22)) { n__23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, base__22, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(out__21)).Ref())).Ref() } else { n__23 = base__22 }
		G__1078000062__11_, seen__12, out__13 = more__19, lang.IFn_Cast(A_arbace_classes_native_A_const_9.GetRawRoot__O()).Invoke_O_O__O(seen__20, n__23), lang.IFn_Cast(A_arbace_classes_native_A_const_9.GetRawRoot__O()).Invoke_O_O__O(out__21, n__23); continue L1 } } }; /*line :108:1*/panic("j2g: unreachable") }









func A_arbace_classes_native_fn_class_form_A_New() *A_arbace_classes_native_fn_class_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_native_fn_class_form_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_native_fn_class_form_A) Invoke_O_O_O_O__O(self, cname__0, form__1, captured__2 any) any { var map__1078000070__4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_60.GetRawRoot__O()).Invoke_O__O(form__1); var map__1078000070__5 any; if



	lang.ISeq_InstanceOf(map__1078000070__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_12.GetRawRoot__O()).Invoke_O__O(map__1078000070__4)) { map__1078000070__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_native_A_const_13.GetRawRoot__O()).Invoke_O__O(map__1078000070__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(map__1078000070__4)) { map__1078000070__5 = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(map__1078000070__4) } else { map__1078000070__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000070__5 = map__1078000070__4 }; var nm__6 any = /*line :118:1*/lang.RT_Get_O_O__O_NoInit(map__1078000070__5, A_arbace_classes_native_A_const_61); var arities__7 any = lang.RT_Get_O_O__O_NoInit(map__1078000070__5, A_arbace_classes_native_A_const_62); var i__8 int32 = jrt.NN(jrt.String_Cast(cname__0)).LastIndexOf_String__I(Lit_17); var pkg__9 any; if





	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__8)) { pkg__9 = Lit_18 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_63.GetRawRoot__O()); var tmp2 any = A_arbace_classes_native_A_const_72; pkg__9 = tmp1.Invoke_O_O_O__O(cname__0, tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(i__8).Ref()) }; var simple__10 any = /*line :118:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_63.GetRawRoot__O()).Invoke_O_O__O(cname__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__8))).Ref()); var rcv__11 any = lang.IFn_Cast(A_arbace_classes_native_A_const_64.GetRawRoot__O()).Invoke_O__O(Lit_19); var fields__12 any = lang.IFn_Cast(A_arbace_classes_native_A_const_65.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_15.GetRawRoot__O(), captured__2)); var super__13 any; if









	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_66.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_74.GetRawRoot__O(), arities__7)) { super__13 = A_arbace_classes_native_A_const_67 } else { super__13 = A_arbace_classes_native_A_const_68 }; var typed__14 any; var tmp3 any = /*line :118:1*/A_arbace_classes_native_fn_class_form_typed__1078000072_A_New(); var tmp4 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class; if










	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }; typed__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn =
	lang.IFn_Cast(A_arbace_classes_native_A_const_42.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_69.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(simple__10), A_arbace_classes_native_A_const_84); var tmp7 any = A_arbace_classes_native_A_const_75; var tmp8 any = A_arbace_classes_native_A_const_76; var tmp9 any = A_arbace_classes_native_A_const_77; var tmp10 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, pkg__9, tmp8, super__13, tmp9, lang.IFn_Cast(A_arbace_classes_native_A_const_78.GetRawRoot__O()).Invoke_O__O(arities__7))); var tmp11 any; var iter__1927001039__auto____15 any; var tmp12 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_New_O(typed__14); var tmp13 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class; if




	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class = fncls__13d; tmp13 = fncls__13d } else { tmp13 = fncls__13 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); tmp11 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_classes_native_A_const_85.GetRawRoot__O(), fields__12, captured__2)); var tmp14 any = tmp11; var tmp15 lang.IFn = /*line :130:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_86.GetRawRoot__O()); var tmp16 any = A_arbace_classes_native_A_const_87; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_69.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_25.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_35.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()); var tmp21 any = A_arbace_classes_native_fn_class_form_fn__1078000097_A_New_O(typed__14); var tmp22 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class; if






	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class = fncls__17d; tmp22 = fncls__17d } else { tmp22 = fncls__17 }; var tmp23 any = /*line :130:1*/tmp17.Invoke_O_O__O(tmp18.Invoke_O__O(tmp19.Invoke_O_O__O(rcv__11, tmp20.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), fields__12, captured__2))), A_arbace_classes_native_A_const_89); var tmp24 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_90); var tmp25 any; var iter__1927001039__auto____15_2 any; var tmp26 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_New_O(rcv__11); var tmp27 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class; if









	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class = fncls__16d; tmp27 = fncls__16d } else { tmp27 = fncls__16 }; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); tmp25 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(fields__12); var tmp28 any = /*line :130:1*/lang.Tuple_Create_O__IPersistentVector(tmp15.Invoke_O_O_O_O__O(tmp16, tmp23, tmp24, tmp25)); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_83.GetRawRoot__O()); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_25.GetRawRoot__O()); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_91.GetRawRoot__O()); var tmp32 any = A_arbace_classes_native_fn_class_form_fn__1078000113_A_New_O(rcv__11); var tmp33 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class; if











	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class = fncls__18d; tmp33 = fncls__18d } else { tmp33 = fncls__18 }; return /*line :130:1*/ tmp5.Invoke_O_O_O_O__O(tmp10, tmp14, tmp28, tmp29.Invoke_O_O_O_O__O(rcv__11, nm__6, arities__7, tmp30.Invoke_O__O(tmp31.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil), fields__12, captured__2)))) }
//line :129:1
func A_arbace_classes_native_fn_class_form_typed__1078000072_A_New() *A_arbace_classes_native_fn_class_form_typed__1078000072_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_typed__1078000072_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000072_A) Ctor() {}
//line :129:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000072_A) Invoke_O_O_O__O(self, s__1, c__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__2, A_arbace_classes_native_A_const_56) { return s__1 } else { var tmp1 any = A_arbace_classes_native_A_const_70; return lang.IFn_Cast(A_arbace_classes_native_A_const_69.GetRawRoot__O()).Invoke_O_O__O(s__1, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.IFn_Cast(A_arbace_classes_native_A_const_71.GetRawRoot__O()).Invoke_O__O(c__2)))) } }





func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A) Invoke_O_O__O(self, s__1078000075__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_New_O_O_O(s__1078000075__1, self, t.F_typed); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :135:1
func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A) Ctor_O_O_O(c__s__1078000075, c__iter__1078000074, c__typed any) { t.F_s__1078000075 = c__s__1078000075; t.F_iter__1078000074 = c__iter__1078000074; t.F_typed = c__typed }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A) Invoke_O__O(self any) any { { var s__1078000075__1 any; var t_ any = t.F_s__1078000075; t.F_s__1078000075 = nil; s__1078000075__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1078000075__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000075__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1078000075__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1078000075__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000077__6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_New_O_O_I_O(b__1078000077__6, t.F_typed, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1078000074); return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000077__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_37.GetRawRoot__O()).Invoke_O__O(s__1078000075__3))) } else { return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000077__6), nil) } } else { var vec__1078000088__4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1078000075__3); var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000088__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000091__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000088__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000091__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000091__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp5 any = A_arbace_classes_native_A_const_79; var tmp6 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000074); _ = ___7; return lang.IFn_Cast(A_arbace_classes_native_A_const_35.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_classes_native_A_const_80.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp6.Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(f__5), c__8), A_arbace_classes_native_A_const_81.GetRawRoot__O(), A_arbace_classes_native_A_const_82, jrt.Boolean_TRUE.Ref())), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_38.GetRawRoot__O()).Invoke_O__O(s__1078000075__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :135:1
func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A) Ctor_O_O_I_O(c__b__1078000077, c__typed any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000077 = c__b__1078000077; t.F_typed = c__typed; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A) Invoke_O__O(self any) any { { var i__1078000076__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000076__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000081__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000076__1)); var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000081__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000084__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000081__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000084__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000084__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_33.GetRawRoot__O()); var tmp3 any = t.F_b__1078000077; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp5 any = A_arbace_classes_native_A_const_79; var tmp6 lang.IFn = lang.IFn_Cast(t.F_typed); _ = ___5; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_classes_native_A_const_80.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp6.Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(f__3), c__6), A_arbace_classes_native_A_const_81.GetRawRoot__O(), A_arbace_classes_native_A_const_82, jrt.Boolean_TRUE.Ref()))); i__1078000076__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000076__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000097_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000097_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000097_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000097_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :137:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000097_A) Invoke_O_O_O__O(self, f__1, p__1078000096__2 any) any { var vec__1078000098__3 any = p__1078000096__2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000098__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000098__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_typed); _ = ___4; return tmp1.Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(f__1), c__5) }


func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A{}; t.Ctor_O(p0); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A) Invoke_O_O__O(self, s__1078000103__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_New_O_O_O(s__1078000103__1, t.F_rcv, self); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :140:1
func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A) Ctor_O_O_O(c__s__1078000103, c__rcv, c__iter__1078000102 any) { t.F_s__1078000103 = c__s__1078000103; t.F_rcv = c__rcv; t.F_iter__1078000102 = c__iter__1078000102 }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A) Invoke_O__O(self any) any { { var s__1078000103__1 any; var t_ any = t.F_s__1078000103; t.F_s__1078000103 = nil; s__1078000103__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1078000103__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000103__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1078000103__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1078000103__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000105__6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_O_I_O(b__1078000105__6, t.F_rcv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000105__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_37.GetRawRoot__O()).Invoke_O__O(s__1078000103__3))) } else { return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000105__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1078000103__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp5 any = A_arbace_classes_native_A_const_88; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); return lang.IFn_Cast(A_arbace_classes_native_A_const_35.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref()), t.F_rcv), lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(f__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_38.GetRawRoot__O()).Invoke_O__O(s__1078000103__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :140:1
func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Ctor_O_O_I_O(c__b__1078000105, c__rcv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000105 = c__b__1078000105; t.F_rcv = c__rcv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Invoke_O__O(self any) any { { var i__1078000104__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000104__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_33.GetRawRoot__O()); var tmp3 any = t.F_b__1078000105; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp5 any = A_arbace_classes_native_A_const_88; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref()), t.F_rcv), lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(f__2))); i__1078000104__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000104__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000113_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000113_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000113_A{}; t.Ctor_O(p0); return t }
//line :142:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000113_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :142:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000113_A) Invoke_O_O_O__O(self, f__1, p__1078000112__2 any) any { var vec__1078000114__3 any = p__1078000112__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000114__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000114__3, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return lang.Tuple_Create_O_O__IPersistentVector(s__4, lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_53.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref()), t.F_rcv)) }

func A_arbace_classes_native_compile_fn_A_New() *A_arbace_classes_native_compile_fn_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_classes_native_compile_fn_A) Ctor() {}
//line :144:1
func (t *A_arbace_classes_native_compile_fn_A) Invoke_O_O_O_O_O__O(self, ns__0, cname__1, form__2, env__3 any) any { { var host__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_23.GetRawRoot__O()); var tmp2 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp3 any; var iter__1927001039__auto____5 any; var tmp4 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_New(); var tmp5 *jrt.Class
															var fncls__24 /*line :144:1*/*jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class





	if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class = fncls__24d; tmp5 = fncls__24d } else { tmp5 = fncls__24 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(env__3); host__5 = tmp1.Invoke_O_O__O(tmp2, tmp3)
//line :144:1
	var mentioned__6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_92.GetRawRoot__O()).Invoke_O__O(form__2); var syms__7 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_93.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_compile_fn_fn__1078000138_A_New_O(host__5); var tmp8 *jrt.Class
	var fncls__25 /*line :144:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class







	if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class = fncls__25d; tmp8 = fncls__25d } else { tmp8 = fncls__25 }; syms__7 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_classes_native_A_const_104.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_54.GetRawRoot__O(), mentioned__6))
//line :144:1
L1: for { var captured__8 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_27.GetRawRoot__O()); var tmp10 any = A_arbace_classes_native_compile_fn_fn__1078000140_A_New_O(host__5); var tmp11 *jrt.Class
	var fncls__26 /*line :144:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class








	if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class = fncls__26d; tmp11 = fncls__26d } else { tmp11 = fncls__26 }; captured__8 = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), syms__7)
//line :144:1
	var r__9 any; var tmp12 any = A_arbace_classes_native_compile_fn_fn__1078000142_A_New_O_O_O_O_O_O(form__2, host__5, ns__0, syms__7, cname__1, captured__8); var tmp13 *jrt.Class
	var fncls__21 /*line :144:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class









	if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class = fncls__21d; tmp13 = fncls__21d } else { tmp13 = fncls__21 }; r__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O()









	var tmp14 any = A_arbace_classes_native_A_const_101; if lang.Util_Equiv_O_O__Z_NoInit(tmp14, lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(r__9)) {
		syms__7 = lang.IFn_Cast(A_arbace_classes_native_A_const_9.GetRawRoot__O()).Invoke_O_O__O(syms__7, lang.IFn_Cast(A_arbace_classes_native_A_const_46.GetRawRoot__O()).Invoke_O__O(r__9)); continue L1 } else {
//line :164:1
			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_86.GetRawRoot__O()); var tmp16 any = A_arbace_classes_native_A_const_105; var new__10 any = tmp15.Invoke_O_O_O__O(tmp16, lang.IFn_Cast(A_arbace_classes_native_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(r__9)), syms__7); var temp__1927000408__auto____11 any = lang.IFn_Cast(A_arbace_classes_native_A_const_102.GetRawRoot__O()).Invoke_O__O(form__2)



			if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11
				return lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_classes_native_A_const_106, new__10, m__12) } else {
//line :168:1
					return new__10 } } } }; /*line :144:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_New() *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A) Ctor() {}
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A) Invoke_O_O__O(self, s__1078000123__1 any) any { var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_New_O_O(s__1078000123__1, self); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A) Ctor_O_O(c__s__1078000123, c__iter__1078000122 any) { t.F_s__1078000123 = c__s__1078000123; t.F_iter__1078000122 = c__iter__1078000122 }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A) Invoke_O__O(self any) any { { var s__1078000123__1 any; var t_ any = t.F_s__1078000123; t.F_s__1078000123 = nil; s__1078000123__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1078000123__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000123__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_native_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1078000123__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1078000123__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000125__6 any = lang.IFn_Cast(A_arbace_classes_native_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_New_O_I_O(b__1078000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1078000122); return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000125__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_37.GetRawRoot__O()).Invoke_O__O(s__1078000123__3))) } else { return lang.IFn_Cast(A_arbace_classes_native_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_36.GetRawRoot__O()).Invoke_O__O(b__1078000125__6), nil) } } else { var vec__1078000133__4 any = lang.IFn_Cast(A_arbace_classes_native_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1078000123__3); var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000133__4, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000133__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000122); return lang.IFn_Cast(A_arbace_classes_native_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(s__5, lang.IFn_Cast(A_arbace_classes_native_A_const_103.GetRawRoot__O()).Invoke_O__O(lb__6)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_38.GetRawRoot__O()).Invoke_O__O(s__1078000123__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A) Ctor_O_I_O(c__b__1078000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000125 = c__b__1078000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A) Invoke_O__O(self any) any { { var i__1078000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000129__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000124__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000129__2, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000129__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_33.GetRawRoot__O()); var tmp3 any = t.F_b__1078000125; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(s__3, lang.IFn_Cast(A_arbace_classes_native_A_const_103.GetRawRoot__O()).Invoke_O__O(lb__4))); i__1078000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000124__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_compile_fn_fn__1078000138_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000138_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000138_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000138_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :152:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000138_A) Invoke_O_O__O(self, p1__1078000119_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_native_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_host, p1__1078000119_SHARP___1) }
func A_arbace_classes_native_compile_fn_fn__1078000140_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000140_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000140_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000140_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :153:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000140_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(s__1, lang.IFn_Cast(t.F_host).Invoke_O__O(s__1)) }
func A_arbace_classes_native_compile_fn_fn__1078000142_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_native_compile_fn_fn__1078000142_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :154:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_A) Ctor_O_O_O_O_O_O(c__form, c__host, c__ns, c__syms, c__cname, c__captured any) { t.F_form = c__form; t.F_host = c__host; t.F_ns = c__ns; t.F_syms = c__syms; t.F_cname = c__cname; t.F_captured = c__captured }
//line :154:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											lang.IFn_Cast(A_arbace_classes_native_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_51, t.F_ns))
//line :154:1
	{ tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_94.GetRawRoot__O()); var tmp6 any; var t__2 any = t.F_cname; t.F_cname = nil; tmp6 = t__2; var tmp7 any = tmp6; var tmp8 any; var t__3 any = t.F_form; t.F_form = nil; tmp8 = t__3; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_captured; t.F_captured = nil; tmp10 = t__4; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10))) }
//line :154:1
		return nil }()
		lang.IFn_Cast(A_arbace_classes_native_A_const_47.GetRawRoot__O()).Invoke__O()
//line :154:1
		if tmp11 != nil { panic(tmp11) } }; return nil }(); if tmp12 != nil { if lang.ExceptionInfo_InstanceOf(tmp12) { var e__3 *lang.ExceptionInfo = lang.ExceptionInfo_Cast(tmp12); var u__4 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_66.GetRawRoot__O()); var tmp14 any = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_New(); var tmp15 *jrt.Class
			var fncls__19 /*line :154:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class





			if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class = fncls__19d; tmp15 = fncls__19d } else { tmp15 = fncls__19 }; var tmp16 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_98.GetRawRoot__O()); var tmp18 any = A_arbace_classes_native_A_const_99.GetRawRoot__O(); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_100.GetRawRoot__O()); var tmp20 any = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_New(); var tmp21 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class = fncls__20d; tmp21 = fncls__20d } else { tmp21 = fncls__20 }; u__4 = tmp13.Invoke_O_O__O(tmp16, tmp17.Invoke_O_O__O(tmp18, tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), e__3.Ref())))
			var tmp22 any; var and__1927000168__auto____5 any = u__4; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_95.GetRawRoot__O()); var tmp24 any; var t__5 any = t.F_host; t.F_host = nil; tmp24 = t__5; and__1927000168__auto____6 = tmp23.Invoke_O_O__O(tmp24, u__4); if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_32.GetRawRoot__O()); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_66.GetRawRoot__O()); var tmp27 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, u__4)); var tmp28 any; var t__6 any = t.F_syms; t.F_syms = nil; tmp28 = t__6; tmp22 = tmp25.Invoke_O__O(tmp26.Invoke_O_O__O(tmp27, tmp28)) } else { tmp22 = and__1927000168__auto____6 } } else { tmp22 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp22) { tmp1 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_classes_native_A_const_101, u__4) } else { panic(jrt.Thrown(Up_ExceptionInfo_Throwable(e__3))) } } else {
//line :154:1
				panic(tmp12) } }; return tmp1 }





func A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_New() *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A) Ctor() {}
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A) Invoke_O_O__O(self, p1__1078000120_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_native_A_const_96; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_native_A_const_97.GetRawRoot__O()).Invoke_O__O(p1__1078000120_SHARP___1)) }
//line :160:1
func A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_New() *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A) Ctor() {}
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A) Invoke_O_O__O(self, p1__1078000121_SHARP___1 any) any { return jrt.Throwable_Cast(p1__1078000121_SHARP___1).GetCause__Throwable() }


























































































type A_arbace_classes_native_A struct{ jrt.Object }

var A_arbace_classes_native_A_const_pool *jrt.RefArray

var A_arbace_classes_native_A_const_0 *lang.Var

var A_arbace_classes_native_A_const_1 *lang.Var

var A_arbace_classes_native_A_const_2 any

var A_arbace_classes_native_A_const_3 any

var A_arbace_classes_native_A_const_4 any

var A_arbace_classes_native_A_const_5 any

var A_arbace_classes_native_A_const_6 any

var A_arbace_classes_native_A_const_7 *lang.Var

var A_arbace_classes_native_A_const_8 *lang.Var

var A_arbace_classes_native_A_const_9 *lang.Var

var A_arbace_classes_native_A_const_10 any

var A_arbace_classes_native_A_const_11 *lang.Var

var A_arbace_classes_native_A_const_12 *lang.Var

var A_arbace_classes_native_A_const_13 *lang.Var

var A_arbace_classes_native_A_const_14 *lang.Var

var A_arbace_classes_native_A_const_15 *lang.Var

var A_arbace_classes_native_A_const_16 *lang.Keyword

var A_arbace_classes_native_A_const_17 *lang.Var

var A_arbace_classes_native_A_const_18 *lang.Var

var A_arbace_classes_native_A_const_19 *lang.Var

var A_arbace_classes_native_A_const_20 *lang.Keyword

var A_arbace_classes_native_A_const_21 *lang.Var

var A_arbace_classes_native_A_const_22 *lang.Keyword

var A_arbace_classes_native_A_const_23 *lang.Var

var A_arbace_classes_native_A_const_24 *lang.Keyword

var A_arbace_classes_native_A_const_25 *lang.Var

var A_arbace_classes_native_A_const_26 *lang.Keyword

var A_arbace_classes_native_A_const_27 *lang.Var

var A_arbace_classes_native_A_const_28 *lang.Var

var A_arbace_classes_native_A_const_29 *lang.Var

var A_arbace_classes_native_A_const_30 *lang.Var

var A_arbace_classes_native_A_const_31 *lang.Var

var A_arbace_classes_native_A_const_32 *lang.Var

var A_arbace_classes_native_A_const_33 *lang.Var

var A_arbace_classes_native_A_const_34 *lang.Var

var A_arbace_classes_native_A_const_35 *lang.Var

var A_arbace_classes_native_A_const_36 *lang.Var

var A_arbace_classes_native_A_const_37 *lang.Var

var A_arbace_classes_native_A_const_38 *lang.Var

var A_arbace_classes_native_A_const_39 *lang.Var

var A_arbace_classes_native_A_const_40 *lang.Keyword

var A_arbace_classes_native_A_const_41 *lang.Var

var A_arbace_classes_native_A_const_42 *lang.Var

var A_arbace_classes_native_A_const_43 *lang.Var

var A_arbace_classes_native_A_const_44 any

var A_arbace_classes_native_A_const_45 any

var A_arbace_classes_native_A_const_46 *lang.Var

var A_arbace_classes_native_A_const_47 *lang.Var

var A_arbace_classes_native_A_const_48 *lang.Var

var A_arbace_classes_native_A_const_49 *lang.Var

var A_arbace_classes_native_A_const_50 *lang.Var

var A_arbace_classes_native_A_const_51 *lang.Var

var A_arbace_classes_native_A_const_52 *lang.Keyword

var A_arbace_classes_native_A_const_53 *lang.Var

var A_arbace_classes_native_A_const_54 *lang.Var

var A_arbace_classes_native_A_const_55 *lang.Var

var A_arbace_classes_native_A_const_56 *jrt.Class

var A_arbace_classes_native_A_const_57 *lang.Var

var A_arbace_classes_native_A_const_58 *lang.Var

var A_arbace_classes_native_A_const_59 *lang.Var

var A_arbace_classes_native_A_const_60 *lang.Var

var A_arbace_classes_native_A_const_61 *lang.Keyword

var A_arbace_classes_native_A_const_62 *lang.Keyword

var A_arbace_classes_native_A_const_63 *lang.Var

var A_arbace_classes_native_A_const_64 *lang.Var

var A_arbace_classes_native_A_const_65 *lang.Var

var A_arbace_classes_native_A_const_66 *lang.Var

var A_arbace_classes_native_A_const_67 any

var A_arbace_classes_native_A_const_68 any

var A_arbace_classes_native_A_const_69 *lang.Var

var A_arbace_classes_native_A_const_70 *lang.Keyword

var A_arbace_classes_native_A_const_71 *lang.Var

var A_arbace_classes_native_A_const_72 any

var A_arbace_classes_native_A_const_73 *lang.Var

var A_arbace_classes_native_A_const_74 *lang.Var

var A_arbace_classes_native_A_const_75 *lang.Keyword

var A_arbace_classes_native_A_const_76 *lang.Keyword

var A_arbace_classes_native_A_const_77 *lang.Keyword

var A_arbace_classes_native_A_const_78 *lang.Var

var A_arbace_classes_native_A_const_79 any

var A_arbace_classes_native_A_const_80 *lang.Var

var A_arbace_classes_native_A_const_81 *lang.Var

var A_arbace_classes_native_A_const_82 *lang.Keyword

var A_arbace_classes_native_A_const_83 *lang.Var

var A_arbace_classes_native_A_const_84 any

var A_arbace_classes_native_A_const_85 *lang.Var

var A_arbace_classes_native_A_const_86 *lang.Var

var A_arbace_classes_native_A_const_87 any

var A_arbace_classes_native_A_const_88 any

var A_arbace_classes_native_A_const_89 any

var A_arbace_classes_native_A_const_90 any

var A_arbace_classes_native_A_const_91 *lang.Var

var A_arbace_classes_native_A_const_92 *lang.Var

var A_arbace_classes_native_A_const_93 *lang.Var

var A_arbace_classes_native_A_const_94 *lang.Var

var A_arbace_classes_native_A_const_95 *lang.Var

var A_arbace_classes_native_A_const_96 *lang.Keyword

var A_arbace_classes_native_A_const_97 *lang.Var

var A_arbace_classes_native_A_const_98 *lang.Var

var A_arbace_classes_native_A_const_99 *lang.Var

var A_arbace_classes_native_A_const_100 *lang.Var

var A_arbace_classes_native_A_const_101 *lang.Keyword

var A_arbace_classes_native_A_const_102 *lang.Var

var A_arbace_classes_native_A_const_103 *lang.Var

var A_arbace_classes_native_A_const_104 *lang.Var

var A_arbace_classes_native_A_const_105 any

var A_arbace_classes_native_A_const_106 any

var A_arbace_classes_native_A_init jrt.ClassInit

func A_arbace_classes_native_A_Init() { if !A_arbace_classes_native_A_init.Done() { A_arbace_classes_native_A_init.Run(A_arbace_classes_native_A_clinit) } }

func A_arbace_classes_native_A_clinit() { A_arbace_classes_native_A_clinit_p0(); A_arbace_classes_native_A_clinit_p1(); A_arbace_classes_native_A_clinit_p2(); A_arbace_classes_native_A_clinit_p3(); A_arbace_classes_native_A_clinit_p4(); A_arbace_classes_native_A_clinit_p5(); A_arbace_classes_native_A_clinit_p6(); A_arbace_classes_native_A_clinit_p7(); A_arbace_classes_native_A_clinit_p8() }

func A_arbace_classes_native_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_native_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 148); A_arbace_classes_native_A_const_0 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[41]); A_arbace_classes_native_A_const_1 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[42]); A_arbace_classes_native_A_const_2 = A_arbace_classes_native_A_const_pool.A[43]; A_arbace_classes_native_A_const_3 = A_arbace_classes_native_A_const_pool.A[44]; A_arbace_classes_native_A_const_4 = A_arbace_classes_native_A_const_pool.A[45]; A_arbace_classes_native_A_const_5 = A_arbace_classes_native_A_const_pool.A[46]; A_arbace_classes_native_A_const_6 = A_arbace_classes_native_A_const_pool.A[47]; A_arbace_classes_native_A_const_7 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[48]); A_arbace_classes_native_A_const_8 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[49]); A_arbace_classes_native_A_const_9 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[50]); A_arbace_classes_native_A_const_10 = A_arbace_classes_native_A_const_pool.A[51]; A_arbace_classes_native_A_const_11 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[52]) }

func A_arbace_classes_native_A_clinit_p1() { A_arbace_classes_native_A_const_12 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[53]); A_arbace_classes_native_A_const_13 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[54]); A_arbace_classes_native_A_const_14 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[55]); A_arbace_classes_native_A_const_15 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[56]); A_arbace_classes_native_A_const_16 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[57]); A_arbace_classes_native_A_const_17 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[58]); A_arbace_classes_native_A_const_18 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[59]); A_arbace_classes_native_A_const_19 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[60]); A_arbace_classes_native_A_const_20 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[61]); A_arbace_classes_native_A_const_21 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[62]); A_arbace_classes_native_A_const_22 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[63]); A_arbace_classes_native_A_const_23 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[64]) }

func A_arbace_classes_native_A_clinit_p2() { A_arbace_classes_native_A_const_24 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[65]); A_arbace_classes_native_A_const_25 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[66]); A_arbace_classes_native_A_const_26 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[67]); A_arbace_classes_native_A_const_27 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[68]); A_arbace_classes_native_A_const_28 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[69]); A_arbace_classes_native_A_const_29 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[70]); A_arbace_classes_native_A_const_30 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[71]); A_arbace_classes_native_A_const_31 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[72]); A_arbace_classes_native_A_const_32 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[73]); A_arbace_classes_native_A_const_33 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[74]); A_arbace_classes_native_A_const_34 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[75]); A_arbace_classes_native_A_const_35 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[76]) }

func A_arbace_classes_native_A_clinit_p3() { A_arbace_classes_native_A_const_36 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[77]); A_arbace_classes_native_A_const_37 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[78]); A_arbace_classes_native_A_const_38 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[79]); A_arbace_classes_native_A_const_39 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[80]); A_arbace_classes_native_A_const_40 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[81]); A_arbace_classes_native_A_const_41 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[82]); A_arbace_classes_native_A_const_42 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[83]); A_arbace_classes_native_A_const_43 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[84]); A_arbace_classes_native_A_const_44 = A_arbace_classes_native_A_const_pool.A[85]; A_arbace_classes_native_A_const_45 = A_arbace_classes_native_A_const_pool.A[86]; A_arbace_classes_native_A_const_46 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[87]); A_arbace_classes_native_A_const_47 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[88]) }

func A_arbace_classes_native_A_clinit_p4() { A_arbace_classes_native_A_const_48 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[89]); A_arbace_classes_native_A_const_49 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[90]); A_arbace_classes_native_A_const_50 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[91]); A_arbace_classes_native_A_const_51 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[92]); A_arbace_classes_native_A_const_52 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[93]); A_arbace_classes_native_A_const_53 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[94]); A_arbace_classes_native_A_const_54 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[95]); A_arbace_classes_native_A_const_55 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[96]); A_arbace_classes_native_A_const_56 = jrt.Class_Cast(A_arbace_classes_native_A_const_pool.A[97]); A_arbace_classes_native_A_const_57 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[98]); A_arbace_classes_native_A_const_58 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[99]); A_arbace_classes_native_A_const_59 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[100]) }

func A_arbace_classes_native_A_clinit_p5() { A_arbace_classes_native_A_const_60 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[101]); A_arbace_classes_native_A_const_61 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[102]); A_arbace_classes_native_A_const_62 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[103]); A_arbace_classes_native_A_const_63 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[104]); A_arbace_classes_native_A_const_64 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[105]); A_arbace_classes_native_A_const_65 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[106]); A_arbace_classes_native_A_const_66 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[107]); A_arbace_classes_native_A_const_67 = A_arbace_classes_native_A_const_pool.A[108]; A_arbace_classes_native_A_const_68 = A_arbace_classes_native_A_const_pool.A[109]; A_arbace_classes_native_A_const_69 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[110]); A_arbace_classes_native_A_const_70 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[111]); A_arbace_classes_native_A_const_71 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[112]) }

func A_arbace_classes_native_A_clinit_p6() { A_arbace_classes_native_A_const_72 = A_arbace_classes_native_A_const_pool.A[113]; A_arbace_classes_native_A_const_73 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[114]); A_arbace_classes_native_A_const_74 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[115]); A_arbace_classes_native_A_const_75 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[116]); A_arbace_classes_native_A_const_76 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[117]); A_arbace_classes_native_A_const_77 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[118]); A_arbace_classes_native_A_const_78 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[119]); A_arbace_classes_native_A_const_79 = A_arbace_classes_native_A_const_pool.A[120]; A_arbace_classes_native_A_const_80 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[121]); A_arbace_classes_native_A_const_81 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[122]); A_arbace_classes_native_A_const_82 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[123]); A_arbace_classes_native_A_const_83 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[124]) }

func A_arbace_classes_native_A_clinit_p7() { A_arbace_classes_native_A_const_84 = A_arbace_classes_native_A_const_pool.A[125]; A_arbace_classes_native_A_const_85 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[126]); A_arbace_classes_native_A_const_86 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[127]); A_arbace_classes_native_A_const_87 = A_arbace_classes_native_A_const_pool.A[128]; A_arbace_classes_native_A_const_88 = A_arbace_classes_native_A_const_pool.A[129]; A_arbace_classes_native_A_const_89 = A_arbace_classes_native_A_const_pool.A[130]; A_arbace_classes_native_A_const_90 = A_arbace_classes_native_A_const_pool.A[131]; A_arbace_classes_native_A_const_91 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[132]); A_arbace_classes_native_A_const_92 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[133]); A_arbace_classes_native_A_const_93 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[134]); A_arbace_classes_native_A_const_94 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[135]); A_arbace_classes_native_A_const_95 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[136]); A_arbace_classes_native_A_const_96 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[137]) }

func A_arbace_classes_native_A_clinit_p8() { A_arbace_classes_native_A_const_97 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[138]); A_arbace_classes_native_A_const_98 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[139]); A_arbace_classes_native_A_const_99 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[140]); A_arbace_classes_native_A_const_100 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[141]); A_arbace_classes_native_A_const_101 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[142]); A_arbace_classes_native_A_const_102 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[143]); A_arbace_classes_native_A_const_103 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[144]); A_arbace_classes_native_A_const_104 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[145]); A_arbace_classes_native_A_const_105 = A_arbace_classes_native_A_const_pool.A[146]; A_arbace_classes_native_A_const_106 = A_arbace_classes_native_A_const_pool.A[147] }

func A_arbace_classes_native_A_New() *A_arbace_classes_native_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_A) Ctor() {}

func (t *A_arbace_classes_native_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_A_class }

func (t *A_arbace_classes_native_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_A); return ok }

func A_arbace_classes_native_A_Cast(x any) *A_arbace_classes_native_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_A_class)) }; return v }



type A_arbace_classes_native_compile_and_load_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A struct{ j2g_header uint64; F_s__1078000016, F_iter__1078000015 any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A struct{ j2g_header uint64; F_b__1078000018 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_deftype_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_fn__1078000049_A struct{ j2g_header uint64; F_form, F_ns any }

var A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000138_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000140_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_A struct{ j2g_header uint64; F_form, F_host, F_ns, F_syms, F_cname, F_captured any }

var A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A struct{ j2g_header uint64; F_s__1078000123, F_iter__1078000122 any }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A struct{ j2g_header uint64; F_b__1078000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A struct{ j2g_header uint64; F_s__1078000033, F_iter__1078000032 any }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1078000035, F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000004_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000004_A_New() *A_arbace_classes_native_eval1078000004_A { t := &A_arbace_classes_native_eval1078000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000004_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000004_A_class }

func (t *A_arbace_classes_native_eval1078000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000004_A); return ok }

func A_arbace_classes_native_eval1078000004_A_Cast(x any) *A_arbace_classes_native_eval1078000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000004_A_class)) }; return v }



type A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000008_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000008_A_New() *A_arbace_classes_native_eval1078000008_A { t := &A_arbace_classes_native_eval1078000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000008_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000008_A_class }

func (t *A_arbace_classes_native_eval1078000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000008_A); return ok }

func A_arbace_classes_native_eval1078000008_A_Cast(x any) *A_arbace_classes_native_eval1078000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000008_A_class)) }; return v }



type A_arbace_classes_native_eval1078000008_fn__1078000009_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class *jrt.Class



type A_arbace_classes_native_field_names_A struct{ j2g_header uint64 }

var A_arbace_classes_native_field_names_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000097_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000113_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A struct{ j2g_header uint64; F_s__1078000075, F_iter__1078000074, F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A struct{ j2g_header uint64; F_b__1078000077, F_typed any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A struct{ j2g_header uint64; F_s__1078000103, F_rcv, F_iter__1078000102 any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A struct{ j2g_header uint64; F_b__1078000105, F_rcv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_typed__1078000072_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_A struct{ j2g_header uint64 }

var A_arbace_classes_native_local_class_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000054_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000054_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000056_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000056_A_fn_class *jrt.Class



type A_arbace_classes_native_public_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_native_public_class_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_native_type_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_type_form_A_fn_class *jrt.Class
