//line aot_arbace_classes_native.ae:1
package aot_arbace_classes_native

import (
	"arbace/aot_arbace_classes_lower"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New() *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_native_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_classes_native_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_native_A_const_1, A_arbace_classes_native_A_const_2, A_arbace_classes_native_A_const_3, A_arbace_classes_native_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_native_eval1078000008_fn__1078000009_A_New() *A_arbace_classes_native_eval1078000008_fn__1078000009_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000008_fn__1078000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_classes_native_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_classes_native_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_native_A_const_10.GetRawRoot__O(), A_arbace_classes_native_A_const_11) }



































func A_arbace_classes_native_symbols_A_New() *A_arbace_classes_native_symbols_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_symbols_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_native_symbols_A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_native_symbols_A) Invoke_O_O__O(self, form__0 any) any {


	var tmp1 any; var root_22 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_24 lang.IFn
	if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = form__0; if linked_23 == nil { tmp1 = ifn_24.Invoke_O__O(arg_25) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_22, arg_25) }
//line :40:1
	if jrt.J2g_Truth(tmp1) { return lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, form__0)) } else { var tmp2 any; var or__1927000174__auto____2 any; var root_26 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_28 lang.IFn

		if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = form__0; if linked_27 == nil { or__1927000174__auto____2 = ifn_28.Invoke_O__O(arg_29) } else { or__1927000174__auto____2 = linked_27.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_26, arg_29) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_30 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = form__0; if linked_31 == nil { or__1927000174__auto____3 = ifn_32.Invoke_O__O(arg_33) } else { or__1927000174__auto____3 = linked_31.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_30, arg_33) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_34 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = form__0; if linked_35 == nil { tmp2 = ifn_36.Invoke_O__O(arg_37) } else { tmp2 = linked_35.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_34, arg_37) } } }
//line :40:1
		if jrt.J2g_Truth(tmp2) {

			var root_38 any = A_arbace_classes_native_A_const_16.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var arg_42 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_43 any; var root_44 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var arg_48 any = form__0; if linked_45 == nil { arg_43 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { arg_43 = linked_45.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }; if linked_39 == nil { return ifn_40.Invoke_O_O_O__O(arg_41, arg_42, arg_43) } else { return linked_39.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_38, arg_41, arg_42, arg_43) } } else {
//line :40:1
				var tmp3 any; var root_49 any = A_arbace_classes_native_A_const_20.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_51 lang.IFn


				if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = form__0; if linked_50 == nil { tmp3 = ifn_51.Invoke_O__O(arg_52) } else { tmp3 = linked_50.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_49, arg_52) }
//line :40:1
				if jrt.J2g_Truth(tmp3) {


					var root_53 any = A_arbace_classes_native_A_const_16.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var arg_57 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_58 any; var root_59 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var arg_63 any = lang.IFn_Cast(A_arbace_classes_native_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_22.GetRawRoot__O(), form__0); if linked_60 == nil { arg_58 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { arg_58 = linked_60.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; if linked_54 == nil { return ifn_55.Invoke_O_O_O__O(arg_56, arg_57, arg_58) } else { return linked_54.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_53, arg_56, arg_57, arg_58) } } else {
//line :40:1
						if A_arbace_classes_native_A_const_23 != nil { return lang.PersistentHashSet_EMPTY.Ref() } else { return nil
						}
					}
			}
	}
}
func A_arbace_classes_native_form_vars_A_New() *A_arbace_classes_native_form_vars_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_native_form_vars_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_native_form_vars_A) Invoke_O_O_O__O(self, ns__0, forms__1 any) any {






	var root_69 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var root_78 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var arg_82 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); if linked_79 == nil { arg_76 = ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { arg_76 = linked_79.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_78, arg_81, arg_82) }; var arg_77 any; var iter__1927001039__auto____3 any; var fnbody__334 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_New_O(ns__0); var tmp1 *jrt.Class; var fncls__333 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_fn_class
	if fncls__333 == nil { var fncls__333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__334); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_fn_class = fncls__333d; tmp1 = fncls__333d } else { tmp1 = fncls__333 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__334, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_335 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, A_arbace_classes_native_symbols_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = forms__1; if linked_336 == nil { tmp3 = ifn_337.Invoke_O__O(arg_338) } else { tmp3 = linked_336.(*A_arbace_classes_native_symbols_A).Invoke_O_O__O(root_335, arg_338) }; arg_77 = tmp2.Invoke_O__O(tmp3)
//line :53:1
	if linked_74 == nil { arg_72 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { arg_72 = linked_74.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_69, arg_72) } }
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_New_O(p0 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A{}; t.Ctor_O(p0); return t }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A) Invoke_O_O__O(self, s__1078000014__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__332 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_New_O_O_O(t.F_ns, s__1078000014__1, self); var tmp2 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__332); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_fn_class = fncls__331d; tmp2 = fncls__331d } else { tmp2 = fncls__331 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__332, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :54:1
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A) Ctor_O_O_O(c__ns, c__s__1078000014, c__iter__1078000013 any) { t.F_ns = c__ns; t.F_s__1078000014 = c__s__1078000014; t.F_iter__1078000013 = c__iter__1078000013 }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A) Invoke_O__O(self any) any { { var s__1078000014__1 any; var t_ any = t.F_s__1078000014; t.F_s__1078000014 = nil; s__1078000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_83 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = s__1078000014__1; if linked_84 == nil { temp__1927000414__auto____2 = ifn_85.Invoke_O__O(arg_86) } else { temp__1927000414__auto____2 = linked_84.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_83, arg_86) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_87 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__1078000014__3; if linked_88 == nil { tmp1 = ifn_89.Invoke_O__O(arg_90) } else { tmp1 = linked_88.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_91 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = s__1078000014__3; if linked_92 == nil { c__1927001037__auto____4 = ifn_93.Invoke_O__O(arg_94) } else { c__1927001037__auto____4 = linked_92.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_91, arg_94) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000016__6 any; var root_95 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_96 == nil { b__1078000016__6 = ifn_97.Invoke_O__O(arg_98) } else { b__1078000016__6 = linked_96.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_95, arg_98) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__198 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_New_O_O_I_O(b__1078000016__6, t.F_ns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__197 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_fn_class; if fncls__197 == nil { var fncls__197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__198); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_fn_class = fncls__197d; tmp3 = fncls__197d } else { tmp3 = fncls__197 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__198, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_199 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_204 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = b__1078000016__6; if linked_205 == nil { arg_202 = ifn_206.Invoke_O__O(arg_207) } else { arg_202 = linked_205.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_204, arg_207) }; var arg_203 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000013); var tmp5 any; var root_208 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = s__1078000014__3; if linked_209 == nil { tmp5 = ifn_210.Invoke_O__O(arg_211) } else { tmp5 = linked_209.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_208, arg_211) }; arg_203 = tmp4.Invoke_O__O(tmp5); if linked_200 == nil { return ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { return linked_200.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) } } else { var root_212 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var root_217 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = b__1078000016__6; if linked_218 == nil { arg_215 = ifn_219.Invoke_O__O(arg_220) } else { arg_215 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_217, arg_220) }; var arg_216 any; if linked_213 == nil { return ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { return linked_213.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) } } } else { var s__4 any; var root_221 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__1078000014__3; if linked_222 == nil { s__4 = ifn_223.Invoke_O__O(arg_224) } else { s__4 = linked_222.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_221, arg_224) }; var v__5 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__231 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_New_O_O(t.F_ns, s__4); var tmp7 *jrt.Class; var fncls__230 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_fn_class
															if fncls__230 == nil { var fncls__230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__231); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_fn_class = fncls__230d; tmp7 = fncls__230d } else { tmp7 = fncls__230 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__231, tmp7, nil); v__5 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :54:1
	var tmp8 any; var and__1927000168__auto____6 any; var root_232 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_234 lang.IFn


	if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = v__5; if linked_233 == nil { and__1927000168__auto____6 = ifn_234.Invoke_O__O(arg_235) } else { and__1927000168__auto____6 = linked_233.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_232, arg_235) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_236 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var and__1927000168__auto____7 bool; var tmp9 any; var root_240 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var root_244 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = lang.Var_Cast(v__5).F_ns.Ref(); if linked_245 == nil { arg_243 = ifn_246.Invoke_O__O(arg_247) } else { arg_243 = linked_245.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_244, arg_247) }; if linked_241 == nil { tmp9 = ifn_242.Invoke_O__O(arg_243) } else { tmp9 = linked_241.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_240, arg_243) }; and__1927000168__auto____7 = lang.Util_Equiv_O_O__Z_NoInit(Lit_34, tmp9); if and__1927000168__auto____7 {
			var root_248 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = A_arbace_classes_native_A_const_53; var arg_252 any; var root_253 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = s__4; if linked_254 == nil { arg_252 = ifn_255.Invoke_O__O(arg_256) } else { arg_252 = linked_254.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_253, arg_256) }; if linked_249 == nil { arg_239 = ifn_250.Invoke_O_O__O(arg_251, arg_252) } else { arg_239 = linked_249.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_248, arg_251, arg_252) } } else {
//line :58:1
				arg_239 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if linked_237 == nil { tmp8 = ifn_238.Invoke_O__O(arg_239) } else { tmp8 = linked_237.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_236, arg_239) } } else {
//line :57:1
					tmp8 = and__1927000168__auto____6 }
//line :54:1
	if jrt.J2g_Truth(tmp8) { var m__6 any = lang.RT_Meta_O__IPersistentMap_NoInit(v__5); var tag__7 any = A_arbace_classes_native_A_const_40.Invoke_O__O(m__6); var root_257 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any; var tmp10 any; var root_262 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_264 lang.IFn







		if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = s__4; var arg_266 any; if linked_263 == nil { tmp10 = ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { tmp10 = linked_263.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }
//line :54:1
		var tmp11 any = tmp10; var tmp12 any; var root_267 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_269 lang.IFn







		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any; var root_271 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = lang.Var_Cast(v__5).F_ns.Ref(); if linked_272 == nil { arg_270 = ifn_273.Invoke_O__O(arg_274) } else { arg_270 = linked_272.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_271, arg_274) }; if linked_268 == nil { tmp12 = ifn_269.Invoke_O__O(arg_270) } else { tmp12 = linked_268.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_267, arg_270) }
//line :54:1
		var tmp13 any = tmp12; var tmp14 any; var root_275 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_277 lang.IFn







		if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = lang.Var_Cast(v__5).F_sym.Ref(); if linked_276 == nil { tmp14 = ifn_277.Invoke_O__O(arg_278) } else { tmp14 = linked_276.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_275, arg_278) }
//line :54:1
		var tmp15 any = tmp14; var tmp16 any; var G__1078000026__8_ any; var root_279 any = A_arbace_classes_native_A_const_43.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_281 lang.IFn








		if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = m__6; var arg_283 any = A_arbace_classes_native_A_const_55; if linked_280 == nil { G__1078000026__8_ = ifn_281.Invoke_O_O__O(arg_282, arg_283) } else { G__1078000026__8_ = linked_280.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_279, arg_282, arg_283) }
//line :54:1
		var G__1078000026__9_ any; var tmp17 any; var or__1927000174__auto____9 any; var root_284 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_286 lang.IFn









		if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = tag__7; if linked_285 == nil { or__1927000174__auto____9 = ifn_286.Invoke_O__O(arg_287) } else { or__1927000174__auto____9 = linked_285.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_284, arg_287) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp17 = or__1927000174__auto____9 } else { var root_288 any = A_arbace_classes_native_A_const_45.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = tag__7; if linked_289 == nil { tmp17 = ifn_290.Invoke_O__O(arg_291) } else { tmp17 = linked_289.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_288, arg_291) } }
//line :63:1
		if jrt.J2g_Truth(tmp17) {
			var root_292 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = G__1078000026__8_; var arg_296 any = A_arbace_classes_native_A_const_40; var arg_297 any = tag__7; if linked_293 == nil { G__1078000026__9_ = ifn_294.Invoke_O_O_O__O(arg_295, arg_296, arg_297) } else { G__1078000026__9_ = linked_293.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_292, arg_295, arg_296, arg_297) } } else {
//line :63:1
				G__1078000026__9_ = G__1078000026__8_ }
//line :54:1
		var G__1078000026__10_ any








		if jrt.Class_InstanceOf(tag__7) {

			var root_298 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = G__1078000026__9_; var arg_302 any = A_arbace_classes_native_A_const_40; var arg_303 any; var root_304 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = jrt.NN(jrt.Class_Cast(tag__7)).GetName__String().Ref(); if linked_305 == nil { arg_303 = ifn_306.Invoke_O__O(arg_307) } else { arg_303 = linked_305.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_304, arg_307) }; if linked_299 == nil { G__1078000026__10_ = ifn_300.Invoke_O_O_O__O(arg_301, arg_302, arg_303) } else { G__1078000026__10_ = linked_299.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_298, arg_301, arg_302, arg_303) } } else {
//line :63:1
				G__1078000026__10_ = G__1078000026__9_ }; var tmp18 any; var and__1927000168__auto____11 any; var root_308 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_310 lang.IFn


		if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__6); if linked_309 == nil { and__1927000168__auto____11 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____11 = linked_309.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_312 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var arg_316 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__6); if linked_313 == nil { tmp18 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp18 = linked_313.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_312, arg_315, arg_316) } } else { tmp18 = and__1927000168__auto____11 }
//line :63:1
		if jrt.J2g_Truth(tmp18) {


			var root_317 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = G__1078000026__10_; var arg_321 any = A_arbace_classes_native_A_const_48; var arg_322 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__6); if linked_318 == nil { tmp16 = ifn_319.Invoke_O_O_O__O(arg_320, arg_321, arg_322) } else { tmp16 = linked_318.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_317, arg_320, arg_321, arg_322) } } else {
//line :63:1
				tmp16 = G__1078000026__10_ }
//line :54:1
		arg_260 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp11, tmp13, tmp15, tmp16); var arg_261 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__1078000013); var tmp20 any; var root_323 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = s__1078000014__3; if linked_324 == nil { tmp20 = ifn_325.Invoke_O__O(arg_326) } else { tmp20 = linked_324.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_323, arg_326) }; arg_261 = tmp19.Invoke_O__O(tmp20); if linked_258 == nil { return ifn_259.Invoke_O_O__O(arg_260, arg_261) } else { return linked_258.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_257, arg_260, arg_261) } } else { var tmp21 any; var root_327 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = s__1078000014__3; if linked_328 == nil { tmp21 = ifn_329.Invoke_O__O(arg_330) } else { tmp21 = linked_328.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_327, arg_330) }; s__1078000014__1 = tmp21; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :54:1
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A) Ctor_O_O_I_O(c__b__1078000016, c__ns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000016 = c__b__1078000016; t.F_ns = c__ns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :54:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A) Invoke_O__O(self any) any { { var i__1078000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000015__1)); var v__3 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__105 any = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_New_O_O(t.F_ns, s__2); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_fn_class
																	if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__105); A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__105, tmp3, nil); v__3 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :54:1
	var tmp4 any; var and__1927000168__auto____4 any; var root_106 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_108 lang.IFn


	if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = v__3; if linked_107 == nil { and__1927000168__auto____4 = ifn_108.Invoke_O__O(arg_109) } else { and__1927000168__auto____4 = linked_107.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_106, arg_109) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_110 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var and__1927000168__auto____5 bool; var tmp5 any; var root_114 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any; var root_118 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = lang.Var_Cast(v__3).F_ns.Ref(); if linked_119 == nil { arg_117 = ifn_120.Invoke_O__O(arg_121) } else { arg_117 = linked_119.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_118, arg_121) }; if linked_115 == nil { tmp5 = ifn_116.Invoke_O__O(arg_117) } else { tmp5 = linked_115.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_114, arg_117) }; and__1927000168__auto____5 = lang.Util_Equiv_O_O__Z_NoInit(Lit_34, tmp5); if and__1927000168__auto____5 {
			var root_122 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = A_arbace_classes_native_A_const_38; var arg_126 any; var root_127 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = s__2; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_127, arg_130) }; if linked_123 == nil { arg_113 = ifn_124.Invoke_O_O__O(arg_125, arg_126) } else { arg_113 = linked_123.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_122, arg_125, arg_126) } } else {
//line :58:1
				arg_113 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if linked_111 == nil { tmp4 = ifn_112.Invoke_O__O(arg_113) } else { tmp4 = linked_111.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_110, arg_113) } } else {
//line :57:1
					tmp4 = and__1927000168__auto____4 }
//line :54:1
	if jrt.J2g_Truth(tmp4) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(v__3); var tag__5 any = A_arbace_classes_native_A_const_40.Invoke_O__O(m__4); var root_131 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = t.F_b__1078000016; var arg_135 any; var tmp6 any; var root_136 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_138 lang.IFn







		if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = s__2; var arg_140 any; if linked_137 == nil { tmp6 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { tmp6 = linked_137.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }
//line :54:1
		var tmp7 any = tmp6; var tmp8 any; var root_141 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_143 lang.IFn







		if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var root_145 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = lang.Var_Cast(v__3).F_ns.Ref(); if linked_146 == nil { arg_144 = ifn_147.Invoke_O__O(arg_148) } else { arg_144 = linked_146.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_145, arg_148) }; if linked_142 == nil { tmp8 = ifn_143.Invoke_O__O(arg_144) } else { tmp8 = linked_142.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_141, arg_144) }
//line :54:1
		var tmp9 any = tmp8; var tmp10 any; var root_149 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_151 lang.IFn







		if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = lang.Var_Cast(v__3).F_sym.Ref(); if linked_150 == nil { tmp10 = ifn_151.Invoke_O__O(arg_152) } else { tmp10 = linked_150.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_149, arg_152) }
//line :54:1
		var tmp11 any = tmp10; var tmp12 any; var G__1078000022__6_ any; var root_153 any = A_arbace_classes_native_A_const_43.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_155 lang.IFn








		if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = m__4; var arg_157 any = A_arbace_classes_native_A_const_44; if linked_154 == nil { G__1078000022__6_ = ifn_155.Invoke_O_O__O(arg_156, arg_157) } else { G__1078000022__6_ = linked_154.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_153, arg_156, arg_157) }
//line :54:1
		var G__1078000022__7_ any; var tmp13 any; var or__1927000174__auto____7 any; var root_158 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_160 lang.IFn









		if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = tag__5; if linked_159 == nil { or__1927000174__auto____7 = ifn_160.Invoke_O__O(arg_161) } else { or__1927000174__auto____7 = linked_159.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_158, arg_161) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp13 = or__1927000174__auto____7 } else { var root_162 any = A_arbace_classes_native_A_const_45.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = tag__5; if linked_163 == nil { tmp13 = ifn_164.Invoke_O__O(arg_165) } else { tmp13 = linked_163.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_162, arg_165) } }
//line :63:1
		if jrt.J2g_Truth(tmp13) {
			var root_166 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = G__1078000022__6_; var arg_170 any = A_arbace_classes_native_A_const_40; var arg_171 any = tag__5; if linked_167 == nil { G__1078000022__7_ = ifn_168.Invoke_O_O_O__O(arg_169, arg_170, arg_171) } else { G__1078000022__7_ = linked_167.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_166, arg_169, arg_170, arg_171) } } else {
//line :63:1
				G__1078000022__7_ = G__1078000022__6_ }
//line :54:1
		var G__1078000022__8_ any








		if jrt.Class_InstanceOf(tag__5) {

			var root_172 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = G__1078000022__7_; var arg_176 any = A_arbace_classes_native_A_const_40; var arg_177 any; var root_178 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = jrt.NN(jrt.Class_Cast(tag__5)).GetName__String().Ref(); if linked_179 == nil { arg_177 = ifn_180.Invoke_O__O(arg_181) } else { arg_177 = linked_179.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_178, arg_181) }; if linked_173 == nil { G__1078000022__8_ = ifn_174.Invoke_O_O_O__O(arg_175, arg_176, arg_177) } else { G__1078000022__8_ = linked_173.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_172, arg_175, arg_176, arg_177) } } else {
//line :63:1
				G__1078000022__8_ = G__1078000022__7_ }; var tmp14 any; var and__1927000168__auto____9 any; var root_182 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_184 lang.IFn


		if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__4); if linked_183 == nil { and__1927000168__auto____9 = ifn_184.Invoke_O__O(arg_185) } else { and__1927000168__auto____9 = linked_183.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_186 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var arg_190 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__4); if linked_187 == nil { tmp14 = ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { tmp14 = linked_187.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_186, arg_189, arg_190) } } else { tmp14 = and__1927000168__auto____9 }
//line :63:1
		if jrt.J2g_Truth(tmp14) {


			var root_191 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = G__1078000022__8_; var arg_195 any = A_arbace_classes_native_A_const_48; var arg_196 any = A_arbace_classes_native_A_const_48.Invoke_O__O(m__4); if linked_192 == nil { tmp12 = ifn_193.Invoke_O_O_O__O(arg_194, arg_195, arg_196) } else { tmp12 = linked_192.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_191, arg_194, arg_195, arg_196) } } else {
//line :63:1
				tmp12 = G__1078000022__8_ }
//line :54:1
		arg_135 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp7, tmp9, tmp11, tmp12); if linked_132 == nil { ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { linked_132.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }; i__1078000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000015__1); continue L1 } else { i__1078000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000015__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_New_O_O(p0, p1 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A) Ctor_O_O(c__ns, c__s any) { t.F_ns = c__ns; t.F_s = c__s }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_99 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_ns_resolve_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var t_ any = t.F_ns; t.F_ns = nil; arg_102 = t_; var arg_103 any; var t__2 any = t.F_s; t.F_s = nil; arg_103 = t__2; if linked_100 == nil { tmp1 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { tmp1 = linked_100.(*aot_arbace_core.A_arbace_core_ns_resolve_A).Invoke_O_O_O__O(root_99, arg_102, arg_103) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }
//line :55:1
func A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_New_O_O(p0, p1 any) *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A{}; t.Ctor_O_O(p0, p1); return t }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A) Ctor_O_O(c__ns, c__s any) { t.F_ns = c__ns; t.F_s = c__s }
//line :55:1
func (t *A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_225 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_ns_resolve_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any; var t_ any = t.F_ns; t.F_ns = nil; arg_228 = t_; var arg_229 any; var t__2 any = t.F_s; t.F_s = nil; arg_229 = t__2; if linked_226 == nil { tmp1 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { tmp1 = linked_226.(*aot_arbace_core.A_arbace_core_ns_resolve_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }












func A_arbace_classes_native_compile_and_load_BANG__A_New() *A_arbace_classes_native_compile_and_load_BANG__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) Ctor() {}
//line :68:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) DoInvoke_O_O_O_O__O(self, ns__0, forms__1, p__1078000030__2 any) any { var map__1078000031__4 any = p__1078000030__2; var map__1078000031__5 any; if lang.ISeq_InstanceOf(map__1078000031__4) { var tmp1 any; var root_339 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = map__1078000031__4; if linked_340 == nil { tmp1 = ifn_341.Invoke_O__O(arg_342) } else { tmp1 = linked_340.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_339, arg_342) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_343 any = A_arbace_classes_native_A_const_58.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = map__1078000031__4; if linked_344 == nil { tmp2 = ifn_345.Invoke_O__O(arg_346) } else { tmp2 = linked_344.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_343, arg_346) }; map__1078000031__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_347 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = map__1078000031__4; if linked_348 == nil { tmp3 = ifn_349.Invoke_O__O(arg_350) } else { tmp3 = linked_348.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_347, arg_350) }; if jrt.J2g_Truth(tmp3) { var root_351 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = map__1078000031__4; if linked_352 == nil { map__1078000031__5 = ifn_353.Invoke_O__O(arg_354) } else { map__1078000031__5 = linked_352.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_351, arg_354) } } else { map__1078000031__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000031__5 = map__1078000031__4 }; var siblings__6 any = lang.RT_Get_O_O__O_NoInit(map__1078000031__5, A_arbace_classes_native_A_const_59); var loaded__7 any = lang.IFn_Cast(A_arbace_classes_native_A_const_60.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__1, A_arbace_classes_native_A_const_59, siblings__6); if



	jrt.J2g_Truth(A_arbace_classes_native_A_const_61.GetRawRoot__O()) {
		var root_362 any = A_arbace_classes_native_A_const_62.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_classes_native_A_const_61.GetRawRoot__O(); var arg_366 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var arg_367 any; var tmp4 any = A_arbace_classes_native_A_const_63; var tmp5 any; var root_368 any = A_arbace_classes_native_A_const_36.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_370 lang.IFn
		if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = ns__0; if linked_369 == nil { tmp5 = ifn_370.Invoke_O__O(arg_371) } else { tmp5 = linked_369.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_368, arg_371) }
//line :73:1
		var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_native_A_const_64; var tmp8 any; var root_372 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_374 lang.IFn

		if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = lang.IFn_Cast(A_arbace_classes_native_A_const_65.GetRawRoot__O()).Invoke__O(); var arg_376 any; var iter__1927001039__auto____8 any; var fnbody__453 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_New(); var tmp9 *jrt.Class; var fncls__452 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_fn_class
		if fncls__452 == nil { var fncls__452d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_fn_class = fncls__452d; tmp9 = fncls__452d } else { tmp9 = fncls__452 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__453, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp11 any; var root_454 any = A_arbace_classes_native_A_const_66.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_ns_imports_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = ns__0; if linked_455 == nil { tmp11 = ifn_456.Invoke_O__O(arg_457) } else { tmp11 = linked_455.(*aot_arbace_core.A_arbace_core_ns_imports_A).Invoke_O_O__O(root_454, arg_457) }; arg_376 = tmp10.Invoke_O__O(tmp11)
//line :75:1
		if linked_373 == nil { tmp8 = ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { tmp8 = linked_373.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) }
//line :73:1
		var tmp12 any = tmp8; var tmp13 any = A_arbace_classes_native_A_const_67; var tmp14 any; var root_458 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_460 lang.IFn





		if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = forms__1; if linked_459 == nil { tmp14 = ifn_460.Invoke_O__O(arg_461) } else { tmp14 = linked_459.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_458, arg_461) }
//line :73:1
		var tmp15 any = tmp14; var tmp16 any = A_arbace_classes_native_A_const_68; var tmp17 any; var root_462 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_464 lang.IFn






		if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var arg_466 any = loaded__7; if linked_463 == nil { tmp17 = ifn_464.Invoke_O_O__O(arg_465, arg_466) } else { tmp17 = linked_463.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_462, arg_465, arg_466) }
//line :73:1
		var tmp18 any = tmp17; var tmp19 any = A_arbace_classes_native_A_const_70; var tmp20 any; var root_467 any = A_arbace_classes_native_A_const_71.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, A_arbace_classes_native_form_vars_A_fn_class); var ifn_469 lang.IFn







		if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = ns__0; var arg_471 any = forms__1; if linked_468 == nil { tmp20 = ifn_469.Invoke_O_O__O(arg_470, arg_471) } else { tmp20 = linked_468.(*A_arbace_classes_native_form_vars_A).Invoke_O_O_O__O(root_467, arg_470, arg_471) }
//line :73:1
		arg_367 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp20)); if linked_363 == nil { ifn_364.Invoke_O_O_O__O(arg_365, arg_366, arg_367) } else { linked_363.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_362, arg_365, arg_366, arg_367) } }; return loaded__7 }


func A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_New() *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A) Ctor() {}
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A) Invoke_O_O__O(self, s__1078000034__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__451 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_New_O_O(s__1078000034__1, self); var tmp2 *jrt.Class; var fncls__450 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_fn_class; if fncls__450 == nil { var fncls__450d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__451); A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_fn_class = fncls__450d; tmp2 = fncls__450d } else { tmp2 = fncls__450 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__451, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :76:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A{}; t.Ctor_O_O(p0, p1); return t }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A) Ctor_O_O(c__s__1078000034, c__iter__1078000033 any) { t.F_s__1078000034 = c__s__1078000034; t.F_iter__1078000033 = c__iter__1078000033 }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A) Invoke_O__O(self any) any { { var s__1078000034__1 any; var t_ any = t.F_s__1078000034; t.F_s__1078000034 = nil; s__1078000034__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_380 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = s__1078000034__1; if linked_381 == nil { temp__1927000414__auto____2 = ifn_382.Invoke_O__O(arg_383) } else { temp__1927000414__auto____2 = linked_381.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_380, arg_383) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000034__3 any = temp__1927000414__auto____2; var tmp1 any; var root_384 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = s__1078000034__3; if linked_385 == nil { tmp1 = ifn_386.Invoke_O__O(arg_387) } else { tmp1 = linked_385.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_384, arg_387) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_388 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = s__1078000034__3; if linked_389 == nil { c__1927001037__auto____4 = ifn_390.Invoke_O__O(arg_391) } else { c__1927001037__auto____4 = linked_389.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_388, arg_391) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000036__6 any; var root_392 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_393 == nil { b__1078000036__6 = ifn_394.Invoke_O__O(arg_395) } else { b__1078000036__6 = linked_393.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_392, arg_395) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__406 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1078000036__6); var tmp3 *jrt.Class; var fncls__405 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_fn_class; if fncls__405 == nil { var fncls__405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__406); A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_fn_class = fncls__405d; tmp3 = fncls__405d } else { tmp3 = fncls__405 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__406, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_407 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var root_412 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = b__1078000036__6; if linked_413 == nil { arg_410 = ifn_414.Invoke_O__O(arg_415) } else { arg_410 = linked_413.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_412, arg_415) }; var arg_411 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000033); var tmp5 any; var root_416 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = s__1078000034__3; if linked_417 == nil { tmp5 = ifn_418.Invoke_O__O(arg_419) } else { tmp5 = linked_417.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_416, arg_419) }; arg_411 = tmp4.Invoke_O__O(tmp5); if linked_408 == nil { return ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { return linked_408.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) } } else { var root_420 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any; var root_425 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = b__1078000036__6; if linked_426 == nil { arg_423 = ifn_427.Invoke_O__O(arg_428) } else { arg_423 = linked_426.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_425, arg_428) }; var arg_424 any; if linked_421 == nil { return ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { return linked_421.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) } } } else { var vec__1078000044__4 any; var root_429 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = s__1078000034__3; if linked_430 == nil { vec__1078000044__4 = ifn_431.Invoke_O__O(arg_432) } else { vec__1078000044__4 = linked_430.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_429, arg_432) }; var sym__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000044__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000044__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_433 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_435 lang.IFn
																	if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__6, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__5))).Ref(); if linked_434 == nil { tmp6 = ifn_435.Invoke_O__O(arg_436) } else { tmp6 = linked_434.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_433, arg_436) }
//line :76:1
	if jrt.J2g_Truth(tmp6) { var root_437 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = lang.Tuple_Create_O_O__IPersistentVector(sym__5, jrt.NN(jrt.Class_Cast(c__6)).GetName__String().Ref()); var arg_441 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000033); var tmp8 any; var root_442 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = s__1078000034__3; if linked_443 == nil { tmp8 = ifn_444.Invoke_O__O(arg_445) } else { tmp8 = linked_443.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_442, arg_445) }; arg_441 = tmp7.Invoke_O__O(tmp8); if linked_438 == nil { return ifn_439.Invoke_O_O__O(arg_440, arg_441) } else { return linked_438.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_437, arg_440, arg_441) } } else { var tmp9 any; var root_446 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = s__1078000034__3; if linked_447 == nil { tmp9 = ifn_448.Invoke_O__O(arg_449) } else { tmp9 = linked_447.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_446, arg_449) }; s__1078000034__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1078000036 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1078000036 = c__b__1078000036 }
//line :76:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A) Invoke_O__O(self any) any { { var i__1078000035__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000035__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000040__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000035__1)); var sym__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000040__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000040__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_396 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_398 lang.IFn
																		if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__4, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__3))).Ref(); if linked_397 == nil { tmp2 = ifn_398.Invoke_O__O(arg_399) } else { tmp2 = linked_397.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_396, arg_399) }
//line :76:1
	if jrt.J2g_Truth(tmp2) { var root_400 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = t.F_b__1078000036; var arg_404 any = lang.Tuple_Create_O_O__IPersistentVector(sym__3, jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref()); if linked_401 == nil { ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { linked_401.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }; i__1078000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000035__1); continue L1 } else { i__1078000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000035__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_classes_native_compile_top_A_New() *A_arbace_classes_native_compile_top_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_classes_native_compile_top_A) Ctor() {}
//line :84:1
func (t *A_arbace_classes_native_compile_top_A) Invoke_O_O_O_O_O__O(self, ns__0, kind__1, forms__2, siblings__3 any) any { var forms__5 any; if






	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_72, kind__1) { forms__5 = lang.Tuple_Create_O__IPersistentVector(forms__2) } else { var root_472 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = forms__2; if linked_473 == nil { forms__5 = ifn_474.Invoke_O__O(arg_475) } else { forms__5 = linked_473.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_472, arg_475) } }; var loaded__6 any = /*line :84:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__5, A_arbace_classes_native_A_const_59, siblings__3); var root_483 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_485 lang.IFn; if






	linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_74.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_76); var tmp3 any; var iter__1927001039__auto____7 any; var fnbody__554 any = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_New(); var tmp4 *jrt.Class; var fncls__553 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_fn_class; if


	fncls__553 == nil { var fncls__553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_fn_class = fncls__553d; tmp4 = fncls__553d } else { tmp4 = fncls__553 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__554, tmp4, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(loaded__6); var tmp5 any = tmp3; var tmp6 lang.IFn = /*line :91:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp7 any; if



	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_72, kind__1) { var root_555 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any; var root_559 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = loaded__6; if linked_560 == nil { arg_558 = ifn_561.Invoke_O__O(arg_562) } else { arg_558 = linked_560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_559, arg_562) }; if linked_556 == nil { tmp7 = ifn_557.Invoke_O__O(arg_558) } else { tmp7 = linked_556.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_555, arg_558) } } else { var root_563 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var arg_567 any = loaded__6; if linked_564 == nil { tmp7 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { tmp7 = linked_564.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_563, arg_566, arg_567) } }; arg_486 = /*line :91:1*/tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_484 == nil { return ifn_485.Invoke_O__O(arg_486) } else { return linked_484.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_483, arg_486) } }


func A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_New() *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A) Ctor() {}
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A) Invoke_O_O__O(self, s__1078000051__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__552 any = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_New_O_O(s__1078000051__1, self); var tmp2 *jrt.Class; var fncls__551 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_fn_class; if fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__552); A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_fn_class = fncls__551d; tmp2 = fncls__551d } else { tmp2 = fncls__551 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__552, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :94:1
func A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A) Ctor_O_O(c__s__1078000051, c__iter__1078000050 any) { t.F_s__1078000051 = c__s__1078000051; t.F_iter__1078000050 = c__iter__1078000050 }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A) Invoke_O__O(self any) any { { var s__1078000051__1 any; var t_ any = t.F_s__1078000051; t.F_s__1078000051 = nil; s__1078000051__1 = t_; for { var temp__1927000414__auto____2 any; var root_493 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = s__1078000051__1; if linked_494 == nil { temp__1927000414__auto____2 = ifn_495.Invoke_O__O(arg_496) } else { temp__1927000414__auto____2 = linked_494.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_493, arg_496) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000051__3 any = temp__1927000414__auto____2; var tmp1 any; var root_497 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = s__1078000051__3; if linked_498 == nil { tmp1 = ifn_499.Invoke_O__O(arg_500) } else { tmp1 = linked_498.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_497, arg_500) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_501 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = s__1078000051__3; if linked_502 == nil { c__1927001037__auto____4 = ifn_503.Invoke_O__O(arg_504) } else { c__1927001037__auto____4 = linked_502.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_501, arg_504) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000053__6 any; var root_505 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_506 == nil { b__1078000053__6 = ifn_507.Invoke_O__O(arg_508) } else { b__1078000053__6 = linked_506.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_505, arg_508) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__515 any = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_New_O_I_O(b__1078000053__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__514 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_fn_class; if fncls__514 == nil { var fncls__514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__515); A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_fn_class = fncls__514d; tmp3 = fncls__514d } else { tmp3 = fncls__514 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__515, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_516 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var root_521 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = b__1078000053__6; if linked_522 == nil { arg_519 = ifn_523.Invoke_O__O(arg_524) } else { arg_519 = linked_522.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_521, arg_524) }; var arg_520 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000050); var tmp5 any; var root_525 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = s__1078000051__3; if linked_526 == nil { tmp5 = ifn_527.Invoke_O__O(arg_528) } else { tmp5 = linked_526.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_525, arg_528) }; arg_520 = tmp4.Invoke_O__O(tmp5); if linked_517 == nil { return ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { return linked_517.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_516, arg_519, arg_520) } } else { var root_529 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any; var root_534 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = b__1078000053__6; if linked_535 == nil { arg_532 = ifn_536.Invoke_O__O(arg_537) } else { arg_532 = linked_535.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_534, arg_537) }; var arg_533 any; if linked_530 == nil { return ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { return linked_530.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) } } } else { var vec__1078000061__4 any; var root_538 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = s__1078000051__3; if linked_539 == nil { vec__1078000061__4 = ifn_540.Invoke_O__O(arg_541) } else { vec__1078000061__4 = linked_539.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_538, arg_541) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_542 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_77, n__5); var arg_546 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1078000050); var tmp7 any; var root_547 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = s__1078000051__3; if linked_548 == nil { tmp7 = ifn_549.Invoke_O__O(arg_550) } else { tmp7 = linked_548.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_547, arg_550) }; arg_546 = tmp6.Invoke_O__O(tmp7); if linked_543 == nil { return ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { return linked_543.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :94:1
func A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A) Ctor_O_I_O(c__b__1078000053 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000053 = c__b__1078000053; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :94:1
func (t *A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A) Invoke_O__O(self any) any { { var i__1078000052__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000052__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000057__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000052__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_509 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = t.F_b__1078000053; var arg_513 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_77, n__3); if linked_510 == nil { ifn_511.Invoke_O_O__O(arg_512, arg_513) } else { linked_510.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_509, arg_512, arg_513) }; i__1078000052__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000052__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_native_compile_deftype_A_New() *A_arbace_classes_native_compile_deftype_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_classes_native_compile_deftype_A) Ctor() {}
//line :100:1
func (t *A_arbace_classes_native_compile_deftype_A) Invoke_O_O_O__O(self, ns__0, form__1 any) any {




	var root_582 any = A_arbace_classes_native_A_const_81.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = lang.IFn_Cast(A_arbace_classes_native_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_83, ns__0); if linked_583 == nil { ifn_584.Invoke_O__O(arg_585) } else { linked_583.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_582, arg_585) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__581 any = A_arbace_classes_native_compile_deftype_fn__1078000067_A_New_O_O(form__1, ns__0); var tmp2 *jrt.Class; var fncls__580 *jrt.Class = A_arbace_classes_native_compile_deftype_fn__1078000067_A_fn_class; if fncls__580 == nil { var fncls__580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__581); A_arbace_classes_native_compile_deftype_fn__1078000067_A_fn_class = fncls__580d; tmp2 = fncls__580d } else { tmp2 = fncls__580 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__581, tmp2, nil); Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :100:1
	return nil
}



func A_arbace_classes_native_compile_deftype_fn__1078000067_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_deftype_fn__1078000067_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_fn__1078000067_A{}; t.Ctor_O_O(p0, p1); return t }
//line :105:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000067_A) Ctor_O_O(c__form, c__ns any) { t.F_form = c__form; t.F_ns = c__ns }
//line :105:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000067_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_573 any = A_arbace_classes_native_A_const_79.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var t__2 any = t.F_form; t.F_form = nil; arg_576 = t__2; if linked_574 == nil { tmp5 = ifn_575.Invoke_O__O(arg_576) } else { tmp5 = linked_574.(*aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A).Invoke_O_O__O(root_573, arg_576) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :105:1
	return nil }(); var root_577 any = A_arbace_classes_native_A_const_80.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; if linked_578 == nil { ifn_579.Invoke__O() } else { linked_578.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_577) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }






func A_arbace_classes_native_public_class_QMARK__A_New() *A_arbace_classes_native_public_class_QMARK__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_public_class_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Invoke_O_O__O(self, c__0 any) any { { var c__2 any = c__0; L1: for {

	if lang.Util_Identical_O_O__Z_NoInit(c__2, nil) { return jrt.Boolean_TRUE.Ref() } else { var tmp1 any; var root_591 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_593 lang.IFn
		if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__2)).GetModifiers__I())).Ref(); if linked_592 == nil { tmp1 = ifn_593.Invoke_O__O(arg_594) } else { tmp1 = linked_592.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_591, arg_594) }
//line :114:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_native_A_const_23 != nil {

			c__2 = jrt.NN(jrt.Class_Cast(c__2)).GetDeclaringClass__Class().Ref(); continue L1 } else {
//line :114:1
				return nil } } } } }; /*line :112:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_type_form_A_New() *A_arbace_classes_native_type_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_type_form_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_native_type_form_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_native_type_form_A) Invoke_O_O__O(self, c__0 any) any {


	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var c__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(c__2)).IsArray__Z() { c__2, n__3 = jrt.NN(jrt.Class_Cast(c__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J_NoInit(n__3); continue L1 } else { var root_595 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); var arg_599 any; var root_600 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); if linked_601 == nil { arg_599 = ifn_602.Invoke_O__O(arg_603) } else { arg_599 = linked_601.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_600, arg_603) }; if linked_596 == nil { return ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { return linked_596.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_595, arg_598, arg_599) } } } } else {
			var root_604 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); if linked_605 == nil { return ifn_606.Invoke_O__O(arg_607) } else { return linked_605.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_604, arg_607) } }
//line :118:1
	panic("j2g: unreachable")
}






func A_arbace_classes_native_local_class_A_New() *A_arbace_classes_native_local_class_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_classes_native_local_class_A) Ctor() {}
//line :126:1
func (t *A_arbace_classes_native_local_class_A) Invoke_O_O__O(self, lb__0 any) any { var prim__2 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__609 any = A_arbace_classes_native_local_class_fn__1078000072_A_New_O(lb__0); var tmp2 *jrt.Class; var fncls__608 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000072_A_fn_class; if



	fncls__608 == nil { var fncls__608d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__609); A_arbace_classes_native_local_class_fn__1078000072_A_fn_class = fncls__608d; tmp2 = fncls__608d } else { tmp2 = fncls__608 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__609, tmp2, nil); prim__2 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var or__1927000174__auto____3 any = prim__2; if
	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var c__4 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__611 any = A_arbace_classes_native_local_class_fn__1078000074_A_New_O(lb__0); var tmp4 *jrt.Class; var fncls__610 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000074_A_fn_class
		if fncls__610 == nil { var fncls__610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__611); A_arbace_classes_native_local_class_fn__1078000074_A_fn_class = fncls__610d; tmp4 = fncls__610d } else { tmp4 = fncls__610 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__611, tmp4, nil); c__4 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()


		var tmp5 any; var and__1927000168__auto____5 bool = jrt.Class_InstanceOf(c__4); if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_612 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__4)).IsPrimitive__Z()).Ref(); if linked_613 == nil { and__1927000168__auto____6 = ifn_614.Invoke_O__O(arg_615) } else { and__1927000168__auto____6 = linked_613.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_612, arg_615) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_616 any = A_arbace_classes_native_A_const_84.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, A_arbace_classes_native_public_class_QMARK__A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = c__4; if linked_617 == nil { and__1927000168__auto____7 = ifn_618.Invoke_O__O(arg_619) } else { and__1927000168__auto____7 = linked_617.(*A_arbace_classes_native_public_class_QMARK__A).Invoke_O_O__O(root_616, arg_619) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
			var root_620 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any; var root_624 any = A_arbace_classes_native_A_const_85.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref(); var arg_628 any = Lit_38; if linked_625 == nil { arg_623 = ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { arg_623 = linked_625.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }; if linked_621 == nil { tmp5 = ifn_622.Invoke_O__O(arg_623) } else { tmp5 = linked_621.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_620, arg_623) } } else {
//line :135:1
				tmp5 = and__1927000168__auto____7 } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp5) { return c__4 } else { return A_arbace_classes_native_A_const_86 } } }
//line :130:1
func A_arbace_classes_native_local_class_fn__1078000072_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000072_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000072_A{}; t.Ctor_O(p0); return t }
//line :130:1
func (t *A_arbace_classes_native_local_class_fn__1078000072_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :130:1
func (t *A_arbace_classes_native_local_class_fn__1078000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetPrimitiveType__Class().Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_classes_native_local_class_fn__1078000074_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000074_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000074_A{}; t.Ctor_O(p0); return t }
//line :132:1
func (t *A_arbace_classes_native_local_class_fn__1078000074_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :132:1
func (t *A_arbace_classes_native_local_class_fn__1078000074_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); if jrt.NN(lang.Compiler_LocalBinding_Cast(t.F_lb)).HasJavaClass__Z() {
												var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetJavaClass__Class().Ref() } else {
//line :132:1
		tmp1 = nil }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_classes_native_field_names_A_New() *A_arbace_classes_native_field_names_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_field_names_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_classes_native_field_names_A) Ctor() {}
//line :140:1
func (t *A_arbace_classes_native_field_names_A) Invoke_O_O__O(self, syms__0 any) any { { var G__1078000080__2_ any = syms__0; var vec__1078000081__3 any = G__1078000080__2_; var seq__1078000082__4 any; var root_629 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_631 lang.IFn


	if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = vec__1078000081__3; if linked_630 == nil { seq__1078000082__4 = ifn_631.Invoke_O__O(arg_632) } else { seq__1078000082__4 = linked_630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_629, arg_632) }
//line :140:1
	var first__1078000083__5 any; var root_633 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_635 lang.IFn


	if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = seq__1078000082__4; if linked_634 == nil { first__1078000083__5 = ifn_635.Invoke_O__O(arg_636) } else { first__1078000083__5 = linked_634.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_633, arg_636) }
//line :140:1
	var seq__1078000082__6 any; var root_637 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_639 lang.IFn


	if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = seq__1078000082__4; if linked_638 == nil { seq__1078000082__6 = ifn_639.Invoke_O__O(arg_640) } else { seq__1078000082__6 = linked_638.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_637, arg_640) }
//line :140:1
	var s__7 any = first__1078000083__5; var more__8 any = seq__1078000082__6; var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); var out__10 any = lang.PersistentVector_EMPTY.Ref(); var G__1078000080__11_ any = G__1078000080__2_; var seen__12 any = seen__9; var out__13 any = out__10; _ = s__7; _ = more__8; L1: for { var vec__1078000084__14 any = G__1078000080__11_; var seq__1078000085__15 any; var root_641 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_643 lang.IFn


		if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = vec__1078000084__14; if linked_642 == nil { seq__1078000085__15 = ifn_643.Invoke_O__O(arg_644) } else { seq__1078000085__15 = linked_642.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_641, arg_644) }
//line :140:1
		var first__1078000086__16 any; var root_645 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_647 lang.IFn


		if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = seq__1078000085__15; if linked_646 == nil { first__1078000086__16 = ifn_647.Invoke_O__O(arg_648) } else { first__1078000086__16 = linked_646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_645, arg_648) }
//line :140:1
		var seq__1078000085__17 any; var root_649 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_651 lang.IFn


		if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = seq__1078000085__15; if linked_650 == nil { seq__1078000085__17 = ifn_651.Invoke_O__O(arg_652) } else { seq__1078000085__17 = linked_650.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_649, arg_652) }
//line :140:1
		var s__18 any = first__1078000086__16; var more__19 any = seq__1078000085__17; var seen__20 any = seen__12; var out__21 any = out__13; var tmp1 any; var root_653 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_655 lang.IFn



		if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = s__18; if linked_654 == nil { tmp1 = ifn_655.Invoke_O__O(arg_656) } else { tmp1 = linked_654.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_653, arg_656) }; if jrt.J2g_Truth(tmp1) { return out__21 } else { var base__22 any; var root_657 any = A_arbace_classes_native_A_const_87.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_659 lang.IFn

			if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any; var root_661 any = A_arbace_classes_native_A_const_88.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = s__18; if linked_662 == nil { arg_660 = ifn_663.Invoke_O__O(arg_664) } else { arg_660 = linked_662.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_661, arg_664) }; if linked_658 == nil { base__22 = ifn_659.Invoke_O__O(arg_660) } else { base__22 = linked_658.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_657, arg_660) }
//line :144:1
			var n__23 any


			if jrt.J2g_Truth(lang.IFn_Cast(seen__20).Invoke_O__O(base__22)) { n__23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, base__22, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(out__21)).Ref())).Ref() } else { n__23 = base__22 }
			var tmp2 any; var root_665 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seen__20; var arg_669 any = n__23; if linked_666 == nil { tmp2 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { tmp2 = linked_666.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }; var tmp3 any = tmp2; var tmp4 any; var root_670 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = out__21; var arg_674 any = n__23; if linked_671 == nil { tmp4 = ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { tmp4 = linked_671.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_670, arg_673, arg_674) }; G__1078000080__11_, seen__12, out__13 = more__19, tmp3, tmp4; continue L1 } } }; /*line :140:1*/panic("j2g: unreachable") }









func A_arbace_classes_native_fn_class_form_A_New() *A_arbace_classes_native_fn_class_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_classes_native_fn_class_form_A) Ctor() {}
//line :150:1
func (t *A_arbace_classes_native_fn_class_form_A) Invoke_O_O_O_O__O(self, cname__0, form__1, captured__2 any) any { var map__1078000088__4 any; var root_675 any = A_arbace_classes_native_A_const_89.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A_fn_class); var ifn_677 lang.IFn; if



	linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = form__1; if linked_676 == nil { map__1078000088__4 = ifn_677.Invoke_O__O(arg_678) } else { map__1078000088__4 = linked_676.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A).Invoke_O_O__O(root_675, arg_678) }; var map__1078000088__5 any; if lang.ISeq_InstanceOf(map__1078000088__4) { var tmp1 any; var root_679 any = A_arbace_classes_native_A_const_57.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = map__1078000088__4; if linked_680 == nil { tmp1 = ifn_681.Invoke_O__O(arg_682) } else { tmp1 = linked_680.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_679, arg_682) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_683 any = A_arbace_classes_native_A_const_58.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = map__1078000088__4; if linked_684 == nil { tmp2 = ifn_685.Invoke_O__O(arg_686) } else { tmp2 = linked_684.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_683, arg_686) }; map__1078000088__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_687 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = map__1078000088__4; if linked_688 == nil { tmp3 = ifn_689.Invoke_O__O(arg_690) } else { tmp3 = linked_688.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_687, arg_690) }; if jrt.J2g_Truth(tmp3) { var root_691 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = map__1078000088__4; if linked_692 == nil { map__1078000088__5 = ifn_693.Invoke_O__O(arg_694) } else { map__1078000088__5 = linked_692.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_691, arg_694) } } else { map__1078000088__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000088__5 = map__1078000088__4 }; var nm__6 any = /*line :150:1*/lang.RT_Get_O_O__O_NoInit(map__1078000088__5, A_arbace_classes_native_A_const_90); var arities__7 any = lang.RT_Get_O_O__O_NoInit(map__1078000088__5, A_arbace_classes_native_A_const_91); var i__8 int32 = jrt.NN(jrt.String_Cast(cname__0)).LastIndexOf_String__I(Lit_17); var pkg__9 any; if





	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__8)) { pkg__9 = Lit_18 } else { var root_695 any = A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = cname__0; var arg_699 any = A_arbace_classes_native_A_const_93; var arg_700 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__8).Ref(); if linked_696 == nil { pkg__9 = ifn_697.Invoke_O_O_O__O(arg_698, arg_699, arg_700) } else { pkg__9 = linked_696.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_695, arg_698, arg_699, arg_700) } }; var simple__10 any; var root_701 any = /*line :150:1*/A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_703 lang.IFn; if






	linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = cname__0; var arg_705 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__8))).Ref(); if linked_702 == nil { simple__10 = ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { simple__10 = linked_702.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) }; var rcv__11 any; var root_706 any = /*line :150:1*/A_arbace_classes_native_A_const_94.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_708 lang.IFn; if







	linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = Lit_19; if linked_707 == nil { rcv__11 = ifn_708.Invoke_O__O(arg_709) } else { rcv__11 = linked_707.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_706, arg_709) }; var fields__12 any; var root_710 any = /*line :150:1*/A_arbace_classes_native_A_const_95.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_classes_native_field_names_A_fn_class); var ifn_712 lang.IFn; if








	linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any; var root_714 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var arg_718 any = captured__2; if linked_715 == nil { arg_713 = ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { arg_713 = linked_715.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) }; if linked_711 == nil { fields__12 = ifn_712.Invoke_O__O(arg_713) } else { fields__12 = linked_711.(*A_arbace_classes_native_field_names_A).Invoke_O_O__O(root_710, arg_713) }; var super__13 any; var tmp4 any; var root_719 any = /*line :150:1*/A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_721 lang.IFn; if









	linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = A_arbace_classes_native_A_const_97.GetRawRoot__O(); var arg_723 any = arities__7; if linked_720 == nil { tmp4 = ifn_721.Invoke_O_O__O(arg_722, arg_723) } else { tmp4 = linked_720.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_719, arg_722, arg_723) }; if jrt.J2g_Truth(tmp4) { super__13 = A_arbace_classes_native_A_const_98 } else { super__13 = A_arbace_classes_native_A_const_99 }; var typed__14 any; var fnbody__734 any = /*line :150:1*/A_arbace_classes_native_fn_class_form_typed__1078000090_A_New(); var tmp5 *jrt.Class; var fncls__733 *jrt.Class = A_arbace_classes_native_fn_class_form_typed__1078000090_A_fn_class; if










	fncls__733 == nil { var fncls__733d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_classes_native_fn_class_form_typed__1078000090_A_fn_class = fncls__733d; tmp5 = fncls__733d } else { tmp5 = fncls__733 }; typed__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__734, tmp5, nil); var tmp6 lang.IFn =
	lang.IFn_Cast(A_arbace_classes_native_A_const_74.GetRawRoot__O()); var tmp7 any; var root_742 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_744 lang.IFn; if
	linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any; var root_747 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = simple__10; if linked_748 == nil { arg_745 = ifn_749.Invoke_O__O(arg_750) } else { arg_745 = linked_748.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_747, arg_750) }; var arg_746 any = A_arbace_classes_native_A_const_101; if linked_743 == nil { tmp7 = ifn_744.Invoke_O_O__O(arg_745, arg_746) } else { tmp7 = linked_743.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_742, arg_745, arg_746) }; var tmp8 any = tmp7; var tmp9 any = A_arbace_classes_native_A_const_102; var tmp10 any = A_arbace_classes_native_A_const_103; var tmp11 any = A_arbace_classes_native_A_const_104; var tmp12 any; var root_751 any = /*line :162:1*/A_arbace_classes_native_A_const_105.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A_fn_class); var ifn_753 lang.IFn; if



	linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = arities__7; if linked_752 == nil { tmp12 = ifn_753.Invoke_O__O(arg_754) } else { tmp12 = linked_752.(*aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A).Invoke_O_O__O(root_751, arg_754) }; var tmp13 any = /*line :162:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, pkg__9, tmp10, super__13, tmp11, tmp12)); var tmp14 any; var iter__1927001039__auto____15 any; var fnbody__838 any = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_New_O(typed__14); var tmp15 *jrt.Class; var fncls__837 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_fn_class; if




	fncls__837 == nil { var fncls__837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__838); A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_fn_class = fncls__837d; tmp15 = fncls__837d } else { tmp15 = fncls__837 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__838, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp17 any; var root_839 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any = A_arbace_classes_native_A_const_109.GetRawRoot__O(); var arg_843 any = fields__12; var arg_844 any = captured__2; if linked_840 == nil { tmp17 = ifn_841.Invoke_O_O_O__O(arg_842, arg_843, arg_844) } else { tmp17 = linked_840.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_839, arg_842, arg_843, arg_844) }; tmp14 = tmp16.Invoke_O__O(tmp17); var tmp18 any = tmp14; var tmp19 any; var root_845 any = /*line :162:1*/A_arbace_classes_native_A_const_110.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_847 lang.IFn; if






	linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = A_arbace_classes_native_A_const_111; var arg_849 any; var root_852 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var root_857 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = rcv__11; var arg_865 any; var root_866 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var fnbody__877 any = A_arbace_classes_native_fn_class_form_fn__1078000115_A_New_O(typed__14); var tmp20 *jrt.Class; var fncls__876 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000115_A_fn_class; if fncls__876 == nil { var fncls__876d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__877); A_arbace_classes_native_fn_class_form_fn__1078000115_A_fn_class = fncls__876d; tmp20 = fncls__876d } else { tmp20 = fncls__876 }; arg_869 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__877, tmp20, nil); var arg_870 any = fields__12; var arg_871 any = captured__2; if linked_867 == nil { arg_865 = ifn_868.Invoke_O_O_O__O(arg_869, arg_870, arg_871) } else { arg_865 = linked_867.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_866, arg_869, arg_870, arg_871) }; if linked_862 == nil { arg_860 = ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }; if linked_858 == nil { arg_855 = ifn_859.Invoke_O__O(arg_860) } else { arg_855 = linked_858.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_857, arg_860) }; var arg_856 any = A_arbace_classes_native_A_const_112; if linked_853 == nil { arg_849 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { arg_849 = linked_853.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; var arg_850 any = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_113); var arg_851 any; var iter__1927001039__auto____15_2 any; var fnbody__955 any = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_New_O(rcv__11); var tmp21 *jrt.Class; var fncls__954 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_fn_class; if


	fncls__954 == nil { var fncls__954d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__955); A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_fn_class = fncls__954d; tmp21 = fncls__954d } else { tmp21 = fncls__954 }; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__955, tmp21, nil); arg_851 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(fields__12); if /*line :169:1*/ linked_846 == nil { tmp19 = ifn_847.Invoke_O_O_O_O__O(arg_848, arg_849, arg_850, arg_851) } else { tmp19 = linked_846.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_845, arg_848, arg_849, arg_850, arg_851) }; var tmp22 any = /*line :162:1*/lang.Tuple_Create_O__IPersistentVector(tmp19); var tmp23 any; var root_956 any = A_arbace_classes_native_A_const_115.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A_fn_class); var ifn_958 lang.IFn; if










	linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = rcv__11; var arg_960 any = nm__6; var arg_961 any = arities__7; var arg_962 any; var root_963 any = A_arbace_classes_native_A_const_24.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_965 lang.IFn; if
	linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_21.GetRawRoot__O()); var tmp25 *lang.Compiler_AOTFn; var fnbody__978 any = A_arbace_classes_native_fn_class_form_fn__1078000131_A_New_O(rcv__11); var tmp26 *jrt.Class; var fncls__977 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000131_A_fn_class; if fncls__977 == nil { var fncls__977d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__978); A_arbace_classes_native_fn_class_form_fn__1078000131_A_fn_class = fncls__977d; tmp26 = fncls__977d } else { tmp26 = fncls__977 }; tmp25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__978, tmp26, nil); arg_966 = tmp24.Invoke_O_O_O__O(tmp25.Ref(), fields__12, captured__2); if linked_964 == nil { arg_962 = ifn_965.Invoke_O__O(arg_966) } else { arg_962 = linked_964.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_963, arg_966) }; if /*line :173:1*/ linked_957 == nil { tmp23 = ifn_958.Invoke_O_O_O_O__O(arg_959, arg_960, arg_961, arg_962) } else { tmp23 = linked_957.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A).Invoke_O_O_O_O_O__O(root_956, arg_959, arg_960, arg_961, arg_962) }; return /*line :162:1*/ tmp6.Invoke_O_O_O_O__O(tmp13, tmp18, tmp22, tmp23) }
//line :161:1
func A_arbace_classes_native_fn_class_form_typed__1078000090_A_New() *A_arbace_classes_native_fn_class_form_typed__1078000090_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_typed__1078000090_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000090_A) Ctor() {}
//line :161:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000090_A) Invoke_O_O_O__O(self, s__1, c__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__2, A_arbace_classes_native_A_const_86) { return s__1 } else { var root_724 any = A_arbace_classes_native_A_const_42.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = s__1; var arg_728 any; var tmp1 any = A_arbace_classes_native_A_const_40; var tmp2 any; var root_729 any = A_arbace_classes_native_A_const_100.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, A_arbace_classes_native_type_form_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = c__2; if linked_730 == nil { tmp2 = ifn_731.Invoke_O__O(arg_732) } else { tmp2 = linked_730.(*A_arbace_classes_native_type_form_A).Invoke_O_O__O(root_729, arg_732) }; arg_728 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2)); if linked_725 == nil { return ifn_726.Invoke_O_O__O(arg_727, arg_728) } else { return linked_725.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_724, arg_727, arg_728) } } }





func A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A) Invoke_O_O__O(self, s__1078000093__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__836 any = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_New_O_O_O(s__1078000093__1, self, t.F_typed); var tmp2 *jrt.Class; var fncls__835 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_fn_class; if fncls__835 == nil { var fncls__835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__836); A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_fn_class = fncls__835d; tmp2 = fncls__835d } else { tmp2 = fncls__835 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__836, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :167:1
func A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A) Ctor_O_O_O(c__s__1078000093, c__iter__1078000092, c__typed any) { t.F_s__1078000093 = c__s__1078000093; t.F_iter__1078000092 = c__iter__1078000092; t.F_typed = c__typed }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A) Invoke_O__O(self any) any { { var s__1078000093__1 any; var t_ any = t.F_s__1078000093; t.F_s__1078000093 = nil; s__1078000093__1 = t_; for { var temp__1927000414__auto____2 any; var root_755 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = s__1078000093__1; if linked_756 == nil { temp__1927000414__auto____2 = ifn_757.Invoke_O__O(arg_758) } else { temp__1927000414__auto____2 = linked_756.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_755, arg_758) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000093__3 any = temp__1927000414__auto____2; var tmp1 any; var root_759 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = s__1078000093__3; if linked_760 == nil { tmp1 = ifn_761.Invoke_O__O(arg_762) } else { tmp1 = linked_760.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_759, arg_762) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_763 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = s__1078000093__3; if linked_764 == nil { c__1927001037__auto____4 = ifn_765.Invoke_O__O(arg_766) } else { c__1927001037__auto____4 = linked_764.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_763, arg_766) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000095__6 any; var root_767 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_768 == nil { b__1078000095__6 = ifn_769.Invoke_O__O(arg_770) } else { b__1078000095__6 = linked_768.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_767, arg_770) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__788 any = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_New_O_O_I_O(b__1078000095__6, t.F_typed, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__787 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_fn_class; if fncls__787 == nil { var fncls__787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__788); A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_fn_class = fncls__787d; tmp3 = fncls__787d } else { tmp3 = fncls__787 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__788, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_789 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var root_794 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = b__1078000095__6; if linked_795 == nil { arg_792 = ifn_796.Invoke_O__O(arg_797) } else { arg_792 = linked_795.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_794, arg_797) }; var arg_793 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000092); var tmp5 any; var root_798 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = s__1078000093__3; if linked_799 == nil { tmp5 = ifn_800.Invoke_O__O(arg_801) } else { tmp5 = linked_799.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_798, arg_801) }; arg_793 = tmp4.Invoke_O__O(tmp5); if linked_790 == nil { return ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { return linked_790.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) } } else { var root_802 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any; var root_807 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = b__1078000095__6; if linked_808 == nil { arg_805 = ifn_809.Invoke_O__O(arg_810) } else { arg_805 = linked_808.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_807, arg_810) }; var arg_806 any; if linked_803 == nil { return ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { return linked_803.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) } } } else { var vec__1078000106__4 any; var root_811 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = s__1078000093__3; if linked_812 == nil { vec__1078000106__4 = ifn_813.Invoke_O__O(arg_814) } else { vec__1078000106__4 = linked_812.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_811, arg_814) }; var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000106__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000109__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000106__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000109__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000109__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_815 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_817 lang.IFn; _ = ___7; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_106; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_107.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp10 any; var root_827 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_829 lang.IFn
															if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = f__5; if linked_828 == nil { tmp10 = ifn_829.Invoke_O__O(arg_830) } else { tmp10 = linked_828.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_827, arg_830) }; arg_818 = tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O_O__O(tmp9.Invoke_O_O__O(tmp10, c__8), A_arbace_classes_native_A_const_46.GetRawRoot__O(), A_arbace_classes_native_A_const_108, jrt.Boolean_TRUE.Ref()))
//line :167:1
	var arg_819 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000092); var tmp12 any; var root_831 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = s__1078000093__3; if linked_832 == nil { tmp12 = ifn_833.Invoke_O__O(arg_834) } else { tmp12 = linked_832.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_831, arg_834) }; arg_819 = tmp11.Invoke_O__O(tmp12); if linked_816 == nil { return ifn_817.Invoke_O_O__O(arg_818, arg_819) } else { return linked_816.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_815, arg_818, arg_819) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :167:1
func A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A) Ctor_O_O_I_O(c__b__1078000095, c__typed any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000095 = c__b__1078000095; t.F_typed = c__typed; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :167:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A) Invoke_O__O(self any) any { { var i__1078000094__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000099__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000094__1)); var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000099__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000102__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000099__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000102__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000102__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_771 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_773 lang.IFn; _ = ___5; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = t.F_b__1078000095; var arg_775 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_106; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_107.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp6 any; var root_783 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_785 lang.IFn
																	if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = f__3; if linked_784 == nil { tmp6 = ifn_785.Invoke_O__O(arg_786) } else { tmp6 = linked_784.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_783, arg_786) }; arg_775 = tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5.Invoke_O_O__O(tmp6, c__6), A_arbace_classes_native_A_const_46.GetRawRoot__O(), A_arbace_classes_native_A_const_108, jrt.Boolean_TRUE.Ref()))
//line :167:1
	if linked_772 == nil { ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { linked_772.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) }; i__1078000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000094__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000115_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000115_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000115_A{}; t.Ctor_O(p0); return t }
//line :169:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000115_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :169:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000115_A) Invoke_O_O_O__O(self, f__1, p__1078000114__2 any) any { var vec__1078000116__3 any = p__1078000114__2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000116__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000116__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp2 any; var root_872 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_874 lang.IFn; _ = ___4; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = f__1; if linked_873 == nil { tmp2 = ifn_874.Invoke_O__O(arg_875) } else { tmp2 = linked_873.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_872, arg_875) }; return tmp1.Invoke_O_O__O(tmp2, c__5) }


func A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A) Invoke_O_O__O(self, s__1078000121__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__953 any = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_New_O_O_O(s__1078000121__1, self, t.F_rcv); var tmp2 *jrt.Class; var fncls__952 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_fn_class; if fncls__952 == nil { var fncls__952d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__953); A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_fn_class = fncls__952d; tmp2 = fncls__952d } else { tmp2 = fncls__952 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__953, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :172:1
func A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A) Ctor_O_O_O(c__s__1078000121, c__iter__1078000120, c__rcv any) { t.F_s__1078000121 = c__s__1078000121; t.F_iter__1078000120 = c__iter__1078000120; t.F_rcv = c__rcv }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A) Invoke_O__O(self any) any { { var s__1078000121__1 any; var t_ any = t.F_s__1078000121; t.F_s__1078000121 = nil; s__1078000121__1 = t_; for { var temp__1927000414__auto____2 any; var root_878 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = s__1078000121__1; if linked_879 == nil { temp__1927000414__auto____2 = ifn_880.Invoke_O__O(arg_881) } else { temp__1927000414__auto____2 = linked_879.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_878, arg_881) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000121__3 any = temp__1927000414__auto____2; var tmp1 any; var root_882 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = s__1078000121__3; if linked_883 == nil { tmp1 = ifn_884.Invoke_O__O(arg_885) } else { tmp1 = linked_883.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_882, arg_885) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_886 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = s__1078000121__3; if linked_887 == nil { c__1927001037__auto____4 = ifn_888.Invoke_O__O(arg_889) } else { c__1927001037__auto____4 = linked_887.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_886, arg_889) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000123__6 any; var root_890 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_891 == nil { b__1078000123__6 = ifn_892.Invoke_O__O(arg_893) } else { b__1078000123__6 = linked_891.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_890, arg_893) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__908 any = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_New_O_I_O_O(t.F_rcv, size__1927001038__auto____5, b__1078000123__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__907 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_fn_class; if fncls__907 == nil { var fncls__907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__908); A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_fn_class = fncls__907d; tmp3 = fncls__907d } else { tmp3 = fncls__907 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__908, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_909 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var root_914 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = b__1078000123__6; if linked_915 == nil { arg_912 = ifn_916.Invoke_O__O(arg_917) } else { arg_912 = linked_915.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_914, arg_917) }; var arg_913 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000120); var tmp5 any; var root_918 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = s__1078000121__3; if linked_919 == nil { tmp5 = ifn_920.Invoke_O__O(arg_921) } else { tmp5 = linked_919.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_918, arg_921) }; arg_913 = tmp4.Invoke_O__O(tmp5); if linked_910 == nil { return ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { return linked_910.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) } } else { var root_922 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any; var root_927 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = b__1078000123__6; if linked_928 == nil { arg_925 = ifn_929.Invoke_O__O(arg_930) } else { arg_925 = linked_928.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_927, arg_930) }; var arg_926 any; if linked_923 == nil { return ifn_924.Invoke_O_O__O(arg_925, arg_926) } else { return linked_923.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_922, arg_925, arg_926) } } } else { var f__4 any; var root_931 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = s__1078000121__3; if linked_932 == nil { f__4 = ifn_933.Invoke_O__O(arg_934) } else { f__4 = linked_932.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_931, arg_934) }; var root_935 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_114; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp9 any; var root_944 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref(); if linked_945 == nil { tmp9 = ifn_946.Invoke_O__O(arg_947) } else { tmp9 = linked_945.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_944, arg_947) }; var tmp10 any = tmp8.Invoke_O_O__O(tmp9, t.F_rcv); var tmp11 any; var root_940 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = f__4; if linked_941 == nil { tmp11 = ifn_942.Invoke_O__O(arg_943) } else { tmp11 = linked_941.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_940, arg_943) }; arg_938 = tmp6.Invoke_O_O_O__O(tmp7, tmp10, tmp11); var arg_939 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1078000120); var tmp13 any; var root_948 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__1078000121__3; if linked_949 == nil { tmp13 = ifn_950.Invoke_O__O(arg_951) } else { tmp13 = linked_949.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_948, arg_951) }; arg_939 = tmp12.Invoke_O__O(tmp13); if linked_936 == nil { return ifn_937.Invoke_O_O__O(arg_938, arg_939) } else { return linked_936.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_935, arg_938, arg_939) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A) Ctor_O_I_O_O(c__rcv any, c__size__1927001038__auto__ int32, c__b__1078000123, c__c__1927001037__auto__ any) { t.F_rcv = c__rcv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1078000123 = c__b__1078000123; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A) Invoke_O__O(self any) any { { var i__1078000122__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000122__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000122__1)); var root_894 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = t.F_b__1078000123; var arg_898 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_114; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp5 any; var root_903 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref(); if linked_904 == nil { tmp5 = ifn_905.Invoke_O__O(arg_906) } else { tmp5 = linked_904.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_903, arg_906) }; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, t.F_rcv); var tmp7 any; var root_899 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = f__2; if linked_900 == nil { tmp7 = ifn_901.Invoke_O__O(arg_902) } else { tmp7 = linked_900.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_899, arg_902) }; arg_898 = tmp2.Invoke_O_O_O__O(tmp3, tmp6, tmp7); if linked_895 == nil { ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { linked_895.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) }; i__1078000122__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000122__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000131_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000131_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000131_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000131_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :174:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000131_A) Invoke_O_O_O__O(self, f__1, p__1078000130__2 any) any { var vec__1078000132__3 any = p__1078000130__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000132__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000132__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()); var tmp2 any; var root_973 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_975 lang.IFn; _ = ___5; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref(); if linked_974 == nil { tmp2 = ifn_975.Invoke_O__O(arg_976) } else { tmp2 = linked_974.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_973, arg_976) }; return lang.Tuple_Create_O_O__IPersistentVector(s__4, tmp1.Invoke_O_O__O(tmp2, t.F_rcv)) }

func A_arbace_classes_native_compile_fn_A_New() *A_arbace_classes_native_compile_fn_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_classes_native_compile_fn_A) Ctor() {}
//line :176:1
func (t *A_arbace_classes_native_compile_fn_A) Invoke_O_O_O_O_O__O(self, ns__0, cname__1, form__2, env__3 any) any { { var host__5 any; var root_979 any = A_arbace_classes_native_A_const_17.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_981 lang.IFn





	if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_983 any; var iter__1927001039__auto____5 any; var fnbody__1053 any = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_New(); var tmp1 *jrt.Class; var fncls__1052 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_fn_class; if fncls__1052 == nil { var fncls__1052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_fn_class = fncls__1052d; tmp1 = fncls__1052d } else { tmp1 = fncls__1052 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1053, tmp1, nil); arg_983 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(env__3); if linked_980 == nil { host__5 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { host__5 = linked_980.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }
//line :176:1
	var mentioned__6 any; var root_1054 any = A_arbace_classes_native_A_const_117.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A_fn_class); var ifn_1056 lang.IFn






	if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = form__2; if linked_1055 == nil { mentioned__6 = ifn_1056.Invoke_O__O(arg_1057) } else { mentioned__6 = linked_1055.(*aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A).Invoke_O_O__O(root_1054, arg_1057) }
//line :176:1
	var syms__7 any; var root_1058 any = A_arbace_classes_native_A_const_118.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_1060 lang.IFn







	if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any; var fnbody__1069 any = A_arbace_classes_native_compile_fn_fn__1078000156_A_New_O(host__5); var tmp2 *jrt.Class; var fncls__1068 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000156_A_fn_class; if fncls__1068 == nil { var fncls__1068d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__1069); A_arbace_classes_native_compile_fn_fn__1078000156_A_fn_class = fncls__1068d; tmp2 = fncls__1068d } else { tmp2 = fncls__1068 }; arg_1061 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1069, tmp2, nil); var arg_1062 any; var root_1070 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var arg_1074 any = mentioned__6; if linked_1071 == nil { arg_1062 = ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { arg_1062 = linked_1071.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) }; if linked_1059 == nil { syms__7 = ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { syms__7 = linked_1059.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) }
//line :176:1
L1: for { var captured__8 any; var root_1075 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1077 lang.IFn








	if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any; var fnbody__1081 any = A_arbace_classes_native_compile_fn_fn__1078000158_A_New_O(host__5); var tmp3 *jrt.Class; var fncls__1080 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000158_A_fn_class; if fncls__1080 == nil { var fncls__1080d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__1081); A_arbace_classes_native_compile_fn_fn__1078000158_A_fn_class = fncls__1080d; tmp3 = fncls__1080d } else { tmp3 = fncls__1080 }; arg_1078 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1081, tmp3, nil); var arg_1079 any = syms__7; if linked_1076 == nil { captured__8 = ifn_1077.Invoke_O_O__O(arg_1078, arg_1079) } else { captured__8 = linked_1076.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1075, arg_1078, arg_1079) }
//line :176:1
	var r__9 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__1143 any = A_arbace_classes_native_compile_fn_fn__1078000160_A_New_O_O_O_O_O_O(form__2, host__5, ns__0, syms__7, cname__1, captured__8); var tmp5 *jrt.Class
	var fncls__1142 /*line :176:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000160_A_fn_class









	if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__1143); A_arbace_classes_native_compile_fn_fn__1078000160_A_fn_class = fncls__1142d; tmp5 = fncls__1142d } else { tmp5 = fncls__1142 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1143, tmp5, nil); r__9 = Up_Compiler_AOTFn_IFn(tmp4).Invoke__O()









	var tmp6 any = A_arbace_classes_native_A_const_125; var tmp7 any; var root_1144 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = r__9; if linked_1145 == nil { tmp7 = ifn_1146.Invoke_O__O(arg_1147) } else { tmp7 = linked_1145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1144, arg_1147) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) {
		var tmp8 any; var root_1166 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = syms__7; var arg_1170 any; var root_1171 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = r__9; if linked_1172 == nil { arg_1170 = ifn_1173.Invoke_O__O(arg_1174) } else { arg_1170 = linked_1172.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1171, arg_1174) }; if linked_1167 == nil { tmp8 = ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { tmp8 = linked_1167.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) }; syms__7 = tmp8; continue L1 } else {
//line :196:1
			var new__10 any; var root_1148 any = A_arbace_classes_native_A_const_110.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1150 lang.IFn


			if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = A_arbace_classes_native_A_const_126; var arg_1152 any; var root_1154 any = A_arbace_classes_native_A_const_78.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any; var root_1158 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = r__9; if linked_1159 == nil { arg_1157 = ifn_1160.Invoke_O__O(arg_1161) } else { arg_1157 = linked_1159.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1158, arg_1161) }; if linked_1155 == nil { arg_1152 = ifn_1156.Invoke_O__O(arg_1157) } else { arg_1152 = linked_1155.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1154, arg_1157) }; var arg_1153 any = syms__7; if linked_1149 == nil { new__10 = ifn_1150.Invoke_O_O_O__O(arg_1151, arg_1152, arg_1153) } else { new__10 = linked_1149.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1148, arg_1151, arg_1152, arg_1153) }
//line :196:1
			var temp__1927000408__auto____11 any; var root_1162 any = A_arbace_classes_native_A_const_127.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A_fn_class); var ifn_1164 lang.IFn



			if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = form__2; if linked_1163 == nil { temp__1927000408__auto____11 = ifn_1164.Invoke_O__O(arg_1165) } else { temp__1927000408__auto____11 = linked_1163.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A).Invoke_O_O__O(root_1162, arg_1165) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11
				return lang.IFn_Cast(A_arbace_classes_native_A_const_75.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_classes_native_A_const_128, new__10, m__12) } else {
//line :200:1
					return new__10 } } } }; /*line :176:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_New() *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A) Ctor() {}
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A) Invoke_O_O__O(self, s__1078000141__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1051 any = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_New_O_O(s__1078000141__1, self); var tmp2 *jrt.Class; var fncls__1050 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_fn_class; if fncls__1050 == nil { var fncls__1050d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__1051); A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_fn_class = fncls__1050d; tmp2 = fncls__1050d } else { tmp2 = fncls__1050 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1051, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :182:1
func A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A) Ctor_O_O(c__s__1078000141, c__iter__1078000140 any) { t.F_s__1078000141 = c__s__1078000141; t.F_iter__1078000140 = c__iter__1078000140 }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A) Invoke_O__O(self any) any { { var s__1078000141__1 any; var t_ any = t.F_s__1078000141; t.F_s__1078000141 = nil; s__1078000141__1 = t_; for { var temp__1927000414__auto____2 any; var root_984 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = s__1078000141__1; if linked_985 == nil { temp__1927000414__auto____2 = ifn_986.Invoke_O__O(arg_987) } else { temp__1927000414__auto____2 = linked_985.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_984, arg_987) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000141__3 any = temp__1927000414__auto____2; var tmp1 any; var root_988 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = s__1078000141__3; if linked_989 == nil { tmp1 = ifn_990.Invoke_O__O(arg_991) } else { tmp1 = linked_989.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_988, arg_991) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_992 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = s__1078000141__3; if linked_993 == nil { c__1927001037__auto____4 = ifn_994.Invoke_O__O(arg_995) } else { c__1927001037__auto____4 = linked_993.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_992, arg_995) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000143__6 any; var root_996 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_997 == nil { b__1078000143__6 = ifn_998.Invoke_O__O(arg_999) } else { b__1078000143__6 = linked_997.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_996, arg_999) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1010 any = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_New_O_I_O(b__1078000143__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_fn_class; if fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__1010); A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_fn_class = fncls__1009d; tmp3 = fncls__1009d } else { tmp3 = fncls__1009 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1010, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1011 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any; var root_1016 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = b__1078000143__6; if linked_1017 == nil { arg_1014 = ifn_1018.Invoke_O__O(arg_1019) } else { arg_1014 = linked_1017.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1016, arg_1019) }; var arg_1015 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000140); var tmp5 any; var root_1020 any = A_arbace_classes_native_A_const_52.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = s__1078000141__3; if linked_1021 == nil { tmp5 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp5 = linked_1021.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1020, arg_1023) }; arg_1015 = tmp4.Invoke_O__O(tmp5); if linked_1012 == nil { return ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { return linked_1012.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) } } else { var root_1024 any = A_arbace_classes_native_A_const_50.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any; var root_1029 any = A_arbace_classes_native_A_const_51.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = b__1078000143__6; if linked_1030 == nil { arg_1027 = ifn_1031.Invoke_O__O(arg_1032) } else { arg_1027 = linked_1030.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1029, arg_1032) }; var arg_1028 any; if linked_1025 == nil { return ifn_1026.Invoke_O_O__O(arg_1027, arg_1028) } else { return linked_1025.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1024, arg_1027, arg_1028) } } } else { var vec__1078000151__4 any; var root_1033 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = s__1078000141__3; if linked_1034 == nil { vec__1078000151__4 = ifn_1035.Invoke_O__O(arg_1036) } else { vec__1078000151__4 = linked_1034.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1033, arg_1036) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000151__4, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000151__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1037 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any; var tmp6 any; var root_1042 any = A_arbace_classes_native_A_const_116.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_classes_native_local_class_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = lb__6; if linked_1043 == nil { tmp6 = ifn_1044.Invoke_O__O(arg_1045) } else { tmp6 = linked_1043.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_1042, arg_1045) }; arg_1040 = lang.Tuple_Create_O_O__IPersistentVector(s__5, tmp6); var arg_1041 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000140); var tmp8 any; var root_1046 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = s__1078000141__3; if linked_1047 == nil { tmp8 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp8 = linked_1047.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1046, arg_1049) }; arg_1041 = tmp7.Invoke_O__O(tmp8); if linked_1038 == nil { return ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { return linked_1038.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A) Ctor_O_I_O(c__b__1078000143 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000143 = c__b__1078000143; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A) Invoke_O__O(self any) any { { var i__1078000142__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000142__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000147__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000142__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000147__2, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000147__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1000 any = A_arbace_classes_native_A_const_41.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = t.F_b__1078000143; var arg_1004 any; var tmp2 any; var root_1005 any = A_arbace_classes_native_A_const_116.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, A_arbace_classes_native_local_class_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = lb__4; if linked_1006 == nil { tmp2 = ifn_1007.Invoke_O__O(arg_1008) } else { tmp2 = linked_1006.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_1005, arg_1008) }; arg_1004 = lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp2); if linked_1001 == nil { ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { linked_1001.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) }; i__1078000142__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000142__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_compile_fn_fn__1078000156_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000156_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000156_A{}; t.Ctor_O(p0); return t }
//line :184:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000156_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :184:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000156_A) Invoke_O_O__O(self, p1__1078000137_SHARP___1 any) any { var root_1063 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = t.F_host; var arg_1067 any = p1__1078000137_SHARP___1; if linked_1064 == nil { return ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { return linked_1064.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) } }
func A_arbace_classes_native_compile_fn_fn__1078000158_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000158_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000158_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000158_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :185:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000158_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(s__1, lang.IFn_Cast(t.F_host).Invoke_O__O(s__1)) }
func A_arbace_classes_native_compile_fn_fn__1078000160_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_native_compile_fn_fn__1078000160_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000160_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :186:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_A) Ctor_O_O_O_O_O_O(c__form, c__host, c__ns, c__syms, c__cname, c__captured any) { t.F_form = c__form; t.F_host = c__host; t.F_ns = c__ns; t.F_syms = c__syms; t.F_cname = c__cname; t.F_captured = c__captured }
//line :186:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1096 any = A_arbace_classes_native_A_const_81.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = lang.IFn_Cast(A_arbace_classes_native_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_83, t.F_ns); if linked_1097 == nil { ifn_1098.Invoke_O__O(arg_1099) } else { linked_1097.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1096, arg_1099) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_1087 any = A_arbace_classes_native_A_const_119.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, A_arbace_classes_native_fn_class_form_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any; var t__2 any = t.F_cname; t.F_cname = nil; arg_1090 = t__2; var arg_1091 any; var t__3 any = t.F_form; t.F_form = nil; arg_1091 = t__3; var arg_1092 any; var t__4 any = t.F_captured; t.F_captured = nil; arg_1092 = t__4; if linked_1088 == nil { tmp5 = ifn_1089.Invoke_O_O_O__O(arg_1090, arg_1091, arg_1092) } else { tmp5 = linked_1088.(*A_arbace_classes_native_fn_class_form_A).Invoke_O_O_O_O__O(root_1087, arg_1090, arg_1091, arg_1092) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :187:1
		return nil }(); var root_1093 any = A_arbace_classes_native_A_const_80.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; if linked_1094 == nil { ifn_1095.Invoke__O() } else { linked_1094.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1093) }
//line :186:1
		if tmp6 != nil { panic(tmp6) } }; return nil }(); if tmp7 != nil { if lang.ExceptionInfo_InstanceOf(tmp7) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp7); var u__4 any; var root_1105 any = A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1107 lang.IFn





			if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var fnbody__1115 any = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_New(); var tmp8 *jrt.Class; var fncls__1114 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_fn_class; if fncls__1114 == nil { var fncls__1114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_fn_class = fncls__1114d; tmp8 = fncls__1114d } else { tmp8 = fncls__1114 }; arg_1108 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1115, tmp8, nil); var arg_1109 any; var root_1116 any = A_arbace_classes_native_A_const_122.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = A_arbace_classes_native_A_const_123.GetRawRoot__O(); var arg_1120 any; var root_1121 any = A_arbace_classes_native_A_const_124.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any; var fnbody__1127 any = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_New(); var tmp9 *jrt.Class; var fncls__1126 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_fn_class; if fncls__1126 == nil { var fncls__1126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_fn_class = fncls__1126d; tmp9 = fncls__1126d } else { tmp9 = fncls__1126 }; arg_1124 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1127, tmp9, nil); var arg_1125 any = e__3; if linked_1122 == nil { arg_1120 = ifn_1123.Invoke_O_O__O(arg_1124, arg_1125) } else { arg_1120 = linked_1122.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1121, arg_1124, arg_1125) }; if linked_1117 == nil { arg_1109 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { arg_1109 = linked_1117.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }; if linked_1106 == nil { u__4 = ifn_1107.Invoke_O_O__O(arg_1108, arg_1109) } else { u__4 = linked_1106.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1105, arg_1108, arg_1109) }
			var tmp10 any; var and__1927000168__auto____5 any = u__4; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1128 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any; var t__5 any = t.F_host; t.F_host = nil; arg_1131 = t__5; var arg_1132 any = u__4; if linked_1129 == nil { and__1927000168__auto____6 = ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { and__1927000168__auto____6 = linked_1129.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1133 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any; var root_1137 any = A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, u__4)); var arg_1141 any; var t__6 any = t.F_syms; t.F_syms = nil; arg_1141 = t__6; if linked_1138 == nil { arg_1136 = ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { arg_1136 = linked_1138.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) }; if linked_1134 == nil { tmp10 = ifn_1135.Invoke_O__O(arg_1136) } else { tmp10 = linked_1134.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1133, arg_1136) } } else { tmp10 = and__1927000168__auto____6 } } else { tmp10 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp10) { tmp1 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_classes_native_A_const_125, u__4) } else { panic(jrt.Thrown(e__3)) } } else {
//line :186:1
				panic(tmp7) } }; return tmp1 }





func A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_New() *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A) Ctor() {}
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A) Invoke_O_O__O(self, p1__1078000138_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_native_A_const_120; var tmp2 any; var root_1110 any = A_arbace_classes_native_A_const_121.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = p1__1078000138_SHARP___1; if linked_1111 == nil { tmp2 = ifn_1112.Invoke_O__O(arg_1113) } else { tmp2 = linked_1111.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1110, arg_1113) }; return tmp1.Invoke_O__O(tmp2) }
//line :192:1
func A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_New() *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A) Ctor() {}
//line :192:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A) Invoke_O_O__O(self, p1__1078000139_SHARP___1 any) any { return jrt.Throwable_Cast(p1__1078000139_SHARP___1).GetCause__Throwable() }







































































































type A_arbace_classes_native_A struct{ jrt.Object }

var A_arbace_classes_native_A_const_pool *jrt.RefArray

var A_arbace_classes_native_A_const_0 *lang.Var

var A_arbace_classes_native_A_const_1 any

var A_arbace_classes_native_A_const_2 any

var A_arbace_classes_native_A_const_3 any

var A_arbace_classes_native_A_const_4 any

var A_arbace_classes_native_A_const_5 *lang.Var

var A_arbace_classes_native_A_const_6 any

var A_arbace_classes_native_A_const_7 *lang.Var

var A_arbace_classes_native_A_const_8 *lang.Var

var A_arbace_classes_native_A_const_9 *lang.Var

var A_arbace_classes_native_A_const_10 *lang.Var

var A_arbace_classes_native_A_const_11 any

var A_arbace_classes_native_A_const_12 *lang.Var

var A_arbace_classes_native_A_const_13 *lang.Var

var A_arbace_classes_native_A_const_14 *lang.Var

var A_arbace_classes_native_A_const_15 *lang.Var

var A_arbace_classes_native_A_const_16 *lang.Var

var A_arbace_classes_native_A_const_17 *lang.Var

var A_arbace_classes_native_A_const_18 *lang.Var

var A_arbace_classes_native_A_const_19 *lang.Var

var A_arbace_classes_native_A_const_20 *lang.Var

var A_arbace_classes_native_A_const_21 *lang.Var

var A_arbace_classes_native_A_const_22 *lang.Var

var A_arbace_classes_native_A_const_23 *lang.Keyword

var A_arbace_classes_native_A_const_24 *lang.Var

var A_arbace_classes_native_A_const_25 *lang.Var

var A_arbace_classes_native_A_const_26 *lang.Var

var A_arbace_classes_native_A_const_27 *lang.Var

var A_arbace_classes_native_A_const_28 *lang.Var

var A_arbace_classes_native_A_const_29 *lang.Var

var A_arbace_classes_native_A_const_30 *lang.Var

var A_arbace_classes_native_A_const_31 *lang.Var

var A_arbace_classes_native_A_const_32 *lang.Var

var A_arbace_classes_native_A_const_33 *lang.Var

var A_arbace_classes_native_A_const_34 *lang.Var

var A_arbace_classes_native_A_const_35 *lang.Var

var A_arbace_classes_native_A_const_36 *lang.Var

var A_arbace_classes_native_A_const_37 *lang.Var

var A_arbace_classes_native_A_const_38 any

var A_arbace_classes_native_A_const_39 *lang.Var

var A_arbace_classes_native_A_const_40 *lang.Keyword

var A_arbace_classes_native_A_const_41 *lang.Var

var A_arbace_classes_native_A_const_42 *lang.Var

var A_arbace_classes_native_A_const_43 *lang.Var

var A_arbace_classes_native_A_const_44 any

var A_arbace_classes_native_A_const_45 *lang.Var

var A_arbace_classes_native_A_const_46 *lang.Var

var A_arbace_classes_native_A_const_47 *lang.Var

var A_arbace_classes_native_A_const_48 *lang.Keyword

var A_arbace_classes_native_A_const_49 *lang.Var

var A_arbace_classes_native_A_const_50 *lang.Var

var A_arbace_classes_native_A_const_51 *lang.Var

var A_arbace_classes_native_A_const_52 *lang.Var

var A_arbace_classes_native_A_const_53 any

var A_arbace_classes_native_A_const_54 *lang.Var

var A_arbace_classes_native_A_const_55 any

var A_arbace_classes_native_A_const_56 *lang.Var

var A_arbace_classes_native_A_const_57 *lang.Var

var A_arbace_classes_native_A_const_58 *lang.Var

var A_arbace_classes_native_A_const_59 *lang.Keyword

var A_arbace_classes_native_A_const_60 *lang.Var

var A_arbace_classes_native_A_const_61 *lang.Var

var A_arbace_classes_native_A_const_62 *lang.Var

var A_arbace_classes_native_A_const_63 *lang.Keyword

var A_arbace_classes_native_A_const_64 *lang.Keyword

var A_arbace_classes_native_A_const_65 *lang.Var

var A_arbace_classes_native_A_const_66 *lang.Var

var A_arbace_classes_native_A_const_67 *lang.Keyword

var A_arbace_classes_native_A_const_68 *lang.Keyword

var A_arbace_classes_native_A_const_69 *lang.Var

var A_arbace_classes_native_A_const_70 *lang.Keyword

var A_arbace_classes_native_A_const_71 *lang.Var

var A_arbace_classes_native_A_const_72 *lang.Keyword

var A_arbace_classes_native_A_const_73 *lang.Var

var A_arbace_classes_native_A_const_74 *lang.Var

var A_arbace_classes_native_A_const_75 *lang.Var

var A_arbace_classes_native_A_const_76 any

var A_arbace_classes_native_A_const_77 any

var A_arbace_classes_native_A_const_78 *lang.Var

var A_arbace_classes_native_A_const_79 *lang.Var

var A_arbace_classes_native_A_const_80 *lang.Var

var A_arbace_classes_native_A_const_81 *lang.Var

var A_arbace_classes_native_A_const_82 *lang.Var

var A_arbace_classes_native_A_const_83 *lang.Var

var A_arbace_classes_native_A_const_84 *lang.Var

var A_arbace_classes_native_A_const_85 *lang.Var

var A_arbace_classes_native_A_const_86 *jrt.Class

var A_arbace_classes_native_A_const_87 *lang.Var

var A_arbace_classes_native_A_const_88 *lang.Var

var A_arbace_classes_native_A_const_89 *lang.Var

var A_arbace_classes_native_A_const_90 *lang.Keyword

var A_arbace_classes_native_A_const_91 *lang.Keyword

var A_arbace_classes_native_A_const_92 *lang.Var

var A_arbace_classes_native_A_const_93 any

var A_arbace_classes_native_A_const_94 *lang.Var

var A_arbace_classes_native_A_const_95 *lang.Var

var A_arbace_classes_native_A_const_96 *lang.Var

var A_arbace_classes_native_A_const_97 *lang.Var

var A_arbace_classes_native_A_const_98 any

var A_arbace_classes_native_A_const_99 any

var A_arbace_classes_native_A_const_100 *lang.Var

var A_arbace_classes_native_A_const_101 any

var A_arbace_classes_native_A_const_102 *lang.Keyword

var A_arbace_classes_native_A_const_103 *lang.Keyword

var A_arbace_classes_native_A_const_104 *lang.Keyword

var A_arbace_classes_native_A_const_105 *lang.Var

var A_arbace_classes_native_A_const_106 any

var A_arbace_classes_native_A_const_107 *lang.Var

var A_arbace_classes_native_A_const_108 *lang.Keyword

var A_arbace_classes_native_A_const_109 *lang.Var

var A_arbace_classes_native_A_const_110 *lang.Var

var A_arbace_classes_native_A_const_111 any

var A_arbace_classes_native_A_const_112 any

var A_arbace_classes_native_A_const_113 any

var A_arbace_classes_native_A_const_114 any

var A_arbace_classes_native_A_const_115 *lang.Var

var A_arbace_classes_native_A_const_116 *lang.Var

var A_arbace_classes_native_A_const_117 *lang.Var

var A_arbace_classes_native_A_const_118 *lang.Var

var A_arbace_classes_native_A_const_119 *lang.Var

var A_arbace_classes_native_A_const_120 *lang.Keyword

var A_arbace_classes_native_A_const_121 *lang.Var

var A_arbace_classes_native_A_const_122 *lang.Var

var A_arbace_classes_native_A_const_123 *lang.Var

var A_arbace_classes_native_A_const_124 *lang.Var

var A_arbace_classes_native_A_const_125 *lang.Keyword

var A_arbace_classes_native_A_const_126 any

var A_arbace_classes_native_A_const_127 *lang.Var

var A_arbace_classes_native_A_const_128 any

var A_arbace_classes_native_A_init jrt.ClassInit

func A_arbace_classes_native_A_Init() { if !A_arbace_classes_native_A_init.Done() { A_arbace_classes_native_A_init.Run(A_arbace_classes_native_A_clinit) } }

func A_arbace_classes_native_A_clinit() { A_arbace_classes_native_A_clinit_p0(); A_arbace_classes_native_A_clinit_p1(); A_arbace_classes_native_A_clinit_p2(); A_arbace_classes_native_A_clinit_p3(); A_arbace_classes_native_A_clinit_p4(); A_arbace_classes_native_A_clinit_p5(); A_arbace_classes_native_A_clinit_p6(); A_arbace_classes_native_A_clinit_p7(); A_arbace_classes_native_A_clinit_p8(); A_arbace_classes_native_A_clinit_p9(); A_arbace_classes_native_A_clinit_p10() }

func A_arbace_classes_native_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_native_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 175); A_arbace_classes_native_A_const_0 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[46]); A_arbace_classes_native_A_const_1 = A_arbace_classes_native_A_const_pool.A[47]; A_arbace_classes_native_A_const_2 = A_arbace_classes_native_A_const_pool.A[48]; A_arbace_classes_native_A_const_3 = A_arbace_classes_native_A_const_pool.A[49]; A_arbace_classes_native_A_const_4 = A_arbace_classes_native_A_const_pool.A[50]; A_arbace_classes_native_A_const_5 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[51]); A_arbace_classes_native_A_const_6 = A_arbace_classes_native_A_const_pool.A[52]; A_arbace_classes_native_A_const_7 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[53]); A_arbace_classes_native_A_const_8 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[54]); A_arbace_classes_native_A_const_9 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[55]); A_arbace_classes_native_A_const_10 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[56]); A_arbace_classes_native_A_const_11 = A_arbace_classes_native_A_const_pool.A[57] }

func A_arbace_classes_native_A_clinit_p1() { A_arbace_classes_native_A_const_12 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[58]); A_arbace_classes_native_A_const_13 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[59]); A_arbace_classes_native_A_const_14 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[60]); A_arbace_classes_native_A_const_15 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[61]); A_arbace_classes_native_A_const_16 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[62]); A_arbace_classes_native_A_const_17 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[63]); A_arbace_classes_native_A_const_18 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[64]); A_arbace_classes_native_A_const_19 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[65]); A_arbace_classes_native_A_const_20 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[66]); A_arbace_classes_native_A_const_21 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[67]); A_arbace_classes_native_A_const_22 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[68]); A_arbace_classes_native_A_const_23 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[69]) }

func A_arbace_classes_native_A_clinit_p2() { A_arbace_classes_native_A_const_24 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[70]); A_arbace_classes_native_A_const_25 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[71]); A_arbace_classes_native_A_const_26 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[72]); A_arbace_classes_native_A_const_27 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[73]); A_arbace_classes_native_A_const_28 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[74]); A_arbace_classes_native_A_const_29 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[75]); A_arbace_classes_native_A_const_30 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[76]); A_arbace_classes_native_A_const_31 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[77]); A_arbace_classes_native_A_const_32 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[78]); A_arbace_classes_native_A_const_33 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[79]); A_arbace_classes_native_A_const_34 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[80]); A_arbace_classes_native_A_const_35 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[81]) }

func A_arbace_classes_native_A_clinit_p3() { A_arbace_classes_native_A_const_36 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[82]); A_arbace_classes_native_A_const_37 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[83]); A_arbace_classes_native_A_const_38 = A_arbace_classes_native_A_const_pool.A[84]; A_arbace_classes_native_A_const_39 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[85]); A_arbace_classes_native_A_const_40 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[86]); A_arbace_classes_native_A_const_41 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[87]); A_arbace_classes_native_A_const_42 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[88]); A_arbace_classes_native_A_const_43 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[89]); A_arbace_classes_native_A_const_44 = A_arbace_classes_native_A_const_pool.A[90]; A_arbace_classes_native_A_const_45 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[91]); A_arbace_classes_native_A_const_46 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[92]); A_arbace_classes_native_A_const_47 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[93]) }

func A_arbace_classes_native_A_clinit_p4() { A_arbace_classes_native_A_const_48 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[94]); A_arbace_classes_native_A_const_49 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[95]); A_arbace_classes_native_A_const_50 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[96]); A_arbace_classes_native_A_const_51 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[97]); A_arbace_classes_native_A_const_52 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[98]); A_arbace_classes_native_A_const_53 = A_arbace_classes_native_A_const_pool.A[99]; A_arbace_classes_native_A_const_54 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[100]); A_arbace_classes_native_A_const_55 = A_arbace_classes_native_A_const_pool.A[101]; A_arbace_classes_native_A_const_56 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[102]); A_arbace_classes_native_A_const_57 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[103]); A_arbace_classes_native_A_const_58 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[104]); A_arbace_classes_native_A_const_59 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[105]) }

func A_arbace_classes_native_A_clinit_p5() { A_arbace_classes_native_A_const_60 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[106]); A_arbace_classes_native_A_const_61 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[107]); A_arbace_classes_native_A_const_62 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[108]); A_arbace_classes_native_A_const_63 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[109]); A_arbace_classes_native_A_const_64 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[110]); A_arbace_classes_native_A_const_65 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[111]); A_arbace_classes_native_A_const_66 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[112]); A_arbace_classes_native_A_const_67 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[113]); A_arbace_classes_native_A_const_68 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[114]); A_arbace_classes_native_A_const_69 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[115]); A_arbace_classes_native_A_const_70 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[116]); A_arbace_classes_native_A_const_71 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[117]) }

func A_arbace_classes_native_A_clinit_p6() { A_arbace_classes_native_A_const_72 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[118]); A_arbace_classes_native_A_const_73 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[119]); A_arbace_classes_native_A_const_74 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[120]); A_arbace_classes_native_A_const_75 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[121]); A_arbace_classes_native_A_const_76 = A_arbace_classes_native_A_const_pool.A[122]; A_arbace_classes_native_A_const_77 = A_arbace_classes_native_A_const_pool.A[123]; A_arbace_classes_native_A_const_78 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[124]); A_arbace_classes_native_A_const_79 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[125]); A_arbace_classes_native_A_const_80 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[126]); A_arbace_classes_native_A_const_81 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[127]); A_arbace_classes_native_A_const_82 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[128]); A_arbace_classes_native_A_const_83 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[129]) }

func A_arbace_classes_native_A_clinit_p7() { A_arbace_classes_native_A_const_84 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[130]); A_arbace_classes_native_A_const_85 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[131]); A_arbace_classes_native_A_const_86 = jrt.Class_Cast(A_arbace_classes_native_A_const_pool.A[132]); A_arbace_classes_native_A_const_87 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[133]); A_arbace_classes_native_A_const_88 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[134]); A_arbace_classes_native_A_const_89 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[135]); A_arbace_classes_native_A_const_90 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[136]); A_arbace_classes_native_A_const_91 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[137]); A_arbace_classes_native_A_const_92 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[138]); A_arbace_classes_native_A_const_93 = A_arbace_classes_native_A_const_pool.A[139]; A_arbace_classes_native_A_const_94 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[140]); A_arbace_classes_native_A_const_95 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[141]) }

func A_arbace_classes_native_A_clinit_p8() { A_arbace_classes_native_A_const_96 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[142]); A_arbace_classes_native_A_const_97 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[143]); A_arbace_classes_native_A_const_98 = A_arbace_classes_native_A_const_pool.A[144]; A_arbace_classes_native_A_const_99 = A_arbace_classes_native_A_const_pool.A[145]; A_arbace_classes_native_A_const_100 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[146]); A_arbace_classes_native_A_const_101 = A_arbace_classes_native_A_const_pool.A[147]; A_arbace_classes_native_A_const_102 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[148]); A_arbace_classes_native_A_const_103 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[149]); A_arbace_classes_native_A_const_104 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[150]); A_arbace_classes_native_A_const_105 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[151]); A_arbace_classes_native_A_const_106 = A_arbace_classes_native_A_const_pool.A[152]; A_arbace_classes_native_A_const_107 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[153]); A_arbace_classes_native_A_const_108 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[154]) }

func A_arbace_classes_native_A_clinit_p9() { A_arbace_classes_native_A_const_109 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[155]); A_arbace_classes_native_A_const_110 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[156]); A_arbace_classes_native_A_const_111 = A_arbace_classes_native_A_const_pool.A[157]; A_arbace_classes_native_A_const_112 = A_arbace_classes_native_A_const_pool.A[158]; A_arbace_classes_native_A_const_113 = A_arbace_classes_native_A_const_pool.A[159]; A_arbace_classes_native_A_const_114 = A_arbace_classes_native_A_const_pool.A[160]; A_arbace_classes_native_A_const_115 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[161]); A_arbace_classes_native_A_const_116 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[162]); A_arbace_classes_native_A_const_117 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[163]); A_arbace_classes_native_A_const_118 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[164]); A_arbace_classes_native_A_const_119 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[165]); A_arbace_classes_native_A_const_120 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[166]); A_arbace_classes_native_A_const_121 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[167]) }

func A_arbace_classes_native_A_clinit_p10() { A_arbace_classes_native_A_const_122 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[168]); A_arbace_classes_native_A_const_123 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[169]); A_arbace_classes_native_A_const_124 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[170]); A_arbace_classes_native_A_const_125 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[171]); A_arbace_classes_native_A_const_126 = A_arbace_classes_native_A_const_pool.A[172]; A_arbace_classes_native_A_const_127 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[173]); A_arbace_classes_native_A_const_128 = A_arbace_classes_native_A_const_pool.A[174] }

func A_arbace_classes_native_A_New() *A_arbace_classes_native_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_A) Ctor() {}

func (t *A_arbace_classes_native_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_A_class }

func (t *A_arbace_classes_native_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_A); return ok }

func A_arbace_classes_native_A_Cast(x any) *A_arbace_classes_native_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_A_class)) }; return v }



type A_arbace_classes_native_compile_and_load_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A struct{ j2g_header uint64; F_s__1078000034, F_iter__1078000033 any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1078000036 any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000033__1078000037_fn__1078000038_fn__1078000039_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_deftype_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_fn__1078000067_A struct{ j2g_header uint64; F_form, F_ns any }

var A_arbace_classes_native_compile_deftype_fn__1078000067_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000156_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000156_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000158_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000158_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000160_A struct{ j2g_header uint64; F_form, F_host, F_ns, F_syms, F_cname, F_captured any }

var A_arbace_classes_native_compile_fn_fn__1078000160_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000161_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000160_fn__1078000163_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A struct{ j2g_header uint64; F_s__1078000141, F_iter__1078000140 any }

var A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A struct{ j2g_header uint64; F_b__1078000143 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_fn_iter__1078000140__1078000144_fn__1078000145_fn__1078000146_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_iter__1078000050__1078000054_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A struct{ j2g_header uint64; F_s__1078000051, F_iter__1078000050 any }

var A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A struct{ j2g_header uint64; F_b__1078000053 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_top_iter__1078000050__1078000054_fn__1078000055_fn__1078000056_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000004_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000004_A_New() *A_arbace_classes_native_eval1078000004_A { t := &A_arbace_classes_native_eval1078000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000004_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000004_A_class }

func (t *A_arbace_classes_native_eval1078000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000004_A); return ok }

func A_arbace_classes_native_eval1078000004_A_Cast(x any) *A_arbace_classes_native_eval1078000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000004_A_class)) }; return v }



type A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000008_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000008_A_New() *A_arbace_classes_native_eval1078000008_A { t := &A_arbace_classes_native_eval1078000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000008_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000008_A_class }

func (t *A_arbace_classes_native_eval1078000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000008_A); return ok }

func A_arbace_classes_native_eval1078000008_A_Cast(x any) *A_arbace_classes_native_eval1078000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000008_A_class)) }; return v }



type A_arbace_classes_native_eval1078000008_fn__1078000009_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class *jrt.Class



type A_arbace_classes_native_field_names_A struct{ j2g_header uint64 }

var A_arbace_classes_native_field_names_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000115_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_fn__1078000115_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000131_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_fn__1078000131_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A struct{ j2g_header uint64; F_s__1078000093, F_iter__1078000092, F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A struct{ j2g_header uint64; F_b__1078000095, F_typed any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000092__1078000096_fn__1078000097_fn__1078000098_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A struct{ j2g_header uint64; F_s__1078000121, F_iter__1078000120, F_rcv any }

var A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A struct{ j2g_header uint64; F_rcv any; F_size__1927001038__auto__ int32; F_b__1078000123, F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000120__1078000124_fn__1078000125_fn__1078000126_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_typed__1078000090_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_typed__1078000090_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_A struct{ j2g_header uint64 }

var A_arbace_classes_native_form_vars_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A struct{ j2g_header uint64; F_ns any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A struct{ j2g_header uint64; F_ns, F_s__1078000014, F_iter__1078000013 any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A struct{ j2g_header uint64; F_b__1078000016, F_ns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A struct{ j2g_header uint64; F_ns, F_s any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000019_fn__1078000020_A_fn_class *jrt.Class



type A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A struct{ j2g_header uint64; F_ns, F_s any }

var A_arbace_classes_native_form_vars_iter__1078000013__1078000017_fn__1078000018_fn__1078000024_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_A struct{ j2g_header uint64 }

var A_arbace_classes_native_local_class_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000072_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000072_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000074_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000074_A_fn_class *jrt.Class



type A_arbace_classes_native_public_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_native_public_class_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_native_symbols_A struct{ j2g_header uint64 }

var A_arbace_classes_native_symbols_A_fn_class *jrt.Class



type A_arbace_classes_native_type_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_type_form_A_fn_class *jrt.Class
