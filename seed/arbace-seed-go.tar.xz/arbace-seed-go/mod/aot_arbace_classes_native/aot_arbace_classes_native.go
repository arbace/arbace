//line aot_arbace_classes_native.ae:1
package aot_arbace_classes_native

import (
	"arbace/aot_arbace_classes_lower"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New() *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_native_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_classes_native_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_native_A_const_1, A_arbace_classes_native_A_const_2, A_arbace_classes_native_A_const_3, A_arbace_classes_native_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_native_eval1078000008_fn__1078000009_A_New() *A_arbace_classes_native_eval1078000008_fn__1078000009_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_eval1078000008_fn__1078000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_classes_native_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_classes_native_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_native_A_const_10.GetRawRoot__O(), A_arbace_classes_native_A_const_11) }



































func A_arbace_classes_native_compile_and_load_BANG__A_New() *A_arbace_classes_native_compile_and_load_BANG__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_native_compile_and_load_BANG__A) DoInvoke_O_O_O_O__O(self, ns__0, forms__1, p__1078000012__2 any) any { var map__1078000013__4 any = p__1078000012__2; var map__1078000013__5 any; if lang.ISeq_InstanceOf(map__1078000013__4) { var tmp1 any; var root_22 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = map__1078000013__4; if linked_23 == nil { tmp1 = ifn_24.Invoke_O__O(arg_25) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_22, arg_25) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_26 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = map__1078000013__4; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_26, arg_29) }; map__1078000013__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_30 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = map__1078000013__4; if linked_31 == nil { tmp3 = ifn_32.Invoke_O__O(arg_33) } else { tmp3 = linked_31.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_30, arg_33) }; if jrt.J2g_Truth(tmp3) { var root_34 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = map__1078000013__4; if linked_35 == nil { map__1078000013__5 = ifn_36.Invoke_O__O(arg_37) } else { map__1078000013__5 = linked_35.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_34, arg_37) } } else { map__1078000013__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000013__5 = map__1078000013__4 }; var siblings__6 any = lang.RT_Get_O_O__O_NoInit(map__1078000013__5, A_arbace_classes_native_A_const_16); var loaded__7 any = lang.IFn_Cast(A_arbace_classes_native_A_const_17.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__1, A_arbace_classes_native_A_const_16, siblings__6); if



	jrt.J2g_Truth(A_arbace_classes_native_A_const_18.GetRawRoot__O()) {
		var root_45 any = A_arbace_classes_native_A_const_19.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = A_arbace_classes_native_A_const_18.GetRawRoot__O(); var arg_49 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var arg_50 any; var tmp4 any = A_arbace_classes_native_A_const_20; var tmp5 any; var root_51 any = A_arbace_classes_native_A_const_21.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_53 lang.IFn
		if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = ns__0; if linked_52 == nil { tmp5 = ifn_53.Invoke_O__O(arg_54) } else { tmp5 = linked_52.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_51, arg_54) }
//line :42:1
		var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_native_A_const_22; var tmp8 any; var root_55 any = A_arbace_classes_native_A_const_23.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_57 lang.IFn

		if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = lang.IFn_Cast(A_arbace_classes_native_A_const_24.GetRawRoot__O()).Invoke__O(); var arg_59 any; var iter__1927001039__auto____8 any; var tmp9 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_New(); var tmp10 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class
		if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class = fncls__133d; tmp10 = fncls__133d } else { tmp10 = fncls__133 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp12 any; var root_134 any = A_arbace_classes_native_A_const_35.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_ns_imports_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = ns__0; if linked_135 == nil { tmp12 = ifn_136.Invoke_O__O(arg_137) } else { tmp12 = linked_135.(*aot_arbace_core.A_arbace_core_ns_imports_A).Invoke_O_O__O(root_134, arg_137) }; arg_59 = tmp11.Invoke_O__O(tmp12)
//line :44:1
		if linked_56 == nil { tmp8 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { tmp8 = linked_56.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }
//line :42:1
		var tmp13 any = tmp8; var tmp14 any = A_arbace_classes_native_A_const_36; var tmp15 any; var root_138 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_140 lang.IFn





		if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = forms__1; if linked_139 == nil { tmp15 = ifn_140.Invoke_O__O(arg_141) } else { tmp15 = linked_139.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_138, arg_141) }
//line :42:1
		var tmp16 any = tmp15; var tmp17 any = A_arbace_classes_native_A_const_38; var tmp18 any; var root_142 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_144 lang.IFn






		if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var arg_146 any = loaded__7; if linked_143 == nil { tmp18 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { tmp18 = linked_143.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) }
//line :42:1
		arg_50 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp13, tmp14, tmp16, tmp17, tmp18)); if linked_46 == nil { ifn_47.Invoke_O_O_O__O(arg_48, arg_49, arg_50) } else { linked_46.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_45, arg_48, arg_49, arg_50) } }; return loaded__7 }


func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_New() *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A) Ctor() {}
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A) Invoke_O_O__O(self, s__1078000016__1 any) any { var tmp1 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_New_O_O(s__1078000016__1, self); var tmp2 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class = fncls__132d; tmp2 = fncls__132d } else { tmp2 = fncls__132 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :45:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A) Ctor_O_O(c__s__1078000016, c__iter__1078000015 any) { t.F_s__1078000016 = c__s__1078000016; t.F_iter__1078000015 = c__iter__1078000015 }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A) Invoke_O__O(self any) any { { var s__1078000016__1 any; var t_ any = t.F_s__1078000016; t.F_s__1078000016 = nil; s__1078000016__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_63 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = s__1078000016__1; if linked_64 == nil { temp__1927000414__auto____2 = ifn_65.Invoke_O__O(arg_66) } else { temp__1927000414__auto____2 = linked_64.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_63, arg_66) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000016__3 any = temp__1927000414__auto____2; var tmp1 any; var root_67 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = s__1078000016__3; if linked_68 == nil { tmp1 = ifn_69.Invoke_O__O(arg_70) } else { tmp1 = linked_68.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_67, arg_70) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_71 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = s__1078000016__3; if linked_72 == nil { c__1927001037__auto____4 = ifn_73.Invoke_O__O(arg_74) } else { c__1927001037__auto____4 = linked_72.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_71, arg_74) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000018__6 any; var root_75 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_76 == nil { b__1078000018__6 = ifn_77.Invoke_O__O(arg_78) } else { b__1078000018__6 = linked_76.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_75, arg_78) }; var tmp2 any = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_New_O_I_O(b__1078000018__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_89 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any; var root_94 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = b__1078000018__6; if linked_95 == nil { arg_92 = ifn_96.Invoke_O__O(arg_97) } else { arg_92 = linked_95.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_94, arg_97) }; var arg_93 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000015); var tmp5 any; var root_98 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = s__1078000016__3; if linked_99 == nil { tmp5 = ifn_100.Invoke_O__O(arg_101) } else { tmp5 = linked_99.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_98, arg_101) }; arg_93 = tmp4.Invoke_O__O(tmp5); if linked_90 == nil { return ifn_91.Invoke_O_O__O(arg_92, arg_93) } else { return linked_90.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_89, arg_92, arg_93) } } else { var root_102 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any; var root_107 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = b__1078000018__6; if linked_108 == nil { arg_105 = ifn_109.Invoke_O__O(arg_110) } else { arg_105 = linked_108.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_107, arg_110) }; var arg_106 any; if linked_103 == nil { return ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { return linked_103.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) } } } else { var vec__1078000026__4 any; var root_111 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = s__1078000016__3; if linked_112 == nil { vec__1078000026__4 = ifn_113.Invoke_O__O(arg_114) } else { vec__1078000026__4 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; var sym__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000026__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000026__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_115 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_117 lang.IFn
																	if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__6, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__5))).Ref(); if linked_116 == nil { tmp6 = ifn_117.Invoke_O__O(arg_118) } else { tmp6 = linked_116.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_115, arg_118) }
//line :45:1
	if jrt.J2g_Truth(tmp6) { var root_119 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = lang.Tuple_Create_O_O__IPersistentVector(sym__5, jrt.NN(jrt.Class_Cast(c__6)).GetName__String().Ref()); var arg_123 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000015); var tmp8 any; var root_124 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__1078000016__3; if linked_125 == nil { tmp8 = ifn_126.Invoke_O__O(arg_127) } else { tmp8 = linked_125.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_124, arg_127) }; arg_123 = tmp7.Invoke_O__O(tmp8); if linked_120 == nil { return ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { return linked_120.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) } } else { var tmp9 any; var root_128 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = s__1078000016__3; if linked_129 == nil { tmp9 = ifn_130.Invoke_O__O(arg_131) } else { tmp9 = linked_129.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_128, arg_131) }; s__1078000016__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :45:1
func A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A) Ctor_O_I_O(c__b__1078000018 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000018 = c__b__1078000018; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :45:1
func (t *A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A) Invoke_O__O(self any) any { { var i__1078000017__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000022__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000017__1)); var sym__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000022__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000022__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_79 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_81 lang.IFn
																		if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(c__4, lang.RT_Get_O_O__O_NoInit(lang.RT_DEFAULT_IMPORTS, sym__3))).Ref(); if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_79, arg_82) }
//line :45:1
	if jrt.J2g_Truth(tmp2) { var root_83 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = t.F_b__1078000018; var arg_87 any = lang.Tuple_Create_O_O__IPersistentVector(sym__3, jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref()); if linked_84 == nil { ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { linked_84.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) }; i__1078000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000017__1); continue L1 } else { i__1078000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000017__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_native_compile_top_A_New() *A_arbace_classes_native_compile_top_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_native_compile_top_A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_native_compile_top_A) Invoke_O_O_O_O_O__O(self, ns__0, kind__1, forms__2, siblings__3 any) any { var forms__5 any; if






	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_40, kind__1) { forms__5 = lang.Tuple_Create_O__IPersistentVector(forms__2) } else { var root_147 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = forms__2; if linked_148 == nil { forms__5 = ifn_149.Invoke_O__O(arg_150) } else { forms__5 = linked_148.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_147, arg_150) } }; var loaded__6 any = /*line :52:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()).Invoke_O_O_O_O__O(ns__0, forms__5, A_arbace_classes_native_A_const_16, siblings__3); var root_158 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_160 lang.IFn; if






	linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_42.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_44); var tmp3 any; var iter__1927001039__auto____7 any; var tmp4 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_New(); var tmp5 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class; if


	fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class = fncls__226d; tmp5 = fncls__226d } else { tmp5 = fncls__226 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(loaded__6); var tmp6 any = tmp3; var tmp7 lang.IFn = /*line :59:1*/lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp8 any; if



	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_native_A_const_40, kind__1) { var root_227 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any; var root_231 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = loaded__6; if linked_232 == nil { arg_230 = ifn_233.Invoke_O__O(arg_234) } else { arg_230 = linked_232.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_231, arg_234) }; if linked_228 == nil { tmp8 = ifn_229.Invoke_O__O(arg_230) } else { tmp8 = linked_228.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_227, arg_230) } } else { var root_235 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var arg_239 any = loaded__6; if linked_236 == nil { tmp8 = ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { tmp8 = linked_236.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_235, arg_238, arg_239) } }; arg_161 = /*line :59:1*/tmp1.Invoke_O_O_O__O(tmp2, tmp6, tmp7.Invoke_O__O(tmp8)); if linked_159 == nil { return ifn_160.Invoke_O__O(arg_161) } else { return linked_159.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_158, arg_161) } }


func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_New() *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A) Invoke_O_O__O(self, s__1078000033__1 any) any { var tmp1 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_New_O_O(s__1078000033__1, self); var tmp2 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class = fncls__225d; tmp2 = fncls__225d } else { tmp2 = fncls__225 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :62:1
func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A{}; t.Ctor_O_O(p0, p1); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A) Ctor_O_O(c__s__1078000033, c__iter__1078000032 any) { t.F_s__1078000033 = c__s__1078000033; t.F_iter__1078000032 = c__iter__1078000032 }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A) Invoke_O__O(self any) any { { var s__1078000033__1 any; var t_ any = t.F_s__1078000033; t.F_s__1078000033 = nil; s__1078000033__1 = t_; for { var temp__1927000414__auto____2 any; var root_168 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = s__1078000033__1; if linked_169 == nil { temp__1927000414__auto____2 = ifn_170.Invoke_O__O(arg_171) } else { temp__1927000414__auto____2 = linked_169.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_168, arg_171) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000033__3 any = temp__1927000414__auto____2; var tmp1 any; var root_172 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = s__1078000033__3; if linked_173 == nil { tmp1 = ifn_174.Invoke_O__O(arg_175) } else { tmp1 = linked_173.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_172, arg_175) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_176 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__1078000033__3; if linked_177 == nil { c__1927001037__auto____4 = ifn_178.Invoke_O__O(arg_179) } else { c__1927001037__auto____4 = linked_177.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_176, arg_179) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000035__6 any; var root_180 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_181 == nil { b__1078000035__6 = ifn_182.Invoke_O__O(arg_183) } else { b__1078000035__6 = linked_181.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_180, arg_183) }; var tmp2 any = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_New_I_O_O(size__1927001038__auto____5, b__1078000035__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class; if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class = fncls__189d; tmp3 = fncls__189d } else { tmp3 = fncls__189 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_190 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_195 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = b__1078000035__6; if linked_196 == nil { arg_193 = ifn_197.Invoke_O__O(arg_198) } else { arg_193 = linked_196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_195, arg_198) }; var arg_194 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000032); var tmp5 any; var root_199 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__1078000033__3; if linked_200 == nil { tmp5 = ifn_201.Invoke_O__O(arg_202) } else { tmp5 = linked_200.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_199, arg_202) }; arg_194 = tmp4.Invoke_O__O(tmp5); if linked_191 == nil { return ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { return linked_191.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) } } else { var root_203 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var root_208 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = b__1078000035__6; if linked_209 == nil { arg_206 = ifn_210.Invoke_O__O(arg_211) } else { arg_206 = linked_209.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_208, arg_211) }; var arg_207 any; if linked_204 == nil { return ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { return linked_204.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } } } else { var vec__1078000043__4 any; var root_212 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = s__1078000033__3; if linked_213 == nil { vec__1078000043__4 = ifn_214.Invoke_O__O(arg_215) } else { vec__1078000043__4 = linked_213.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_212, arg_215) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000043__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_216 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_45, n__5); var arg_220 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1078000032); var tmp7 any; var root_221 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__1078000033__3; if linked_222 == nil { tmp7 = ifn_223.Invoke_O__O(arg_224) } else { tmp7 = linked_222.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_221, arg_224) }; arg_220 = tmp6.Invoke_O__O(tmp7); if linked_217 == nil { return ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { return linked_217.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :62:1
func A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1078000035, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1078000035 = c__b__1078000035; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :62:1
func (t *A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A) Invoke_O__O(self any) any { { var i__1078000034__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000034__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000039__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000034__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_184 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = t.F_b__1078000035; var arg_188 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_45, n__3); if linked_185 == nil { ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { linked_185.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) }; i__1078000034__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000034__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_native_compile_deftype_A_New() *A_arbace_classes_native_compile_deftype_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_classes_native_compile_deftype_A) Ctor() {}
//line :68:1
func (t *A_arbace_classes_native_compile_deftype_A) Invoke_O_O_O__O(self, ns__0, form__1 any) any {




	var root_253 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = lang.IFn_Cast(A_arbace_classes_native_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_51, ns__0); if linked_254 == nil { ifn_255.Invoke_O__O(arg_256) } else { linked_254.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_253, arg_256) }; var tmp1 any = A_arbace_classes_native_compile_deftype_fn__1078000049_A_New_O_O(form__1, ns__0); var tmp2 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class = fncls__252d; tmp2 = fncls__252d } else { tmp2 = fncls__252 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :68:1
	return nil
}



func A_arbace_classes_native_compile_deftype_fn__1078000049_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_deftype_fn__1078000049_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_deftype_fn__1078000049_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000049_A) Ctor_O_O(c__form, c__ns any) { t.F_form = c__form; t.F_ns = c__ns }
//line :73:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_245 any = A_arbace_classes_native_A_const_47.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var t__2 any = t.F_form; t.F_form = nil; arg_248 = t__2; if linked_246 == nil { tmp5 = ifn_247.Invoke_O__O(arg_248) } else { tmp5 = linked_246.(*aot_arbace_classes_lower.A_arbace_classes_lower_deftype_class_form_A).Invoke_O_O__O(root_245, arg_248) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :73:1
	return nil }(); var root_249 any = A_arbace_classes_native_A_const_48.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; if linked_250 == nil { ifn_251.Invoke__O() } else { linked_250.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_249) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }






func A_arbace_classes_native_public_class_QMARK__A_New() *A_arbace_classes_native_public_class_QMARK__A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_public_class_QMARK__A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Invoke_O_O__O(self, c__0 any) any { { var c__2 any = c__0; L1: for {

	if lang.Util_Identical_O_O__Z_NoInit(c__2, nil) { return jrt.Boolean_TRUE.Ref() } else { var tmp1 any; var root_262 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_264 lang.IFn
		if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__2)).GetModifiers__I())).Ref(); if linked_263 == nil { tmp1 = ifn_264.Invoke_O__O(arg_265) } else { tmp1 = linked_263.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_262, arg_265) }
//line :82:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_native_A_const_52 != nil {

			c__2 = jrt.NN(jrt.Class_Cast(c__2)).GetDeclaringClass__Class().Ref(); continue L1 } else {
//line :82:1
				return nil } } } } }; /*line :80:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_type_form_A_New() *A_arbace_classes_native_type_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_type_form_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_classes_native_type_form_A) Ctor() {}
//line :86:1
func (t *A_arbace_classes_native_type_form_A) Invoke_O_O__O(self, c__0 any) any {


	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var c__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(c__2)).IsArray__Z() { c__2, n__3 = jrt.NN(jrt.Class_Cast(c__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J_NoInit(n__3); continue L1 } else { var root_266 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); var arg_270 any; var root_271 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); if linked_272 == nil { arg_270 = ifn_273.Invoke_O__O(arg_274) } else { arg_270 = linked_272.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_271, arg_274) }; if linked_267 == nil { return ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { return linked_267.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_266, arg_269, arg_270) } } } } else {
			var root_275 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); if linked_276 == nil { return ifn_277.Invoke_O__O(arg_278) } else { return linked_276.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_275, arg_278) } }
//line :86:1
	panic("j2g: unreachable")
}






func A_arbace_classes_native_local_class_A_New() *A_arbace_classes_native_local_class_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_classes_native_local_class_A) Ctor() {}
//line :94:1
func (t *A_arbace_classes_native_local_class_A) Invoke_O_O__O(self, lb__0 any) any { var prim__2 any; var tmp1 any = A_arbace_classes_native_local_class_fn__1078000054_A_New_O(lb__0); var tmp2 *jrt.Class; var fncls__279 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000054_A_fn_class; if



	fncls__279 == nil { var fncls__279d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_classes_native_local_class_fn__1078000054_A_fn_class = fncls__279d; tmp2 = fncls__279d } else { tmp2 = fncls__279 }; prim__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var or__1927000174__auto____3 any = prim__2; if
	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var c__4 any; var tmp3 any = A_arbace_classes_native_local_class_fn__1078000056_A_New_O(lb__0); var tmp4 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_classes_native_local_class_fn__1078000056_A_fn_class
		if fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_native_local_class_fn__1078000056_A_fn_class = fncls__280d; tmp4 = fncls__280d } else { tmp4 = fncls__280 }; c__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


		var tmp5 any; var and__1927000168__auto____5 bool = jrt.Class_InstanceOf(c__4); if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_281 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__4)).IsPrimitive__Z()).Ref(); if linked_282 == nil { and__1927000168__auto____6 = ifn_283.Invoke_O__O(arg_284) } else { and__1927000168__auto____6 = linked_282.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_281, arg_284) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_285 any = A_arbace_classes_native_A_const_55.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, A_arbace_classes_native_public_class_QMARK__A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = c__4; if linked_286 == nil { and__1927000168__auto____7 = ifn_287.Invoke_O__O(arg_288) } else { and__1927000168__auto____7 = linked_286.(*A_arbace_classes_native_public_class_QMARK__A).Invoke_O_O__O(root_285, arg_288) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
			var root_289 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any; var root_293 any = A_arbace_classes_native_A_const_56.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref(); var arg_297 any = Lit_32; if linked_294 == nil { arg_292 = ifn_295.Invoke_O_O__O(arg_296, arg_297) } else { arg_292 = linked_294.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_293, arg_296, arg_297) }; if linked_290 == nil { tmp5 = ifn_291.Invoke_O__O(arg_292) } else { tmp5 = linked_290.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_289, arg_292) } } else {
//line :103:1
				tmp5 = and__1927000168__auto____7 } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp5) { return c__4 } else { return A_arbace_classes_native_A_const_57 } } }
//line :98:1
func A_arbace_classes_native_local_class_fn__1078000054_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000054_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000054_A{}; t.Ctor_O(p0); return t }
//line :98:1
func (t *A_arbace_classes_native_local_class_fn__1078000054_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :98:1
func (t *A_arbace_classes_native_local_class_fn__1078000054_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetPrimitiveType__Class().Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_classes_native_local_class_fn__1078000056_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000056_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000056_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_classes_native_local_class_fn__1078000056_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :100:1
func (t *A_arbace_classes_native_local_class_fn__1078000056_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); if jrt.NN(lang.Compiler_LocalBinding_Cast(t.F_lb)).HasJavaClass__Z() {
												var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetJavaClass__Class().Ref() } else {
//line :100:1
		tmp1 = nil }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_classes_native_field_names_A_New() *A_arbace_classes_native_field_names_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_field_names_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_classes_native_field_names_A) Ctor() {}
//line :108:1
func (t *A_arbace_classes_native_field_names_A) Invoke_O_O__O(self, syms__0 any) any { { var G__1078000062__2_ any = syms__0; var vec__1078000063__3 any = G__1078000062__2_; var seq__1078000064__4 any; var root_298 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_300 lang.IFn


	if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = vec__1078000063__3; if linked_299 == nil { seq__1078000064__4 = ifn_300.Invoke_O__O(arg_301) } else { seq__1078000064__4 = linked_299.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_298, arg_301) }
//line :108:1
	var first__1078000065__5 any; var root_302 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_304 lang.IFn


	if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = seq__1078000064__4; if linked_303 == nil { first__1078000065__5 = ifn_304.Invoke_O__O(arg_305) } else { first__1078000065__5 = linked_303.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_302, arg_305) }
//line :108:1
	var seq__1078000064__6 any; var root_306 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_308 lang.IFn


	if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = seq__1078000064__4; if linked_307 == nil { seq__1078000064__6 = ifn_308.Invoke_O__O(arg_309) } else { seq__1078000064__6 = linked_307.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_306, arg_309) }
//line :108:1
	var s__7 any = first__1078000065__5; var more__8 any = seq__1078000064__6; var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); var out__10 any = lang.PersistentVector_EMPTY.Ref(); var G__1078000062__11_ any = G__1078000062__2_; var seen__12 any = seen__9; var out__13 any = out__10; _ = s__7; _ = more__8; L1: for { var vec__1078000066__14 any = G__1078000062__11_; var seq__1078000067__15 any; var root_310 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_312 lang.IFn


		if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = vec__1078000066__14; if linked_311 == nil { seq__1078000067__15 = ifn_312.Invoke_O__O(arg_313) } else { seq__1078000067__15 = linked_311.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_310, arg_313) }
//line :108:1
		var first__1078000068__16 any; var root_314 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_316 lang.IFn


		if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = seq__1078000067__15; if linked_315 == nil { first__1078000068__16 = ifn_316.Invoke_O__O(arg_317) } else { first__1078000068__16 = linked_315.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_314, arg_317) }
//line :108:1
		var seq__1078000067__17 any; var root_318 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_320 lang.IFn


		if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = seq__1078000067__15; if linked_319 == nil { seq__1078000067__17 = ifn_320.Invoke_O__O(arg_321) } else { seq__1078000067__17 = linked_319.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_318, arg_321) }
//line :108:1
		var s__18 any = first__1078000068__16; var more__19 any = seq__1078000067__17; var seen__20 any = seen__12; var out__21 any = out__13; var tmp1 any; var root_322 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_324 lang.IFn



		if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = s__18; if linked_323 == nil { tmp1 = ifn_324.Invoke_O__O(arg_325) } else { tmp1 = linked_323.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_322, arg_325) }; if jrt.J2g_Truth(tmp1) { return out__21 } else { var base__22 any; var root_326 any = A_arbace_classes_native_A_const_58.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_munge_A_fn_class); var ifn_328 lang.IFn

			if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any; var root_330 any = A_arbace_classes_native_A_const_59.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = s__18; if linked_331 == nil { arg_329 = ifn_332.Invoke_O__O(arg_333) } else { arg_329 = linked_331.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_330, arg_333) }; if linked_327 == nil { base__22 = ifn_328.Invoke_O__O(arg_329) } else { base__22 = linked_327.(*aot_arbace_core.A_arbace_core_munge_A).Invoke_O_O__O(root_326, arg_329) }
//line :112:1
			var n__23 any


			if jrt.J2g_Truth(lang.IFn_Cast(seen__20).Invoke_O__O(base__22)) { n__23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, base__22, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(out__21)).Ref())).Ref() } else { n__23 = base__22 }
			var tmp2 any; var root_334 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = seen__20; var arg_338 any = n__23; if linked_335 == nil { tmp2 = ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { tmp2 = linked_335.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) }; var tmp3 any = tmp2; var tmp4 any; var root_339 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = out__21; var arg_343 any = n__23; if linked_340 == nil { tmp4 = ifn_341.Invoke_O_O__O(arg_342, arg_343) } else { tmp4 = linked_340.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_339, arg_342, arg_343) }; G__1078000062__11_, seen__12, out__13 = more__19, tmp3, tmp4; continue L1 } } }; /*line :108:1*/panic("j2g: unreachable") }









func A_arbace_classes_native_fn_class_form_A_New() *A_arbace_classes_native_fn_class_form_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_native_fn_class_form_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_native_fn_class_form_A) Invoke_O_O_O_O__O(self, cname__0, form__1, captured__2 any) any { var map__1078000070__4 any; var root_344 any = A_arbace_classes_native_A_const_60.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A_fn_class); var ifn_346 lang.IFn; if



	linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = form__1; if linked_345 == nil { map__1078000070__4 = ifn_346.Invoke_O__O(arg_347) } else { map__1078000070__4 = linked_345.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_parts_A).Invoke_O_O__O(root_344, arg_347) }; var map__1078000070__5 any; if lang.ISeq_InstanceOf(map__1078000070__4) { var tmp1 any; var root_348 any = A_arbace_classes_native_A_const_12.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = map__1078000070__4; if linked_349 == nil { tmp1 = ifn_350.Invoke_O__O(arg_351) } else { tmp1 = linked_349.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_348, arg_351) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_352 any = A_arbace_classes_native_A_const_13.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = map__1078000070__4; if linked_353 == nil { tmp2 = ifn_354.Invoke_O__O(arg_355) } else { tmp2 = linked_353.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_352, arg_355) }; map__1078000070__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_356 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = map__1078000070__4; if linked_357 == nil { tmp3 = ifn_358.Invoke_O__O(arg_359) } else { tmp3 = linked_357.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(tmp3) { var root_360 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = map__1078000070__4; if linked_361 == nil { map__1078000070__5 = ifn_362.Invoke_O__O(arg_363) } else { map__1078000070__5 = linked_361.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_360, arg_363) } } else { map__1078000070__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000070__5 = map__1078000070__4 }; var nm__6 any = /*line :118:1*/lang.RT_Get_O_O__O_NoInit(map__1078000070__5, A_arbace_classes_native_A_const_61); var arities__7 any = lang.RT_Get_O_O__O_NoInit(map__1078000070__5, A_arbace_classes_native_A_const_62); var i__8 int32 = jrt.NN(jrt.String_Cast(cname__0)).LastIndexOf_String__I(Lit_17); var pkg__9 any; if





	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__8)) { pkg__9 = Lit_18 } else { var root_364 any = A_arbace_classes_native_A_const_63.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = cname__0; var arg_368 any = A_arbace_classes_native_A_const_64; var arg_369 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__8).Ref(); if linked_365 == nil { pkg__9 = ifn_366.Invoke_O_O_O__O(arg_367, arg_368, arg_369) } else { pkg__9 = linked_365.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_364, arg_367, arg_368, arg_369) } }; var simple__10 any; var root_370 any = /*line :118:1*/A_arbace_classes_native_A_const_63.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_372 lang.IFn; if






	linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = cname__0; var arg_374 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(i__8))).Ref(); if linked_371 == nil { simple__10 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { simple__10 = linked_371.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; var rcv__11 any; var root_375 any = /*line :118:1*/A_arbace_classes_native_A_const_65.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_377 lang.IFn; if







	linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = Lit_19; if linked_376 == nil { rcv__11 = ifn_377.Invoke_O__O(arg_378) } else { rcv__11 = linked_376.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_375, arg_378) }; var fields__12 any; var root_379 any = /*line :118:1*/A_arbace_classes_native_A_const_66.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, A_arbace_classes_native_field_names_A_fn_class); var ifn_381 lang.IFn; if








	linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any; var root_383 any = A_arbace_classes_native_A_const_67.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var arg_387 any = captured__2; if linked_384 == nil { arg_382 = ifn_385.Invoke_O_O__O(arg_386, arg_387) } else { arg_382 = linked_384.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_383, arg_386, arg_387) }; if linked_380 == nil { fields__12 = ifn_381.Invoke_O__O(arg_382) } else { fields__12 = linked_380.(*A_arbace_classes_native_field_names_A).Invoke_O_O__O(root_379, arg_382) }; var super__13 any; var tmp4 any; var root_388 any = /*line :118:1*/A_arbace_classes_native_A_const_68.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_390 lang.IFn; if









	linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = A_arbace_classes_native_A_const_69.GetRawRoot__O(); var arg_392 any = arities__7; if linked_389 == nil { tmp4 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { tmp4 = linked_389.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }; if jrt.J2g_Truth(tmp4) { super__13 = A_arbace_classes_native_A_const_70 } else { super__13 = A_arbace_classes_native_A_const_71 }; var typed__14 any; var tmp5 any = /*line :118:1*/A_arbace_classes_native_fn_class_form_typed__1078000072_A_New(); var tmp6 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class; if










	fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class = fncls__402d; tmp6 = fncls__402d } else { tmp6 = fncls__402 }; typed__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_classes_native_A_const_42.GetRawRoot__O()); var tmp8 any; var root_410 any = A_arbace_classes_native_A_const_72.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_412 lang.IFn; if
	linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var root_415 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = simple__10; if linked_416 == nil { arg_413 = ifn_417.Invoke_O__O(arg_418) } else { arg_413 = linked_416.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_415, arg_418) }; var arg_414 any = A_arbace_classes_native_A_const_75; if linked_411 == nil { tmp8 = ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { tmp8 = linked_411.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) }; var tmp9 any = tmp8; var tmp10 any = A_arbace_classes_native_A_const_76; var tmp11 any = A_arbace_classes_native_A_const_77; var tmp12 any = A_arbace_classes_native_A_const_78; var tmp13 any; var root_419 any = /*line :130:1*/A_arbace_classes_native_A_const_79.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A_fn_class); var ifn_421 lang.IFn; if



	linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = arities__7; if linked_420 == nil { tmp13 = ifn_421.Invoke_O__O(arg_422) } else { tmp13 = linked_420.(*aot_arbace_classes_lower.A_arbace_classes_lower_prim_interfaces_A).Invoke_O_O__O(root_419, arg_422) }; var tmp14 any = /*line :130:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, pkg__9, tmp11, super__13, tmp12, tmp13)); var tmp15 any; var iter__1927001039__auto____15 any; var tmp16 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_New_O(typed__14); var tmp17 *jrt.Class; var fncls__503 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class; if




	fncls__503 == nil { var fncls__503d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class = fncls__503d; tmp17 = fncls__503d } else { tmp17 = fncls__503 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var tmp18 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp19 any; var root_504 any = A_arbace_classes_native_A_const_67.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = A_arbace_classes_native_A_const_84.GetRawRoot__O(); var arg_508 any = fields__12; var arg_509 any = captured__2; if linked_505 == nil { tmp19 = ifn_506.Invoke_O_O_O__O(arg_507, arg_508, arg_509) } else { tmp19 = linked_505.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_504, arg_507, arg_508, arg_509) }; tmp15 = tmp18.Invoke_O__O(tmp19); var tmp20 any = tmp15; var tmp21 any; var root_510 any = /*line :130:1*/A_arbace_classes_native_A_const_85.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_512 lang.IFn; if






	linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = A_arbace_classes_native_A_const_86; var arg_514 any; var root_517 any = A_arbace_classes_native_A_const_72.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var root_522 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any; var root_526 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = rcv__11; var arg_530 any; var root_531 any = A_arbace_classes_native_A_const_67.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any; var tmp22 any = A_arbace_classes_native_fn_class_form_fn__1078000097_A_New_O(typed__14); var tmp23 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class = fncls__541d; tmp23 = fncls__541d } else { tmp23 = fncls__541 }; arg_534 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_535 any = fields__12; var arg_536 any = captured__2; if linked_532 == nil { arg_530 = ifn_533.Invoke_O_O_O__O(arg_534, arg_535, arg_536) } else { arg_530 = linked_532.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_531, arg_534, arg_535, arg_536) }; if linked_527 == nil { arg_525 = ifn_528.Invoke_O_O__O(arg_529, arg_530) } else { arg_525 = linked_527.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_526, arg_529, arg_530) }; if linked_523 == nil { arg_520 = ifn_524.Invoke_O__O(arg_525) } else { arg_520 = linked_523.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_522, arg_525) }; var arg_521 any = A_arbace_classes_native_A_const_87; if linked_518 == nil { arg_514 = ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { arg_514 = linked_518.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_517, arg_520, arg_521) }; var arg_515 any = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_native_A_const_88); var arg_516 any; var iter__1927001039__auto____15_2 any; var tmp24 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_New_O(rcv__11); var tmp25 *jrt.Class; var fncls__616 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class; if


	fncls__616 == nil { var fncls__616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class = fncls__616d; tmp25 = fncls__616d } else { tmp25 = fncls__616 }; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); arg_516 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(fields__12); if /*line :137:1*/ linked_511 == nil { tmp21 = ifn_512.Invoke_O_O_O_O__O(arg_513, arg_514, arg_515, arg_516) } else { tmp21 = linked_511.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_510, arg_513, arg_514, arg_515, arg_516) }; var tmp26 any = /*line :130:1*/lang.Tuple_Create_O__IPersistentVector(tmp21); var tmp27 any; var root_617 any = A_arbace_classes_native_A_const_90.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A_fn_class); var ifn_619 lang.IFn; if










	linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = rcv__11; var arg_621 any = nm__6; var arg_622 any = arities__7; var arg_623 any; var root_624 any = A_arbace_classes_native_A_const_37.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_626 lang.IFn; if
	linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_91.GetRawRoot__O()); var tmp29 any = A_arbace_classes_native_fn_class_form_fn__1078000113_A_New_O(rcv__11); var tmp30 *jrt.Class; var fncls__638 *jrt.Class = A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class; if fncls__638 == nil { var fncls__638d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class = fncls__638d; tmp30 = fncls__638d } else { tmp30 = fncls__638 }; arg_627 = tmp28.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), fields__12, captured__2); if linked_625 == nil { arg_623 = ifn_626.Invoke_O__O(arg_627) } else { arg_623 = linked_625.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_624, arg_627) }; if /*line :141:1*/ linked_618 == nil { tmp27 = ifn_619.Invoke_O_O_O_O__O(arg_620, arg_621, arg_622, arg_623) } else { tmp27 = linked_618.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_methods_A).Invoke_O_O_O_O_O__O(root_617, arg_620, arg_621, arg_622, arg_623) }; return /*line :130:1*/ tmp7.Invoke_O_O_O_O__O(tmp14, tmp20, tmp26, tmp27) }
//line :129:1
func A_arbace_classes_native_fn_class_form_typed__1078000072_A_New() *A_arbace_classes_native_fn_class_form_typed__1078000072_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_typed__1078000072_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000072_A) Ctor() {}
//line :129:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000072_A) Invoke_O_O_O__O(self, s__1, c__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__2, A_arbace_classes_native_A_const_57) { return s__1 } else { var root_393 any = A_arbace_classes_native_A_const_72.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = s__1; var arg_397 any; var tmp1 any = A_arbace_classes_native_A_const_73; var tmp2 any; var root_398 any = A_arbace_classes_native_A_const_74.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_classes_native_type_form_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = c__2; if linked_399 == nil { tmp2 = ifn_400.Invoke_O__O(arg_401) } else { tmp2 = linked_399.(*A_arbace_classes_native_type_form_A).Invoke_O_O__O(root_398, arg_401) }; arg_397 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2)); if linked_394 == nil { return ifn_395.Invoke_O_O__O(arg_396, arg_397) } else { return linked_394.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_393, arg_396, arg_397) } } }





func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A) Invoke_O_O__O(self, s__1078000075__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_New_O_O_O(s__1078000075__1, self, t.F_typed); var tmp2 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class = fncls__502d; tmp2 = fncls__502d } else { tmp2 = fncls__502 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :135:1
func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A) Ctor_O_O_O(c__s__1078000075, c__iter__1078000074, c__typed any) { t.F_s__1078000075 = c__s__1078000075; t.F_iter__1078000074 = c__iter__1078000074; t.F_typed = c__typed }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A) Invoke_O__O(self any) any { { var s__1078000075__1 any; var t_ any = t.F_s__1078000075; t.F_s__1078000075 = nil; s__1078000075__1 = t_; for { var temp__1927000414__auto____2 any; var root_423 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = s__1078000075__1; if linked_424 == nil { temp__1927000414__auto____2 = ifn_425.Invoke_O__O(arg_426) } else { temp__1927000414__auto____2 = linked_424.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_423, arg_426) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000075__3 any = temp__1927000414__auto____2; var tmp1 any; var root_427 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = s__1078000075__3; if linked_428 == nil { tmp1 = ifn_429.Invoke_O__O(arg_430) } else { tmp1 = linked_428.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_427, arg_430) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_431 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = s__1078000075__3; if linked_432 == nil { c__1927001037__auto____4 = ifn_433.Invoke_O__O(arg_434) } else { c__1927001037__auto____4 = linked_432.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_431, arg_434) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000077__6 any; var root_435 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_436 == nil { b__1078000077__6 = ifn_437.Invoke_O__O(arg_438) } else { b__1078000077__6 = linked_436.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_435, arg_438) }; var tmp2 any = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_New_O_O_I_O(b__1078000077__6, t.F_typed, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__455 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class; if fncls__455 == nil { var fncls__455d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class = fncls__455d; tmp3 = fncls__455d } else { tmp3 = fncls__455 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_456 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var root_461 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = b__1078000077__6; if linked_462 == nil { arg_459 = ifn_463.Invoke_O__O(arg_464) } else { arg_459 = linked_462.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_461, arg_464) }; var arg_460 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000074); var tmp5 any; var root_465 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = s__1078000075__3; if linked_466 == nil { tmp5 = ifn_467.Invoke_O__O(arg_468) } else { tmp5 = linked_466.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_465, arg_468) }; arg_460 = tmp4.Invoke_O__O(tmp5); if linked_457 == nil { return ifn_458.Invoke_O_O__O(arg_459, arg_460) } else { return linked_457.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_456, arg_459, arg_460) } } else { var root_469 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var root_474 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = b__1078000077__6; if linked_475 == nil { arg_472 = ifn_476.Invoke_O__O(arg_477) } else { arg_472 = linked_475.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_474, arg_477) }; var arg_473 any; if linked_470 == nil { return ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { return linked_470.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) } } } else { var vec__1078000088__4 any; var root_478 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = s__1078000075__3; if linked_479 == nil { vec__1078000088__4 = ifn_480.Invoke_O__O(arg_481) } else { vec__1078000088__4 = linked_479.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_478, arg_481) }; var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000088__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000091__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000088__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000091__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000091__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_482 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_484 lang.IFn; _ = ___7; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_80; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_81.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp10 any; var root_494 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_496 lang.IFn
															if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = f__5; if linked_495 == nil { tmp10 = ifn_496.Invoke_O__O(arg_497) } else { tmp10 = linked_495.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_494, arg_497) }; arg_485 = tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O_O__O(tmp9.Invoke_O_O__O(tmp10, c__8), A_arbace_classes_native_A_const_82.GetRawRoot__O(), A_arbace_classes_native_A_const_83, jrt.Boolean_TRUE.Ref()))
//line :135:1
	var arg_486 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000074); var tmp12 any; var root_498 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__1078000075__3; if linked_499 == nil { tmp12 = ifn_500.Invoke_O__O(arg_501) } else { tmp12 = linked_499.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_498, arg_501) }; arg_486 = tmp11.Invoke_O__O(tmp12); if linked_483 == nil { return ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { return linked_483.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :135:1
func A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A) Ctor_O_O_I_O(c__b__1078000077, c__typed any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000077 = c__b__1078000077; t.F_typed = c__typed; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :135:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A) Invoke_O__O(self any) any { { var i__1078000076__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000076__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000081__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000076__1)); var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000081__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1078000084__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000081__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000084__4, lang.RT_IntCast_J__I_NoInit(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000084__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_439 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_441 lang.IFn; _ = ___5; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = t.F_b__1078000077; var arg_443 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_80; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_81.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp6 any; var root_451 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_453 lang.IFn
																	if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = f__3; if linked_452 == nil { tmp6 = ifn_453.Invoke_O__O(arg_454) } else { tmp6 = linked_452.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_451, arg_454) }; arg_443 = tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5.Invoke_O_O__O(tmp6, c__6), A_arbace_classes_native_A_const_82.GetRawRoot__O(), A_arbace_classes_native_A_const_83, jrt.Boolean_TRUE.Ref()))
//line :135:1
	if linked_440 == nil { ifn_441.Invoke_O_O__O(arg_442, arg_443) } else { linked_440.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_439, arg_442, arg_443) }; i__1078000076__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000076__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000097_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000097_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000097_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000097_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :137:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000097_A) Invoke_O_O_O__O(self, f__1, p__1078000096__2 any) any { var vec__1078000098__3 any = p__1078000096__2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000098__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000098__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp2 any; var root_537 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_539 lang.IFn; _ = ___4; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = f__1; if linked_538 == nil { tmp2 = ifn_539.Invoke_O__O(arg_540) } else { tmp2 = linked_538.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_537, arg_540) }; return tmp1.Invoke_O_O__O(tmp2, c__5) }


func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A{}; t.Ctor_O(p0); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A) Invoke_O_O__O(self, s__1078000103__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_New_O_O_O(s__1078000103__1, t.F_rcv, self); var tmp2 *jrt.Class; var fncls__615 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class; if fncls__615 == nil { var fncls__615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class = fncls__615d; tmp2 = fncls__615d } else { tmp2 = fncls__615 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :140:1
func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A) Ctor_O_O_O(c__s__1078000103, c__rcv, c__iter__1078000102 any) { t.F_s__1078000103 = c__s__1078000103; t.F_rcv = c__rcv; t.F_iter__1078000102 = c__iter__1078000102 }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A) Invoke_O__O(self any) any { { var s__1078000103__1 any; var t_ any = t.F_s__1078000103; t.F_s__1078000103 = nil; s__1078000103__1 = t_; for { var temp__1927000414__auto____2 any; var root_542 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = s__1078000103__1; if linked_543 == nil { temp__1927000414__auto____2 = ifn_544.Invoke_O__O(arg_545) } else { temp__1927000414__auto____2 = linked_543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_542, arg_545) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000103__3 any = temp__1927000414__auto____2; var tmp1 any; var root_546 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = s__1078000103__3; if linked_547 == nil { tmp1 = ifn_548.Invoke_O__O(arg_549) } else { tmp1 = linked_547.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_546, arg_549) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_550 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = s__1078000103__3; if linked_551 == nil { c__1927001037__auto____4 = ifn_552.Invoke_O__O(arg_553) } else { c__1927001037__auto____4 = linked_551.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_550, arg_553) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000105__6 any; var root_554 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_555 == nil { b__1078000105__6 = ifn_556.Invoke_O__O(arg_557) } else { b__1078000105__6 = linked_555.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_554, arg_557) }; var tmp2 any = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_O_I_O(b__1078000105__6, t.F_rcv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__571 *jrt.Class = A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class; if fncls__571 == nil { var fncls__571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class = fncls__571d; tmp3 = fncls__571d } else { tmp3 = fncls__571 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_572 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var root_577 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = b__1078000105__6; if linked_578 == nil { arg_575 = ifn_579.Invoke_O__O(arg_580) } else { arg_575 = linked_578.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_577, arg_580) }; var arg_576 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); var tmp5 any; var root_581 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = s__1078000103__3; if linked_582 == nil { tmp5 = ifn_583.Invoke_O__O(arg_584) } else { tmp5 = linked_582.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_581, arg_584) }; arg_576 = tmp4.Invoke_O__O(tmp5); if linked_573 == nil { return ifn_574.Invoke_O_O__O(arg_575, arg_576) } else { return linked_573.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_572, arg_575, arg_576) } } else { var root_585 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any; var root_590 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = b__1078000105__6; if linked_591 == nil { arg_588 = ifn_592.Invoke_O__O(arg_593) } else { arg_588 = linked_591.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_590, arg_593) }; var arg_589 any; if linked_586 == nil { return ifn_587.Invoke_O_O__O(arg_588, arg_589) } else { return linked_586.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_585, arg_588, arg_589) } } } else { var f__4 any; var root_594 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = s__1078000103__3; if linked_595 == nil { f__4 = ifn_596.Invoke_O__O(arg_597) } else { f__4 = linked_595.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_594, arg_597) }; var root_598 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp7 any = A_arbace_classes_native_A_const_89; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp9 any; var root_607 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref(); if linked_608 == nil { tmp9 = ifn_609.Invoke_O__O(arg_610) } else { tmp9 = linked_608.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_607, arg_610) }; var tmp10 any = tmp8.Invoke_O_O__O(tmp9, t.F_rcv); var tmp11 any; var root_603 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = f__4; if linked_604 == nil { tmp11 = ifn_605.Invoke_O__O(arg_606) } else { tmp11 = linked_604.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_603, arg_606) }; arg_601 = tmp6.Invoke_O_O_O__O(tmp7, tmp10, tmp11); var arg_602 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); var tmp13 any; var root_611 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = s__1078000103__3; if linked_612 == nil { tmp13 = ifn_613.Invoke_O__O(arg_614) } else { tmp13 = linked_612.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_611, arg_614) }; arg_602 = tmp12.Invoke_O__O(tmp13); if linked_599 == nil { return ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { return linked_599.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_598, arg_601, arg_602) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :140:1
func A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Ctor_O_O_I_O(c__b__1078000105, c__rcv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000105 = c__b__1078000105; t.F_rcv = c__rcv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Invoke_O__O(self any) any { { var i__1078000104__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000104__1)); var root_558 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = t.F_b__1078000105; var arg_562 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp3 any = A_arbace_classes_native_A_const_89; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp5 any; var root_567 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref(); if linked_568 == nil { tmp5 = ifn_569.Invoke_O__O(arg_570) } else { tmp5 = linked_568.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_567, arg_570) }; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, t.F_rcv); var tmp7 any; var root_563 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = f__2; if linked_564 == nil { tmp7 = ifn_565.Invoke_O__O(arg_566) } else { tmp7 = linked_564.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_563, arg_566) }; arg_562 = tmp2.Invoke_O_O_O__O(tmp3, tmp6, tmp7); if linked_559 == nil { ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { linked_559.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }; i__1078000104__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000104__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000113_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000113_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000113_A{}; t.Ctor_O(p0); return t }
//line :142:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000113_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :142:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000113_A) Invoke_O_O_O__O(self, f__1, p__1078000112__2 any) any { var vec__1078000114__3 any = p__1078000112__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000114__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000114__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()); var tmp2 any; var root_634 any = A_arbace_classes_native_A_const_53.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_636 lang.IFn; _ = ___5; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref(); if linked_635 == nil { tmp2 = ifn_636.Invoke_O__O(arg_637) } else { tmp2 = linked_635.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_634, arg_637) }; return lang.Tuple_Create_O_O__IPersistentVector(s__4, tmp1.Invoke_O_O__O(tmp2, t.F_rcv)) }

func A_arbace_classes_native_compile_fn_A_New() *A_arbace_classes_native_compile_fn_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_classes_native_compile_fn_A) Ctor() {}
//line :144:1
func (t *A_arbace_classes_native_compile_fn_A) Invoke_O_O_O_O_O__O(self, ns__0, cname__1, form__2, env__3 any) any { { var host__5 any; var root_639 any = A_arbace_classes_native_A_const_23.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_641 lang.IFn





	if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_643 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_New(); var tmp2 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class; if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class = fncls__710d; tmp2 = fncls__710d } else { tmp2 = fncls__710 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_643 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(env__3); if linked_640 == nil { host__5 = ifn_641.Invoke_O_O__O(arg_642, arg_643) } else { host__5 = linked_640.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_639, arg_642, arg_643) }
//line :144:1
	var mentioned__6 any; var root_711 any = A_arbace_classes_native_A_const_93.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A_fn_class); var ifn_713 lang.IFn






	if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = form__2; if linked_712 == nil { mentioned__6 = ifn_713.Invoke_O__O(arg_714) } else { mentioned__6 = linked_712.(*aot_arbace_classes_lower.A_arbace_classes_lower_symbols_in_A).Invoke_O_O__O(root_711, arg_714) }
//line :144:1
	var syms__7 any; var root_715 any = A_arbace_classes_native_A_const_94.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_717 lang.IFn







	if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any; var tmp3 any = A_arbace_classes_native_compile_fn_fn__1078000138_A_New_O(host__5); var tmp4 *jrt.Class; var fncls__725 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class; if fncls__725 == nil { var fncls__725d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class = fncls__725d; tmp4 = fncls__725d } else { tmp4 = fncls__725 }; arg_718 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_719 any; var root_726 any = A_arbace_classes_native_A_const_96.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = A_arbace_classes_native_A_const_54.GetRawRoot__O(); var arg_730 any = mentioned__6; if linked_727 == nil { arg_719 = ifn_728.Invoke_O_O__O(arg_729, arg_730) } else { arg_719 = linked_727.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_726, arg_729, arg_730) }; if linked_716 == nil { syms__7 = ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { syms__7 = linked_716.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_715, arg_718, arg_719) }
//line :144:1
L1: for { var captured__8 any; var root_731 any = A_arbace_classes_native_A_const_39.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_733 lang.IFn








	if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any; var tmp5 any = A_arbace_classes_native_compile_fn_fn__1078000140_A_New_O(host__5); var tmp6 *jrt.Class; var fncls__736 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class; if fncls__736 == nil { var fncls__736d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class = fncls__736d; tmp6 = fncls__736d } else { tmp6 = fncls__736 }; arg_734 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_735 any = syms__7; if linked_732 == nil { captured__8 = ifn_733.Invoke_O_O__O(arg_734, arg_735) } else { captured__8 = linked_732.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_731, arg_734, arg_735) }
//line :144:1
	var r__9 any; var tmp7 any = A_arbace_classes_native_compile_fn_fn__1078000142_A_New_O_O_O_O_O_O(form__2, host__5, ns__0, syms__7, cname__1, captured__8); var tmp8 *jrt.Class
	var fncls__795 /*line :144:1*/*jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class









	if fncls__795 == nil { var fncls__795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class = fncls__795d; tmp8 = fncls__795d } else { tmp8 = fncls__795 }; r__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()









	var tmp9 any = A_arbace_classes_native_A_const_103; var tmp10 any; var root_796 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = r__9; if linked_797 == nil { tmp10 = ifn_798.Invoke_O__O(arg_799) } else { tmp10 = linked_797.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_796, arg_799) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10) {
		var tmp11 any; var root_818 any = A_arbace_classes_native_A_const_10.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = syms__7; var arg_822 any; var root_823 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = r__9; if linked_824 == nil { arg_822 = ifn_825.Invoke_O__O(arg_826) } else { arg_822 = linked_824.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_823, arg_826) }; if linked_819 == nil { tmp11 = ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { tmp11 = linked_819.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) }; syms__7 = tmp11; continue L1 } else {
//line :164:1
			var new__10 any; var root_800 any = A_arbace_classes_native_A_const_85.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_802 lang.IFn


			if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = A_arbace_classes_native_A_const_104; var arg_804 any; var root_806 any = A_arbace_classes_native_A_const_46.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any; var root_810 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = r__9; if linked_811 == nil { arg_809 = ifn_812.Invoke_O__O(arg_813) } else { arg_809 = linked_811.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_810, arg_813) }; if linked_807 == nil { arg_804 = ifn_808.Invoke_O__O(arg_809) } else { arg_804 = linked_807.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_806, arg_809) }; var arg_805 any = syms__7; if linked_801 == nil { new__10 = ifn_802.Invoke_O_O_O__O(arg_803, arg_804, arg_805) } else { new__10 = linked_801.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_800, arg_803, arg_804, arg_805) }
//line :164:1
			var temp__1927000408__auto____11 any; var root_814 any = A_arbace_classes_native_A_const_105.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A_fn_class); var ifn_816 lang.IFn



			if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = form__2; if linked_815 == nil { temp__1927000408__auto____11 = ifn_816.Invoke_O__O(arg_817) } else { temp__1927000408__auto____11 = linked_815.(*aot_arbace_classes_lower.A_arbace_classes_lower_fn_meta_A).Invoke_O_O__O(root_814, arg_817) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11
				return lang.IFn_Cast(A_arbace_classes_native_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_classes_native_A_const_106, new__10, m__12) } else {
//line :168:1
					return new__10 } } } }; /*line :144:1*/panic("j2g: unreachable") }





func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_New() *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A) Ctor() {}
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A) Invoke_O_O__O(self, s__1078000123__1 any) any { var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_New_O_O(s__1078000123__1, self); var tmp2 *jrt.Class; var fncls__709 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class; if fncls__709 == nil { var fncls__709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class = fncls__709d; tmp2 = fncls__709d } else { tmp2 = fncls__709 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A) Ctor_O_O(c__s__1078000123, c__iter__1078000122 any) { t.F_s__1078000123 = c__s__1078000123; t.F_iter__1078000122 = c__iter__1078000122 }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A) Invoke_O__O(self any) any { { var s__1078000123__1 any; var t_ any = t.F_s__1078000123; t.F_s__1078000123 = nil; s__1078000123__1 = t_; for { var temp__1927000414__auto____2 any; var root_644 any = A_arbace_classes_native_A_const_14.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = s__1078000123__1; if linked_645 == nil { temp__1927000414__auto____2 = ifn_646.Invoke_O__O(arg_647) } else { temp__1927000414__auto____2 = linked_645.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_644, arg_647) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1078000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_648 any = A_arbace_classes_native_A_const_25.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = s__1078000123__3; if linked_649 == nil { tmp1 = ifn_650.Invoke_O__O(arg_651) } else { tmp1 = linked_649.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_652 any = A_arbace_classes_native_A_const_26.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = s__1078000123__3; if linked_653 == nil { c__1927001037__auto____4 = ifn_654.Invoke_O__O(arg_655) } else { c__1927001037__auto____4 = linked_653.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_652, arg_655) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1078000125__6 any; var root_656 any = A_arbace_classes_native_A_const_27.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_657 == nil { b__1078000125__6 = ifn_658.Invoke_O__O(arg_659) } else { b__1078000125__6 = linked_657.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_656, arg_659) }; var tmp2 any = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_New_O_I_O(b__1078000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__669 *jrt.Class = A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class; if fncls__669 == nil { var fncls__669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class = fncls__669d; tmp3 = fncls__669d } else { tmp3 = fncls__669 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_670 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var root_675 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = b__1078000125__6; if linked_676 == nil { arg_673 = ifn_677.Invoke_O__O(arg_678) } else { arg_673 = linked_676.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_675, arg_678) }; var arg_674 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1078000122); var tmp5 any; var root_679 any = A_arbace_classes_native_A_const_32.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__1078000123__3; if linked_680 == nil { tmp5 = ifn_681.Invoke_O__O(arg_682) } else { tmp5 = linked_680.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_679, arg_682) }; arg_674 = tmp4.Invoke_O__O(tmp5); if linked_671 == nil { return ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { return linked_671.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_670, arg_673, arg_674) } } else { var root_683 any = A_arbace_classes_native_A_const_30.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var root_688 any = A_arbace_classes_native_A_const_31.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = b__1078000125__6; if linked_689 == nil { arg_686 = ifn_690.Invoke_O__O(arg_691) } else { arg_686 = linked_689.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_688, arg_691) }; var arg_687 any; if linked_684 == nil { return ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { return linked_684.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) } } } else { var vec__1078000133__4 any; var root_692 any = A_arbace_classes_native_A_const_15.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = s__1078000123__3; if linked_693 == nil { vec__1078000133__4 = ifn_694.Invoke_O__O(arg_695) } else { vec__1078000133__4 = linked_693.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_692, arg_695) }; var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000133__4, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000133__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_696 any = A_arbace_classes_native_A_const_33.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var tmp6 any; var root_701 any = A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, A_arbace_classes_native_local_class_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = lb__6; if linked_702 == nil { tmp6 = ifn_703.Invoke_O__O(arg_704) } else { tmp6 = linked_702.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_701, arg_704) }; arg_699 = lang.Tuple_Create_O_O__IPersistentVector(s__5, tmp6); var arg_700 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1078000122); var tmp8 any; var root_705 any = A_arbace_classes_native_A_const_34.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = s__1078000123__3; if linked_706 == nil { tmp8 = ifn_707.Invoke_O__O(arg_708) } else { tmp8 = linked_706.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_705, arg_708) }; arg_700 = tmp7.Invoke_O__O(tmp8); if linked_697 == nil { return ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { return linked_697.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A) Ctor_O_I_O(c__b__1078000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000125 = c__b__1078000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A) Invoke_O__O(self any) any { { var i__1078000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1078000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000129__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1078000124__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000129__2, lang.RT_IntCast_J__I_NoInit(0), nil); var lb__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1078000129__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_660 any = A_arbace_classes_native_A_const_29.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = t.F_b__1078000125; var arg_664 any; var tmp2 any; var root_665 any = A_arbace_classes_native_A_const_92.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, A_arbace_classes_native_local_class_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = lb__4; if linked_666 == nil { tmp2 = ifn_667.Invoke_O__O(arg_668) } else { tmp2 = linked_666.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(root_665, arg_668) }; arg_664 = lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp2); if linked_661 == nil { ifn_662.Invoke_O_O__O(arg_663, arg_664) } else { linked_661.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_660, arg_663, arg_664) }; i__1078000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1078000124__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_native_compile_fn_fn__1078000138_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000138_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000138_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000138_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :152:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000138_A) Invoke_O_O__O(self, p1__1078000119_SHARP___1 any) any { var root_720 any = A_arbace_classes_native_A_const_95.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = t.F_host; var arg_724 any = p1__1078000119_SHARP___1; if linked_721 == nil { return ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { return linked_721.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_720, arg_723, arg_724) } }
func A_arbace_classes_native_compile_fn_fn__1078000140_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000140_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000140_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000140_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :153:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000140_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(s__1, lang.IFn_Cast(t.F_host).Invoke_O__O(s__1)) }
func A_arbace_classes_native_compile_fn_fn__1078000142_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_native_compile_fn_fn__1078000142_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :154:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_A) Ctor_O_O_O_O_O_O(c__form, c__host, c__ns, c__syms, c__cname, c__captured any) { t.F_form = c__form; t.F_host = c__host; t.F_ns = c__ns; t.F_syms = c__syms; t.F_cname = c__cname; t.F_captured = c__captured }
//line :154:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_751 any = A_arbace_classes_native_A_const_49.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = lang.IFn_Cast(A_arbace_classes_native_A_const_50.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_native_A_const_51, t.F_ns); if linked_752 == nil { ifn_753.Invoke_O__O(arg_754) } else { linked_752.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_751, arg_754) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_native_A_const_41.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns; t.F_ns = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var root_742 any = A_arbace_classes_native_A_const_97.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, A_arbace_classes_native_fn_class_form_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any; var t__2 any = t.F_cname; t.F_cname = nil; arg_745 = t__2; var arg_746 any; var t__3 any = t.F_form; t.F_form = nil; arg_746 = t__3; var arg_747 any; var t__4 any = t.F_captured; t.F_captured = nil; arg_747 = t__4; if linked_743 == nil { tmp5 = ifn_744.Invoke_O_O_O__O(arg_745, arg_746, arg_747) } else { tmp5 = linked_743.(*A_arbace_classes_native_fn_class_form_A).Invoke_O_O_O_O__O(root_742, arg_745, arg_746, arg_747) }; tmp1 = tmp2.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5)) }
//line :155:1
		return nil }(); var root_748 any = A_arbace_classes_native_A_const_48.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; if linked_749 == nil { ifn_750.Invoke__O() } else { linked_749.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_748) }
//line :154:1
		if tmp6 != nil { panic(tmp6) } }; return nil }(); if tmp7 != nil { if lang.ExceptionInfo_InstanceOf(tmp7) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp7); var u__4 any; var root_760 any = A_arbace_classes_native_A_const_68.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_762 lang.IFn





			if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var tmp8 any = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_New(); var tmp9 *jrt.Class; var fncls__769 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class; if fncls__769 == nil { var fncls__769d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class = fncls__769d; tmp9 = fncls__769d } else { tmp9 = fncls__769 }; arg_763 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_764 any; var root_770 any = A_arbace_classes_native_A_const_100.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = A_arbace_classes_native_A_const_101.GetRawRoot__O(); var arg_774 any; var root_775 any = A_arbace_classes_native_A_const_102.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var tmp10 any = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_New(); var tmp11 *jrt.Class; var fncls__780 *jrt.Class = A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class; if fncls__780 == nil { var fncls__780d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class = fncls__780d; tmp11 = fncls__780d } else { tmp11 = fncls__780 }; arg_778 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_779 any = e__3; if linked_776 == nil { arg_774 = ifn_777.Invoke_O_O__O(arg_778, arg_779) } else { arg_774 = linked_776.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_775, arg_778, arg_779) }; if linked_771 == nil { arg_764 = ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { arg_764 = linked_771.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) }; if linked_761 == nil { u__4 = ifn_762.Invoke_O_O__O(arg_763, arg_764) } else { u__4 = linked_761.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_760, arg_763, arg_764) }
			var tmp12 any; var and__1927000168__auto____5 any = u__4; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_781 any = A_arbace_classes_native_A_const_95.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var t__5 any = t.F_host; t.F_host = nil; arg_784 = t__5; var arg_785 any = u__4; if linked_782 == nil { and__1927000168__auto____6 = ifn_783.Invoke_O_O__O(arg_784, arg_785) } else { and__1927000168__auto____6 = linked_782.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_781, arg_784, arg_785) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_786 any = A_arbace_classes_native_A_const_28.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var root_790 any = A_arbace_classes_native_A_const_68.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, u__4)); var arg_794 any; var t__6 any = t.F_syms; t.F_syms = nil; arg_794 = t__6; if linked_791 == nil { arg_789 = ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { arg_789 = linked_791.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) }; if linked_787 == nil { tmp12 = ifn_788.Invoke_O__O(arg_789) } else { tmp12 = linked_787.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_786, arg_789) } } else { tmp12 = and__1927000168__auto____6 } } else { tmp12 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp12) { tmp1 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_classes_native_A_const_103, u__4) } else { panic(jrt.Thrown(e__3)) } } else {
//line :154:1
				panic(tmp7) } }; return tmp1 }





func A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_New() *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A) Ctor() {}
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A) Invoke_O_O__O(self, p1__1078000120_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_native_A_const_98; var tmp2 any; var root_765 any = A_arbace_classes_native_A_const_99.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = p1__1078000120_SHARP___1; if linked_766 == nil { tmp2 = ifn_767.Invoke_O__O(arg_768) } else { tmp2 = linked_766.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_765, arg_768) }; return tmp1.Invoke_O__O(tmp2) }
//line :160:1
func A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_New() *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A) Ctor() {}
//line :160:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A) Invoke_O_O__O(self, p1__1078000121_SHARP___1 any) any { return jrt.Throwable_Cast(p1__1078000121_SHARP___1).GetCause__Throwable() }


























































































type A_arbace_classes_native_A struct{ jrt.Object }

var A_arbace_classes_native_A_const_pool *jrt.RefArray

var A_arbace_classes_native_A_const_0 *lang.Var

var A_arbace_classes_native_A_const_1 any

var A_arbace_classes_native_A_const_2 any

var A_arbace_classes_native_A_const_3 any

var A_arbace_classes_native_A_const_4 any

var A_arbace_classes_native_A_const_5 *lang.Var

var A_arbace_classes_native_A_const_6 any

var A_arbace_classes_native_A_const_7 *lang.Var

var A_arbace_classes_native_A_const_8 *lang.Var

var A_arbace_classes_native_A_const_9 *lang.Var

var A_arbace_classes_native_A_const_10 *lang.Var

var A_arbace_classes_native_A_const_11 any

var A_arbace_classes_native_A_const_12 *lang.Var

var A_arbace_classes_native_A_const_13 *lang.Var

var A_arbace_classes_native_A_const_14 *lang.Var

var A_arbace_classes_native_A_const_15 *lang.Var

var A_arbace_classes_native_A_const_16 *lang.Keyword

var A_arbace_classes_native_A_const_17 *lang.Var

var A_arbace_classes_native_A_const_18 *lang.Var

var A_arbace_classes_native_A_const_19 *lang.Var

var A_arbace_classes_native_A_const_20 *lang.Keyword

var A_arbace_classes_native_A_const_21 *lang.Var

var A_arbace_classes_native_A_const_22 *lang.Keyword

var A_arbace_classes_native_A_const_23 *lang.Var

var A_arbace_classes_native_A_const_24 *lang.Var

var A_arbace_classes_native_A_const_25 *lang.Var

var A_arbace_classes_native_A_const_26 *lang.Var

var A_arbace_classes_native_A_const_27 *lang.Var

var A_arbace_classes_native_A_const_28 *lang.Var

var A_arbace_classes_native_A_const_29 *lang.Var

var A_arbace_classes_native_A_const_30 *lang.Var

var A_arbace_classes_native_A_const_31 *lang.Var

var A_arbace_classes_native_A_const_32 *lang.Var

var A_arbace_classes_native_A_const_33 *lang.Var

var A_arbace_classes_native_A_const_34 *lang.Var

var A_arbace_classes_native_A_const_35 *lang.Var

var A_arbace_classes_native_A_const_36 *lang.Keyword

var A_arbace_classes_native_A_const_37 *lang.Var

var A_arbace_classes_native_A_const_38 *lang.Keyword

var A_arbace_classes_native_A_const_39 *lang.Var

var A_arbace_classes_native_A_const_40 *lang.Keyword

var A_arbace_classes_native_A_const_41 *lang.Var

var A_arbace_classes_native_A_const_42 *lang.Var

var A_arbace_classes_native_A_const_43 *lang.Var

var A_arbace_classes_native_A_const_44 any

var A_arbace_classes_native_A_const_45 any

var A_arbace_classes_native_A_const_46 *lang.Var

var A_arbace_classes_native_A_const_47 *lang.Var

var A_arbace_classes_native_A_const_48 *lang.Var

var A_arbace_classes_native_A_const_49 *lang.Var

var A_arbace_classes_native_A_const_50 *lang.Var

var A_arbace_classes_native_A_const_51 *lang.Var

var A_arbace_classes_native_A_const_52 *lang.Keyword

var A_arbace_classes_native_A_const_53 *lang.Var

var A_arbace_classes_native_A_const_54 *lang.Var

var A_arbace_classes_native_A_const_55 *lang.Var

var A_arbace_classes_native_A_const_56 *lang.Var

var A_arbace_classes_native_A_const_57 *jrt.Class

var A_arbace_classes_native_A_const_58 *lang.Var

var A_arbace_classes_native_A_const_59 *lang.Var

var A_arbace_classes_native_A_const_60 *lang.Var

var A_arbace_classes_native_A_const_61 *lang.Keyword

var A_arbace_classes_native_A_const_62 *lang.Keyword

var A_arbace_classes_native_A_const_63 *lang.Var

var A_arbace_classes_native_A_const_64 any

var A_arbace_classes_native_A_const_65 *lang.Var

var A_arbace_classes_native_A_const_66 *lang.Var

var A_arbace_classes_native_A_const_67 *lang.Var

var A_arbace_classes_native_A_const_68 *lang.Var

var A_arbace_classes_native_A_const_69 *lang.Var

var A_arbace_classes_native_A_const_70 any

var A_arbace_classes_native_A_const_71 any

var A_arbace_classes_native_A_const_72 *lang.Var

var A_arbace_classes_native_A_const_73 *lang.Keyword

var A_arbace_classes_native_A_const_74 *lang.Var

var A_arbace_classes_native_A_const_75 any

var A_arbace_classes_native_A_const_76 *lang.Keyword

var A_arbace_classes_native_A_const_77 *lang.Keyword

var A_arbace_classes_native_A_const_78 *lang.Keyword

var A_arbace_classes_native_A_const_79 *lang.Var

var A_arbace_classes_native_A_const_80 any

var A_arbace_classes_native_A_const_81 *lang.Var

var A_arbace_classes_native_A_const_82 *lang.Var

var A_arbace_classes_native_A_const_83 *lang.Keyword

var A_arbace_classes_native_A_const_84 *lang.Var

var A_arbace_classes_native_A_const_85 *lang.Var

var A_arbace_classes_native_A_const_86 any

var A_arbace_classes_native_A_const_87 any

var A_arbace_classes_native_A_const_88 any

var A_arbace_classes_native_A_const_89 any

var A_arbace_classes_native_A_const_90 *lang.Var

var A_arbace_classes_native_A_const_91 *lang.Var

var A_arbace_classes_native_A_const_92 *lang.Var

var A_arbace_classes_native_A_const_93 *lang.Var

var A_arbace_classes_native_A_const_94 *lang.Var

var A_arbace_classes_native_A_const_95 *lang.Var

var A_arbace_classes_native_A_const_96 *lang.Var

var A_arbace_classes_native_A_const_97 *lang.Var

var A_arbace_classes_native_A_const_98 *lang.Keyword

var A_arbace_classes_native_A_const_99 *lang.Var

var A_arbace_classes_native_A_const_100 *lang.Var

var A_arbace_classes_native_A_const_101 *lang.Var

var A_arbace_classes_native_A_const_102 *lang.Var

var A_arbace_classes_native_A_const_103 *lang.Keyword

var A_arbace_classes_native_A_const_104 any

var A_arbace_classes_native_A_const_105 *lang.Var

var A_arbace_classes_native_A_const_106 any

var A_arbace_classes_native_A_init jrt.ClassInit

func A_arbace_classes_native_A_Init() { if !A_arbace_classes_native_A_init.Done() { A_arbace_classes_native_A_init.Run(A_arbace_classes_native_A_clinit) } }

func A_arbace_classes_native_A_clinit() { A_arbace_classes_native_A_clinit_p0(); A_arbace_classes_native_A_clinit_p1(); A_arbace_classes_native_A_clinit_p2(); A_arbace_classes_native_A_clinit_p3(); A_arbace_classes_native_A_clinit_p4(); A_arbace_classes_native_A_clinit_p5(); A_arbace_classes_native_A_clinit_p6(); A_arbace_classes_native_A_clinit_p7(); A_arbace_classes_native_A_clinit_p8() }

func A_arbace_classes_native_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_native_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 148); A_arbace_classes_native_A_const_0 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[41]); A_arbace_classes_native_A_const_1 = A_arbace_classes_native_A_const_pool.A[42]; A_arbace_classes_native_A_const_2 = A_arbace_classes_native_A_const_pool.A[43]; A_arbace_classes_native_A_const_3 = A_arbace_classes_native_A_const_pool.A[44]; A_arbace_classes_native_A_const_4 = A_arbace_classes_native_A_const_pool.A[45]; A_arbace_classes_native_A_const_5 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[46]); A_arbace_classes_native_A_const_6 = A_arbace_classes_native_A_const_pool.A[47]; A_arbace_classes_native_A_const_7 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[48]); A_arbace_classes_native_A_const_8 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[49]); A_arbace_classes_native_A_const_9 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[50]); A_arbace_classes_native_A_const_10 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[51]); A_arbace_classes_native_A_const_11 = A_arbace_classes_native_A_const_pool.A[52] }

func A_arbace_classes_native_A_clinit_p1() { A_arbace_classes_native_A_const_12 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[53]); A_arbace_classes_native_A_const_13 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[54]); A_arbace_classes_native_A_const_14 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[55]); A_arbace_classes_native_A_const_15 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[56]); A_arbace_classes_native_A_const_16 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[57]); A_arbace_classes_native_A_const_17 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[58]); A_arbace_classes_native_A_const_18 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[59]); A_arbace_classes_native_A_const_19 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[60]); A_arbace_classes_native_A_const_20 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[61]); A_arbace_classes_native_A_const_21 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[62]); A_arbace_classes_native_A_const_22 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[63]); A_arbace_classes_native_A_const_23 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[64]) }

func A_arbace_classes_native_A_clinit_p2() { A_arbace_classes_native_A_const_24 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[65]); A_arbace_classes_native_A_const_25 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[66]); A_arbace_classes_native_A_const_26 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[67]); A_arbace_classes_native_A_const_27 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[68]); A_arbace_classes_native_A_const_28 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[69]); A_arbace_classes_native_A_const_29 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[70]); A_arbace_classes_native_A_const_30 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[71]); A_arbace_classes_native_A_const_31 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[72]); A_arbace_classes_native_A_const_32 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[73]); A_arbace_classes_native_A_const_33 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[74]); A_arbace_classes_native_A_const_34 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[75]); A_arbace_classes_native_A_const_35 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[76]) }

func A_arbace_classes_native_A_clinit_p3() { A_arbace_classes_native_A_const_36 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[77]); A_arbace_classes_native_A_const_37 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[78]); A_arbace_classes_native_A_const_38 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[79]); A_arbace_classes_native_A_const_39 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[80]); A_arbace_classes_native_A_const_40 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[81]); A_arbace_classes_native_A_const_41 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[82]); A_arbace_classes_native_A_const_42 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[83]); A_arbace_classes_native_A_const_43 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[84]); A_arbace_classes_native_A_const_44 = A_arbace_classes_native_A_const_pool.A[85]; A_arbace_classes_native_A_const_45 = A_arbace_classes_native_A_const_pool.A[86]; A_arbace_classes_native_A_const_46 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[87]); A_arbace_classes_native_A_const_47 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[88]) }

func A_arbace_classes_native_A_clinit_p4() { A_arbace_classes_native_A_const_48 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[89]); A_arbace_classes_native_A_const_49 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[90]); A_arbace_classes_native_A_const_50 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[91]); A_arbace_classes_native_A_const_51 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[92]); A_arbace_classes_native_A_const_52 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[93]); A_arbace_classes_native_A_const_53 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[94]); A_arbace_classes_native_A_const_54 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[95]); A_arbace_classes_native_A_const_55 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[96]); A_arbace_classes_native_A_const_56 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[97]); A_arbace_classes_native_A_const_57 = jrt.Class_Cast(A_arbace_classes_native_A_const_pool.A[98]); A_arbace_classes_native_A_const_58 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[99]); A_arbace_classes_native_A_const_59 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[100]) }

func A_arbace_classes_native_A_clinit_p5() { A_arbace_classes_native_A_const_60 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[101]); A_arbace_classes_native_A_const_61 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[102]); A_arbace_classes_native_A_const_62 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[103]); A_arbace_classes_native_A_const_63 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[104]); A_arbace_classes_native_A_const_64 = A_arbace_classes_native_A_const_pool.A[105]; A_arbace_classes_native_A_const_65 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[106]); A_arbace_classes_native_A_const_66 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[107]); A_arbace_classes_native_A_const_67 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[108]); A_arbace_classes_native_A_const_68 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[109]); A_arbace_classes_native_A_const_69 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[110]); A_arbace_classes_native_A_const_70 = A_arbace_classes_native_A_const_pool.A[111]; A_arbace_classes_native_A_const_71 = A_arbace_classes_native_A_const_pool.A[112] }

func A_arbace_classes_native_A_clinit_p6() { A_arbace_classes_native_A_const_72 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[113]); A_arbace_classes_native_A_const_73 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[114]); A_arbace_classes_native_A_const_74 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[115]); A_arbace_classes_native_A_const_75 = A_arbace_classes_native_A_const_pool.A[116]; A_arbace_classes_native_A_const_76 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[117]); A_arbace_classes_native_A_const_77 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[118]); A_arbace_classes_native_A_const_78 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[119]); A_arbace_classes_native_A_const_79 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[120]); A_arbace_classes_native_A_const_80 = A_arbace_classes_native_A_const_pool.A[121]; A_arbace_classes_native_A_const_81 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[122]); A_arbace_classes_native_A_const_82 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[123]); A_arbace_classes_native_A_const_83 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[124]) }

func A_arbace_classes_native_A_clinit_p7() { A_arbace_classes_native_A_const_84 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[125]); A_arbace_classes_native_A_const_85 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[126]); A_arbace_classes_native_A_const_86 = A_arbace_classes_native_A_const_pool.A[127]; A_arbace_classes_native_A_const_87 = A_arbace_classes_native_A_const_pool.A[128]; A_arbace_classes_native_A_const_88 = A_arbace_classes_native_A_const_pool.A[129]; A_arbace_classes_native_A_const_89 = A_arbace_classes_native_A_const_pool.A[130]; A_arbace_classes_native_A_const_90 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[131]); A_arbace_classes_native_A_const_91 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[132]); A_arbace_classes_native_A_const_92 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[133]); A_arbace_classes_native_A_const_93 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[134]); A_arbace_classes_native_A_const_94 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[135]); A_arbace_classes_native_A_const_95 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[136]); A_arbace_classes_native_A_const_96 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[137]) }

func A_arbace_classes_native_A_clinit_p8() { A_arbace_classes_native_A_const_97 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[138]); A_arbace_classes_native_A_const_98 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[139]); A_arbace_classes_native_A_const_99 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[140]); A_arbace_classes_native_A_const_100 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[141]); A_arbace_classes_native_A_const_101 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[142]); A_arbace_classes_native_A_const_102 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[143]); A_arbace_classes_native_A_const_103 = lang.Keyword_Cast(A_arbace_classes_native_A_const_pool.A[144]); A_arbace_classes_native_A_const_104 = A_arbace_classes_native_A_const_pool.A[145]; A_arbace_classes_native_A_const_105 = lang.Var_Cast(A_arbace_classes_native_A_const_pool.A[146]); A_arbace_classes_native_A_const_106 = A_arbace_classes_native_A_const_pool.A[147] }

func A_arbace_classes_native_A_New() *A_arbace_classes_native_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_A) Ctor() {}

func (t *A_arbace_classes_native_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_A_class }

func (t *A_arbace_classes_native_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_A); return ok }

func A_arbace_classes_native_A_Cast(x any) *A_arbace_classes_native_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_A_class)) }; return v }



type A_arbace_classes_native_compile_and_load_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A struct{ j2g_header uint64; F_s__1078000016, F_iter__1078000015 any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A struct{ j2g_header uint64; F_b__1078000018 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_and_load_BANG__iter__1078000015__1078000019_fn__1078000020_fn__1078000021_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_deftype_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_deftype_fn__1078000049_A struct{ j2g_header uint64; F_form, F_ns any }

var A_arbace_classes_native_compile_deftype_fn__1078000049_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000138_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000138_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000140_A struct{ j2g_header uint64; F_host any }

var A_arbace_classes_native_compile_fn_fn__1078000140_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_A struct{ j2g_header uint64; F_form, F_host, F_ns, F_syms, F_cname, F_captured any }

var A_arbace_classes_native_compile_fn_fn__1078000142_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000143_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_fn__1078000142_fn__1078000145_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A struct{ j2g_header uint64; F_s__1078000123, F_iter__1078000122 any }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A struct{ j2g_header uint64; F_b__1078000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_fn_iter__1078000122__1078000126_fn__1078000127_fn__1078000128_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A struct{ j2g_header uint64 }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A struct{ j2g_header uint64; F_s__1078000033, F_iter__1078000032 any }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_A_fn_class *jrt.Class



type A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1078000035, F_c__1927001037__auto__ any }

var A_arbace_classes_native_compile_top_iter__1078000032__1078000036_fn__1078000037_fn__1078000038_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000004_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000004_A_New() *A_arbace_classes_native_eval1078000004_A { t := &A_arbace_classes_native_eval1078000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000004_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000004_A_class }

func (t *A_arbace_classes_native_eval1078000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000004_A); return ok }

func A_arbace_classes_native_eval1078000004_A_Cast(x any) *A_arbace_classes_native_eval1078000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000004_A_class)) }; return v }



type A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class *jrt.Class



type A_arbace_classes_native_eval1078000008_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000008_A_New() *A_arbace_classes_native_eval1078000008_A { t := &A_arbace_classes_native_eval1078000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000008_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000008_A_class }

func (t *A_arbace_classes_native_eval1078000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000008_A); return ok }

func A_arbace_classes_native_eval1078000008_A_Cast(x any) *A_arbace_classes_native_eval1078000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000008_A_class)) }; return v }



type A_arbace_classes_native_eval1078000008_fn__1078000009_A struct{ j2g_header uint64 }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class *jrt.Class



type A_arbace_classes_native_field_names_A struct{ j2g_header uint64 }

var A_arbace_classes_native_field_names_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000097_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_fn__1078000097_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_fn__1078000113_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_fn__1078000113_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A struct{ j2g_header uint64; F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A struct{ j2g_header uint64; F_s__1078000075, F_iter__1078000074, F_typed any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A struct{ j2g_header uint64; F_b__1078000077, F_typed any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000074__1078000078_fn__1078000079_fn__1078000080_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A struct{ j2g_header uint64; F_rcv any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A struct{ j2g_header uint64; F_s__1078000103, F_rcv, F_iter__1078000102 any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A struct{ j2g_header uint64; F_b__1078000105, F_rcv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_native_fn_class_form_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class *jrt.Class



type A_arbace_classes_native_fn_class_form_typed__1078000072_A struct{ j2g_header uint64 }

var A_arbace_classes_native_fn_class_form_typed__1078000072_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_A struct{ j2g_header uint64 }

var A_arbace_classes_native_local_class_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000054_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000054_A_fn_class *jrt.Class



type A_arbace_classes_native_local_class_fn__1078000056_A struct{ j2g_header uint64; F_lb any }

var A_arbace_classes_native_local_class_fn__1078000056_A_fn_class *jrt.Class



type A_arbace_classes_native_public_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_native_public_class_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_native_type_form_A struct{ j2g_header uint64 }

var A_arbace_classes_native_type_form_A_fn_class *jrt.Class
