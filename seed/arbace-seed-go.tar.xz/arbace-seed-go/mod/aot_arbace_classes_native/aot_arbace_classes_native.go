//line aot_arbace_classes_native.ae:1
package aot_arbace_classes_native

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New() *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A { A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_Init(); t := &A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_classes_native_A_Init(); tmp11 = A_arbace_classes_native_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_classes_native_A_Init(); tmp15 = A_arbace_classes_native_A_const_6; tmp3 = tmp8.Invoke_O_O_O_O__O(tmp10, tmp12, tmp14, tmp15) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp16 != nil { panic(tmp16) }; return tmp3 }
//line :1:1
func A_arbace_classes_native_eval1078000008_fn__1078000009_A_New() *A_arbace_classes_native_eval1078000008_fn__1078000009_A { A_arbace_classes_native_eval1078000008_fn__1078000009_A_Init(); t := &A_arbace_classes_native_eval1078000008_fn__1078000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
























func A_arbace_classes_native_compile_top_A_New() *A_arbace_classes_native_compile_top_A { A_arbace_classes_native_compile_top_A_Init(); t := &A_arbace_classes_native_compile_top_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_classes_native_compile_top_A) Ctor() {}
//line :26:1
func (t *A_arbace_classes_native_compile_top_A) Invoke_O_O_O_O_O__O(self, ns__0, kind__1, forms__2, siblings__3 any) any { var forms__5 any; var tmp1 *lang.Keyword;






	A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_12; if lang.Util_Equiv_O_O__Z(tmp1.Ref(), kind__1) { forms__5 = lang.Tuple_Create_O__IPersistentVector(forms__2) } else { var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_13; forms__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(forms__2) }; var loaded__6 any; var tmp3 /*line :26:1*/*lang.Var;







	A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_14; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_16; loaded__6 = tmp4.Invoke_O_O_O_O__O(ns__0, forms__5, tmp5.Ref(), siblings__3); var tmp6 /*line :33:1*/*lang.Var; A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_15; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_classes_native_A_Init(); tmp8 = A_arbace_classes_native_A_const_17; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_classes_native_A_Init(); tmp10 = A_arbace_classes_native_A_const_18; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_classes_native_A_Init(); tmp12 = A_arbace_classes_native_A_const_30; var tmp13 any = tmp11.Invoke_O__O(tmp12); var tmp14 any; var iter__1927001039__auto____7 any; var tmp15 any = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_New(); var tmp16 *jrt.Class;


	A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_Init(); tmp16 = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_fn_class; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(loaded__6); var tmp17 any = tmp14; var tmp18 /*line :33:1*/*lang.Var; A_arbace_classes_native_A_Init(); tmp18 = A_arbace_classes_native_A_const_18; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; var tmp21 *lang.Keyword;



	A_arbace_classes_native_A_Init(); tmp21 = A_arbace_classes_native_A_const_12; if lang.Util_Equiv_O_O__Z(tmp21.Ref(), kind__1) { var tmp22 *lang.Var; A_arbace_classes_native_A_Init(); tmp22 = A_arbace_classes_native_A_const_31; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_classes_native_A_Init(); tmp24 = A_arbace_classes_native_A_const_25; tmp20 = tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(loaded__6)) } else { var tmp25 *lang.Var; A_arbace_classes_native_A_Init(); tmp25 = A_arbace_classes_native_A_const_32; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_classes_native_A_Init(); tmp27 = A_arbace_classes_native_A_const_31; tmp20 = tmp26.Invoke_O_O__O(jrt.NN(tmp27).GetRawRoot__O(), loaded__6) }; return /*line :33:1*/ tmp7.Invoke_O__O(tmp9.Invoke_O_O_O__O(tmp13, tmp17, tmp19.Invoke_O__O(tmp20))) }


func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_New() *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) Ctor() {}
//line :36:1
func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) Invoke_O_O__O(self, s__1078000013__1 any) any { var tmp1 any = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_New_O_O(s__1078000013__1, self); var tmp2 *jrt.Class; A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_Init(); tmp2 = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :36:1
func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A{}; t.Ctor_O_O(p0, p1); return t }
//line :36:1
func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) Ctor_O_O(c__s__1078000013, c__iter__1078000012 any) { t.F_s__1078000013 = c__s__1078000013; t.F_iter__1078000012 = c__iter__1078000012 }
//line :36:1
func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) Invoke_O__O(self any) any { { var s__1078000013__1 any; var t_ any = t.F_s__1078000013; t.F_s__1078000013 = nil; s__1078000013__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1078000013__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1078000013__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1078000013__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_20; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1078000013__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1078000015__6 any; var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_21; b__1078000015__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_New_O_I_O(b__1078000015__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_Init(); tmp6 = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1078000015__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000012); var tmp12 *lang.Var; A_arbace_classes_native_A_Init(); tmp12 = A_arbace_classes_native_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1078000013__3))) } else { var tmp13 *lang.Var; A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_native_A_Init(); tmp15 = A_arbace_classes_native_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1078000015__6), nil) } } else { var vec__1078000023__4 any; var tmp16 *lang.Var; A_arbace_classes_native_A_Init(); tmp16 = A_arbace_classes_native_A_const_25; vec__1078000023__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1078000013__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1078000023__4, lang.RT_IntCast_J__I(0), nil); var tmp17 *lang.Var; A_arbace_classes_native_A_Init(); tmp17 = A_arbace_classes_native_A_const_26; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_native_A_Init(); tmp19 = A_arbace_classes_native_A_const_18; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_native_A_Init(); tmp21 = A_arbace_classes_native_A_const_23; var tmp22 any = tmp20.Invoke_O_O__O(tmp21, n__5); var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__1078000012); var tmp24 *lang.Var; A_arbace_classes_native_A_Init(); tmp24 = A_arbace_classes_native_A_const_29; return tmp18.Invoke_O_O__O(tmp22, tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(s__1078000013__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :36:1
func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_Init(); t := &A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :36:1
func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) Ctor_O_I_O(c__b__1078000015 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000015 = c__b__1078000015; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :36:1
func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) Invoke_O__O(self any) any { { var i__1078000014__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1078000014__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000019__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1078000014__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1078000019__2, lang.RT_IntCast_J__I(0), nil); var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1078000015; var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_18; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_23; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp7, n__3)); i__1078000014__1 = lang.Numbers_Unchecked_inc_J__J(i__1078000014__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_classes_native_compile_deftype_A_New() *A_arbace_classes_native_compile_deftype_A { A_arbace_classes_native_compile_deftype_A_Init(); t := &A_arbace_classes_native_compile_deftype_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_classes_native_compile_deftype_A) Ctor() {}
//line :42:1
func (t *A_arbace_classes_native_compile_deftype_A) Invoke_O_O_O__O(self, ns__0, form__1 any) any {




	var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_36; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_37; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5.Ref(), ns__0)); var tmp6 any = A_arbace_classes_native_compile_deftype_fn__1078000029_A_New_O_O(form__1, ns__0); var tmp7 *jrt.Class; A_arbace_classes_native_compile_deftype_fn__1078000029_A_Init(); tmp7 = A_arbace_classes_native_compile_deftype_fn__1078000029_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :42:1
	return nil
}



func A_arbace_classes_native_compile_deftype_fn__1078000029_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_deftype_fn__1078000029_A { A_arbace_classes_native_compile_deftype_fn__1078000029_A_Init(); t := &A_arbace_classes_native_compile_deftype_fn__1078000029_A{}; t.Ctor_O_O(p0, p1); return t }
//line :47:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) Ctor_O_O(c__form, c__ns any) { t.F_form = c__form; t.F_ns = c__ns }
//line :47:1
func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_14; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_ns; t.F_ns = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 *lang.Var; A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_34; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; var t__2 any = t.F_form; t.F_form = nil; tmp8 = t__2; tmp1 = tmp3.Invoke_O_O__O(tmp5, lang.Tuple_Create_O__IPersistentVector(tmp7.Invoke_O__O(tmp8))) }
//line :47:1
	return nil }(); var tmp10 *lang.Var; A_arbace_classes_native_A_Init(); tmp10 = A_arbace_classes_native_A_const_33; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke__O(); if tmp9 != nil { panic(tmp9) }; return tmp1 }






func A_arbace_classes_native_public_class_QMARK__A_New() *A_arbace_classes_native_public_class_QMARK__A { A_arbace_classes_native_public_class_QMARK__A_Init(); t := &A_arbace_classes_native_public_class_QMARK__A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Ctor() {}
//line :54:1
func (t *A_arbace_classes_native_public_class_QMARK__A) Invoke_O_O__O(self, c__0 any) any { { var c__2 any = c__0; L1: for {

	if lang.Util_Identical_O_O__Z(c__2, nil) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_38; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__2)).GetModifiers__I())).Ref())) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp2 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_39; if tmp2 != nil {

		c__2 = jrt.NN(jrt.Class_Cast(c__2)).GetDeclaringClass__Class().Ref(); continue L1 } else {
//line :56:1
			return nil } } } } }; /*line :54:1*/panic("a2g: unreachable") }





func A_arbace_classes_native_type_form_A_New() *A_arbace_classes_native_type_form_A { A_arbace_classes_native_type_form_A_Init(); t := &A_arbace_classes_native_type_form_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_native_type_form_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_native_type_form_A) Invoke_O_O__O(self, c__0 any) any {


	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var c__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(c__2)).IsArray__Z() { c__2, n__3 = jrt.NN(jrt.Class_Cast(c__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J(n__3); continue L1 } else { var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_40; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_41; return tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(n__3).Ref())) } } } else {
			var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_40; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref()) }
//line :60:1
	panic("a2g: unreachable")
}






func A_arbace_classes_native_local_class_A_New() *A_arbace_classes_native_local_class_A { A_arbace_classes_native_local_class_A_Init(); t := &A_arbace_classes_native_local_class_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_classes_native_local_class_A) Ctor() {}
//line :68:1
func (t *A_arbace_classes_native_local_class_A) Invoke_O_O__O(self, lb__0 any) any { var prim__2 any; var tmp1 any = A_arbace_classes_native_local_class_fn__1078000034_A_New_O(lb__0); var tmp2 *jrt.Class;



	A_arbace_classes_native_local_class_fn__1078000034_A_Init(); tmp2 = A_arbace_classes_native_local_class_fn__1078000034_A_fn_class; prim__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var or__1927000174__auto____3 any = prim__2; if
	jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var c__4 any; var tmp3 any = A_arbace_classes_native_local_class_fn__1078000036_A_New_O(lb__0); var tmp4 *jrt.Class
		A_arbace_classes_native_local_class_fn__1078000036_A_Init(); tmp4 = A_arbace_classes_native_local_class_fn__1078000036_A_fn_class; c__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


		var tmp5 any; var and__1927000168__auto____5 bool = jrt.Class_InstanceOf(c__4); if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var tmp6 *lang.Var; A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_38; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__4)).IsPrimitive__Z()).Ref()); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_42; and__1927000168__auto____7 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(c__4); if jrt.A2g_Truth(and__1927000168__auto____7) {
			var tmp8 *lang.Var; A_arbace_classes_native_A_Init(); tmp8 = A_arbace_classes_native_A_const_38; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_classes_native_A_Init(); tmp10 = A_arbace_classes_native_A_const_44; tmp5 = tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref(), Lit_136)) } else {
//line :77:1
				tmp5 = and__1927000168__auto____7 } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.A2g_Truth(tmp5) { return c__4 } else { A_arbace_classes_native_A_Init(); return A_arbace_classes_native_A_const_43.Ref() } } }
//line :72:1
func A_arbace_classes_native_local_class_fn__1078000034_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000034_A { A_arbace_classes_native_local_class_fn__1078000034_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000034_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_classes_native_local_class_fn__1078000034_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :72:1
func (t *A_arbace_classes_native_local_class_fn__1078000034_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetPrimitiveType__Class().Ref() }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_classes_native_local_class_fn__1078000036_A_New_O(p0 any) *A_arbace_classes_native_local_class_fn__1078000036_A { A_arbace_classes_native_local_class_fn__1078000036_A_Init(); t := &A_arbace_classes_native_local_class_fn__1078000036_A{}; t.Ctor_O(p0); return t }
//line :74:1
func (t *A_arbace_classes_native_local_class_fn__1078000036_A) Ctor_O(c__lb any) { t.F_lb = c__lb }
//line :74:1
func (t *A_arbace_classes_native_local_class_fn__1078000036_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); if jrt.NN(lang.Compiler_LocalBinding_Cast(t.F_lb)).HasJavaClass__Z() {
												var tmp2 any; var t_ any = t.F_lb; t.F_lb = nil; tmp2 = t_; tmp1 = jrt.NN(lang.Compiler_LocalBinding_Cast(tmp2)).GetJavaClass__Class().Ref() } else {
//line :74:1
		tmp1 = nil }; return nil }(); if tmp3 != nil { if true { var ___3 jrt.Throwable_I = tmp3; _ = ___3; tmp1 = nil } }; return tmp1 }







func A_arbace_classes_native_field_names_A_New() *A_arbace_classes_native_field_names_A { A_arbace_classes_native_field_names_A_Init(); t := &A_arbace_classes_native_field_names_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_classes_native_field_names_A) Ctor() {}
//line :82:1
func (t *A_arbace_classes_native_field_names_A) Invoke_O_O__O(self, syms__0 any) any { { var G__1078000042__2_ any = syms__0; var vec__1078000043__3 any = G__1078000042__2_; var seq__1078000044__4 any; var tmp1 *lang.Var


	A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_15; seq__1078000044__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1078000043__3)
//line :82:1
	var first__1078000045__5 any; var tmp2 *lang.Var


	A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_25; first__1078000045__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1078000044__4)
//line :82:1
	var seq__1078000044__6 any; var tmp3 *lang.Var


	A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_45; seq__1078000044__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1078000044__4)
//line :82:1
	var s__7 any = first__1078000045__5; var more__8 any = seq__1078000044__6; var seen__9 any; _ = s__7; _ = more__8; lang.PersistentHashSet_Init(); seen__9 = lang.PersistentHashSet_EMPTY.Ref(); var out__10 any; lang.PersistentVector_Init(); out__10 = lang.PersistentVector_EMPTY.Ref(); var G__1078000042__11_ any = G__1078000042__2_; var seen__12 any = seen__9; var out__13 any = out__10; L1: for { var vec__1078000046__14 any = G__1078000042__11_; var seq__1078000047__15 any; var tmp4 *lang.Var


		A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_15; seq__1078000047__15 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(vec__1078000046__14)
//line :82:1
		var first__1078000048__16 any; var tmp5 *lang.Var


		A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_25; first__1078000048__16 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1078000047__15)
//line :82:1
		var seq__1078000047__17 any; var tmp6 *lang.Var


		A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_45; seq__1078000047__17 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__1078000047__15)
//line :82:1
		var s__18 any = first__1078000048__16; var more__19 any = seq__1078000047__17; var seen__20 any = seen__12; var out__21 any = out__13; var tmp7 *lang.Var



		A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_38; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(s__18)) { return out__21 } else { var base__22 any; var tmp8 *lang.Var

			A_arbace_classes_native_A_Init(); tmp8 = A_arbace_classes_native_A_const_46; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_classes_native_A_Init(); tmp10 = A_arbace_classes_native_A_const_47; base__22 = tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(s__18))
//line :86:1
			var n__23 any


			if jrt.A2g_Truth(lang.IFn_Cast(seen__20).Invoke_O__O(base__22)) { n__23 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_120, nil), jrt.RefArrayOf(jrt.Object_class, base__22, nil, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(out__21)).Ref())).Ref() } else { n__23 = base__22 }
			var tmp11 *lang.Var; A_arbace_classes_native_A_Init(); tmp11 = A_arbace_classes_native_A_const_9; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(seen__20, n__23); var tmp13 *lang.Var; A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_9; G__1078000042__11_, seen__12, out__13 = more__19, tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(out__21, n__23); continue L1 } } }; /*line :82:1*/panic("a2g: unreachable") }









func A_arbace_classes_native_fn_class_form_A_New() *A_arbace_classes_native_fn_class_form_A { A_arbace_classes_native_fn_class_form_A_Init(); t := &A_arbace_classes_native_fn_class_form_A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_classes_native_fn_class_form_A) Ctor() {}
//line :92:1
func (t *A_arbace_classes_native_fn_class_form_A) Invoke_O_O_O_O__O(self, cname__0, form__1, captured__2 any) any { var map__1078000050__4 any; var tmp1 *lang.Var;



	A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_48; map__1078000050__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__1); var map__1078000050__5 any; if lang.ISeq_InstanceOf(map__1078000050__4) { var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1078000050__4)) { var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_49; map__1078000050__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1078000050__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1078000050__4)) { var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_25; map__1078000050__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1078000050__4) } else { lang.PersistentArrayMap_Init(); map__1078000050__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1078000050__5 = map__1078000050__4 }; var nm__6 any; var tmp6 /*line :92:1*/*lang.Keyword;



	A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_50; nm__6 = lang.RT_Get_O_O__O(map__1078000050__5, tmp6.Ref()); var arities__7 any; var tmp7 /*line :92:1*/*lang.Keyword;



	A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_51; arities__7 = lang.RT_Get_O_O__O(map__1078000050__5, tmp7.Ref()); var i__8 int32 = /*line :92:1*/jrt.NN(jrt.String_Cast(cname__0)).LastIndexOf_String__I(Lit_122); var pkg__9 any; if





	lang.Numbers_IsNeg_J__Z(int64(i__8)) { pkg__9 = Lit_123 } else { var tmp8 *lang.Var; A_arbace_classes_native_A_Init(); tmp8 = A_arbace_classes_native_A_const_52; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_classes_native_A_Init(); tmp10 = A_arbace_classes_native_A_const_61; var tmp11 any = tmp10; pkg__9 = tmp9.Invoke_O_O_O__O(cname__0, tmp11, jrt.Integer_ValueOf_I__Integer(i__8).Ref()) }; var simple__10 any; var tmp12 /*line :92:1*/*lang.Var;






	A_arbace_classes_native_A_Init(); tmp12 = A_arbace_classes_native_A_const_52; simple__10 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(cname__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(i__8))).Ref()); var rcv__11 any; var tmp13 /*line :92:1*/*lang.Var;







	A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_53; rcv__11 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(Lit_124); var fields__12 any; var tmp14 /*line :92:1*/*lang.Var;








	A_arbace_classes_native_A_Init(); tmp14 = A_arbace_classes_native_A_const_54; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_classes_native_A_Init(); tmp16 = A_arbace_classes_native_A_const_62; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_classes_native_A_Init(); tmp18 = A_arbace_classes_native_A_const_25; fields__12 = tmp15.Invoke_O__O(tmp17.Invoke_O_O__O(jrt.NN(tmp18).GetRawRoot__O(), captured__2)); var super__13 any; var tmp19 /*line :92:1*/*lang.Var;









	A_arbace_classes_native_A_Init(); tmp19 = A_arbace_classes_native_A_const_55; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_native_A_Init(); tmp21 = A_arbace_classes_native_A_const_63; if jrt.A2g_Truth(tmp20.Invoke_O_O__O(jrt.NN(tmp21).GetRawRoot__O(), arities__7)) { A_arbace_classes_native_A_Init(); super__13 = A_arbace_classes_native_A_const_56 } else { A_arbace_classes_native_A_Init(); super__13 = A_arbace_classes_native_A_const_57 }; var typed__14 any; var tmp22 any = /*line :92:1*/A_arbace_classes_native_fn_class_form_typed__1078000052_A_New(); var tmp23 *jrt.Class;










	A_arbace_classes_native_fn_class_form_typed__1078000052_A_Init(); tmp23 = A_arbace_classes_native_fn_class_form_typed__1078000052_A_fn_class; typed__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var tmp24 /*line :104:1*/*lang.Var; A_arbace_classes_native_A_Init(); tmp24 = A_arbace_classes_native_A_const_17; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_classes_native_A_Init(); tmp26 = A_arbace_classes_native_A_const_58; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_classes_native_A_Init(); tmp28 = A_arbace_classes_native_A_const_40; var tmp29 any = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(simple__10); var tmp30 any; A_arbace_classes_native_A_Init(); tmp30 = A_arbace_classes_native_A_const_73; var tmp31 any = tmp27.Invoke_O_O__O(tmp29, tmp30); var tmp32 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp32 = A_arbace_classes_native_A_const_64; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp34 = A_arbace_classes_native_A_const_65; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp36 = A_arbace_classes_native_A_const_66; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Var; A_arbace_classes_native_A_Init(); tmp38 = A_arbace_classes_native_A_const_67; var tmp39 any = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, pkg__9, tmp35, super__13, tmp37, lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(arities__7))); var tmp40 any; var iter__1927001039__auto____15 any; var tmp41 any = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_New_O(typed__14); var tmp42 *jrt.Class;




	A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_Init(); tmp42 = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_fn_class; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil); var tmp43 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp44 *lang.Var; A_arbace_classes_native_A_Init(); tmp44 = A_arbace_classes_native_A_const_62; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_classes_native_A_Init(); tmp46 = A_arbace_classes_native_A_const_74; tmp40 = tmp43.Invoke_O__O(tmp45.Invoke_O_O_O__O(jrt.NN(tmp46).GetRawRoot__O(), fields__12, captured__2)); var tmp47 any = tmp40; var tmp48 /*line :104:1*/*lang.Var; A_arbace_classes_native_A_Init(); tmp48 = A_arbace_classes_native_A_const_75; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any; A_arbace_classes_native_A_Init(); tmp50 = A_arbace_classes_native_A_const_76; var tmp51 any = tmp50; var tmp52 *lang.Var; A_arbace_classes_native_A_Init(); tmp52 = A_arbace_classes_native_A_const_58; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_classes_native_A_Init(); tmp54 = A_arbace_classes_native_A_const_13; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_classes_native_A_Init(); tmp56 = A_arbace_classes_native_A_const_26; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Var; A_arbace_classes_native_A_Init(); tmp58 = A_arbace_classes_native_A_const_62; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any = A_arbace_classes_native_fn_class_form_fn__1078000077_A_New_O(typed__14); var tmp61 *jrt.Class; A_arbace_classes_native_fn_class_form_fn__1078000077_A_Init(); tmp61 = A_arbace_classes_native_fn_class_form_fn__1078000077_A_fn_class; var tmp62 any = tmp55.Invoke_O__O(tmp57.Invoke_O_O__O(rcv__11, tmp59.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil), fields__12, captured__2))); var tmp63 any; A_arbace_classes_native_A_Init(); tmp63 = A_arbace_classes_native_A_const_78; var tmp64 any = tmp53.Invoke_O_O__O(tmp62, tmp63); var tmp65 *lang.Var; A_arbace_classes_native_A_Init(); tmp65 = A_arbace_classes_native_A_const_18; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 any; A_arbace_classes_native_A_Init(); tmp67 = A_arbace_classes_native_A_const_79; var tmp68 any = tmp66.Invoke_O__O(tmp67); var tmp69 any; var iter__1927001039__auto____15_2 any; var tmp70 any = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_New_O(rcv__11); var tmp71 *jrt.Class;









	A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_Init(); tmp71 = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_fn_class; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp70, tmp71, nil); tmp69 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(fields__12); var tmp72 any = /*line :104:1*/lang.Tuple_Create_O__IPersistentVector(tmp49.Invoke_O_O_O_O__O(tmp51, tmp64, tmp68, tmp69)); var tmp73 *lang.Var; A_arbace_classes_native_A_Init(); tmp73 = A_arbace_classes_native_A_const_72; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_classes_native_A_Init(); tmp75 = A_arbace_classes_native_A_const_13; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Var; A_arbace_classes_native_A_Init(); tmp77 = A_arbace_classes_native_A_const_80; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 any = A_arbace_classes_native_fn_class_form_fn__1078000093_A_New_O(rcv__11); var tmp80 *jrt.Class; A_arbace_classes_native_fn_class_form_fn__1078000093_A_Init(); tmp80 = A_arbace_classes_native_fn_class_form_fn__1078000093_A_fn_class; return tmp25.Invoke_O_O_O_O__O(tmp39, tmp47, tmp72, tmp74.Invoke_O_O_O_O__O(rcv__11, nm__6, arities__7, tmp76.Invoke_O__O(tmp78.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp79, tmp80, nil), fields__12, captured__2)))) }
//line :103:1
func A_arbace_classes_native_fn_class_form_typed__1078000052_A_New() *A_arbace_classes_native_fn_class_form_typed__1078000052_A { A_arbace_classes_native_fn_class_form_typed__1078000052_A_Init(); t := &A_arbace_classes_native_fn_class_form_typed__1078000052_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) Ctor() {}
//line :103:1
func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) Invoke_O_O_O__O(self, s__1, c__2 any) any { var tmp1 *jrt.Class; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_43; if lang.Util_Equiv_O_O__Z(c__2, tmp1.Ref()) { return s__1 } else { var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_58; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_59; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_60; return tmp3.Invoke_O_O__O(s__1, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(c__2)))) } }





func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A{}; t.Ctor_O(p0); return t }
//line :109:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :109:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) Invoke_O_O__O(self, s__1078000055__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_New_O_O_O(s__1078000055__1, self, t.F_typed); var tmp2 *jrt.Class; A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_Init(); tmp2 = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) Ctor_O_O_O(c__s__1078000055, c__iter__1078000054, c__typed any) { t.F_s__1078000055 = c__s__1078000055; t.F_iter__1078000054 = c__iter__1078000054; t.F_typed = c__typed }
//line :109:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) Invoke_O__O(self any) any { { var s__1078000055__1 any; var t_ any = t.F_s__1078000055; t.F_s__1078000055 = nil; s__1078000055__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1078000055__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1078000055__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1078000055__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_20; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1078000055__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1078000057__6 any; var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_21; b__1078000057__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_New_O_I_O_O(t.F_typed, size__1927001038__auto____5, b__1078000057__6, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_Init(); tmp6 = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1078000057__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000054); var tmp12 *lang.Var; A_arbace_classes_native_A_Init(); tmp12 = A_arbace_classes_native_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1078000055__3))) } else { var tmp13 *lang.Var; A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_native_A_Init(); tmp15 = A_arbace_classes_native_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1078000057__6), nil) } } else { var vec__1078000068__4 any; var tmp16 *lang.Var; A_arbace_classes_native_A_Init(); tmp16 = A_arbace_classes_native_A_const_25; vec__1078000068__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1078000055__3); var f__5 any = lang.RT_Nth_O_I_O__O(vec__1078000068__4, lang.RT_IntCast_J__I(0), nil); var vec__1078000071__6 any = lang.RT_Nth_O_I_O__O(vec__1078000068__4, lang.RT_IntCast_J__I(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O(vec__1078000071__6, lang.RT_IntCast_J__I(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O(vec__1078000071__6, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; _ = ___7; A_arbace_classes_native_A_Init(); tmp17 = A_arbace_classes_native_A_const_26; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_native_A_Init(); tmp19 = A_arbace_classes_native_A_const_18; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_native_A_Init(); tmp21 = A_arbace_classes_native_A_const_68; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_classes_native_A_Init(); tmp23 = A_arbace_classes_native_A_const_69; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp26 *lang.Var; A_arbace_classes_native_A_Init(); tmp26 = A_arbace_classes_native_A_const_40; var tmp27 any = tmp25.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(f__5), c__8); var tmp28 *lang.Var; A_arbace_classes_native_A_Init(); tmp28 = A_arbace_classes_native_A_const_70; var tmp29 any = jrt.NN(tmp28).GetRawRoot__O(); var tmp30 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp30 = A_arbace_classes_native_A_const_71; var tmp31 any = tmp30.Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp20.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O_O_O__O(tmp27, tmp29, tmp31, tmp32.Ref())); var tmp34 lang.IFn = lang.IFn_Cast(t.F_iter__1078000054); var tmp35 *lang.Var; A_arbace_classes_native_A_Init(); tmp35 = A_arbace_classes_native_A_const_29; return tmp18.Invoke_O_O__O(tmp33, tmp34.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(s__1078000055__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :109:1
func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :109:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) Ctor_O_I_O_O(c__typed any, c__size__1927001038__auto__ int32, c__b__1078000057, c__c__1927001037__auto__ any) { t.F_typed = c__typed; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1078000057 = c__b__1078000057; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) Invoke_O__O(self any) any { { var i__1078000056__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1078000056__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000061__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1078000056__1)); var f__3 any = lang.RT_Nth_O_I_O__O(vec__1078000061__2, lang.RT_IntCast_J__I(0), nil); var vec__1078000064__4 any = lang.RT_Nth_O_I_O__O(vec__1078000061__2, lang.RT_IntCast_J__I(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1078000064__4, lang.RT_IntCast_J__I(0), nil); var c__6 any = lang.RT_Nth_O_I_O__O(vec__1078000064__4, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; _ = ___5; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1078000057; var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_18; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_68; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_69; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp12 *lang.Var; A_arbace_classes_native_A_Init(); tmp12 = A_arbace_classes_native_A_const_40; var tmp13 any = tmp11.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(f__3), c__6); var tmp14 *lang.Var; A_arbace_classes_native_A_Init(); tmp14 = A_arbace_classes_native_A_const_70; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp16 = A_arbace_classes_native_A_const_71; var tmp17 any = tmp16.Ref(); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O_O_O__O(tmp13, tmp15, tmp17, tmp18.Ref()))); i__1078000056__1 = lang.Numbers_Unchecked_inc_J__J(i__1078000056__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000077_A { A_arbace_classes_native_fn_class_form_fn__1078000077_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000077_A{}; t.Ctor_O(p0); return t }
//line :111:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) Ctor_O(c__typed any) { t.F_typed = c__typed }
//line :111:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) Invoke_O_O_O__O(self, f__1, p__1078000076__2 any) any { var vec__1078000078__3 any = p__1078000076__2; var ___4 any = lang.RT_Nth_O_I_O__O(vec__1078000078__3, lang.RT_IntCast_J__I(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O(vec__1078000078__3, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_typed); var tmp2 *lang.Var; _ = ___4; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_40; return tmp1.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(f__1), c__5) }


func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A{}; t.Ctor_O(p0); return t }
//line :114:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :114:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) Invoke_O_O__O(self, s__1078000083__1 any) any { var tmp1 any = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_New_O_O_O(s__1078000083__1, self, t.F_rcv); var tmp2 *jrt.Class; A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_Init(); tmp2 = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) Ctor_O_O_O(c__s__1078000083, c__iter__1078000082, c__rcv any) { t.F_s__1078000083 = c__s__1078000083; t.F_iter__1078000082 = c__iter__1078000082; t.F_rcv = c__rcv }
//line :114:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) Invoke_O__O(self any) any { { var s__1078000083__1 any; var t_ any = t.F_s__1078000083; t.F_s__1078000083 = nil; s__1078000083__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1078000083__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1078000083__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1078000083__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_20; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1078000083__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1078000085__6 any; var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_21; b__1078000085__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_New_O_O_I_O(b__1078000085__6, t.F_rcv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_Init(); tmp6 = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1078000085__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000082); var tmp12 *lang.Var; A_arbace_classes_native_A_Init(); tmp12 = A_arbace_classes_native_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1078000083__3))) } else { var tmp13 *lang.Var; A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_native_A_Init(); tmp15 = A_arbace_classes_native_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1078000085__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_classes_native_A_Init(); tmp16 = A_arbace_classes_native_A_const_25; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1078000083__3); var tmp17 *lang.Var; A_arbace_classes_native_A_Init(); tmp17 = A_arbace_classes_native_A_const_26; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_native_A_Init(); tmp19 = A_arbace_classes_native_A_const_18; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_classes_native_A_Init(); tmp21 = A_arbace_classes_native_A_const_77; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_classes_native_A_Init(); tmp23 = A_arbace_classes_native_A_const_18; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_native_A_Init(); tmp25 = A_arbace_classes_native_A_const_40; var tmp26 any = tmp24.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref()), t.F_rcv); var tmp27 *lang.Var; A_arbace_classes_native_A_Init(); tmp27 = A_arbace_classes_native_A_const_40; var tmp28 any = tmp20.Invoke_O_O_O__O(tmp22, tmp26, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(f__4)); var tmp29 lang.IFn = lang.IFn_Cast(t.F_iter__1078000082); var tmp30 *lang.Var; A_arbace_classes_native_A_Init(); tmp30 = A_arbace_classes_native_A_const_29; return tmp18.Invoke_O_O__O(tmp28, tmp29.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(s__1078000083__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :114:1
func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_Init(); t := &A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :114:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) Ctor_O_O_I_O(c__b__1078000085, c__rcv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000085 = c__b__1078000085; t.F_rcv = c__rcv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) Invoke_O__O(self any) any { { var i__1078000084__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1078000084__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1078000084__1)); var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1078000085; var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_18; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_77; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_18; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_classes_native_A_Init(); tmp11 = A_arbace_classes_native_A_const_40; var tmp12 any = tmp10.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref()), t.F_rcv); var tmp13 *lang.Var; A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_40; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O_O__O(tmp8, tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(f__2))); i__1078000084__1 = lang.Numbers_Unchecked_inc_J__J(i__1078000084__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_New_O(p0 any) *A_arbace_classes_native_fn_class_form_fn__1078000093_A { A_arbace_classes_native_fn_class_form_fn__1078000093_A_Init(); t := &A_arbace_classes_native_fn_class_form_fn__1078000093_A{}; t.Ctor_O(p0); return t }
//line :116:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) Ctor_O(c__rcv any) { t.F_rcv = c__rcv }
//line :116:1
func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) Invoke_O_O_O__O(self, f__1, p__1078000092__2 any) any { var vec__1078000094__3 any = p__1078000092__2; var s__4 any = lang.RT_Nth_O_I_O__O(vec__1078000094__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1078000094__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; _ = ___5; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_40; return lang.Tuple_Create_O_O__IPersistentVector(s__4, tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref()), t.F_rcv)) }

func A_arbace_classes_native_compile_fn_A_New() *A_arbace_classes_native_compile_fn_A { A_arbace_classes_native_compile_fn_A_Init(); t := &A_arbace_classes_native_compile_fn_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_native_compile_fn_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_native_compile_fn_A) Invoke_O_O_O_O_O__O(self, ns__0, cname__1, form__2, env__3 any) any { { var host__5 any; var tmp1 *lang.Var





	A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_81; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____5 any; var tmp6 any = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_New(); var tmp7 *jrt.Class; A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_Init(); tmp7 = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_fn_class; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(env__3); host__5 = tmp2.Invoke_O_O__O(tmp4, tmp5)
//line :118:1
	var mentioned__6 any; var tmp8 *lang.Var






	A_arbace_classes_native_A_Init(); tmp8 = A_arbace_classes_native_A_const_82; mentioned__6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(form__2)
//line :118:1
	var syms__7 any; var tmp9 *lang.Var







	A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_83; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_classes_native_compile_fn_fn__1078000118_A_New_O(host__5); var tmp12 *jrt.Class; A_arbace_classes_native_compile_fn_fn__1078000118_A_Init(); tmp12 = A_arbace_classes_native_compile_fn_fn__1078000118_A_fn_class; var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 *lang.Var; A_arbace_classes_native_A_Init(); tmp14 = A_arbace_classes_native_A_const_94; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_classes_native_A_Init(); tmp16 = A_arbace_classes_native_A_const_41; syms__7 = tmp10.Invoke_O_O__O(tmp13, tmp15.Invoke_O_O__O(jrt.NN(tmp16).GetRawRoot__O(), mentioned__6))
//line :118:1
L1: for { var captured__8 any; var tmp17 *lang.Var








	A_arbace_classes_native_A_Init(); tmp17 = A_arbace_classes_native_A_const_32; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_classes_native_compile_fn_fn__1078000120_A_New_O(host__5); var tmp20 *jrt.Class; A_arbace_classes_native_compile_fn_fn__1078000120_A_Init(); tmp20 = A_arbace_classes_native_compile_fn_fn__1078000120_A_fn_class; captured__8 = tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), syms__7)
//line :118:1
	var r__9 any; var tmp21 any = A_arbace_classes_native_compile_fn_fn__1078000122_A_New_O_O_O_O_O_O(form__2, host__5, ns__0, syms__7, cname__1, captured__8); var tmp22 *jrt.Class









	A_arbace_classes_native_compile_fn_fn__1078000122_A_Init(); tmp22 = A_arbace_classes_native_compile_fn_fn__1078000122_A_fn_class; r__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O()









	var tmp23 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp23 = A_arbace_classes_native_A_const_91; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Var; A_arbace_classes_native_A_Init(); tmp25 = A_arbace_classes_native_A_const_25; if lang.Util_Equiv_O_O__Z(tmp24, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(r__9)) {
		var tmp26 *lang.Var; A_arbace_classes_native_A_Init(); tmp26 = A_arbace_classes_native_A_const_9; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_classes_native_A_Init(); tmp28 = A_arbace_classes_native_A_const_31; syms__7 = tmp27.Invoke_O_O__O(syms__7, lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(r__9)); continue L1 } else {
//line :138:1
			var new__10 any; var tmp29 *lang.Var


			A_arbace_classes_native_A_Init(); tmp29 = A_arbace_classes_native_A_const_75; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_classes_native_A_Init(); tmp31 = A_arbace_classes_native_A_const_95; var tmp32 any = tmp31; var tmp33 *lang.Var; A_arbace_classes_native_A_Init(); tmp33 = A_arbace_classes_native_A_const_31; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_classes_native_A_Init(); tmp35 = A_arbace_classes_native_A_const_25; new__10 = tmp30.Invoke_O_O_O__O(tmp32, tmp34.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(r__9)), syms__7)
//line :138:1
			var temp__1927000408__auto____11 any; var tmp36 *lang.Var



			A_arbace_classes_native_A_Init(); tmp36 = A_arbace_classes_native_A_const_92; temp__1927000408__auto____11 = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(form__2); if jrt.A2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp37 *lang.Var
				A_arbace_classes_native_A_Init(); tmp37 = A_arbace_classes_native_A_const_18; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_classes_native_A_Init(); tmp39 = A_arbace_classes_native_A_const_96; return tmp38.Invoke_O_O_O__O(tmp39, new__10, m__12) } else {
//line :142:1
					return new__10 } } } }; /*line :118:1*/panic("a2g: unreachable") }





func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_New() *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) Ctor() {}
//line :124:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) Invoke_O_O__O(self, s__1078000103__1 any) any { var tmp1 any = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_New_O_O(s__1078000103__1, self); var tmp2 *jrt.Class; A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_Init(); tmp2 = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :124:1
func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_New_O_O(p0, p1 any) *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A{}; t.Ctor_O_O(p0, p1); return t }
//line :124:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) Ctor_O_O(c__s__1078000103, c__iter__1078000102 any) { t.F_s__1078000103 = c__s__1078000103; t.F_iter__1078000102 = c__iter__1078000102 }
//line :124:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) Invoke_O__O(self any) any { { var s__1078000103__1 any; var t_ any = t.F_s__1078000103; t.F_s__1078000103 = nil; s__1078000103__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_15; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1078000103__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1078000103__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1078000103__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_20; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1078000103__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1078000105__6 any; var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_21; b__1078000105__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_I_O(b__1078000105__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_Init(); tmp6 = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_native_A_Init(); tmp9 = A_arbace_classes_native_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1078000105__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); var tmp12 *lang.Var; A_arbace_classes_native_A_Init(); tmp12 = A_arbace_classes_native_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1078000103__3))) } else { var tmp13 *lang.Var; A_arbace_classes_native_A_Init(); tmp13 = A_arbace_classes_native_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_native_A_Init(); tmp15 = A_arbace_classes_native_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1078000105__6), nil) } } else { var vec__1078000113__4 any; var tmp16 *lang.Var; A_arbace_classes_native_A_Init(); tmp16 = A_arbace_classes_native_A_const_25; vec__1078000113__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1078000103__3); var s__5 any = lang.RT_Nth_O_I_O__O(vec__1078000113__4, lang.RT_IntCast_J__I(0), nil); var lb__6 any = lang.RT_Nth_O_I_O__O(vec__1078000113__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_classes_native_A_Init(); tmp17 = A_arbace_classes_native_A_const_26; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_native_A_Init(); tmp19 = A_arbace_classes_native_A_const_93; var tmp20 any = lang.Tuple_Create_O_O__IPersistentVector(s__5, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(lb__6)); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1078000102); var tmp22 *lang.Var; A_arbace_classes_native_A_Init(); tmp22 = A_arbace_classes_native_A_const_29; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1078000103__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :124:1
func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_Init(); t := &A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :124:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Ctor_O_I_O(c__b__1078000105 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1078000105 = c__b__1078000105; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :124:1
func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Invoke_O__O(self any) any { { var i__1078000104__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1078000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1078000109__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1078000104__1)); var s__3 any = lang.RT_Nth_O_I_O__O(vec__1078000109__2, lang.RT_IntCast_J__I(0), nil); var lb__4 any = lang.RT_Nth_O_I_O__O(vec__1078000109__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1078000105; var tmp5 *lang.Var; A_arbace_classes_native_A_Init(); tmp5 = A_arbace_classes_native_A_const_93; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(s__3, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(lb__4))); i__1078000104__1 = lang.Numbers_Unchecked_inc_J__J(i__1078000104__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_classes_native_compile_fn_fn__1078000118_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000118_A { A_arbace_classes_native_compile_fn_fn__1078000118_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000118_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :126:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) Invoke_O_O__O(self, p1__1078000099_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_85; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_host, p1__1078000099_SHARP___1) }
func A_arbace_classes_native_compile_fn_fn__1078000120_A_New_O(p0 any) *A_arbace_classes_native_compile_fn_fn__1078000120_A { A_arbace_classes_native_compile_fn_fn__1078000120_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000120_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) Ctor_O(c__host any) { t.F_host = c__host }
//line :127:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) Invoke_O_O__O(self, s__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(s__1, lang.IFn_Cast(t.F_host).Invoke_O__O(s__1)) }
func A_arbace_classes_native_compile_fn_fn__1078000122_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_native_compile_fn_fn__1078000122_A { A_arbace_classes_native_compile_fn_fn__1078000122_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000122_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :128:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) Ctor_O_O_O_O_O_O(c__form, c__host, c__ns, c__syms, c__cname, c__captured any) { t.F_form = c__form; t.F_host = c__host; t.F_ns = c__ns; t.F_syms = c__syms; t.F_cname = c__cname; t.F_captured = c__captured }
//line :128:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) Invoke_O__O(self any) any { var tmp1 any; tmp20 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 *lang.Var; A_arbace_classes_native_A_Init(); tmp2 = A_arbace_classes_native_A_const_35; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_native_A_Init(); tmp4 = A_arbace_classes_native_A_const_36; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_native_A_Init(); tmp6 = A_arbace_classes_native_A_const_37; tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6.Ref(), t.F_ns)); tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp7 *lang.Var; A_arbace_classes_native_A_Init(); tmp7 = A_arbace_classes_native_A_const_14; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var t_ any = t.F_ns; t.F_ns = nil; tmp9 = t_; var tmp10 any = tmp9; var tmp11 *lang.Var; A_arbace_classes_native_A_Init(); tmp11 = A_arbace_classes_native_A_const_84; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; var t__2 any = t.F_cname; t.F_cname = nil; tmp13 = t__2; var tmp14 any = tmp13; var tmp15 any; var t__3 any = t.F_form; t.F_form = nil; tmp15 = t__3; var tmp16 any = tmp15; var tmp17 any; var t__4 any = t.F_captured; t.F_captured = nil; tmp17 = t__4; tmp1 = tmp8.Invoke_O_O__O(tmp10, lang.Tuple_Create_O__IPersistentVector(tmp12.Invoke_O_O_O__O(tmp14, tmp16, tmp17))) }
//line :129:1
		return nil }(); var tmp19 *lang.Var; A_arbace_classes_native_A_Init(); tmp19 = A_arbace_classes_native_A_const_33; lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke__O()
//line :128:1
		if tmp18 != nil { panic(tmp18) } }; return nil }(); if tmp20 != nil { if lang.ExceptionInfo_InstanceOf(tmp20) { var e__3 *lang.ExceptionInfo = lang.ExceptionInfo_Cast(tmp20); var u__4 any; var tmp21 *lang.Var





			A_arbace_classes_native_A_Init(); tmp21 = A_arbace_classes_native_A_const_55; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_New(); var tmp24 *jrt.Class; A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_Init(); tmp24 = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_fn_class; var tmp25 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp26 *lang.Var; A_arbace_classes_native_A_Init(); tmp26 = A_arbace_classes_native_A_const_88; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_classes_native_A_Init(); tmp28 = A_arbace_classes_native_A_const_89; var tmp29 any = jrt.NN(tmp28).GetRawRoot__O(); var tmp30 *lang.Var; A_arbace_classes_native_A_Init(); tmp30 = A_arbace_classes_native_A_const_90; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_New(); var tmp33 *jrt.Class; A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_Init(); tmp33 = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_fn_class; u__4 = tmp22.Invoke_O_O__O(tmp25, tmp27.Invoke_O_O__O(tmp29, tmp31.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil), e__3.Ref())))
			var tmp34 any; var and__1927000168__auto____5 any = u__4; if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp35 *lang.Var; A_arbace_classes_native_A_Init(); tmp35 = A_arbace_classes_native_A_const_85; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; var t__5 any = t.F_host; t.F_host = nil; tmp37 = t__5; and__1927000168__auto____6 = tmp36.Invoke_O_O__O(tmp37, u__4); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp38 *lang.Var; A_arbace_classes_native_A_Init(); tmp38 = A_arbace_classes_native_A_const_38; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_classes_native_A_Init(); tmp40 = A_arbace_classes_native_A_const_55; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 any = lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, u__4)); var tmp43 any; var t__6 any = t.F_syms; t.F_syms = nil; tmp43 = t__6; tmp34 = tmp39.Invoke_O__O(tmp41.Invoke_O_O__O(tmp42, tmp43)) } else { tmp34 = and__1927000168__auto____6 } } else { tmp34 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp34) { var tmp44 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp44 = A_arbace_classes_native_A_const_91; tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp44.Ref(), u__4) } else { panic(jrt.Thrown(Up_ExceptionInfo_Throwable(e__3))) } } else {
//line :128:1
				panic(tmp20) } }; return tmp1 }





func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_New() *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A { A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) Ctor() {}
//line :134:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) Invoke_O_O__O(self, p1__1078000100_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_classes_native_A_Init(); tmp1 = A_arbace_classes_native_A_const_86; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_classes_native_A_Init(); tmp3 = A_arbace_classes_native_A_const_87; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__1078000100_SHARP___1)) }
//line :134:1
func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_New() *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A { A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_Init(); t := &A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) Ctor() {}
//line :134:1
func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) Invoke_O_O__O(self, p1__1078000101_SHARP___1 any) any { return jrt.Throwable_Cast(p1__1078000101_SHARP___1).GetCause__Throwable() }



















































































type A_arbace_classes_native_A struct{ jrt.Object }

var A_arbace_classes_native_A_const_0 *lang.Var

var A_arbace_classes_native_A_const_1 *lang.Var

var A_arbace_classes_native_A_const_2 any

var A_arbace_classes_native_A_const_3 any

var A_arbace_classes_native_A_const_4 any

var A_arbace_classes_native_A_const_5 any

var A_arbace_classes_native_A_const_6 any

var A_arbace_classes_native_A_const_7 *lang.Var

var A_arbace_classes_native_A_const_8 *lang.Var

var A_arbace_classes_native_A_const_9 *lang.Var

var A_arbace_classes_native_A_const_10 any

var A_arbace_classes_native_A_const_11 *lang.Var

var A_arbace_classes_native_A_const_12 *lang.Keyword

var A_arbace_classes_native_A_const_13 *lang.Var

var A_arbace_classes_native_A_const_14 *lang.Var

var A_arbace_classes_native_A_const_15 *lang.Var

var A_arbace_classes_native_A_const_16 *lang.Keyword

var A_arbace_classes_native_A_const_17 *lang.Var

var A_arbace_classes_native_A_const_18 *lang.Var

var A_arbace_classes_native_A_const_19 *lang.Var

var A_arbace_classes_native_A_const_20 *lang.Var

var A_arbace_classes_native_A_const_21 *lang.Var

var A_arbace_classes_native_A_const_22 *lang.Var

var A_arbace_classes_native_A_const_23 any

var A_arbace_classes_native_A_const_24 *lang.Var

var A_arbace_classes_native_A_const_25 *lang.Var

var A_arbace_classes_native_A_const_26 *lang.Var

var A_arbace_classes_native_A_const_27 *lang.Var

var A_arbace_classes_native_A_const_28 *lang.Var

var A_arbace_classes_native_A_const_29 *lang.Var

var A_arbace_classes_native_A_const_30 any

var A_arbace_classes_native_A_const_31 *lang.Var

var A_arbace_classes_native_A_const_32 *lang.Var

var A_arbace_classes_native_A_const_33 *lang.Var

var A_arbace_classes_native_A_const_34 *lang.Var

var A_arbace_classes_native_A_const_35 *lang.Var

var A_arbace_classes_native_A_const_36 *lang.Var

var A_arbace_classes_native_A_const_37 *lang.Var

var A_arbace_classes_native_A_const_38 *lang.Var

var A_arbace_classes_native_A_const_39 *lang.Keyword

var A_arbace_classes_native_A_const_40 *lang.Var

var A_arbace_classes_native_A_const_41 *lang.Var

var A_arbace_classes_native_A_const_42 *lang.Var

var A_arbace_classes_native_A_const_43 *jrt.Class

var A_arbace_classes_native_A_const_44 *lang.Var

var A_arbace_classes_native_A_const_45 *lang.Var

var A_arbace_classes_native_A_const_46 *lang.Var

var A_arbace_classes_native_A_const_47 *lang.Var

var A_arbace_classes_native_A_const_48 *lang.Var

var A_arbace_classes_native_A_const_49 *lang.Var

var A_arbace_classes_native_A_const_50 *lang.Keyword

var A_arbace_classes_native_A_const_51 *lang.Keyword

var A_arbace_classes_native_A_const_52 *lang.Var

var A_arbace_classes_native_A_const_53 *lang.Var

var A_arbace_classes_native_A_const_54 *lang.Var

var A_arbace_classes_native_A_const_55 *lang.Var

var A_arbace_classes_native_A_const_56 any

var A_arbace_classes_native_A_const_57 any

var A_arbace_classes_native_A_const_58 *lang.Var

var A_arbace_classes_native_A_const_59 *lang.Keyword

var A_arbace_classes_native_A_const_60 *lang.Var

var A_arbace_classes_native_A_const_61 any

var A_arbace_classes_native_A_const_62 *lang.Var

var A_arbace_classes_native_A_const_63 *lang.Var

var A_arbace_classes_native_A_const_64 *lang.Keyword

var A_arbace_classes_native_A_const_65 *lang.Keyword

var A_arbace_classes_native_A_const_66 *lang.Keyword

var A_arbace_classes_native_A_const_67 *lang.Var

var A_arbace_classes_native_A_const_68 any

var A_arbace_classes_native_A_const_69 *lang.Var

var A_arbace_classes_native_A_const_70 *lang.Var

var A_arbace_classes_native_A_const_71 *lang.Keyword

var A_arbace_classes_native_A_const_72 *lang.Var

var A_arbace_classes_native_A_const_73 any

var A_arbace_classes_native_A_const_74 *lang.Var

var A_arbace_classes_native_A_const_75 *lang.Var

var A_arbace_classes_native_A_const_76 any

var A_arbace_classes_native_A_const_77 any

var A_arbace_classes_native_A_const_78 any

var A_arbace_classes_native_A_const_79 any

var A_arbace_classes_native_A_const_80 *lang.Var

var A_arbace_classes_native_A_const_81 *lang.Var

var A_arbace_classes_native_A_const_82 *lang.Var

var A_arbace_classes_native_A_const_83 *lang.Var

var A_arbace_classes_native_A_const_84 *lang.Var

var A_arbace_classes_native_A_const_85 *lang.Var

var A_arbace_classes_native_A_const_86 *lang.Keyword

var A_arbace_classes_native_A_const_87 *lang.Var

var A_arbace_classes_native_A_const_88 *lang.Var

var A_arbace_classes_native_A_const_89 *lang.Var

var A_arbace_classes_native_A_const_90 *lang.Var

var A_arbace_classes_native_A_const_91 *lang.Keyword

var A_arbace_classes_native_A_const_92 *lang.Var

var A_arbace_classes_native_A_const_93 *lang.Var

var A_arbace_classes_native_A_const_94 *lang.Var

var A_arbace_classes_native_A_const_95 any

var A_arbace_classes_native_A_const_96 any

var A_arbace_classes_native_A_init jrt.ClassInit

func A_arbace_classes_native_A_Init() { if !A_arbace_classes_native_A_init.Done() { A_arbace_classes_native_A_init.Run(A_arbace_classes_native_A_clinit) } }

func A_arbace_classes_native_A_clinit() { A_arbace_classes_native_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_classes_native_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_classes_native_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_native_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_classes_native_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_classes_native_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_classes_native_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_classes_native_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_classes_native_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_classes_native_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_classes_native_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_classes_native_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_classes_native_A_const_12 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_classes_native_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_classes_native_A_const_14 = lang.RT_Var_String_String__Var(Lit_10, Lit_21); A_arbace_classes_native_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_classes_native_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_23); A_arbace_classes_native_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_classes_native_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_classes_native_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_classes_native_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_classes_native_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_classes_native_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_classes_native_A_const_23 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_30).Ref(); A_arbace_classes_native_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_classes_native_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_classes_native_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_classes_native_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_classes_native_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_classes_native_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_classes_native_A_const_30 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(); A_arbace_classes_native_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_classes_native_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_classes_native_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_classes_native_A_const_34 = lang.RT_Var_String_String__Var(Lit_8, Lit_41); A_arbace_classes_native_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_classes_native_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_classes_native_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_classes_native_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_classes_native_A_const_39 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_classes_native_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_classes_native_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_classes_native_A_const_42 = lang.RT_Var_String_String__Var(Lit_15, Lit_48); A_arbace_classes_native_A_const_43 = lang.RT_ClassForNameNonLoading_String__Class(Lit_49); A_arbace_classes_native_A_const_44 = lang.RT_Var_String_String__Var(Lit_3, Lit_50); A_arbace_classes_native_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_classes_native_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_classes_native_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_classes_native_A_const_48 = lang.RT_Var_String_String__Var(Lit_8, Lit_54); A_arbace_classes_native_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_classes_native_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_classes_native_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_classes_native_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_classes_native_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_classes_native_A_const_54 = lang.RT_Var_String_String__Var(Lit_15, Lit_59); A_arbace_classes_native_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_classes_native_A_const_56 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(); A_arbace_classes_native_A_const_57 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(); A_arbace_classes_native_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_classes_native_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_classes_native_A_const_60 = lang.RT_Var_String_String__Var(Lit_15, Lit_65); A_arbace_classes_native_A_const_61 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_native_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_classes_native_A_const_63 = lang.RT_Var_String_String__Var(Lit_8, Lit_67); A_arbace_classes_native_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_classes_native_A_const_65 = lang.RT_Keyword_String_String__Keyword(nil, Lit_69); A_arbace_classes_native_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_70); A_arbace_classes_native_A_const_67 = lang.RT_Var_String_String__Var(Lit_8, Lit_71); A_arbace_classes_native_A_const_68 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(); A_arbace_classes_native_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_classes_native_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_classes_native_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_classes_native_A_const_72 = lang.RT_Var_String_String__Var(Lit_8, Lit_76); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_78).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_classes_native_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp6, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref())); A_arbace_classes_native_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_classes_native_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_classes_native_A_const_76 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(); A_arbace_classes_native_A_const_77 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; A_arbace_classes_native_A_const_78 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp11.Ref())); A_arbace_classes_native_A_const_79 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(); A_arbace_classes_native_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_classes_native_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_classes_native_A_const_82 = lang.RT_Var_String_String__Var(Lit_8, Lit_88); A_arbace_classes_native_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_classes_native_A_const_84 = lang.RT_Var_String_String__Var(Lit_15, Lit_90); A_arbace_classes_native_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_classes_native_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_92); A_arbace_classes_native_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_93); A_arbace_classes_native_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_classes_native_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_classes_native_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_classes_native_A_const_91 = lang.RT_Keyword_String_String__Keyword(Lit_15, Lit_97); A_arbace_classes_native_A_const_92 = lang.RT_Var_String_String__Var(Lit_8, Lit_98); A_arbace_classes_native_A_const_93 = lang.RT_Var_String_String__Var(Lit_15, Lit_99); A_arbace_classes_native_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_classes_native_A_const_95 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_classes_native_A_const_96 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_63).Ref() }

func A_arbace_classes_native_A_New() *A_arbace_classes_native_A { A_arbace_classes_native_A_Init(); t := &A_arbace_classes_native_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_A) Ctor() {}

func (t *A_arbace_classes_native_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_A_class }

func (t *A_arbace_classes_native_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_A); return ok }

func A_arbace_classes_native_A_Cast(x any) *A_arbace_classes_native_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_A_class)) }; return v }



type A_arbace_classes_native_compile_deftype_A struct{ jrt.Object }

func (t *A_arbace_classes_native_compile_deftype_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_native_compile_deftype_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_deftype_A_init jrt.ClassInit

func A_arbace_classes_native_compile_deftype_A_Init() { if !A_arbace_classes_native_compile_deftype_A_init.Done() { A_arbace_classes_native_compile_deftype_A_init.Run(A_arbace_classes_native_compile_deftype_A_clinit) } }

func A_arbace_classes_native_compile_deftype_A_clinit() { A_arbace_classes_native_compile_deftype_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_deftype_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_deftype_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_deftype_A_class }

func (t *A_arbace_classes_native_compile_deftype_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_deftype_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_deftype_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_deftype_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_deftype_A); return ok }

func A_arbace_classes_native_compile_deftype_A_Cast(x any) *A_arbace_classes_native_compile_deftype_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_deftype_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_deftype_A_class)) }; return v }



type A_arbace_classes_native_compile_deftype_fn__1078000029_A struct{ jrt.Object; F_form, F_ns any }

func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_compile_deftype_fn__1078000029_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_deftype_fn__1078000029_A_init jrt.ClassInit

func A_arbace_classes_native_compile_deftype_fn__1078000029_A_Init() { if !A_arbace_classes_native_compile_deftype_fn__1078000029_A_init.Done() { A_arbace_classes_native_compile_deftype_fn__1078000029_A_init.Run(A_arbace_classes_native_compile_deftype_fn__1078000029_A_clinit) } }

func A_arbace_classes_native_compile_deftype_fn__1078000029_A_clinit() { A_arbace_classes_native_compile_deftype_fn__1078000029_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_deftype_fn__1078000029_A_class }

func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_deftype_fn__1078000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_deftype_fn__1078000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_deftype_fn__1078000029_A); return ok }

func A_arbace_classes_native_compile_deftype_fn__1078000029_A_Cast(x any) *A_arbace_classes_native_compile_deftype_fn__1078000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_deftype_fn__1078000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_deftype_fn__1078000029_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_A struct{ jrt.Object }

func (t *A_arbace_classes_native_compile_fn_A) Is_Compiler_AOTF4() {}

var A_arbace_classes_native_compile_fn_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_A_Init() { if !A_arbace_classes_native_compile_fn_A_init.Done() { A_arbace_classes_native_compile_fn_A_init.Run(A_arbace_classes_native_compile_fn_A_clinit) } }

func A_arbace_classes_native_compile_fn_A_clinit() { A_arbace_classes_native_compile_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_A_class }

func (t *A_arbace_classes_native_compile_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_A); return ok }

func A_arbace_classes_native_compile_fn_A_Cast(x any) *A_arbace_classes_native_compile_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_fn__1078000118_A struct{ jrt.Object; F_host any }

func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_compile_fn_fn__1078000118_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000118_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_fn__1078000118_A_Init() { if !A_arbace_classes_native_compile_fn_fn__1078000118_A_init.Done() { A_arbace_classes_native_compile_fn_fn__1078000118_A_init.Run(A_arbace_classes_native_compile_fn_fn__1078000118_A_clinit) } }

func A_arbace_classes_native_compile_fn_fn__1078000118_A_clinit() { A_arbace_classes_native_compile_fn_fn__1078000118_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_fn__1078000118_A_class }

func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000118_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_fn__1078000118_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000118_A); return ok }

func A_arbace_classes_native_compile_fn_fn__1078000118_A_Cast(x any) *A_arbace_classes_native_compile_fn_fn__1078000118_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000118_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_fn__1078000118_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_fn__1078000120_A struct{ jrt.Object; F_host any }

func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_compile_fn_fn__1078000120_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000120_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_fn__1078000120_A_Init() { if !A_arbace_classes_native_compile_fn_fn__1078000120_A_init.Done() { A_arbace_classes_native_compile_fn_fn__1078000120_A_init.Run(A_arbace_classes_native_compile_fn_fn__1078000120_A_clinit) } }

func A_arbace_classes_native_compile_fn_fn__1078000120_A_clinit() { A_arbace_classes_native_compile_fn_fn__1078000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_fn__1078000120_A_class }

func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_fn__1078000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000120_A); return ok }

func A_arbace_classes_native_compile_fn_fn__1078000120_A_Cast(x any) *A_arbace_classes_native_compile_fn_fn__1078000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_fn__1078000120_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_fn__1078000122_A struct{ jrt.Object; F_form, F_host, F_ns, F_syms, F_cname, F_captured any }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_compile_fn_fn__1078000122_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000122_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_fn__1078000122_A_Init() { if !A_arbace_classes_native_compile_fn_fn__1078000122_A_init.Done() { A_arbace_classes_native_compile_fn_fn__1078000122_A_init.Run(A_arbace_classes_native_compile_fn_fn__1078000122_A_clinit) } }

func A_arbace_classes_native_compile_fn_fn__1078000122_A_clinit() { A_arbace_classes_native_compile_fn_fn__1078000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_fn__1078000122_A_class }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_fn__1078000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000122_A); return ok }

func A_arbace_classes_native_compile_fn_fn__1078000122_A_Cast(x any) *A_arbace_classes_native_compile_fn_fn__1078000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_fn__1078000122_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A struct{ jrt.Object }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_Init() { if !A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_init.Done() { A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_init.Run(A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_clinit) } }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_clinit() { A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_class }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A); return ok }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_Cast(x any) *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A struct{ jrt.Object }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_Init() { if !A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_init.Done() { A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_init.Run(A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_clinit) } }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_clinit() { A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_class }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A); return ok }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_Cast(x any) *A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A struct{ jrt.Object }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_Init() { if !A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_init.Done() { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_init.Run(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_clinit) } }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_clinit() { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A); return ok }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_Cast(x any) *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A struct{ jrt.Object; F_s__1078000103, F_iter__1078000102 any }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_Init() { if !A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_init.Done() { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_init.Run(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_clinit) } }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_clinit() { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A); return ok }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_Cast(x any) *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class)) }; return v }



type A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A struct{ jrt.Object; F_b__1078000105 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_init jrt.ClassInit

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_Init() { if !A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_init.Done() { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_init.Run(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_clinit) } }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_clinit() { A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A); return ok }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_Cast(x any) *A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class)) }; return v }



type A_arbace_classes_native_compile_top_A struct{ jrt.Object }

func (t *A_arbace_classes_native_compile_top_A) Is_Compiler_AOTF4() {}

var A_arbace_classes_native_compile_top_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_top_A_init jrt.ClassInit

func A_arbace_classes_native_compile_top_A_Init() { if !A_arbace_classes_native_compile_top_A_init.Done() { A_arbace_classes_native_compile_top_A_init.Run(A_arbace_classes_native_compile_top_A_clinit) } }

func A_arbace_classes_native_compile_top_A_clinit() { A_arbace_classes_native_compile_top_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_top_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_top_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_top_A_class }

func (t *A_arbace_classes_native_compile_top_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_top_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_top_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_top_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_top_A); return ok }

func A_arbace_classes_native_compile_top_A_Cast(x any) *A_arbace_classes_native_compile_top_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_top_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_top_A_class)) }; return v }



type A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A struct{ jrt.Object }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_init jrt.ClassInit

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_Init() { if !A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_init.Done() { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_init.Run(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_clinit) } }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_clinit() { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A); return ok }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_Cast(x any) *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class)) }; return v }



type A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A struct{ jrt.Object; F_s__1078000013, F_iter__1078000012 any }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_init jrt.ClassInit

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_Init() { if !A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_init.Done() { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_init.Run(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_clinit) } }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_clinit() { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A); return ok }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_Cast(x any) *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class)) }; return v }



type A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A struct{ jrt.Object; F_b__1078000015 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_fn_class *jrt.Class

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_init jrt.ClassInit

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_Init() { if !A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_init.Done() { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_init.Run(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_clinit) } }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_clinit() { A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_class }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A); return ok }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_Cast(x any) *A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_class)) }; return v }



type A_arbace_classes_native_eval1078000004_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000004_A_New() *A_arbace_classes_native_eval1078000004_A { t := &A_arbace_classes_native_eval1078000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000004_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000004_A_class }

func (t *A_arbace_classes_native_eval1078000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000004_A); return ok }

func A_arbace_classes_native_eval1078000004_A_Cast(x any) *A_arbace_classes_native_eval1078000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000004_A_class)) }; return v }



type A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A struct{ jrt.Object }

func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class *jrt.Class

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_init jrt.ClassInit

func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_Init() { if !A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_init.Done() { A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_init.Run(A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_clinit) } }

func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_clinit() { A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class }

func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A); return ok }

func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_Cast(x any) *A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class)) }; return v }



type A_arbace_classes_native_eval1078000008_A struct{ jrt.Object }

func A_arbace_classes_native_eval1078000008_A_New() *A_arbace_classes_native_eval1078000008_A { t := &A_arbace_classes_native_eval1078000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_native_eval1078000008_A) Ctor() {}

func (t *A_arbace_classes_native_eval1078000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000008_A_class }

func (t *A_arbace_classes_native_eval1078000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000008_A); return ok }

func A_arbace_classes_native_eval1078000008_A_Cast(x any) *A_arbace_classes_native_eval1078000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000008_A_class)) }; return v }



type A_arbace_classes_native_eval1078000008_fn__1078000009_A struct{ jrt.Object }

func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class *jrt.Class

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_init jrt.ClassInit

func A_arbace_classes_native_eval1078000008_fn__1078000009_A_Init() { if !A_arbace_classes_native_eval1078000008_fn__1078000009_A_init.Done() { A_arbace_classes_native_eval1078000008_fn__1078000009_A_init.Run(A_arbace_classes_native_eval1078000008_fn__1078000009_A_clinit) } }

func A_arbace_classes_native_eval1078000008_fn__1078000009_A_clinit() { A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_eval1078000008_fn__1078000009_A_class }

func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_eval1078000008_fn__1078000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_eval1078000008_fn__1078000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_eval1078000008_fn__1078000009_A); return ok }

func A_arbace_classes_native_eval1078000008_fn__1078000009_A_Cast(x any) *A_arbace_classes_native_eval1078000008_fn__1078000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_eval1078000008_fn__1078000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_eval1078000008_fn__1078000009_A_class)) }; return v }



type A_arbace_classes_native_field_names_A struct{ jrt.Object }

func (t *A_arbace_classes_native_field_names_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_field_names_A_fn_class *jrt.Class

var A_arbace_classes_native_field_names_A_init jrt.ClassInit

func A_arbace_classes_native_field_names_A_Init() { if !A_arbace_classes_native_field_names_A_init.Done() { A_arbace_classes_native_field_names_A_init.Run(A_arbace_classes_native_field_names_A_clinit) } }

func A_arbace_classes_native_field_names_A_clinit() { A_arbace_classes_native_field_names_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_field_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_field_names_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_field_names_A_class }

func (t *A_arbace_classes_native_field_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_field_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_field_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_field_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_field_names_A); return ok }

func A_arbace_classes_native_field_names_A_Cast(x any) *A_arbace_classes_native_field_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_field_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_field_names_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_A struct{ jrt.Object }

func (t *A_arbace_classes_native_fn_class_form_A) Is_Compiler_AOTF3() {}

var A_arbace_classes_native_fn_class_form_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_A_Init() { if !A_arbace_classes_native_fn_class_form_A_init.Done() { A_arbace_classes_native_fn_class_form_A_init.Run(A_arbace_classes_native_fn_class_form_A_clinit) } }

func A_arbace_classes_native_fn_class_form_A_clinit() { A_arbace_classes_native_fn_class_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_A_class }

func (t *A_arbace_classes_native_fn_class_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_A); return ok }

func A_arbace_classes_native_fn_class_form_A_Cast(x any) *A_arbace_classes_native_fn_class_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_fn__1078000077_A struct{ jrt.Object; F_typed any }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_native_fn_class_form_fn__1078000077_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_fn__1078000077_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_Init() { if !A_arbace_classes_native_fn_class_form_fn__1078000077_A_init.Done() { A_arbace_classes_native_fn_class_form_fn__1078000077_A_init.Run(A_arbace_classes_native_fn_class_form_fn__1078000077_A_clinit) } }

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_clinit() { A_arbace_classes_native_fn_class_form_fn__1078000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_fn__1078000077_A_class }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_fn__1078000077_A); return ok }

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_Cast(x any) *A_arbace_classes_native_fn_class_form_fn__1078000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_fn__1078000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_fn__1078000077_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_fn__1078000093_A struct{ jrt.Object; F_rcv any }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_native_fn_class_form_fn__1078000093_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_fn__1078000093_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_Init() { if !A_arbace_classes_native_fn_class_form_fn__1078000093_A_init.Done() { A_arbace_classes_native_fn_class_form_fn__1078000093_A_init.Run(A_arbace_classes_native_fn_class_form_fn__1078000093_A_clinit) } }

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_clinit() { A_arbace_classes_native_fn_class_form_fn__1078000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_fn__1078000093_A_class }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_fn__1078000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_fn__1078000093_A); return ok }

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_Cast(x any) *A_arbace_classes_native_fn_class_form_fn__1078000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_fn__1078000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_fn__1078000093_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A struct{ jrt.Object; F_typed any }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_Init() { if !A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_init.Done() { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_init.Run(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_clinit) } }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_clinit() { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A); return ok }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_Cast(x any) *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A struct{ jrt.Object; F_s__1078000055, F_iter__1078000054, F_typed any }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_Init() { if !A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_init.Done() { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_init.Run(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_clinit) } }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_clinit() { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A); return ok }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_Cast(x any) *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A struct{ jrt.Object; F_typed any; F_size__1927001038__auto__ int32; F_b__1078000057, F_c__1927001037__auto__ any }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_Init() { if !A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_init.Done() { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_init.Run(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_clinit) } }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_clinit() { A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_class }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A); return ok }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_Cast(x any) *A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A struct{ jrt.Object; F_rcv any }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_Init() { if !A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_init.Done() { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_init.Run(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_clinit) } }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_clinit() { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A); return ok }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_Cast(x any) *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A struct{ jrt.Object; F_s__1078000083, F_iter__1078000082, F_rcv any }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_Init() { if !A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_init.Done() { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_init.Run(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_clinit) } }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_clinit() { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A); return ok }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_Cast(x any) *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A struct{ jrt.Object; F_b__1078000085, F_rcv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_Init() { if !A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_init.Done() { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_init.Run(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_clinit) } }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_clinit() { A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_class }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A); return ok }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_Cast(x any) *A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_class)) }; return v }



type A_arbace_classes_native_fn_class_form_typed__1078000052_A struct{ jrt.Object }

func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_native_fn_class_form_typed__1078000052_A_fn_class *jrt.Class

var A_arbace_classes_native_fn_class_form_typed__1078000052_A_init jrt.ClassInit

func A_arbace_classes_native_fn_class_form_typed__1078000052_A_Init() { if !A_arbace_classes_native_fn_class_form_typed__1078000052_A_init.Done() { A_arbace_classes_native_fn_class_form_typed__1078000052_A_init.Run(A_arbace_classes_native_fn_class_form_typed__1078000052_A_clinit) } }

func A_arbace_classes_native_fn_class_form_typed__1078000052_A_clinit() { A_arbace_classes_native_fn_class_form_typed__1078000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_fn_class_form_typed__1078000052_A_class }

func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_fn_class_form_typed__1078000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_fn_class_form_typed__1078000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_fn_class_form_typed__1078000052_A); return ok }

func A_arbace_classes_native_fn_class_form_typed__1078000052_A_Cast(x any) *A_arbace_classes_native_fn_class_form_typed__1078000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_fn_class_form_typed__1078000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_fn_class_form_typed__1078000052_A_class)) }; return v }



type A_arbace_classes_native_local_class_A struct{ jrt.Object }

func (t *A_arbace_classes_native_local_class_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_local_class_A_fn_class *jrt.Class

var A_arbace_classes_native_local_class_A_init jrt.ClassInit

func A_arbace_classes_native_local_class_A_Init() { if !A_arbace_classes_native_local_class_A_init.Done() { A_arbace_classes_native_local_class_A_init.Run(A_arbace_classes_native_local_class_A_clinit) } }

func A_arbace_classes_native_local_class_A_clinit() { A_arbace_classes_native_local_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_local_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_local_class_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_local_class_A_class }

func (t *A_arbace_classes_native_local_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_local_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_local_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_local_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_local_class_A); return ok }

func A_arbace_classes_native_local_class_A_Cast(x any) *A_arbace_classes_native_local_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_local_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_local_class_A_class)) }; return v }



type A_arbace_classes_native_local_class_fn__1078000034_A struct{ jrt.Object; F_lb any }

func (t *A_arbace_classes_native_local_class_fn__1078000034_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_local_class_fn__1078000034_A_fn_class *jrt.Class

var A_arbace_classes_native_local_class_fn__1078000034_A_init jrt.ClassInit

func A_arbace_classes_native_local_class_fn__1078000034_A_Init() { if !A_arbace_classes_native_local_class_fn__1078000034_A_init.Done() { A_arbace_classes_native_local_class_fn__1078000034_A_init.Run(A_arbace_classes_native_local_class_fn__1078000034_A_clinit) } }

func A_arbace_classes_native_local_class_fn__1078000034_A_clinit() { A_arbace_classes_native_local_class_fn__1078000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_local_class_fn__1078000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_local_class_fn__1078000034_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_local_class_fn__1078000034_A_class }

func (t *A_arbace_classes_native_local_class_fn__1078000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_local_class_fn__1078000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_local_class_fn__1078000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_local_class_fn__1078000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_local_class_fn__1078000034_A); return ok }

func A_arbace_classes_native_local_class_fn__1078000034_A_Cast(x any) *A_arbace_classes_native_local_class_fn__1078000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_local_class_fn__1078000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_local_class_fn__1078000034_A_class)) }; return v }



type A_arbace_classes_native_local_class_fn__1078000036_A struct{ jrt.Object; F_lb any }

func (t *A_arbace_classes_native_local_class_fn__1078000036_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_native_local_class_fn__1078000036_A_fn_class *jrt.Class

var A_arbace_classes_native_local_class_fn__1078000036_A_init jrt.ClassInit

func A_arbace_classes_native_local_class_fn__1078000036_A_Init() { if !A_arbace_classes_native_local_class_fn__1078000036_A_init.Done() { A_arbace_classes_native_local_class_fn__1078000036_A_init.Run(A_arbace_classes_native_local_class_fn__1078000036_A_clinit) } }

func A_arbace_classes_native_local_class_fn__1078000036_A_clinit() { A_arbace_classes_native_local_class_fn__1078000036_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_local_class_fn__1078000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_local_class_fn__1078000036_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_local_class_fn__1078000036_A_class }

func (t *A_arbace_classes_native_local_class_fn__1078000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_local_class_fn__1078000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_local_class_fn__1078000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_local_class_fn__1078000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_local_class_fn__1078000036_A); return ok }

func A_arbace_classes_native_local_class_fn__1078000036_A_Cast(x any) *A_arbace_classes_native_local_class_fn__1078000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_local_class_fn__1078000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_local_class_fn__1078000036_A_class)) }; return v }



type A_arbace_classes_native_public_class_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_native_public_class_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_public_class_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_native_public_class_QMARK__A_init jrt.ClassInit

func A_arbace_classes_native_public_class_QMARK__A_Init() { if !A_arbace_classes_native_public_class_QMARK__A_init.Done() { A_arbace_classes_native_public_class_QMARK__A_init.Run(A_arbace_classes_native_public_class_QMARK__A_clinit) } }

func A_arbace_classes_native_public_class_QMARK__A_clinit() { A_arbace_classes_native_public_class_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_public_class_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_public_class_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_public_class_QMARK__A_class }

func (t *A_arbace_classes_native_public_class_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_public_class_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_public_class_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_public_class_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_public_class_QMARK__A); return ok }

func A_arbace_classes_native_public_class_QMARK__A_Cast(x any) *A_arbace_classes_native_public_class_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_public_class_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_public_class_QMARK__A_class)) }; return v }



type A_arbace_classes_native_type_form_A struct{ jrt.Object }

func (t *A_arbace_classes_native_type_form_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_native_type_form_A_fn_class *jrt.Class

var A_arbace_classes_native_type_form_A_init jrt.ClassInit

func A_arbace_classes_native_type_form_A_Init() { if !A_arbace_classes_native_type_form_A_init.Done() { A_arbace_classes_native_type_form_A_init.Run(A_arbace_classes_native_type_form_A_clinit) } }

func A_arbace_classes_native_type_form_A_clinit() { A_arbace_classes_native_type_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_native_type_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_native_type_form_A) GetClass__Class() *jrt.Class { return A_arbace_classes_native_type_form_A_class }

func (t *A_arbace_classes_native_type_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_native_type_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_native_type_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_native_type_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_native_type_form_A); return ok }

func A_arbace_classes_native_type_form_A_Cast(x any) *A_arbace_classes_native_type_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_native_type_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_native_type_form_A_class)) }; return v }
