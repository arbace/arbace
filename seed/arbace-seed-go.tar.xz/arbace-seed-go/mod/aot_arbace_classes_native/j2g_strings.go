//line j2g_strings.ae:1
package aot_arbace_classes_native

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn18,arbace.classes.envyn3,envyn20,arbace.classes.loweryn5,loweryn21,arbace.classes.interpyn8,compileryn11,arbace.corekn3,dockn8,siblingskn2,nskn7,importskn5,formskn5,nameskn3,topyn2,doys11,arbace.core7,import*kn4,elsekn4,namekn7,aritiesyn18,arbace.lang.RestFnyn21,arbace.lang.AFunctionkn3,tagkn6,publickn5,finalkn10,clojure-fnkn10,reflectionkn7,clojurekn7,packagekn7,extendskn10,implementsyn5,fieldyn11,constructoryn6,super.yn4,set!kn10,unresolvedks21,arbace.classes.native5,retryyn3,newys11,arbace.core9,with-metav11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,v11,arbace.core5,referR9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn21,arbace.classes.nativem2,R10,s1467,The boundary between arbace.lang.Compiler and the Java forms compiler (SPEC §9.5).\n\n  arbace.lang.Compiler knows the Java forms' special forms (class*, label*, switch*, ...) but\n  does not compile them itself: there is one implementation of the Java forms, this library.\n  The compiler loads this namespace on first use and calls the functions below:\n\n  - `compile-top`, for (class* :top form) and (class* :tops forms), the expansions of\n    `defclass` and `defclasses`: compiles and defines the classes, and returns the form the\n    compiler analyzes in place of the Java form (imports and the class or classes).\n  - `compile-fn`, for a fn* whose code uses the Java forms (a special form of theirs in it, or\n    a form whose new meaning only they know): the compiler hands the whole fn over, at the\n    innermost fn* that is not one of its own wrappers (`(fn* ^:once [] ...)`); this compiles\n    it into a fn class, a subclass of arbace.lang.AFunction or RestFn named as the compiler\n    names its fn classes, whose code is compiled with Clojure's meaning (SPEC §5.13), and\n    returns the form the compiler analyzes in its place: (new C captured-local...).\n    The locals of the compiler's environment that the fn uses become the class's fields.\n  - `compile-deftype`, for a deftype* one of whose method bodies uses the Java forms: compiles\n    and defines the deftype class, with the shape arbace.lang.Compiler gives it, and returns\n    nil, the value of deftype*.v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR11,v21,arbace.classes.interp17,compile-and-load!v21,arbace.classes.native8,compiledv11,arbace.core5,swap!R12,v11,arbace.core7,ns-nameR13,v11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core3,notv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core10,ns-importsR14,v11,arbace.core3,vecR15,v11,arbace.core4,mapvR16,v21,arbace.classes.native17,compile-and-load!v11,arbace.core6,concatv11,arbace.core4,listR17,R18,v11,arbace.core6,secondv20,arbace.classes.lower18,deftype-class-formv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core4,*ns*R19,v11,arbace.core6,symbolv11,arbace.core3,strv21,arbace.classes.native13,public-class?v13,arbace.string9,includes?C16,java.lang.Objectv11,arbace.core5,mungev11,arbace.core4,namev20,arbace.classes.lower8,fn-partsR20,R21,v11,arbace.core4,subsl0,v11,arbace.core6,gensymv21,arbace.classes.native11,field-namesv11,arbace.core3,mapv11,arbace.core4,somev20,arbace.classes.lower9,variadic?R22,R23,v11,arbace.core9,with-metaR24,v21,arbace.classes.native9,type-formm8,R25,TR26,TR27,TR28,R29,R30,R31,R32,v20,arbace.classes.lower15,prim-interfacesR33,v11,arbace.core9,vary-metav11,arbace.core5,assocR26,v11,arbace.core6,vectorv11,arbace.core5,list*R34,m2,R25,TR35,R36,v20,arbace.classes.lower10,fn-methodsv11,arbace.core6,mapcatv21,arbace.classes.native11,local-classv20,arbace.classes.lower10,symbols-inv11,arbace.core7,filtervv11,arbace.core9,contains?v11,arbace.core7,sort-byv21,arbace.classes.native13,fn-class-formR37,v11,arbace.core7,ex-datav11,arbace.core10,take-whilev11,arbace.core5,some?v11,arbace.core7,iterateR38,R39,v20,arbace.classes.lower7,fn-metaR40,")

var Lit_1 *jrt.String = jrt.Intern("arbace.classes.native$compile_and_load_BANG_$iter__1078000015__1078000019")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.native$compile_and_load_BANG_$iter__1078000015__1078000019$fn__1078000020")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.native$compile_and_load_BANG_$iter__1078000015__1078000019$fn__1078000020$fn__1078000021")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.native$compile_deftype$fn__1078000049")

var Lit_5 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000122__1078000126")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000138")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000140")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000142")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000142$fn__1078000143")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000142$fn__1078000145")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000122__1078000126$fn__1078000127")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000122__1078000126$fn__1078000127$fn__1078000128")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000032__1078000036")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000032__1078000036$fn__1078000037")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000032__1078000036$fn__1078000037$fn__1078000038")

var Lit_16 *jrt.String = jrt.Intern("__")

var Lit_17 *jrt.String = jrt.Intern(".")

var Lit_18 *jrt.String = jrt.Intern("")

var Lit_19 *jrt.String = jrt.Intern("fn__this")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$typed__1078000072")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000074__1078000078")

var Lit_22 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$fn__1078000097")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000102__1078000106")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$fn__1078000113")

var Lit_25 *jrt.String = jrt.Intern(".-")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000074__1078000078$fn__1078000079")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000074__1078000078$fn__1078000079$fn__1078000080")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000102__1078000106$fn__1078000107")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000102__1078000106$fn__1078000107$fn__1078000108")

var Lit_30 *jrt.String = jrt.Intern("arbace.classes.native$local_class$fn__1078000054")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.native$local_class$fn__1078000056")

var Lit_32 *jrt.String = jrt.Intern("compile__stub")

var Lit_33 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn2,nsyn5,formsyn1,&kn4,keysyn8,siblingsyn4,kindyn4,formkn3,tagyn5,Classyn2,lbyn4,symsyn5,cnameyn8,capturedyn3,envv11,arbace.core5,in-nsMyn21,arbace.classes.nativem2,R0,s1467,The boundary between arbace.lang.Compiler and the Java forms compiler (SPEC §9.5).\n\n  arbace.lang.Compiler knows the Java forms' special forms (class*, label*, switch*, ...) but\n  does not compile them itself: there is one implementation of the Java forms, this library.\n  The compiler loads this namespace on first use and calls the functions below:\n\n  - `compile-top`, for (class* :top form) and (class* :tops forms), the expansions of\n    `defclass` and `defclasses`: compiles and defines the classes, and returns the form the\n    compiler analyzes in place of the Java form (imports and the class or classes).\n  - `compile-fn`, for a fn* whose code uses the Java forms (a special form of theirs in it, or\n    a form whose new meaning only they know): the compiler hands the whole fn over, at the\n    innermost fn* that is not one of its own wrappers (`(fn* ^:once [] ...)`); this compiles\n    it into a fn class, a subclass of arbace.lang.AFunction or RestFn named as the compiler\n    names its fn classes, whose code is compiled with Clojure's meaning (SPEC §5.13), and\n    returns the form the compiler analyzes in its place: (new C captured-local...).\n    The locals of the compiler's environment that the fn uses become the class's fields.\n  - `compile-deftype`, for a deftype* one of whose method bodies uses the Java forms: compiles\n    and defines the deftype class, with the shape arbace.lang.Compiler gives it, and returns\n    nil, the value of deftype*.m2,R0,s1467,The boundary between arbace.lang.Compiler and the Java forms compiler (SPEC §9.5).\n\n  arbace.lang.Compiler knows the Java forms' special forms (class*, label*, switch*, ...) but\n  does not compile them itself: there is one implementation of the Java forms, this library.\n  The compiler loads this namespace on first use and calls the functions below:\n\n  - `compile-top`, for (class* :top form) and (class* :tops forms), the expansions of\n    `defclass` and `defclasses`: compiles and defines the classes, and returns the form the\n    compiler analyzes in place of the Java form (imports and the class or classes).\n  - `compile-fn`, for a fn* whose code uses the Java forms (a special form of theirs in it, or\n    a form whose new meaning only they know): the compiler hands the whole fn over, at the\n    innermost fn* that is not one of its own wrappers (`(fn* ^:once [] ...)`); this compiles\n    it into a fn class, a subclass of arbace.lang.AFunction or RestFn named as the compiler\n    names its fn classes, whose code is compiled with Clojure's meaning (SPEC §5.13), and\n    returns the form the compiler analyzes in its place: (new C captured-local...).\n    The locals of the compiler's environment that the fn uses become the class's fields.\n  - `compile-deftype`, for a deftype* one of whose method bodies uses the Java forms: compiles\n    and defines the deftype class, with the shape arbace.lang.Compiler gives it, and returns\n    nil, the value of deftype*.R1,v21,arbace.classes.native8,compiledv11,arbace.core4,atomm8,R2,i26,R3,i1,R4,s24,arbace/classes/native.aeR0,s663,While the program records the units of the namespaces it prepares to compile them\n  (ARBACE_COMPILE, Compiler$AST; the back end arbace.c2j), the Java forms compiled here, in\n  order: {:ns the namespace's name, :imports its class imports then (symbol -> binary name),\n  :forms the Java forms (each the rest of a defclass form), :names the top-level classes'\n  binary names}. The back end puts them in the compiled tree, so that a deftype, a fn (a reify\n  in it) or a defclass using the Java forms is a class of the compiled program, as the\n  namespace's other classes are (Futamura F2.6, doc/FUTAMURA-SURVEY.md \"F3 and the back end's\n  limits as built\"). Else nil.v21,arbace.classes.native17,compile-and-load!m12,R5,TR6,L1,V4,R7,R8,R9,m2,R10,V1,R11,R0,s61,compiler/compile-and-load!, its classes recorded in compiled.R2,i37,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native11,compile-topm10,R6,L1,V4,R7,R12,R8,R11,R0,s410,(class* :top form) or (class* :tops forms), each form the rest of a defclass form, in\n  namespace ns: compiles the classes as one compilation, with `siblings` (the Java forms of\n  the enclosing top-level do, SPEC §9.2) entered as declarations, and defines them (and writes\n  them under *compile-files*). Returns the form evaluating to the class (:top) or a vector of\n  the classes (:tops) after importing them.R2,i52,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native15,compile-deftypem10,R6,L1,V2,R7,R13,R0,s266,Compiles (deftype* tagname classname [fields] :implements [interfaces] ...) in namespace ns\n  into the deftype class (arbace.classes.lower/deftype-class-form) and defines it (writing it\n  under *compile-files*). Returns nil, the form to analyze in place of deftype*.R2,i68,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native13,public-class?m10,R5,TR6,L1,V1,Myn1,cm2,R14,R15,R2,i80,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native9,type-formm12,R5,TR6,L1,V1,Myn1,cm2,R14,R15,R0,s81,The type form of class c (SPEC §4.3): long, java.lang.String, java.lang.String/2.R2,i86,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native11,local-classm12,R5,TR6,L1,V1,R16,R0,s172,The class of a local binding of the compiler, as precise as a field of a class compiled\n  elsewhere can have it: its primitive type, its tag's class if public, else Object.R2,i94,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native11,field-namesm12,R5,TR6,L1,V1,R17,R0,s43,Unique field names for the captured locals.R2,i108,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native13,fn-class-formm10,R6,L1,V3,R18,R13,R19,R0,s160,The Java form (rest of a defclass form) of the fn class `cname` (dotted binary name) for\n  fn* form `form`, capturing the locals `captured` ([[sym Class] ...]).R2,i118,R3,i1,R4,s24,arbace/classes/native.aev21,arbace.classes.native10,compile-fnm10,R6,L1,V4,R7,R18,R13,R20,R0,s323,Compiles fn* form `form` in namespace ns into the fn class `cname` (the compiler's name for\n  it) and defines it (writing it under *compile-files*). `env` is the compiler's local\n  environment (symbol -> LocalBinding). Returns the form to analyze in place of the fn:\n  (new cname captured-local...), with the fn's metadata.R2,i144,R3,i1,R4,s24,arbace/classes/native.ae")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.native$eval1078000004$loading__1927001464__auto____1078000005")

var Lit_35 *jrt.String = jrt.Intern("arbace.classes.native$eval1078000008$fn__1078000009")

var Lit_36 *jrt.String = jrt.Intern("ARBACE_COMPILE")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.native$compile_and_load_BANG_")

var Lit_38 *jrt.String = jrt.Intern("arbace.classes.native$compile_top")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.native$compile_deftype")

var Lit_40 *jrt.String = jrt.Intern("arbace.classes.native$public_class_QMARK_")

var Lit_41 *jrt.String = jrt.Intern("arbace.classes.native$type_form")

var Lit_42 *jrt.String = jrt.Intern("arbace.classes.native$local_class")

var Lit_43 *jrt.String = jrt.Intern("arbace.classes.native$field_names")

var Lit_44 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form")

var Lit_45 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn")
