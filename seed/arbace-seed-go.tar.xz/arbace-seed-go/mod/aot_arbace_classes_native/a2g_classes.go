//line a2g_classes.ae:1
package aot_arbace_classes_native

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_native_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_A_New()}; return nil }

var A_arbace_classes_native_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_A_new}

var A_arbace_classes_native_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_A"})

func init() { i := A_arbace_classes_native_A_class.Info(); i.IsInstance = A_arbace_classes_native_A_InstanceOf; i.Init = A_arbace_classes_native_A_Init; i.Table = A_arbace_classes_native_A_members; jrt.RegisterGoType(A_arbace_classes_native_A_class, reflect.TypeFor[A_arbace_classes_native_A]()) }

func A_arbace_classes_native_compile_deftype_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_deftype_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_native_compile_deftype_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_deftype_A_New()}; return nil }

func A_arbace_classes_native_compile_deftype_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_deftype_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_deftype_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_deftype_A_invoke, New: A_arbace_classes_native_compile_deftype_A_new, Get: A_arbace_classes_native_compile_deftype_A_get}

var A_arbace_classes_native_compile_deftype_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_deftype", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_native_A_class, Simple: "compile_deftype", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_deftype_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_deftype_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_deftype_A_InstanceOf; i.Init = A_arbace_classes_native_compile_deftype_A_Init; i.Table = A_arbace_classes_native_compile_deftype_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_deftype_A_class, reflect.TypeFor[A_arbace_classes_native_compile_deftype_A]()) }

func A_arbace_classes_native_compile_deftype_fn__1078000029_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_deftype_fn__1078000029_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_compile_deftype_fn__1078000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_deftype_fn__1078000029_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_deftype_fn__1078000029_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_deftype_fn__1078000029_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_deftype_fn__1078000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_deftype_fn__1078000029_A_invoke, New: A_arbace_classes_native_compile_deftype_fn__1078000029_A_new, Get: A_arbace_classes_native_compile_deftype_fn__1078000029_A_get}

var A_arbace_classes_native_compile_deftype_fn__1078000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_deftype$fn__1078000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_compile_deftype_A_class, Simple: "fn__1078000029", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_deftype_fn__1078000029_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_deftype_fn__1078000029_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_deftype_fn__1078000029_A_InstanceOf; i.Init = A_arbace_classes_native_compile_deftype_fn__1078000029_A_Init; i.Table = A_arbace_classes_native_compile_deftype_fn__1078000029_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_deftype_fn__1078000029_A_class, reflect.TypeFor[A_arbace_classes_native_compile_deftype_fn__1078000029_A]()) }

func A_arbace_classes_native_compile_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_native_compile_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_A_New()}; return nil }

func A_arbace_classes_native_compile_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_A_invoke, New: A_arbace_classes_native_compile_fn_A_new, Get: A_arbace_classes_native_compile_fn_A_get}

var A_arbace_classes_native_compile_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_native_A_class, Simple: "compile_fn", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_A_Init; i.Table = A_arbace_classes_native_compile_fn_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_A]()) }

func A_arbace_classes_native_compile_fn_fn__1078000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_fn__1078000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_fn__1078000118_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_fn__1078000118_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_fn__1078000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_fn__1078000118_A_invoke, New: A_arbace_classes_native_compile_fn_fn__1078000118_A_new, Get: A_arbace_classes_native_compile_fn_fn__1078000118_A_get}

var A_arbace_classes_native_compile_fn_fn__1078000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$fn__1078000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_compile_fn_A_class, Simple: "fn__1078000118", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000118_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_fn__1078000118_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_fn__1078000118_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_fn__1078000118_A_Init; i.Table = A_arbace_classes_native_compile_fn_fn__1078000118_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_fn__1078000118_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_fn__1078000118_A]()) }

func A_arbace_classes_native_compile_fn_fn__1078000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_fn__1078000120_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_fn__1078000120_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_fn__1078000120_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_fn__1078000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_fn__1078000120_A_invoke, New: A_arbace_classes_native_compile_fn_fn__1078000120_A_new, Get: A_arbace_classes_native_compile_fn_fn__1078000120_A_get}

var A_arbace_classes_native_compile_fn_fn__1078000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$fn__1078000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_compile_fn_A_class, Simple: "fn__1078000120", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000120_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_fn__1078000120_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_fn__1078000120_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_fn__1078000120_A_Init; i.Table = A_arbace_classes_native_compile_fn_fn__1078000120_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_fn__1078000120_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_fn__1078000120_A]()) }

func A_arbace_classes_native_compile_fn_fn__1078000122_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_fn__1078000122_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000122_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_fn__1078000122_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000122_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_fn__1078000122_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_fn__1078000122_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_fn__1078000122_A_invoke, New: A_arbace_classes_native_compile_fn_fn__1078000122_A_new, Get: A_arbace_classes_native_compile_fn_fn__1078000122_A_get}

var A_arbace_classes_native_compile_fn_fn__1078000122_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$fn__1078000122", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_compile_fn_A_class, Simple: "fn__1078000122", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000122_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_fn__1078000122_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_fn__1078000122_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_fn__1078000122_A_Init; i.Table = A_arbace_classes_native_compile_fn_fn__1078000122_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_fn__1078000122_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_fn__1078000122_A]()) }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_New()}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_invoke, New: A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_new, Get: A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_get}

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$fn__1078000122$fn__1078000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_compile_fn_fn__1078000122_A_class, Simple: "fn__1078000123", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_Init; i.Table = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000123_A]()) }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_New()}; return nil }

func A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_invoke, New: A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_new, Get: A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_get}

var A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$fn__1078000122$fn__1078000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_compile_fn_fn__1078000122_A_class, Simple: "fn__1078000125", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_Init; i.Table = A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_fn__1078000122_fn__1078000125_A]()) }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_New()}; return nil }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_invoke, New: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_new, Get: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_get}

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$iter__1078000102__1078000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_compile_fn_A_class, Simple: "iter__1078000102__1078000106", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_Init; i.Table = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A]()) }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_invoke, New: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_new, Get: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_get}

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_A_class, Simple: "fn__1078000107", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_Init; i.Table = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A]()) }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_invoke, New: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_new, Get: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_get}

var A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107$fn__1078000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_A_class, Simple: "fn__1078000108", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_InstanceOf; i.Init = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_Init; i.Table = A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A_class, reflect.TypeFor[A_arbace_classes_native_compile_fn_iter__1078000102__1078000106_fn__1078000107_fn__1078000108_A]()) }

func A_arbace_classes_native_compile_top_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_top_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_native_compile_top_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_top_A_New()}; return nil }

func A_arbace_classes_native_compile_top_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_top_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_top_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_top_A_invoke, New: A_arbace_classes_native_compile_top_A_new, Get: A_arbace_classes_native_compile_top_A_get}

var A_arbace_classes_native_compile_top_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_top", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_native_A_class, Simple: "compile_top", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_top_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_top_A_InstanceOf; i.Init = A_arbace_classes_native_compile_top_A_Init; i.Table = A_arbace_classes_native_compile_top_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_top_A_class, reflect.TypeFor[A_arbace_classes_native_compile_top_A]()) }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_New()}; return nil }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_invoke, New: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_new, Get: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_get}

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_top$iter__1078000012__1078000016", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_compile_top_A_class, Simple: "iter__1078000012__1078000016", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_InstanceOf; i.Init = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_Init; i.Table = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class, reflect.TypeFor[A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A]()) }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_invoke, New: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_new, Get: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_get}

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_A_class, Simple: "fn__1078000017", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_InstanceOf; i.Init = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_Init; i.Table = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class, reflect.TypeFor[A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A]()) }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_fn_class)}; return nil }

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_invoke, New: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_new, Get: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_get}

var A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017$fn__1078000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_A_class, Simple: "fn__1078000018", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_class.Info(); i.IsInstance = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_InstanceOf; i.Init = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_Init; i.Table = A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_members; jrt.RegisterGoType(A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A_class, reflect.TypeFor[A_arbace_classes_native_compile_top_iter__1078000012__1078000016_fn__1078000017_fn__1078000018_A]()) }

func A_arbace_classes_native_eval1078000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000004_A_New()}; return nil }

var A_arbace_classes_native_eval1078000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_eval1078000004_A_new}

var A_arbace_classes_native_eval1078000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_native_A_class, Simple: "eval1078000004", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000004_A"})

func init() { i := A_arbace_classes_native_eval1078000004_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000004_A_InstanceOf; i.Table = A_arbace_classes_native_eval1078000004_A_members; jrt.RegisterGoType(A_arbace_classes_native_eval1078000004_A_class, reflect.TypeFor[A_arbace_classes_native_eval1078000004_A]()) }

func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_New()}; return nil }

func A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_fn_class)}; return nil }

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_invoke, New: A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_new, Get: A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_get}

var A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000004$loading__1927001464__auto____1078000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_eval1078000004_A_class, Simple: "loading__1927001464__auto____1078000005", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_InstanceOf; i.Init = A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_Init; i.Table = A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_members; jrt.RegisterGoType(A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A_class, reflect.TypeFor[A_arbace_classes_native_eval1078000004_loading__1927001464__auto____1078000005_A]()) }

func A_arbace_classes_native_eval1078000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000008_A_New()}; return nil }

var A_arbace_classes_native_eval1078000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_native_eval1078000008_A_new}

var A_arbace_classes_native_eval1078000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_native_A_class, Simple: "eval1078000008", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000008_A"})

func init() { i := A_arbace_classes_native_eval1078000008_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000008_A_InstanceOf; i.Table = A_arbace_classes_native_eval1078000008_A_members; jrt.RegisterGoType(A_arbace_classes_native_eval1078000008_A_class, reflect.TypeFor[A_arbace_classes_native_eval1078000008_A]()) }

func A_arbace_classes_native_eval1078000008_fn__1078000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_eval1078000008_fn__1078000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_eval1078000008_fn__1078000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_eval1078000008_fn__1078000009_A_New()}; return nil }

func A_arbace_classes_native_eval1078000008_fn__1078000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_eval1078000008_fn__1078000009_A_fn_class)}; return nil }

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_eval1078000008_fn__1078000009_A_invoke, New: A_arbace_classes_native_eval1078000008_fn__1078000009_A_new, Get: A_arbace_classes_native_eval1078000008_fn__1078000009_A_get}

var A_arbace_classes_native_eval1078000008_fn__1078000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$eval1078000008$fn__1078000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_eval1078000008_A_class, Simple: "fn__1078000009", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_eval1078000008_fn__1078000009_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_eval1078000008_fn__1078000009_A_class.Info(); i.IsInstance = A_arbace_classes_native_eval1078000008_fn__1078000009_A_InstanceOf; i.Init = A_arbace_classes_native_eval1078000008_fn__1078000009_A_Init; i.Table = A_arbace_classes_native_eval1078000008_fn__1078000009_A_members; jrt.RegisterGoType(A_arbace_classes_native_eval1078000008_fn__1078000009_A_class, reflect.TypeFor[A_arbace_classes_native_eval1078000008_fn__1078000009_A]()) }

func A_arbace_classes_native_field_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_field_names_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_field_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_field_names_A_New()}; return nil }

func A_arbace_classes_native_field_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_field_names_A_fn_class)}; return nil }

var A_arbace_classes_native_field_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_field_names_A_invoke, New: A_arbace_classes_native_field_names_A_new, Get: A_arbace_classes_native_field_names_A_get}

var A_arbace_classes_native_field_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$field_names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_A_class, Simple: "field_names", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_field_names_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_field_names_A_class.Info(); i.IsInstance = A_arbace_classes_native_field_names_A_InstanceOf; i.Init = A_arbace_classes_native_field_names_A_Init; i.Table = A_arbace_classes_native_field_names_A_members; jrt.RegisterGoType(A_arbace_classes_native_field_names_A_class, reflect.TypeFor[A_arbace_classes_native_field_names_A]()) }

func A_arbace_classes_native_fn_class_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_native_fn_class_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_A_New()}; return nil }

func A_arbace_classes_native_fn_class_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_A_invoke, New: A_arbace_classes_native_fn_class_form_A_new, Get: A_arbace_classes_native_fn_class_form_A_get}

var A_arbace_classes_native_fn_class_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_native_A_class, Simple: "fn_class_form", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_A_Init; i.Table = A_arbace_classes_native_fn_class_form_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_A]()) }

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_fn__1078000077_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_fn__1078000077_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_fn__1078000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_fn__1078000077_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_fn__1078000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_fn__1078000077_A_invoke, New: A_arbace_classes_native_fn_class_form_fn__1078000077_A_new, Get: A_arbace_classes_native_fn_class_form_fn__1078000077_A_get}

var A_arbace_classes_native_fn_class_form_fn__1078000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$fn__1078000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_native_fn_class_form_A_class, Simple: "fn__1078000077", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_fn__1078000077_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_fn__1078000077_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_fn__1078000077_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_fn__1078000077_A_Init; i.Table = A_arbace_classes_native_fn_class_form_fn__1078000077_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_fn__1078000077_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_fn__1078000077_A]()) }

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_fn__1078000093_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_fn__1078000093_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_fn__1078000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_fn__1078000093_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_fn__1078000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_fn__1078000093_A_invoke, New: A_arbace_classes_native_fn_class_form_fn__1078000093_A_new, Get: A_arbace_classes_native_fn_class_form_fn__1078000093_A_get}

var A_arbace_classes_native_fn_class_form_fn__1078000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$fn__1078000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_native_fn_class_form_A_class, Simple: "fn__1078000093", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_fn__1078000093_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_fn__1078000093_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_fn__1078000093_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_fn__1078000093_A_Init; i.Table = A_arbace_classes_native_fn_class_form_fn__1078000093_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_fn__1078000093_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_fn__1078000093_A]()) }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_invoke, New: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_new, Get: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_get}

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$iter__1078000054__1078000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_fn_class_form_A_class, Simple: "iter__1078000054__1078000058", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_Init; i.Table = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A]()) }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_invoke, New: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_new, Get: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_get}

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_A_class, Simple: "fn__1078000059", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_Init; i.Table = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A]()) }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_invoke, New: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_new, Get: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_get}

var A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059$fn__1078000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_A_class, Simple: "fn__1078000060", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_Init; i.Table = A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_iter__1078000054__1078000058_fn__1078000059_fn__1078000060_A]()) }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_invoke, New: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_new, Get: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_get}

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$iter__1078000082__1078000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_fn_class_form_A_class, Simple: "iter__1078000082__1078000086", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_Init; i.Table = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A]()) }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_invoke, New: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_new, Get: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_get}

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_A_class, Simple: "fn__1078000087", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_Init; i.Table = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A]()) }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_invoke, New: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_new, Get: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_get}

var A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087$fn__1078000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_A_class, Simple: "fn__1078000088", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_Init; i.Table = A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_iter__1078000082__1078000086_fn__1078000087_fn__1078000088_A]()) }

func A_arbace_classes_native_fn_class_form_typed__1078000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_fn_class_form_typed__1078000052_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_native_fn_class_form_typed__1078000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_fn_class_form_typed__1078000052_A_New()}; return nil }

func A_arbace_classes_native_fn_class_form_typed__1078000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_fn_class_form_typed__1078000052_A_fn_class)}; return nil }

var A_arbace_classes_native_fn_class_form_typed__1078000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_fn_class_form_typed__1078000052_A_invoke, New: A_arbace_classes_native_fn_class_form_typed__1078000052_A_new, Get: A_arbace_classes_native_fn_class_form_typed__1078000052_A_get}

var A_arbace_classes_native_fn_class_form_typed__1078000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$fn_class_form$typed__1078000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_native_fn_class_form_A_class, Simple: "typed__1078000052", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_fn_class_form_typed__1078000052_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_fn_class_form_typed__1078000052_A_class.Info(); i.IsInstance = A_arbace_classes_native_fn_class_form_typed__1078000052_A_InstanceOf; i.Init = A_arbace_classes_native_fn_class_form_typed__1078000052_A_Init; i.Table = A_arbace_classes_native_fn_class_form_typed__1078000052_A_members; jrt.RegisterGoType(A_arbace_classes_native_fn_class_form_typed__1078000052_A_class, reflect.TypeFor[A_arbace_classes_native_fn_class_form_typed__1078000052_A]()) }

func A_arbace_classes_native_local_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_local_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_local_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_local_class_A_New()}; return nil }

func A_arbace_classes_native_local_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_local_class_A_fn_class)}; return nil }

var A_arbace_classes_native_local_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_local_class_A_invoke, New: A_arbace_classes_native_local_class_A_new, Get: A_arbace_classes_native_local_class_A_get}

var A_arbace_classes_native_local_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$local_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_A_class, Simple: "local_class", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_local_class_A_class.Info(); i.IsInstance = A_arbace_classes_native_local_class_A_InstanceOf; i.Init = A_arbace_classes_native_local_class_A_Init; i.Table = A_arbace_classes_native_local_class_A_members; jrt.RegisterGoType(A_arbace_classes_native_local_class_A_class, reflect.TypeFor[A_arbace_classes_native_local_class_A]()) }

func A_arbace_classes_native_local_class_fn__1078000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_local_class_fn__1078000034_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_local_class_fn__1078000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_local_class_fn__1078000034_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_local_class_fn__1078000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_local_class_fn__1078000034_A_fn_class)}; return nil }

var A_arbace_classes_native_local_class_fn__1078000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_local_class_fn__1078000034_A_invoke, New: A_arbace_classes_native_local_class_fn__1078000034_A_new, Get: A_arbace_classes_native_local_class_fn__1078000034_A_get}

var A_arbace_classes_native_local_class_fn__1078000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$local_class$fn__1078000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_local_class_A_class, Simple: "fn__1078000034", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_fn__1078000034_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_local_class_fn__1078000034_A_class.Info(); i.IsInstance = A_arbace_classes_native_local_class_fn__1078000034_A_InstanceOf; i.Init = A_arbace_classes_native_local_class_fn__1078000034_A_Init; i.Table = A_arbace_classes_native_local_class_fn__1078000034_A_members; jrt.RegisterGoType(A_arbace_classes_native_local_class_fn__1078000034_A_class, reflect.TypeFor[A_arbace_classes_native_local_class_fn__1078000034_A]()) }

func A_arbace_classes_native_local_class_fn__1078000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_local_class_fn__1078000036_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_native_local_class_fn__1078000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_local_class_fn__1078000036_A_New_O(args[0])}; return nil }

func A_arbace_classes_native_local_class_fn__1078000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_local_class_fn__1078000036_A_fn_class)}; return nil }

var A_arbace_classes_native_local_class_fn__1078000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_local_class_fn__1078000036_A_invoke, New: A_arbace_classes_native_local_class_fn__1078000036_A_new, Get: A_arbace_classes_native_local_class_fn__1078000036_A_get}

var A_arbace_classes_native_local_class_fn__1078000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$local_class$fn__1078000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_native_local_class_A_class, Simple: "fn__1078000036", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_local_class_fn__1078000036_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_local_class_fn__1078000036_A_class.Info(); i.IsInstance = A_arbace_classes_native_local_class_fn__1078000036_A_InstanceOf; i.Init = A_arbace_classes_native_local_class_fn__1078000036_A_Init; i.Table = A_arbace_classes_native_local_class_fn__1078000036_A_members; jrt.RegisterGoType(A_arbace_classes_native_local_class_fn__1078000036_A_class, reflect.TypeFor[A_arbace_classes_native_local_class_fn__1078000036_A]()) }

func A_arbace_classes_native_public_class_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_public_class_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_public_class_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_public_class_QMARK__A_New()}; return nil }

func A_arbace_classes_native_public_class_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_public_class_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_native_public_class_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_public_class_QMARK__A_invoke, New: A_arbace_classes_native_public_class_QMARK__A_new, Get: A_arbace_classes_native_public_class_QMARK__A_get}

var A_arbace_classes_native_public_class_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$public_class_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_A_class, Simple: "public_class_QMARK_", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_public_class_QMARK__A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_public_class_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_native_public_class_QMARK__A_InstanceOf; i.Init = A_arbace_classes_native_public_class_QMARK__A_Init; i.Table = A_arbace_classes_native_public_class_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_native_public_class_QMARK__A_class, reflect.TypeFor[A_arbace_classes_native_public_class_QMARK__A]()) }

func A_arbace_classes_native_type_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_native_type_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_native_type_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native_type_form_A_New()}; return nil }

func A_arbace_classes_native_type_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_native_type_form_A_fn_class)}; return nil }

var A_arbace_classes_native_type_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_native_type_form_A_invoke, New: A_arbace_classes_native_type_form_A_new, Get: A_arbace_classes_native_type_form_A_get}

var A_arbace_classes_native_type_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native$type_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_native_A_class, Simple: "type_form", Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native_type_form_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native_type_form_A_class.Info(); i.IsInstance = A_arbace_classes_native_type_form_A_InstanceOf; i.Init = A_arbace_classes_native_type_form_A_Init; i.Table = A_arbace_classes_native_type_form_A_members; jrt.RegisterGoType(A_arbace_classes_native_type_form_A_class, reflect.TypeFor[A_arbace_classes_native_type_form_A]()) }

func A_arbace_classes_native__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_native__init_A_Load__O(); case 1: return A_arbace_classes_native__init_A_Unit0__O(); case 2: return A_arbace_classes_native__init_A_Unit1__O(); case 3: return A_arbace_classes_native__init_A_Unit10__O(); case 4: return A_arbace_classes_native__init_A_Unit11__O(); case 5: return A_arbace_classes_native__init_A_Unit2__O(); case 6: return A_arbace_classes_native__init_A_Unit3__O(); case 7: return A_arbace_classes_native__init_A_Unit4__O(); case 8: return A_arbace_classes_native__init_A_Unit5__O(); case 9: return A_arbace_classes_native__init_A_Unit6__O(); case 10: return A_arbace_classes_native__init_A_Unit7__O(); case 11: return A_arbace_classes_native__init_A_Unit8__O(); case 12: return A_arbace_classes_native__init_A_Unit9__O()}; return nil }

func A_arbace_classes_native__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_native__init_A_New()}; return nil }

var A_arbace_classes_native__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_native__init_A_invoke, New: A_arbace_classes_native__init_A_new}

var A_arbace_classes_native__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.native__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_native.A_arbace_classes_native__init_A", Source: "native.ae"})

func init() { i := A_arbace_classes_native__init_A_class.Info(); i.IsInstance = A_arbace_classes_native__init_A_InstanceOf; i.Init = A_arbace_classes_native__init_A_Init; i.Table = A_arbace_classes_native__init_A_members; jrt.RegisterGoType(A_arbace_classes_native__init_A_class, reflect.TypeFor[A_arbace_classes_native__init_A]()) }
