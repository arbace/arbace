//line a2g_strings.ae:1
package aot_arbace_classes_native

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn18,arbace.classes.envyn3,envyn20,arbace.classes.loweryn5,loweryn21,arbace.classes.interpyn8,compilerkn3,dockn3,topkn8,siblingsys11,arbace.core7,import*yn2,dokn4,elsekn4,namekn7,aritiesyn18,arbace.lang.RestFnyn21,arbace.lang.AFunctionkn3,tagkn7,packagekn7,extendskn10,implementsyn5,fieldkn5,finalkn6,publickn10,clojure-fnkn10,reflectionkn7,clojureyn11,constructoryn4,set!yn6,super.kn10,unresolvedks21,arbace.classes.native5,retryyn3,newys11,arbace.core9,with-metav11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn21,arbace.classes.nativem2,R10,s1473,The boundary between arbace.lang.Compiler and the class forms compiler (SPEC §9.5).\n\n  arbace.lang.Compiler knows the class forms' special forms (class*, label*, switch*, ...) but\n  does not compile them itself: there is one implementation of the class forms, this library.\n  The compiler loads this namespace on first use and calls the functions below:\n\n  - `compile-top`, for (class* :top form) and (class* :tops forms), the expansions of\n    `defclass` and `defclasses`: compiles and defines the classes, and returns the form the\n    compiler analyzes in place of the class form (imports and the class or classes).\n  - `compile-fn`, for a fn* whose code uses the class forms (a special form of theirs in it, or\n    a form whose new meaning only they know): the compiler hands the whole fn over, at the\n    innermost fn* that is not one of its own wrappers (`(fn* ^:once [] ...)`); this compiles\n    it into a fn class, a subclass of arbace.lang.AFunction or RestFn named as the compiler\n    names its fn classes, whose code is compiled with Clojure's meaning (SPEC §5.13), and\n    returns the form the compiler analyzes in its place: (new C captured-local...).\n    The locals of the compiler's environment that the fn uses become the class's fields.\n  - `compile-deftype`, for a deftype* one of whose method bodies uses the class forms: compiles\n    and defines the deftype class, with the shape arbace.lang.Compiler gives it, and returns\n    nil, the value of deftype*.v11,arbace.core13,*loaded-libs*R11,v11,arbace.core3,vecv21,arbace.classes.interp17,compile-and-load!v11,arbace.core3,seqR12,v11,arbace.core6,concatv11,arbace.core4,listv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR13,v11,arbace.core10,chunk-consv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restR14,v11,arbace.core6,secondv11,arbace.core4,mapvv11,arbace.core19,pop-thread-bindingsv20,arbace.classes.lower18,deftype-class-formv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core4,*ns*v11,arbace.core3,notR15,v11,arbace.core6,symbolv11,arbace.core3,strv21,arbace.classes.native13,public-class?C16,java.lang.Objectv13,arbace.string9,includes?v11,arbace.core4,nextv11,arbace.core5,mungev11,arbace.core4,namev20,arbace.classes.lower8,fn-partsv11,arbace.core8,to-arrayR16,R17,v11,arbace.core4,subsv11,arbace.core6,gensymv21,arbace.classes.native11,field-namesv11,arbace.core4,someR18,R19,v11,arbace.core9,with-metaR20,v21,arbace.classes.native9,type-forml0,v11,arbace.core3,mapv20,arbace.classes.lower9,variadic?R21,R22,R23,v20,arbace.classes.lower15,prim-interfacesR24,v11,arbace.core9,vary-metav11,arbace.core5,assocR25,v20,arbace.classes.lower10,fn-methodsm8,R26,TR25,TR27,TR28,R29,v11,arbace.core6,vectorv11,arbace.core5,list*R30,R31,m2,R26,TR32,v11,arbace.core6,mapcatv11,arbace.core4,intov20,arbace.classes.lower10,symbols-inv11,arbace.core7,filtervv21,arbace.classes.native13,fn-class-formv11,arbace.core9,contains?R33,v11,arbace.core7,ex-datav11,arbace.core10,take-whilev11,arbace.core5,some?v11,arbace.core7,iterateR34,v20,arbace.classes.lower7,fn-metav21,arbace.classes.native11,local-classv11,arbace.core7,sort-byR35,R36,")

var Lit_1 *jrt.String = jrt.Intern("arbace.classes.native$compile_deftype$fn__1078000029")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000102__1078000106")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000118")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000120")

var Lit_5 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000122")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000122$fn__1078000123")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000122$fn__1078000125")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107$fn__1078000108")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000012__1078000016")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017$fn__1078000018")

var Lit_13 *jrt.String = jrt.Intern("__")

var Lit_14 *jrt.String = jrt.Intern(".")

var Lit_15 *jrt.String = jrt.Intern("")

var Lit_16 *jrt.String = jrt.Intern("fn__this")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$typed__1078000052")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000054__1078000058")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$fn__1078000077")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000082__1078000086")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$fn__1078000093")

var Lit_22 *jrt.String = jrt.Intern(".-")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059$fn__1078000060")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087$fn__1078000088")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.native$local_class$fn__1078000034")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.native$local_class$fn__1078000036")

var Lit_29 *jrt.String = jrt.Intern("compile__stub")

var Lit_30 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn2,nsyn4,kindyn5,formsyn8,siblingskn4,linekn6,columnkn4,fileyn4,formkn7,privatekn3,tagyn5,Classyn2,lbyn4,symsyn5,cnameyn8,capturedyn3,envv11,arbace.core5,in-nsMyn21,arbace.classes.nativem2,R0,s1473,The boundary between arbace.lang.Compiler and the class forms compiler (SPEC §9.5).\n\n  arbace.lang.Compiler knows the class forms' special forms (class*, label*, switch*, ...) but\n  does not compile them itself: there is one implementation of the class forms, this library.\n  The compiler loads this namespace on first use and calls the functions below:\n\n  - `compile-top`, for (class* :top form) and (class* :tops forms), the expansions of\n    `defclass` and `defclasses`: compiles and defines the classes, and returns the form the\n    compiler analyzes in place of the class form (imports and the class or classes).\n  - `compile-fn`, for a fn* whose code uses the class forms (a special form of theirs in it, or\n    a form whose new meaning only they know): the compiler hands the whole fn over, at the\n    innermost fn* that is not one of its own wrappers (`(fn* ^:once [] ...)`); this compiles\n    it into a fn class, a subclass of arbace.lang.AFunction or RestFn named as the compiler\n    names its fn classes, whose code is compiled with Clojure's meaning (SPEC §5.13), and\n    returns the form the compiler analyzes in its place: (new C captured-local...).\n    The locals of the compiler's environment that the fn uses become the class's fields.\n  - `compile-deftype`, for a deftype* one of whose method bodies uses the class forms: compiles\n    and defines the deftype class, with the shape arbace.lang.Compiler gives it, and returns\n    nil, the value of deftype*.m2,R0,s1473,The boundary between arbace.lang.Compiler and the class forms compiler (SPEC §9.5).\n\n  arbace.lang.Compiler knows the class forms' special forms (class*, label*, switch*, ...) but\n  does not compile them itself: there is one implementation of the class forms, this library.\n  The compiler loads this namespace on first use and calls the functions below:\n\n  - `compile-top`, for (class* :top form) and (class* :tops forms), the expansions of\n    `defclass` and `defclasses`: compiles and defines the classes, and returns the form the\n    compiler analyzes in place of the class form (imports and the class or classes).\n  - `compile-fn`, for a fn* whose code uses the class forms (a special form of theirs in it, or\n    a form whose new meaning only they know): the compiler hands the whole fn over, at the\n    innermost fn* that is not one of its own wrappers (`(fn* ^:once [] ...)`); this compiles\n    it into a fn class, a subclass of arbace.lang.AFunction or RestFn named as the compiler\n    names its fn classes, whose code is compiled with Clojure's meaning (SPEC §5.13), and\n    returns the form the compiler analyzes in its place: (new C captured-local...).\n    The locals of the compiler's environment that the fn uses become the class's fields.\n  - `compile-deftype`, for a deftype* one of whose method bodies uses the class forms: compiles\n    and defines the deftype class, with the shape arbace.lang.Compiler gives it, and returns\n    nil, the value of deftype*.R1,v21,arbace.classes.native11,compile-topm10,R2,L1,V4,R3,R4,R5,R6,R0,s411,(class* :top form) or (class* :tops forms), each form the rest of a defclass form, in\n  namespace ns: compiles the classes as one compilation, with `siblings` (the class forms of\n  the enclosing top-level do, SPEC §9.2) entered as declarations, and defines them (and writes\n  them under *compile-files*). Returns the form evaluating to the class (:top) or a vector of\n  the classes (:tops) after importing them.R7,i26,R8,i1,R9,s24,arbace/classes/native.aev21,arbace.classes.native15,compile-deftypem10,R2,L1,V2,R3,R10,R0,s266,Compiles (deftype* tagname classname [fields] :implements [interfaces] ...) in namespace ns\n  into the deftype class (arbace.classes.lower/deftype-class-form) and defines it (writing it\n  under *compile-files*). Returns nil, the form to analyze in place of deftype*.R7,i42,R8,i1,R9,s24,arbace/classes/native.aev21,arbace.classes.native13,public-class?m10,R11,TR2,L1,V1,Myn1,cm2,R12,R13,R7,i54,R8,i1,R9,s24,arbace/classes/native.aev21,arbace.classes.native9,type-formm12,R11,TR2,L1,V1,Myn1,cm2,R12,R13,R0,s81,The type form of class c (SPEC §4.3): long, java.lang.String, java.lang.String/2.R7,i60,R8,i1,R9,s24,arbace/classes/native.aev21,arbace.classes.native11,local-classm12,R11,TR2,L1,V1,R14,R0,s172,The class of a local binding of the compiler, as precise as a field of a class compiled\n  elsewhere can have it: its primitive type, its tag's class if public, else Object.R7,i68,R8,i1,R9,s24,arbace/classes/native.aev21,arbace.classes.native11,field-namesm12,R11,TR2,L1,V1,R15,R0,s43,Unique field names for the captured locals.R7,i82,R8,i1,R9,s24,arbace/classes/native.aev21,arbace.classes.native13,fn-class-formm10,R2,L1,V3,R16,R10,R17,R0,s161,The class form (rest of a defclass form) of the fn class `cname` (dotted binary name) for\n  fn* form `form`, capturing the locals `captured` ([[sym Class] ...]).R7,i92,R8,i1,R9,s24,arbace/classes/native.aev21,arbace.classes.native10,compile-fnm10,R2,L1,V4,R3,R16,R10,R18,R0,s323,Compiles fn* form `form` in namespace ns into the fn class `cname` (the compiler's name for\n  it) and defines it (writing it under *compile-files*). `env` is the compiler's local\n  environment (symbol -> LocalBinding). Returns the form to analyze in place of the fn:\n  (new cname captured-local...), with the fn's metadata.R7,i118,R8,i1,R9,s24,arbace/classes/native.ae")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.native$eval1078000004$loading__1927001464__auto____1078000005")

var Lit_32 *jrt.String = jrt.Intern("arbace.classes.native$eval1078000008$fn__1078000009")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.native$compile_top")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.native$compile_deftype")

var Lit_35 *jrt.String = jrt.Intern("arbace.classes.native$public_class_QMARK_")

var Lit_36 *jrt.String = jrt.Intern("arbace.classes.native$type_form")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.native$local_class")

var Lit_38 *jrt.String = jrt.Intern("arbace.classes.native$field_names")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form")

var Lit_40 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn")
