//line a2g_strings.ae:1
package aot_arbace_classes_native

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_7 *jrt.String = jrt.Intern("env")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.lower")

var Lit_9 *jrt.String = jrt.Intern("lower")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.interp")

var Lit_11 *jrt.String = jrt.Intern("compiler")

var Lit_12 *jrt.String = jrt.Intern("commute")

var Lit_13 *jrt.String = jrt.Intern("deref")

var Lit_14 *jrt.String = jrt.Intern("conj")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.native")

var Lit_16 *jrt.String = jrt.Intern("doc")

var Lit_17 *jrt.String = jrt.Intern("The boundary between arbace.lang.Compiler and the class forms compiler (SPEC §9.5).\n\n  arbace.lang.Compiler knows the class forms' special forms (class*, label*, switch*, ...) but\n  does not compile them itself: there is one implementation of the class forms, this library.\n  The compiler loads this namespace on first use and calls the functions below:\n\n  - `compile-top`, for (class* :top form) and (class* :tops forms), the expansions of\n    `defclass` and `defclasses`: compiles and defines the classes, and returns the form the\n    compiler analyzes in place of the class form (imports and the class or classes).\n  - `compile-fn`, for a fn* whose code uses the class forms (a special form of theirs in it, or\n    a form whose new meaning only they know): the compiler hands the whole fn over, at the\n    innermost fn* that is not one of its own wrappers (`(fn* ^:once [] ...)`); this compiles\n    it into a fn class, a subclass of arbace.lang.AFunction or RestFn named as the compiler\n    names its fn classes, whose code is compiled with Clojure's meaning (SPEC §5.13), and\n    returns the form the compiler analyzes in its place: (new C captured-local...).\n    The locals of the compiler's environment that the fn uses become the class's fields.\n  - `compile-deftype`, for a deftype* one of whose method bodies uses the class forms: compiles\n    and defines the deftype class, with the shape arbace.lang.Compiler gives it, and returns\n    nil, the value of deftype*.")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("top")

var Lit_20 *jrt.String = jrt.Intern("vec")

var Lit_21 *jrt.String = jrt.Intern("compile-and-load!")

var Lit_22 *jrt.String = jrt.Intern("seq")

var Lit_23 *jrt.String = jrt.Intern("siblings")

var Lit_24 *jrt.String = jrt.Intern("concat")

var Lit_25 *jrt.String = jrt.Intern("list")

var Lit_26 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_27 *jrt.String = jrt.Intern("chunk-first")

var Lit_28 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_29 *jrt.String = jrt.Intern("chunk-append")

var Lit_30 *jrt.String = jrt.Intern("import*")

var Lit_31 *jrt.String = jrt.Intern("chunk-cons")

var Lit_32 *jrt.String = jrt.Intern("first")

var Lit_33 *jrt.String = jrt.Intern("cons")

var Lit_34 *jrt.String = jrt.Intern("chunk")

var Lit_35 *jrt.String = jrt.Intern("chunk-rest")

var Lit_36 *jrt.String = jrt.Intern("rest")

var Lit_37 *jrt.String = jrt.Intern("do")

var Lit_38 *jrt.String = jrt.Intern("second")

var Lit_39 *jrt.String = jrt.Intern("mapv")

var Lit_40 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_41 *jrt.String = jrt.Intern("deftype-class-form")

var Lit_42 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_43 *jrt.String = jrt.Intern("hash-map")

var Lit_44 *jrt.String = jrt.Intern("*ns*")

var Lit_45 *jrt.String = jrt.Intern("not")

var Lit_46 *jrt.String = jrt.Intern("else")

var Lit_47 *jrt.String = jrt.Intern("symbol")

var Lit_48 *jrt.String = jrt.Intern("public-class?")

var Lit_49 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_50 *jrt.String = jrt.Intern("includes?")

var Lit_51 *jrt.String = jrt.Intern("next")

var Lit_52 *jrt.String = jrt.Intern("munge")

var Lit_53 *jrt.String = jrt.Intern("name")

var Lit_54 *jrt.String = jrt.Intern("fn-parts")

var Lit_55 *jrt.String = jrt.Intern("to-array")

var Lit_56 *jrt.String = jrt.Intern("arities")

var Lit_57 *jrt.String = jrt.Intern("subs")

var Lit_58 *jrt.String = jrt.Intern("gensym")

var Lit_59 *jrt.String = jrt.Intern("field-names")

var Lit_60 *jrt.String = jrt.Intern("some")

var Lit_61 *jrt.String = jrt.Intern("arbace.lang.RestFn")

var Lit_62 *jrt.String = jrt.Intern("arbace.lang.AFunction")

var Lit_63 *jrt.String = jrt.Intern("with-meta")

var Lit_64 *jrt.String = jrt.Intern("tag")

var Lit_65 *jrt.String = jrt.Intern("type-form")

var Lit_66 *jrt.String = jrt.Intern("map")

var Lit_67 *jrt.String = jrt.Intern("variadic?")

var Lit_68 *jrt.String = jrt.Intern("package")

var Lit_69 *jrt.String = jrt.Intern("extends")

var Lit_70 *jrt.String = jrt.Intern("implements")

var Lit_71 *jrt.String = jrt.Intern("prim-interfaces")

var Lit_72 *jrt.String = jrt.Intern("field")

var Lit_73 *jrt.String = jrt.Intern("vary-meta")

var Lit_74 *jrt.String = jrt.Intern("assoc")

var Lit_75 *jrt.String = jrt.Intern("final")

var Lit_76 *jrt.String = jrt.Intern("fn-methods")

var Lit_77 *jrt.String = jrt.Intern("public")

var Lit_78 *jrt.String = jrt.Intern("clojure-fn")

var Lit_79 *jrt.String = jrt.Intern("reflection")

var Lit_80 *jrt.String = jrt.Intern("clojure")

var Lit_81 *jrt.String = jrt.Intern("vector")

var Lit_82 *jrt.String = jrt.Intern("list*")

var Lit_83 *jrt.String = jrt.Intern("constructor")

var Lit_84 *jrt.String = jrt.Intern("set!")

var Lit_85 *jrt.String = jrt.Intern("super.")

var Lit_86 *jrt.String = jrt.Intern("mapcat")

var Lit_87 *jrt.String = jrt.Intern("into")

var Lit_88 *jrt.String = jrt.Intern("symbols-in")

var Lit_89 *jrt.String = jrt.Intern("filterv")

var Lit_90 *jrt.String = jrt.Intern("fn-class-form")

var Lit_91 *jrt.String = jrt.Intern("contains?")

var Lit_92 *jrt.String = jrt.Intern("unresolved")

var Lit_93 *jrt.String = jrt.Intern("ex-data")

var Lit_94 *jrt.String = jrt.Intern("take-while")

var Lit_95 *jrt.String = jrt.Intern("some?")

var Lit_96 *jrt.String = jrt.Intern("iterate")

var Lit_97 *jrt.String = jrt.Intern("retry")

var Lit_98 *jrt.String = jrt.Intern("fn-meta")

var Lit_99 *jrt.String = jrt.Intern("local-class")

var Lit_100 *jrt.String = jrt.Intern("sort-by")

var Lit_101 *jrt.String = jrt.Intern("new")

var Lit_102 *jrt.String = jrt.Intern("arbace.classes.native$compile_deftype")

var Lit_103 *jrt.String = jrt.Intern("arbace.classes.native$compile_deftype$fn__1078000029")

var Lit_104 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn")

var Lit_105 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000118")

var Lit_106 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000120")

var Lit_107 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000122")

var Lit_108 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000122$fn__1078000123")

var Lit_109 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$fn__1078000122$fn__1078000125")

var Lit_110 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000102__1078000106")

var Lit_111 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107")

var Lit_112 *jrt.String = jrt.Intern("arbace.classes.native$compile_fn$iter__1078000102__1078000106$fn__1078000107$fn__1078000108")

var Lit_113 *jrt.String = jrt.Intern("arbace.classes.native$compile_top")

var Lit_114 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000012__1078000016")

var Lit_115 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017")

var Lit_116 *jrt.String = jrt.Intern("arbace.classes.native$compile_top$iter__1078000012__1078000016$fn__1078000017$fn__1078000018")

var Lit_117 *jrt.String = jrt.Intern("arbace.classes.native$eval1078000004$loading__1927001464__auto____1078000005")

var Lit_118 *jrt.String = jrt.Intern("arbace.classes.native$eval1078000008$fn__1078000009")

var Lit_119 *jrt.String = jrt.Intern("arbace.classes.native$field_names")

var Lit_120 *jrt.String = jrt.Intern("__")

var Lit_121 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form")

var Lit_122 *jrt.String = jrt.Intern(".")

var Lit_123 *jrt.String = jrt.Intern("")

var Lit_124 *jrt.String = jrt.Intern("fn__this")

var Lit_125 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$fn__1078000077")

var Lit_126 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$fn__1078000093")

var Lit_127 *jrt.String = jrt.Intern(".-")

var Lit_128 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000054__1078000058")

var Lit_129 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059")

var Lit_130 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000054__1078000058$fn__1078000059$fn__1078000060")

var Lit_131 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000082__1078000086")

var Lit_132 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087")

var Lit_133 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$iter__1078000082__1078000086$fn__1078000087$fn__1078000088")

var Lit_134 *jrt.String = jrt.Intern("arbace.classes.native$fn_class_form$typed__1078000052")

var Lit_135 *jrt.String = jrt.Intern("arbace.classes.native$local_class")

var Lit_136 *jrt.String = jrt.Intern("compile__stub")

var Lit_137 *jrt.String = jrt.Intern("arbace.classes.native$local_class$fn__1078000034")

var Lit_138 *jrt.String = jrt.Intern("arbace.classes.native$local_class$fn__1078000036")

var Lit_139 *jrt.String = jrt.Intern("arbace.classes.native$public_class_QMARK_")

var Lit_140 *jrt.String = jrt.Intern("arbace.classes.native$type_form")

var Lit_141 *jrt.String = jrt.Intern("in-ns")

var Lit_142 *jrt.String = jrt.Intern("compile-top")

var Lit_143 *jrt.String = jrt.Intern("arglists")

var Lit_144 *jrt.String = jrt.Intern("ns")

var Lit_145 *jrt.String = jrt.Intern("kind")

var Lit_146 *jrt.String = jrt.Intern("forms")

var Lit_147 *jrt.String = jrt.Intern("(class* :top form) or (class* :tops forms), each form the rest of a defclass form, in\n  namespace ns: compiles the classes as one compilation, with `siblings` (the class forms of\n  the enclosing top-level do, SPEC §9.2) entered as declarations, and defines them (and writes\n  them under *compile-files*). Returns the form evaluating to the class (:top) or a vector of\n  the classes (:tops) after importing them.")

var Lit_148 *jrt.String = jrt.Intern("line")

var Lit_149 *jrt.String = jrt.Intern("column")

var Lit_150 *jrt.String = jrt.Intern("file")

var Lit_151 *jrt.String = jrt.Intern("arbace/classes/native.ae")

var Lit_152 *jrt.String = jrt.Intern("compile-deftype")

var Lit_153 *jrt.String = jrt.Intern("form")

var Lit_154 *jrt.String = jrt.Intern("Compiles (deftype* tagname classname [fields] :implements [interfaces] ...) in namespace ns\n  into the deftype class (arbace.classes.lower/deftype-class-form) and defines it (writing it\n  under *compile-files*). Returns nil, the form to analyze in place of deftype*.")

var Lit_155 *jrt.String = jrt.Intern("private")

var Lit_156 *jrt.String = jrt.Intern("c")

var Lit_157 *jrt.String = jrt.Intern("Class")

var Lit_158 *jrt.String = jrt.Intern("The type form of class c (SPEC §4.3): long, java.lang.String, java.lang.String/2.")

var Lit_159 *jrt.String = jrt.Intern("lb")

var Lit_160 *jrt.String = jrt.Intern("The class of a local binding of the compiler, as precise as a field of a class compiled\n  elsewhere can have it: its primitive type, its tag's class if public, else Object.")

var Lit_161 *jrt.String = jrt.Intern("syms")

var Lit_162 *jrt.String = jrt.Intern("Unique field names for the captured locals.")

var Lit_163 *jrt.String = jrt.Intern("cname")

var Lit_164 *jrt.String = jrt.Intern("captured")

var Lit_165 *jrt.String = jrt.Intern("The class form (rest of a defclass form) of the fn class `cname` (dotted binary name) for\n  fn* form `form`, capturing the locals `captured` ([[sym Class] ...]).")

var Lit_166 *jrt.String = jrt.Intern("compile-fn")

var Lit_167 *jrt.String = jrt.Intern("Compiles fn* form `form` in namespace ns into the fn class `cname` (the compiler's name for\n  it) and defines it (writing it under *compile-files*). `env` is the compiler's local\n  environment (symbol -> LocalBinding). Returns the form to analyze in place of the fn:\n  (new cname captured-local...), with the fn's metadata.")
