//line aot_arbace_classes_types__init.ae:1
package aot_arbace_classes_types

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_types__init_A_Unit0__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_types__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types__init_A_const_1) }
//line :1:1
func A_arbace_classes_types__init_A_Unit1__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_types__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_2)) }
//line :1:1
func A_arbace_classes_types__init_A_Unit2__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_types__init_A_Unit3__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_types__init_A_const_1)).Equals_O__Z(A_arbace_classes_types__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_types_eval48000008_fn__48000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_types__init_A_Load__O() any { A_arbace_classes_types__init_A_Init(); jrt.StartCheck(); A_arbace_classes_types__init_A_Unit0__O(); A_arbace_classes_types__init_A_Unit1__O(); A_arbace_classes_types__init_A_Unit2__O(); A_arbace_classes_types__init_A_Unit3__O(); A_arbace_classes_types__init_A_Unit4__O(); A_arbace_classes_types__init_A_Unit5__O(); A_arbace_classes_types__init_A_Unit6__O(); A_arbace_classes_types__init_A_Unit7__O(); A_arbace_classes_types__init_A_Unit8__O(); A_arbace_classes_types__init_A_Unit9__O(); A_arbace_classes_types__init_A_Unit10__O(); A_arbace_classes_types__init_A_Unit11__O(); A_arbace_classes_types__init_A_Unit12__O(); A_arbace_classes_types__init_A_Unit13__O(); A_arbace_classes_types__init_A_Unit14__O(); A_arbace_classes_types__init_A_Unit15__O(); A_arbace_classes_types__init_A_Unit16__O(); A_arbace_classes_types__init_A_Unit17__O(); A_arbace_classes_types__init_A_Unit18__O(); A_arbace_classes_types__init_A_Unit19__O(); A_arbace_classes_types__init_A_Unit20__O(); A_arbace_classes_types__init_A_Unit21__O(); A_arbace_classes_types__init_A_Unit22__O(); A_arbace_classes_types__init_A_Unit23__O(); A_arbace_classes_types__init_A_Unit24__O(); A_arbace_classes_types__init_A_Unit25__O(); A_arbace_classes_types__init_A_Unit26__O(); A_arbace_classes_types__init_A_Unit27__O(); A_arbace_classes_types__init_A_Unit28__O(); A_arbace_classes_types__init_A_Unit29__O(); A_arbace_classes_types__init_A_Unit30__O(); A_arbace_classes_types__init_A_Unit31__O(); A_arbace_classes_types__init_A_Unit32__O(); A_arbace_classes_types__init_A_Unit33__O(); A_arbace_classes_types__init_A_Unit34__O(); A_arbace_classes_types__init_A_Unit35__O(); A_arbace_classes_types__init_A_Unit36__O(); A_arbace_classes_types__init_A_Unit37__O(); A_arbace_classes_types__init_A_Unit38__O(); A_arbace_classes_types__init_A_Unit39__O(); A_arbace_classes_types__init_A_Unit40__O(); A_arbace_classes_types__init_A_Unit41__O(); A_arbace_classes_types__init_A_Unit42__O(); A_arbace_classes_types__init_A_Unit43__O(); A_arbace_classes_types__init_A_Unit44__O(); A_arbace_classes_types__init_A_Unit45__O(); A_arbace_classes_types__init_A_Unit46__O(); A_arbace_classes_types__init_A_Unit47__O(); A_arbace_classes_types__init_A_Unit48__O(); A_arbace_classes_types__init_A_Unit49__O(); return nil }







func A_arbace_classes_types__init_A_Unit4__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); A_arbace_classes_types__init_A_const_4.BindRoot_O__V(A_arbace_classes_types__init_A_const_5); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_6)); return A_arbace_classes_types__init_A_const_4 }



func A_arbace_classes_types__init_A_Unit5__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_7; var tmp2 any; var root_9 any = A_arbace_classes_types__init_A_const_8.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_13 any; var root_4 any = A_arbace_classes_types__init_A_const_9.GetRawRoot__O(); var linked_5 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_6 lang.IFn; if linked_5 == nil { ifn_6 = lang.IFn_Cast(root_4) } else { ifn_6 = nil }; var arg_7 any; var tmp3 any = A_arbace_classes_types_fn__48000013_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_types_fn__48000013_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_classes_types_fn__48000013_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; arg_7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_8 any = A_arbace_classes_types__init_A_const_4.GetRawRoot__O(); if linked_5 == nil { arg_13 = ifn_6.Invoke_O_O__O(arg_7, arg_8) } else { arg_13 = linked_5.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4, arg_7, arg_8) }; if linked_10 == nil { tmp2 = ifn_11.Invoke_O_O__O(arg_12, arg_13) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_9, arg_12, arg_13) }; tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_classes_types__init_A_const_7; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_10)); return A_arbace_classes_types__init_A_const_7 }

func A_arbace_classes_types__init_A_Unit6__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); A_arbace_classes_types__init_A_const_11.BindRoot_O__V(A_arbace_classes_types__init_A_const_12); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_13)); return A_arbace_classes_types__init_A_const_11 }



func A_arbace_classes_types__init_A_Unit7__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); A_arbace_classes_types__init_A_const_14.BindRoot_O__V(Lit_68); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_15)); return A_arbace_classes_types__init_A_const_14 }
func A_arbace_classes_types__init_A_Unit8__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); A_arbace_classes_types__init_A_const_16.BindRoot_O__V(Lit_69); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_17)); return A_arbace_classes_types__init_A_const_16 }

func A_arbace_classes_types__init_A_Unit9__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); A_arbace_classes_types__init_A_const_18.BindRoot_O__V(Lit_70); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_19)); return A_arbace_classes_types__init_A_const_18 }




func A_arbace_classes_types__init_A_Unit10__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_20; var tmp2 any = A_arbace_classes_types_lang_class_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_types_lang_class_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_classes_types_lang_class_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_21)); return A_arbace_classes_types__init_A_const_20 }
func A_arbace_classes_types__init_A_Unit11__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_22; var tmp2 any = A_arbace_classes_types_lang_desc_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_types_lang_desc_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_classes_types_lang_desc_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_23)); return A_arbace_classes_types__init_A_const_22 }

func A_arbace_classes_types__init_A_Unit12__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_24; var tmp2 any = A_arbace_classes_types_prim_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_types_prim_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_classes_types_prim_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_25)); return A_arbace_classes_types__init_A_const_24 }
func A_arbace_classes_types__init_A_Unit13__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_26; var tmp2 any = A_arbace_classes_types_void_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_types_void_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_classes_types_void_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_27)); return A_arbace_classes_types__init_A_const_26 }
func A_arbace_classes_types__init_A_Unit14__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_28; var tmp2 any = A_arbace_classes_types_array_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_types_array_QMARK__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_classes_types_array_QMARK__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_29)); return A_arbace_classes_types__init_A_const_28 }
func A_arbace_classes_types__init_A_Unit15__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_30; var tmp2 any = A_arbace_classes_types_ref_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_types_ref_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_classes_types_ref_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_31)); return A_arbace_classes_types__init_A_const_30 }
func A_arbace_classes_types__init_A_Unit16__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_32; var tmp2 any = A_arbace_classes_types_class_desc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_types_class_desc_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_classes_types_class_desc_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_33)); return A_arbace_classes_types__init_A_const_32 }

func A_arbace_classes_types__init_A_Unit17__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_34; var tmp2 any = A_arbace_classes_types_internal__GT_desc_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_types_internal__GT_desc_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_classes_types_internal__GT_desc_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_35)); return A_arbace_classes_types__init_A_const_34 }
func A_arbace_classes_types__init_A_Unit18__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_36; var tmp2 any = A_arbace_classes_types_desc__GT_internal_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_types_desc__GT_internal_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_classes_types_desc__GT_internal_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_37)); return A_arbace_classes_types__init_A_const_36 }




func A_arbace_classes_types__init_A_Unit19__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_38; var tmp2 any = A_arbace_classes_types_elem_type_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_types_elem_type_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_classes_types_elem_type_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_39)); return A_arbace_classes_types__init_A_const_38 }
func A_arbace_classes_types__init_A_Unit20__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_40; var tmp2 any = A_arbace_classes_types_array_of_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_types_array_of_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_classes_types_array_of_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_41)); return A_arbace_classes_types__init_A_const_40 }
func A_arbace_classes_types__init_A_Unit21__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_42; var tmp2 any = A_arbace_classes_types_array_dims_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_types_array_dims_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_classes_types_array_dims_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_43)); return A_arbace_classes_types__init_A_const_42 }

func A_arbace_classes_types__init_A_Unit22__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_44; var tmp2 any = A_arbace_classes_types_size_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_types_size_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_classes_types_size_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_45)); return A_arbace_classes_types__init_A_const_44 }

func A_arbace_classes_types__init_A_Unit23__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_46; var tmp2 any = A_arbace_classes_types_int_like_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_types_int_like_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_classes_types_int_like_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_47)); return A_arbace_classes_types__init_A_const_46 }
func A_arbace_classes_types__init_A_Unit24__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_48; var tmp2 any = A_arbace_classes_types_numeric_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_classes_types_numeric_QMARK__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_classes_types_numeric_QMARK__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_49)); return A_arbace_classes_types__init_A_const_48 }

func A_arbace_classes_types__init_A_Unit25__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); A_arbace_classes_types__init_A_const_50.BindRoot_O__V(A_arbace_classes_types__init_A_const_51); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_50; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_52)); return A_arbace_classes_types__init_A_const_50 }


func A_arbace_classes_types__init_A_Unit26__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_53; var tmp2 any; var root_35 any = A_arbace_classes_types__init_A_const_8.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_39 any; var root_30 any = A_arbace_classes_types__init_A_const_9.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var tmp3 any = A_arbace_classes_types_fn__48000037_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_types_fn__48000037_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_classes_types_fn__48000037_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; arg_33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_34 any = A_arbace_classes_types__init_A_const_50.GetRawRoot__O(); if linked_31 == nil { arg_39 = ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { arg_39 = linked_31.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) }; if linked_36 == nil { tmp2 = ifn_37.Invoke_O_O__O(arg_38, arg_39) } else { tmp2 = linked_36.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_35, arg_38, arg_39) }; tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_classes_types__init_A_const_53; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_54)); return A_arbace_classes_types__init_A_const_53 }

func A_arbace_classes_types__init_A_Unit27__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_55; var tmp2 any = A_arbace_classes_types_method_desc_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_classes_types_method_desc_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_classes_types_method_desc_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_56)); return A_arbace_classes_types__init_A_const_55 }

func A_arbace_classes_types__init_A_Unit28__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_57; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_classes_types__init_A_const_57; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_58)); return A_arbace_classes_types__init_A_const_57 }




func A_arbace_classes_types__init_A_Unit29__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_59; var tmp2 any = A_arbace_classes_types_parse_method_desc_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_types_parse_method_desc_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_classes_types_parse_method_desc_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_60)); return A_arbace_classes_types__init_A_const_59 }












func A_arbace_classes_types__init_A_Unit30__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_61; var tmp2 any = A_arbace_classes_types_package_of_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_classes_types_package_of_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_classes_types_package_of_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_62)); return A_arbace_classes_types__init_A_const_61 }


func A_arbace_classes_types__init_A_Unit31__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_63; var tmp2 any = A_arbace_classes_types_simple_name_of_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_types_simple_name_of_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_classes_types_simple_name_of_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_64)); return A_arbace_classes_types__init_A_const_63 }



func A_arbace_classes_types__init_A_Unit32__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_65; var tmp2 any = A_arbace_classes_types_desc__GT_class_name_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_classes_types_desc__GT_class_name_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_classes_types_desc__GT_class_name_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_66)); return A_arbace_classes_types__init_A_const_65 }





func A_arbace_classes_types__init_A_Unit33__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_67; var tmp2 any = A_arbace_classes_types_class__GT_desc_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_types_class__GT_desc_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_classes_types_class__GT_desc_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_68)); return A_arbace_classes_types__init_A_const_67 }
















func A_arbace_classes_types__init_A_Unit34__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_69; var tmp2 any = A_arbace_classes_types_array_sym_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_classes_types_array_sym_QMARK__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_classes_types_array_sym_QMARK__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_70)); return A_arbace_classes_types__init_A_const_69 }


func A_arbace_classes_types__init_A_Unit35__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_72)); return A_arbace_classes_types__init_A_const_71 }

func A_arbace_classes_types__init_A_Unit36__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_73; var tmp2 any = A_arbace_classes_types_with_anns_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_types_with_anns_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_classes_types_with_anns_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_74)); return A_arbace_classes_types__init_A_const_73 }




func A_arbace_classes_types__init_A_Unit37__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_71; var tmp2 any = A_arbace_classes_types_parse_type_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_classes_types_parse_type_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_classes_types_parse_type_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_75)); return A_arbace_classes_types__init_A_const_71 }





































































func A_arbace_classes_types__init_A_Unit38__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_76; var tmp2 any = A_arbace_classes_types_erase_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_types_erase_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_classes_types_erase_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_77)); return A_arbace_classes_types__init_A_const_76 }










func A_arbace_classes_types__init_A_Unit39__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_78; var tmp2 any = A_arbace_classes_types_generic_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_classes_types_generic_QMARK__A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_classes_types_generic_QMARK__A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_79)); return A_arbace_classes_types__init_A_const_78 }










func A_arbace_classes_types__init_A_Unit40__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_80; var tmp2 any = A_arbace_classes_types_local_class_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_types_local_class_name_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_classes_types_local_class_name_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_81)); return A_arbace_classes_types__init_A_const_80 }






func A_arbace_classes_types__init_A_Unit41__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_82; var tmp2 any = A_arbace_classes_types_signature_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_classes_types_signature_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_classes_types_signature_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_83)); return A_arbace_classes_types__init_A_const_82 }
















func A_arbace_classes_types__init_A_Unit42__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_84; var tmp2 any = A_arbace_classes_types_parse_type_params_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_types_parse_type_params_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_classes_types_parse_type_params_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_85)); return A_arbace_classes_types__init_A_const_84 }












func A_arbace_classes_types__init_A_Unit43__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(249, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_86; var tmp2 any = A_arbace_classes_types_type_params_signature_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_classes_types_type_params_signature_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_classes_types_type_params_signature_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_87)); return A_arbace_classes_types__init_A_const_86 }




















func A_arbace_classes_types__init_A_Unit44__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_88; var tmp2 any = A_arbace_classes_types_bounds_map_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_types_bounds_map_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_classes_types_bounds_map_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_89)); return A_arbace_classes_types__init_A_const_88 }

func A_arbace_classes_types__init_A_Unit45__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_90; var tmp2 any = A_arbace_classes_types_desc__GT_tnode_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_classes_types_desc__GT_tnode_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_classes_types_desc__GT_tnode_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_91)); return A_arbace_classes_types__init_A_const_90 }





func A_arbace_classes_types__init_A_Unit46__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(278, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_92; var tmp2 any = A_arbace_classes_types_reflect__GT_tnode_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_types_reflect__GT_tnode_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_classes_types_reflect__GT_tnode_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_93)); return A_arbace_classes_types__init_A_const_92 }




















func A_arbace_classes_types__init_A_Unit47__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_94; var tmp2 any = A_arbace_classes_types_subst_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_classes_types_subst_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_classes_types_subst_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_95)); return A_arbace_classes_types__init_A_const_94 }











func A_arbace_classes_types__init_A_Unit48__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(311, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_96; var tmp2 any = A_arbace_classes_types_type_anns_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_types_type_anns_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_classes_types_type_anns_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_97)); return A_arbace_classes_types__init_A_const_96 }
















func A_arbace_classes_types__init_A_Unit49__O() any { A_arbace_classes_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_classes_types__init_A_const_98; var tmp2 any = A_arbace_classes_types_element_path_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_classes_types_element_path_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_classes_types_element_path_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_types__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_types__init_A_const_99)); return A_arbace_classes_types__init_A_const_98 }



type A_arbace_classes_types__init_A struct{ jrt.Object }

var A_arbace_classes_types__init_A_const_pool *jrt.RefArray

var A_arbace_classes_types__init_A_const_0 *lang.Var

var A_arbace_classes_types__init_A_const_1 any

var A_arbace_classes_types__init_A_const_2 any

var A_arbace_classes_types__init_A_const_3 any

var A_arbace_classes_types__init_A_const_4 *lang.Var

var A_arbace_classes_types__init_A_const_5 any

var A_arbace_classes_types__init_A_const_6 any

var A_arbace_classes_types__init_A_const_7 *lang.Var

var A_arbace_classes_types__init_A_const_8 *lang.Var

var A_arbace_classes_types__init_A_const_9 *lang.Var

var A_arbace_classes_types__init_A_const_10 any

var A_arbace_classes_types__init_A_const_11 *lang.Var

var A_arbace_classes_types__init_A_const_12 any

var A_arbace_classes_types__init_A_const_13 any

var A_arbace_classes_types__init_A_const_14 *lang.Var

var A_arbace_classes_types__init_A_const_15 any

var A_arbace_classes_types__init_A_const_16 *lang.Var

var A_arbace_classes_types__init_A_const_17 any

var A_arbace_classes_types__init_A_const_18 *lang.Var

var A_arbace_classes_types__init_A_const_19 any

var A_arbace_classes_types__init_A_const_20 *lang.Var

var A_arbace_classes_types__init_A_const_21 any

var A_arbace_classes_types__init_A_const_22 *lang.Var

var A_arbace_classes_types__init_A_const_23 any

var A_arbace_classes_types__init_A_const_24 *lang.Var

var A_arbace_classes_types__init_A_const_25 any

var A_arbace_classes_types__init_A_const_26 *lang.Var

var A_arbace_classes_types__init_A_const_27 any

var A_arbace_classes_types__init_A_const_28 *lang.Var

var A_arbace_classes_types__init_A_const_29 any

var A_arbace_classes_types__init_A_const_30 *lang.Var

var A_arbace_classes_types__init_A_const_31 any

var A_arbace_classes_types__init_A_const_32 *lang.Var

var A_arbace_classes_types__init_A_const_33 any

var A_arbace_classes_types__init_A_const_34 *lang.Var

var A_arbace_classes_types__init_A_const_35 any

var A_arbace_classes_types__init_A_const_36 *lang.Var

var A_arbace_classes_types__init_A_const_37 any

var A_arbace_classes_types__init_A_const_38 *lang.Var

var A_arbace_classes_types__init_A_const_39 any

var A_arbace_classes_types__init_A_const_40 *lang.Var

var A_arbace_classes_types__init_A_const_41 any

var A_arbace_classes_types__init_A_const_42 *lang.Var

var A_arbace_classes_types__init_A_const_43 any

var A_arbace_classes_types__init_A_const_44 *lang.Var

var A_arbace_classes_types__init_A_const_45 any

var A_arbace_classes_types__init_A_const_46 *lang.Var

var A_arbace_classes_types__init_A_const_47 any

var A_arbace_classes_types__init_A_const_48 *lang.Var

var A_arbace_classes_types__init_A_const_49 any

var A_arbace_classes_types__init_A_const_50 *lang.Var

var A_arbace_classes_types__init_A_const_51 any

var A_arbace_classes_types__init_A_const_52 any

var A_arbace_classes_types__init_A_const_53 *lang.Var

var A_arbace_classes_types__init_A_const_54 any

var A_arbace_classes_types__init_A_const_55 *lang.Var

var A_arbace_classes_types__init_A_const_56 any

var A_arbace_classes_types__init_A_const_57 *lang.Var

var A_arbace_classes_types__init_A_const_58 any

var A_arbace_classes_types__init_A_const_59 *lang.Var

var A_arbace_classes_types__init_A_const_60 any

var A_arbace_classes_types__init_A_const_61 *lang.Var

var A_arbace_classes_types__init_A_const_62 any

var A_arbace_classes_types__init_A_const_63 *lang.Var

var A_arbace_classes_types__init_A_const_64 any

var A_arbace_classes_types__init_A_const_65 *lang.Var

var A_arbace_classes_types__init_A_const_66 any

var A_arbace_classes_types__init_A_const_67 *lang.Var

var A_arbace_classes_types__init_A_const_68 any

var A_arbace_classes_types__init_A_const_69 *lang.Var

var A_arbace_classes_types__init_A_const_70 any

var A_arbace_classes_types__init_A_const_71 *lang.Var

var A_arbace_classes_types__init_A_const_72 any

var A_arbace_classes_types__init_A_const_73 *lang.Var

var A_arbace_classes_types__init_A_const_74 any

var A_arbace_classes_types__init_A_const_75 any

var A_arbace_classes_types__init_A_const_76 *lang.Var

var A_arbace_classes_types__init_A_const_77 any

var A_arbace_classes_types__init_A_const_78 *lang.Var

var A_arbace_classes_types__init_A_const_79 any

var A_arbace_classes_types__init_A_const_80 *lang.Var

var A_arbace_classes_types__init_A_const_81 any

var A_arbace_classes_types__init_A_const_82 *lang.Var

var A_arbace_classes_types__init_A_const_83 any

var A_arbace_classes_types__init_A_const_84 *lang.Var

var A_arbace_classes_types__init_A_const_85 any

var A_arbace_classes_types__init_A_const_86 *lang.Var

var A_arbace_classes_types__init_A_const_87 any

var A_arbace_classes_types__init_A_const_88 *lang.Var

var A_arbace_classes_types__init_A_const_89 any

var A_arbace_classes_types__init_A_const_90 *lang.Var

var A_arbace_classes_types__init_A_const_91 any

var A_arbace_classes_types__init_A_const_92 *lang.Var

var A_arbace_classes_types__init_A_const_93 any

var A_arbace_classes_types__init_A_const_94 *lang.Var

var A_arbace_classes_types__init_A_const_95 any

var A_arbace_classes_types__init_A_const_96 *lang.Var

var A_arbace_classes_types__init_A_const_97 any

var A_arbace_classes_types__init_A_const_98 *lang.Var

var A_arbace_classes_types__init_A_const_99 any

var A_arbace_classes_types__init_A_init jrt.ClassInit

func A_arbace_classes_types__init_A_Init() { if !A_arbace_classes_types__init_A_init.Done() { A_arbace_classes_types__init_A_init.Run(A_arbace_classes_types__init_A_clinit) } }

func A_arbace_classes_types__init_A_clinit() { A_arbace_classes_types__init_A_clinit_p0(); A_arbace_classes_types__init_A_clinit_p1(); A_arbace_classes_types__init_A_clinit_p2(); A_arbace_classes_types__init_A_clinit_p3(); A_arbace_classes_types__init_A_clinit_p4(); A_arbace_classes_types__init_A_clinit_p5(); A_arbace_classes_types__init_A_clinit_p6(); A_arbace_classes_types__init_A_clinit_p7() }

func A_arbace_classes_types__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_types__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_64, 145); A_arbace_classes_types__init_A_const_0 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[45]); A_arbace_classes_types__init_A_const_1 = A_arbace_classes_types__init_A_const_pool.A[46]; A_arbace_classes_types__init_A_const_2 = A_arbace_classes_types__init_A_const_pool.A[47]; A_arbace_classes_types__init_A_const_3 = A_arbace_classes_types__init_A_const_pool.A[48]; A_arbace_classes_types__init_A_const_4 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[49]); A_arbace_classes_types__init_A_const_5 = A_arbace_classes_types__init_A_const_pool.A[50]; A_arbace_classes_types__init_A_const_6 = A_arbace_classes_types__init_A_const_pool.A[51]; A_arbace_classes_types__init_A_const_7 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[52]); A_arbace_classes_types__init_A_const_8 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[53]); A_arbace_classes_types__init_A_const_9 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[54]); A_arbace_classes_types__init_A_const_10 = A_arbace_classes_types__init_A_const_pool.A[55]; A_arbace_classes_types__init_A_const_11 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[56]); A_arbace_classes_types__init_A_const_12 = A_arbace_classes_types__init_A_const_pool.A[57] }

func A_arbace_classes_types__init_A_clinit_p1() { A_arbace_classes_types__init_A_const_13 = A_arbace_classes_types__init_A_const_pool.A[58]; A_arbace_classes_types__init_A_const_14 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[59]); A_arbace_classes_types__init_A_const_15 = A_arbace_classes_types__init_A_const_pool.A[60]; A_arbace_classes_types__init_A_const_16 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[61]); A_arbace_classes_types__init_A_const_17 = A_arbace_classes_types__init_A_const_pool.A[62]; A_arbace_classes_types__init_A_const_18 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[63]); A_arbace_classes_types__init_A_const_19 = A_arbace_classes_types__init_A_const_pool.A[64]; A_arbace_classes_types__init_A_const_20 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[65]); A_arbace_classes_types__init_A_const_21 = A_arbace_classes_types__init_A_const_pool.A[66]; A_arbace_classes_types__init_A_const_22 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[67]); A_arbace_classes_types__init_A_const_23 = A_arbace_classes_types__init_A_const_pool.A[68]; A_arbace_classes_types__init_A_const_24 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[69]); A_arbace_classes_types__init_A_const_25 = A_arbace_classes_types__init_A_const_pool.A[70] }

func A_arbace_classes_types__init_A_clinit_p2() { A_arbace_classes_types__init_A_const_26 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[71]); A_arbace_classes_types__init_A_const_27 = A_arbace_classes_types__init_A_const_pool.A[72]; A_arbace_classes_types__init_A_const_28 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[73]); A_arbace_classes_types__init_A_const_29 = A_arbace_classes_types__init_A_const_pool.A[74]; A_arbace_classes_types__init_A_const_30 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[75]); A_arbace_classes_types__init_A_const_31 = A_arbace_classes_types__init_A_const_pool.A[76]; A_arbace_classes_types__init_A_const_32 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[77]); A_arbace_classes_types__init_A_const_33 = A_arbace_classes_types__init_A_const_pool.A[78]; A_arbace_classes_types__init_A_const_34 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[79]); A_arbace_classes_types__init_A_const_35 = A_arbace_classes_types__init_A_const_pool.A[80]; A_arbace_classes_types__init_A_const_36 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[81]); A_arbace_classes_types__init_A_const_37 = A_arbace_classes_types__init_A_const_pool.A[82]; A_arbace_classes_types__init_A_const_38 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[83]) }

func A_arbace_classes_types__init_A_clinit_p3() { A_arbace_classes_types__init_A_const_39 = A_arbace_classes_types__init_A_const_pool.A[84]; A_arbace_classes_types__init_A_const_40 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[85]); A_arbace_classes_types__init_A_const_41 = A_arbace_classes_types__init_A_const_pool.A[86]; A_arbace_classes_types__init_A_const_42 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[87]); A_arbace_classes_types__init_A_const_43 = A_arbace_classes_types__init_A_const_pool.A[88]; A_arbace_classes_types__init_A_const_44 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[89]); A_arbace_classes_types__init_A_const_45 = A_arbace_classes_types__init_A_const_pool.A[90]; A_arbace_classes_types__init_A_const_46 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[91]); A_arbace_classes_types__init_A_const_47 = A_arbace_classes_types__init_A_const_pool.A[92]; A_arbace_classes_types__init_A_const_48 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[93]); A_arbace_classes_types__init_A_const_49 = A_arbace_classes_types__init_A_const_pool.A[94]; A_arbace_classes_types__init_A_const_50 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[95]); A_arbace_classes_types__init_A_const_51 = A_arbace_classes_types__init_A_const_pool.A[96]; A_arbace_classes_types__init_A_const_52 = A_arbace_classes_types__init_A_const_pool.A[97] }

func A_arbace_classes_types__init_A_clinit_p4() { A_arbace_classes_types__init_A_const_53 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[98]); A_arbace_classes_types__init_A_const_54 = A_arbace_classes_types__init_A_const_pool.A[99]; A_arbace_classes_types__init_A_const_55 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[100]); A_arbace_classes_types__init_A_const_56 = A_arbace_classes_types__init_A_const_pool.A[101]; A_arbace_classes_types__init_A_const_57 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[102]); A_arbace_classes_types__init_A_const_58 = A_arbace_classes_types__init_A_const_pool.A[103]; A_arbace_classes_types__init_A_const_59 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[104]); A_arbace_classes_types__init_A_const_60 = A_arbace_classes_types__init_A_const_pool.A[105]; A_arbace_classes_types__init_A_const_61 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[106]); A_arbace_classes_types__init_A_const_62 = A_arbace_classes_types__init_A_const_pool.A[107]; A_arbace_classes_types__init_A_const_63 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[108]); A_arbace_classes_types__init_A_const_64 = A_arbace_classes_types__init_A_const_pool.A[109]; A_arbace_classes_types__init_A_const_65 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[110]) }

func A_arbace_classes_types__init_A_clinit_p5() { A_arbace_classes_types__init_A_const_66 = A_arbace_classes_types__init_A_const_pool.A[111]; A_arbace_classes_types__init_A_const_67 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[112]); A_arbace_classes_types__init_A_const_68 = A_arbace_classes_types__init_A_const_pool.A[113]; A_arbace_classes_types__init_A_const_69 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[114]); A_arbace_classes_types__init_A_const_70 = A_arbace_classes_types__init_A_const_pool.A[115]; A_arbace_classes_types__init_A_const_71 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[116]); A_arbace_classes_types__init_A_const_72 = A_arbace_classes_types__init_A_const_pool.A[117]; A_arbace_classes_types__init_A_const_73 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[118]); A_arbace_classes_types__init_A_const_74 = A_arbace_classes_types__init_A_const_pool.A[119]; A_arbace_classes_types__init_A_const_75 = A_arbace_classes_types__init_A_const_pool.A[120]; A_arbace_classes_types__init_A_const_76 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[121]); A_arbace_classes_types__init_A_const_77 = A_arbace_classes_types__init_A_const_pool.A[122]; A_arbace_classes_types__init_A_const_78 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[123]); A_arbace_classes_types__init_A_const_79 = A_arbace_classes_types__init_A_const_pool.A[124] }

func A_arbace_classes_types__init_A_clinit_p6() { A_arbace_classes_types__init_A_const_80 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[125]); A_arbace_classes_types__init_A_const_81 = A_arbace_classes_types__init_A_const_pool.A[126]; A_arbace_classes_types__init_A_const_82 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[127]); A_arbace_classes_types__init_A_const_83 = A_arbace_classes_types__init_A_const_pool.A[128]; A_arbace_classes_types__init_A_const_84 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[129]); A_arbace_classes_types__init_A_const_85 = A_arbace_classes_types__init_A_const_pool.A[130]; A_arbace_classes_types__init_A_const_86 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[131]); A_arbace_classes_types__init_A_const_87 = A_arbace_classes_types__init_A_const_pool.A[132]; A_arbace_classes_types__init_A_const_88 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[133]); A_arbace_classes_types__init_A_const_89 = A_arbace_classes_types__init_A_const_pool.A[134]; A_arbace_classes_types__init_A_const_90 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[135]); A_arbace_classes_types__init_A_const_91 = A_arbace_classes_types__init_A_const_pool.A[136]; A_arbace_classes_types__init_A_const_92 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[137]) }

func A_arbace_classes_types__init_A_clinit_p7() { A_arbace_classes_types__init_A_const_93 = A_arbace_classes_types__init_A_const_pool.A[138]; A_arbace_classes_types__init_A_const_94 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[139]); A_arbace_classes_types__init_A_const_95 = A_arbace_classes_types__init_A_const_pool.A[140]; A_arbace_classes_types__init_A_const_96 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[141]); A_arbace_classes_types__init_A_const_97 = A_arbace_classes_types__init_A_const_pool.A[142]; A_arbace_classes_types__init_A_const_98 = lang.Var_Cast(A_arbace_classes_types__init_A_const_pool.A[143]); A_arbace_classes_types__init_A_const_99 = A_arbace_classes_types__init_A_const_pool.A[144] }

func A_arbace_classes_types__init_A_New() *A_arbace_classes_types__init_A { A_arbace_classes_types__init_A_Init(); t := &A_arbace_classes_types__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types__init_A) Ctor() {}

func (t *A_arbace_classes_types__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types__init_A_class }

func (t *A_arbace_classes_types__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types__init_A); return ok }

func A_arbace_classes_types__init_A_Cast(x any) *A_arbace_classes_types__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types__init_A_class)) }; return v }
