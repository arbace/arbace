//line aot_arbace_classes_types.ae:1
package aot_arbace_classes_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New() *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A { A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_Init(); t := &A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :1:1
func A_arbace_classes_types_eval48000008_fn__48000009_A_New() *A_arbace_classes_types_eval48000008_fn__48000009_A { A_arbace_classes_types_eval48000008_fn__48000009_A_Init(); t := &A_arbace_classes_types_eval48000008_fn__48000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }















func A_arbace_classes_types_fn__48000013_A_New() *A_arbace_classes_types_fn__48000013_A { A_arbace_classes_types_fn__48000013_A_Init(); t := &A_arbace_classes_types_fn__48000013_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Ctor() {}
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Invoke_O_O__O(self, p__48000012__0 any) any { var vec__48000014__2 any = p__48000012__0; var k__3 any = lang.RT_Nth_O_I_O__O(vec__48000014__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__48000014__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_9; return lang.Tuple_Create_O_O__IPersistentVector(v__4, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(k__3)) }













func A_arbace_classes_types_lang_class_A_New() *A_arbace_classes_types_lang_class_A { A_arbace_classes_types_lang_class_A_Init(); t := &A_arbace_classes_types_lang_class_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Ctor() {}
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Invoke_O_O__O(self, simple__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_125, nil); var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_10; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, jrt.NN(tmp2).GetRawRoot__O(), nil, simple__0)).Ref() }
func A_arbace_classes_types_lang_desc_A_New() *A_arbace_classes_types_lang_desc_A { A_arbace_classes_types_lang_desc_A_Init(); t := &A_arbace_classes_types_lang_desc_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Ctor() {}
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Invoke_O_O__O(self, simple__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_125, nil, Lit_127); var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_10; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp2).GetRawRoot__O(), nil, simple__0, nil)).Ref() }

func A_arbace_classes_types_prim_QMARK__A_New() *A_arbace_classes_types_prim_QMARK__A { A_arbace_classes_types_prim_QMARK__A_Init(); t := &A_arbace_classes_types_prim_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_11; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(t__0))); if and__1927000168__auto____3 { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_12; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_132) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_void_QMARK__A_New() *A_arbace_classes_types_void_QMARK__A { A_arbace_classes_types_void_QMARK__A_Init(); t := &A_arbace_classes_types_void_QMARK__A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Ctor() {}
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(t__0, Lit_132)).Ref() }
func A_arbace_classes_types_array_QMARK__A_New() *A_arbace_classes_types_array_QMARK__A { A_arbace_classes_types_array_QMARK__A_Init(); t := &A_arbace_classes_types_array_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_11; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_13; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_116) } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_ref_QMARK__A_New() *A_arbace_classes_types_ref_QMARK__A { A_arbace_classes_types_ref_QMARK__A_Init(); t := &A_arbace_classes_types_ref_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 bool; var tmp1 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_14; or__1927000174__auto____2 = lang.Util_Equiv_O_O__Z(t__0, tmp1.Ref()); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_11; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_13; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_126); if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_15; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t__0) } } else { return and__1927000168__auto____3 } } }
func A_arbace_classes_types_class_desc_QMARK__A_New() *A_arbace_classes_types_class_desc_QMARK__A { A_arbace_classes_types_class_desc_QMARK__A_Init(); t := &A_arbace_classes_types_class_desc_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_11; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_13; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_126) } else { return and__1927000168__auto____2 } }

func A_arbace_classes_types_internal__GT_desc_A_New() *A_arbace_classes_types_internal__GT_desc_A { A_arbace_classes_types_internal__GT_desc_A_Init(); t := &A_arbace_classes_types_internal__GT_desc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_116)) { return n__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref() } }
func A_arbace_classes_types_desc__GT_internal_A_New() *A_arbace_classes_types_desc__GT_internal_A { A_arbace_classes_types_desc__GT_internal_A_Init(); t := &A_arbace_classes_types_desc__GT_internal_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Ctor() {}
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(d__0, Lit_126)) { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_16; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_17; var tmp5 any = tmp4; return tmp3.Invoke_O_O_O__O(d__0, tmp5, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(d__0)))).Ref()) } else { return d__0
	} }
func A_arbace_classes_types_elem_type_A_New() *A_arbace_classes_types_elem_type_A { A_arbace_classes_types_elem_type_A_Init(); t := &A_arbace_classes_types_elem_type_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_17; return tmp2.Invoke_O_O__O(d__0, tmp3) }
func A_arbace_classes_types_array_of_A_New() *A_arbace_classes_types_array_of_A { A_arbace_classes_types_array_of_A_Init(); t := &A_arbace_classes_types_array_of_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Invoke_O_O__O(self, d__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_116, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__0)).Ref() }
func A_arbace_classes_types_array_dims_A_New() *A_arbace_classes_types_array_dims_A { A_arbace_classes_types_array_dims_A_Init(); t := &A_arbace_classes_types_array_dims_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_array_dims_fn__48000030_A_New(); var tmp4 *jrt.Class; A_arbace_classes_types_array_dims_fn__48000030_A_Init(); tmp4 = A_arbace_classes_types_array_dims_fn__48000030_A_fn_class; return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), d__0))).Ref() }
//line :48:1
func A_arbace_classes_types_array_dims_fn__48000030_A_New() *A_arbace_classes_types_array_dims_fn__48000030_A { A_arbace_classes_types_array_dims_fn__48000030_A_Init(); t := &A_arbace_classes_types_array_dims_fn__48000030_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Invoke_O_O__O(self, p1__48000029_SHARP___1 any) any { var tmp1 any; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_19; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, p1__48000029_SHARP___1)).Ref() }

func A_arbace_classes_types_size_A_New() *A_arbace_classes_types_size_A { A_arbace_classes_types_size_A_Init(); t := &A_arbace_classes_types_size_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_classes_types_size_A) Ctor() {}
//line :50:1
func (t *A_arbace_classes_types_size_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z(t__0, Lit_195); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z(t__0, Lit_196) }; if tmp1 { A_arbace_classes_types_A_Init(); return A_arbace_classes_types_A_const_20 } else { if lang.Util_Equiv_O_O__Z(t__0, Lit_132) { A_arbace_classes_types_A_Init(); return A_arbace_classes_types_A_const_21 } else { A_arbace_classes_types_A_Init(); return A_arbace_classes_types_A_const_17 } } }

func A_arbace_classes_types_int_like_QMARK__A_New() *A_arbace_classes_types_int_like_QMARK__A { A_arbace_classes_types_int_like_QMARK__A_Init(); t := &A_arbace_classes_types_int_like_QMARK__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_23; return tmp2.Invoke_O_O__O(tmp3, t__0) }
func A_arbace_classes_types_numeric_QMARK__A_New() *A_arbace_classes_types_numeric_QMARK__A { A_arbace_classes_types_numeric_QMARK__A_Init(); t := &A_arbace_classes_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_24; return tmp2.Invoke_O_O__O(tmp3, t__0) }




func A_arbace_classes_types_fn__48000037_A_New() *A_arbace_classes_types_fn__48000037_A { A_arbace_classes_types_fn__48000037_A_Init(); t := &A_arbace_classes_types_fn__48000037_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Ctor() {}
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Invoke_O_O__O(self, p__48000036__0 any) any { var vec__48000038__2 any = p__48000036__0; var k__3 any = lang.RT_Nth_O_I_O__O(vec__48000038__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__48000038__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_25; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__4), k__3) }

func A_arbace_classes_types_method_desc_A_New() *A_arbace_classes_types_method_desc_A { A_arbace_classes_types_method_desc_A_Init(); t := &A_arbace_classes_types_method_desc_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Invoke_O_O_O__O(self, params__0, ret__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_150, nil, Lit_151, nil); var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_26; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_27; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O__O(jrt.NN(tmp4).GetRawRoot__O(), params__0), nil, ret__1)).Ref() }

func A_arbace_classes_types_parse_method_desc_A_New() *A_arbace_classes_types_parse_method_desc_A { A_arbace_classes_types_parse_method_desc_A_Init(); t := &A_arbace_classes_types_parse_method_desc_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_types_parse_method_desc_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_types_parse_method_desc_A) Invoke_O_O__O(self, d__0 any) any { { var i__2 any = lang.RT_Box_J__Number(1); var ps__3 any; lang.PersistentVector_Init(); ps__3 = lang.PersistentVector_EMPTY.Ref(); L1: for {



	var tmp1 any; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_28; if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(tmp1)).CharValue__C(), jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__2))) { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_16; return lang.Tuple_Create_O_O__IPersistentVector(ps__3, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(d__0, lang.Numbers_Inc_O__Number(i__2))) } else { var j__4 any; var tmp3 any = A_arbace_classes_types_parse_method_desc_fn__48000045_A_New_O_O(d__0, i__2); var tmp4 *jrt.Class

		A_arbace_classes_types_parse_method_desc_fn__48000045_A_Init(); tmp4 = A_arbace_classes_types_parse_method_desc_fn__48000045_A_fn_class; j__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :66:1
		var end__5 any; var tmp5 any


		A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_29; if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(tmp5)).CharValue__C(), jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))) { end__5 = lang.Numbers_Inc_O__Number(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(d__0, Lit_155, jrt.RefArrayOf(jrt.Object_class, Lit_127, j__4))) } else { end__5 = lang.Numbers_Inc_O__Number(j__4) }
		var tmp6 *lang.Var; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_6; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_16; i__2, ps__3 = end__5, tmp7.Invoke_O_O__O(ps__3, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O_O__O(d__0, i__2, end__5)); continue L1 } } }; /*line :62:1*/panic("a2g: unreachable") }





func A_arbace_classes_types_parse_method_desc_fn__48000045_A_New_O_O(p0, p1 any) *A_arbace_classes_types_parse_method_desc_fn__48000045_A { A_arbace_classes_types_parse_method_desc_fn__48000045_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :68:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :68:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 any; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_19; var tmp2 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(tmp1)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I(j__1))) { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; panic("a2g: unreachable") }



func A_arbace_classes_types_package_of_A_New() *A_arbace_classes_types_package_of_A { A_arbace_classes_types_package_of_A_Init(); t := &A_arbace_classes_types_package_of_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_classes_types_package_of_A) Ctor() {}
//line :72:1
func (t *A_arbace_classes_types_package_of_A) Invoke_O_O__O(self, internal__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_125); if
											lang.Numbers_IsNeg_J__Z(int64(i__2)) { return Lit_135 } else { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_21; var tmp4 any = tmp3; return tmp2.Invoke_O_O_O__O(internal__0, tmp4, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_classes_types_simple_name_of_A_New() *A_arbace_classes_types_simple_name_of_A { A_arbace_classes_types_simple_name_of_A_Init(); t := &A_arbace_classes_types_simple_name_of_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_types_simple_name_of_A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_types_simple_name_of_A) Invoke_O_O__O(self, internal__0 any) any { var n__2 any; var tmp1 *lang.Var;
												A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_16; n__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(internal__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_125)))).Ref()); var tmp2 /*line :77:1*/*lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_16; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(n__2, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(n__2)).LastIndexOf_String__I(Lit_148)))).Ref()) }

func A_arbace_classes_types_desc__GT_class_name_A_New() *A_arbace_classes_types_desc__GT_class_name_A { A_arbace_classes_types_desc__GT_class_name_A_Init(); t := &A_arbace_classes_types_desc__GT_class_name_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Ctor() {}
//line :79:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0)) { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_30; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(d__0, Lit_125, Lit_124) } else { var tmp3 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_31; if tmp3 != nil {
		var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_30; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_32; return tmp5.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(d__0), Lit_125, Lit_124) } else {
//line :82:1
			return nil
		}
	} }
func A_arbace_classes_types_class__GT_desc_A_New() *A_arbace_classes_types_class__GT_desc_A { A_arbace_classes_types_class__GT_desc_A_Init(); t := &A_arbace_classes_types_class__GT_desc_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_classes_types_class__GT_desc_A) Ctor() {}
//line :85:1
func (t *A_arbace_classes_types_class__GT_desc_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.NN(jrt.Class_Cast(c__0)).IsPrimitive__Z() { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_33; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_34; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref())) } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {
		var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_30; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_124, Lit_125) } else {
//line :86:1
			var tmp5 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_31; if tmp5 != nil {

				var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127); var tmp7 *lang.Var; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_30; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_124, Lit_125), nil)).Ref() } else {
//line :86:1
					return nil
				}
		}
	}
}











func A_arbace_classes_types_array_sym_QMARK__A_New() *A_arbace_classes_types_array_sym_QMARK__A { A_arbace_classes_types_array_sym_QMARK__A_Init(); t := &A_arbace_classes_types_array_sym_QMARK__A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Ctor() {}
//line :102:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;
											A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_35; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_36; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_37; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_38; var tmp6 any = tmp5; var tmp7 *lang.Var; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_9; return tmp4.Invoke_O_O__O(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(s__0)) } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_classes_types_with_anns_A_New() *A_arbace_classes_types_with_anns_A { A_arbace_classes_types_with_anns_A_Init(); t := &A_arbace_classes_types_with_anns_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_classes_types_with_anns_A) Ctor() {}
//line :107:1
func (t *A_arbace_classes_types_with_anns_A) Invoke_O_O_O__O(self, tn__0, form__1 any) any { var m__3 any = lang.RT_Meta_O__IPersistentMap(form__1); var anns__4 any; if

	jrt.A2g_Truth(m__3) { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_42; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_classes_types_with_anns_fn__48000054_A_New(); var tmp8 *jrt.Class; A_arbace_classes_types_with_anns_fn__48000054_A_Init(); tmp8 = A_arbace_classes_types_with_anns_fn__48000054_A_fn_class; anns__4 = tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), m__3)) } else { anns__4 = nil }; var tmp9 /*line :110:1*/*lang.Var; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(anns__4)) { var tmp10 *lang.Var; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_41; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_43; return tmp11.Invoke_O_O_O__O(tn__0, tmp12.Ref(), anns__4) } else { return tn__0 } }
//line :109:1
func A_arbace_classes_types_with_anns_fn__48000054_A_New() *A_arbace_classes_types_with_anns_fn__48000054_A { A_arbace_classes_types_with_anns_fn__48000054_A_Init(); t := &A_arbace_classes_types_with_anns_fn__48000054_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_classes_types_with_anns_fn__48000054_A) Ctor() {}
//line :109:1
func (t *A_arbace_classes_types_with_anns_fn__48000054_A) Invoke_O_O__O(self, p__48000053__1 any) any { var vec__48000055__2 any = p__48000053__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__48000055__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__48000055__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; _ = ___4; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_35; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(k__3) }


func A_arbace_classes_types_parse_type_A_New() *A_arbace_classes_types_parse_type_A { A_arbace_classes_types_parse_type_A_Init(); t := &A_arbace_classes_types_parse_type_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_classes_types_parse_type_A) Ctor() {}
//line :112:1
func (t *A_arbace_classes_types_parse_type_A) Invoke_O_O_O__O(self, scope__0, form__1 any) any {



	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_44; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var tmp4 any; var and__1927000168__auto____3 any; var tmp5 *lang.Var

	A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_35; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp6 *lang.Var; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_33; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp7 *lang.Var; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_36; tmp4 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(form__1), nil)).Ref() } else { tmp4 = and__1927000168__auto____4 } } else { tmp4 = and__1927000168__auto____3 }
//line :117:1
	if jrt.A2g_Truth(tmp4) { var tmp8 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_45; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_46; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_47; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_classes_types_A_Init(); tmp14 = A_arbace_classes_types_A_const_33; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, tmp13, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(form__1))) } else { var tmp15 *lang.Var; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_48; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(form__1)) { var base__3 any; var tmp16 *lang.Var




		A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_34; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_classes_types_A_Init(); tmp18 = A_arbace_classes_types_A_const_36; base__3 = tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(form__1))
//line :117:1
		var n__4 any; var tmp19 *lang.Var





		A_arbace_classes_types_A_Init(); tmp19 = A_arbace_classes_types_A_const_49; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_9; n__4 = tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(form__1))
		var tmp22 *lang.Var; A_arbace_classes_types_A_Init(); tmp22 = A_arbace_classes_types_A_const_50; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any = A_arbace_classes_types_parse_type_fn__48000063_A_New(); var tmp25 *jrt.Class; A_arbace_classes_types_parse_type_fn__48000063_A_Init(); tmp25 = A_arbace_classes_types_parse_type_fn__48000063_A_fn_class; var tmp26 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var tmp27 *lang.Var; A_arbace_classes_types_A_Init(); tmp27 = A_arbace_classes_types_A_const_64; tmp3 = lang.RT_Nth_O_I__O(tmp23.Invoke_O_O__O(tmp26, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O__O(scope__0, base__3)), lang.RT_IntCast_O__I(n__4)) } else {
//line :117:1
			var tmp28 any; var and__1927000168__auto____3_2 any; var tmp29 *lang.Var








			A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_35; and__1927000168__auto____3_2 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____3_2) { var tmp30 *lang.Var; A_arbace_classes_types_A_Init(); tmp30 = A_arbace_classes_types_A_const_51; tmp28 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(form__1) } else { tmp28 = and__1927000168__auto____3_2 }
//line :117:1
			if jrt.A2g_Truth(tmp28) { var d__3 any; var tmp31 *lang.Var









				A_arbace_classes_types_A_Init(); tmp31 = A_arbace_classes_types_A_const_51; d__3 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(form__1)
				if lang.Util_Equiv_O_O__Z(d__3, Lit_158) { var tmp32 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp32 = A_arbace_classes_types_A_const_45; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp34 = A_arbace_classes_types_A_const_52; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp36 = A_arbace_classes_types_A_const_53; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp38 = A_arbace_classes_types_A_const_45; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp40 = A_arbace_classes_types_A_const_54; var tmp41 any = tmp40.Ref(); var tmp42 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp42 = A_arbace_classes_types_A_const_55; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp44 = A_arbace_classes_types_A_const_56; var tmp45 any = tmp44.Ref(); var tmp46 *lang.PersistentVector; lang.PersistentVector_Init(); tmp46 = lang.PersistentVector_EMPTY; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp35, tmp37, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp39, tmp41, tmp43, Lit_159, tmp45, tmp46.Ref())))) } else { var tmp47 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp47 = A_arbace_classes_types_A_const_45; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp49 = A_arbace_classes_types_A_const_52; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp51 = A_arbace_classes_types_A_const_53; var tmp52 any = tmp51.Ref(); var tmp53 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp53 = A_arbace_classes_types_A_const_45; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp55 = A_arbace_classes_types_A_const_46; var tmp56 any = tmp55.Ref(); var tmp57 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp57 = A_arbace_classes_types_A_const_47; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Var; A_arbace_classes_types_A_Init(); tmp59 = A_arbace_classes_types_A_const_16; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_classes_types_A_Init(); tmp61 = A_arbace_classes_types_A_const_17; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp50, tmp52, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp54, tmp56, tmp58, tmp60.Invoke_O_O__O(d__3, tmp61))))) } } else {
//line :117:1
					var tmp62 any; A_arbace_classes_types_A_Init(); tmp62 = A_arbace_classes_types_A_const_57; if lang.Util_Equiv_O_O__Z(form__1, tmp62) { A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_58 } else { var tmp63 any; var and__1927000168__auto____3_3 any; var tmp64 *lang.Var
















						A_arbace_classes_types_A_Init(); tmp64 = A_arbace_classes_types_A_const_35; and__1927000168__auto____3_3 = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____3_3) { var tmp65 *lang.Var; A_arbace_classes_types_A_Init(); tmp65 = A_arbace_classes_types_A_const_22; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp67 = A_arbace_classes_types_A_const_81; tmp63 = tmp66.Invoke_O_O__O(jrt.NN(tmp67).Invoke_O__O(scope__0), form__1) } else { tmp63 = and__1927000168__auto____3_3 }
//line :117:1
						if jrt.A2g_Truth(tmp63) { var tmp68 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp68 = A_arbace_classes_types_A_const_45; var tmp69 any = tmp68.Ref(); var tmp70 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp70 = A_arbace_classes_types_A_const_59; var tmp71 any = tmp70.Ref(); var tmp72 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp72 = A_arbace_classes_types_A_const_60; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp69, tmp71, tmp72.Ref(), form__1)) } else { var tmp73 *lang.Var; A_arbace_classes_types_A_Init(); tmp73 = A_arbace_classes_types_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(form__1)) { var temp__1927000408__auto____3 any; var tmp74 *lang.Keyword




















							A_arbace_classes_types_A_Init(); tmp74 = A_arbace_classes_types_A_const_61; temp__1927000408__auto____3 = lang.IFn_Cast(jrt.NN(tmp74).Invoke_O__O(scope__0)).Invoke_O__O(form__1); if jrt.A2g_Truth(temp__1927000408__auto____3) { var n__4_2 any = temp__1927000408__auto____3; var o__5 any; var temp__1927000414__auto____5 any; var tmp75 *lang.Keyword
								A_arbace_classes_types_A_Init(); tmp75 = A_arbace_classes_types_A_const_62; temp__1927000414__auto____5 = jrt.NN(tmp75).Invoke_O__O(scope__0); if jrt.A2g_Truth(temp__1927000414__auto____5) { var f__6 any = temp__1927000414__auto____5; o__5 = lang.IFn_Cast(f__6).Invoke_O__O(n__4_2) } else { o__5 = nil }
//line :138:1
								var G__48000065__6_ any; var tmp76 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp76 = A_arbace_classes_types_A_const_45; var tmp77 any = tmp76.Ref(); var tmp78 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp78 = A_arbace_classes_types_A_const_54; var tmp79 any = tmp78.Ref(); var tmp80 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp80 = A_arbace_classes_types_A_const_55; var tmp81 any = tmp80.Ref(); var tmp82 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp82 = A_arbace_classes_types_A_const_56; var tmp83 any = tmp82.Ref(); var tmp84 *lang.PersistentVector; lang.PersistentVector_Init(); tmp84 = lang.PersistentVector_EMPTY; G__48000065__6_ = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp77, tmp79, tmp81, n__4_2, tmp83, tmp84.Ref()))

								if jrt.A2g_Truth(o__5) { var tmp85 *lang.Var; A_arbace_classes_types_A_Init(); tmp85 = A_arbace_classes_types_A_const_41; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp87 = A_arbace_classes_types_A_const_82; tmp3 = tmp86.Invoke_O_O_O__O(G__48000065__6_, tmp87.Ref(), o__5) } else { tmp3 = G__48000065__6_ } } else {
//line :138:1
									var tmp88 *lang.Var; A_arbace_classes_types_A_Init(); tmp88 = A_arbace_classes_types_A_const_63; var tmp89 lang.IFn = lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()); var tmp90 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_160, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var tmp91 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp91 = A_arbace_classes_types_A_const_83; panic(jrt.Thrown(jrt.Throwable_Cast(tmp89.Invoke_O_O__O(tmp90, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp91.Ref(), form__1)))))) } } else {
//line :117:1
										var tmp92 *lang.Var; A_arbace_classes_types_A_Init(); tmp92 = A_arbace_classes_types_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()).Invoke_O__O(form__1)) { var d__3_2 any; var tmp93 *lang.Var


























											A_arbace_classes_types_A_Init(); tmp93 = A_arbace_classes_types_A_const_30; d__3_2 = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()).Invoke_O_O_O__O(form__1, Lit_124, Lit_125)
											var tmp94 *lang.Var; A_arbace_classes_types_A_Init(); tmp94 = A_arbace_classes_types_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()).Invoke_O_O__O(d__3_2, Lit_116)) { var body_p__4 *A_arbace_classes_types_parse_type_p__48000066_A = A_arbace_classes_types_parse_type_p__48000066_A_New(); var p__4 any; var tmp95 *jrt.Class; A_arbace_classes_types_parse_type_p__48000066_A_Init(); tmp95 = A_arbace_classes_types_parse_type_p__48000066_A_fn_class; p__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_p__4.Ref(), tmp95, nil)



												tmp3 = lang.IFn_Cast(p__4).Invoke_O__O(d__3_2) } else {
													var tmp96 *lang.Var; A_arbace_classes_types_A_Init(); tmp96 = A_arbace_classes_types_A_const_64; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 *lang.Var; A_arbace_classes_types_A_Init(); tmp98 = A_arbace_classes_types_A_const_34; tmp3 = tmp97.Invoke_O_O__O(scope__0, lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()).Invoke_O__O(form__1)) } } else {
//line :117:1
														var tmp99 *lang.Var; A_arbace_classes_types_A_Init(); tmp99 = A_arbace_classes_types_A_const_65; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()).Invoke_O__O(form__1)) { var d__3_3 any; var tmp100 *lang.Var


































															A_arbace_classes_types_A_Init(); tmp100 = A_arbace_classes_types_A_const_66; d__3_3 = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()).Invoke_O__O(form__1)
															var tmp101 *lang.Var; A_arbace_classes_types_A_Init(); tmp101 = A_arbace_classes_types_A_const_64; var tmp102 lang.IFn = lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()); var tmp103 any; var tmp104 *lang.Var; A_arbace_classes_types_A_Init(); tmp104 = A_arbace_classes_types_A_const_84; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()).Invoke_O__O(d__3_3)) { var tmp105 *lang.Var; A_arbace_classes_types_A_Init(); tmp105 = A_arbace_classes_types_A_const_34; var tmp106 lang.IFn = lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()); var tmp107 *lang.Var; A_arbace_classes_types_A_Init(); tmp107 = A_arbace_classes_types_A_const_86; tmp103 = tmp106.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()).Invoke_O__O(d__3_3)) } else {
																var tmp108 *lang.Var; A_arbace_classes_types_A_Init(); tmp108 = A_arbace_classes_types_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()).Invoke_O__O(d__3_3)) { var tmp109 *lang.Var; A_arbace_classes_types_A_Init(); tmp109 = A_arbace_classes_types_A_const_85; tmp103 = lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()).Invoke_O__O(d__3_3) } else { var tmp110 *lang.Var; A_arbace_classes_types_A_Init(); tmp110 = A_arbace_classes_types_A_const_34; tmp103 = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(form__1)).GetName__String().Ref()) } }
//line :153:1
															tmp3 = tmp102.Invoke_O_O__O(scope__0, tmp103) } else {
//line :117:1
																var tmp111 any; var and__1927000168__auto____3_4 any; var tmp112 *lang.Var






































																A_arbace_classes_types_A_Init(); tmp112 = A_arbace_classes_types_A_const_67; and__1927000168__auto____3_4 = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____3_4) { var tmp113 any; A_arbace_classes_types_A_Init(); tmp113 = A_arbace_classes_types_A_const_68; var tmp114 any = tmp113; var tmp115 *lang.Var; A_arbace_classes_types_A_Init(); tmp115 = A_arbace_classes_types_A_const_69; tmp111 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp114, lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp111 = and__1927000168__auto____3_4 }
//line :117:1
																if jrt.A2g_Truth(tmp111) { var tmp116 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp116 = A_arbace_classes_types_A_const_45; var tmp117 any = tmp116.Ref(); var tmp118 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp118 = A_arbace_classes_types_A_const_52; var tmp119 any = tmp118.Ref(); var tmp120 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp120 = A_arbace_classes_types_A_const_53; var tmp121 any = tmp120.Ref(); var tmp122 *lang.Var; A_arbace_classes_types_A_Init(); tmp122 = A_arbace_classes_types_A_const_64; var tmp123 lang.IFn = lang.IFn_Cast(jrt.NN(tmp122).GetRawRoot__O()); var tmp124 *lang.Var; A_arbace_classes_types_A_Init(); tmp124 = A_arbace_classes_types_A_const_87; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp117, tmp119, tmp121, tmp123.Invoke_O_O__O(scope__0, lang.IFn_Cast(jrt.NN(tmp124).GetRawRoot__O()).Invoke_O__O(form__1)))) } else { var tmp125 any; var and__1927000168__auto____3_5 any; var tmp126 *lang.Var









































																	A_arbace_classes_types_A_Init(); tmp126 = A_arbace_classes_types_A_const_67; and__1927000168__auto____3_5 = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____3_5) { var tmp127 any; A_arbace_classes_types_A_Init(); tmp127 = A_arbace_classes_types_A_const_70; var tmp128 any = tmp127; var tmp129 *lang.Var; A_arbace_classes_types_A_Init(); tmp129 = A_arbace_classes_types_A_const_69; tmp125 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp128, lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp125 = and__1927000168__auto____3_5 }
//line :117:1
																	if jrt.A2g_Truth(tmp125) { var vec__48000068__3 any = form__1; var ___4 any = lang.RT_Nth_O_I_O__O(vec__48000068__3, lang.RT_IntCast_J__I(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O(vec__48000068__3, lang.RT_IntCast_J__I(1), nil); var b__6 any = lang.RT_Nth_O_I_O__O(vec__48000068__3, lang.RT_IntCast_J__I(2), nil); var tmp130 *lang.Keyword; _ = ___4; A_arbace_classes_types_A_Init(); tmp130 = A_arbace_classes_types_A_const_45; var tmp131 any = tmp130.Ref(); var tmp132 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp132 = A_arbace_classes_types_A_const_71; var tmp133 any = tmp132.Ref(); var tmp134 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp134 = A_arbace_classes_types_A_const_72; var tmp135 any = tmp134.Ref(); var tmp136 *lang.Var; A_arbace_classes_types_A_Init(); tmp136 = A_arbace_classes_types_A_const_73; var tmp137 lang.IFn = lang.IFn_Cast(jrt.NN(tmp136).GetRawRoot__O()); var tmp138 *lang.Var; A_arbace_classes_types_A_Init(); tmp138 = A_arbace_classes_types_A_const_9; var tmp139 any = tmp137.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()).Invoke_O__O(k__5)); var tmp140 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp140 = A_arbace_classes_types_A_const_74; var tmp141 any = tmp140.Ref(); var tmp142 *lang.Var; A_arbace_classes_types_A_Init(); tmp142 = A_arbace_classes_types_A_const_64; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp131, tmp133, tmp135, tmp139, tmp141, lang.IFn_Cast(jrt.NN(tmp142).GetRawRoot__O()).Invoke_O_O__O(scope__0, b__6))) } else { var tmp143 any; var and__1927000168__auto____3_6 any; var tmp144 *lang.Var













































																		A_arbace_classes_types_A_Init(); tmp144 = A_arbace_classes_types_A_const_67; and__1927000168__auto____3_6 = lang.IFn_Cast(jrt.NN(tmp144).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____3_6) { var tmp145 any; A_arbace_classes_types_A_Init(); tmp145 = A_arbace_classes_types_A_const_75; var tmp146 any = tmp145; var tmp147 *lang.Var; A_arbace_classes_types_A_Init(); tmp147 = A_arbace_classes_types_A_const_69; tmp143 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp146, lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp143 = and__1927000168__auto____3_6 }
//line :117:1
																		if jrt.A2g_Truth(tmp143) { var tmp148 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp148 = A_arbace_classes_types_A_const_45; var tmp149 any = tmp148.Ref(); var tmp150 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp150 = A_arbace_classes_types_A_const_76; var tmp151 any = tmp150.Ref(); var tmp152 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp152 = A_arbace_classes_types_A_const_77; var tmp153 any = tmp152.Ref(); var tmp154 *lang.Var; A_arbace_classes_types_A_Init(); tmp154 = A_arbace_classes_types_A_const_78; var tmp155 lang.IFn = lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()); var tmp156 any = A_arbace_classes_types_parse_type_fn__48000071_A_New_O(scope__0); var tmp157 *jrt.Class; A_arbace_classes_types_parse_type_fn__48000071_A_Init(); tmp157 = A_arbace_classes_types_parse_type_fn__48000071_A_fn_class; var tmp158 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp156, tmp157, nil); var tmp159 *lang.Var; A_arbace_classes_types_A_Init(); tmp159 = A_arbace_classes_types_A_const_88; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp149, tmp151, tmp153, tmp155.Invoke_O_O__O(tmp158, lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()).Invoke_O__O(form__1)))) } else { var tmp160 any; var and__1927000168__auto____3_7 any; var tmp161 *lang.Var
















































																			A_arbace_classes_types_A_Init(); tmp161 = A_arbace_classes_types_A_const_67; and__1927000168__auto____3_7 = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____3_7) { var tmp162 any; A_arbace_classes_types_A_Init(); tmp162 = A_arbace_classes_types_A_const_79; var tmp163 any = tmp162; var tmp164 *lang.Var; A_arbace_classes_types_A_Init(); tmp164 = A_arbace_classes_types_A_const_69; tmp160 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp163, lang.IFn_Cast(jrt.NN(tmp164).GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp160 = and__1927000168__auto____3_7 }
//line :117:1
																			if jrt.A2g_Truth(tmp160) {

















































																				var tmp165 *lang.Var; A_arbace_classes_types_A_Init(); tmp165 = A_arbace_classes_types_A_const_80; var tmp166 lang.IFn = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()); var tmp167 any = A_arbace_classes_types_parse_type_fn__48000073_A_New_O(scope__0); var tmp168 *jrt.Class; A_arbace_classes_types_parse_type_fn__48000073_A_Init(); tmp168 = A_arbace_classes_types_parse_type_fn__48000073_A_fn_class; var tmp169 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp167, tmp168, nil); var tmp170 *lang.Var; A_arbace_classes_types_A_Init(); tmp170 = A_arbace_classes_types_A_const_64; var tmp171 lang.IFn = lang.IFn_Cast(jrt.NN(tmp170).GetRawRoot__O()); var tmp172 *lang.Var; A_arbace_classes_types_A_Init(); tmp172 = A_arbace_classes_types_A_const_87; var tmp173 any = tmp171.Invoke_O_O__O(scope__0, lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()).Invoke_O__O(form__1)); var tmp174 *lang.Var; A_arbace_classes_types_A_Init(); tmp174 = A_arbace_classes_types_A_const_90; tmp3 = tmp166.Invoke_O_O_O__O(tmp169, tmp173, lang.IFn_Cast(jrt.NN(tmp174).GetRawRoot__O()).Invoke_O__O(form__1)) } else {
//line :117:1
																					var tmp175 *lang.Var; A_arbace_classes_types_A_Init(); tmp175 = A_arbace_classes_types_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp175).GetRawRoot__O()).Invoke_O__O(form__1)) { var c__3 any; var tmp176 *lang.Var

























































																						A_arbace_classes_types_A_Init(); tmp176 = A_arbace_classes_types_A_const_64; var tmp177 lang.IFn = lang.IFn_Cast(jrt.NN(tmp176).GetRawRoot__O()); var tmp178 *lang.Var; A_arbace_classes_types_A_Init(); tmp178 = A_arbace_classes_types_A_const_69; c__3 = tmp177.Invoke_O_O__O(scope__0, lang.IFn_Cast(jrt.NN(tmp178).GetRawRoot__O()).Invoke_O__O(form__1))
																						var tmp179 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp179 = A_arbace_classes_types_A_const_54; var tmp180 any = tmp179.Ref(); var tmp181 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp181 = A_arbace_classes_types_A_const_45; if lang.Util_Equiv_O_O__Z(tmp180, jrt.NN(tmp181).Invoke_O__O(c__3)) { } else { var tmp182 *lang.Var; A_arbace_classes_types_A_Init(); tmp182 = A_arbace_classes_types_A_const_63; var tmp183 lang.IFn = lang.IFn_Cast(jrt.NN(tmp182).GetRawRoot__O()); var tmp184 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_161, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var tmp185 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp185 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp183.Invoke_O_O__O(tmp184, tmp185.Ref())))) }
																						var tmp186 *lang.Var; A_arbace_classes_types_A_Init(); tmp186 = A_arbace_classes_types_A_const_41; var tmp187 lang.IFn = lang.IFn_Cast(jrt.NN(tmp186).GetRawRoot__O()); var tmp188 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp188 = A_arbace_classes_types_A_const_56; var tmp189 any = tmp188.Ref(); var tmp190 *lang.Var; A_arbace_classes_types_A_Init(); tmp190 = A_arbace_classes_types_A_const_78; var tmp191 lang.IFn = lang.IFn_Cast(jrt.NN(tmp190).GetRawRoot__O()); var tmp192 any = A_arbace_classes_types_parse_type_fn__48000080_A_New_O(scope__0); var tmp193 *jrt.Class; A_arbace_classes_types_parse_type_fn__48000080_A_Init(); tmp193 = A_arbace_classes_types_parse_type_fn__48000080_A_fn_class; var tmp194 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp192, tmp193, nil); var tmp195 *lang.Var; A_arbace_classes_types_A_Init(); tmp195 = A_arbace_classes_types_A_const_88; tmp3 = tmp187.Invoke_O_O_O__O(c__3, tmp189, tmp191.Invoke_O_O__O(tmp194, lang.IFn_Cast(jrt.NN(tmp195).GetRawRoot__O()).Invoke_O__O(form__1))) } else {
//line :117:1
																							var tmp196 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp196 = A_arbace_classes_types_A_const_31; if tmp196 != nil { var tmp197 *lang.Var; A_arbace_classes_types_A_Init(); tmp197 = A_arbace_classes_types_A_const_63; var tmp198 lang.IFn = lang.IFn_Cast(jrt.NN(tmp197).GetRawRoot__O()); var tmp199 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_162, nil); var tmp200 *lang.Var; A_arbace_classes_types_A_Init(); tmp200 = A_arbace_classes_types_A_const_91; var tmp201 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp199, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp200).GetRawRoot__O()).Invoke_O__O(form__1))).Ref(); var tmp202 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp202 = A_arbace_classes_types_A_const_83; panic(jrt.Thrown(jrt.Throwable_Cast(tmp198.Invoke_O_O__O(tmp201, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp202.Ref(), form__1)))))) } else { tmp3 = nil } } } } } } } } } } } } } }
//line :116:1
	return tmp2.Invoke_O_O__O(tmp3, form__1)
}






func A_arbace_classes_types_parse_type_fn__48000063_A_New() *A_arbace_classes_types_parse_type_fn__48000063_A { A_arbace_classes_types_parse_type_fn__48000063_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000063_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_classes_types_parse_type_fn__48000063_A) Ctor() {}
//line :124:1
func (t *A_arbace_classes_types_parse_type_fn__48000063_A) Invoke_O_O__O(self, e__1 any) any { var tmp1 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_45; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_52; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_53; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp4, tmp5.Ref(), e__1)) }





















func A_arbace_classes_types_parse_type_p__48000066_A_New() *A_arbace_classes_types_parse_type_p__48000066_A { A_arbace_classes_types_parse_type_p__48000066_A_Init(); t := &A_arbace_classes_types_parse_type_p__48000066_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_classes_types_parse_type_p__48000066_A) Ctor() {}
//line :146:1
func (t *A_arbace_classes_types_parse_type_p__48000066_A) Invoke_O_O__O(self, d__1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(d__1, Lit_116)) { var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_45; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_52; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_53; var tmp7 any = tmp6.Ref(); var tmp8 lang.IFn = lang.IFn_Cast(self); var tmp9 *lang.Var; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_16; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_classes_types_A_Init(); tmp11 = A_arbace_classes_types_A_const_17; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp7, tmp8.Invoke_O__O(tmp10.Invoke_O_O__O(d__1, tmp11)))) } else { var tmp12 *lang.Var; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(d__1, Lit_126)) { var tmp13 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_45; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_54; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_55; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_classes_types_A_Init(); tmp19 = A_arbace_classes_types_A_const_32; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__1); var tmp21 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_56; var tmp22 any = tmp21.Ref(); var tmp23 *lang.PersistentVector; lang.PersistentVector_Init(); tmp23 = lang.PersistentVector_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp16, tmp18, tmp20, tmp22, tmp23.Ref())) } else { var tmp24 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp24 = A_arbace_classes_types_A_const_31; if tmp24 != nil { var tmp25 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp25 = A_arbace_classes_types_A_const_45; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp27 = A_arbace_classes_types_A_const_46; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_47; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp28, tmp29.Ref(), d__1)) } else { return nil } } } }

















func A_arbace_classes_types_parse_type_fn__48000071_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000071_A { A_arbace_classes_types_parse_type_fn__48000071_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000071_A{}; t.Ctor_O(p0); return t }
//line :164:1
func (t *A_arbace_classes_types_parse_type_fn__48000071_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :164:1
func (t *A_arbace_classes_types_parse_type_fn__48000071_A) Invoke_O_O__O(self, p1__48000060_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_64; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000060_SHARP___1) }


func A_arbace_classes_types_parse_type_fn__48000073_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_A { A_arbace_classes_types_parse_type_fn__48000073_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :167:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Invoke_O_O_O__O(self, outer__1, f__2 any) any { var vec__48000074__3 any; var tmp1 *lang.Var;
														A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__2)) { vec__48000074__3 = f__2 } else { vec__48000074__3 = lang.Tuple_Create_O__IPersistentVector(f__2) }; var seq__48000075__4 any; var tmp2 /*line :167:1*/*lang.Var;
														A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_40; seq__48000075__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(vec__48000074__3); var first__48000076__5 any; var tmp3 /*line :167:1*/*lang.Var;
														A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_69; first__48000076__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__48000075__4); var seq__48000075__6 any; var tmp4 /*line :167:1*/*lang.Var;
														A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_89; seq__48000075__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__48000075__4); var c__7 any = first__48000076__5; var args__8 any = seq__48000075__6; var n__9 any; var tmp5 /*line :167:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_148, nil); var tmp6 *lang.Keyword;

	A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_55; var tmp7 any = jrt.NN(tmp6).Invoke_O__O(outer__1); var tmp8 *lang.Var; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_9; n__9 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(c__7))).Ref(); var tmp9 /*line :167:1*/*lang.Keyword; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_45; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp11 = A_arbace_classes_types_A_const_54; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_55; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_56; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_78; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_New_O(t.F_scope); var tmp20 *jrt.Class; A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_Init(); tmp20 = A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_fn_class; var tmp21 any = tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), args__8); var tmp22 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp22 = A_arbace_classes_types_A_const_82; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp14, n__9, tmp16, tmp21, tmp22.Ref(), outer__1)) }


func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A { A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A{}; t.Ctor_O(p0); return t }
//line :170:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :170:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) Invoke_O_O__O(self, p1__48000061_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_64; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000061_SHARP___1) }






func A_arbace_classes_types_parse_type_fn__48000080_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000080_A { A_arbace_classes_types_parse_type_fn__48000080_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000080_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_classes_types_parse_type_fn__48000080_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :177:1
func (t *A_arbace_classes_types_parse_type_fn__48000080_A) Invoke_O_O__O(self, p1__48000062_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_64; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000062_SHARP___1) }




func A_arbace_classes_types_erase_A_New() *A_arbace_classes_types_erase_A { A_arbace_classes_types_erase_A_Init(); t := &A_arbace_classes_types_erase_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_classes_types_erase_A) Ctor() {}
//line :182:1
func (t *A_arbace_classes_types_erase_A) Invoke_O_O_O__O(self, bounds__0, tn__1 any) any { var G__48000083__3_ any; var tmp1 *lang.Keyword;


	A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_45; G__48000083__3_ = jrt.NN(tmp1).Invoke_O__O(tn__1); switch lang.Util_Hash_O__I(G__48000083__3_) >> 9 & 7 { case 0: var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_71; if any(G__48000083__3_) == any(tmp2.Ref()) {





		var tmp3 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_92; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_72; if lang.Util_Equiv_O_O__Z(tmp4, jrt.NN(tmp5).Invoke_O__O(tn__1)) { var tmp6 *lang.Var; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_93; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_74; return tmp7.Invoke_O_O__O(bounds__0, jrt.NN(tmp8).Invoke_O__O(tn__1)) } else { var tmp9 *lang.Var; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_94; return jrt.NN(tmp9).GetRawRoot__O() } }
//line :185:1
	case 1: var tmp10 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_46; if any(G__48000083__3_) == any(tmp10.Ref()) {
		var tmp11 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp11 = A_arbace_classes_types_A_const_47; return jrt.NN(tmp11).Invoke_O__O(tn__1) }
//line :185:1
	case 2: var tmp12 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_54; if any(G__48000083__3_) == any(tmp12.Ref()) {

		var tmp13 *lang.Var; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_25; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_55; return tmp14.Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(tn__1)) }
//line :185:1
	case 3: var tmp16 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_76; if any(G__48000083__3_) == any(tmp16.Ref()) {




		var tmp17 *lang.Var; A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_93; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_types_A_Init(); tmp19 = A_arbace_classes_types_A_const_69; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_77; return tmp18.Invoke_O_O__O(bounds__0, tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(tn__1))) }
//line :185:1
	case 4: var tmp22 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp22 = A_arbace_classes_types_A_const_52; if any(G__48000083__3_) == any(tmp22.Ref()) {


		var tmp23 *lang.Var; A_arbace_classes_types_A_Init(); tmp23 = A_arbace_classes_types_A_const_95; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_types_A_Init(); tmp25 = A_arbace_classes_types_A_const_93; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp27 = A_arbace_classes_types_A_const_53; return tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(bounds__0, jrt.NN(tmp27).Invoke_O__O(tn__1))) }
//line :185:1
	case 7: var tmp28 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp28 = A_arbace_classes_types_A_const_59; if any(G__48000083__3_) == any(tmp28.Ref()) { var temp__1927000408__auto____4 any; var tmp29 *lang.Var



		A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_69; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp31 = A_arbace_classes_types_A_const_60; temp__1927000408__auto____4 = tmp30.Invoke_O__O(lang.RT_Get_O_O__O(bounds__0, jrt.NN(tmp31).Invoke_O__O(tn__1))); if jrt.A2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var tmp32 *lang.Var; A_arbace_classes_types_A_Init(); tmp32 = A_arbace_classes_types_A_const_93; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_classes_types_A_Init(); tmp34 = A_arbace_classes_types_A_const_96; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp36 = A_arbace_classes_types_A_const_60; return tmp33.Invoke_O_O__O(tmp35.Invoke_O_O__O(bounds__0, jrt.NN(tmp36).Invoke_O__O(tn__1)), b__5) } else { var tmp37 *lang.Var; A_arbace_classes_types_A_Init(); tmp37 = A_arbace_classes_types_A_const_94; return jrt.NN(tmp37).GetRawRoot__O() } }
//line :185:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000083__3_))))) }







func A_arbace_classes_types_generic_QMARK__A_New() *A_arbace_classes_types_generic_QMARK__A { A_arbace_classes_types_generic_QMARK__A_Init(); t := &A_arbace_classes_types_generic_QMARK__A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_classes_types_generic_QMARK__A) Ctor() {}
//line :193:1
func (t *A_arbace_classes_types_generic_QMARK__A) Invoke_O_O__O(self, tn__0 any) any { var G__48000085__2_ any; var tmp1 *lang.Keyword;


	A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_45; G__48000085__2_ = jrt.NN(tmp1).Invoke_O__O(tn__0); switch lang.Util_Hash_O__I(G__48000085__2_) >> 9 & 7 { case 0: var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_71; if any(G__48000085__2_) == any(tmp2.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 1: var tmp3 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_46; if any(G__48000085__2_) == any(tmp3.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }; case 2: var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_54; if any(G__48000085__2_) == any(tmp4.Ref()) { var or__1927000174__auto____3 bool; var tmp5 *lang.Var

		A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_40; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_56; or__1927000174__auto____3 = lang.RT_BooleanCast_O__Z(tmp6.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(tn__0))); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var tmp8 any; var and__1927000168__auto____4 any; var tmp9 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_82; and__1927000168__auto____4 = jrt.NN(tmp9).Invoke_O__O(tn__0); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp10 *lang.Var; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_97; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_82; tmp8 = tmp11.Invoke_O__O(jrt.NN(tmp12).Invoke_O__O(tn__0)) } else { tmp8 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp8)).Ref() } }
//line :196:1
	case 3: var tmp13 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_76; if any(G__48000085__2_) == any(tmp13.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 4: var tmp14 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp14 = A_arbace_classes_types_A_const_52; if any(G__48000085__2_) == any(tmp14.Ref()) {


		var tmp15 *lang.Var; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_97; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_53; return tmp16.Invoke_O__O(jrt.NN(tmp17).Invoke_O__O(tn__0)) }
//line :196:1
	case 7: var tmp18 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp18 = A_arbace_classes_types_A_const_59; if any(G__48000085__2_) == any(tmp18.Ref()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000085__2_))))) }







func A_arbace_classes_types_local_class_name_QMARK__A_New() *A_arbace_classes_types_local_class_name_QMARK__A { A_arbace_classes_types_local_class_name_QMARK__A_Init(); t := &A_arbace_classes_types_local_class_name_QMARK__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Ctor() {}
//line :204:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Invoke_O_O_O__O(self, n__0, outer__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = outer__1; if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_13; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(n__0, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_148), jrt.RefArrayOf(jrt.Object_class, outer__1, nil)).Ref()); if jrt.A2g_Truth(and__1927000168__auto____4) {
		var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_37; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_98; var tmp6 any = tmp5; var tmp7 *lang.Var; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_16; tmp1 = tmp4.Invoke_O_O__O(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(n__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(outer__1)))).Ref())) } else {
//line :208:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref()
}

func A_arbace_classes_types_signature_A_New() *A_arbace_classes_types_signature_A { A_arbace_classes_types_signature_A_Init(); t := &A_arbace_classes_types_signature_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_classes_types_signature_A) Ctor() {}
//line :211:1
func (t *A_arbace_classes_types_signature_A) Invoke_O_O__O(self, tn__0 any) any { var G__48000088__2_ any; var tmp1 *lang.Keyword;


	A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_45; G__48000088__2_ = jrt.NN(tmp1).Invoke_O__O(tn__0); switch lang.Util_Hash_O__I(G__48000088__2_) >> 9 & 7 { case 0: var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_71; if any(G__48000088__2_) == any(tmp2.Ref()) { var G__48000089__3_ any; var tmp3 *lang.Keyword









		A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_72; G__48000089__3_ = jrt.NN(tmp3).Invoke_O__O(tn__0); switch lang.Util_Hash_O__I(G__48000089__3_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__48000089__3_, nil) { return Lit_187 }; case 1: var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_99; if lang.Util_Equiv_O_O__Z(G__48000089__3_, tmp4.Ref()) {
			var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_188, nil); var tmp6 *lang.Var; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_100; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_74; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(tn__0)))).Ref() }
//line :224:1
		case 3: var tmp9 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_92; if lang.Util_Equiv_O_O__Z(G__48000089__3_, tmp9.Ref()) { var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_189, nil); var tmp11 *lang.Var; A_arbace_classes_types_A_Init(); tmp11 = A_arbace_classes_types_A_const_100; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_74; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(tn__0)))).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000089__3_))))) }
//line :214:1
	case 1: var tmp14 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp14 = A_arbace_classes_types_A_const_46; if any(G__48000088__2_) == any(tmp14.Ref()) {
		var tmp15 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_47; return jrt.NN(tmp15).Invoke_O__O(tn__0) }
//line :214:1
	case 2: var tmp16 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_54; if any(G__48000088__2_) == any(tmp16.Ref()) { var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var tmp17 *lang.Var

		A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_101; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_types_A_Init(); tmp19 = A_arbace_classes_types_A_const_102; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_55; var tmp22 any = jrt.NN(tmp21).Invoke_O__O(tn__0); var tmp23 any; var G__48000090__3_ any; var tmp24 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp24 = A_arbace_classes_types_A_const_82; G__48000090__3_ = jrt.NN(tmp24).Invoke_O__O(tn__0); if lang.Util_Identical_O_O__Z(G__48000090__3_, nil) { tmp23 = nil } else { var tmp25 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp25 = A_arbace_classes_types_A_const_55; tmp23 = jrt.NN(tmp25).Invoke_O__O(G__48000090__3_) }; and__1927000168__auto____3 = tmp18.Invoke_O__O(tmp20.Invoke_O_O__O(tmp22, tmp23)); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp26 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp26 = A_arbace_classes_types_A_const_82; temp__1927000408__auto____3 = jrt.NN(tmp26).Invoke_O__O(tn__0) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.A2g_Truth(temp__1927000408__auto____3) { var o__4 any = temp__1927000408__auto____3; var os__5 any; var tmp27 *lang.Var
			A_arbace_classes_types_A_Init(); tmp27 = A_arbace_classes_types_A_const_100; os__5 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(o__4)
			var tmp28 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_124, nil, nil, Lit_127); var tmp29 *lang.Var; A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_16; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_classes_types_A_Init(); tmp31 = A_arbace_classes_types_A_const_21; var tmp32 any = tmp31; var tmp33 any = tmp30.Invoke_O_O_O__O(os__5, tmp32, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(os__5)))).Ref()); var tmp34 *lang.Var; A_arbace_classes_types_A_Init(); tmp34 = A_arbace_classes_types_A_const_16; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp36 = A_arbace_classes_types_A_const_55; var tmp37 any = jrt.NN(tmp36).Invoke_O__O(tn__0); var tmp38 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp38 = A_arbace_classes_types_A_const_55; var tmp39 any = tmp35.Invoke_O_O__O(tmp37, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(jrt.NN(tmp38).Invoke_O__O(o__4))))).Ref()); var tmp40 *jrt.String; var tmp41 *lang.Var
			A_arbace_classes_types_A_Init(); tmp41 = A_arbace_classes_types_A_const_40; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp43 = A_arbace_classes_types_A_const_56; if jrt.A2g_Truth(tmp42.Invoke_O__O(jrt.NN(tmp43).Invoke_O__O(tn__0))) { var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_190, nil, Lit_191); var tmp45 *lang.Var; A_arbace_classes_types_A_Init(); tmp45 = A_arbace_classes_types_A_const_26; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_classes_types_A_Init(); tmp47 = A_arbace_classes_types_A_const_27; var tmp48 any = jrt.NN(tmp47).GetRawRoot__O(); var tmp49 *lang.Var; A_arbace_classes_types_A_Init(); tmp49 = A_arbace_classes_types_A_const_103; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_classes_types_A_Init(); tmp51 = A_arbace_classes_types_A_const_100; var tmp52 any = jrt.NN(tmp51).GetRawRoot__O(); var tmp53 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp53 = A_arbace_classes_types_A_const_56; tmp40 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp44, jrt.RefArrayOf(jrt.Object_class, nil, tmp46.Invoke_O_O__O(tmp48, tmp50.Invoke_O_O__O(tmp52, jrt.NN(tmp53).Invoke_O__O(tn__0))), nil)) } else { tmp40 = nil }
//line :218:1
			return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp28, jrt.RefArrayOf(jrt.Object_class, tmp33, nil, tmp39, tmp40.Ref(), nil)).Ref() } else {

				var tmp54 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_126, nil, nil, Lit_127); var tmp55 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp55 = A_arbace_classes_types_A_const_55; var tmp56 any = jrt.NN(tmp55).Invoke_O__O(tn__0); var tmp57 *jrt.String; var tmp58 *lang.Var
				A_arbace_classes_types_A_Init(); tmp58 = A_arbace_classes_types_A_const_40; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp60 = A_arbace_classes_types_A_const_56; if jrt.A2g_Truth(tmp59.Invoke_O__O(jrt.NN(tmp60).Invoke_O__O(tn__0))) { var tmp61 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_190, nil, Lit_191); var tmp62 *lang.Var; A_arbace_classes_types_A_Init(); tmp62 = A_arbace_classes_types_A_const_26; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_classes_types_A_Init(); tmp64 = A_arbace_classes_types_A_const_27; var tmp65 any = jrt.NN(tmp64).GetRawRoot__O(); var tmp66 *lang.Var; A_arbace_classes_types_A_Init(); tmp66 = A_arbace_classes_types_A_const_103; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 *lang.Var; A_arbace_classes_types_A_Init(); tmp68 = A_arbace_classes_types_A_const_100; var tmp69 any = jrt.NN(tmp68).GetRawRoot__O(); var tmp70 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp70 = A_arbace_classes_types_A_const_56; tmp57 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp61, jrt.RefArrayOf(jrt.Object_class, nil, tmp63.Invoke_O_O__O(tmp65, tmp67.Invoke_O_O__O(tmp69, jrt.NN(tmp70).Invoke_O__O(tn__0))), nil)) } else { tmp57 = nil }
//line :220:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp54, jrt.RefArrayOf(jrt.Object_class, nil, tmp56, tmp57.Ref(), nil)).Ref() } }
//line :214:1
	case 3: var tmp71 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp71 = A_arbace_classes_types_A_const_76; if any(G__48000088__2_) == any(tmp71.Ref()) {











		var tmp72 *lang.Var; A_arbace_classes_types_A_Init(); tmp72 = A_arbace_classes_types_A_const_100; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_classes_types_A_Init(); tmp74 = A_arbace_classes_types_A_const_69; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp76 = A_arbace_classes_types_A_const_77; return tmp73.Invoke_O__O(tmp75.Invoke_O__O(jrt.NN(tmp76).Invoke_O__O(tn__0))) }
//line :214:1
	case 4: var tmp77 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp77 = A_arbace_classes_types_A_const_52; if any(G__48000088__2_) == any(tmp77.Ref()) {







		var tmp78 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_116, nil); var tmp79 *lang.Var; A_arbace_classes_types_A_Init(); tmp79 = A_arbace_classes_types_A_const_100; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp81 = A_arbace_classes_types_A_const_53; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp78, jrt.RefArrayOf(jrt.Object_class, nil, tmp80.Invoke_O__O(jrt.NN(tmp81).Invoke_O__O(tn__0)))).Ref() }
//line :214:1
	case 7: var tmp82 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp82 = A_arbace_classes_types_A_const_59; if any(G__48000088__2_) == any(tmp82.Ref()) {








		var tmp83 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_192, nil, Lit_127); var tmp84 *lang.Var; A_arbace_classes_types_A_Init(); tmp84 = A_arbace_classes_types_A_const_9; var tmp85 lang.IFn = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()); var tmp86 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp86 = A_arbace_classes_types_A_const_60; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp83, jrt.RefArrayOf(jrt.Object_class, nil, tmp85.Invoke_O__O(jrt.NN(tmp86).Invoke_O__O(tn__0)), nil)).Ref() }
//line :214:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000088__2_))))) }













func A_arbace_classes_types_parse_type_params_A_New() *A_arbace_classes_types_parse_type_params_A { A_arbace_classes_types_parse_type_params_A_Init(); t := &A_arbace_classes_types_parse_type_params_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_classes_types_parse_type_params_A) Ctor() {}
//line :228:1
func (t *A_arbace_classes_types_parse_type_params_A) Invoke_O_O_O__O(self, scope__0, tps__1 any) any {




	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_78; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_parse_type_params_fn__48000093_A_New_O(scope__0); var tmp4 *jrt.Class; A_arbace_classes_types_parse_type_params_fn__48000093_A_Init(); tmp4 = A_arbace_classes_types_parse_type_params_fn__48000093_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), tps__1) }
//line :233:1
func A_arbace_classes_types_parse_type_params_fn__48000093_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000093_A { A_arbace_classes_types_parse_type_params_fn__48000093_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000093_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :233:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) Invoke_O_O__O(self, tp__1 any) any {
	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(tp__1)) { var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_60; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_104; var tmp5 any = tmp4.Ref(); var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_43; var tmp9 any = tmp8.Ref(); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tp__1, tmp5, tmp7, tmp9, lang.RT_Meta_O__IPersistentMap(tp__1))) } else { var vec__48000094__2 any = tp__1; var seq__48000095__3 any; var tmp10 *lang.Var

		A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_40; seq__48000095__3 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(vec__48000094__2)
//line :234:1
		var first__48000096__4 any; var tmp11 *lang.Var

		A_arbace_classes_types_A_Init(); tmp11 = A_arbace_classes_types_A_const_69; first__48000096__4 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq__48000095__3)
//line :234:1
		var seq__48000095__5 any; var tmp12 *lang.Var

		A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_89; seq__48000095__5 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq__48000095__3)
//line :234:1
		var s__6 any = first__48000096__4; var first__48000096__7 any; var tmp13 *lang.Var

		A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_69; first__48000096__7 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq__48000095__5)
//line :234:1
		var seq__48000095__8 any; var tmp14 *lang.Var

		A_arbace_classes_types_A_Init(); tmp14 = A_arbace_classes_types_A_const_89; seq__48000095__8 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq__48000095__5)
//line :234:1
		var kw__9 any = first__48000096__7; var bs__10 any = seq__48000095__8; var tmp15 any


		A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_105; if lang.Util_Equiv_O_O__Z(tmp15, kw__9) { } else { var tmp16 *lang.Var; A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_63; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_171, nil), jrt.RefArrayOf(jrt.Object_class, nil, tp__1)).Ref(); var tmp19 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp19 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp17.Invoke_O_O__O(tmp18, tmp19.Ref())))) }
//line :234:1
		var tmp20 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp20 = A_arbace_classes_types_A_const_60; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp22 = A_arbace_classes_types_A_const_104; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_classes_types_A_Init(); tmp24 = A_arbace_classes_types_A_const_78; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any = A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_New_O(t.F_scope); var tmp27 *jrt.Class; A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_Init(); tmp27 = A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_fn_class; var tmp28 any = tmp25.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil), bs__10); var tmp29 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_43; var tmp30 any = tmp29.Ref(); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, s__6, tmp23, tmp28, tmp30, lang.RT_Meta_O__IPersistentMap(s__6)))
	}
}

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A { A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A{}; t.Ctor_O(p0); return t }
//line :238:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :238:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) Invoke_O_O__O(self, p1__48000092_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_64; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000092_SHARP___1) }


func A_arbace_classes_types_type_params_signature_A_New() *A_arbace_classes_types_type_params_signature_A { A_arbace_classes_types_type_params_signature_A_Init(); t := &A_arbace_classes_types_type_params_signature_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_classes_types_type_params_signature_A) Ctor() {}
//line :241:1
func (t *A_arbace_classes_types_type_params_signature_A) Invoke_O_O_O__O(self, interface_QMARK___0, tps__1 any) any {



	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_106; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(tps__1)) { return Lit_135 } else {

		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_190, nil, Lit_191); var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_26; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_27; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 any; var iter__1927001039__auto____6 any; var tmp8 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_New_O(interface_QMARK___0); var tmp9 *jrt.Class

		A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_Init(); tmp9 = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_fn_class; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(tps__1)
//line :247:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O_O__O(tmp6, tmp7), nil)).Ref()
	} }
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A{}; t.Ctor_O(p0); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) Invoke_O_O__O(self, s__48000102__1 any) any { var tmp1 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_New_O_O_O(t.F_interface_QMARK_, s__48000102__1, self); var tmp2 *jrt.Class; A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_Init(); tmp2 = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :249:1
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) Ctor_O_O_O(c__interface_QMARK_, c__s__48000102, c__iter__48000101 any) { t.F_interface_QMARK_ = c__interface_QMARK_; t.F_s__48000102 = c__s__48000102; t.F_iter__48000101 = c__iter__48000101 }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) Invoke_O__O(self any) any { { var s__48000102__1 any; var t_ any = t.F_s__48000102; t.F_s__48000102 = nil; s__48000102__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__48000102__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__48000102__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_107; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__48000102__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_108; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__48000102__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__48000104__6 any; var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_109; b__48000104__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_New_O_O_I_O(b__48000104__6, t.F_interface_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_Init(); tmp6 = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_113; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_115; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__48000104__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__48000101); var tmp12 *lang.Var; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_116; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__48000102__3))) } else { var tmp13 *lang.Var; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_113; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_115; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__48000104__6), nil) } } else { var map__48000113__4 any; var tmp16 *lang.Var; A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_69; map__48000113__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__48000102__3); var map__48000113__5 any; if lang.ISeq_InstanceOf(map__48000113__4) { var tmp17 *lang.Var; A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_89; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(map__48000113__4)) { var tmp18 *lang.Var; A_arbace_classes_types_A_Init(); tmp18 = A_arbace_classes_types_A_const_110; map__48000113__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(map__48000113__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp19 *lang.Var; A_arbace_classes_types_A_Init(); tmp19 = A_arbace_classes_types_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(map__48000113__4)) { var tmp20 *lang.Var; A_arbace_classes_types_A_Init(); tmp20 = A_arbace_classes_types_A_const_69; map__48000113__5 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(map__48000113__4) } else { lang.PersistentArrayMap_Init(); map__48000113__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000113__5 = map__48000113__4 }; var sym__6 any; var tmp21 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_60; sym__6 = lang.RT_Get_O_O__O(map__48000113__5, tmp21.Ref()); var bounds__7 any; var tmp22 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp22 = A_arbace_classes_types_A_const_104; bounds__7 = lang.RT_Get_O_O__O(map__48000113__5, tmp22.Ref()); var tmp23 *lang.Var; A_arbace_classes_types_A_Init(); tmp23 = A_arbace_classes_types_A_const_114; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp26 *lang.Var; A_arbace_classes_types_A_Init(); tmp26 = A_arbace_classes_types_A_const_9; var tmp27 any = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(sym__6); var tmp28 any; var tmp29 *lang.Var

	A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_106; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(bounds__7)) { tmp28 = Lit_209 } else {

		var tmp30 *lang.Var; A_arbace_classes_types_A_Init(); tmp30 = A_arbace_classes_types_A_const_26; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_classes_types_A_Init(); tmp32 = A_arbace_classes_types_A_const_27; var tmp33 any = jrt.NN(tmp32).GetRawRoot__O(); var tmp34 *lang.Var; A_arbace_classes_types_A_Init(); tmp34 = A_arbace_classes_types_A_const_112; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_New_O(t.F_interface_QMARK_); var tmp37 *jrt.Class; A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_Init(); tmp37 = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_fn_class; tmp28 = tmp31.Invoke_O_O__O(tmp33, tmp35.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil), bounds__7)) }
//line :249:1
	var tmp38 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp25, jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28)).Ref(); var tmp39 lang.IFn = lang.IFn_Cast(t.F_iter__48000101); var tmp40 *lang.Var; A_arbace_classes_types_A_Init(); tmp40 = A_arbace_classes_types_A_const_88; return tmp24.Invoke_O_O__O(tmp38, tmp39.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(s__48000102__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :249:1
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) Ctor_O_O_I_O(c__b__48000104, c__interface_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__48000104 = c__b__48000104; t.F_interface_QMARK_ = c__interface_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) Invoke_O__O(self any) any { { var i__48000103__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__48000103__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__48000108__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__48000103__1)); var map__48000108__3 any; if lang.ISeq_InstanceOf(map__48000108__2) { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_89; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__48000108__2)) { var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_110; map__48000108__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__48000108__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__48000108__2)) { var tmp5 *lang.Var; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_69; map__48000108__3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__48000108__2) } else { lang.PersistentArrayMap_Init(); map__48000108__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000108__3 = map__48000108__2 }; var sym__4 any; var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_60; sym__4 = lang.RT_Get_O_O__O(map__48000108__3, tmp6.Ref()); var bounds__5 any; var tmp7 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_104; bounds__5 = lang.RT_Get_O_O__O(map__48000108__3, tmp7.Ref()); var tmp8 *lang.Var; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_111; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = t.F_b__48000104; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp12 *lang.Var; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_9; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(sym__4); var tmp14 any; var tmp15 *lang.Var

	A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_106; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(bounds__5)) { tmp14 = Lit_209 } else {

		var tmp16 *lang.Var; A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_26; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_classes_types_A_Init(); tmp18 = A_arbace_classes_types_A_const_27; var tmp19 any = jrt.NN(tmp18).GetRawRoot__O(); var tmp20 *lang.Var; A_arbace_classes_types_A_Init(); tmp20 = A_arbace_classes_types_A_const_112; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_New_O(t.F_interface_QMARK_); var tmp23 *jrt.Class; A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_Init(); tmp23 = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_fn_class; tmp14 = tmp17.Invoke_O_O__O(tmp19, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), bounds__5)) }
//line :249:1
	tmp9.Invoke_O_O__O(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14)).Ref()); i__48000103__1 = lang.Numbers_Unchecked_inc_J__J(i__48000103__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A{}; t.Ctor_O(p0); return t }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool = lang.Numbers_IsZero_O__Z(i__1); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool; var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_54; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_45; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp5 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_55; tmp1 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) {
		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_212, nil); var tmp8 *lang.Var; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_100; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } else {
			var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_213, nil); var tmp10 *lang.Var; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_100; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } }
//line :255:1
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A{}; t.Ctor_O(p0); return t }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool = lang.Numbers_IsZero_O__Z(i__1); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool; var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_54; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_45; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp5 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_55; tmp1 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) {
		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_212, nil); var tmp8 *lang.Var; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_100; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } else {
			var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_213, nil); var tmp10 *lang.Var; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_100; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(b__2))).Ref()
		}
}

func A_arbace_classes_types_bounds_map_A_New() *A_arbace_classes_types_bounds_map_A { A_arbace_classes_types_bounds_map_A_Init(); t := &A_arbace_classes_types_bounds_map_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_classes_types_bounds_map_A) Ctor() {}
//line :262:1
func (t *A_arbace_classes_types_bounds_map_A) Invoke_O_O__O(self, tps__0 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_103; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_classes_types_bounds_map_fn__48000121_A_New(); var tmp8 *jrt.Class; A_arbace_classes_types_bounds_map_fn__48000121_A_Init(); tmp8 = A_arbace_classes_types_bounds_map_fn__48000121_A_fn_class; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), tps__0)) }
//line :262:1
func A_arbace_classes_types_bounds_map_fn__48000121_A_New() *A_arbace_classes_types_bounds_map_fn__48000121_A { A_arbace_classes_types_bounds_map_fn__48000121_A_Init(); t := &A_arbace_classes_types_bounds_map_fn__48000121_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) Ctor() {}
//line :262:1
func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) Invoke_O_O__O(self, p__48000120__1 any) any { var map__48000122__2 any = p__48000120__1; var map__48000122__3 any; if lang.ISeq_InstanceOf(map__48000122__2) { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_89; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__48000122__2)) { var tmp2 *lang.Var; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_110; map__48000122__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__48000122__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__48000122__2)) { var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_69; map__48000122__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__48000122__2) } else { lang.PersistentArrayMap_Init(); map__48000122__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000122__3 = map__48000122__2 }; var sym__4 any; var tmp5 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_60; sym__4 = lang.RT_Get_O_O__O(map__48000122__3, tmp5.Ref()); var bounds__5 any; var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_104; bounds__5 = lang.RT_Get_O_O__O(map__48000122__3, tmp6.Ref()); return lang.Tuple_Create_O_O__IPersistentVector(sym__4, bounds__5) }

func A_arbace_classes_types_desc__GT_tnode_A_New() *A_arbace_classes_types_desc__GT_tnode_A { A_arbace_classes_types_desc__GT_tnode_A_Init(); t := &A_arbace_classes_types_desc__GT_tnode_A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Ctor() {}
//line :264:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Invoke_O_O__O(self, d__0 any) any {
	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_84; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0)) { var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_45; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_46; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_47; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref(), d__0)) } else { if lang.Util_Equiv_O_O__Z(d__0, Lit_132) { var tmp7 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_45; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp9 = A_arbace_classes_types_A_const_46; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp11 = A_arbace_classes_types_A_const_47; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp11.Ref(), d__0)) } else { var tmp12 *lang.Var; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(d__0)) { var tmp13 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_45; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_52; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_53; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_classes_types_A_Init(); tmp19 = A_arbace_classes_types_A_const_117; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_118; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp16, tmp18, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(d__0)))) } else { var tmp22 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp22 = A_arbace_classes_types_A_const_31; if tmp22 != nil { var tmp23 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp23 = A_arbace_classes_types_A_const_45; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp25 = A_arbace_classes_types_A_const_54; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp27 = A_arbace_classes_types_A_const_55; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Var; A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_32; var tmp30 any = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(d__0); var tmp31 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp31 = A_arbace_classes_types_A_const_56; var tmp32 any = tmp31.Ref(); var tmp33 *lang.PersistentVector; lang.PersistentVector_Init(); tmp33 = lang.PersistentVector_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp26, tmp28, tmp30, tmp32, tmp33.Ref())) } else { return nil
	}
	}
	}
	} }
func A_arbace_classes_types_reflect__GT_tnode_A_New() *A_arbace_classes_types_reflect__GT_tnode_A { A_arbace_classes_types_reflect__GT_tnode_A_Init(); t := &A_arbace_classes_types_reflect__GT_tnode_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Invoke_O_O__O(self, ty__0 any) any {


	if jrt.Class_InstanceOf(ty__0) {
		var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_117; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_66; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(ty__0)) } else {
//line :273:1
			if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_176)).IsInstance_O__Z(ty__0) { var pt__2 any = ty__0; var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_45; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_54; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_55; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_32; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_classes_types_A_Init(); tmp12 = A_arbace_classes_types_A_const_66; var tmp13 any = tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_176), Lit_177, jrt.RefArrayOf(jrt.Object_class)))); var tmp14 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp14 = A_arbace_classes_types_A_const_56; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Var; A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_78; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_classes_types_A_Init(); tmp18 = A_arbace_classes_types_A_const_119; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp7, tmp9, tmp13, tmp15, tmp17.Invoke_O_O__O(jrt.NN(tmp18).GetRawRoot__O(), lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_176), Lit_178, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_179)).IsInstance_O__Z(ty__0) { var tmp19 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp19 = A_arbace_classes_types_A_const_45; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_59; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp23 = A_arbace_classes_types_A_const_60; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Var; A_arbace_classes_types_A_Init(); tmp25 = A_arbace_classes_types_A_const_34; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp22, tmp24, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class(Lit_179), Lit_180, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_181)).IsInstance_O__Z(ty__0) { var tmp26 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp26 = A_arbace_classes_types_A_const_45; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp28 = A_arbace_classes_types_A_const_52; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp30 = A_arbace_classes_types_A_const_53; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Var; A_arbace_classes_types_A_Init(); tmp32 = A_arbace_classes_types_A_const_119; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp29, tmp31, lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class(Lit_181), Lit_182, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_183)).IsInstance_O__Z(ty__0) { var w__2 any = ty__0; var lo__3 any; var tmp33 *lang.Var











				A_arbace_classes_types_A_Init(); tmp33 = A_arbace_classes_types_A_const_40; lo__3 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_183), Lit_184, jrt.RefArrayOf(jrt.Object_class)))
//line :273:1
				var up__4 any; var tmp34 *lang.Var











				A_arbace_classes_types_A_Init(); tmp34 = A_arbace_classes_types_A_const_40; up__4 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_183), Lit_185, jrt.RefArrayOf(jrt.Object_class)))
				if jrt.A2g_Truth(lo__3) { var tmp35 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp35 = A_arbace_classes_types_A_const_45; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp37 = A_arbace_classes_types_A_const_71; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp39 = A_arbace_classes_types_A_const_72; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp41 = A_arbace_classes_types_A_const_99; var tmp42 any = tmp41.Ref(); var tmp43 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp43 = A_arbace_classes_types_A_const_74; var tmp44 any = tmp43.Ref(); var tmp45 *lang.Var; A_arbace_classes_types_A_Init(); tmp45 = A_arbace_classes_types_A_const_119; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_classes_types_A_Init(); tmp47 = A_arbace_classes_types_A_const_69; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp36, tmp38, tmp40, tmp42, tmp44, tmp46.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(lo__3)))) } else { var tmp48 any; var and__1927000168__auto____5 any = up__4
					if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp49 *lang.Var; A_arbace_classes_types_A_Init(); tmp49 = A_arbace_classes_types_A_const_12; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *jrt.Class; A_arbace_classes_types_A_Init(); tmp51 = A_arbace_classes_types_A_const_121; var tmp52 any = tmp51.Ref(); var tmp53 *lang.Var; A_arbace_classes_types_A_Init(); tmp53 = A_arbace_classes_types_A_const_69; tmp48 = tmp50.Invoke_O_O__O(tmp52, lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(up__4)) } else { tmp48 = and__1927000168__auto____5 }
//line :286:1
					if jrt.A2g_Truth(tmp48) { var tmp54 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp54 = A_arbace_classes_types_A_const_45; var tmp55 any = tmp54.Ref(); var tmp56 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp56 = A_arbace_classes_types_A_const_71; var tmp57 any = tmp56.Ref(); var tmp58 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp58 = A_arbace_classes_types_A_const_72; var tmp59 any = tmp58.Ref(); var tmp60 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp60 = A_arbace_classes_types_A_const_92; var tmp61 any = tmp60.Ref(); var tmp62 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp62 = A_arbace_classes_types_A_const_74; var tmp63 any = tmp62.Ref(); var tmp64 *lang.Var; A_arbace_classes_types_A_Init(); tmp64 = A_arbace_classes_types_A_const_119; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 *lang.Var; A_arbace_classes_types_A_Init(); tmp66 = A_arbace_classes_types_A_const_69; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, tmp59, tmp61, tmp63, tmp65.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(up__4)))) } else { var tmp67 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp67 = A_arbace_classes_types_A_const_31; if tmp67 != nil { A_arbace_classes_types_A_Init(); return A_arbace_classes_types_A_const_120 } else { return nil } } } } else {
//line :273:1
						var tmp68 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp68 = A_arbace_classes_types_A_const_31; if tmp68 != nil { var tmp69 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp69 = A_arbace_classes_types_A_const_45; var tmp70 any = tmp69.Ref(); var tmp71 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp71 = A_arbace_classes_types_A_const_54; var tmp72 any = tmp71.Ref(); var tmp73 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp73 = A_arbace_classes_types_A_const_55; var tmp74 any = tmp73.Ref(); var tmp75 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp75 = A_arbace_classes_types_A_const_56; var tmp76 any = tmp75.Ref(); var tmp77 *lang.PersistentVector; lang.PersistentVector_Init(); tmp77 = lang.PersistentVector_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp72, tmp74, Lit_159, tmp76, tmp77.Ref())) } else { return nil
						}
					}
			}
			}
			}
		}
}










func A_arbace_classes_types_subst_A_New() *A_arbace_classes_types_subst_A { A_arbace_classes_types_subst_A_Init(); t := &A_arbace_classes_types_subst_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_classes_types_subst_A) Ctor() {}
//line :291:1
func (t *A_arbace_classes_types_subst_A) Invoke_O_O_O__O(self, env__0, tn__1 any) any { var G__48000133__3_ any; var tmp1 *lang.Keyword;


	A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_45; G__48000133__3_ = jrt.NN(tmp1).Invoke_O__O(tn__1); switch lang.Util_Hash_O__I(G__48000133__3_) >> 9 & 7 { case 0: var tmp2 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp2 = A_arbace_classes_types_A_const_71; if any(G__48000133__3_) == any(tmp2.Ref()) {




		var tmp3 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_74; if jrt.A2g_Truth(jrt.NN(tmp3).Invoke_O__O(tn__1)) { var tmp4 *lang.Var; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_122; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp6 = A_arbace_classes_types_A_const_74; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_classes_types_subst_fn__48000134_A_New_O(env__0); var tmp9 *jrt.Class; A_arbace_classes_types_subst_fn__48000134_A_Init(); tmp9 = A_arbace_classes_types_subst_fn__48000134_A_fn_class; return tmp5.Invoke_O_O_O__O(tn__1, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else { return tn__1 } }
//line :294:1
	case 2: var tmp10 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_54; if any(G__48000133__3_) == any(tmp10.Ref()) { var G__48000136__4_ any; var tmp11 *lang.Var

		A_arbace_classes_types_A_Init(); tmp11 = A_arbace_classes_types_A_const_41; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp13 = A_arbace_classes_types_A_const_56; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Var; A_arbace_classes_types_A_Init(); tmp15 = A_arbace_classes_types_A_const_78; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any = A_arbace_classes_types_subst_fn__48000137_A_New_O(env__0); var tmp18 *jrt.Class; A_arbace_classes_types_subst_fn__48000137_A_Init(); tmp18 = A_arbace_classes_types_subst_fn__48000137_A_fn_class; var tmp19 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var tmp20 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp20 = A_arbace_classes_types_A_const_56; G__48000136__4_ = tmp12.Invoke_O_O_O__O(tn__1, tmp14, tmp16.Invoke_O_O__O(tmp19, jrt.NN(tmp20).Invoke_O__O(tn__1))); var tmp21 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_82; if jrt.A2g_Truth(jrt.NN(tmp21).Invoke_O__O(tn__1)) {
			var tmp22 *lang.Var; A_arbace_classes_types_A_Init(); tmp22 = A_arbace_classes_types_A_const_122; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp24 = A_arbace_classes_types_A_const_82; var tmp25 any = tmp24.Ref(); var tmp26 any = A_arbace_classes_types_subst_fn__48000139_A_New_O(env__0); var tmp27 *jrt.Class; A_arbace_classes_types_subst_fn__48000139_A_Init(); tmp27 = A_arbace_classes_types_subst_fn__48000139_A_fn_class; return tmp23.Invoke_O_O_O__O(G__48000136__4_, tmp25, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil)) } else {
//line :296:1
				return G__48000136__4_ } }
//line :294:1
	case 3: var tmp28 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp28 = A_arbace_classes_types_A_const_76; if any(G__48000133__3_) == any(tmp28.Ref()) {





		var tmp29 *lang.Var; A_arbace_classes_types_A_Init(); tmp29 = A_arbace_classes_types_A_const_122; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp31 = A_arbace_classes_types_A_const_77; var tmp32 any = tmp31.Ref(); var tmp33 any = A_arbace_classes_types_subst_fn__48000141_A_New_O(env__0); var tmp34 *jrt.Class; A_arbace_classes_types_subst_fn__48000141_A_Init(); tmp34 = A_arbace_classes_types_subst_fn__48000141_A_fn_class; return tmp30.Invoke_O_O_O__O(tn__1, tmp32, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil)) }
//line :294:1
	case 4: var tmp35 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp35 = A_arbace_classes_types_A_const_52; if any(G__48000133__3_) == any(tmp35.Ref()) {



		var tmp36 *lang.Var; A_arbace_classes_types_A_Init(); tmp36 = A_arbace_classes_types_A_const_122; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp38 = A_arbace_classes_types_A_const_53; var tmp39 any = tmp38.Ref(); var tmp40 any = A_arbace_classes_types_subst_fn__48000143_A_New_O(env__0); var tmp41 *jrt.Class; A_arbace_classes_types_subst_fn__48000143_A_Init(); tmp41 = A_arbace_classes_types_subst_fn__48000143_A_fn_class; return tmp37.Invoke_O_O_O__O(tn__1, tmp39, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil)) }
//line :294:1
	case 7: var tmp42 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp42 = A_arbace_classes_types_A_const_59; if any(G__48000133__3_) == any(tmp42.Ref()) {
		var tmp43 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp43 = A_arbace_classes_types_A_const_60; return lang.RT_Get_O_O_O__O(env__0, jrt.NN(tmp43).Invoke_O__O(tn__1), tn__1) }
//line :294:1
	default:}; return tn__1 }

func A_arbace_classes_types_subst_fn__48000137_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000137_A { A_arbace_classes_types_subst_fn__48000137_A_Init(); t := &A_arbace_classes_types_subst_fn__48000137_A{}; t.Ctor_O(p0); return t }
//line :296:1
func (t *A_arbace_classes_types_subst_fn__48000137_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :296:1
func (t *A_arbace_classes_types_subst_fn__48000137_A) Invoke_O_O__O(self, p1__48000128_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_123; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000128_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000139_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000139_A { A_arbace_classes_types_subst_fn__48000139_A_Init(); t := &A_arbace_classes_types_subst_fn__48000139_A{}; t.Ctor_O(p0); return t }
//line :297:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :297:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Invoke_O_O__O(self, p1__48000129_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_123; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000129_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000143_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000143_A { A_arbace_classes_types_subst_fn__48000143_A_Init(); t := &A_arbace_classes_types_subst_fn__48000143_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :298:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Invoke_O_O__O(self, p1__48000130_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_123; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000130_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000134_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000134_A { A_arbace_classes_types_subst_fn__48000134_A_Init(); t := &A_arbace_classes_types_subst_fn__48000134_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_classes_types_subst_fn__48000134_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :299:1
func (t *A_arbace_classes_types_subst_fn__48000134_A) Invoke_O_O__O(self, p1__48000131_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_123; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000131_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000141_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000141_A { A_arbace_classes_types_subst_fn__48000141_A_Init(); t := &A_arbace_classes_types_subst_fn__48000141_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :300:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Invoke_O_O__O(self, p1__48000132_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_78; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_124; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_123; return tmp2.Invoke_O_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), t.F_env), p1__48000132_SHARP___1) }


func A_arbace_classes_types_type_anns_A_New() *A_arbace_classes_types_type_anns_A { A_arbace_classes_types_type_anns_A_Init(); t := &A_arbace_classes_types_type_anns_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_classes_types_type_anns_A) Ctor() {}
//line :303:1
func (t *A_arbace_classes_types_type_anns_A) Invoke_O_O__O(self, tn__0 any) any { var body_walk__2 *A_arbace_classes_types_type_anns_walk__48000146_A = A_arbace_classes_types_type_anns_walk__48000146_A_New(); var walk__2 any; var tmp1 *jrt.Class; A_arbace_classes_types_type_anns_walk__48000146_A_Init(); tmp1 = A_arbace_classes_types_type_anns_walk__48000146_A_fn_class; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_walk__2.Ref(), tmp1, nil); return /*line :318:1*/ lang.IFn_Cast(walk__2).Invoke_O_O__O(tn__0, Lit_135) }
//line :307:1
func A_arbace_classes_types_type_anns_walk__48000146_A_New() *A_arbace_classes_types_type_anns_walk__48000146_A { A_arbace_classes_types_type_anns_walk__48000146_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000146_A{}; t.Ctor(); return t }
//line :307:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_A) Ctor() {}
//line :307:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_A) Invoke_O_O_O__O(self, tn__1, path__2 any) any {
	var tmp1 *lang.Var; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_125; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var tmp4 any; var and__1927000168__auto____3 bool; var tmp5 *lang.Keyword
	A_arbace_classes_types_A_Init(); tmp5 = A_arbace_classes_types_A_const_54; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp7 = A_arbace_classes_types_A_const_45; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).Invoke_O__O(tn__1)); if and__1927000168__auto____3 { var tmp8 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp8 = A_arbace_classes_types_A_const_82; tmp4 = jrt.NN(tmp8).Invoke_O__O(tn__1) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp4) { var tmp9 lang.IFn = lang.IFn_Cast(self); var tmp10 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp10 = A_arbace_classes_types_A_const_82; tmp3 = tmp9.Invoke_O_O__O(jrt.NN(tmp10).Invoke_O__O(tn__1), path__2) } else { tmp3 = nil }
//line :308:1
	var tmp11 any = tmp3; var tmp12 any; var path__3 any; var tmp13 any; var and__1927000168__auto____3_2 bool; var tmp14 *lang.Keyword

	A_arbace_classes_types_A_Init(); tmp14 = A_arbace_classes_types_A_const_54; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp16 = A_arbace_classes_types_A_const_45; and__1927000168__auto____3_2 = lang.Util_Equiv_O_O__Z(tmp15, jrt.NN(tmp16).Invoke_O__O(tn__1)); if and__1927000168__auto____3_2 { var tmp17 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp17 = A_arbace_classes_types_A_const_82; tmp13 = jrt.NN(tmp17).Invoke_O__O(tn__1) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3_2).Ref() }; if jrt.A2g_Truth(tmp13) { path__3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_124), jrt.RefArrayOf(jrt.Object_class, path__2, nil)).Ref() } else { path__3 = path__2 }
	var tmp18 *lang.Var; A_arbace_classes_types_A_Init(); tmp18 = A_arbace_classes_types_A_const_125; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 lang.IPersistentVector; var temp__1927000414__auto____4 any; var tmp21 *lang.Keyword
	A_arbace_classes_types_A_Init(); tmp21 = A_arbace_classes_types_A_const_43; temp__1927000414__auto____4 = jrt.NN(tmp21).Invoke_O__O(tn__1); if jrt.A2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; tmp20 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(path__3, a__5)) } else { tmp20 = nil }
//line :311:1
	var tmp22 any = tmp20; var tmp23 any; var G__48000147__4_ any; var tmp24 *lang.Keyword

	A_arbace_classes_types_A_Init(); tmp24 = A_arbace_classes_types_A_const_45; G__48000147__4_ = jrt.NN(tmp24).Invoke_O__O(tn__1); L1: switch { default: switch lang.Util_Hash_O__I(G__48000147__4_) >> 0 & 3 { case 0: var tmp25 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp25 = A_arbace_classes_types_A_const_54; if any(G__48000147__4_) == any(tmp25.Ref()) {

		var tmp26 *lang.Var; A_arbace_classes_types_A_Init(); tmp26 = A_arbace_classes_types_A_const_26; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_classes_types_A_Init(); tmp28 = A_arbace_classes_types_A_const_125; var tmp29 any = jrt.NN(tmp28).GetRawRoot__O(); var tmp30 *lang.Var; A_arbace_classes_types_A_Init(); tmp30 = A_arbace_classes_types_A_const_112; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any = A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_New_O_O(path__3, self); var tmp33 *jrt.Class; A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_Init(); tmp33 = A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_fn_class; var tmp34 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var tmp35 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp35 = A_arbace_classes_types_A_const_56; tmp23 = tmp27.Invoke_O_O__O(tmp29, tmp31.Invoke_O_O__O(tmp34, jrt.NN(tmp35).Invoke_O__O(tn__1)))
//line :313:1
		break L1 }; case 2: var tmp36 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp36 = A_arbace_classes_types_A_const_71; if any(G__48000147__4_) == any(tmp36.Ref()) {


			var tmp37 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp37 = A_arbace_classes_types_A_const_74; if jrt.A2g_Truth(jrt.NN(tmp37).Invoke_O__O(tn__1)) { var tmp38 lang.IFn = lang.IFn_Cast(self); var tmp39 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp39 = A_arbace_classes_types_A_const_74; tmp23 = tmp38.Invoke_O_O__O(jrt.NN(tmp39).Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_187), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref()) } else { tmp23 = nil }
//line :313:1
			break L1 }; case 3: var tmp40 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp40 = A_arbace_classes_types_A_const_52; if any(G__48000147__4_) == any(tmp40.Ref()) {
				var tmp41 lang.IFn = lang.IFn_Cast(self); var tmp42 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp42 = A_arbace_classes_types_A_const_53; tmp23 = tmp41.Invoke_O_O__O(jrt.NN(tmp42).Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_116), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref())
//line :313:1
				break L1 }; default:}; tmp23 = nil}
//line :311:1
	tmp12 = tmp19.Invoke_O_O__O(tmp22, tmp23)
//line :308:1
	return tmp2.Invoke_O_O__O(tmp11, tmp12)
}





func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_New_O_O(p0, p1 any) *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A { A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) Ctor_O_O(c__path, c__walk any) { t.F_path = c__path; t.F_walk = c__walk }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) Invoke_O_O_O__O(self, i__1, a__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp1.Invoke_O_O__O(a__2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_127), jrt.RefArrayOf(jrt.Object_class, t.F_path, i__1, nil)).Ref()) }




func A_arbace_classes_types_element_path_A_New() *A_arbace_classes_types_element_path_A { A_arbace_classes_types_element_path_A_Init(); t := &A_arbace_classes_types_element_path_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_classes_types_element_path_A) Ctor() {}
//line :320:1
func (t *A_arbace_classes_types_element_path_A) Invoke_O_O__O(self, tn__0 any) any { { var tn__2 any = tn__0; var path__3 any = Lit_135; L1: for {




	var tmp1 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp1 = A_arbace_classes_types_A_const_52; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp3 = A_arbace_classes_types_A_const_45; if lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(tn__2)) { var tmp4 *lang.Keyword; A_arbace_classes_types_A_Init(); tmp4 = A_arbace_classes_types_A_const_53; tn__2, path__3 = jrt.NN(tmp4).Invoke_O__O(tn__2), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_116), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref(); continue L1 } else { return path__3 } } }; /*line :320:1*/panic("a2g: unreachable") }














































































type A_arbace_classes_types_A struct{ jrt.Object }

var A_arbace_classes_types_A_const_0 *lang.Var

var A_arbace_classes_types_A_const_1 *lang.Var

var A_arbace_classes_types_A_const_2 any

var A_arbace_classes_types_A_const_3 any

var A_arbace_classes_types_A_const_4 *lang.Var

var A_arbace_classes_types_A_const_5 *lang.Var

var A_arbace_classes_types_A_const_6 *lang.Var

var A_arbace_classes_types_A_const_7 any

var A_arbace_classes_types_A_const_8 *lang.Var

var A_arbace_classes_types_A_const_9 *lang.Var

var A_arbace_classes_types_A_const_10 *lang.Var

var A_arbace_classes_types_A_const_11 *lang.Var

var A_arbace_classes_types_A_const_12 *lang.Var

var A_arbace_classes_types_A_const_13 *lang.Var

var A_arbace_classes_types_A_const_14 *lang.Keyword

var A_arbace_classes_types_A_const_15 *lang.Var

var A_arbace_classes_types_A_const_16 *lang.Var

var A_arbace_classes_types_A_const_17 any

var A_arbace_classes_types_A_const_18 *lang.Var

var A_arbace_classes_types_A_const_19 any

var A_arbace_classes_types_A_const_20 any

var A_arbace_classes_types_A_const_21 any

var A_arbace_classes_types_A_const_22 *lang.Var

var A_arbace_classes_types_A_const_23 any

var A_arbace_classes_types_A_const_24 any

var A_arbace_classes_types_A_const_25 *lang.Var

var A_arbace_classes_types_A_const_26 *lang.Var

var A_arbace_classes_types_A_const_27 *lang.Var

var A_arbace_classes_types_A_const_28 any

var A_arbace_classes_types_A_const_29 any

var A_arbace_classes_types_A_const_30 *lang.Var

var A_arbace_classes_types_A_const_31 *lang.Keyword

var A_arbace_classes_types_A_const_32 *lang.Var

var A_arbace_classes_types_A_const_33 *lang.Var

var A_arbace_classes_types_A_const_34 *lang.Var

var A_arbace_classes_types_A_const_35 *lang.Var

var A_arbace_classes_types_A_const_36 *lang.Var

var A_arbace_classes_types_A_const_37 *lang.Var

var A_arbace_classes_types_A_const_38 any

var A_arbace_classes_types_A_const_39 *lang.Var

var A_arbace_classes_types_A_const_40 *lang.Var

var A_arbace_classes_types_A_const_41 *lang.Var

var A_arbace_classes_types_A_const_42 *lang.Var

var A_arbace_classes_types_A_const_43 *lang.Keyword

var A_arbace_classes_types_A_const_44 *lang.Var

var A_arbace_classes_types_A_const_45 *lang.Keyword

var A_arbace_classes_types_A_const_46 *lang.Keyword

var A_arbace_classes_types_A_const_47 *lang.Keyword

var A_arbace_classes_types_A_const_48 *lang.Var

var A_arbace_classes_types_A_const_49 *lang.Var

var A_arbace_classes_types_A_const_50 *lang.Var

var A_arbace_classes_types_A_const_51 *lang.Var

var A_arbace_classes_types_A_const_52 *lang.Keyword

var A_arbace_classes_types_A_const_53 *lang.Keyword

var A_arbace_classes_types_A_const_54 *lang.Keyword

var A_arbace_classes_types_A_const_55 *lang.Keyword

var A_arbace_classes_types_A_const_56 *lang.Keyword

var A_arbace_classes_types_A_const_57 any

var A_arbace_classes_types_A_const_58 any

var A_arbace_classes_types_A_const_59 *lang.Keyword

var A_arbace_classes_types_A_const_60 *lang.Keyword

var A_arbace_classes_types_A_const_61 *lang.Keyword

var A_arbace_classes_types_A_const_62 *lang.Keyword

var A_arbace_classes_types_A_const_63 *lang.Var

var A_arbace_classes_types_A_const_64 *lang.Var

var A_arbace_classes_types_A_const_65 *lang.Var

var A_arbace_classes_types_A_const_66 *lang.Var

var A_arbace_classes_types_A_const_67 *lang.Var

var A_arbace_classes_types_A_const_68 any

var A_arbace_classes_types_A_const_69 *lang.Var

var A_arbace_classes_types_A_const_70 any

var A_arbace_classes_types_A_const_71 *lang.Keyword

var A_arbace_classes_types_A_const_72 *lang.Keyword

var A_arbace_classes_types_A_const_73 *lang.Var

var A_arbace_classes_types_A_const_74 *lang.Keyword

var A_arbace_classes_types_A_const_75 any

var A_arbace_classes_types_A_const_76 *lang.Keyword

var A_arbace_classes_types_A_const_77 *lang.Keyword

var A_arbace_classes_types_A_const_78 *lang.Var

var A_arbace_classes_types_A_const_79 any

var A_arbace_classes_types_A_const_80 *lang.Var

var A_arbace_classes_types_A_const_81 *lang.Keyword

var A_arbace_classes_types_A_const_82 *lang.Keyword

var A_arbace_classes_types_A_const_83 *lang.Keyword

var A_arbace_classes_types_A_const_84 *lang.Var

var A_arbace_classes_types_A_const_85 *lang.Var

var A_arbace_classes_types_A_const_86 *lang.Var

var A_arbace_classes_types_A_const_87 *lang.Var

var A_arbace_classes_types_A_const_88 *lang.Var

var A_arbace_classes_types_A_const_89 *lang.Var

var A_arbace_classes_types_A_const_90 *lang.Var

var A_arbace_classes_types_A_const_91 *lang.Var

var A_arbace_classes_types_A_const_92 *lang.Keyword

var A_arbace_classes_types_A_const_93 *lang.Var

var A_arbace_classes_types_A_const_94 *lang.Var

var A_arbace_classes_types_A_const_95 *lang.Var

var A_arbace_classes_types_A_const_96 *lang.Var

var A_arbace_classes_types_A_const_97 *lang.Var

var A_arbace_classes_types_A_const_98 any

var A_arbace_classes_types_A_const_99 *lang.Keyword

var A_arbace_classes_types_A_const_100 *lang.Var

var A_arbace_classes_types_A_const_101 *lang.Var

var A_arbace_classes_types_A_const_102 *lang.Var

var A_arbace_classes_types_A_const_103 *lang.Var

var A_arbace_classes_types_A_const_104 *lang.Keyword

var A_arbace_classes_types_A_const_105 any

var A_arbace_classes_types_A_const_106 *lang.Var

var A_arbace_classes_types_A_const_107 *lang.Var

var A_arbace_classes_types_A_const_108 *lang.Var

var A_arbace_classes_types_A_const_109 *lang.Var

var A_arbace_classes_types_A_const_110 *lang.Var

var A_arbace_classes_types_A_const_111 *lang.Var

var A_arbace_classes_types_A_const_112 *lang.Var

var A_arbace_classes_types_A_const_113 *lang.Var

var A_arbace_classes_types_A_const_114 *lang.Var

var A_arbace_classes_types_A_const_115 *lang.Var

var A_arbace_classes_types_A_const_116 *lang.Var

var A_arbace_classes_types_A_const_117 *lang.Var

var A_arbace_classes_types_A_const_118 *lang.Var

var A_arbace_classes_types_A_const_119 *lang.Var

var A_arbace_classes_types_A_const_120 any

var A_arbace_classes_types_A_const_121 *jrt.Class

var A_arbace_classes_types_A_const_122 *lang.Var

var A_arbace_classes_types_A_const_123 *lang.Var

var A_arbace_classes_types_A_const_124 *lang.Var

var A_arbace_classes_types_A_const_125 *lang.Var

var A_arbace_classes_types_A_init jrt.ClassInit

func A_arbace_classes_types_A_Init() { if !A_arbace_classes_types_A_init.Done() { A_arbace_classes_types_A_init.Run(A_arbace_classes_types_A_clinit) } }

func A_arbace_classes_types_A_clinit() { A_arbace_classes_types_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_classes_types_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_classes_types_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_types_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_classes_types_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_classes_types_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_classes_types_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_classes_types_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_classes_types_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_classes_types_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_classes_types_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_14); A_arbace_classes_types_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_classes_types_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_classes_types_A_const_13 = lang.RT_Var_String_String__Var(Lit_3, Lit_17); A_arbace_classes_types_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_classes_types_A_const_15 = lang.RT_Var_String_String__Var(Lit_9, Lit_19); A_arbace_classes_types_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_classes_types_A_const_17 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_classes_types_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_classes_types_A_const_19 = jrt.Character_ValueOf_C__Character(91).Ref(); A_arbace_classes_types_A_const_20 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_classes_types_A_const_21 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_types_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_classes_types_A_const_23 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,4,s1:Ss1:Cs1:Bs1:I", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_classes_types_A_const_24 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,7,s1:Js1:Ss1:Cs1:Fs1:Bs1:Is1:D", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_classes_types_A_const_25 = lang.RT_Var_String_String__Var(Lit_9, Lit_23); A_arbace_classes_types_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_classes_types_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_classes_types_A_const_28 = jrt.Character_ValueOf_C__Character(41).Ref(); A_arbace_classes_types_A_const_29 = jrt.Character_ValueOf_C__Character(76).Ref(); A_arbace_classes_types_A_const_30 = lang.RT_Var_String_String__Var(Lit_3, Lit_25); A_arbace_classes_types_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_classes_types_A_const_32 = lang.RT_Var_String_String__Var(Lit_9, Lit_27); A_arbace_classes_types_A_const_33 = lang.RT_Var_String_String__Var(Lit_9, Lit_28); A_arbace_classes_types_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_classes_types_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_classes_types_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_classes_types_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_classes_types_A_const_38 = jrt.Pattern_Compile_String__Pattern(Lit_33).Ref(); A_arbace_classes_types_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_classes_types_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_classes_types_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_classes_types_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_classes_types_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_classes_types_A_const_44 = lang.RT_Var_String_String__Var(Lit_9, Lit_39); A_arbace_classes_types_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_40); A_arbace_classes_types_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_classes_types_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_classes_types_A_const_48 = lang.RT_Var_String_String__Var(Lit_9, Lit_43); A_arbace_classes_types_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_classes_types_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_classes_types_A_const_51 = lang.RT_Var_String_String__Var(Lit_9, Lit_46); A_arbace_classes_types_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_classes_types_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_classes_types_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_classes_types_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_13); A_arbace_classes_types_A_const_56 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_classes_types_A_const_57 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_51).Ref(); A_arbace_classes_types_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), nil)); A_arbace_classes_types_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_classes_types_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_classes_types_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_classes_types_A_const_62 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_classes_types_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_classes_types_A_const_64 = lang.RT_Var_String_String__Var(Lit_9, Lit_59); A_arbace_classes_types_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_classes_types_A_const_66 = lang.RT_Var_String_String__Var(Lit_9, Lit_61); A_arbace_classes_types_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_classes_types_A_const_68 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref(); A_arbace_classes_types_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_classes_types_A_const_70 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_51).Ref(); A_arbace_classes_types_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_classes_types_A_const_72 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_classes_types_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_classes_types_A_const_74 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_classes_types_A_const_75 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref(); A_arbace_classes_types_A_const_76 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_classes_types_A_const_77 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_classes_types_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_classes_types_A_const_79 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_70).Ref(); A_arbace_classes_types_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_classes_types_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_classes_types_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_classes_types_A_const_83 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_classes_types_A_const_84 = lang.RT_Var_String_String__Var(Lit_9, Lit_75); A_arbace_classes_types_A_const_85 = lang.RT_Var_String_String__Var(Lit_9, Lit_76); A_arbace_classes_types_A_const_86 = lang.RT_Var_String_String__Var(Lit_9, Lit_77); A_arbace_classes_types_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_classes_types_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_classes_types_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_classes_types_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_classes_types_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_classes_types_A_const_92 = lang.RT_Keyword_String_String__Keyword(nil, Lit_83); A_arbace_classes_types_A_const_93 = lang.RT_Var_String_String__Var(Lit_9, Lit_84); A_arbace_classes_types_A_const_94 = lang.RT_Var_String_String__Var(Lit_9, Lit_85); A_arbace_classes_types_A_const_95 = lang.RT_Var_String_String__Var(Lit_9, Lit_86); A_arbace_classes_types_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_classes_types_A_const_97 = lang.RT_Var_String_String__Var(Lit_9, Lit_88); A_arbace_classes_types_A_const_98 = jrt.Pattern_Compile_String__Pattern(Lit_89).Ref(); A_arbace_classes_types_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_90); A_arbace_classes_types_A_const_100 = lang.RT_Var_String_String__Var(Lit_9, Lit_91); A_arbace_classes_types_A_const_101 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_classes_types_A_const_102 = lang.RT_Var_String_String__Var(Lit_9, Lit_93); A_arbace_classes_types_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_classes_types_A_const_104 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_classes_types_A_const_105 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(); A_arbace_classes_types_A_const_106 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_classes_types_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_classes_types_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_classes_types_A_const_109 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_classes_types_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_classes_types_A_const_111 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_classes_types_A_const_112 = lang.RT_Var_String_String__Var(Lit_0, Lit_102); A_arbace_classes_types_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_103); A_arbace_classes_types_A_const_114 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_classes_types_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_classes_types_A_const_116 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_classes_types_A_const_117 = lang.RT_Var_String_String__Var(Lit_9, Lit_107); A_arbace_classes_types_A_const_118 = lang.RT_Var_String_String__Var(Lit_9, Lit_108); A_arbace_classes_types_A_const_119 = lang.RT_Var_String_String__Var(Lit_9, Lit_109); A_arbace_classes_types_A_const_120 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), nil)); A_arbace_classes_types_A_const_121 = lang.RT_ClassForNameNonLoading_String__Class(Lit_110); A_arbace_classes_types_A_const_122 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_classes_types_A_const_123 = lang.RT_Var_String_String__Var(Lit_9, Lit_112); A_arbace_classes_types_A_const_124 = lang.RT_Var_String_String__Var(Lit_0, Lit_113); A_arbace_classes_types_A_const_125 = lang.RT_Var_String_String__Var(Lit_0, Lit_114) }

func A_arbace_classes_types_A_New() *A_arbace_classes_types_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_A) Ctor() {}

func (t *A_arbace_classes_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_A_class }

func (t *A_arbace_classes_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_A); return ok }

func A_arbace_classes_types_A_Cast(x any) *A_arbace_classes_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_A_class)) }; return v }



type A_arbace_classes_types_array_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_array_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_array_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_array_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_array_QMARK__A_Init() { if !A_arbace_classes_types_array_QMARK__A_init.Done() { A_arbace_classes_types_array_QMARK__A_init.Run(A_arbace_classes_types_array_QMARK__A_clinit) } }

func A_arbace_classes_types_array_QMARK__A_clinit() { A_arbace_classes_types_array_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_array_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_array_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_array_QMARK__A_class }

func (t *A_arbace_classes_types_array_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_array_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_array_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_array_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_array_QMARK__A); return ok }

func A_arbace_classes_types_array_QMARK__A_Cast(x any) *A_arbace_classes_types_array_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_array_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_array_QMARK__A_class)) }; return v }



type A_arbace_classes_types_array_dims_A struct{ jrt.Object }

func (t *A_arbace_classes_types_array_dims_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_array_dims_A_fn_class *jrt.Class

var A_arbace_classes_types_array_dims_A_init jrt.ClassInit

func A_arbace_classes_types_array_dims_A_Init() { if !A_arbace_classes_types_array_dims_A_init.Done() { A_arbace_classes_types_array_dims_A_init.Run(A_arbace_classes_types_array_dims_A_clinit) } }

func A_arbace_classes_types_array_dims_A_clinit() { A_arbace_classes_types_array_dims_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_array_dims_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_array_dims_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_array_dims_A_class }

func (t *A_arbace_classes_types_array_dims_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_array_dims_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_array_dims_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_array_dims_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_array_dims_A); return ok }

func A_arbace_classes_types_array_dims_A_Cast(x any) *A_arbace_classes_types_array_dims_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_array_dims_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_array_dims_A_class)) }; return v }



type A_arbace_classes_types_array_dims_fn__48000030_A struct{ jrt.Object }

func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_array_dims_fn__48000030_A_fn_class *jrt.Class

var A_arbace_classes_types_array_dims_fn__48000030_A_init jrt.ClassInit

func A_arbace_classes_types_array_dims_fn__48000030_A_Init() { if !A_arbace_classes_types_array_dims_fn__48000030_A_init.Done() { A_arbace_classes_types_array_dims_fn__48000030_A_init.Run(A_arbace_classes_types_array_dims_fn__48000030_A_clinit) } }

func A_arbace_classes_types_array_dims_fn__48000030_A_clinit() { A_arbace_classes_types_array_dims_fn__48000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_array_dims_fn__48000030_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_array_dims_fn__48000030_A_class }

func (t *A_arbace_classes_types_array_dims_fn__48000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_array_dims_fn__48000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_array_dims_fn__48000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_array_dims_fn__48000030_A); return ok }

func A_arbace_classes_types_array_dims_fn__48000030_A_Cast(x any) *A_arbace_classes_types_array_dims_fn__48000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_array_dims_fn__48000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_array_dims_fn__48000030_A_class)) }; return v }



type A_arbace_classes_types_array_of_A struct{ jrt.Object }

func (t *A_arbace_classes_types_array_of_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_array_of_A_fn_class *jrt.Class

var A_arbace_classes_types_array_of_A_init jrt.ClassInit

func A_arbace_classes_types_array_of_A_Init() { if !A_arbace_classes_types_array_of_A_init.Done() { A_arbace_classes_types_array_of_A_init.Run(A_arbace_classes_types_array_of_A_clinit) } }

func A_arbace_classes_types_array_of_A_clinit() { A_arbace_classes_types_array_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_array_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_array_of_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_array_of_A_class }

func (t *A_arbace_classes_types_array_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_array_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_array_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_array_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_array_of_A); return ok }

func A_arbace_classes_types_array_of_A_Cast(x any) *A_arbace_classes_types_array_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_array_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_array_of_A_class)) }; return v }



type A_arbace_classes_types_array_sym_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_array_sym_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_array_sym_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_array_sym_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_array_sym_QMARK__A_Init() { if !A_arbace_classes_types_array_sym_QMARK__A_init.Done() { A_arbace_classes_types_array_sym_QMARK__A_init.Run(A_arbace_classes_types_array_sym_QMARK__A_clinit) } }

func A_arbace_classes_types_array_sym_QMARK__A_clinit() { A_arbace_classes_types_array_sym_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_array_sym_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_array_sym_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_array_sym_QMARK__A_class }

func (t *A_arbace_classes_types_array_sym_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_array_sym_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_array_sym_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_array_sym_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_array_sym_QMARK__A); return ok }

func A_arbace_classes_types_array_sym_QMARK__A_Cast(x any) *A_arbace_classes_types_array_sym_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_array_sym_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_array_sym_QMARK__A_class)) }; return v }



type A_arbace_classes_types_bounds_map_A struct{ jrt.Object }

func (t *A_arbace_classes_types_bounds_map_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_bounds_map_A_fn_class *jrt.Class

var A_arbace_classes_types_bounds_map_A_init jrt.ClassInit

func A_arbace_classes_types_bounds_map_A_Init() { if !A_arbace_classes_types_bounds_map_A_init.Done() { A_arbace_classes_types_bounds_map_A_init.Run(A_arbace_classes_types_bounds_map_A_clinit) } }

func A_arbace_classes_types_bounds_map_A_clinit() { A_arbace_classes_types_bounds_map_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_bounds_map_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_bounds_map_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_bounds_map_A_class }

func (t *A_arbace_classes_types_bounds_map_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_bounds_map_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_bounds_map_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_bounds_map_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_bounds_map_A); return ok }

func A_arbace_classes_types_bounds_map_A_Cast(x any) *A_arbace_classes_types_bounds_map_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_bounds_map_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_bounds_map_A_class)) }; return v }



type A_arbace_classes_types_bounds_map_fn__48000121_A struct{ jrt.Object }

func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_bounds_map_fn__48000121_A_fn_class *jrt.Class

var A_arbace_classes_types_bounds_map_fn__48000121_A_init jrt.ClassInit

func A_arbace_classes_types_bounds_map_fn__48000121_A_Init() { if !A_arbace_classes_types_bounds_map_fn__48000121_A_init.Done() { A_arbace_classes_types_bounds_map_fn__48000121_A_init.Run(A_arbace_classes_types_bounds_map_fn__48000121_A_clinit) } }

func A_arbace_classes_types_bounds_map_fn__48000121_A_clinit() { A_arbace_classes_types_bounds_map_fn__48000121_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_bounds_map_fn__48000121_A_class }

func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_bounds_map_fn__48000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_bounds_map_fn__48000121_A); return ok }

func A_arbace_classes_types_bounds_map_fn__48000121_A_Cast(x any) *A_arbace_classes_types_bounds_map_fn__48000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_bounds_map_fn__48000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_bounds_map_fn__48000121_A_class)) }; return v }



type A_arbace_classes_types_class__GT_desc_A struct{ jrt.Object }

func (t *A_arbace_classes_types_class__GT_desc_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_class__GT_desc_A_fn_class *jrt.Class

var A_arbace_classes_types_class__GT_desc_A_init jrt.ClassInit

func A_arbace_classes_types_class__GT_desc_A_Init() { if !A_arbace_classes_types_class__GT_desc_A_init.Done() { A_arbace_classes_types_class__GT_desc_A_init.Run(A_arbace_classes_types_class__GT_desc_A_clinit) } }

func A_arbace_classes_types_class__GT_desc_A_clinit() { A_arbace_classes_types_class__GT_desc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_class__GT_desc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_class__GT_desc_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_class__GT_desc_A_class }

func (t *A_arbace_classes_types_class__GT_desc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_class__GT_desc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_class__GT_desc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_class__GT_desc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_class__GT_desc_A); return ok }

func A_arbace_classes_types_class__GT_desc_A_Cast(x any) *A_arbace_classes_types_class__GT_desc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_class__GT_desc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_class__GT_desc_A_class)) }; return v }



type A_arbace_classes_types_class_desc_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_class_desc_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_class_desc_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_class_desc_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_class_desc_QMARK__A_Init() { if !A_arbace_classes_types_class_desc_QMARK__A_init.Done() { A_arbace_classes_types_class_desc_QMARK__A_init.Run(A_arbace_classes_types_class_desc_QMARK__A_clinit) } }

func A_arbace_classes_types_class_desc_QMARK__A_clinit() { A_arbace_classes_types_class_desc_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_class_desc_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_class_desc_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_class_desc_QMARK__A_class }

func (t *A_arbace_classes_types_class_desc_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_class_desc_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_class_desc_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_class_desc_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_class_desc_QMARK__A); return ok }

func A_arbace_classes_types_class_desc_QMARK__A_Cast(x any) *A_arbace_classes_types_class_desc_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_class_desc_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_class_desc_QMARK__A_class)) }; return v }



type A_arbace_classes_types_desc__GT_class_name_A struct{ jrt.Object }

func (t *A_arbace_classes_types_desc__GT_class_name_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_desc__GT_class_name_A_fn_class *jrt.Class

var A_arbace_classes_types_desc__GT_class_name_A_init jrt.ClassInit

func A_arbace_classes_types_desc__GT_class_name_A_Init() { if !A_arbace_classes_types_desc__GT_class_name_A_init.Done() { A_arbace_classes_types_desc__GT_class_name_A_init.Run(A_arbace_classes_types_desc__GT_class_name_A_clinit) } }

func A_arbace_classes_types_desc__GT_class_name_A_clinit() { A_arbace_classes_types_desc__GT_class_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_desc__GT_class_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_desc__GT_class_name_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_desc__GT_class_name_A_class }

func (t *A_arbace_classes_types_desc__GT_class_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_desc__GT_class_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_desc__GT_class_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_desc__GT_class_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_desc__GT_class_name_A); return ok }

func A_arbace_classes_types_desc__GT_class_name_A_Cast(x any) *A_arbace_classes_types_desc__GT_class_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_desc__GT_class_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_desc__GT_class_name_A_class)) }; return v }



type A_arbace_classes_types_desc__GT_internal_A struct{ jrt.Object }

func (t *A_arbace_classes_types_desc__GT_internal_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_desc__GT_internal_A_fn_class *jrt.Class

var A_arbace_classes_types_desc__GT_internal_A_init jrt.ClassInit

func A_arbace_classes_types_desc__GT_internal_A_Init() { if !A_arbace_classes_types_desc__GT_internal_A_init.Done() { A_arbace_classes_types_desc__GT_internal_A_init.Run(A_arbace_classes_types_desc__GT_internal_A_clinit) } }

func A_arbace_classes_types_desc__GT_internal_A_clinit() { A_arbace_classes_types_desc__GT_internal_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_desc__GT_internal_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_desc__GT_internal_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_desc__GT_internal_A_class }

func (t *A_arbace_classes_types_desc__GT_internal_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_desc__GT_internal_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_desc__GT_internal_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_desc__GT_internal_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_desc__GT_internal_A); return ok }

func A_arbace_classes_types_desc__GT_internal_A_Cast(x any) *A_arbace_classes_types_desc__GT_internal_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_desc__GT_internal_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_desc__GT_internal_A_class)) }; return v }



type A_arbace_classes_types_desc__GT_tnode_A struct{ jrt.Object }

func (t *A_arbace_classes_types_desc__GT_tnode_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_desc__GT_tnode_A_fn_class *jrt.Class

var A_arbace_classes_types_desc__GT_tnode_A_init jrt.ClassInit

func A_arbace_classes_types_desc__GT_tnode_A_Init() { if !A_arbace_classes_types_desc__GT_tnode_A_init.Done() { A_arbace_classes_types_desc__GT_tnode_A_init.Run(A_arbace_classes_types_desc__GT_tnode_A_clinit) } }

func A_arbace_classes_types_desc__GT_tnode_A_clinit() { A_arbace_classes_types_desc__GT_tnode_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_desc__GT_tnode_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_desc__GT_tnode_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_desc__GT_tnode_A_class }

func (t *A_arbace_classes_types_desc__GT_tnode_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_desc__GT_tnode_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_desc__GT_tnode_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_desc__GT_tnode_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_desc__GT_tnode_A); return ok }

func A_arbace_classes_types_desc__GT_tnode_A_Cast(x any) *A_arbace_classes_types_desc__GT_tnode_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_desc__GT_tnode_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_desc__GT_tnode_A_class)) }; return v }



type A_arbace_classes_types_elem_type_A struct{ jrt.Object }

func (t *A_arbace_classes_types_elem_type_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_elem_type_A_fn_class *jrt.Class

var A_arbace_classes_types_elem_type_A_init jrt.ClassInit

func A_arbace_classes_types_elem_type_A_Init() { if !A_arbace_classes_types_elem_type_A_init.Done() { A_arbace_classes_types_elem_type_A_init.Run(A_arbace_classes_types_elem_type_A_clinit) } }

func A_arbace_classes_types_elem_type_A_clinit() { A_arbace_classes_types_elem_type_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_elem_type_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_elem_type_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_elem_type_A_class }

func (t *A_arbace_classes_types_elem_type_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_elem_type_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_elem_type_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_elem_type_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_elem_type_A); return ok }

func A_arbace_classes_types_elem_type_A_Cast(x any) *A_arbace_classes_types_elem_type_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_elem_type_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_elem_type_A_class)) }; return v }



type A_arbace_classes_types_element_path_A struct{ jrt.Object }

func (t *A_arbace_classes_types_element_path_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_element_path_A_fn_class *jrt.Class

var A_arbace_classes_types_element_path_A_init jrt.ClassInit

func A_arbace_classes_types_element_path_A_Init() { if !A_arbace_classes_types_element_path_A_init.Done() { A_arbace_classes_types_element_path_A_init.Run(A_arbace_classes_types_element_path_A_clinit) } }

func A_arbace_classes_types_element_path_A_clinit() { A_arbace_classes_types_element_path_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_element_path_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_element_path_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_element_path_A_class }

func (t *A_arbace_classes_types_element_path_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_element_path_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_element_path_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_element_path_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_element_path_A); return ok }

func A_arbace_classes_types_element_path_A_Cast(x any) *A_arbace_classes_types_element_path_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_element_path_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_element_path_A_class)) }; return v }



type A_arbace_classes_types_erase_A struct{ jrt.Object }

func (t *A_arbace_classes_types_erase_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_erase_A_fn_class *jrt.Class

var A_arbace_classes_types_erase_A_init jrt.ClassInit

func A_arbace_classes_types_erase_A_Init() { if !A_arbace_classes_types_erase_A_init.Done() { A_arbace_classes_types_erase_A_init.Run(A_arbace_classes_types_erase_A_clinit) } }

func A_arbace_classes_types_erase_A_clinit() { A_arbace_classes_types_erase_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_erase_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_erase_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_erase_A_class }

func (t *A_arbace_classes_types_erase_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_erase_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_erase_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_erase_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_erase_A); return ok }

func A_arbace_classes_types_erase_A_Cast(x any) *A_arbace_classes_types_erase_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_erase_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_erase_A_class)) }; return v }



type A_arbace_classes_types_eval48000004_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000004_A_New() *A_arbace_classes_types_eval48000004_A { t := &A_arbace_classes_types_eval48000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000004_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000004_A_class }

func (t *A_arbace_classes_types_eval48000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000004_A); return ok }

func A_arbace_classes_types_eval48000004_A_Cast(x any) *A_arbace_classes_types_eval48000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000004_A_class)) }; return v }



type A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A struct{ jrt.Object }

func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class *jrt.Class

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_init jrt.ClassInit

func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_Init() { if !A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_init.Done() { A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_init.Run(A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_clinit) } }

func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_clinit() { A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_class }

func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A); return ok }

func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_Cast(x any) *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_class)) }; return v }



type A_arbace_classes_types_eval48000008_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000008_A_New() *A_arbace_classes_types_eval48000008_A { t := &A_arbace_classes_types_eval48000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000008_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000008_A_class }

func (t *A_arbace_classes_types_eval48000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000008_A); return ok }

func A_arbace_classes_types_eval48000008_A_Cast(x any) *A_arbace_classes_types_eval48000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000008_A_class)) }; return v }



type A_arbace_classes_types_eval48000008_fn__48000009_A struct{ jrt.Object }

func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class *jrt.Class

var A_arbace_classes_types_eval48000008_fn__48000009_A_init jrt.ClassInit

func A_arbace_classes_types_eval48000008_fn__48000009_A_Init() { if !A_arbace_classes_types_eval48000008_fn__48000009_A_init.Done() { A_arbace_classes_types_eval48000008_fn__48000009_A_init.Run(A_arbace_classes_types_eval48000008_fn__48000009_A_clinit) } }

func A_arbace_classes_types_eval48000008_fn__48000009_A_clinit() { A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000008_fn__48000009_A_class }

func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000008_fn__48000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000008_fn__48000009_A); return ok }

func A_arbace_classes_types_eval48000008_fn__48000009_A_Cast(x any) *A_arbace_classes_types_eval48000008_fn__48000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000008_fn__48000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000008_fn__48000009_A_class)) }; return v }



type A_arbace_classes_types_fn__48000013_A struct{ jrt.Object }

func (t *A_arbace_classes_types_fn__48000013_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_fn__48000013_A_fn_class *jrt.Class

var A_arbace_classes_types_fn__48000013_A_init jrt.ClassInit

func A_arbace_classes_types_fn__48000013_A_Init() { if !A_arbace_classes_types_fn__48000013_A_init.Done() { A_arbace_classes_types_fn__48000013_A_init.Run(A_arbace_classes_types_fn__48000013_A_clinit) } }

func A_arbace_classes_types_fn__48000013_A_clinit() { A_arbace_classes_types_fn__48000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_fn__48000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_fn__48000013_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_fn__48000013_A_class }

func (t *A_arbace_classes_types_fn__48000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_fn__48000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_fn__48000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_fn__48000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_fn__48000013_A); return ok }

func A_arbace_classes_types_fn__48000013_A_Cast(x any) *A_arbace_classes_types_fn__48000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_fn__48000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_fn__48000013_A_class)) }; return v }



type A_arbace_classes_types_fn__48000037_A struct{ jrt.Object }

func (t *A_arbace_classes_types_fn__48000037_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_fn__48000037_A_fn_class *jrt.Class

var A_arbace_classes_types_fn__48000037_A_init jrt.ClassInit

func A_arbace_classes_types_fn__48000037_A_Init() { if !A_arbace_classes_types_fn__48000037_A_init.Done() { A_arbace_classes_types_fn__48000037_A_init.Run(A_arbace_classes_types_fn__48000037_A_clinit) } }

func A_arbace_classes_types_fn__48000037_A_clinit() { A_arbace_classes_types_fn__48000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_fn__48000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_fn__48000037_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_fn__48000037_A_class }

func (t *A_arbace_classes_types_fn__48000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_fn__48000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_fn__48000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_fn__48000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_fn__48000037_A); return ok }

func A_arbace_classes_types_fn__48000037_A_Cast(x any) *A_arbace_classes_types_fn__48000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_fn__48000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_fn__48000037_A_class)) }; return v }



type A_arbace_classes_types_generic_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_generic_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_generic_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_generic_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_generic_QMARK__A_Init() { if !A_arbace_classes_types_generic_QMARK__A_init.Done() { A_arbace_classes_types_generic_QMARK__A_init.Run(A_arbace_classes_types_generic_QMARK__A_clinit) } }

func A_arbace_classes_types_generic_QMARK__A_clinit() { A_arbace_classes_types_generic_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_generic_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_generic_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_generic_QMARK__A_class }

func (t *A_arbace_classes_types_generic_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_generic_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_generic_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_generic_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_generic_QMARK__A); return ok }

func A_arbace_classes_types_generic_QMARK__A_Cast(x any) *A_arbace_classes_types_generic_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_generic_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_generic_QMARK__A_class)) }; return v }



type A_arbace_classes_types_int_like_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_int_like_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_int_like_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_int_like_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_int_like_QMARK__A_Init() { if !A_arbace_classes_types_int_like_QMARK__A_init.Done() { A_arbace_classes_types_int_like_QMARK__A_init.Run(A_arbace_classes_types_int_like_QMARK__A_clinit) } }

func A_arbace_classes_types_int_like_QMARK__A_clinit() { A_arbace_classes_types_int_like_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_int_like_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_int_like_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_int_like_QMARK__A_class }

func (t *A_arbace_classes_types_int_like_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_int_like_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_int_like_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_int_like_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_int_like_QMARK__A); return ok }

func A_arbace_classes_types_int_like_QMARK__A_Cast(x any) *A_arbace_classes_types_int_like_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_int_like_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_int_like_QMARK__A_class)) }; return v }



type A_arbace_classes_types_internal__GT_desc_A struct{ jrt.Object }

func (t *A_arbace_classes_types_internal__GT_desc_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_internal__GT_desc_A_fn_class *jrt.Class

var A_arbace_classes_types_internal__GT_desc_A_init jrt.ClassInit

func A_arbace_classes_types_internal__GT_desc_A_Init() { if !A_arbace_classes_types_internal__GT_desc_A_init.Done() { A_arbace_classes_types_internal__GT_desc_A_init.Run(A_arbace_classes_types_internal__GT_desc_A_clinit) } }

func A_arbace_classes_types_internal__GT_desc_A_clinit() { A_arbace_classes_types_internal__GT_desc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_internal__GT_desc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_internal__GT_desc_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_internal__GT_desc_A_class }

func (t *A_arbace_classes_types_internal__GT_desc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_internal__GT_desc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_internal__GT_desc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_internal__GT_desc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_internal__GT_desc_A); return ok }

func A_arbace_classes_types_internal__GT_desc_A_Cast(x any) *A_arbace_classes_types_internal__GT_desc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_internal__GT_desc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_internal__GT_desc_A_class)) }; return v }



type A_arbace_classes_types_lang_class_A struct{ jrt.Object }

func (t *A_arbace_classes_types_lang_class_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_lang_class_A_fn_class *jrt.Class

var A_arbace_classes_types_lang_class_A_init jrt.ClassInit

func A_arbace_classes_types_lang_class_A_Init() { if !A_arbace_classes_types_lang_class_A_init.Done() { A_arbace_classes_types_lang_class_A_init.Run(A_arbace_classes_types_lang_class_A_clinit) } }

func A_arbace_classes_types_lang_class_A_clinit() { A_arbace_classes_types_lang_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_lang_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_lang_class_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_lang_class_A_class }

func (t *A_arbace_classes_types_lang_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_lang_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_lang_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_lang_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_lang_class_A); return ok }

func A_arbace_classes_types_lang_class_A_Cast(x any) *A_arbace_classes_types_lang_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_lang_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_lang_class_A_class)) }; return v }



type A_arbace_classes_types_lang_desc_A struct{ jrt.Object }

func (t *A_arbace_classes_types_lang_desc_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_lang_desc_A_fn_class *jrt.Class

var A_arbace_classes_types_lang_desc_A_init jrt.ClassInit

func A_arbace_classes_types_lang_desc_A_Init() { if !A_arbace_classes_types_lang_desc_A_init.Done() { A_arbace_classes_types_lang_desc_A_init.Run(A_arbace_classes_types_lang_desc_A_clinit) } }

func A_arbace_classes_types_lang_desc_A_clinit() { A_arbace_classes_types_lang_desc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_146, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_lang_desc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_lang_desc_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_lang_desc_A_class }

func (t *A_arbace_classes_types_lang_desc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_lang_desc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_lang_desc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_lang_desc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_lang_desc_A); return ok }

func A_arbace_classes_types_lang_desc_A_Cast(x any) *A_arbace_classes_types_lang_desc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_lang_desc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_lang_desc_A_class)) }; return v }



type A_arbace_classes_types_local_class_name_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_local_class_name_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_local_class_name_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_local_class_name_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_local_class_name_QMARK__A_Init() { if !A_arbace_classes_types_local_class_name_QMARK__A_init.Done() { A_arbace_classes_types_local_class_name_QMARK__A_init.Run(A_arbace_classes_types_local_class_name_QMARK__A_clinit) } }

func A_arbace_classes_types_local_class_name_QMARK__A_clinit() { A_arbace_classes_types_local_class_name_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_local_class_name_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_local_class_name_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_local_class_name_QMARK__A_class }

func (t *A_arbace_classes_types_local_class_name_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_local_class_name_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_local_class_name_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_local_class_name_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_local_class_name_QMARK__A); return ok }

func A_arbace_classes_types_local_class_name_QMARK__A_Cast(x any) *A_arbace_classes_types_local_class_name_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_local_class_name_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_local_class_name_QMARK__A_class)) }; return v }



type A_arbace_classes_types_method_desc_A struct{ jrt.Object }

func (t *A_arbace_classes_types_method_desc_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_method_desc_A_fn_class *jrt.Class

var A_arbace_classes_types_method_desc_A_init jrt.ClassInit

func A_arbace_classes_types_method_desc_A_Init() { if !A_arbace_classes_types_method_desc_A_init.Done() { A_arbace_classes_types_method_desc_A_init.Run(A_arbace_classes_types_method_desc_A_clinit) } }

func A_arbace_classes_types_method_desc_A_clinit() { A_arbace_classes_types_method_desc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_method_desc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_method_desc_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_method_desc_A_class }

func (t *A_arbace_classes_types_method_desc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_method_desc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_method_desc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_method_desc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_method_desc_A); return ok }

func A_arbace_classes_types_method_desc_A_Cast(x any) *A_arbace_classes_types_method_desc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_method_desc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_method_desc_A_class)) }; return v }



type A_arbace_classes_types_numeric_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_numeric_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_numeric_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_numeric_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_numeric_QMARK__A_Init() { if !A_arbace_classes_types_numeric_QMARK__A_init.Done() { A_arbace_classes_types_numeric_QMARK__A_init.Run(A_arbace_classes_types_numeric_QMARK__A_clinit) } }

func A_arbace_classes_types_numeric_QMARK__A_clinit() { A_arbace_classes_types_numeric_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_152, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_numeric_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_numeric_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_numeric_QMARK__A_class }

func (t *A_arbace_classes_types_numeric_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_numeric_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_numeric_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_numeric_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_numeric_QMARK__A); return ok }

func A_arbace_classes_types_numeric_QMARK__A_Cast(x any) *A_arbace_classes_types_numeric_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_numeric_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_numeric_QMARK__A_class)) }; return v }



type A_arbace_classes_types_package_of_A struct{ jrt.Object }

func (t *A_arbace_classes_types_package_of_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_package_of_A_fn_class *jrt.Class

var A_arbace_classes_types_package_of_A_init jrt.ClassInit

func A_arbace_classes_types_package_of_A_Init() { if !A_arbace_classes_types_package_of_A_init.Done() { A_arbace_classes_types_package_of_A_init.Run(A_arbace_classes_types_package_of_A_clinit) } }

func A_arbace_classes_types_package_of_A_clinit() { A_arbace_classes_types_package_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_153, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_package_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_package_of_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_package_of_A_class }

func (t *A_arbace_classes_types_package_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_package_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_package_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_package_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_package_of_A); return ok }

func A_arbace_classes_types_package_of_A_Cast(x any) *A_arbace_classes_types_package_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_package_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_package_of_A_class)) }; return v }



type A_arbace_classes_types_parse_method_desc_A struct{ jrt.Object }

func (t *A_arbace_classes_types_parse_method_desc_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_method_desc_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_method_desc_A_init jrt.ClassInit

func A_arbace_classes_types_parse_method_desc_A_Init() { if !A_arbace_classes_types_parse_method_desc_A_init.Done() { A_arbace_classes_types_parse_method_desc_A_init.Run(A_arbace_classes_types_parse_method_desc_A_clinit) } }

func A_arbace_classes_types_parse_method_desc_A_clinit() { A_arbace_classes_types_parse_method_desc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_154, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_method_desc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_method_desc_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_method_desc_A_class }

func (t *A_arbace_classes_types_parse_method_desc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_method_desc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_method_desc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_method_desc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_method_desc_A); return ok }

func A_arbace_classes_types_parse_method_desc_A_Cast(x any) *A_arbace_classes_types_parse_method_desc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_method_desc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_method_desc_A_class)) }; return v }



type A_arbace_classes_types_parse_method_desc_fn__48000045_A struct{ jrt.Object; F_d, F_i any }

func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_types_parse_method_desc_fn__48000045_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_method_desc_fn__48000045_A_init jrt.ClassInit

func A_arbace_classes_types_parse_method_desc_fn__48000045_A_Init() { if !A_arbace_classes_types_parse_method_desc_fn__48000045_A_init.Done() { A_arbace_classes_types_parse_method_desc_fn__48000045_A_init.Run(A_arbace_classes_types_parse_method_desc_fn__48000045_A_clinit) } }

func A_arbace_classes_types_parse_method_desc_fn__48000045_A_clinit() { A_arbace_classes_types_parse_method_desc_fn__48000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_method_desc_fn__48000045_A_class }

func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_method_desc_fn__48000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_method_desc_fn__48000045_A); return ok }

func A_arbace_classes_types_parse_method_desc_fn__48000045_A_Cast(x any) *A_arbace_classes_types_parse_method_desc_fn__48000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_method_desc_fn__48000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_method_desc_fn__48000045_A_class)) }; return v }



type A_arbace_classes_types_parse_type_A struct{ jrt.Object }

func (t *A_arbace_classes_types_parse_type_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_parse_type_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_A_Init() { if !A_arbace_classes_types_parse_type_A_init.Done() { A_arbace_classes_types_parse_type_A_init.Run(A_arbace_classes_types_parse_type_A_clinit) } }

func A_arbace_classes_types_parse_type_A_clinit() { A_arbace_classes_types_parse_type_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_A_class }

func (t *A_arbace_classes_types_parse_type_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_A); return ok }

func A_arbace_classes_types_parse_type_A_Cast(x any) *A_arbace_classes_types_parse_type_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_A_class)) }; return v }



type A_arbace_classes_types_parse_type_fn__48000063_A struct{ jrt.Object }

func (t *A_arbace_classes_types_parse_type_fn__48000063_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_type_fn__48000063_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000063_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_fn__48000063_A_Init() { if !A_arbace_classes_types_parse_type_fn__48000063_A_init.Done() { A_arbace_classes_types_parse_type_fn__48000063_A_init.Run(A_arbace_classes_types_parse_type_fn__48000063_A_clinit) } }

func A_arbace_classes_types_parse_type_fn__48000063_A_clinit() { A_arbace_classes_types_parse_type_fn__48000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_fn__48000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_fn__48000063_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_fn__48000063_A_class }

func (t *A_arbace_classes_types_parse_type_fn__48000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_fn__48000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_fn__48000063_A); return ok }

func A_arbace_classes_types_parse_type_fn__48000063_A_Cast(x any) *A_arbace_classes_types_parse_type_fn__48000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_fn__48000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_fn__48000063_A_class)) }; return v }



type A_arbace_classes_types_parse_type_fn__48000071_A struct{ jrt.Object; F_scope any }

func (t *A_arbace_classes_types_parse_type_fn__48000071_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_type_fn__48000071_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000071_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_fn__48000071_A_Init() { if !A_arbace_classes_types_parse_type_fn__48000071_A_init.Done() { A_arbace_classes_types_parse_type_fn__48000071_A_init.Run(A_arbace_classes_types_parse_type_fn__48000071_A_clinit) } }

func A_arbace_classes_types_parse_type_fn__48000071_A_clinit() { A_arbace_classes_types_parse_type_fn__48000071_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_fn__48000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_fn__48000071_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_fn__48000071_A_class }

func (t *A_arbace_classes_types_parse_type_fn__48000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000071_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_fn__48000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_fn__48000071_A); return ok }

func A_arbace_classes_types_parse_type_fn__48000071_A_Cast(x any) *A_arbace_classes_types_parse_type_fn__48000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_fn__48000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_fn__48000071_A_class)) }; return v }



type A_arbace_classes_types_parse_type_fn__48000073_A struct{ jrt.Object; F_scope any }

func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_parse_type_fn__48000073_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000073_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_fn__48000073_A_Init() { if !A_arbace_classes_types_parse_type_fn__48000073_A_init.Done() { A_arbace_classes_types_parse_type_fn__48000073_A_init.Run(A_arbace_classes_types_parse_type_fn__48000073_A_clinit) } }

func A_arbace_classes_types_parse_type_fn__48000073_A_clinit() { A_arbace_classes_types_parse_type_fn__48000073_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_fn__48000073_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_fn__48000073_A_class }

func (t *A_arbace_classes_types_parse_type_fn__48000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_fn__48000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_fn__48000073_A); return ok }

func A_arbace_classes_types_parse_type_fn__48000073_A_Cast(x any) *A_arbace_classes_types_parse_type_fn__48000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_fn__48000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_fn__48000073_A_class)) }; return v }



type A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A struct{ jrt.Object; F_scope any }

func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_Init() { if !A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_init.Done() { A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_init.Run(A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_clinit) } }

func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_clinit() { A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_class }

func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A); return ok }

func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_Cast(x any) *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_class)) }; return v }



type A_arbace_classes_types_parse_type_fn__48000080_A struct{ jrt.Object; F_scope any }

func (t *A_arbace_classes_types_parse_type_fn__48000080_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_type_fn__48000080_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000080_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_fn__48000080_A_Init() { if !A_arbace_classes_types_parse_type_fn__48000080_A_init.Done() { A_arbace_classes_types_parse_type_fn__48000080_A_init.Run(A_arbace_classes_types_parse_type_fn__48000080_A_clinit) } }

func A_arbace_classes_types_parse_type_fn__48000080_A_clinit() { A_arbace_classes_types_parse_type_fn__48000080_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_fn__48000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_fn__48000080_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_fn__48000080_A_class }

func (t *A_arbace_classes_types_parse_type_fn__48000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_fn__48000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_fn__48000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_fn__48000080_A); return ok }

func A_arbace_classes_types_parse_type_fn__48000080_A_Cast(x any) *A_arbace_classes_types_parse_type_fn__48000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_fn__48000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_fn__48000080_A_class)) }; return v }



type A_arbace_classes_types_parse_type_p__48000066_A struct{ jrt.Object }

func (t *A_arbace_classes_types_parse_type_p__48000066_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_type_p__48000066_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_p__48000066_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_p__48000066_A_Init() { if !A_arbace_classes_types_parse_type_p__48000066_A_init.Done() { A_arbace_classes_types_parse_type_p__48000066_A_init.Run(A_arbace_classes_types_parse_type_p__48000066_A_clinit) } }

func A_arbace_classes_types_parse_type_p__48000066_A_clinit() { A_arbace_classes_types_parse_type_p__48000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_p__48000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_p__48000066_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_p__48000066_A_class }

func (t *A_arbace_classes_types_parse_type_p__48000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_p__48000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_p__48000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_p__48000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_p__48000066_A); return ok }

func A_arbace_classes_types_parse_type_p__48000066_A_Cast(x any) *A_arbace_classes_types_parse_type_p__48000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_p__48000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_p__48000066_A_class)) }; return v }



type A_arbace_classes_types_parse_type_params_A struct{ jrt.Object }

func (t *A_arbace_classes_types_parse_type_params_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_parse_type_params_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_params_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_params_A_Init() { if !A_arbace_classes_types_parse_type_params_A_init.Done() { A_arbace_classes_types_parse_type_params_A_init.Run(A_arbace_classes_types_parse_type_params_A_clinit) } }

func A_arbace_classes_types_parse_type_params_A_clinit() { A_arbace_classes_types_parse_type_params_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_params_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_params_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_params_A_class }

func (t *A_arbace_classes_types_parse_type_params_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_params_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_params_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_params_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_params_A); return ok }

func A_arbace_classes_types_parse_type_params_A_Cast(x any) *A_arbace_classes_types_parse_type_params_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_params_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_params_A_class)) }; return v }



type A_arbace_classes_types_parse_type_params_fn__48000093_A struct{ jrt.Object; F_scope any }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_type_params_fn__48000093_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_params_fn__48000093_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_params_fn__48000093_A_Init() { if !A_arbace_classes_types_parse_type_params_fn__48000093_A_init.Done() { A_arbace_classes_types_parse_type_params_fn__48000093_A_init.Run(A_arbace_classes_types_parse_type_params_fn__48000093_A_clinit) } }

func A_arbace_classes_types_parse_type_params_fn__48000093_A_clinit() { A_arbace_classes_types_parse_type_params_fn__48000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_params_fn__48000093_A_class }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_params_fn__48000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_params_fn__48000093_A); return ok }

func A_arbace_classes_types_parse_type_params_fn__48000093_A_Cast(x any) *A_arbace_classes_types_parse_type_params_fn__48000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_params_fn__48000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_params_fn__48000093_A_class)) }; return v }



type A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A struct{ jrt.Object; F_scope any }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_fn_class *jrt.Class

var A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_init jrt.ClassInit

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_Init() { if !A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_init.Done() { A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_init.Run(A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_clinit) } }

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_clinit() { A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_class }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A); return ok }

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_Cast(x any) *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_class)) }; return v }



type A_arbace_classes_types_prim_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_prim_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_prim_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_prim_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_prim_QMARK__A_Init() { if !A_arbace_classes_types_prim_QMARK__A_init.Done() { A_arbace_classes_types_prim_QMARK__A_init.Run(A_arbace_classes_types_prim_QMARK__A_clinit) } }

func A_arbace_classes_types_prim_QMARK__A_clinit() { A_arbace_classes_types_prim_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_173, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_prim_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_prim_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_prim_QMARK__A_class }

func (t *A_arbace_classes_types_prim_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_prim_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_prim_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_prim_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_prim_QMARK__A); return ok }

func A_arbace_classes_types_prim_QMARK__A_Cast(x any) *A_arbace_classes_types_prim_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_prim_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_prim_QMARK__A_class)) }; return v }



type A_arbace_classes_types_ref_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_ref_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_ref_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_ref_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_ref_QMARK__A_Init() { if !A_arbace_classes_types_ref_QMARK__A_init.Done() { A_arbace_classes_types_ref_QMARK__A_init.Run(A_arbace_classes_types_ref_QMARK__A_clinit) } }

func A_arbace_classes_types_ref_QMARK__A_clinit() { A_arbace_classes_types_ref_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_174, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_ref_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_ref_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_ref_QMARK__A_class }

func (t *A_arbace_classes_types_ref_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_ref_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_ref_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_ref_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_ref_QMARK__A); return ok }

func A_arbace_classes_types_ref_QMARK__A_Cast(x any) *A_arbace_classes_types_ref_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_ref_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_ref_QMARK__A_class)) }; return v }



type A_arbace_classes_types_reflect__GT_tnode_A struct{ jrt.Object }

func (t *A_arbace_classes_types_reflect__GT_tnode_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_reflect__GT_tnode_A_fn_class *jrt.Class

var A_arbace_classes_types_reflect__GT_tnode_A_init jrt.ClassInit

func A_arbace_classes_types_reflect__GT_tnode_A_Init() { if !A_arbace_classes_types_reflect__GT_tnode_A_init.Done() { A_arbace_classes_types_reflect__GT_tnode_A_init.Run(A_arbace_classes_types_reflect__GT_tnode_A_clinit) } }

func A_arbace_classes_types_reflect__GT_tnode_A_clinit() { A_arbace_classes_types_reflect__GT_tnode_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_175, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_reflect__GT_tnode_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_reflect__GT_tnode_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_reflect__GT_tnode_A_class }

func (t *A_arbace_classes_types_reflect__GT_tnode_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_reflect__GT_tnode_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_reflect__GT_tnode_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_reflect__GT_tnode_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_reflect__GT_tnode_A); return ok }

func A_arbace_classes_types_reflect__GT_tnode_A_Cast(x any) *A_arbace_classes_types_reflect__GT_tnode_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_reflect__GT_tnode_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_reflect__GT_tnode_A_class)) }; return v }



type A_arbace_classes_types_signature_A struct{ jrt.Object }

func (t *A_arbace_classes_types_signature_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_signature_A_fn_class *jrt.Class

var A_arbace_classes_types_signature_A_init jrt.ClassInit

func A_arbace_classes_types_signature_A_Init() { if !A_arbace_classes_types_signature_A_init.Done() { A_arbace_classes_types_signature_A_init.Run(A_arbace_classes_types_signature_A_clinit) } }

func A_arbace_classes_types_signature_A_clinit() { A_arbace_classes_types_signature_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_186, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_signature_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_signature_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_signature_A_class }

func (t *A_arbace_classes_types_signature_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_signature_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_signature_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_signature_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_signature_A); return ok }

func A_arbace_classes_types_signature_A_Cast(x any) *A_arbace_classes_types_signature_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_signature_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_signature_A_class)) }; return v }



type A_arbace_classes_types_simple_name_of_A struct{ jrt.Object }

func (t *A_arbace_classes_types_simple_name_of_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_simple_name_of_A_fn_class *jrt.Class

var A_arbace_classes_types_simple_name_of_A_init jrt.ClassInit

func A_arbace_classes_types_simple_name_of_A_Init() { if !A_arbace_classes_types_simple_name_of_A_init.Done() { A_arbace_classes_types_simple_name_of_A_init.Run(A_arbace_classes_types_simple_name_of_A_clinit) } }

func A_arbace_classes_types_simple_name_of_A_clinit() { A_arbace_classes_types_simple_name_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_193, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_simple_name_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_simple_name_of_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_simple_name_of_A_class }

func (t *A_arbace_classes_types_simple_name_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_simple_name_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_simple_name_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_simple_name_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_simple_name_of_A); return ok }

func A_arbace_classes_types_simple_name_of_A_Cast(x any) *A_arbace_classes_types_simple_name_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_simple_name_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_simple_name_of_A_class)) }; return v }



type A_arbace_classes_types_size_A struct{ jrt.Object }

func (t *A_arbace_classes_types_size_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_size_A_fn_class *jrt.Class

var A_arbace_classes_types_size_A_init jrt.ClassInit

func A_arbace_classes_types_size_A_Init() { if !A_arbace_classes_types_size_A_init.Done() { A_arbace_classes_types_size_A_init.Run(A_arbace_classes_types_size_A_clinit) } }

func A_arbace_classes_types_size_A_clinit() { A_arbace_classes_types_size_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_size_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_size_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_size_A_class }

func (t *A_arbace_classes_types_size_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_size_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_size_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_size_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_size_A); return ok }

func A_arbace_classes_types_size_A_Cast(x any) *A_arbace_classes_types_size_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_size_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_size_A_class)) }; return v }



type A_arbace_classes_types_subst_A struct{ jrt.Object }

func (t *A_arbace_classes_types_subst_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_subst_A_fn_class *jrt.Class

var A_arbace_classes_types_subst_A_init jrt.ClassInit

func A_arbace_classes_types_subst_A_Init() { if !A_arbace_classes_types_subst_A_init.Done() { A_arbace_classes_types_subst_A_init.Run(A_arbace_classes_types_subst_A_clinit) } }

func A_arbace_classes_types_subst_A_clinit() { A_arbace_classes_types_subst_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_subst_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_subst_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_subst_A_class }

func (t *A_arbace_classes_types_subst_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_subst_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_subst_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_subst_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_subst_A); return ok }

func A_arbace_classes_types_subst_A_Cast(x any) *A_arbace_classes_types_subst_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_subst_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_subst_A_class)) }; return v }



type A_arbace_classes_types_subst_fn__48000134_A struct{ jrt.Object; F_env any }

func (t *A_arbace_classes_types_subst_fn__48000134_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_subst_fn__48000134_A_fn_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000134_A_init jrt.ClassInit

func A_arbace_classes_types_subst_fn__48000134_A_Init() { if !A_arbace_classes_types_subst_fn__48000134_A_init.Done() { A_arbace_classes_types_subst_fn__48000134_A_init.Run(A_arbace_classes_types_subst_fn__48000134_A_clinit) } }

func A_arbace_classes_types_subst_fn__48000134_A_clinit() { A_arbace_classes_types_subst_fn__48000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_subst_fn__48000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_subst_fn__48000134_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_subst_fn__48000134_A_class }

func (t *A_arbace_classes_types_subst_fn__48000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_subst_fn__48000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_subst_fn__48000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_subst_fn__48000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_subst_fn__48000134_A); return ok }

func A_arbace_classes_types_subst_fn__48000134_A_Cast(x any) *A_arbace_classes_types_subst_fn__48000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_subst_fn__48000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_subst_fn__48000134_A_class)) }; return v }



type A_arbace_classes_types_subst_fn__48000137_A struct{ jrt.Object; F_env any }

func (t *A_arbace_classes_types_subst_fn__48000137_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_subst_fn__48000137_A_fn_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000137_A_init jrt.ClassInit

func A_arbace_classes_types_subst_fn__48000137_A_Init() { if !A_arbace_classes_types_subst_fn__48000137_A_init.Done() { A_arbace_classes_types_subst_fn__48000137_A_init.Run(A_arbace_classes_types_subst_fn__48000137_A_clinit) } }

func A_arbace_classes_types_subst_fn__48000137_A_clinit() { A_arbace_classes_types_subst_fn__48000137_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_subst_fn__48000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_subst_fn__48000137_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_subst_fn__48000137_A_class }

func (t *A_arbace_classes_types_subst_fn__48000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_subst_fn__48000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_subst_fn__48000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_subst_fn__48000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_subst_fn__48000137_A); return ok }

func A_arbace_classes_types_subst_fn__48000137_A_Cast(x any) *A_arbace_classes_types_subst_fn__48000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_subst_fn__48000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_subst_fn__48000137_A_class)) }; return v }



type A_arbace_classes_types_subst_fn__48000139_A struct{ jrt.Object; F_env any }

func (t *A_arbace_classes_types_subst_fn__48000139_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_subst_fn__48000139_A_fn_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000139_A_init jrt.ClassInit

func A_arbace_classes_types_subst_fn__48000139_A_Init() { if !A_arbace_classes_types_subst_fn__48000139_A_init.Done() { A_arbace_classes_types_subst_fn__48000139_A_init.Run(A_arbace_classes_types_subst_fn__48000139_A_clinit) } }

func A_arbace_classes_types_subst_fn__48000139_A_clinit() { A_arbace_classes_types_subst_fn__48000139_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_subst_fn__48000139_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_subst_fn__48000139_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_subst_fn__48000139_A_class }

func (t *A_arbace_classes_types_subst_fn__48000139_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_subst_fn__48000139_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_subst_fn__48000139_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_subst_fn__48000139_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_subst_fn__48000139_A); return ok }

func A_arbace_classes_types_subst_fn__48000139_A_Cast(x any) *A_arbace_classes_types_subst_fn__48000139_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_subst_fn__48000139_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_subst_fn__48000139_A_class)) }; return v }



type A_arbace_classes_types_subst_fn__48000141_A struct{ jrt.Object; F_env any }

func (t *A_arbace_classes_types_subst_fn__48000141_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_subst_fn__48000141_A_fn_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000141_A_init jrt.ClassInit

func A_arbace_classes_types_subst_fn__48000141_A_Init() { if !A_arbace_classes_types_subst_fn__48000141_A_init.Done() { A_arbace_classes_types_subst_fn__48000141_A_init.Run(A_arbace_classes_types_subst_fn__48000141_A_clinit) } }

func A_arbace_classes_types_subst_fn__48000141_A_clinit() { A_arbace_classes_types_subst_fn__48000141_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_subst_fn__48000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_subst_fn__48000141_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_subst_fn__48000141_A_class }

func (t *A_arbace_classes_types_subst_fn__48000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_subst_fn__48000141_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_subst_fn__48000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_subst_fn__48000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_subst_fn__48000141_A); return ok }

func A_arbace_classes_types_subst_fn__48000141_A_Cast(x any) *A_arbace_classes_types_subst_fn__48000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_subst_fn__48000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_subst_fn__48000141_A_class)) }; return v }



type A_arbace_classes_types_subst_fn__48000143_A struct{ jrt.Object; F_env any }

func (t *A_arbace_classes_types_subst_fn__48000143_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_subst_fn__48000143_A_fn_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000143_A_init jrt.ClassInit

func A_arbace_classes_types_subst_fn__48000143_A_Init() { if !A_arbace_classes_types_subst_fn__48000143_A_init.Done() { A_arbace_classes_types_subst_fn__48000143_A_init.Run(A_arbace_classes_types_subst_fn__48000143_A_clinit) } }

func A_arbace_classes_types_subst_fn__48000143_A_clinit() { A_arbace_classes_types_subst_fn__48000143_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_subst_fn__48000143_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_subst_fn__48000143_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_subst_fn__48000143_A_class }

func (t *A_arbace_classes_types_subst_fn__48000143_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_subst_fn__48000143_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_subst_fn__48000143_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_subst_fn__48000143_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_subst_fn__48000143_A); return ok }

func A_arbace_classes_types_subst_fn__48000143_A_Cast(x any) *A_arbace_classes_types_subst_fn__48000143_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_subst_fn__48000143_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_subst_fn__48000143_A_class)) }; return v }



type A_arbace_classes_types_type_anns_A struct{ jrt.Object }

func (t *A_arbace_classes_types_type_anns_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_type_anns_A_fn_class *jrt.Class

var A_arbace_classes_types_type_anns_A_init jrt.ClassInit

func A_arbace_classes_types_type_anns_A_Init() { if !A_arbace_classes_types_type_anns_A_init.Done() { A_arbace_classes_types_type_anns_A_init.Run(A_arbace_classes_types_type_anns_A_clinit) } }

func A_arbace_classes_types_type_anns_A_clinit() { A_arbace_classes_types_type_anns_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_anns_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_anns_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_anns_A_class }

func (t *A_arbace_classes_types_type_anns_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_anns_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_anns_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_anns_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_anns_A); return ok }

func A_arbace_classes_types_type_anns_A_Cast(x any) *A_arbace_classes_types_type_anns_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_anns_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_anns_A_class)) }; return v }



type A_arbace_classes_types_type_anns_walk__48000146_A struct{ jrt.Object }

func (t *A_arbace_classes_types_type_anns_walk__48000146_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_type_anns_walk__48000146_A_fn_class *jrt.Class

var A_arbace_classes_types_type_anns_walk__48000146_A_init jrt.ClassInit

func A_arbace_classes_types_type_anns_walk__48000146_A_Init() { if !A_arbace_classes_types_type_anns_walk__48000146_A_init.Done() { A_arbace_classes_types_type_anns_walk__48000146_A_init.Run(A_arbace_classes_types_type_anns_walk__48000146_A_clinit) } }

func A_arbace_classes_types_type_anns_walk__48000146_A_clinit() { A_arbace_classes_types_type_anns_walk__48000146_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_anns_walk__48000146_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_anns_walk__48000146_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_anns_walk__48000146_A_class }

func (t *A_arbace_classes_types_type_anns_walk__48000146_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_anns_walk__48000146_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_anns_walk__48000146_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_anns_walk__48000146_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_anns_walk__48000146_A); return ok }

func A_arbace_classes_types_type_anns_walk__48000146_A_Cast(x any) *A_arbace_classes_types_type_anns_walk__48000146_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_anns_walk__48000146_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_anns_walk__48000146_A_class)) }; return v }



type A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A struct{ jrt.Object; F_path, F_walk any }

func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_fn_class *jrt.Class

var A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_init jrt.ClassInit

func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_Init() { if !A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_init.Done() { A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_init.Run(A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_clinit) } }

func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_clinit() { A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_class }

func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A); return ok }

func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_Cast(x any) *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_class)) }; return v }



type A_arbace_classes_types_type_params_signature_A struct{ jrt.Object }

func (t *A_arbace_classes_types_type_params_signature_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_type_params_signature_A_fn_class *jrt.Class

var A_arbace_classes_types_type_params_signature_A_init jrt.ClassInit

func A_arbace_classes_types_type_params_signature_A_Init() { if !A_arbace_classes_types_type_params_signature_A_init.Done() { A_arbace_classes_types_type_params_signature_A_init.Run(A_arbace_classes_types_type_params_signature_A_clinit) } }

func A_arbace_classes_types_type_params_signature_A_clinit() { A_arbace_classes_types_type_params_signature_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_params_signature_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_params_signature_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_params_signature_A_class }

func (t *A_arbace_classes_types_type_params_signature_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_params_signature_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_params_signature_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_params_signature_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_params_signature_A); return ok }

func A_arbace_classes_types_type_params_signature_A_Cast(x any) *A_arbace_classes_types_type_params_signature_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_params_signature_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_params_signature_A_class)) }; return v }



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A struct{ jrt.Object; F_interface_QMARK_ any }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_fn_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_init jrt.ClassInit

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_Init() { if !A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_init.Done() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_init.Run(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_clinit) } }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_clinit() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_207, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_class }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A); return ok }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_Cast(x any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_class)) }; return v }



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A struct{ jrt.Object; F_interface_QMARK_, F_s__48000102, F_iter__48000101 any }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_fn_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_init jrt.ClassInit

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_Init() { if !A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_init.Done() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_init.Run(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_clinit) } }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_clinit() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_class }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A); return ok }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_Cast(x any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_class)) }; return v }



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A struct{ jrt.Object; F_b__48000104, F_interface_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_fn_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_init jrt.ClassInit

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_Init() { if !A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_init.Done() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_init.Run(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_clinit) } }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_clinit() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_class }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A); return ok }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_Cast(x any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_class)) }; return v }



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A struct{ jrt.Object; F_interface_QMARK_ any }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_fn_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_init jrt.ClassInit

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_Init() { if !A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_init.Done() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_init.Run(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_clinit) } }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_clinit() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_class }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A); return ok }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_Cast(x any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_class)) }; return v }



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A struct{ jrt.Object; F_interface_QMARK_ any }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_fn_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_init jrt.ClassInit

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_Init() { if !A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_init.Done() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_init.Run(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_clinit) } }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_clinit() { A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_class }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A); return ok }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_Cast(x any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_class)) }; return v }



type A_arbace_classes_types_void_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_types_void_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_void_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_types_void_QMARK__A_init jrt.ClassInit

func A_arbace_classes_types_void_QMARK__A_Init() { if !A_arbace_classes_types_void_QMARK__A_init.Done() { A_arbace_classes_types_void_QMARK__A_init.Run(A_arbace_classes_types_void_QMARK__A_clinit) } }

func A_arbace_classes_types_void_QMARK__A_clinit() { A_arbace_classes_types_void_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_void_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_void_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_void_QMARK__A_class }

func (t *A_arbace_classes_types_void_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_void_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_void_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_void_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_void_QMARK__A); return ok }

func A_arbace_classes_types_void_QMARK__A_Cast(x any) *A_arbace_classes_types_void_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_void_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_void_QMARK__A_class)) }; return v }



type A_arbace_classes_types_with_anns_A struct{ jrt.Object }

func (t *A_arbace_classes_types_with_anns_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_types_with_anns_A_fn_class *jrt.Class

var A_arbace_classes_types_with_anns_A_init jrt.ClassInit

func A_arbace_classes_types_with_anns_A_Init() { if !A_arbace_classes_types_with_anns_A_init.Done() { A_arbace_classes_types_with_anns_A_init.Run(A_arbace_classes_types_with_anns_A_clinit) } }

func A_arbace_classes_types_with_anns_A_clinit() { A_arbace_classes_types_with_anns_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_with_anns_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_with_anns_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_with_anns_A_class }

func (t *A_arbace_classes_types_with_anns_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_with_anns_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_with_anns_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_with_anns_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_with_anns_A); return ok }

func A_arbace_classes_types_with_anns_A_Cast(x any) *A_arbace_classes_types_with_anns_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_with_anns_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_with_anns_A_class)) }; return v }



type A_arbace_classes_types_with_anns_fn__48000054_A struct{ jrt.Object }

func (t *A_arbace_classes_types_with_anns_fn__48000054_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_types_with_anns_fn__48000054_A_fn_class *jrt.Class

var A_arbace_classes_types_with_anns_fn__48000054_A_init jrt.ClassInit

func A_arbace_classes_types_with_anns_fn__48000054_A_Init() { if !A_arbace_classes_types_with_anns_fn__48000054_A_init.Done() { A_arbace_classes_types_with_anns_fn__48000054_A_init.Run(A_arbace_classes_types_with_anns_fn__48000054_A_clinit) } }

func A_arbace_classes_types_with_anns_fn__48000054_A_clinit() { A_arbace_classes_types_with_anns_fn__48000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_types_with_anns_fn__48000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_with_anns_fn__48000054_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_with_anns_fn__48000054_A_class }

func (t *A_arbace_classes_types_with_anns_fn__48000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_with_anns_fn__48000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_with_anns_fn__48000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_with_anns_fn__48000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_with_anns_fn__48000054_A); return ok }

func A_arbace_classes_types_with_anns_fn__48000054_A_Cast(x any) *A_arbace_classes_types_with_anns_fn__48000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_with_anns_fn__48000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_with_anns_fn__48000054_A_class)) }; return v }
