//line aot_arbace_classes_types.ae:1
package aot_arbace_classes_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New() *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_types_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_types_eval48000008_fn__48000009_A_New() *A_arbace_classes_types_eval48000008_fn__48000009_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000008_fn__48000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_classes_types_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_classes_types_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_types_A_const_7.GetRawRoot__O(), A_arbace_classes_types_A_const_8) }















func A_arbace_classes_types_fn__48000013_A_New() *A_arbace_classes_types_fn__48000013_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000013_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Ctor() {}
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Invoke_O_O__O(self, p__48000012__0 any) any { var vec__48000014__2 any = p__48000012__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_19 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = k__3; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_19, arg_22) }; return lang.Tuple_Create_O_O__IPersistentVector(v__4, tmp1) }













func A_arbace_classes_types_lang_class_A_New() *A_arbace_classes_types_lang_class_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_class_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Ctor() {}
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0)).Ref() }
func A_arbace_classes_types_lang_desc_A_New() *A_arbace_classes_types_lang_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_desc_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Ctor() {}
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_5, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0, nil)).Ref() }

func A_arbace_classes_types_prim_QMARK__A_New() *A_arbace_classes_types_prim_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_prim_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_23 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = t__0; if linked_24 == nil { and__1927000168__auto____2 = ifn_25.Invoke_O__O(arg_26) } else { and__1927000168__auto____2 = linked_24.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_23, arg_26) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(t__0))); if and__1927000168__auto____3 { var root_27 any = A_arbace_classes_types_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = t__0; var arg_31 any = Lit_8; if linked_28 == nil { return ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { return linked_28.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_27, arg_30, arg_31) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_void_QMARK__A_New() *A_arbace_classes_types_void_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_void_QMARK__A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Ctor() {}
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8)).Ref() }
func A_arbace_classes_types_array_QMARK__A_New() *A_arbace_classes_types_array_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_32 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = t__0; if linked_33 == nil { and__1927000168__auto____2 = ifn_34.Invoke_O__O(arg_35) } else { and__1927000168__auto____2 = linked_33.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_36 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = t__0; var arg_40 any = Lit_1; if linked_37 == nil { return ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { return linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_ref_QMARK__A_New() *A_arbace_classes_types_ref_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_ref_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_classes_types_A_const_14); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var and__1927000168__auto____3 any; var root_41 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = t__0; if linked_42 == nil { and__1927000168__auto____3 = ifn_43.Invoke_O__O(arg_44) } else { and__1927000168__auto____3 = linked_42.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_45 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = t__0; var arg_49 any = Lit_6; if linked_46 == nil { or__1927000174__auto____4 = ifn_47.Invoke_O_O__O(arg_48, arg_49) } else { or__1927000174__auto____4 = linked_46.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_45, arg_48, arg_49) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_50 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = t__0; if linked_51 == nil { return ifn_52.Invoke_O__O(arg_53) } else { return linked_51.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_50, arg_53) } } } else { return and__1927000168__auto____3 } } }
func A_arbace_classes_types_class_desc_QMARK__A_New() *A_arbace_classes_types_class_desc_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class_desc_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_54 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = t__0; if linked_55 == nil { and__1927000168__auto____2 = ifn_56.Invoke_O__O(arg_57) } else { and__1927000168__auto____2 = linked_55.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_54, arg_57) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_58 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = t__0; var arg_62 any = Lit_6; if linked_59 == nil { return ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { return linked_59.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_58, arg_61, arg_62) } } else { return and__1927000168__auto____2 } }

func A_arbace_classes_types_internal__GT_desc_A_New() *A_arbace_classes_types_internal__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_internal__GT_desc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var root_63 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = n__0; var arg_67 any = Lit_1; if linked_64 == nil { tmp1 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { tmp1 = linked_64.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if jrt.J2g_Truth(tmp1) { return n__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref() } }
func A_arbace_classes_types_desc__GT_internal_A_New() *A_arbace_classes_types_desc__GT_internal_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_internal_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Ctor() {}
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_68 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = d__0; var arg_72 any = Lit_6; if linked_69 == nil { tmp1 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp1 = linked_69.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; if jrt.J2g_Truth(tmp1) { var root_73 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = d__0; var arg_77 any = A_arbace_classes_types_A_const_17; var arg_78 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(d__0)))).Ref(); if linked_74 == nil { return ifn_75.Invoke_O_O_O__O(arg_76, arg_77, arg_78) } else { return linked_74.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_73, arg_76, arg_77, arg_78) } } else { return d__0
	} }
func A_arbace_classes_types_elem_type_A_New() *A_arbace_classes_types_elem_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_elem_type_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Invoke_O_O__O(self, d__0 any) any { var root_79 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = d__0; var arg_83 any = A_arbace_classes_types_A_const_17; if linked_80 == nil { return ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { return linked_80.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) } }
func A_arbace_classes_types_array_of_A_New() *A_arbace_classes_types_array_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_of_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Invoke_O_O__O(self, d__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__0)).Ref() }
func A_arbace_classes_types_array_dims_A_New() *A_arbace_classes_types_array_dims_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 any; var root_84 any = A_arbace_classes_types_A_const_18.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var tmp2 any = A_arbace_classes_types_array_dims_fn__48000030_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_types_array_dims_fn__48000030_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_types_array_dims_fn__48000030_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; arg_87 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_88 any = d__0; if linked_85 == nil { tmp1 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref() }
//line :48:1
func A_arbace_classes_types_array_dims_fn__48000030_A_New() *A_arbace_classes_types_array_dims_fn__48000030_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_fn__48000030_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Invoke_O_O__O(self, p1__48000029_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_19, p1__48000029_SHARP___1)).Ref() }

func A_arbace_classes_types_size_A_New() *A_arbace_classes_types_size_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_size_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_classes_types_size_A) Ctor() {}
//line :50:1
func (t *A_arbace_classes_types_size_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_46); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_47) }; if tmp1 { return A_arbace_classes_types_A_const_20 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8) { return A_arbace_classes_types_A_const_21 } else { return A_arbace_classes_types_A_const_17 } } }

func A_arbace_classes_types_int_like_QMARK__A_New() *A_arbace_classes_types_int_like_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_int_like_QMARK__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_90 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_classes_types_A_const_23; var arg_94 any = t__0; if linked_91 == nil { return ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { return linked_91.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_90, arg_93, arg_94) } }
func A_arbace_classes_types_numeric_QMARK__A_New() *A_arbace_classes_types_numeric_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_95 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = A_arbace_classes_types_A_const_24; var arg_99 any = t__0; if linked_96 == nil { return ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { return linked_96.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_95, arg_98, arg_99) } }




func A_arbace_classes_types_fn__48000037_A_New() *A_arbace_classes_types_fn__48000037_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000037_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Ctor() {}
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Invoke_O_O__O(self, p__48000036__0 any) any { var vec__48000038__2 any = p__48000036__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_100 any = A_arbace_classes_types_A_const_25.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = v__4; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_100, arg_103) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, k__3) }

func A_arbace_classes_types_method_desc_A_New() *A_arbace_classes_types_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_method_desc_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Invoke_O_O_O__O(self, params__0, ret__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13, nil); var tmp2 any; var root_104 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_108 any = params__0; if linked_105 == nil { tmp2 = ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { tmp2 = linked_105.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, ret__1)).Ref() }






func A_arbace_classes_types_parse_method_desc_A_New() *A_arbace_classes_types_parse_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Ctor() {}
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Invoke_O_O__O(self, d__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Get_O__O(d__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var tmp1 any = A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class
		if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class = fncls__132d; tmp2 = fncls__132d } else { tmp2 = fncls__132 }; r__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()





		jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Put_O_O__O(d__0, r__3)
//line :70:1
		return r__3 } }
func A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(p0 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Invoke_O__O(self any) any { { var i__1 any = lang.RT_Box_J__Number_NoInit(1); var ps__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_29)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))) { var tmp2 any; var root_114 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_116 lang.IFn
													if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = t.F_d; var arg_118 any; var na_119 any = i__1; if jrt.Long_InstanceOf(na_119) { var n0_120 int64 = jrt.NN(jrt.Long_Cast(na_119)).LongValue__J(); if n0_120 == 9223372036854775807 { arg_118 = lang.Numbers_Inc_O__Number_NoInit(na_119) } else { arg_118 = jrt.Long_ValueOf_J__Long_NoInit(n0_120 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_119) { var n0_120_2 float64 = jrt.NN(jrt.Double_Cast(na_119)).DoubleValue__D(); arg_118 = jrt.Double_ValueOf_D__Double_NoInit(n0_120_2 + 1.0).Ref() } else { arg_118 = lang.Numbers_Inc_O__Number_NoInit(na_119) } }; if linked_115 == nil { tmp2 = ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { tmp2 = linked_115.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) }
//line :72:1
		return lang.Tuple_Create_O_O__IPersistentVector(ps__2, tmp2) } else { var j__3 any; var tmp3 any = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(t.F_d, i__1); var tmp4 *jrt.Class
			var fncls__111 /*line :72:1*/*jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class

			if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class = fncls__111d; tmp4 = fncls__111d } else { tmp4 = fncls__111 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :72:1
			var end__4 any; var tmp5 *jrt.String = jrt.String_Cast(t.F_d)


			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_30)).CharValue__C(), jrt.NN(tmp5).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__3))) { var tmp6 *jrt.String = jrt.String_Cast(t.F_d); end__4 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(tmp6).IndexOf_String_I__I(Lit_7, lang.RT_IntCast_O__I_NoInit(j__3))))).Ref() } else { var na_112 any = j__3; if jrt.Long_InstanceOf(na_112) { var n0_113 int64 = jrt.NN(jrt.Long_Cast(na_112)).LongValue__J(); if n0_113 == 9223372036854775807 { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_112) } else { end__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_113 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_112) { var n0_113_2 float64 = jrt.NN(jrt.Double_Cast(na_112)).DoubleValue__D(); end__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_113_2 + 1.0).Ref() } else { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_112) } } }
			var tmp7 any; var root_121 any = A_arbace_classes_types_A_const_7.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = ps__2; var arg_125 any; var root_126 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = t.F_d; var arg_130 any = i__1; var arg_131 any = end__4; if linked_127 == nil { arg_125 = ifn_128.Invoke_O_O_O__O(arg_129, arg_130, arg_131) } else { arg_125 = linked_127.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_126, arg_129, arg_130, arg_131) }; if linked_122 == nil { tmp7 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { tmp7 = linked_122.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; i__1, ps__2 = end__4, tmp7; continue L1 } } }; /*line :71:1*/panic("j2g: unreachable") }


func A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(p0, p1 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_19)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) { var tmp2 jrt.Number_I; var na_109 any = j__1; if jrt.Long_InstanceOf(na_109) { var n0_110 int64 = jrt.NN(jrt.Long_Cast(na_109)).LongValue__J(); if n0_110 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_109) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_110 + 1)) } } else { if jrt.Double_InstanceOf(na_109) { var n0_110_2 float64 = jrt.NN(jrt.Double_Cast(na_109)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_110_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_109) } }; j__1 = tmp2; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_package_of_A_New() *A_arbace_classes_types_package_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_package_of_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Invoke_O_O__O(self, internal__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5); if
											lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_9 } else { var root_133 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = internal__0; var arg_137 any = A_arbace_classes_types_A_const_21; var arg_138 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_134 == nil { return ifn_135.Invoke_O_O_O__O(arg_136, arg_137, arg_138) } else { return linked_134.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_133, arg_136, arg_137, arg_138) } } }

func A_arbace_classes_types_simple_name_of_A_New() *A_arbace_classes_types_simple_name_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_simple_name_of_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Ctor() {}
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Invoke_O_O__O(self, internal__0 any) any { var n__2 any; var root_139 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_141 lang.IFn; if
												linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = internal__0; var arg_143 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5)))).Ref(); if linked_140 == nil { n__2 = ifn_141.Invoke_O_O__O(arg_142, arg_143) } else { n__2 = linked_140.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_139, arg_142, arg_143) }; var root_144 any =
												A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = n__2; var arg_148 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(n__2)).LastIndexOf_String__I(Lit_11)))).Ref(); if linked_145 == nil { return ifn_146.Invoke_O_O__O(arg_147, arg_148) } else { return linked_145.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_144, arg_147, arg_148) } }

func A_arbace_classes_types_desc__GT_class_name_A_New() *A_arbace_classes_types_desc__GT_class_name_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_class_name_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Ctor() {}
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_149 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = d__0; if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_149, arg_152) }; if jrt.J2g_Truth(tmp1) { var root_153 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = d__0; var arg_157 any = Lit_5; var arg_158 any = Lit_4; if linked_154 == nil { return ifn_155.Invoke_O_O_O__O(arg_156, arg_157, arg_158) } else { return linked_154.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_153, arg_156, arg_157, arg_158) } } else { if A_arbace_classes_types_A_const_32 != nil {
		var root_159 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_165 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = d__0; if linked_166 == nil { arg_162 = ifn_167.Invoke_O__O(arg_168) } else { arg_162 = linked_166.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_165, arg_168) }; var arg_163 any = Lit_5; var arg_164 any = Lit_4; if linked_160 == nil { return ifn_161.Invoke_O_O_O__O(arg_162, arg_163, arg_164) } else { return linked_160.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_159, arg_162, arg_163, arg_164) } } else {
//line :90:1
			return nil
		}
	} }
func A_arbace_classes_types_class__GT_desc_A_New() *A_arbace_classes_types_class__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class__GT_desc_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Ctor() {}
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.NN(jrt.Class_Cast(c__0)).IsPrimitive__Z() { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()); var tmp2 any; var root_181 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); if linked_182 == nil { tmp2 = ifn_183.Invoke_O__O(arg_184) } else { tmp2 = linked_182.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_181, arg_184) }; return tmp1.Invoke_O__O(tmp2) } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {
		var root_169 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_173 any = Lit_4; var arg_174 any = Lit_5; if linked_170 == nil { return ifn_171.Invoke_O_O_O__O(arg_172, arg_173, arg_174) } else { return linked_170.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_169, arg_172, arg_173, arg_174) } } else {
//line :94:1
			if A_arbace_classes_types_A_const_32 != nil {

				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7); var tmp4 any; var root_175 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_179 any = Lit_4; var arg_180 any = Lit_5; if linked_176 == nil { tmp4 = ifn_177.Invoke_O_O_O__O(arg_178, arg_179, arg_180) } else { tmp4 = linked_176.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_175, arg_178, arg_179, arg_180) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil)).Ref() } else {
//line :94:1
					return nil
				}
		}
	}
}











func A_arbace_classes_types_array_sym_QMARK__A_New() *A_arbace_classes_types_array_sym_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_sym_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any; var root_185 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_187 lang.IFn; if
											linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = s__0; if linked_186 == nil { and__1927000168__auto____2 = ifn_187.Invoke_O__O(arg_188) } else { and__1927000168__auto____2 = linked_186.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_185, arg_188) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_189 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__0; if linked_190 == nil { and__1927000168__auto____3 = ifn_191.Invoke_O__O(arg_192) } else { and__1927000168__auto____3 = linked_190.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_193 any = A_arbace_classes_types_A_const_38.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = A_arbace_classes_types_A_const_39; var arg_197 any; var root_198 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = s__0; if linked_199 == nil { arg_197 = ifn_200.Invoke_O__O(arg_201) } else { arg_197 = linked_199.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_198, arg_201) }; if linked_194 == nil { return ifn_195.Invoke_O_O__O(arg_196, arg_197) } else { return linked_194.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_193, arg_196, arg_197) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_classes_types_with_anns_A_New() *A_arbace_classes_types_with_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Ctor() {}
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Invoke_O_O_O__O(self, tn__0, form__1 any) any { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__1); var anns__4 any; if

	jrt.J2g_Truth(m__3) { var root_202 any = A_arbace_classes_types_A_const_40.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_206 any; var root_207 any = A_arbace_classes_types_A_const_41.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any; var tmp1 any = A_arbace_classes_types_with_anns_fn__48000056_A_New(); var tmp2 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_classes_types_with_anns_fn__48000056_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_classes_types_with_anns_fn__48000056_A_fn_class = fncls__216d; tmp2 = fncls__216d } else { tmp2 = fncls__216 }; arg_210 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_211 any = m__3; if linked_208 == nil { arg_206 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { arg_206 = linked_208.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }; if linked_203 == nil { anns__4 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { anns__4 = linked_203.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) } } else { anns__4 = nil }; var tmp3 any; var root_217 any =
	A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = anns__4; if linked_218 == nil { tmp3 = ifn_219.Invoke_O__O(arg_220) } else { tmp3 = linked_218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_217, arg_220) }; if jrt.J2g_Truth(tmp3) { var root_221 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = tn__0; var arg_225 any = A_arbace_classes_types_A_const_44; var arg_226 any = anns__4; if linked_222 == nil { return ifn_223.Invoke_O_O_O__O(arg_224, arg_225, arg_226) } else { return linked_222.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_221, arg_224, arg_225, arg_226) } } else { return tn__0 } }
//line :117:1
func A_arbace_classes_types_with_anns_fn__48000056_A_New() *A_arbace_classes_types_with_anns_fn__48000056_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_fn__48000056_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Ctor() {}
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Invoke_O_O__O(self, p__48000055__1 any) any { var vec__48000057__2 any = p__48000055__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_212 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_214 lang.IFn; _ = ___4; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = k__3; if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_212, arg_215) } }


func A_arbace_classes_types_parse_type_A_New() *A_arbace_classes_types_parse_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Ctor() {}
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Invoke_O_O_O__O(self, scope__0, form__1 any) any {



	var root_227 any = A_arbace_classes_types_A_const_45.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_classes_types_with_anns_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any; var tmp1 any; var and__1927000168__auto____3 any; var root_232 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_234 lang.IFn

	if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = form__1; if linked_233 == nil { and__1927000168__auto____3 = ifn_234.Invoke_O__O(arg_235) } else { and__1927000168__auto____3 = linked_233.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_232, arg_235) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_236 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = form__1; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_236, arg_239) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :125:1
	if jrt.J2g_Truth(tmp1) { var tmp3 any = A_arbace_classes_types_A_const_46; var tmp4 any = A_arbace_classes_types_A_const_47; var tmp5 any = A_arbace_classes_types_A_const_48; arg_230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1))) } else { var tmp6 any; var root_240 any = A_arbace_classes_types_A_const_49.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, A_arbace_classes_types_array_sym_QMARK__A_fn_class); var ifn_242 lang.IFn



		if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = form__1; if linked_241 == nil { tmp6 = ifn_242.Invoke_O__O(arg_243) } else { tmp6 = linked_241.(*A_arbace_classes_types_array_sym_QMARK__A).Invoke_O_O__O(root_240, arg_243) }
//line :125:1
		if jrt.J2g_Truth(tmp6) { var base__3 any; var root_244 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_246 lang.IFn




			if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any; var root_248 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = form__1; if linked_249 == nil { arg_247 = ifn_250.Invoke_O__O(arg_251) } else { arg_247 = linked_249.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_248, arg_251) }; if linked_245 == nil { base__3 = ifn_246.Invoke_O__O(arg_247) } else { base__3 = linked_245.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_244, arg_247) }
//line :125:1
			var n__4 any; var root_252 any = A_arbace_classes_types_A_const_50.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_parse_long_A_fn_class); var ifn_254 lang.IFn





			if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any; var root_256 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = form__1; if linked_257 == nil { arg_255 = ifn_258.Invoke_O__O(arg_259) } else { arg_255 = linked_257.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_256, arg_259) }; if linked_253 == nil { n__4 = ifn_254.Invoke_O__O(arg_255) } else { n__4 = linked_253.(*aot_arbace_core.A_arbace_core_parse_long_A).Invoke_O_O__O(root_252, arg_255) }
			var tmp7 any; var root_260 any = A_arbace_classes_types_A_const_51.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var tmp8 any = A_arbace_classes_types_parse_type_fn__48000065_A_New(); var tmp9 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000065_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_classes_types_parse_type_fn__48000065_A_fn_class = fncls__265d; tmp9 = fncls__265d } else { tmp9 = fncls__265 }; arg_263 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_264 any; var root_266 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_classes_types_parse_type_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = scope__0; var arg_270 any = base__3; if linked_267 == nil { arg_264 = ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { arg_264 = linked_267.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_266, arg_269, arg_270) }; if linked_261 == nil { tmp7 = ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { tmp7 = linked_261.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_260, arg_263, arg_264) }; arg_230 = lang.RT_Nth_O_I__O_NoInit(tmp7, lang.RT_IntCast_O__I_NoInit(n__4)) } else {
//line :125:1
				var tmp10 any; var and__1927000168__auto____3_2 any; var root_271 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_273 lang.IFn








				if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = form__1; if linked_272 == nil { and__1927000168__auto____3_2 = ifn_273.Invoke_O__O(arg_274) } else { and__1927000168__auto____3_2 = linked_272.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_271, arg_274) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp10 = lang.IFn_Cast(A_arbace_classes_types_A_const_55.GetRawRoot__O()).Invoke_O__O(form__1) } else { tmp10 = and__1927000168__auto____3_2 }
//line :125:1
				if jrt.J2g_Truth(tmp10) { var d__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_55.GetRawRoot__O()).Invoke_O__O(form__1)










					if lang.Util_Equiv_O_O__Z_NoInit(d__3, Lit_17) { var tmp11 any = A_arbace_classes_types_A_const_46; var tmp12 any = A_arbace_classes_types_A_const_52; var tmp13 any = A_arbace_classes_types_A_const_53; arg_230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, Lit_18, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())))) } else { var tmp14 any = A_arbace_classes_types_A_const_46; var tmp15 any = A_arbace_classes_types_A_const_52; var tmp16 any = A_arbace_classes_types_A_const_53; var tmp17 any = A_arbace_classes_types_A_const_46; var tmp18 any = A_arbace_classes_types_A_const_47; var tmp19 any = A_arbace_classes_types_A_const_48; var tmp20 any; var root_275 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_277 lang.IFn

						if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = d__3; var arg_279 any = A_arbace_classes_types_A_const_17; if linked_276 == nil { tmp20 = ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { tmp20 = linked_276.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) }
//line :136:1
						arg_230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp20)))) } } else {
//line :125:1
							if lang.Util_Equiv_O_O__Z_NoInit(form__1, A_arbace_classes_types_A_const_59) { arg_230 = A_arbace_classes_types_A_const_60 } else { var tmp21 any; var and__1927000168__auto____3_3 any; var root_280 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_282 lang.IFn
















								if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = form__1; if linked_281 == nil { and__1927000168__auto____3_3 = ifn_282.Invoke_O__O(arg_283) } else { and__1927000168__auto____3_3 = linked_281.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_280, arg_283) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_284 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = A_arbace_classes_types_A_const_61.Invoke_O__O(scope__0); var arg_288 any = form__1; if linked_285 == nil { tmp21 = ifn_286.Invoke_O_O__O(arg_287, arg_288) } else { tmp21 = linked_285.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_284, arg_287, arg_288) } } else { tmp21 = and__1927000168__auto____3_3 }
//line :125:1
								if jrt.J2g_Truth(tmp21) { arg_230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_62, A_arbace_classes_types_A_const_63, form__1)) } else { var tmp22 any; var root_289 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_291 lang.IFn



















									if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = form__1; if linked_290 == nil { tmp22 = ifn_291.Invoke_O__O(arg_292) } else { tmp22 = linked_290.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_289, arg_292) }
//line :125:1
									if jrt.J2g_Truth(tmp22) { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_64.Invoke_O__O(scope__0)).Invoke_O__O(form__1)




















										if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4_2 any = temp__1927000408__auto____3; var o__5 any; var temp__1927000414__auto____5 any = A_arbace_classes_types_A_const_65.Invoke_O__O(scope__0)
											if jrt.J2g_Truth(temp__1927000414__auto____5) { var f__6 any = temp__1927000414__auto____5; o__5 = lang.IFn_Cast(f__6).Invoke_O__O(n__4_2) } else { o__5 = nil }
//line :146:1
											var G__48000067__6_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, n__4_2, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref()))

											if jrt.J2g_Truth(o__5) { var root_293 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = G__48000067__6_; var arg_297 any = A_arbace_classes_types_A_const_66; var arg_298 any = o__5; if linked_294 == nil { arg_230 = ifn_295.Invoke_O_O_O__O(arg_296, arg_297, arg_298) } else { arg_230 = linked_294.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_293, arg_296, arg_297, arg_298) } } else { arg_230 = G__48000067__6_ } } else {
//line :146:1
												var tmp23 any; var root_299 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_301 lang.IFn


												if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var arg_303 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_68, form__1)); if linked_300 == nil { tmp23 = ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { tmp23 = linked_300.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_299, arg_302, arg_303) }
//line :146:1
												panic(jrt.Thrown(jrt.Throwable_Cast(tmp23))) } } else {
//line :125:1
													var tmp24 any; var root_304 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_306 lang.IFn

























													if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = form__1; if linked_305 == nil { tmp24 = ifn_306.Invoke_O__O(arg_307) } else { tmp24 = linked_305.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_304, arg_307) }
//line :125:1
													if jrt.J2g_Truth(tmp24) { var d__3_2 any; var root_308 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_310 lang.IFn


























														if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = form__1; var arg_312 any = Lit_4; var arg_313 any = Lit_5; if linked_309 == nil { d__3_2 = ifn_310.Invoke_O_O_O__O(arg_311, arg_312, arg_313) } else { d__3_2 = linked_309.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_308, arg_311, arg_312, arg_313) }
														var tmp25 any; var root_314 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = d__3_2; var arg_318 any = Lit_1; if linked_315 == nil { tmp25 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { tmp25 = linked_315.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_314, arg_317, arg_318) }; if jrt.J2g_Truth(tmp25) { var body_p__4 *A_arbace_classes_types_parse_type_p__48000068_A = A_arbace_classes_types_parse_type_p__48000068_A_New(); var p__4 any; var tmp26 *jrt.Class; var fncls__338 *jrt.Class = A_arbace_classes_types_parse_type_p__48000068_A_fn_class; if fncls__338 == nil { var fncls__338d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_types_parse_type_p__48000068_A_fn_class = fncls__338d; tmp26 = fncls__338d } else { tmp26 = fncls__338 }; p__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_p__4), tmp26, nil)



															arg_230 = lang.IFn_Cast(p__4).Invoke_O__O(d__3_2) } else {
																var root_339 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, A_arbace_classes_types_parse_type_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = scope__0; var arg_343 any; var root_344 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = form__1; if linked_345 == nil { arg_343 = ifn_346.Invoke_O__O(arg_347) } else { arg_343 = linked_345.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_344, arg_347) }; if linked_340 == nil { arg_230 = ifn_341.Invoke_O_O__O(arg_342, arg_343) } else { arg_230 = linked_340.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_339, arg_342, arg_343) } } } else {
//line :125:1
																	var tmp27 any; var root_348 any = A_arbace_classes_types_A_const_69.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_350 lang.IFn


































																	if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = form__1; if linked_349 == nil { tmp27 = ifn_350.Invoke_O__O(arg_351) } else { tmp27 = linked_349.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_348, arg_351) }
//line :125:1
																	if jrt.J2g_Truth(tmp27) { var d__3_3 any; var root_352 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_354 lang.IFn


































																		if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = form__1; if linked_353 == nil { d__3_3 = ifn_354.Invoke_O__O(arg_355) } else { d__3_3 = linked_353.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_352, arg_355) }
																		var root_356 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, A_arbace_classes_types_parse_type_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = scope__0; var arg_360 any; var tmp28 any; var root_361 any = A_arbace_classes_types_A_const_71.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = d__3_3; if linked_362 == nil { tmp28 = ifn_363.Invoke_O__O(arg_364) } else { tmp28 = linked_362.(*A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_361, arg_364) }; if jrt.J2g_Truth(tmp28) { var root_365 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = lang.IFn_Cast(A_arbace_classes_types_A_const_72.GetRawRoot__O()).Invoke_O__O(d__3_3); if linked_366 == nil { arg_360 = ifn_367.Invoke_O__O(arg_368) } else { arg_360 = linked_366.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_365, arg_368) } } else {
																			var tmp29 any; var root_369 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = d__3_3; if linked_370 == nil { tmp29 = ifn_371.Invoke_O__O(arg_372) } else { tmp29 = linked_370.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_369, arg_372) }; if jrt.J2g_Truth(tmp29) { var root_373 any = A_arbace_classes_types_A_const_73.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, A_arbace_classes_types_desc__GT_class_name_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = d__3_3; if linked_374 == nil { arg_360 = ifn_375.Invoke_O__O(arg_376) } else { arg_360 = linked_374.(*A_arbace_classes_types_desc__GT_class_name_A).Invoke_O_O__O(root_373, arg_376) } } else { var root_377 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = jrt.NN(jrt.Class_Cast(form__1)).GetName__String().Ref(); if linked_378 == nil { arg_360 = ifn_379.Invoke_O__O(arg_380) } else { arg_360 = linked_378.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_377, arg_380) } } }
//line :161:1
																		if linked_357 == nil { arg_230 = ifn_358.Invoke_O_O__O(arg_359, arg_360) } else { arg_230 = linked_357.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_356, arg_359, arg_360) } } else {
//line :125:1
																			var tmp30 any; var and__1927000168__auto____3_4 any; var root_381 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_383 lang.IFn






































																			if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = form__1; if linked_382 == nil { and__1927000168__auto____3_4 = ifn_383.Invoke_O__O(arg_384) } else { and__1927000168__auto____3_4 = linked_382.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_381, arg_384) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var tmp31 any = A_arbace_classes_types_A_const_75; var tmp32 any; var root_385 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = form__1; if linked_386 == nil { tmp32 = ifn_387.Invoke_O__O(arg_388) } else { tmp32 = linked_386.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_385, arg_388) }; tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp31, tmp32)).Ref() } else { tmp30 = and__1927000168__auto____3_4 }
//line :125:1
																			if jrt.J2g_Truth(tmp30) { var tmp33 any = A_arbace_classes_types_A_const_46; var tmp34 any = A_arbace_classes_types_A_const_52; var tmp35 any = A_arbace_classes_types_A_const_53; var tmp36 any; var root_389 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, A_arbace_classes_types_parse_type_A_fn_class); var ifn_391 lang.IFn







































																				if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = scope__0; var arg_393 any; var root_394 any = A_arbace_classes_types_A_const_77.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = form__1; if linked_395 == nil { arg_393 = ifn_396.Invoke_O__O(arg_397) } else { arg_393 = linked_395.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_394, arg_397) }; if linked_390 == nil { tmp36 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { tmp36 = linked_390.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }
//line :125:1
																				arg_230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, tmp35, tmp36)) } else { var tmp37 any; var and__1927000168__auto____3_5 any; var root_398 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_400 lang.IFn









































																					if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = form__1; if linked_399 == nil { and__1927000168__auto____3_5 = ifn_400.Invoke_O__O(arg_401) } else { and__1927000168__auto____3_5 = linked_399.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_398, arg_401) }; if jrt.J2g_Truth(and__1927000168__auto____3_5) { var tmp38 any = A_arbace_classes_types_A_const_78; var tmp39 any; var root_402 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = form__1; if linked_403 == nil { tmp39 = ifn_404.Invoke_O__O(arg_405) } else { tmp39 = linked_403.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_402, arg_405) }; tmp37 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp38, tmp39)).Ref() } else { tmp37 = and__1927000168__auto____3_5 }
//line :125:1
																					if jrt.J2g_Truth(tmp37) { var vec__48000070__3 any = form__1; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(1), nil); var b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp40 any = A_arbace_classes_types_A_const_46; var tmp41 any = A_arbace_classes_types_A_const_79; var tmp42 any = A_arbace_classes_types_A_const_80; var tmp43 any; var root_406 any = A_arbace_classes_types_A_const_81.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_408 lang.IFn; _ = ___4











































																						if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; var root_410 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = k__5; if linked_411 == nil { arg_409 = ifn_412.Invoke_O__O(arg_413) } else { arg_409 = linked_411.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_410, arg_413) }; if linked_407 == nil { tmp43 = ifn_408.Invoke_O__O(arg_409) } else { tmp43 = linked_407.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_406, arg_409) }
//line :125:1
																						var tmp44 any = tmp43; var tmp45 any = A_arbace_classes_types_A_const_82; var tmp46 any; var root_414 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, A_arbace_classes_types_parse_type_A_fn_class); var ifn_416 lang.IFn











































																						if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = scope__0; var arg_418 any = b__6; if linked_415 == nil { tmp46 = ifn_416.Invoke_O_O__O(arg_417, arg_418) } else { tmp46 = linked_415.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_414, arg_417, arg_418) }
//line :125:1
																						arg_230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp41, tmp42, tmp44, tmp45, tmp46)) } else { var tmp47 any; var and__1927000168__auto____3_6 any; var root_419 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_421 lang.IFn













































																							if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = form__1; if linked_420 == nil { and__1927000168__auto____3_6 = ifn_421.Invoke_O__O(arg_422) } else { and__1927000168__auto____3_6 = linked_420.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_419, arg_422) }; if jrt.J2g_Truth(and__1927000168__auto____3_6) { var tmp48 any = A_arbace_classes_types_A_const_83; var tmp49 any; var root_423 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = form__1; if linked_424 == nil { tmp49 = ifn_425.Invoke_O__O(arg_426) } else { tmp49 = linked_424.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_423, arg_426) }; tmp47 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp48, tmp49)).Ref() } else { tmp47 = and__1927000168__auto____3_6 }
//line :125:1
																							if jrt.J2g_Truth(tmp47) { var tmp50 any = A_arbace_classes_types_A_const_46; var tmp51 any = A_arbace_classes_types_A_const_84; var tmp52 any = A_arbace_classes_types_A_const_85; var tmp53 any; var root_427 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_429 lang.IFn














































																								if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var tmp54 any = A_arbace_classes_types_parse_type_fn__48000073_A_New_O(scope__0); var tmp55 *jrt.Class; var fncls__437 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000073_A_fn_class; if fncls__437 == nil { var fncls__437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_types_parse_type_fn__48000073_A_fn_class = fncls__437d; tmp55 = fncls__437d } else { tmp55 = fncls__437 }; arg_430 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp54, tmp55, nil); var arg_431 any; var root_438 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = form__1; if linked_439 == nil { arg_431 = ifn_440.Invoke_O__O(arg_441) } else { arg_431 = linked_439.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_438, arg_441) }; if linked_428 == nil { tmp53 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { tmp53 = linked_428.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }
//line :125:1
																								arg_230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp51, tmp52, tmp53)) } else { var tmp56 any; var and__1927000168__auto____3_7 any; var root_442 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_444 lang.IFn
















































																									if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = form__1; if linked_443 == nil { and__1927000168__auto____3_7 = ifn_444.Invoke_O__O(arg_445) } else { and__1927000168__auto____3_7 = linked_443.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_442, arg_445) }; if jrt.J2g_Truth(and__1927000168__auto____3_7) { var tmp57 any = A_arbace_classes_types_A_const_88; var tmp58 any; var root_446 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = form__1; if linked_447 == nil { tmp58 = ifn_448.Invoke_O__O(arg_449) } else { tmp58 = linked_447.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_446, arg_449) }; tmp56 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp57, tmp58)).Ref() } else { tmp56 = and__1927000168__auto____3_7 }
//line :125:1
																									if jrt.J2g_Truth(tmp56) {

















































																										var root_450 any = A_arbace_classes_types_A_const_89.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var tmp59 any = A_arbace_classes_types_parse_type_fn__48000075_A_New_O(scope__0); var tmp60 *jrt.Class; var fncls__487 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_A_fn_class; if fncls__487 == nil { var fncls__487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_types_parse_type_fn__48000075_A_fn_class = fncls__487d; tmp60 = fncls__487d } else { tmp60 = fncls__487 }; arg_453 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil); var arg_454 any; var root_488 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, A_arbace_classes_types_parse_type_A_fn_class); var ifn_490 lang.IFn



																										if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = scope__0; var arg_492 any; var root_493 any = A_arbace_classes_types_A_const_77.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = form__1; if linked_494 == nil { arg_492 = ifn_495.Invoke_O__O(arg_496) } else { arg_492 = linked_494.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_493, arg_496) }; if linked_489 == nil { arg_454 = ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { arg_454 = linked_489.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) }
//line :175:1
																										var arg_455 any; var root_497 any = A_arbace_classes_types_A_const_91.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_499 lang.IFn




																										if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = form__1; if linked_498 == nil { arg_455 = ifn_499.Invoke_O__O(arg_500) } else { arg_455 = linked_498.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_497, arg_500) }
//line :175:1
																										if linked_451 == nil { arg_230 = ifn_452.Invoke_O_O_O__O(arg_453, arg_454, arg_455) } else { arg_230 = linked_451.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_450, arg_453, arg_454, arg_455) } } else {
//line :125:1
																											var tmp61 any; var root_501 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_503 lang.IFn
























































																											if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = form__1; if linked_502 == nil { tmp61 = ifn_503.Invoke_O__O(arg_504) } else { tmp61 = linked_502.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_501, arg_504) }
//line :125:1
																											if jrt.J2g_Truth(tmp61) { var c__3 any; var root_505 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, A_arbace_classes_types_parse_type_A_fn_class); var ifn_507 lang.IFn

























































																												if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = scope__0; var arg_509 any; var root_510 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = form__1; if linked_511 == nil { arg_509 = ifn_512.Invoke_O__O(arg_513) } else { arg_509 = linked_511.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_510, arg_513) }; if linked_506 == nil { c__3 = ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { c__3 = linked_506.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) }
																												var tmp62 any = A_arbace_classes_types_A_const_56; if lang.Util_Equiv_O_O__Z_NoInit(tmp62, A_arbace_classes_types_A_const_46.Invoke_O__O(c__3)) { } else { var tmp63 any; var root_544 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var arg_548 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_545 == nil { tmp63 = ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { tmp63 = linked_545.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_544, arg_547, arg_548) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp63))) }
																												var root_514 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = c__3; var arg_518 any = A_arbace_classes_types_A_const_58; var arg_519 any; var root_520 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var tmp64 any = A_arbace_classes_types_parse_type_fn__48000082_A_New_O(scope__0); var tmp65 *jrt.Class; var fncls__530 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000082_A_fn_class; if fncls__530 == nil { var fncls__530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_types_parse_type_fn__48000082_A_fn_class = fncls__530d; tmp65 = fncls__530d } else { tmp65 = fncls__530 }; arg_523 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil); var arg_524 any; var root_531 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = form__1; if linked_532 == nil { arg_524 = ifn_533.Invoke_O__O(arg_534) } else { arg_524 = linked_532.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_531, arg_534) }; if linked_521 == nil { arg_519 = ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { arg_519 = linked_521.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) }; if linked_515 == nil { arg_230 = ifn_516.Invoke_O_O_O__O(arg_517, arg_518, arg_519) } else { arg_230 = linked_515.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_514, arg_517, arg_518, arg_519) } } else {
//line :125:1
																													if A_arbace_classes_types_A_const_32 != nil { var tmp66 any; var root_535 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_537 lang.IFn





























































																														if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_92.GetRawRoot__O()).Invoke_O__O(form__1))).Ref(); var arg_539 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_68, form__1)); if linked_536 == nil { tmp66 = ifn_537.Invoke_O_O__O(arg_538, arg_539) } else { tmp66 = linked_536.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_535, arg_538, arg_539) }
//line :125:1
																														panic(jrt.Thrown(jrt.Throwable_Cast(tmp66))) } else { arg_230 = nil } } } } } } } } } } } } } }
//line :124:1
	var arg_231 any = form__1; if linked_228 == nil { return ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { return linked_228.(*A_arbace_classes_types_with_anns_A).Invoke_O_O_O__O(root_227, arg_230, arg_231)
	}
}





func A_arbace_classes_types_parse_type_fn__48000065_A_New() *A_arbace_classes_types_parse_type_fn__48000065_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000065_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Ctor() {}
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Invoke_O_O__O(self, e__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_52, A_arbace_classes_types_A_const_53, e__1)) }





















func A_arbace_classes_types_parse_type_p__48000068_A_New() *A_arbace_classes_types_parse_type_p__48000068_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_p__48000068_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Ctor() {}
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Invoke_O_O__O(self, d__1 any) any { var tmp1 any; var root_319 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = d__1; var arg_323 any = Lit_1; if linked_320 == nil { tmp1 = ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { tmp1 = linked_320.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_types_A_const_46; var tmp3 any = A_arbace_classes_types_A_const_52; var tmp4 any = A_arbace_classes_types_A_const_53; var tmp5 lang.IFn = lang.IFn_Cast(self); var tmp6 any; var root_333 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = d__1; var arg_337 any = A_arbace_classes_types_A_const_17; if linked_334 == nil { tmp6 = ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { tmp6 = linked_334.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5.Invoke_O__O(tmp6))) } else { var tmp7 any; var root_324 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_326 lang.IFn
												if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = d__1; var arg_328 any = Lit_6; if linked_325 == nil { tmp7 = ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { tmp7 = linked_325.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_324, arg_327, arg_328) }
//line :154:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any = A_arbace_classes_types_A_const_46; var tmp9 any = A_arbace_classes_types_A_const_56; var tmp10 any = A_arbace_classes_types_A_const_57; var tmp11 any; var root_329 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_331 lang.IFn
		if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = d__1; if linked_330 == nil { tmp11 = ifn_331.Invoke_O__O(arg_332) } else { tmp11 = linked_330.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_329, arg_332) }
//line :154:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, tmp11, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__1)) } else { return nil } } } }

















func A_arbace_classes_types_parse_type_fn__48000073_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Invoke_O_O__O(self, p1__48000062_SHARP___1 any) any { var root_432 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_classes_types_parse_type_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = t.F_scope; var arg_436 any = p1__48000062_SHARP___1; if linked_433 == nil { return ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { return linked_433.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) } }


func A_arbace_classes_types_parse_type_fn__48000075_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_A{}; t.Ctor_O(p0); return t }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Invoke_O_O_O__O(self, outer__1, f__2 any) any { var vec__48000076__3 any; var tmp1 any; var root_456 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_458 lang.IFn; if
														linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = f__2; if linked_457 == nil { tmp1 = ifn_458.Invoke_O__O(arg_459) } else { tmp1 = linked_457.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_456, arg_459) }; if jrt.J2g_Truth(tmp1) { vec__48000076__3 = f__2 } else { vec__48000076__3 = lang.Tuple_Create_O__IPersistentVector(f__2) }; var seq__48000077__4 any; var root_460 any = /*line :175:1*/A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_462 lang.IFn; if
														linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = vec__48000076__3; if linked_461 == nil { seq__48000077__4 = ifn_462.Invoke_O__O(arg_463) } else { seq__48000077__4 = linked_461.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_460, arg_463) }; var first__48000078__5 any; var root_464 any = /*line :175:1*/A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_466 lang.IFn; if
														linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = seq__48000077__4; if linked_465 == nil { first__48000078__5 = ifn_466.Invoke_O__O(arg_467) } else { first__48000078__5 = linked_465.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_464, arg_467) }; var seq__48000077__6 any; var root_468 any = /*line :175:1*/A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_470 lang.IFn; if
														linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = seq__48000077__4; if linked_469 == nil { seq__48000077__6 = ifn_470.Invoke_O__O(arg_471) } else { seq__48000077__6 = linked_469.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_468, arg_471) }; var c__7 any = first__48000078__5; var args__8 any = seq__48000077__6; var n__9 any; var tmp2 /*line :175:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil); var tmp3 any = A_arbace_classes_types_A_const_57.Invoke_O__O(outer__1); var tmp4 any; var root_472 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_474 lang.IFn; if

	linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = c__7; if linked_473 == nil { tmp4 = ifn_474.Invoke_O__O(arg_475) } else { tmp4 = linked_473.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_472, arg_475) }; n__9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref(); var tmp5 any = A_arbace_classes_types_A_const_46; var tmp6 any = A_arbace_classes_types_A_const_56; var tmp7 any = A_arbace_classes_types_A_const_57; var tmp8 any = A_arbace_classes_types_A_const_58; var tmp9 any; var root_476 any = /*line :175:1*/A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_478 lang.IFn; if


	linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var tmp10 any = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(t.F_scope); var tmp11 *jrt.Class; var fncls__486 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class; if fncls__486 == nil { var fncls__486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class = fncls__486d; tmp11 = fncls__486d } else { tmp11 = fncls__486 }; arg_479 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_480 any = args__8; if linked_477 == nil { tmp9 = ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { tmp9 = linked_477.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) }; return /*line :175:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, n__9, tmp8, tmp9, A_arbace_classes_types_A_const_66, outer__1)) }


func A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Invoke_O_O__O(self, p1__48000063_SHARP___1 any) any { var root_481 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_classes_types_parse_type_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = t.F_scope; var arg_485 any = p1__48000063_SHARP___1; if linked_482 == nil { return ifn_483.Invoke_O_O__O(arg_484, arg_485) } else { return linked_482.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_481, arg_484, arg_485) } }






func A_arbace_classes_types_parse_type_fn__48000082_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000082_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000082_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Invoke_O_O__O(self, p1__48000064_SHARP___1 any) any { var root_525 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, A_arbace_classes_types_parse_type_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = t.F_scope; var arg_529 any = p1__48000064_SHARP___1; if linked_526 == nil { return ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { return linked_526.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) } }




func A_arbace_classes_types_erase_A_New() *A_arbace_classes_types_erase_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_erase_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_classes_types_erase_A) Ctor() {}
//line :190:1
func (t *A_arbace_classes_types_erase_A) Invoke_O_O_O__O(self, bounds__0, tn__1 any) any { var G__48000085__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000085__3_) >> 9 & 7 { case 0: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_79) {





		var tmp1 any = A_arbace_classes_types_A_const_93; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_80.Invoke_O__O(tn__1)) { var root_550 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, A_arbace_classes_types_erase_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = bounds__0; var arg_554 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1); if linked_551 == nil { return ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { return linked_551.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) } } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	case 1: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__1) }
//line :193:1
	case 2: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_56) {

		var root_555 any = A_arbace_classes_types_A_const_25.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__1); if linked_556 == nil { return ifn_557.Invoke_O__O(arg_558) } else { return linked_556.(*A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_555, arg_558) } }
//line :193:1
	case 3: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_84) {




		var root_559 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, A_arbace_classes_types_erase_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = bounds__0; var arg_563 any; var root_564 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = A_arbace_classes_types_A_const_85.Invoke_O__O(tn__1); if linked_565 == nil { arg_563 = ifn_566.Invoke_O__O(arg_567) } else { arg_563 = linked_565.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_564, arg_567) }; if linked_560 == nil { return ifn_561.Invoke_O_O__O(arg_562, arg_563) } else { return linked_560.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_559, arg_562, arg_563) } }
//line :193:1
	case 4: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_52) {


		var root_568 any = A_arbace_classes_types_A_const_96.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_classes_types_array_of_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any; var root_572 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, A_arbace_classes_types_erase_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = bounds__0; var arg_576 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1); if linked_573 == nil { arg_571 = ifn_574.Invoke_O_O__O(arg_575, arg_576) } else { arg_571 = linked_573.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_572, arg_575, arg_576) }; if linked_569 == nil { return ifn_570.Invoke_O__O(arg_571) } else { return linked_569.(*A_arbace_classes_types_array_of_A).Invoke_O_O__O(root_568, arg_571) } }
//line :193:1
	case 7: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_62) { var temp__1927000408__auto____4 any; var root_577 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_579 lang.IFn



		if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = lang.RT_Get_O_O__O_NoInit(bounds__0, A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1)); if linked_578 == nil { temp__1927000408__auto____4 = ifn_579.Invoke_O__O(arg_580) } else { temp__1927000408__auto____4 = linked_578.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_577, arg_580) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var root_581 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_classes_types_erase_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any; var root_586 any = A_arbace_classes_types_A_const_97.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = bounds__0; var arg_590 any = A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1); if linked_587 == nil { arg_584 = ifn_588.Invoke_O_O__O(arg_589, arg_590) } else { arg_584 = linked_587.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_586, arg_589, arg_590) }; var arg_585 any = b__5; if linked_582 == nil { return ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { return linked_582.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) } } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000085__3_))))) }







func A_arbace_classes_types_generic_QMARK__A_New() *A_arbace_classes_types_generic_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_generic_QMARK__A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Ctor() {}
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Invoke_O_O__O(self, tn__0 any) any { var G__48000087__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000087__2_) >> 9 & 7 { case 0: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_79) { return jrt.Boolean_TRUE.Ref() }; case 1: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_47) { return jrt.Boolean_FALSE.Ref() }; case 2: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_56) { var or__1927000174__auto____3 bool; var tmp1 any; var root_592 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_594 lang.IFn

		if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_593 == nil { tmp1 = ifn_594.Invoke_O__O(arg_595) } else { tmp1 = linked_593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_592, arg_595) }; or__1927000174__auto____3 = lang.RT_BooleanCast_O__Z_NoInit(tmp1); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp2 any; var and__1927000168__auto____4 any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_596 any = A_arbace_classes_types_A_const_98.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, A_arbace_classes_types_generic_QMARK__A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if linked_597 == nil { tmp2 = ifn_598.Invoke_O__O(arg_599) } else { tmp2 = linked_597.(*A_arbace_classes_types_generic_QMARK__A).Invoke_O_O__O(root_596, arg_599) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } }
//line :204:1
	case 3: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_84) { return jrt.Boolean_TRUE.Ref() }; case 4: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_52) {


		var root_600 any = A_arbace_classes_types_A_const_98.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, A_arbace_classes_types_generic_QMARK__A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0); if linked_601 == nil { return ifn_602.Invoke_O__O(arg_603) } else { return linked_601.(*A_arbace_classes_types_generic_QMARK__A).Invoke_O_O__O(root_600, arg_603) } }
//line :204:1
	case 7: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_62) { return jrt.Boolean_TRUE.Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000087__2_))))) }







func A_arbace_classes_types_local_class_name_QMARK__A_New() *A_arbace_classes_types_local_class_name_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_local_class_name_QMARK__A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Ctor() {}
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Invoke_O_O_O__O(self, n__0, outer__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = outer__1; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_604 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = n__0; var arg_608 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, outer__1, nil)).Ref(); if linked_605 == nil { and__1927000168__auto____4 = ifn_606.Invoke_O_O__O(arg_607, arg_608) } else { and__1927000168__auto____4 = linked_605.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_604, arg_607, arg_608) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_609 any = A_arbace_classes_types_A_const_38.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = A_arbace_classes_types_A_const_99; var arg_613 any; var root_614 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = n__0; var arg_618 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(outer__1)))).Ref(); if linked_615 == nil { arg_613 = ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { arg_613 = linked_615.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; if linked_610 == nil { tmp1 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { tmp1 = linked_610.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) } } else {
//line :216:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_types_signature_A_New() *A_arbace_classes_types_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_signature_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_classes_types_signature_A) Ctor() {}
//line :219:1
func (t *A_arbace_classes_types_signature_A) Invoke_O_O__O(self, tn__0 any) any { var G__48000090__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000090__2_) >> 9 & 7 { case 0: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_79) { var G__48000091__3_ any = A_arbace_classes_types_A_const_80.Invoke_O__O(tn__0)









		switch lang.Util_Hash_O__I_NoInit(G__48000091__3_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, nil) { return Lit_40 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_100) {
			var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil); var tmp2 any; var root_621 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, A_arbace_classes_types_signature_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0); if linked_622 == nil { tmp2 = ifn_623.Invoke_O__O(arg_624) } else { tmp2 = linked_622.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_621, arg_624) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :232:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_93) { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil); var tmp4 any; var root_625 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, A_arbace_classes_types_signature_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0); if linked_626 == nil { tmp4 = ifn_627.Invoke_O__O(arg_628) } else { tmp4 = linked_626.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_625, arg_628) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000091__3_))))) }
//line :222:1
	case 1: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__0) }
//line :222:1
	case 2: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_56) { var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var root_629 any = A_arbace_classes_types_A_const_102.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_631 lang.IFn

		if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any; var root_633 any = A_arbace_classes_types_A_const_103.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, A_arbace_classes_types_local_class_name_QMARK__A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var arg_637 any; var G__48000092__3_ any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if lang.Util_Identical_O_O__Z_NoInit(G__48000092__3_, nil) { arg_637 = nil } else { arg_637 = A_arbace_classes_types_A_const_57.Invoke_O__O(G__48000092__3_) }; if linked_634 == nil { arg_632 = ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { arg_632 = linked_634.(*A_arbace_classes_types_local_class_name_QMARK__A).Invoke_O_O_O__O(root_633, arg_636, arg_637) }; if linked_630 == nil { and__1927000168__auto____3 = ifn_631.Invoke_O__O(arg_632) } else { and__1927000168__auto____3 = linked_630.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_629, arg_632) }; if jrt.J2g_Truth(and__1927000168__auto____3) { temp__1927000408__auto____3 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var o__4 any = temp__1927000408__auto____3; var os__5 any; var root_638 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, A_arbace_classes_types_signature_A_fn_class); var ifn_640 lang.IFn
			if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = o__4; if linked_639 == nil { os__5 = ifn_640.Invoke_O__O(arg_641) } else { os__5 = linked_639.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_638, arg_641) }
			var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_4, nil, nil, Lit_7); var tmp6 any; var root_642 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = os__5; var arg_646 any = A_arbace_classes_types_A_const_21; var arg_647 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(os__5)))).Ref(); if linked_643 == nil { tmp6 = ifn_644.Invoke_O_O_O__O(arg_645, arg_646, arg_647) } else { tmp6 = linked_643.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_642, arg_645, arg_646, arg_647) }; var tmp7 any = tmp6; var tmp8 any; var root_648 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var arg_652 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_classes_types_A_const_57.Invoke_O__O(o__4))))).Ref(); if linked_649 == nil { tmp8 = ifn_650.Invoke_O_O__O(arg_651, arg_652) } else { tmp8 = linked_649.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_648, arg_651, arg_652) }; var tmp9 any = tmp8; var tmp10 *jrt.String; var tmp11 any; var root_653 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_655 lang.IFn
			if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_654 == nil { tmp11 = ifn_655.Invoke_O__O(arg_656) } else { tmp11 = linked_654.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_653, arg_656) }; if jrt.J2g_Truth(tmp11) { var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp13 any; var root_657 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_661 any; var root_662 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var arg_666 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_663 == nil { arg_661 = ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { arg_661 = linked_663.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }; if linked_658 == nil { tmp13 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { tmp13 = linked_658.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil)) } else { tmp10 = nil }
//line :226:1
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, tmp9, tmp10.Ref(), nil)).Ref() } else {

				var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, nil, Lit_7); var tmp15 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var tmp16 *jrt.String; var tmp17 any; var root_667 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn
				if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_668 == nil { tmp17 = ifn_669.Invoke_O__O(arg_670) } else { tmp17 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(tmp17) { var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp19 any; var root_671 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_675 any; var root_676 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var arg_680 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_677 == nil { arg_675 = ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { arg_675 = linked_677.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_676, arg_679, arg_680) }; if linked_672 == nil { tmp19 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { tmp19 = linked_672.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil)) } else { tmp16 = nil }
//line :228:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, tmp16.Ref(), nil)).Ref() } }
//line :222:1
	case 3: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_84) {











		var root_681 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, A_arbace_classes_types_signature_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any; var root_685 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = A_arbace_classes_types_A_const_85.Invoke_O__O(tn__0); if linked_686 == nil { arg_684 = ifn_687.Invoke_O__O(arg_688) } else { arg_684 = linked_686.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_685, arg_688) }; if linked_682 == nil { return ifn_683.Invoke_O__O(arg_684) } else { return linked_682.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_681, arg_684) } }
//line :222:1
	case 4: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_52) {







		var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp21 any; var root_689 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, A_arbace_classes_types_signature_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0); if linked_690 == nil { tmp21 = ifn_691.Invoke_O__O(arg_692) } else { tmp21 = linked_690.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_689, arg_692) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21)).Ref() }
//line :222:1
	case 7: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_62) {








		var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_7); var tmp23 any; var root_693 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = A_arbace_classes_types_A_const_63.Invoke_O__O(tn__0); if linked_694 == nil { tmp23 = ifn_695.Invoke_O__O(arg_696) } else { tmp23 = linked_694.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_693, arg_696) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, nil)).Ref() }
//line :222:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000090__2_))))) }













func A_arbace_classes_types_parse_type_params_A_New() *A_arbace_classes_types_parse_type_params_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Ctor() {}
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Invoke_O_O_O__O(self, scope__0, tps__1 any) any {




	var root_697 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any; var tmp1 any = A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(scope__0); var tmp2 *jrt.Class; var fncls__742 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class; if fncls__742 == nil { var fncls__742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class = fncls__742d; tmp2 = fncls__742d } else { tmp2 = fncls__742 }; arg_700 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_701 any = tps__1; if linked_698 == nil { return ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { return linked_698.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) } }
//line :241:1
func A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Invoke_O_O__O(self, tp__1 any) any {
	var tmp1 any; var root_702 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = tp__1; if linked_703 == nil { tmp1 = ifn_704.Invoke_O__O(arg_705) } else { tmp1 = linked_703.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_702, arg_705) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_types_A_const_63; var tmp3 any = A_arbace_classes_types_A_const_105; var tmp4 any = lang.PersistentVector_EMPTY.Ref(); var tmp5 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tp__1, tmp3, tmp4, tmp5, lang.RT_Meta_O__IPersistentMap_NoInit(tp__1))) } else { var vec__48000096__2 any = tp__1; var seq__48000097__3 any; var root_706 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_708 lang.IFn

		if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = vec__48000096__2; if linked_707 == nil { seq__48000097__3 = ifn_708.Invoke_O__O(arg_709) } else { seq__48000097__3 = linked_707.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_706, arg_709) }
//line :242:1
		var first__48000098__4 any; var root_710 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_712 lang.IFn

		if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = seq__48000097__3; if linked_711 == nil { first__48000098__4 = ifn_712.Invoke_O__O(arg_713) } else { first__48000098__4 = linked_711.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_710, arg_713) }
//line :242:1
		var seq__48000097__5 any; var root_714 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_716 lang.IFn

		if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = seq__48000097__3; if linked_715 == nil { seq__48000097__5 = ifn_716.Invoke_O__O(arg_717) } else { seq__48000097__5 = linked_715.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_714, arg_717) }
//line :242:1
		var s__6 any = first__48000098__4; var first__48000098__7 any; var root_718 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_720 lang.IFn

		if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = seq__48000097__5; if linked_719 == nil { first__48000098__7 = ifn_720.Invoke_O__O(arg_721) } else { first__48000098__7 = linked_719.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_718, arg_721) }
//line :242:1
		var seq__48000097__8 any; var root_722 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_724 lang.IFn

		if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = seq__48000097__5; if linked_723 == nil { seq__48000097__8 = ifn_724.Invoke_O__O(arg_725) } else { seq__48000097__8 = linked_723.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_722, arg_725) }
//line :242:1
		var kw__9 any = first__48000098__7
		var bs__10 any = seq__48000097__8

		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_106, kw__9) { } else { var tmp6 any; var root_737 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, tp__1)).Ref(); var arg_741 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_738 == nil { tmp6 = ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { tmp6 = linked_738.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_737, arg_740, arg_741) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }
//line :242:1
		var tmp7 any = A_arbace_classes_types_A_const_63; var tmp8 any = A_arbace_classes_types_A_const_105; var tmp9 any; var root_726 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_728 lang.IFn



		if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any; var tmp10 any = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(t.F_scope); var tmp11 *jrt.Class; var fncls__736 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class; if fncls__736 == nil { var fncls__736d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class = fncls__736d; tmp11 = fncls__736d } else { tmp11 = fncls__736 }; arg_729 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_730 any = bs__10; if linked_727 == nil { tmp9 = ifn_728.Invoke_O_O__O(arg_729, arg_730) } else { tmp9 = linked_727.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_726, arg_729, arg_730) }
//line :242:1
		var tmp12 any = tmp9; var tmp13 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, s__6, tmp8, tmp12, tmp13, lang.RT_Meta_O__IPersistentMap_NoInit(s__6)))
	}
}

func A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Invoke_O_O__O(self, p1__48000094_SHARP___1 any) any { var root_731 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, A_arbace_classes_types_parse_type_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = t.F_scope; var arg_735 any = p1__48000094_SHARP___1; if linked_732 == nil { return ifn_733.Invoke_O_O__O(arg_734, arg_735) } else { return linked_732.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_731, arg_734, arg_735) } }


func A_arbace_classes_types_type_params_signature_A_New() *A_arbace_classes_types_type_params_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Ctor() {}
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Invoke_O_O_O__O(self, interface_QMARK___0, tps__1 any) any {



	var tmp1 any; var root_743 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = tps__1; if linked_744 == nil { tmp1 = ifn_745.Invoke_O__O(arg_746) } else { tmp1 = linked_744.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_743, arg_746) }; if jrt.J2g_Truth(tmp1) { return Lit_9 } else {

		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp3 any; var root_747 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_749 lang.IFn
		if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_751 any; var iter__1927001039__auto____6 any; var tmp4 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(interface_QMARK___0); var tmp5 *jrt.Class; var fncls__918 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class
		if fncls__918 == nil { var fncls__918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class = fncls__918d; tmp5 = fncls__918d } else { tmp5 = fncls__918 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_751 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(tps__1)
//line :256:1
		if linked_748 == nil { tmp3 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { tmp3 = linked_748.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }
//line :255:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
	} }
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Invoke_O_O__O(self, s__48000104__1 any) any { var tmp1 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(self, t.F_interface_QMARK_, s__48000104__1); var tmp2 *jrt.Class; var fncls__917 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class; if fncls__917 == nil { var fncls__917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class = fncls__917d; tmp2 = fncls__917d } else { tmp2 = fncls__917 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Ctor_O_O_O(c__iter__48000103, c__interface_QMARK_, c__s__48000104 any) { t.F_iter__48000103 = c__iter__48000103; t.F_interface_QMARK_ = c__interface_QMARK_; t.F_s__48000104 = c__s__48000104 }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Invoke_O__O(self any) any { { var s__48000104__1 any; var t_ any = t.F_s__48000104; t.F_s__48000104 = nil; s__48000104__1 = t_; for { var temp__1927000414__auto____2 any; var root_752 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = s__48000104__1; if linked_753 == nil { temp__1927000414__auto____2 = ifn_754.Invoke_O__O(arg_755) } else { temp__1927000414__auto____2 = linked_753.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_752, arg_755) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__48000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_756 any = A_arbace_classes_types_A_const_108.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = s__48000104__3; if linked_757 == nil { tmp1 = ifn_758.Invoke_O__O(arg_759) } else { tmp1 = linked_757.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_756, arg_759) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_760 any = A_arbace_classes_types_A_const_109.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = s__48000104__3; if linked_761 == nil { c__1927001037__auto____4 = ifn_762.Invoke_O__O(arg_763) } else { c__1927001037__auto____4 = linked_761.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_760, arg_763) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__48000106__6 any; var root_764 any = A_arbace_classes_types_A_const_110.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_765 == nil { b__48000106__6 = ifn_766.Invoke_O__O(arg_767) } else { b__48000106__6 = linked_765.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_764, arg_767) }; var tmp2 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(t.F_interface_QMARK_, b__48000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__827 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class; if fncls__827 == nil { var fncls__827d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class = fncls__827d; tmp3 = fncls__827d } else { tmp3 = fncls__827 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_828 any = A_arbace_classes_types_A_const_114.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any; var root_833 any = A_arbace_classes_types_A_const_115.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = b__48000106__6; if linked_834 == nil { arg_831 = ifn_835.Invoke_O__O(arg_836) } else { arg_831 = linked_834.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_833, arg_836) }; var arg_832 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); var tmp5 any; var root_837 any = A_arbace_classes_types_A_const_116.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = s__48000104__3; if linked_838 == nil { tmp5 = ifn_839.Invoke_O__O(arg_840) } else { tmp5 = linked_838.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_837, arg_840) }; arg_832 = tmp4.Invoke_O__O(tmp5); if linked_829 == nil { return ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { return linked_829.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) } } else { var root_841 any = A_arbace_classes_types_A_const_114.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any; var root_846 any = A_arbace_classes_types_A_const_115.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = b__48000106__6; if linked_847 == nil { arg_844 = ifn_848.Invoke_O__O(arg_849) } else { arg_844 = linked_847.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_846, arg_849) }; var arg_845 any; if linked_842 == nil { return ifn_843.Invoke_O_O__O(arg_844, arg_845) } else { return linked_842.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_841, arg_844, arg_845) } } } else { var map__48000115__4 any; var root_850 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = s__48000104__3; if linked_851 == nil { map__48000115__4 = ifn_852.Invoke_O__O(arg_853) } else { map__48000115__4 = linked_851.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_850, arg_853) }; var map__48000115__5 any; if lang.ISeq_InstanceOf(map__48000115__4) { var tmp6 any; var root_854 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = map__48000115__4; if linked_855 == nil { tmp6 = ifn_856.Invoke_O__O(arg_857) } else { tmp6 = linked_855.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_854, arg_857) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_858 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = map__48000115__4; if linked_859 == nil { tmp7 = ifn_860.Invoke_O__O(arg_861) } else { tmp7 = linked_859.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_858, arg_861) }; map__48000115__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp7, jrt.Object_class.ArrayClass())).Ref() } else { var tmp8 any; var root_862 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = map__48000115__4; if linked_863 == nil { tmp8 = ifn_864.Invoke_O__O(arg_865) } else { tmp8 = linked_863.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_862, arg_865) }; if jrt.J2g_Truth(tmp8) { var root_866 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = map__48000115__4; if linked_867 == nil { map__48000115__5 = ifn_868.Invoke_O__O(arg_869) } else { map__48000115__5 = linked_867.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_866, arg_869) } } else { map__48000115__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000115__5 = map__48000115__4 }; var sym__6 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_63); var bounds__7 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_105); var root_870 any = A_arbace_classes_types_A_const_117.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp10 any; var root_875 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_877 lang.IFn
																if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = sym__6; if linked_876 == nil { tmp10 = ifn_877.Invoke_O__O(arg_878) } else { tmp10 = linked_876.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_875, arg_878) }; var tmp11 any = tmp10; var tmp12 any; var tmp13 any; var root_879 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_881 lang.IFn
																if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = bounds__7; if linked_880 == nil { tmp13 = ifn_881.Invoke_O__O(arg_882) } else { tmp13 = linked_880.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_879, arg_882) }; if jrt.J2g_Truth(tmp13) { tmp12 = Lit_58 } else {

		var root_883 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_887 any; var root_888 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_890 lang.IFn
		if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var tmp14 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(t.F_interface_QMARK_); var tmp15 *jrt.Class; var fncls__912 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class
		if fncls__912 == nil { var fncls__912d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class = fncls__912d; tmp15 = fncls__912d } else { tmp15 = fncls__912 }; arg_891 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)
//line :262:1
		var arg_892 any = bounds__7; if linked_889 == nil { arg_887 = ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { arg_887 = linked_889.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) }
//line :261:1
		if linked_884 == nil { tmp12 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { tmp12 = linked_884.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) } }
//line :258:1
	arg_873 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12)).Ref()
//line :257:1
	var arg_874 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); var tmp17 any; var root_913 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = s__48000104__3; if linked_914 == nil { tmp17 = ifn_915.Invoke_O__O(arg_916) } else { tmp17 = linked_914.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_913, arg_916) }; arg_874 = tmp16.Invoke_O__O(tmp17); if linked_871 == nil { return ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { return linked_871.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Ctor_O_O_I_O(c__interface_QMARK_, c__b__48000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_interface_QMARK_ = c__interface_QMARK_; t.F_b__48000106 = c__b__48000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Invoke_O__O(self any) any { { var i__48000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__48000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__48000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__48000105__1)); var map__48000110__3 any; if lang.ISeq_InstanceOf(map__48000110__2) { var tmp2 any; var root_768 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = map__48000110__2; if linked_769 == nil { tmp2 = ifn_770.Invoke_O__O(arg_771) } else { tmp2 = linked_769.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_768, arg_771) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_772 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = map__48000110__2; if linked_773 == nil { tmp3 = ifn_774.Invoke_O__O(arg_775) } else { tmp3 = linked_773.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_772, arg_775) }; map__48000110__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_776 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = map__48000110__2; if linked_777 == nil { tmp4 = ifn_778.Invoke_O__O(arg_779) } else { tmp4 = linked_777.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_776, arg_779) }; if jrt.J2g_Truth(tmp4) { var root_780 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = map__48000110__2; if linked_781 == nil { map__48000110__3 = ifn_782.Invoke_O__O(arg_783) } else { map__48000110__3 = linked_781.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_780, arg_783) } } else { map__48000110__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000110__3 = map__48000110__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_63); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_105); var root_784 any = A_arbace_classes_types_A_const_112.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = t.F_b__48000106; var arg_788 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 any; var root_789 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_791 lang.IFn
																	if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = sym__4; if linked_790 == nil { tmp6 = ifn_791.Invoke_O__O(arg_792) } else { tmp6 = linked_790.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_789, arg_792) }; var tmp7 any = tmp6; var tmp8 any; var tmp9 any; var root_793 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_795 lang.IFn
																	if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = bounds__5; if linked_794 == nil { tmp9 = ifn_795.Invoke_O__O(arg_796) } else { tmp9 = linked_794.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_793, arg_796) }; if jrt.J2g_Truth(tmp9) { tmp8 = Lit_58 } else {

		var root_797 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_801 any; var root_802 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_804 lang.IFn
		if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any; var tmp10 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(t.F_interface_QMARK_); var tmp11 *jrt.Class; var fncls__826 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class
		if fncls__826 == nil { var fncls__826d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class = fncls__826d; tmp11 = fncls__826d } else { tmp11 = fncls__826 }; arg_805 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :262:1
		var arg_806 any = bounds__5; if linked_803 == nil { arg_801 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { arg_801 = linked_803.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }
//line :261:1
		if linked_798 == nil { tmp8 = ifn_799.Invoke_O_O__O(arg_800, arg_801) } else { tmp8 = linked_798.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_797, arg_800, arg_801) } }
//line :258:1
	arg_788 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref()
//line :257:1
	if linked_785 == nil { ifn_786.Invoke_O_O__O(arg_787, arg_788) } else { linked_785.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_784, arg_787, arg_788) }; i__48000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__48000105__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Invoke_O_O_O__O(self, i__1, b__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, b__2) } else {
																					var tmp1 any; var and__1927000168__auto____3 bool; var na_807 any = i__1; if jrt.Long_InstanceOf(na_807) { var n0_808 int64 = jrt.NN(jrt.Long_Cast(na_807)).LongValue__J(); and__1927000168__auto____3 = n0_808 == 0 } else { if jrt.Double_InstanceOf(na_807) { var n0_808_2 float64 = jrt.NN(jrt.Double_Cast(na_807)).DoubleValue__D(); and__1927000168__auto____3 = n0_808_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_807) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
																						var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_809 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, A_arbace_classes_types_signature_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = b__2; if linked_810 == nil { tmp5 = ifn_811.Invoke_O__O(arg_812) } else { tmp5 = linked_810.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_809, arg_812) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
																							var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_813 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, A_arbace_classes_types_signature_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = b__2; if linked_814 == nil { tmp7 = ifn_815.Invoke_O__O(arg_816) } else { tmp7 = linked_814.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_813, arg_816) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } } }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var n0_817 int64 = i__1_l; and__1927000168__auto____3 = n0_817 == 0; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_818 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, A_arbace_classes_types_signature_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = b__2; if linked_819 == nil { tmp5 = ifn_820.Invoke_O__O(arg_821) } else { tmp5 = linked_819.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_818, arg_821) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_822 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, A_arbace_classes_types_signature_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = b__2; if linked_823 == nil { tmp7 = ifn_824.Invoke_O__O(arg_825) } else { tmp7 = linked_823.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_822, arg_825) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } }
//line :263:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Invoke_O_O_O__O(self, i__1, b__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, b__2) } else {
																			var tmp1 any; var and__1927000168__auto____3 bool; var na_893 any = i__1; if jrt.Long_InstanceOf(na_893) { var n0_894 int64 = jrt.NN(jrt.Long_Cast(na_893)).LongValue__J(); and__1927000168__auto____3 = n0_894 == 0 } else { if jrt.Double_InstanceOf(na_893) { var n0_894_2 float64 = jrt.NN(jrt.Double_Cast(na_893)).DoubleValue__D(); and__1927000168__auto____3 = n0_894_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_893) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
																				var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_895 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, A_arbace_classes_types_signature_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = b__2; if linked_896 == nil { tmp5 = ifn_897.Invoke_O__O(arg_898) } else { tmp5 = linked_896.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_895, arg_898) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
																					var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_899 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_classes_types_signature_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = b__2; if linked_900 == nil { tmp7 = ifn_901.Invoke_O__O(arg_902) } else { tmp7 = linked_900.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_899, arg_902) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } } }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var n0_903 int64 = i__1_l; and__1927000168__auto____3 = n0_903 == 0; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_904 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_classes_types_signature_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = b__2; if linked_905 == nil { tmp5 = ifn_906.Invoke_O__O(arg_907) } else { tmp5 = linked_905.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_904, arg_907) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_908 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, A_arbace_classes_types_signature_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = b__2; if linked_909 == nil { tmp7 = ifn_910.Invoke_O__O(arg_911) } else { tmp7 = linked_909.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_908, arg_911) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref()
		}
}

func A_arbace_classes_types_bounds_map_A_New() *A_arbace_classes_types_bounds_map_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Invoke_O_O__O(self, tps__0 any) any { var root_919 any = A_arbace_classes_types_A_const_40.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_923 any; var root_924 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any; var tmp1 any = A_arbace_classes_types_bounds_map_fn__48000123_A_New(); var tmp2 *jrt.Class; var fncls__945 *jrt.Class = A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class; if fncls__945 == nil { var fncls__945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class = fncls__945d; tmp2 = fncls__945d } else { tmp2 = fncls__945 }; arg_927 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_928 any = tps__0; if linked_925 == nil { arg_923 = ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { arg_923 = linked_925.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_924, arg_927, arg_928) }; if linked_920 == nil { return ifn_921.Invoke_O_O__O(arg_922, arg_923) } else { return linked_920.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_919, arg_922, arg_923) } }
//line :270:1
func A_arbace_classes_types_bounds_map_fn__48000123_A_New() *A_arbace_classes_types_bounds_map_fn__48000123_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_fn__48000123_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Invoke_O_O__O(self, p__48000122__1 any) any { var map__48000124__2 any = p__48000122__1; var map__48000124__3 any; if lang.ISeq_InstanceOf(map__48000124__2) { var tmp1 any; var root_929 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = map__48000124__2; if linked_930 == nil { tmp1 = ifn_931.Invoke_O__O(arg_932) } else { tmp1 = linked_930.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_929, arg_932) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_933 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = map__48000124__2; if linked_934 == nil { tmp2 = ifn_935.Invoke_O__O(arg_936) } else { tmp2 = linked_934.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_933, arg_936) }; map__48000124__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_937 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = map__48000124__2; if linked_938 == nil { tmp3 = ifn_939.Invoke_O__O(arg_940) } else { tmp3 = linked_938.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_937, arg_940) }; if jrt.J2g_Truth(tmp3) { var root_941 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = map__48000124__2; if linked_942 == nil { map__48000124__3 = ifn_943.Invoke_O__O(arg_944) } else { map__48000124__3 = linked_942.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_941, arg_944) } } else { map__48000124__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000124__3 = map__48000124__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_63); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_105); return lang.Tuple_Create_O_O__IPersistentVector(sym__4, bounds__5) }

func A_arbace_classes_types_desc__GT_tnode_A_New() *A_arbace_classes_types_desc__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_tnode_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Invoke_O_O__O(self, d__0 any) any {
	var tmp1 any; var root_946 any = A_arbace_classes_types_A_const_71.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = d__0; if linked_947 == nil { tmp1 = ifn_948.Invoke_O__O(arg_949) } else { tmp1 = linked_947.(*A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_946, arg_949) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { var tmp2 any; var root_950 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_952 lang.IFn

		if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = d__0; if linked_951 == nil { tmp2 = ifn_952.Invoke_O__O(arg_953) } else { tmp2 = linked_951.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_950, arg_953) }
//line :273:1
		if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_classes_types_A_const_46; var tmp4 any = A_arbace_classes_types_A_const_52; var tmp5 any = A_arbace_classes_types_A_const_53; var tmp6 any; var root_954 any = A_arbace_classes_types_A_const_118.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_classes_types_desc__GT_tnode_A_fn_class); var ifn_956 lang.IFn

			if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any; var root_958 any = A_arbace_classes_types_A_const_119.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, A_arbace_classes_types_elem_type_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = d__0; if linked_959 == nil { arg_957 = ifn_960.Invoke_O__O(arg_961) } else { arg_957 = linked_959.(*A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_958, arg_961) }; if linked_955 == nil { tmp6 = ifn_956.Invoke_O__O(arg_957) } else { tmp6 = linked_955.(*A_arbace_classes_types_desc__GT_tnode_A).Invoke_O_O__O(root_954, arg_957) }
//line :273:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6)) } else { if A_arbace_classes_types_A_const_32 != nil { var tmp7 any = A_arbace_classes_types_A_const_46; var tmp8 any = A_arbace_classes_types_A_const_56; var tmp9 any = A_arbace_classes_types_A_const_57; var tmp10 any; var root_962 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_964 lang.IFn


				if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = d__0; if linked_963 == nil { tmp10 = ifn_964.Invoke_O__O(arg_965) } else { tmp10 = linked_963.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_962, arg_965) }
//line :273:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { return nil
				}
			}
	}
	} }
func A_arbace_classes_types_reflect__GT_tnode_A_New() *A_arbace_classes_types_reflect__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_reflect__GT_tnode_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Ctor() {}
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Invoke_O_O__O(self, ty__0 any) any {


	if jrt.Class_InstanceOf(ty__0) {
		var root_966 any = A_arbace_classes_types_A_const_118.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, A_arbace_classes_types_desc__GT_tnode_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var root_970 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = ty__0; if linked_971 == nil { arg_969 = ifn_972.Invoke_O__O(arg_973) } else { arg_969 = linked_971.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_970, arg_973) }; if linked_967 == nil { return ifn_968.Invoke_O__O(arg_969) } else { return linked_967.(*A_arbace_classes_types_desc__GT_tnode_A).Invoke_O_O__O(root_966, arg_969) } } else {
//line :281:1
			if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)).IsInstance_O__Z(ty__0) { var pt__2 any = ty__0; var tmp1 any = A_arbace_classes_types_A_const_46; var tmp2 any = A_arbace_classes_types_A_const_56; var tmp3 any = A_arbace_classes_types_A_const_57; var tmp4 any; var root_974 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_976 lang.IFn



				if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any; var root_978 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_31, jrt.RefArrayOf(jrt.Object_class)); if linked_979 == nil { arg_977 = ifn_980.Invoke_O__O(arg_981) } else { arg_977 = linked_979.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_978, arg_981) }; if linked_975 == nil { tmp4 = ifn_976.Invoke_O__O(arg_977) } else { tmp4 = linked_975.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_974, arg_977) }
//line :281:1
				var tmp5 any = tmp4; var tmp6 any = A_arbace_classes_types_A_const_58; var tmp7 any; var root_982 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_984 lang.IFn




				if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var arg_986 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_32, jrt.RefArrayOf(jrt.Object_class)); if linked_983 == nil { tmp7 = ifn_984.Invoke_O_O__O(arg_985, arg_986) } else { tmp7 = linked_983.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_982, arg_985, arg_986) }
//line :281:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp7)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)).IsInstance_O__Z(ty__0) { var tmp8 any = A_arbace_classes_types_A_const_46; var tmp9 any = A_arbace_classes_types_A_const_62; var tmp10 any = A_arbace_classes_types_A_const_63; var tmp11 any; var root_987 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_989 lang.IFn






					if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33), Lit_34, jrt.RefArrayOf(jrt.Object_class)); if linked_988 == nil { tmp11 = ifn_989.Invoke_O__O(arg_990) } else { tmp11 = linked_988.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_987, arg_990) }
//line :281:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, tmp11)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35)).IsInstance_O__Z(ty__0) { var tmp12 any = A_arbace_classes_types_A_const_46; var tmp13 any = A_arbace_classes_types_A_const_52; var tmp14 any = A_arbace_classes_types_A_const_53; var tmp15 any; var root_991 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_993 lang.IFn








						if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35), Lit_36, jrt.RefArrayOf(jrt.Object_class)); if linked_992 == nil { tmp15 = ifn_993.Invoke_O__O(arg_994) } else { tmp15 = linked_992.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_991, arg_994) }
//line :281:1
						return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37)).IsInstance_O__Z(ty__0) { var w__2 any = ty__0; var lo__3 any; var root_995 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_997 lang.IFn











							if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_38, jrt.RefArrayOf(jrt.Object_class)); if linked_996 == nil { lo__3 = ifn_997.Invoke_O__O(arg_998) } else { lo__3 = linked_996.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_995, arg_998) }
//line :281:1
							var up__4 any; var root_999 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1001 lang.IFn











							if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_39, jrt.RefArrayOf(jrt.Object_class)); if linked_1000 == nil { up__4 = ifn_1001.Invoke_O__O(arg_1002) } else { up__4 = linked_1000.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_999, arg_1002) }
							if jrt.J2g_Truth(lo__3) { var tmp16 any = A_arbace_classes_types_A_const_46; var tmp17 any = A_arbace_classes_types_A_const_79; var tmp18 any = A_arbace_classes_types_A_const_80; var tmp19 any = A_arbace_classes_types_A_const_100; var tmp20 any = A_arbace_classes_types_A_const_82; var tmp21 any; var root_1003 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any; var root_1007 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = lo__3; if linked_1008 == nil { arg_1006 = ifn_1009.Invoke_O__O(arg_1010) } else { arg_1006 = linked_1008.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1007, arg_1010) }; if linked_1004 == nil { tmp21 = ifn_1005.Invoke_O__O(arg_1006) } else { tmp21 = linked_1004.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_1003, arg_1006) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21)) } else { var tmp22 any; var and__1927000168__auto____5 any = up__4
								if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1011 any = A_arbace_classes_types_A_const_12.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = A_arbace_classes_types_A_const_121; var arg_1015 any; var root_1016 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = up__4; if linked_1017 == nil { arg_1015 = ifn_1018.Invoke_O__O(arg_1019) } else { arg_1015 = linked_1017.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1016, arg_1019) }; if linked_1012 == nil { tmp22 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { tmp22 = linked_1012.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) } } else { tmp22 = and__1927000168__auto____5 }
//line :294:1
								if jrt.J2g_Truth(tmp22) { var tmp23 any = A_arbace_classes_types_A_const_46; var tmp24 any = A_arbace_classes_types_A_const_79; var tmp25 any = A_arbace_classes_types_A_const_80; var tmp26 any = A_arbace_classes_types_A_const_93; var tmp27 any = A_arbace_classes_types_A_const_82; var tmp28 any; var root_1020 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_1022 lang.IFn
									if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any; var root_1024 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = up__4; if linked_1025 == nil { arg_1023 = ifn_1026.Invoke_O__O(arg_1027) } else { arg_1023 = linked_1025.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1024, arg_1027) }; if linked_1021 == nil { tmp28 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp28 = linked_1021.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_1020, arg_1023) }
//line :294:1
									return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28)) } else { if A_arbace_classes_types_A_const_32 != nil { return A_arbace_classes_types_A_const_122 } else { return nil } } } } else {
//line :281:1
										if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, Lit_18, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { return nil
										}
									}
						}
					}
				}
		}
}










func A_arbace_classes_types_subst_A_New() *A_arbace_classes_types_subst_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_classes_types_subst_A) Ctor() {}
//line :299:1
func (t *A_arbace_classes_types_subst_A) Invoke_O_O_O__O(self, env__0, tn__1 any) any { var G__48000135__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000135__3_) >> 9 & 7 { case 0: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_79) {




		if jrt.J2g_Truth(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1)) { var root_1029 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = tn__1; var arg_1033 any = A_arbace_classes_types_A_const_82; var arg_1034 any; var tmp1 any = A_arbace_classes_types_subst_fn__48000136_A_New_O(env__0); var tmp2 *jrt.Class; var fncls__1040 *jrt.Class = A_arbace_classes_types_subst_fn__48000136_A_fn_class; if fncls__1040 == nil { var fncls__1040d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_types_subst_fn__48000136_A_fn_class = fncls__1040d; tmp2 = fncls__1040d } else { tmp2 = fncls__1040 }; arg_1034 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1030 == nil { return ifn_1031.Invoke_O_O_O__O(arg_1032, arg_1033, arg_1034) } else { return linked_1030.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1029, arg_1032, arg_1033, arg_1034) } } else { return tn__1 } }
//line :302:1
	case 2: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_56) { var G__48000138__4_ any; var root_1041 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1043 lang.IFn

		if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = tn__1; var arg_1045 any = A_arbace_classes_types_A_const_58; var arg_1046 any; var root_1047 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any; var tmp3 any = A_arbace_classes_types_subst_fn__48000139_A_New_O(env__0); var tmp4 *jrt.Class; var fncls__1057 *jrt.Class = A_arbace_classes_types_subst_fn__48000139_A_fn_class; if fncls__1057 == nil { var fncls__1057d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_types_subst_fn__48000139_A_fn_class = fncls__1057d; tmp4 = fncls__1057d } else { tmp4 = fncls__1057 }; arg_1050 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1051 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__1); if linked_1048 == nil { arg_1046 = ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { arg_1046 = linked_1048.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) }; if linked_1042 == nil { G__48000138__4_ = ifn_1043.Invoke_O_O_O__O(arg_1044, arg_1045, arg_1046) } else { G__48000138__4_ = linked_1042.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1041, arg_1044, arg_1045, arg_1046) }; if jrt.J2g_Truth(A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1)) {
			var root_1058 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = G__48000138__4_; var arg_1062 any = A_arbace_classes_types_A_const_66; var arg_1063 any; var tmp5 any = A_arbace_classes_types_subst_fn__48000141_A_New_O(env__0); var tmp6 *jrt.Class; var fncls__1069 *jrt.Class = A_arbace_classes_types_subst_fn__48000141_A_fn_class; if fncls__1069 == nil { var fncls__1069d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_types_subst_fn__48000141_A_fn_class = fncls__1069d; tmp6 = fncls__1069d } else { tmp6 = fncls__1069 }; arg_1063 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_1059 == nil { return ifn_1060.Invoke_O_O_O__O(arg_1061, arg_1062, arg_1063) } else { return linked_1059.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1058, arg_1061, arg_1062, arg_1063) } } else {
//line :304:1
				return G__48000138__4_ } }
//line :302:1
	case 3: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_84) {





		var root_1070 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = tn__1; var arg_1074 any = A_arbace_classes_types_A_const_85; var arg_1075 any; var tmp7 any = A_arbace_classes_types_subst_fn__48000143_A_New_O(env__0); var tmp8 *jrt.Class; var fncls__1086 *jrt.Class = A_arbace_classes_types_subst_fn__48000143_A_fn_class; if fncls__1086 == nil { var fncls__1086d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_types_subst_fn__48000143_A_fn_class = fncls__1086d; tmp8 = fncls__1086d } else { tmp8 = fncls__1086 }; arg_1075 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_1071 == nil { return ifn_1072.Invoke_O_O_O__O(arg_1073, arg_1074, arg_1075) } else { return linked_1071.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1070, arg_1073, arg_1074, arg_1075) } }
//line :302:1
	case 4: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_52) {



		var root_1087 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = tn__1; var arg_1091 any = A_arbace_classes_types_A_const_53; var arg_1092 any; var tmp9 any = A_arbace_classes_types_subst_fn__48000145_A_New_O(env__0); var tmp10 *jrt.Class; var fncls__1098 *jrt.Class = A_arbace_classes_types_subst_fn__48000145_A_fn_class; if fncls__1098 == nil { var fncls__1098d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_classes_types_subst_fn__48000145_A_fn_class = fncls__1098d; tmp10 = fncls__1098d } else { tmp10 = fncls__1098 }; arg_1092 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1088 == nil { return ifn_1089.Invoke_O_O_O__O(arg_1090, arg_1091, arg_1092) } else { return linked_1088.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1087, arg_1090, arg_1091, arg_1092) } }
//line :302:1
	case 7: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_62) {
		return lang.RT_Get_O_O_O__O_NoInit(env__0, A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1), tn__1) }
//line :302:1
	default:}; return tn__1 }

func A_arbace_classes_types_subst_fn__48000139_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000139_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000139_A{}; t.Ctor_O(p0); return t }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Invoke_O_O__O(self, p1__48000130_SHARP___1 any) any { var root_1052 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, A_arbace_classes_types_subst_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = t.F_env; var arg_1056 any = p1__48000130_SHARP___1; if linked_1053 == nil { return ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { return linked_1053.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) } }
func A_arbace_classes_types_subst_fn__48000141_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000141_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000141_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Invoke_O_O__O(self, p1__48000131_SHARP___1 any) any { var root_1064 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, A_arbace_classes_types_subst_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = t.F_env; var arg_1068 any = p1__48000131_SHARP___1; if linked_1065 == nil { return ifn_1066.Invoke_O_O__O(arg_1067, arg_1068) } else { return linked_1065.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1064, arg_1067, arg_1068) } }
func A_arbace_classes_types_subst_fn__48000145_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000145_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000145_A{}; t.Ctor_O(p0); return t }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Invoke_O_O__O(self, p1__48000132_SHARP___1 any) any { var root_1093 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, A_arbace_classes_types_subst_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = t.F_env; var arg_1097 any = p1__48000132_SHARP___1; if linked_1094 == nil { return ifn_1095.Invoke_O_O__O(arg_1096, arg_1097) } else { return linked_1094.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1093, arg_1096, arg_1097) } }
func A_arbace_classes_types_subst_fn__48000136_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000136_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000136_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Invoke_O_O__O(self, p1__48000133_SHARP___1 any) any { var root_1035 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, A_arbace_classes_types_subst_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = t.F_env; var arg_1039 any = p1__48000133_SHARP___1; if linked_1036 == nil { return ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { return linked_1036.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) } }
func A_arbace_classes_types_subst_fn__48000143_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000143_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000143_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Invoke_O_O__O(self, p1__48000134_SHARP___1 any) any { var root_1076 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any; var root_1081 any = A_arbace_classes_types_A_const_125.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var arg_1085 any = t.F_env; if linked_1082 == nil { arg_1079 = ifn_1083.Invoke_O_O__O(arg_1084, arg_1085) } else { arg_1079 = linked_1082.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O__O(root_1081, arg_1084, arg_1085) }; var arg_1080 any = p1__48000134_SHARP___1; if linked_1077 == nil { return ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { return linked_1077.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) } }


func A_arbace_classes_types_type_anns_A_New() *A_arbace_classes_types_type_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Ctor() {}
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Invoke_O_O__O(self, tn__0 any) any { var body_walk__2 *A_arbace_classes_types_type_anns_walk__48000148_A = A_arbace_classes_types_type_anns_walk__48000148_A_New(); var walk__2 any; var tmp1 *jrt.Class; var fncls__1121 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_A_fn_class; if fncls__1121 == nil { var fncls__1121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_types_type_anns_walk__48000148_A_fn_class = fncls__1121d; tmp1 = fncls__1121d } else { tmp1 = fncls__1121 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__2), tmp1, nil); return /*line :326:1*/ lang.IFn_Cast(walk__2).Invoke_O_O__O(tn__0, Lit_9) }
//line :315:1
func A_arbace_classes_types_type_anns_walk__48000148_A_New() *A_arbace_classes_types_type_anns_walk__48000148_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Ctor() {}
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Invoke_O_O_O__O(self, tn__1, path__2 any) any {
	var root_1099 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any; var tmp1 any; var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))
	if and__1927000168__auto____3 { tmp1 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { arg_1102 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1), path__2) } else { arg_1102 = nil }
//line :316:1
	var arg_1103 any; var path__3 any; var tmp3 any; var tmp4 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))

	if and__1927000168__auto____3_2 { tmp3 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3_2).Ref() }; if jrt.J2g_Truth(tmp3) { path__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, path__2, nil)).Ref() } else { path__3 = path__2 }
	var root_1104 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any; var temp__1927000414__auto____4 any = A_arbace_classes_types_A_const_44.Invoke_O__O(tn__1)
	if jrt.J2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; arg_1107 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(path__3, a__5)) } else { arg_1107 = nil }
//line :319:1
	var arg_1108 any; var G__48000149__4_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1)

L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__48000149__4_) >> 0 & 3 { case 0: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_56) {

	var root_1110 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var arg_1114 any; var root_1115 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any; var tmp5 any = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(path__3, self); var tmp6 *jrt.Class; var fncls__1120 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class; if fncls__1120 == nil { var fncls__1120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class = fncls__1120d; tmp6 = fncls__1120d } else { tmp6 = fncls__1120 }; arg_1118 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1119 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__1); if linked_1116 == nil { arg_1114 = ifn_1117.Invoke_O_O__O(arg_1118, arg_1119) } else { arg_1114 = linked_1116.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1115, arg_1118, arg_1119) }; if linked_1111 == nil { arg_1108 = ifn_1112.Invoke_O_O__O(arg_1113, arg_1114) } else { arg_1108 = linked_1111.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1110, arg_1113, arg_1114) }
//line :321:1
	break L1 }; case 2: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_79) {


		if jrt.J2g_Truth(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1)) { arg_1108 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref()) } else { arg_1108 = nil }
//line :321:1
		break L1 }; case 3: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_52) {
			arg_1108 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref())
//line :321:1
			break L1 }; default:}; arg_1108 = nil}
//line :319:1
	if linked_1105 == nil { arg_1103 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { arg_1103 = linked_1105.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }
//line :316:1
	if linked_1100 == nil { return ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { return linked_1100.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103)
	}
}




func A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(p0, p1 any) *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Ctor_O_O(c__path, c__walk any) { t.F_path = c__path; t.F_walk = c__walk }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Invoke_O_O_O__O(self, i__1, a__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp1.Invoke_O_O__O(a__2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, t.F_path, i__1, nil)).Ref()) }




func A_arbace_classes_types_element_path_A_New() *A_arbace_classes_types_element_path_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_element_path_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Ctor() {}
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Invoke_O_O__O(self, tn__0 any) any { { var tn__2 any = tn__0; var path__3 any = Lit_9; L1: for {




	var tmp1 any = A_arbace_classes_types_A_const_52; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__2)) { tn__2, path__3 = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref(); continue L1 } else { return path__3 } } }; /*line :328:1*/panic("j2g: unreachable") }
















































































type A_arbace_classes_types_A struct{ jrt.Object }

var A_arbace_classes_types_A_const_pool *jrt.RefArray

var A_arbace_classes_types_A_const_0 *lang.Var

var A_arbace_classes_types_A_const_1 any

var A_arbace_classes_types_A_const_2 *lang.Var

var A_arbace_classes_types_A_const_3 any

var A_arbace_classes_types_A_const_4 *lang.Var

var A_arbace_classes_types_A_const_5 *lang.Var

var A_arbace_classes_types_A_const_6 *lang.Var

var A_arbace_classes_types_A_const_7 *lang.Var

var A_arbace_classes_types_A_const_8 any

var A_arbace_classes_types_A_const_9 *lang.Var

var A_arbace_classes_types_A_const_10 *lang.Var

var A_arbace_classes_types_A_const_11 *lang.Var

var A_arbace_classes_types_A_const_12 *lang.Var

var A_arbace_classes_types_A_const_13 *lang.Var

var A_arbace_classes_types_A_const_14 *lang.Keyword

var A_arbace_classes_types_A_const_15 *lang.Var

var A_arbace_classes_types_A_const_16 *lang.Var

var A_arbace_classes_types_A_const_17 any

var A_arbace_classes_types_A_const_18 *lang.Var

var A_arbace_classes_types_A_const_19 any

var A_arbace_classes_types_A_const_20 any

var A_arbace_classes_types_A_const_21 any

var A_arbace_classes_types_A_const_22 *lang.Var

var A_arbace_classes_types_A_const_23 any

var A_arbace_classes_types_A_const_24 any

var A_arbace_classes_types_A_const_25 *lang.Var

var A_arbace_classes_types_A_const_26 *lang.Var

var A_arbace_classes_types_A_const_27 *lang.Var

var A_arbace_classes_types_A_const_28 *lang.Var

var A_arbace_classes_types_A_const_29 any

var A_arbace_classes_types_A_const_30 any

var A_arbace_classes_types_A_const_31 *lang.Var

var A_arbace_classes_types_A_const_32 *lang.Keyword

var A_arbace_classes_types_A_const_33 *lang.Var

var A_arbace_classes_types_A_const_34 *lang.Var

var A_arbace_classes_types_A_const_35 *lang.Var

var A_arbace_classes_types_A_const_36 *lang.Var

var A_arbace_classes_types_A_const_37 *lang.Var

var A_arbace_classes_types_A_const_38 *lang.Var

var A_arbace_classes_types_A_const_39 any

var A_arbace_classes_types_A_const_40 *lang.Var

var A_arbace_classes_types_A_const_41 *lang.Var

var A_arbace_classes_types_A_const_42 *lang.Var

var A_arbace_classes_types_A_const_43 *lang.Var

var A_arbace_classes_types_A_const_44 *lang.Keyword

var A_arbace_classes_types_A_const_45 *lang.Var

var A_arbace_classes_types_A_const_46 *lang.Keyword

var A_arbace_classes_types_A_const_47 *lang.Keyword

var A_arbace_classes_types_A_const_48 *lang.Keyword

var A_arbace_classes_types_A_const_49 *lang.Var

var A_arbace_classes_types_A_const_50 *lang.Var

var A_arbace_classes_types_A_const_51 *lang.Var

var A_arbace_classes_types_A_const_52 *lang.Keyword

var A_arbace_classes_types_A_const_53 *lang.Keyword

var A_arbace_classes_types_A_const_54 *lang.Var

var A_arbace_classes_types_A_const_55 *lang.Var

var A_arbace_classes_types_A_const_56 *lang.Keyword

var A_arbace_classes_types_A_const_57 *lang.Keyword

var A_arbace_classes_types_A_const_58 *lang.Keyword

var A_arbace_classes_types_A_const_59 any

var A_arbace_classes_types_A_const_60 any

var A_arbace_classes_types_A_const_61 *lang.Keyword

var A_arbace_classes_types_A_const_62 *lang.Keyword

var A_arbace_classes_types_A_const_63 *lang.Keyword

var A_arbace_classes_types_A_const_64 *lang.Keyword

var A_arbace_classes_types_A_const_65 *lang.Keyword

var A_arbace_classes_types_A_const_66 *lang.Keyword

var A_arbace_classes_types_A_const_67 *lang.Var

var A_arbace_classes_types_A_const_68 *lang.Keyword

var A_arbace_classes_types_A_const_69 *lang.Var

var A_arbace_classes_types_A_const_70 *lang.Var

var A_arbace_classes_types_A_const_71 *lang.Var

var A_arbace_classes_types_A_const_72 *lang.Var

var A_arbace_classes_types_A_const_73 *lang.Var

var A_arbace_classes_types_A_const_74 *lang.Var

var A_arbace_classes_types_A_const_75 any

var A_arbace_classes_types_A_const_76 *lang.Var

var A_arbace_classes_types_A_const_77 *lang.Var

var A_arbace_classes_types_A_const_78 any

var A_arbace_classes_types_A_const_79 *lang.Keyword

var A_arbace_classes_types_A_const_80 *lang.Keyword

var A_arbace_classes_types_A_const_81 *lang.Var

var A_arbace_classes_types_A_const_82 *lang.Keyword

var A_arbace_classes_types_A_const_83 any

var A_arbace_classes_types_A_const_84 *lang.Keyword

var A_arbace_classes_types_A_const_85 *lang.Keyword

var A_arbace_classes_types_A_const_86 *lang.Var

var A_arbace_classes_types_A_const_87 *lang.Var

var A_arbace_classes_types_A_const_88 any

var A_arbace_classes_types_A_const_89 *lang.Var

var A_arbace_classes_types_A_const_90 *lang.Var

var A_arbace_classes_types_A_const_91 *lang.Var

var A_arbace_classes_types_A_const_92 *lang.Var

var A_arbace_classes_types_A_const_93 *lang.Keyword

var A_arbace_classes_types_A_const_94 *lang.Var

var A_arbace_classes_types_A_const_95 *lang.Var

var A_arbace_classes_types_A_const_96 *lang.Var

var A_arbace_classes_types_A_const_97 *lang.Var

var A_arbace_classes_types_A_const_98 *lang.Var

var A_arbace_classes_types_A_const_99 any

var A_arbace_classes_types_A_const_100 *lang.Keyword

var A_arbace_classes_types_A_const_101 *lang.Var

var A_arbace_classes_types_A_const_102 *lang.Var

var A_arbace_classes_types_A_const_103 *lang.Var

var A_arbace_classes_types_A_const_104 *lang.Var

var A_arbace_classes_types_A_const_105 *lang.Keyword

var A_arbace_classes_types_A_const_106 any

var A_arbace_classes_types_A_const_107 *lang.Var

var A_arbace_classes_types_A_const_108 *lang.Var

var A_arbace_classes_types_A_const_109 *lang.Var

var A_arbace_classes_types_A_const_110 *lang.Var

var A_arbace_classes_types_A_const_111 *lang.Var

var A_arbace_classes_types_A_const_112 *lang.Var

var A_arbace_classes_types_A_const_113 *lang.Var

var A_arbace_classes_types_A_const_114 *lang.Var

var A_arbace_classes_types_A_const_115 *lang.Var

var A_arbace_classes_types_A_const_116 *lang.Var

var A_arbace_classes_types_A_const_117 *lang.Var

var A_arbace_classes_types_A_const_118 *lang.Var

var A_arbace_classes_types_A_const_119 *lang.Var

var A_arbace_classes_types_A_const_120 *lang.Var

var A_arbace_classes_types_A_const_121 *jrt.Class

var A_arbace_classes_types_A_const_122 any

var A_arbace_classes_types_A_const_123 *lang.Var

var A_arbace_classes_types_A_const_124 *lang.Var

var A_arbace_classes_types_A_const_125 *lang.Var

var A_arbace_classes_types_A_const_126 *lang.Var

var A_arbace_classes_types_A_init jrt.ClassInit

func A_arbace_classes_types_A_Init() { if !A_arbace_classes_types_A_init.Done() { A_arbace_classes_types_A_init.Run(A_arbace_classes_types_A_clinit) } }

func A_arbace_classes_types_A_clinit() { A_arbace_classes_types_A_clinit_p0(); A_arbace_classes_types_A_clinit_p1(); A_arbace_classes_types_A_clinit_p2(); A_arbace_classes_types_A_clinit_p3(); A_arbace_classes_types_A_clinit_p4(); A_arbace_classes_types_A_clinit_p5(); A_arbace_classes_types_A_clinit_p6(); A_arbace_classes_types_A_clinit_p7(); A_arbace_classes_types_A_clinit_p8(); A_arbace_classes_types_A_clinit_p9(); A_arbace_classes_types_A_clinit_p10() }

func A_arbace_classes_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 163); A_arbace_classes_types_A_const_0 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[36]); A_arbace_classes_types_A_const_1 = A_arbace_classes_types_A_const_pool.A[37]; A_arbace_classes_types_A_const_2 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[38]); A_arbace_classes_types_A_const_3 = A_arbace_classes_types_A_const_pool.A[39]; A_arbace_classes_types_A_const_4 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[40]); A_arbace_classes_types_A_const_5 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[41]); A_arbace_classes_types_A_const_6 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[42]); A_arbace_classes_types_A_const_7 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[43]); A_arbace_classes_types_A_const_8 = A_arbace_classes_types_A_const_pool.A[44]; A_arbace_classes_types_A_const_9 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[45]); A_arbace_classes_types_A_const_10 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[46]); A_arbace_classes_types_A_const_11 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[47]) }

func A_arbace_classes_types_A_clinit_p1() { A_arbace_classes_types_A_const_12 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[48]); A_arbace_classes_types_A_const_13 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[49]); A_arbace_classes_types_A_const_14 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[50]); A_arbace_classes_types_A_const_15 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[51]); A_arbace_classes_types_A_const_16 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[52]); A_arbace_classes_types_A_const_17 = A_arbace_classes_types_A_const_pool.A[53]; A_arbace_classes_types_A_const_18 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[54]); A_arbace_classes_types_A_const_19 = A_arbace_classes_types_A_const_pool.A[55]; A_arbace_classes_types_A_const_20 = A_arbace_classes_types_A_const_pool.A[56]; A_arbace_classes_types_A_const_21 = A_arbace_classes_types_A_const_pool.A[57]; A_arbace_classes_types_A_const_22 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[58]); A_arbace_classes_types_A_const_23 = A_arbace_classes_types_A_const_pool.A[59]; A_arbace_classes_types_A_const_24 = A_arbace_classes_types_A_const_pool.A[60] }

func A_arbace_classes_types_A_clinit_p2() { A_arbace_classes_types_A_const_25 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[61]); A_arbace_classes_types_A_const_26 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[62]); A_arbace_classes_types_A_const_27 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[63]); A_arbace_classes_types_A_const_28 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[64]); A_arbace_classes_types_A_const_29 = A_arbace_classes_types_A_const_pool.A[65]; A_arbace_classes_types_A_const_30 = A_arbace_classes_types_A_const_pool.A[66]; A_arbace_classes_types_A_const_31 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[67]); A_arbace_classes_types_A_const_32 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[68]); A_arbace_classes_types_A_const_33 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[69]); A_arbace_classes_types_A_const_34 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[70]); A_arbace_classes_types_A_const_35 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[71]); A_arbace_classes_types_A_const_36 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[72]) }

func A_arbace_classes_types_A_clinit_p3() { A_arbace_classes_types_A_const_37 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[73]); A_arbace_classes_types_A_const_38 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[74]); A_arbace_classes_types_A_const_39 = A_arbace_classes_types_A_const_pool.A[75]; A_arbace_classes_types_A_const_40 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[76]); A_arbace_classes_types_A_const_41 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[77]); A_arbace_classes_types_A_const_42 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[78]); A_arbace_classes_types_A_const_43 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[79]); A_arbace_classes_types_A_const_44 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[80]); A_arbace_classes_types_A_const_45 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[81]); A_arbace_classes_types_A_const_46 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[82]); A_arbace_classes_types_A_const_47 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[83]); A_arbace_classes_types_A_const_48 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[84]) }

func A_arbace_classes_types_A_clinit_p4() { A_arbace_classes_types_A_const_49 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[85]); A_arbace_classes_types_A_const_50 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[86]); A_arbace_classes_types_A_const_51 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[87]); A_arbace_classes_types_A_const_52 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[88]); A_arbace_classes_types_A_const_53 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[89]); A_arbace_classes_types_A_const_54 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[90]); A_arbace_classes_types_A_const_55 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[91]); A_arbace_classes_types_A_const_56 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[92]); A_arbace_classes_types_A_const_57 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[93]); A_arbace_classes_types_A_const_58 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[94]); A_arbace_classes_types_A_const_59 = A_arbace_classes_types_A_const_pool.A[95]; A_arbace_classes_types_A_const_60 = A_arbace_classes_types_A_const_pool.A[96] }

func A_arbace_classes_types_A_clinit_p5() { A_arbace_classes_types_A_const_61 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[97]); A_arbace_classes_types_A_const_62 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[98]); A_arbace_classes_types_A_const_63 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[99]); A_arbace_classes_types_A_const_64 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[100]); A_arbace_classes_types_A_const_65 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[101]); A_arbace_classes_types_A_const_66 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[102]); A_arbace_classes_types_A_const_67 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[103]); A_arbace_classes_types_A_const_68 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[104]); A_arbace_classes_types_A_const_69 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[105]); A_arbace_classes_types_A_const_70 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[106]); A_arbace_classes_types_A_const_71 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[107]); A_arbace_classes_types_A_const_72 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[108]) }

func A_arbace_classes_types_A_clinit_p6() { A_arbace_classes_types_A_const_73 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[109]); A_arbace_classes_types_A_const_74 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[110]); A_arbace_classes_types_A_const_75 = A_arbace_classes_types_A_const_pool.A[111]; A_arbace_classes_types_A_const_76 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[112]); A_arbace_classes_types_A_const_77 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[113]); A_arbace_classes_types_A_const_78 = A_arbace_classes_types_A_const_pool.A[114]; A_arbace_classes_types_A_const_79 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[115]); A_arbace_classes_types_A_const_80 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[116]); A_arbace_classes_types_A_const_81 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[117]); A_arbace_classes_types_A_const_82 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[118]); A_arbace_classes_types_A_const_83 = A_arbace_classes_types_A_const_pool.A[119]; A_arbace_classes_types_A_const_84 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[120]) }

func A_arbace_classes_types_A_clinit_p7() { A_arbace_classes_types_A_const_85 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[121]); A_arbace_classes_types_A_const_86 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[122]); A_arbace_classes_types_A_const_87 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[123]); A_arbace_classes_types_A_const_88 = A_arbace_classes_types_A_const_pool.A[124]; A_arbace_classes_types_A_const_89 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[125]); A_arbace_classes_types_A_const_90 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[126]); A_arbace_classes_types_A_const_91 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[127]); A_arbace_classes_types_A_const_92 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[128]); A_arbace_classes_types_A_const_93 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[129]); A_arbace_classes_types_A_const_94 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[130]); A_arbace_classes_types_A_const_95 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[131]); A_arbace_classes_types_A_const_96 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[132]) }

func A_arbace_classes_types_A_clinit_p8() { A_arbace_classes_types_A_const_97 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[133]); A_arbace_classes_types_A_const_98 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[134]); A_arbace_classes_types_A_const_99 = A_arbace_classes_types_A_const_pool.A[135]; A_arbace_classes_types_A_const_100 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[136]); A_arbace_classes_types_A_const_101 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[137]); A_arbace_classes_types_A_const_102 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[138]); A_arbace_classes_types_A_const_103 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[139]); A_arbace_classes_types_A_const_104 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[140]); A_arbace_classes_types_A_const_105 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[141]); A_arbace_classes_types_A_const_106 = A_arbace_classes_types_A_const_pool.A[142]; A_arbace_classes_types_A_const_107 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[143]); A_arbace_classes_types_A_const_108 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[144]) }

func A_arbace_classes_types_A_clinit_p9() { A_arbace_classes_types_A_const_109 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[145]); A_arbace_classes_types_A_const_110 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[146]); A_arbace_classes_types_A_const_111 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[147]); A_arbace_classes_types_A_const_112 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[148]); A_arbace_classes_types_A_const_113 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[149]); A_arbace_classes_types_A_const_114 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[150]); A_arbace_classes_types_A_const_115 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[151]); A_arbace_classes_types_A_const_116 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[152]); A_arbace_classes_types_A_const_117 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[153]); A_arbace_classes_types_A_const_118 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[154]); A_arbace_classes_types_A_const_119 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[155]); A_arbace_classes_types_A_const_120 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[156]) }

func A_arbace_classes_types_A_clinit_p10() { A_arbace_classes_types_A_const_121 = jrt.Class_Cast(A_arbace_classes_types_A_const_pool.A[157]); A_arbace_classes_types_A_const_122 = A_arbace_classes_types_A_const_pool.A[158]; A_arbace_classes_types_A_const_123 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[159]); A_arbace_classes_types_A_const_124 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[160]); A_arbace_classes_types_A_const_125 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[161]); A_arbace_classes_types_A_const_126 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[162]) }

func A_arbace_classes_types_A_New() *A_arbace_classes_types_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_A) Ctor() {}

func (t *A_arbace_classes_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_A_class }

func (t *A_arbace_classes_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_A); return ok }

func A_arbace_classes_types_A_Cast(x any) *A_arbace_classes_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_A_class)) }; return v }



type A_arbace_classes_types_array_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_fn__48000030_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_fn__48000030_A_fn_class *jrt.Class



type A_arbace_classes_types_array_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_of_A_fn_class *jrt.Class



type A_arbace_classes_types_array_sym_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_sym_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_fn__48000123_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class *jrt.Class



type A_arbace_classes_types_class__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_class__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_class_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_class_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_class_name_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_class_name_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_internal_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_elem_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_elem_type_A_fn_class *jrt.Class



type A_arbace_classes_types_element_path_A struct{ j2g_header uint64 }

var A_arbace_classes_types_element_path_A_fn_class *jrt.Class



type A_arbace_classes_types_erase_A struct{ j2g_header uint64 }

var A_arbace_classes_types_erase_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000004_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000004_A_New() *A_arbace_classes_types_eval48000004_A { t := &A_arbace_classes_types_eval48000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000004_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000004_A_class }

func (t *A_arbace_classes_types_eval48000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000004_A); return ok }

func A_arbace_classes_types_eval48000004_A_Cast(x any) *A_arbace_classes_types_eval48000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000004_A_class)) }; return v }



type A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000008_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000008_A_New() *A_arbace_classes_types_eval48000008_A { t := &A_arbace_classes_types_eval48000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000008_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000008_A_class }

func (t *A_arbace_classes_types_eval48000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000008_A); return ok }

func A_arbace_classes_types_eval48000008_A_Cast(x any) *A_arbace_classes_types_eval48000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000008_A_class)) }; return v }



type A_arbace_classes_types_eval48000008_fn__48000009_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000013_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000013_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000037_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000037_A_fn_class *jrt.Class



type A_arbace_classes_types_generic_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_generic_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_int_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_int_like_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_internal__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_internal__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_class_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_class_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_local_class_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_local_class_name_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_package_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_package_of_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_A struct{ j2g_header uint64; F_d any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A struct{ j2g_header uint64; F_d, F_i any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000065_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_fn__48000065_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000073_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000073_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000082_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000082_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_p__48000068_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_p__48000068_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_params_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class *jrt.Class



type A_arbace_classes_types_prim_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_prim_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_ref_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_ref_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_reflect__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_reflect__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_simple_name_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_simple_name_of_A_fn_class *jrt.Class



type A_arbace_classes_types_size_A struct{ j2g_header uint64 }

var A_arbace_classes_types_size_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_A struct{ j2g_header uint64 }

var A_arbace_classes_types_subst_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000136_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000136_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000139_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000139_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000141_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000141_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000143_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000143_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000145_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000145_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_walk__48000148_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A struct{ j2g_header uint64; F_path, F_walk any }

var A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_params_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A struct{ j2g_header uint64; F_iter__48000103, F_interface_QMARK_, F_s__48000104 any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A struct{ j2g_header uint64; F_interface_QMARK_, F_b__48000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class *jrt.Class



type A_arbace_classes_types_void_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_void_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_fn__48000056_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_fn__48000056_A_fn_class *jrt.Class
