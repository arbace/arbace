//line aot_arbace_classes_types.ae:1
package aot_arbace_classes_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New() *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_types_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_types_eval48000008_fn__48000009_A_New() *A_arbace_classes_types_eval48000008_fn__48000009_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000008_fn__48000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_classes_types_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_classes_types_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_types_A_const_7.GetRawRoot__O(), A_arbace_classes_types_A_const_8) }















func A_arbace_classes_types_fn__48000013_A_New() *A_arbace_classes_types_fn__48000013_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000013_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Ctor() {}
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Invoke_O_O__O(self, p__48000012__0 any) any { var vec__48000014__2 any = p__48000012__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_19 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = k__3; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_19, arg_22) }; return lang.Tuple_Create_O_O__IPersistentVector(v__4, tmp1) }













func A_arbace_classes_types_lang_class_A_New() *A_arbace_classes_types_lang_class_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_class_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Ctor() {}
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0)).Ref() }
func A_arbace_classes_types_lang_desc_A_New() *A_arbace_classes_types_lang_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_desc_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Ctor() {}
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_5, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0, nil)).Ref() }

func A_arbace_classes_types_prim_QMARK__A_New() *A_arbace_classes_types_prim_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_prim_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_23 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = t__0; if linked_24 == nil { and__1927000168__auto____2 = ifn_25.Invoke_O__O(arg_26) } else { and__1927000168__auto____2 = linked_24.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_23, arg_26) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(t__0))); if and__1927000168__auto____3 { var root_27 any = A_arbace_classes_types_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = t__0; var arg_31 any = Lit_8; if linked_28 == nil { return ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { return linked_28.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_27, arg_30, arg_31) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_void_QMARK__A_New() *A_arbace_classes_types_void_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_void_QMARK__A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Ctor() {}
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8)).Ref() }
func A_arbace_classes_types_array_QMARK__A_New() *A_arbace_classes_types_array_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_32 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = t__0; if linked_33 == nil { and__1927000168__auto____2 = ifn_34.Invoke_O__O(arg_35) } else { and__1927000168__auto____2 = linked_33.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_36 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = t__0; var arg_40 any = Lit_1; if linked_37 == nil { return ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { return linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_ref_QMARK__A_New() *A_arbace_classes_types_ref_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_ref_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_classes_types_A_const_14); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var and__1927000168__auto____3 any; var root_41 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = t__0; if linked_42 == nil { and__1927000168__auto____3 = ifn_43.Invoke_O__O(arg_44) } else { and__1927000168__auto____3 = linked_42.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_45 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = t__0; var arg_49 any = Lit_6; if linked_46 == nil { or__1927000174__auto____4 = ifn_47.Invoke_O_O__O(arg_48, arg_49) } else { or__1927000174__auto____4 = linked_46.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_45, arg_48, arg_49) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_50 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = t__0; if linked_51 == nil { return ifn_52.Invoke_O__O(arg_53) } else { return linked_51.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_50, arg_53) } } } else { return and__1927000168__auto____3 } } }
func A_arbace_classes_types_class_desc_QMARK__A_New() *A_arbace_classes_types_class_desc_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class_desc_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_54 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = t__0; if linked_55 == nil { and__1927000168__auto____2 = ifn_56.Invoke_O__O(arg_57) } else { and__1927000168__auto____2 = linked_55.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_54, arg_57) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_58 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = t__0; var arg_62 any = Lit_6; if linked_59 == nil { return ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { return linked_59.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_58, arg_61, arg_62) } } else { return and__1927000168__auto____2 } }

func A_arbace_classes_types_internal__GT_desc_A_New() *A_arbace_classes_types_internal__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_internal__GT_desc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var root_63 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = n__0; var arg_67 any = Lit_1; if linked_64 == nil { tmp1 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { tmp1 = linked_64.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if jrt.J2g_Truth(tmp1) { return n__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref() } }
func A_arbace_classes_types_desc__GT_internal_A_New() *A_arbace_classes_types_desc__GT_internal_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_internal_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Ctor() {}
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_68 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = d__0; var arg_72 any = Lit_6; if linked_69 == nil { tmp1 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp1 = linked_69.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; if jrt.J2g_Truth(tmp1) { var root_73 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = d__0; var arg_77 any = A_arbace_classes_types_A_const_17; var arg_78 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(d__0)))).Ref(); if linked_74 == nil { return ifn_75.Invoke_O_O_O__O(arg_76, arg_77, arg_78) } else { return linked_74.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_73, arg_76, arg_77, arg_78) } } else { return d__0
	} }
func A_arbace_classes_types_elem_type_A_New() *A_arbace_classes_types_elem_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_elem_type_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Invoke_O_O__O(self, d__0 any) any { var root_79 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = d__0; var arg_83 any = A_arbace_classes_types_A_const_17; if linked_80 == nil { return ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { return linked_80.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) } }
func A_arbace_classes_types_array_of_A_New() *A_arbace_classes_types_array_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_of_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Invoke_O_O__O(self, d__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__0)).Ref() }
func A_arbace_classes_types_array_dims_A_New() *A_arbace_classes_types_array_dims_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 any; var root_84 any = A_arbace_classes_types_A_const_18.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var fnbody__90 any = A_arbace_classes_types_array_dims_fn__48000030_A_New(); var tmp2 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_types_array_dims_fn__48000030_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_classes_types_array_dims_fn__48000030_A_fn_class = fncls__89d; tmp2 = fncls__89d } else { tmp2 = fncls__89 }; arg_87 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp2, nil); var arg_88 any = d__0; if linked_85 == nil { tmp1 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref() }
//line :48:1
func A_arbace_classes_types_array_dims_fn__48000030_A_New() *A_arbace_classes_types_array_dims_fn__48000030_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_fn__48000030_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Invoke_O_O__O(self, p1__48000029_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_19, p1__48000029_SHARP___1)).Ref() }

func A_arbace_classes_types_size_A_New() *A_arbace_classes_types_size_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_size_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_classes_types_size_A) Ctor() {}
//line :50:1
func (t *A_arbace_classes_types_size_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_46); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_47) }; if tmp1 { return A_arbace_classes_types_A_const_20 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8) { return A_arbace_classes_types_A_const_21 } else { return A_arbace_classes_types_A_const_17 } } }

func A_arbace_classes_types_int_like_QMARK__A_New() *A_arbace_classes_types_int_like_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_int_like_QMARK__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_91 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = A_arbace_classes_types_A_const_23; var arg_95 any = t__0; if linked_92 == nil { return ifn_93.Invoke_O_O__O(arg_94, arg_95) } else { return linked_92.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_91, arg_94, arg_95) } }
func A_arbace_classes_types_numeric_QMARK__A_New() *A_arbace_classes_types_numeric_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_96 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = A_arbace_classes_types_A_const_24; var arg_100 any = t__0; if linked_97 == nil { return ifn_98.Invoke_O_O__O(arg_99, arg_100) } else { return linked_97.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_96, arg_99, arg_100) } }




func A_arbace_classes_types_fn__48000037_A_New() *A_arbace_classes_types_fn__48000037_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000037_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Ctor() {}
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Invoke_O_O__O(self, p__48000036__0 any) any { var vec__48000038__2 any = p__48000036__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_101 any = A_arbace_classes_types_A_const_25.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = v__4; if linked_102 == nil { tmp1 = ifn_103.Invoke_O__O(arg_104) } else { tmp1 = linked_102.(*A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_101, arg_104) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, k__3) }

func A_arbace_classes_types_method_desc_A_New() *A_arbace_classes_types_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_method_desc_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Invoke_O_O_O__O(self, params__0, ret__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13, nil); var tmp2 any; var root_105 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_109 any = params__0; if linked_106 == nil { tmp2 = ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { tmp2 = linked_106.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, ret__1)).Ref() }






func A_arbace_classes_types_parse_method_desc_A_New() *A_arbace_classes_types_parse_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Ctor() {}
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Invoke_O_O__O(self, d__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Get_O__O(d__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__135 any = A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class
		if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__135); A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp2, nil); r__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()





		jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Put_O_O__O(d__0, r__3)
//line :70:1
		return r__3 } }
func A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(p0 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Invoke_O__O(self any) any { { var i__1 any = lang.RT_Box_J__Number_NoInit(1); var ps__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_29)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))) { var tmp2 any; var root_116 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_118 lang.IFn
													if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = t.F_d; var arg_120 any; var na_121 any = i__1; if jrt.Long_InstanceOf(na_121) { var n0_122 int64 = jrt.NN(jrt.Long_Cast(na_121)).LongValue__J(); if n0_122 == 9223372036854775807 { arg_120 = lang.Numbers_Inc_O__Number_NoInit(na_121) } else { arg_120 = jrt.Long_ValueOf_J__Long_NoInit(n0_122 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_121) { var n0_122_2 float64 = jrt.NN(jrt.Double_Cast(na_121)).DoubleValue__D(); arg_120 = jrt.Double_ValueOf_D__Double_NoInit(n0_122_2 + 1.0).Ref() } else { arg_120 = lang.Numbers_Inc_O__Number_NoInit(na_121) } }; if linked_117 == nil { tmp2 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp2 = linked_117.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) }
//line :72:1
		return lang.Tuple_Create_O_O__IPersistentVector(ps__2, tmp2) } else { var j__3 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__113 any = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(t.F_d, i__1); var tmp4 *jrt.Class
			var fncls__112 /*line :72:1*/*jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class

			if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__113); A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class = fncls__112d; tmp4 = fncls__112d } else { tmp4 = fncls__112 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__113, tmp4, nil); j__3 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
//line :72:1
			var end__4 any; var tmp5 *jrt.String = jrt.String_Cast(t.F_d)


			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_30)).CharValue__C(), jrt.NN(tmp5).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__3))) { var tmp6 *jrt.String = jrt.String_Cast(t.F_d); end__4 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(tmp6).IndexOf_String_I__I(Lit_7, lang.RT_IntCast_O__I_NoInit(j__3))))).Ref() } else { var na_114 any = j__3; if jrt.Long_InstanceOf(na_114) { var n0_115 int64 = jrt.NN(jrt.Long_Cast(na_114)).LongValue__J(); if n0_115 == 9223372036854775807 { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_114) } else { end__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_115 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_114) { var n0_115_2 float64 = jrt.NN(jrt.Double_Cast(na_114)).DoubleValue__D(); end__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_115_2 + 1.0).Ref() } else { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_114) } } }
			var tmp7 any; var root_123 any = A_arbace_classes_types_A_const_7.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = ps__2; var arg_127 any; var root_128 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = t.F_d; var arg_132 any = i__1; var arg_133 any = end__4; if linked_129 == nil { arg_127 = ifn_130.Invoke_O_O_O__O(arg_131, arg_132, arg_133) } else { arg_127 = linked_129.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_128, arg_131, arg_132, arg_133) }; if linked_124 == nil { tmp7 = ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { tmp7 = linked_124.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; i__1, ps__2 = end__4, tmp7; continue L1 } } }; /*line :71:1*/panic("j2g: unreachable") }


func A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(p0, p1 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_19)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) { var tmp2 jrt.Number_I; var na_110 any = j__1; if jrt.Long_InstanceOf(na_110) { var n0_111 int64 = jrt.NN(jrt.Long_Cast(na_110)).LongValue__J(); if n0_111 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_110) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_111 + 1)) } } else { if jrt.Double_InstanceOf(na_110) { var n0_111_2 float64 = jrt.NN(jrt.Double_Cast(na_110)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_111_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_110) } }; j__1 = tmp2; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_package_of_A_New() *A_arbace_classes_types_package_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_package_of_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Invoke_O_O__O(self, internal__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5); if
											lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_9 } else { var root_136 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = internal__0; var arg_140 any = A_arbace_classes_types_A_const_21; var arg_141 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_136, arg_139, arg_140, arg_141) } } }

func A_arbace_classes_types_simple_name_of_A_New() *A_arbace_classes_types_simple_name_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_simple_name_of_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Ctor() {}
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Invoke_O_O__O(self, internal__0 any) any { var n__2 any; var root_142 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_144 lang.IFn; if
												linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = internal__0; var arg_146 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5)))).Ref(); if linked_143 == nil { n__2 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { n__2 = linked_143.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) }; var root_147 any =
												A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = n__2; var arg_151 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(n__2)).LastIndexOf_String__I(Lit_11)))).Ref(); if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } }

func A_arbace_classes_types_desc__GT_class_name_A_New() *A_arbace_classes_types_desc__GT_class_name_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_class_name_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Ctor() {}
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_152 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = d__0; if linked_153 == nil { tmp1 = ifn_154.Invoke_O__O(arg_155) } else { tmp1 = linked_153.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_152, arg_155) }; if jrt.J2g_Truth(tmp1) { var root_156 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = d__0; var arg_160 any = Lit_5; var arg_161 any = Lit_4; if linked_157 == nil { return ifn_158.Invoke_O_O_O__O(arg_159, arg_160, arg_161) } else { return linked_157.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_156, arg_159, arg_160, arg_161) } } else { if A_arbace_classes_types_A_const_32 != nil {
		var root_162 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any; var root_168 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = d__0; if linked_169 == nil { arg_165 = ifn_170.Invoke_O__O(arg_171) } else { arg_165 = linked_169.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_168, arg_171) }; var arg_166 any = Lit_5; var arg_167 any = Lit_4; if linked_163 == nil { return ifn_164.Invoke_O_O_O__O(arg_165, arg_166, arg_167) } else { return linked_163.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_162, arg_165, arg_166, arg_167) } } else {
//line :90:1
			return nil
		}
	} }
func A_arbace_classes_types_class__GT_desc_A_New() *A_arbace_classes_types_class__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class__GT_desc_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Ctor() {}
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.NN(jrt.Class_Cast(c__0)).IsPrimitive__Z() { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()); var tmp2 any; var root_184 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); if linked_185 == nil { tmp2 = ifn_186.Invoke_O__O(arg_187) } else { tmp2 = linked_185.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_184, arg_187) }; return tmp1.Invoke_O__O(tmp2) } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {
		var root_172 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_176 any = Lit_4; var arg_177 any = Lit_5; if linked_173 == nil { return ifn_174.Invoke_O_O_O__O(arg_175, arg_176, arg_177) } else { return linked_173.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_172, arg_175, arg_176, arg_177) } } else {
//line :94:1
			if A_arbace_classes_types_A_const_32 != nil {

				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7); var tmp4 any; var root_178 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_182 any = Lit_4; var arg_183 any = Lit_5; if linked_179 == nil { tmp4 = ifn_180.Invoke_O_O_O__O(arg_181, arg_182, arg_183) } else { tmp4 = linked_179.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_178, arg_181, arg_182, arg_183) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil)).Ref() } else {
//line :94:1
					return nil
				}
		}
	}
}











func A_arbace_classes_types_array_sym_QMARK__A_New() *A_arbace_classes_types_array_sym_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_sym_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any; var root_188 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_190 lang.IFn; if
											linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = s__0; if linked_189 == nil { and__1927000168__auto____2 = ifn_190.Invoke_O__O(arg_191) } else { and__1927000168__auto____2 = linked_189.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_192 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = s__0; if linked_193 == nil { and__1927000168__auto____3 = ifn_194.Invoke_O__O(arg_195) } else { and__1927000168__auto____3 = linked_193.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_192, arg_195) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_196 any = A_arbace_classes_types_A_const_38.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_classes_types_A_const_39; var arg_200 any; var root_201 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = s__0; if linked_202 == nil { arg_200 = ifn_203.Invoke_O__O(arg_204) } else { arg_200 = linked_202.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_201, arg_204) }; if linked_197 == nil { return ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { return linked_197.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_classes_types_with_anns_A_New() *A_arbace_classes_types_with_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Ctor() {}
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Invoke_O_O_O__O(self, tn__0, form__1 any) any { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__1); var anns__4 any; if

	jrt.J2g_Truth(m__3) { var root_205 any = A_arbace_classes_types_A_const_40.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_209 any; var root_210 any = A_arbace_classes_types_A_const_41.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any; var fnbody__220 any = A_arbace_classes_types_with_anns_fn__48000056_A_New(); var tmp1 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_classes_types_with_anns_fn__48000056_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_classes_types_with_anns_fn__48000056_A_fn_class = fncls__219d; tmp1 = fncls__219d } else { tmp1 = fncls__219 }; arg_213 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__220, tmp1, nil); var arg_214 any = m__3; if linked_211 == nil { arg_209 = ifn_212.Invoke_O_O__O(arg_213, arg_214) } else { arg_209 = linked_211.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_210, arg_213, arg_214) }; if linked_206 == nil { anns__4 = ifn_207.Invoke_O_O__O(arg_208, arg_209) } else { anns__4 = linked_206.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_205, arg_208, arg_209) } } else { anns__4 = nil }; var tmp2 any; var root_221 any =
	A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = anns__4; if linked_222 == nil { tmp2 = ifn_223.Invoke_O__O(arg_224) } else { tmp2 = linked_222.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_221, arg_224) }; if jrt.J2g_Truth(tmp2) { var root_225 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = tn__0; var arg_229 any = A_arbace_classes_types_A_const_44; var arg_230 any = anns__4; if linked_226 == nil { return ifn_227.Invoke_O_O_O__O(arg_228, arg_229, arg_230) } else { return linked_226.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_225, arg_228, arg_229, arg_230) } } else { return tn__0 } }
//line :117:1
func A_arbace_classes_types_with_anns_fn__48000056_A_New() *A_arbace_classes_types_with_anns_fn__48000056_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_fn__48000056_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Ctor() {}
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Invoke_O_O__O(self, p__48000055__1 any) any { var vec__48000057__2 any = p__48000055__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_215 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_217 lang.IFn; _ = ___4; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = k__3; if linked_216 == nil { return ifn_217.Invoke_O__O(arg_218) } else { return linked_216.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_215, arg_218) } }


func A_arbace_classes_types_parse_type_A_New() *A_arbace_classes_types_parse_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Ctor() {}
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Invoke_O_O_O__O(self, scope__0, form__1 any) any {



	var root_231 any = A_arbace_classes_types_A_const_45.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, A_arbace_classes_types_with_anns_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var tmp1 any; var and__1927000168__auto____3 any; var root_236 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_238 lang.IFn

	if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = form__1; if linked_237 == nil { and__1927000168__auto____3 = ifn_238.Invoke_O__O(arg_239) } else { and__1927000168__auto____3 = linked_237.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_236, arg_239) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_240 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = form__1; if linked_241 == nil { tmp2 = ifn_242.Invoke_O__O(arg_243) } else { tmp2 = linked_241.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_240, arg_243) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :125:1
	if jrt.J2g_Truth(tmp1) { var tmp3 any = A_arbace_classes_types_A_const_46; var tmp4 any = A_arbace_classes_types_A_const_47; var tmp5 any = A_arbace_classes_types_A_const_48; arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1))) } else { var tmp6 any; var root_244 any = A_arbace_classes_types_A_const_49.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, A_arbace_classes_types_array_sym_QMARK__A_fn_class); var ifn_246 lang.IFn



		if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = form__1; if linked_245 == nil { tmp6 = ifn_246.Invoke_O__O(arg_247) } else { tmp6 = linked_245.(*A_arbace_classes_types_array_sym_QMARK__A).Invoke_O_O__O(root_244, arg_247) }
//line :125:1
		if jrt.J2g_Truth(tmp6) { var base__3 any; var root_248 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_250 lang.IFn




			if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var root_252 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = form__1; if linked_253 == nil { arg_251 = ifn_254.Invoke_O__O(arg_255) } else { arg_251 = linked_253.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_252, arg_255) }; if linked_249 == nil { base__3 = ifn_250.Invoke_O__O(arg_251) } else { base__3 = linked_249.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_248, arg_251) }
//line :125:1
			var n__4 any; var root_256 any = A_arbace_classes_types_A_const_50.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_parse_long_A_fn_class); var ifn_258 lang.IFn





			if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var root_260 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = form__1; if linked_261 == nil { arg_259 = ifn_262.Invoke_O__O(arg_263) } else { arg_259 = linked_261.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_260, arg_263) }; if linked_257 == nil { n__4 = ifn_258.Invoke_O__O(arg_259) } else { n__4 = linked_257.(*aot_arbace_core.A_arbace_core_parse_long_A).Invoke_O_O__O(root_256, arg_259) }
			var tmp7 any; var root_264 any = A_arbace_classes_types_A_const_51.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var fnbody__270 any = A_arbace_classes_types_parse_type_fn__48000065_A_New(); var tmp8 *jrt.Class; var fncls__269 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000065_A_fn_class; if fncls__269 == nil { var fncls__269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_classes_types_parse_type_fn__48000065_A_fn_class = fncls__269d; tmp8 = fncls__269d } else { tmp8 = fncls__269 }; arg_267 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__270, tmp8, nil); var arg_268 any; var root_271 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_classes_types_parse_type_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = scope__0; var arg_275 any = base__3; if linked_272 == nil { arg_268 = ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { arg_268 = linked_272.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_271, arg_274, arg_275) }; if linked_265 == nil { tmp7 = ifn_266.Invoke_O_O__O(arg_267, arg_268) } else { tmp7 = linked_265.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_264, arg_267, arg_268) }; arg_234 = lang.RT_Nth_O_I__O_NoInit(tmp7, lang.RT_IntCast_O__I_NoInit(n__4)) } else {
//line :125:1
				var tmp9 any; var and__1927000168__auto____3_2 any; var root_276 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_278 lang.IFn








				if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = form__1; if linked_277 == nil { and__1927000168__auto____3_2 = ifn_278.Invoke_O__O(arg_279) } else { and__1927000168__auto____3_2 = linked_277.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_276, arg_279) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp9 = lang.IFn_Cast(A_arbace_classes_types_A_const_55.GetRawRoot__O()).Invoke_O__O(form__1) } else { tmp9 = and__1927000168__auto____3_2 }
//line :125:1
				if jrt.J2g_Truth(tmp9) { var d__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_55.GetRawRoot__O()).Invoke_O__O(form__1)










					if lang.Util_Equiv_O_O__Z_NoInit(d__3, Lit_17) { var tmp10 any = A_arbace_classes_types_A_const_46; var tmp11 any = A_arbace_classes_types_A_const_52; var tmp12 any = A_arbace_classes_types_A_const_53; arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, Lit_18, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())))) } else { var tmp13 any = A_arbace_classes_types_A_const_46; var tmp14 any = A_arbace_classes_types_A_const_52; var tmp15 any = A_arbace_classes_types_A_const_53; var tmp16 any = A_arbace_classes_types_A_const_46; var tmp17 any = A_arbace_classes_types_A_const_47; var tmp18 any = A_arbace_classes_types_A_const_48; var tmp19 any; var root_280 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_282 lang.IFn

						if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = d__3; var arg_284 any = A_arbace_classes_types_A_const_17; if linked_281 == nil { tmp19 = ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { tmp19 = linked_281.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }
//line :136:1
						arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp19)))) } } else {
//line :125:1
							if lang.Util_Equiv_O_O__Z_NoInit(form__1, A_arbace_classes_types_A_const_59) { arg_234 = A_arbace_classes_types_A_const_60 } else { var tmp20 any; var and__1927000168__auto____3_3 any; var root_285 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_287 lang.IFn
















								if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = form__1; if linked_286 == nil { and__1927000168__auto____3_3 = ifn_287.Invoke_O__O(arg_288) } else { and__1927000168__auto____3_3 = linked_286.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_285, arg_288) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_289 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = A_arbace_classes_types_A_const_61.Invoke_O__O(scope__0); var arg_293 any = form__1; if linked_290 == nil { tmp20 = ifn_291.Invoke_O_O__O(arg_292, arg_293) } else { tmp20 = linked_290.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_289, arg_292, arg_293) } } else { tmp20 = and__1927000168__auto____3_3 }
//line :125:1
								if jrt.J2g_Truth(tmp20) { arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_62, A_arbace_classes_types_A_const_63, form__1)) } else { var tmp21 any; var root_294 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_296 lang.IFn



















									if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = form__1; if linked_295 == nil { tmp21 = ifn_296.Invoke_O__O(arg_297) } else { tmp21 = linked_295.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_294, arg_297) }
//line :125:1
									if jrt.J2g_Truth(tmp21) { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_64.Invoke_O__O(scope__0)).Invoke_O__O(form__1)




















										if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4_2 any = temp__1927000408__auto____3; var o__5 any; var temp__1927000414__auto____5 any = A_arbace_classes_types_A_const_65.Invoke_O__O(scope__0)
											if jrt.J2g_Truth(temp__1927000414__auto____5) { var f__6 any = temp__1927000414__auto____5; o__5 = lang.IFn_Cast(f__6).Invoke_O__O(n__4_2) } else { o__5 = nil }
//line :146:1
											var G__48000067__6_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, n__4_2, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref()))

											if jrt.J2g_Truth(o__5) { var root_298 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = G__48000067__6_; var arg_302 any = A_arbace_classes_types_A_const_66; var arg_303 any = o__5; if linked_299 == nil { arg_234 = ifn_300.Invoke_O_O_O__O(arg_301, arg_302, arg_303) } else { arg_234 = linked_299.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_298, arg_301, arg_302, arg_303) } } else { arg_234 = G__48000067__6_ } } else {
//line :146:1
												var tmp22 any; var root_304 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_306 lang.IFn


												if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var arg_308 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_68, form__1)); if linked_305 == nil { tmp22 = ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { tmp22 = linked_305.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) }
//line :146:1
												panic(jrt.Thrown(jrt.Throwable_Cast(tmp22))) } } else {
//line :125:1
													var tmp23 any; var root_309 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_311 lang.IFn

























													if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = form__1; if linked_310 == nil { tmp23 = ifn_311.Invoke_O__O(arg_312) } else { tmp23 = linked_310.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_309, arg_312) }
//line :125:1
													if jrt.J2g_Truth(tmp23) { var d__3_2 any; var root_313 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_315 lang.IFn


























														if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = form__1; var arg_317 any = Lit_4; var arg_318 any = Lit_5; if linked_314 == nil { d__3_2 = ifn_315.Invoke_O_O_O__O(arg_316, arg_317, arg_318) } else { d__3_2 = linked_314.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_313, arg_316, arg_317, arg_318) }
														var tmp24 any; var root_319 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = d__3_2; var arg_323 any = Lit_1; if linked_320 == nil { tmp24 = ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { tmp24 = linked_320.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }; if jrt.J2g_Truth(tmp24) { var body_p__4 *A_arbace_classes_types_parse_type_p__48000068_A = A_arbace_classes_types_parse_type_p__48000068_A_New(); var p__4 any; var fnbody__344 any = any(body_p__4); var tmp25 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_classes_types_parse_type_p__48000068_A_fn_class; if fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_classes_types_parse_type_p__48000068_A_fn_class = fncls__343d; tmp25 = fncls__343d } else { tmp25 = fncls__343 }; p__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__344, tmp25, nil)



															arg_234 = lang.IFn_Cast(p__4).Invoke_O__O(d__3_2) } else {
																var root_345 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, A_arbace_classes_types_parse_type_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = scope__0; var arg_349 any; var root_350 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = form__1; if linked_351 == nil { arg_349 = ifn_352.Invoke_O__O(arg_353) } else { arg_349 = linked_351.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_350, arg_353) }; if linked_346 == nil { arg_234 = ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { arg_234 = linked_346.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) } } } else {
//line :125:1
																	var tmp26 any; var root_354 any = A_arbace_classes_types_A_const_69.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_356 lang.IFn


































																	if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = form__1; if linked_355 == nil { tmp26 = ifn_356.Invoke_O__O(arg_357) } else { tmp26 = linked_355.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_354, arg_357) }
//line :125:1
																	if jrt.J2g_Truth(tmp26) { var d__3_3 any; var root_358 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_360 lang.IFn


































																		if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = form__1; if linked_359 == nil { d__3_3 = ifn_360.Invoke_O__O(arg_361) } else { d__3_3 = linked_359.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_358, arg_361) }
																		var root_362 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, A_arbace_classes_types_parse_type_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = scope__0; var arg_366 any; var tmp27 any; var root_367 any = A_arbace_classes_types_A_const_71.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = d__3_3; if linked_368 == nil { tmp27 = ifn_369.Invoke_O__O(arg_370) } else { tmp27 = linked_368.(*A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_367, arg_370) }; if jrt.J2g_Truth(tmp27) { var root_371 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = lang.IFn_Cast(A_arbace_classes_types_A_const_72.GetRawRoot__O()).Invoke_O__O(d__3_3); if linked_372 == nil { arg_366 = ifn_373.Invoke_O__O(arg_374) } else { arg_366 = linked_372.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_371, arg_374) } } else {
																			var tmp28 any; var root_375 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = d__3_3; if linked_376 == nil { tmp28 = ifn_377.Invoke_O__O(arg_378) } else { tmp28 = linked_376.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_375, arg_378) }; if jrt.J2g_Truth(tmp28) { var root_379 any = A_arbace_classes_types_A_const_73.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, A_arbace_classes_types_desc__GT_class_name_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = d__3_3; if linked_380 == nil { arg_366 = ifn_381.Invoke_O__O(arg_382) } else { arg_366 = linked_380.(*A_arbace_classes_types_desc__GT_class_name_A).Invoke_O_O__O(root_379, arg_382) } } else { var root_383 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = jrt.NN(jrt.Class_Cast(form__1)).GetName__String().Ref(); if linked_384 == nil { arg_366 = ifn_385.Invoke_O__O(arg_386) } else { arg_366 = linked_384.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_383, arg_386) } } }
//line :161:1
																		if linked_363 == nil { arg_234 = ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { arg_234 = linked_363.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) } } else {
//line :125:1
																			var tmp29 any; var and__1927000168__auto____3_4 any; var root_387 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_389 lang.IFn






































																			if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = form__1; if linked_388 == nil { and__1927000168__auto____3_4 = ifn_389.Invoke_O__O(arg_390) } else { and__1927000168__auto____3_4 = linked_388.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_387, arg_390) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var tmp30 any = A_arbace_classes_types_A_const_75; var tmp31 any; var root_391 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = form__1; if linked_392 == nil { tmp31 = ifn_393.Invoke_O__O(arg_394) } else { tmp31 = linked_392.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_391, arg_394) }; tmp29 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp30, tmp31)).Ref() } else { tmp29 = and__1927000168__auto____3_4 }
//line :125:1
																			if jrt.J2g_Truth(tmp29) { var tmp32 any = A_arbace_classes_types_A_const_46; var tmp33 any = A_arbace_classes_types_A_const_52; var tmp34 any = A_arbace_classes_types_A_const_53; var tmp35 any; var root_395 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_classes_types_parse_type_A_fn_class); var ifn_397 lang.IFn







































																				if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = scope__0; var arg_399 any; var root_400 any = A_arbace_classes_types_A_const_77.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = form__1; if linked_401 == nil { arg_399 = ifn_402.Invoke_O__O(arg_403) } else { arg_399 = linked_401.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_400, arg_403) }; if linked_396 == nil { tmp35 = ifn_397.Invoke_O_O__O(arg_398, arg_399) } else { tmp35 = linked_396.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_395, arg_398, arg_399) }
//line :125:1
																				arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, tmp33, tmp34, tmp35)) } else { var tmp36 any; var and__1927000168__auto____3_5 any; var root_404 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_406 lang.IFn









































																					if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = form__1; if linked_405 == nil { and__1927000168__auto____3_5 = ifn_406.Invoke_O__O(arg_407) } else { and__1927000168__auto____3_5 = linked_405.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_404, arg_407) }; if jrt.J2g_Truth(and__1927000168__auto____3_5) { var tmp37 any = A_arbace_classes_types_A_const_78; var tmp38 any; var root_408 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = form__1; if linked_409 == nil { tmp38 = ifn_410.Invoke_O__O(arg_411) } else { tmp38 = linked_409.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_408, arg_411) }; tmp36 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp37, tmp38)).Ref() } else { tmp36 = and__1927000168__auto____3_5 }
//line :125:1
																					if jrt.J2g_Truth(tmp36) { var vec__48000070__3 any = form__1; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(1), nil); var b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp39 any = A_arbace_classes_types_A_const_46; var tmp40 any = A_arbace_classes_types_A_const_79; var tmp41 any = A_arbace_classes_types_A_const_80; var tmp42 any; var root_412 any = A_arbace_classes_types_A_const_81.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_414 lang.IFn; _ = ___4











































																						if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any; var root_416 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = k__5; if linked_417 == nil { arg_415 = ifn_418.Invoke_O__O(arg_419) } else { arg_415 = linked_417.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_416, arg_419) }; if linked_413 == nil { tmp42 = ifn_414.Invoke_O__O(arg_415) } else { tmp42 = linked_413.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_412, arg_415) }
//line :125:1
																						var tmp43 any = tmp42; var tmp44 any = A_arbace_classes_types_A_const_82; var tmp45 any; var root_420 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, A_arbace_classes_types_parse_type_A_fn_class); var ifn_422 lang.IFn











































																						if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = scope__0; var arg_424 any = b__6; if linked_421 == nil { tmp45 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { tmp45 = linked_421.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }
//line :125:1
																						arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp39, tmp40, tmp41, tmp43, tmp44, tmp45)) } else { var tmp46 any; var and__1927000168__auto____3_6 any; var root_425 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_427 lang.IFn













































																							if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = form__1; if linked_426 == nil { and__1927000168__auto____3_6 = ifn_427.Invoke_O__O(arg_428) } else { and__1927000168__auto____3_6 = linked_426.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_425, arg_428) }; if jrt.J2g_Truth(and__1927000168__auto____3_6) { var tmp47 any = A_arbace_classes_types_A_const_83; var tmp48 any; var root_429 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = form__1; if linked_430 == nil { tmp48 = ifn_431.Invoke_O__O(arg_432) } else { tmp48 = linked_430.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_429, arg_432) }; tmp46 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp47, tmp48)).Ref() } else { tmp46 = and__1927000168__auto____3_6 }
//line :125:1
																							if jrt.J2g_Truth(tmp46) { var tmp49 any = A_arbace_classes_types_A_const_46; var tmp50 any = A_arbace_classes_types_A_const_84; var tmp51 any = A_arbace_classes_types_A_const_85; var tmp52 any; var root_433 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_435 lang.IFn














































																								if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any; var fnbody__444 any = A_arbace_classes_types_parse_type_fn__48000073_A_New_O(scope__0); var tmp53 *jrt.Class; var fncls__443 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000073_A_fn_class; if fncls__443 == nil { var fncls__443d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__444); A_arbace_classes_types_parse_type_fn__48000073_A_fn_class = fncls__443d; tmp53 = fncls__443d } else { tmp53 = fncls__443 }; arg_436 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__444, tmp53, nil); var arg_437 any; var root_445 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = form__1; if linked_446 == nil { arg_437 = ifn_447.Invoke_O__O(arg_448) } else { arg_437 = linked_446.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_445, arg_448) }; if linked_434 == nil { tmp52 = ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { tmp52 = linked_434.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) }
//line :125:1
																								arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp50, tmp51, tmp52)) } else { var tmp54 any; var and__1927000168__auto____3_7 any; var root_449 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_451 lang.IFn
















































																									if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = form__1; if linked_450 == nil { and__1927000168__auto____3_7 = ifn_451.Invoke_O__O(arg_452) } else { and__1927000168__auto____3_7 = linked_450.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_449, arg_452) }; if jrt.J2g_Truth(and__1927000168__auto____3_7) { var tmp55 any = A_arbace_classes_types_A_const_88; var tmp56 any; var root_453 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = form__1; if linked_454 == nil { tmp56 = ifn_455.Invoke_O__O(arg_456) } else { tmp56 = linked_454.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_453, arg_456) }; tmp54 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp55, tmp56)).Ref() } else { tmp54 = and__1927000168__auto____3_7 }
//line :125:1
																									if jrt.J2g_Truth(tmp54) {

















































																										var root_457 any = A_arbace_classes_types_A_const_89.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var fnbody__496 any = A_arbace_classes_types_parse_type_fn__48000075_A_New_O(scope__0); var tmp57 *jrt.Class; var fncls__495 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_A_fn_class; if fncls__495 == nil { var fncls__495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__496); A_arbace_classes_types_parse_type_fn__48000075_A_fn_class = fncls__495d; tmp57 = fncls__495d } else { tmp57 = fncls__495 }; arg_460 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__496, tmp57, nil); var arg_461 any; var root_497 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_classes_types_parse_type_A_fn_class); var ifn_499 lang.IFn



																										if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = scope__0; var arg_501 any; var root_502 any = A_arbace_classes_types_A_const_77.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = form__1; if linked_503 == nil { arg_501 = ifn_504.Invoke_O__O(arg_505) } else { arg_501 = linked_503.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_502, arg_505) }; if linked_498 == nil { arg_461 = ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { arg_461 = linked_498.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_497, arg_500, arg_501) }
//line :175:1
																										var arg_462 any; var root_506 any = A_arbace_classes_types_A_const_91.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_508 lang.IFn




																										if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = form__1; if linked_507 == nil { arg_462 = ifn_508.Invoke_O__O(arg_509) } else { arg_462 = linked_507.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_506, arg_509) }
//line :175:1
																										if linked_458 == nil { arg_234 = ifn_459.Invoke_O_O_O__O(arg_460, arg_461, arg_462) } else { arg_234 = linked_458.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_457, arg_460, arg_461, arg_462) } } else {
//line :125:1
																											var tmp58 any; var root_510 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_512 lang.IFn
























































																											if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = form__1; if linked_511 == nil { tmp58 = ifn_512.Invoke_O__O(arg_513) } else { tmp58 = linked_511.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_510, arg_513) }
//line :125:1
																											if jrt.J2g_Truth(tmp58) { var c__3 any; var root_514 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, A_arbace_classes_types_parse_type_A_fn_class); var ifn_516 lang.IFn

























































																												if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = scope__0; var arg_518 any; var root_519 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = form__1; if linked_520 == nil { arg_518 = ifn_521.Invoke_O__O(arg_522) } else { arg_518 = linked_520.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_519, arg_522) }; if linked_515 == nil { c__3 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { c__3 = linked_515.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }
																												var tmp59 any = A_arbace_classes_types_A_const_56; if lang.Util_Equiv_O_O__Z_NoInit(tmp59, A_arbace_classes_types_A_const_46.Invoke_O__O(c__3)) { } else { var tmp60 any; var root_554 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var arg_558 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_555 == nil { tmp60 = ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { tmp60 = linked_555.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_554, arg_557, arg_558) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp60))) }
																												var root_523 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = c__3; var arg_527 any = A_arbace_classes_types_A_const_58; var arg_528 any; var root_529 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any; var fnbody__540 any = A_arbace_classes_types_parse_type_fn__48000082_A_New_O(scope__0); var tmp61 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000082_A_fn_class; if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__540); A_arbace_classes_types_parse_type_fn__48000082_A_fn_class = fncls__539d; tmp61 = fncls__539d } else { tmp61 = fncls__539 }; arg_532 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__540, tmp61, nil); var arg_533 any; var root_541 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = form__1; if linked_542 == nil { arg_533 = ifn_543.Invoke_O__O(arg_544) } else { arg_533 = linked_542.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_541, arg_544) }; if linked_530 == nil { arg_528 = ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { arg_528 = linked_530.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) }; if linked_524 == nil { arg_234 = ifn_525.Invoke_O_O_O__O(arg_526, arg_527, arg_528) } else { arg_234 = linked_524.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_523, arg_526, arg_527, arg_528) } } else {
//line :125:1
																													if A_arbace_classes_types_A_const_32 != nil { var tmp62 any; var root_545 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_547 lang.IFn





























































																														if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_92.GetRawRoot__O()).Invoke_O__O(form__1))).Ref(); var arg_549 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_68, form__1)); if linked_546 == nil { tmp62 = ifn_547.Invoke_O_O__O(arg_548, arg_549) } else { tmp62 = linked_546.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_545, arg_548, arg_549) }
//line :125:1
																														panic(jrt.Thrown(jrt.Throwable_Cast(tmp62))) } else { arg_234 = nil } } } } } } } } } } } } } }
//line :124:1
	var arg_235 any = form__1; if linked_232 == nil { return ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { return linked_232.(*A_arbace_classes_types_with_anns_A).Invoke_O_O_O__O(root_231, arg_234, arg_235)
	}
}





func A_arbace_classes_types_parse_type_fn__48000065_A_New() *A_arbace_classes_types_parse_type_fn__48000065_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000065_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Ctor() {}
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Invoke_O_O__O(self, e__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_52, A_arbace_classes_types_A_const_53, e__1)) }





















func A_arbace_classes_types_parse_type_p__48000068_A_New() *A_arbace_classes_types_parse_type_p__48000068_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_p__48000068_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Ctor() {}
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Invoke_O_O__O(self, d__1 any) any { var tmp1 any; var root_324 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = d__1; var arg_328 any = Lit_1; if linked_325 == nil { tmp1 = ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { tmp1 = linked_325.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_324, arg_327, arg_328) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_types_A_const_46; var tmp3 any = A_arbace_classes_types_A_const_52; var tmp4 any = A_arbace_classes_types_A_const_53; var tmp5 lang.IFn = lang.IFn_Cast(self); var tmp6 any; var root_338 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = d__1; var arg_342 any = A_arbace_classes_types_A_const_17; if linked_339 == nil { tmp6 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { tmp6 = linked_339.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5.Invoke_O__O(tmp6))) } else { var tmp7 any; var root_329 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_331 lang.IFn
												if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = d__1; var arg_333 any = Lit_6; if linked_330 == nil { tmp7 = ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { tmp7 = linked_330.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_329, arg_332, arg_333) }
//line :154:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any = A_arbace_classes_types_A_const_46; var tmp9 any = A_arbace_classes_types_A_const_56; var tmp10 any = A_arbace_classes_types_A_const_57; var tmp11 any; var root_334 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_336 lang.IFn
		if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = d__1; if linked_335 == nil { tmp11 = ifn_336.Invoke_O__O(arg_337) } else { tmp11 = linked_335.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_334, arg_337) }
//line :154:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, tmp11, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__1)) } else { return nil } } } }

















func A_arbace_classes_types_parse_type_fn__48000073_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Invoke_O_O__O(self, p1__48000062_SHARP___1 any) any { var root_438 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_classes_types_parse_type_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = t.F_scope; var arg_442 any = p1__48000062_SHARP___1; if linked_439 == nil { return ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { return linked_439.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) } }


func A_arbace_classes_types_parse_type_fn__48000075_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_A{}; t.Ctor_O(p0); return t }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Invoke_O_O_O__O(self, outer__1, f__2 any) any { var vec__48000076__3 any; var tmp1 any; var root_463 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_465 lang.IFn; if
														linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = f__2; if linked_464 == nil { tmp1 = ifn_465.Invoke_O__O(arg_466) } else { tmp1 = linked_464.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_463, arg_466) }; if jrt.J2g_Truth(tmp1) { vec__48000076__3 = f__2 } else { vec__48000076__3 = lang.Tuple_Create_O__IPersistentVector(f__2) }; var seq__48000077__4 any; var root_467 any = /*line :175:1*/A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_469 lang.IFn; if
														linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = vec__48000076__3; if linked_468 == nil { seq__48000077__4 = ifn_469.Invoke_O__O(arg_470) } else { seq__48000077__4 = linked_468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_467, arg_470) }; var first__48000078__5 any; var root_471 any = /*line :175:1*/A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if
														linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq__48000077__4; if linked_472 == nil { first__48000078__5 = ifn_473.Invoke_O__O(arg_474) } else { first__48000078__5 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; var seq__48000077__6 any; var root_475 any = /*line :175:1*/A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_477 lang.IFn; if
														linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = seq__48000077__4; if linked_476 == nil { seq__48000077__6 = ifn_477.Invoke_O__O(arg_478) } else { seq__48000077__6 = linked_476.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_475, arg_478) }; var c__7 any = first__48000078__5; var args__8 any = seq__48000077__6; var n__9 any; var tmp2 /*line :175:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil); var tmp3 any = A_arbace_classes_types_A_const_57.Invoke_O__O(outer__1); var tmp4 any; var root_479 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_481 lang.IFn; if

	linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = c__7; if linked_480 == nil { tmp4 = ifn_481.Invoke_O__O(arg_482) } else { tmp4 = linked_480.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_479, arg_482) }; n__9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref(); var tmp5 any = A_arbace_classes_types_A_const_46; var tmp6 any = A_arbace_classes_types_A_const_56; var tmp7 any = A_arbace_classes_types_A_const_57; var tmp8 any = A_arbace_classes_types_A_const_58; var tmp9 any; var root_483 any = /*line :175:1*/A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_485 lang.IFn; if


	linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var fnbody__494 any = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(t.F_scope); var tmp10 *jrt.Class; var fncls__493 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class; if fncls__493 == nil { var fncls__493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__494); A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class = fncls__493d; tmp10 = fncls__493d } else { tmp10 = fncls__493 }; arg_486 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__494, tmp10, nil); var arg_487 any = args__8; if linked_484 == nil { tmp9 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { tmp9 = linked_484.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_483, arg_486, arg_487) }; return /*line :175:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, n__9, tmp8, tmp9, A_arbace_classes_types_A_const_66, outer__1)) }


func A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Invoke_O_O__O(self, p1__48000063_SHARP___1 any) any { var root_488 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, A_arbace_classes_types_parse_type_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = t.F_scope; var arg_492 any = p1__48000063_SHARP___1; if linked_489 == nil { return ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { return linked_489.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) } }






func A_arbace_classes_types_parse_type_fn__48000082_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000082_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000082_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Invoke_O_O__O(self, p1__48000064_SHARP___1 any) any { var root_534 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, A_arbace_classes_types_parse_type_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = t.F_scope; var arg_538 any = p1__48000064_SHARP___1; if linked_535 == nil { return ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { return linked_535.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) } }




func A_arbace_classes_types_erase_A_New() *A_arbace_classes_types_erase_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_erase_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_classes_types_erase_A) Ctor() {}
//line :190:1
func (t *A_arbace_classes_types_erase_A) Invoke_O_O_O__O(self, bounds__0, tn__1 any) any { var G__48000085__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000085__3_) >> 9 & 7 { case 0: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_79) {





		var tmp1 any = A_arbace_classes_types_A_const_93; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_80.Invoke_O__O(tn__1)) { var root_560 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, A_arbace_classes_types_erase_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = bounds__0; var arg_564 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1); if linked_561 == nil { return ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { return linked_561.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) } } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	case 1: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__1) }
//line :193:1
	case 2: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_56) {

		var root_565 any = A_arbace_classes_types_A_const_25.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__1); if linked_566 == nil { return ifn_567.Invoke_O__O(arg_568) } else { return linked_566.(*A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_565, arg_568) } }
//line :193:1
	case 3: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_84) {




		var root_569 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, A_arbace_classes_types_erase_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = bounds__0; var arg_573 any; var root_574 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = A_arbace_classes_types_A_const_85.Invoke_O__O(tn__1); if linked_575 == nil { arg_573 = ifn_576.Invoke_O__O(arg_577) } else { arg_573 = linked_575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_574, arg_577) }; if linked_570 == nil { return ifn_571.Invoke_O_O__O(arg_572, arg_573) } else { return linked_570.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_569, arg_572, arg_573) } }
//line :193:1
	case 4: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_52) {


		var root_578 any = A_arbace_classes_types_A_const_96.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, A_arbace_classes_types_array_of_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var root_582 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, A_arbace_classes_types_erase_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = bounds__0; var arg_586 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1); if linked_583 == nil { arg_581 = ifn_584.Invoke_O_O__O(arg_585, arg_586) } else { arg_581 = linked_583.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_582, arg_585, arg_586) }; if linked_579 == nil { return ifn_580.Invoke_O__O(arg_581) } else { return linked_579.(*A_arbace_classes_types_array_of_A).Invoke_O_O__O(root_578, arg_581) } }
//line :193:1
	case 7: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_62) { var temp__1927000408__auto____4 any; var root_587 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_589 lang.IFn



		if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = lang.RT_Get_O_O__O_NoInit(bounds__0, A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1)); if linked_588 == nil { temp__1927000408__auto____4 = ifn_589.Invoke_O__O(arg_590) } else { temp__1927000408__auto____4 = linked_588.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_587, arg_590) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var root_591 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, A_arbace_classes_types_erase_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any; var root_596 any = A_arbace_classes_types_A_const_97.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = bounds__0; var arg_600 any = A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1); if linked_597 == nil { arg_594 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { arg_594 = linked_597.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }; var arg_595 any = b__5; if linked_592 == nil { return ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { return linked_592.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_591, arg_594, arg_595) } } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000085__3_))))) }







func A_arbace_classes_types_generic_QMARK__A_New() *A_arbace_classes_types_generic_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_generic_QMARK__A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Ctor() {}
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Invoke_O_O__O(self, tn__0 any) any { var G__48000087__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000087__2_) >> 9 & 7 { case 0: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_79) { return jrt.Boolean_TRUE.Ref() }; case 1: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_47) { return jrt.Boolean_FALSE.Ref() }; case 2: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_56) { var or__1927000174__auto____3 bool; var tmp1 any; var root_602 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_604 lang.IFn

		if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_603 == nil { tmp1 = ifn_604.Invoke_O__O(arg_605) } else { tmp1 = linked_603.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_602, arg_605) }; or__1927000174__auto____3 = lang.RT_BooleanCast_O__Z_NoInit(tmp1); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp2 any; var and__1927000168__auto____4 any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_606 any = A_arbace_classes_types_A_const_98.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, A_arbace_classes_types_generic_QMARK__A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if linked_607 == nil { tmp2 = ifn_608.Invoke_O__O(arg_609) } else { tmp2 = linked_607.(*A_arbace_classes_types_generic_QMARK__A).Invoke_O_O__O(root_606, arg_609) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } }
//line :204:1
	case 3: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_84) { return jrt.Boolean_TRUE.Ref() }; case 4: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_52) {


		var root_610 any = A_arbace_classes_types_A_const_98.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, A_arbace_classes_types_generic_QMARK__A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0); if linked_611 == nil { return ifn_612.Invoke_O__O(arg_613) } else { return linked_611.(*A_arbace_classes_types_generic_QMARK__A).Invoke_O_O__O(root_610, arg_613) } }
//line :204:1
	case 7: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_62) { return jrt.Boolean_TRUE.Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000087__2_))))) }







func A_arbace_classes_types_local_class_name_QMARK__A_New() *A_arbace_classes_types_local_class_name_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_local_class_name_QMARK__A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Ctor() {}
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Invoke_O_O_O__O(self, n__0, outer__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = outer__1; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_614 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = n__0; var arg_618 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, outer__1, nil)).Ref(); if linked_615 == nil { and__1927000168__auto____4 = ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { and__1927000168__auto____4 = linked_615.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_619 any = A_arbace_classes_types_A_const_38.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = A_arbace_classes_types_A_const_99; var arg_623 any; var root_624 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = n__0; var arg_628 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(outer__1)))).Ref(); if linked_625 == nil { arg_623 = ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { arg_623 = linked_625.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }; if linked_620 == nil { tmp1 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { tmp1 = linked_620.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) } } else {
//line :216:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_types_signature_A_New() *A_arbace_classes_types_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_signature_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_classes_types_signature_A) Ctor() {}
//line :219:1
func (t *A_arbace_classes_types_signature_A) Invoke_O_O__O(self, tn__0 any) any { var G__48000090__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000090__2_) >> 9 & 7 { case 0: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_79) { var G__48000091__3_ any = A_arbace_classes_types_A_const_80.Invoke_O__O(tn__0)









		switch lang.Util_Hash_O__I_NoInit(G__48000091__3_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, nil) { return Lit_40 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_100) {
			var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil); var tmp2 any; var root_631 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, A_arbace_classes_types_signature_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0); if linked_632 == nil { tmp2 = ifn_633.Invoke_O__O(arg_634) } else { tmp2 = linked_632.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_631, arg_634) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :232:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_93) { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil); var tmp4 any; var root_635 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, A_arbace_classes_types_signature_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0); if linked_636 == nil { tmp4 = ifn_637.Invoke_O__O(arg_638) } else { tmp4 = linked_636.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_635, arg_638) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000091__3_))))) }
//line :222:1
	case 1: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__0) }
//line :222:1
	case 2: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_56) { var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var root_639 any = A_arbace_classes_types_A_const_102.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_641 lang.IFn

		if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any; var root_643 any = A_arbace_classes_types_A_const_103.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, A_arbace_classes_types_local_class_name_QMARK__A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var arg_647 any; var G__48000092__3_ any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if lang.Util_Identical_O_O__Z_NoInit(G__48000092__3_, nil) { arg_647 = nil } else { arg_647 = A_arbace_classes_types_A_const_57.Invoke_O__O(G__48000092__3_) }; if linked_644 == nil { arg_642 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { arg_642 = linked_644.(*A_arbace_classes_types_local_class_name_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if linked_640 == nil { and__1927000168__auto____3 = ifn_641.Invoke_O__O(arg_642) } else { and__1927000168__auto____3 = linked_640.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(and__1927000168__auto____3) { temp__1927000408__auto____3 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var o__4 any = temp__1927000408__auto____3; var os__5 any; var root_648 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, A_arbace_classes_types_signature_A_fn_class); var ifn_650 lang.IFn
			if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = o__4; if linked_649 == nil { os__5 = ifn_650.Invoke_O__O(arg_651) } else { os__5 = linked_649.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_648, arg_651) }
			var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_4, nil, nil, Lit_7); var tmp6 any; var root_652 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = os__5; var arg_656 any = A_arbace_classes_types_A_const_21; var arg_657 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(os__5)))).Ref(); if linked_653 == nil { tmp6 = ifn_654.Invoke_O_O_O__O(arg_655, arg_656, arg_657) } else { tmp6 = linked_653.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_652, arg_655, arg_656, arg_657) }; var tmp7 any = tmp6; var tmp8 any; var root_658 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var arg_662 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_classes_types_A_const_57.Invoke_O__O(o__4))))).Ref(); if linked_659 == nil { tmp8 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { tmp8 = linked_659.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; var tmp9 any = tmp8; var tmp10 *jrt.String; var tmp11 any; var root_663 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_665 lang.IFn
			if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_664 == nil { tmp11 = ifn_665.Invoke_O__O(arg_666) } else { tmp11 = linked_664.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_663, arg_666) }; if jrt.J2g_Truth(tmp11) { var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp13 any; var root_667 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_671 any; var root_672 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var arg_676 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_673 == nil { arg_671 = ifn_674.Invoke_O_O__O(arg_675, arg_676) } else { arg_671 = linked_673.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_672, arg_675, arg_676) }; if linked_668 == nil { tmp13 = ifn_669.Invoke_O_O__O(arg_670, arg_671) } else { tmp13 = linked_668.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_667, arg_670, arg_671) }; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil)) } else { tmp10 = nil }
//line :226:1
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, tmp9, tmp10.Ref(), nil)).Ref() } else {

				var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, nil, Lit_7); var tmp15 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var tmp16 *jrt.String; var tmp17 any; var root_677 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_679 lang.IFn
				if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_678 == nil { tmp17 = ifn_679.Invoke_O__O(arg_680) } else { tmp17 = linked_678.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_677, arg_680) }; if jrt.J2g_Truth(tmp17) { var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp19 any; var root_681 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_685 any; var root_686 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var arg_690 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_687 == nil { arg_685 = ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { arg_685 = linked_687.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) }; if linked_682 == nil { tmp19 = ifn_683.Invoke_O_O__O(arg_684, arg_685) } else { tmp19 = linked_682.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_681, arg_684, arg_685) }; tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil)) } else { tmp16 = nil }
//line :228:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, tmp16.Ref(), nil)).Ref() } }
//line :222:1
	case 3: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_84) {











		var root_691 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, A_arbace_classes_types_signature_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any; var root_695 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = A_arbace_classes_types_A_const_85.Invoke_O__O(tn__0); if linked_696 == nil { arg_694 = ifn_697.Invoke_O__O(arg_698) } else { arg_694 = linked_696.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_695, arg_698) }; if linked_692 == nil { return ifn_693.Invoke_O__O(arg_694) } else { return linked_692.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_691, arg_694) } }
//line :222:1
	case 4: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_52) {







		var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp21 any; var root_699 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, A_arbace_classes_types_signature_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0); if linked_700 == nil { tmp21 = ifn_701.Invoke_O__O(arg_702) } else { tmp21 = linked_700.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_699, arg_702) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21)).Ref() }
//line :222:1
	case 7: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_62) {








		var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_7); var tmp23 any; var root_703 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = A_arbace_classes_types_A_const_63.Invoke_O__O(tn__0); if linked_704 == nil { tmp23 = ifn_705.Invoke_O__O(arg_706) } else { tmp23 = linked_704.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_703, arg_706) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, nil)).Ref() }
//line :222:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000090__2_))))) }













func A_arbace_classes_types_parse_type_params_A_New() *A_arbace_classes_types_parse_type_params_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Ctor() {}
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Invoke_O_O_O__O(self, scope__0, tps__1 any) any {




	var root_707 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var fnbody__754 any = A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(scope__0); var tmp1 *jrt.Class; var fncls__753 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class; if fncls__753 == nil { var fncls__753d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__754); A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class = fncls__753d; tmp1 = fncls__753d } else { tmp1 = fncls__753 }; arg_710 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__754, tmp1, nil); var arg_711 any = tps__1; if linked_708 == nil { return ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { return linked_708.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_707, arg_710, arg_711) } }
//line :241:1
func A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Invoke_O_O__O(self, tp__1 any) any {
	var tmp1 any; var root_712 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = tp__1; if linked_713 == nil { tmp1 = ifn_714.Invoke_O__O(arg_715) } else { tmp1 = linked_713.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_712, arg_715) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_types_A_const_63; var tmp3 any = A_arbace_classes_types_A_const_105; var tmp4 any = lang.PersistentVector_EMPTY.Ref(); var tmp5 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tp__1, tmp3, tmp4, tmp5, lang.RT_Meta_O__IPersistentMap_NoInit(tp__1))) } else { var vec__48000096__2 any = tp__1; var seq__48000097__3 any; var root_716 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn

		if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = vec__48000096__2; if linked_717 == nil { seq__48000097__3 = ifn_718.Invoke_O__O(arg_719) } else { seq__48000097__3 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }
//line :242:1
		var first__48000098__4 any; var root_720 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_722 lang.IFn

		if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = seq__48000097__3; if linked_721 == nil { first__48000098__4 = ifn_722.Invoke_O__O(arg_723) } else { first__48000098__4 = linked_721.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_720, arg_723) }
//line :242:1
		var seq__48000097__5 any; var root_724 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_726 lang.IFn

		if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = seq__48000097__3; if linked_725 == nil { seq__48000097__5 = ifn_726.Invoke_O__O(arg_727) } else { seq__48000097__5 = linked_725.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_724, arg_727) }
//line :242:1
		var s__6 any = first__48000098__4; var first__48000098__7 any; var root_728 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_730 lang.IFn

		if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = seq__48000097__5; if linked_729 == nil { first__48000098__7 = ifn_730.Invoke_O__O(arg_731) } else { first__48000098__7 = linked_729.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_728, arg_731) }
//line :242:1
		var seq__48000097__8 any; var root_732 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_734 lang.IFn

		if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = seq__48000097__5; if linked_733 == nil { seq__48000097__8 = ifn_734.Invoke_O__O(arg_735) } else { seq__48000097__8 = linked_733.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_732, arg_735) }
//line :242:1
		var kw__9 any = first__48000098__7
		var bs__10 any = seq__48000097__8

		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_106, kw__9) { } else { var tmp6 any; var root_748 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, tp__1)).Ref(); var arg_752 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_749 == nil { tmp6 = ifn_750.Invoke_O_O__O(arg_751, arg_752) } else { tmp6 = linked_749.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_748, arg_751, arg_752) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }
//line :242:1
		var tmp7 any = A_arbace_classes_types_A_const_63; var tmp8 any = A_arbace_classes_types_A_const_105; var tmp9 any; var root_736 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_738 lang.IFn



		if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var fnbody__747 any = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(t.F_scope); var tmp10 *jrt.Class; var fncls__746 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class; if fncls__746 == nil { var fncls__746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__747); A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class = fncls__746d; tmp10 = fncls__746d } else { tmp10 = fncls__746 }; arg_739 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__747, tmp10, nil); var arg_740 any = bs__10; if linked_737 == nil { tmp9 = ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { tmp9 = linked_737.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) }
//line :242:1
		var tmp11 any = tmp9; var tmp12 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, s__6, tmp8, tmp11, tmp12, lang.RT_Meta_O__IPersistentMap_NoInit(s__6)))
	}
}

func A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Invoke_O_O__O(self, p1__48000094_SHARP___1 any) any { var root_741 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_classes_types_parse_type_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = t.F_scope; var arg_745 any = p1__48000094_SHARP___1; if linked_742 == nil { return ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { return linked_742.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) } }


func A_arbace_classes_types_type_params_signature_A_New() *A_arbace_classes_types_type_params_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Ctor() {}
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Invoke_O_O_O__O(self, interface_QMARK___0, tps__1 any) any {



	var tmp1 any; var root_755 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = tps__1; if linked_756 == nil { tmp1 = ifn_757.Invoke_O__O(arg_758) } else { tmp1 = linked_756.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_755, arg_758) }; if jrt.J2g_Truth(tmp1) { return Lit_9 } else {

		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp3 any; var root_759 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_761 lang.IFn
		if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_763 any; var iter__1927001039__auto____6 any; var fnbody__935 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(interface_QMARK___0); var tmp4 *jrt.Class; var fncls__934 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class
		if fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__935); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class = fncls__934d; tmp4 = fncls__934d } else { tmp4 = fncls__934 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__935, tmp4, nil); arg_763 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(tps__1)
//line :256:1
		if linked_760 == nil { tmp3 = ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { tmp3 = linked_760.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }
//line :255:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
	} }
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Invoke_O_O__O(self, s__48000104__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__933 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(self, t.F_interface_QMARK_, s__48000104__1); var tmp2 *jrt.Class; var fncls__932 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class; if fncls__932 == nil { var fncls__932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__933); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class = fncls__932d; tmp2 = fncls__932d } else { tmp2 = fncls__932 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__933, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Ctor_O_O_O(c__iter__48000103, c__interface_QMARK_, c__s__48000104 any) { t.F_iter__48000103 = c__iter__48000103; t.F_interface_QMARK_ = c__interface_QMARK_; t.F_s__48000104 = c__s__48000104 }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Invoke_O__O(self any) any { { var s__48000104__1 any; var t_ any = t.F_s__48000104; t.F_s__48000104 = nil; s__48000104__1 = t_; for { var temp__1927000414__auto____2 any; var root_764 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = s__48000104__1; if linked_765 == nil { temp__1927000414__auto____2 = ifn_766.Invoke_O__O(arg_767) } else { temp__1927000414__auto____2 = linked_765.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_764, arg_767) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__48000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_768 any = A_arbace_classes_types_A_const_108.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = s__48000104__3; if linked_769 == nil { tmp1 = ifn_770.Invoke_O__O(arg_771) } else { tmp1 = linked_769.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_768, arg_771) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_772 any = A_arbace_classes_types_A_const_109.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = s__48000104__3; if linked_773 == nil { c__1927001037__auto____4 = ifn_774.Invoke_O__O(arg_775) } else { c__1927001037__auto____4 = linked_773.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_772, arg_775) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__48000106__6 any; var root_776 any = A_arbace_classes_types_A_const_110.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_777 == nil { b__48000106__6 = ifn_778.Invoke_O__O(arg_779) } else { b__48000106__6 = linked_777.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_776, arg_779) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__841 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(t.F_interface_QMARK_, b__48000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__840 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class; if fncls__840 == nil { var fncls__840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__841); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class = fncls__840d; tmp3 = fncls__840d } else { tmp3 = fncls__840 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__841, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_842 any = A_arbace_classes_types_A_const_114.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var root_847 any = A_arbace_classes_types_A_const_115.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = b__48000106__6; if linked_848 == nil { arg_845 = ifn_849.Invoke_O__O(arg_850) } else { arg_845 = linked_848.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_847, arg_850) }; var arg_846 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); var tmp5 any; var root_851 any = A_arbace_classes_types_A_const_116.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_853 lang.IFn; if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = s__48000104__3; if linked_852 == nil { tmp5 = ifn_853.Invoke_O__O(arg_854) } else { tmp5 = linked_852.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_851, arg_854) }; arg_846 = tmp4.Invoke_O__O(tmp5); if linked_843 == nil { return ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { return linked_843.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_842, arg_845, arg_846) } } else { var root_855 any = A_arbace_classes_types_A_const_114.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any; var root_860 any = A_arbace_classes_types_A_const_115.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = b__48000106__6; if linked_861 == nil { arg_858 = ifn_862.Invoke_O__O(arg_863) } else { arg_858 = linked_861.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_860, arg_863) }; var arg_859 any; if linked_856 == nil { return ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { return linked_856.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) } } } else { var map__48000115__4 any; var root_864 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = s__48000104__3; if linked_865 == nil { map__48000115__4 = ifn_866.Invoke_O__O(arg_867) } else { map__48000115__4 = linked_865.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_864, arg_867) }; var map__48000115__5 any; if lang.ISeq_InstanceOf(map__48000115__4) { var tmp6 any; var root_868 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = map__48000115__4; if linked_869 == nil { tmp6 = ifn_870.Invoke_O__O(arg_871) } else { tmp6 = linked_869.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_868, arg_871) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_872 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = map__48000115__4; if linked_873 == nil { tmp7 = ifn_874.Invoke_O__O(arg_875) } else { tmp7 = linked_873.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_872, arg_875) }; map__48000115__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_876 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = map__48000115__4; if linked_877 == nil { tmp8 = ifn_878.Invoke_O__O(arg_879) } else { tmp8 = linked_877.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_876, arg_879) }; if jrt.J2g_Truth(tmp8) { var root_880 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = map__48000115__4; if linked_881 == nil { map__48000115__5 = ifn_882.Invoke_O__O(arg_883) } else { map__48000115__5 = linked_881.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_880, arg_883) } } else { map__48000115__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000115__5 = map__48000115__4 }; var sym__6 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_63); var bounds__7 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_105); var root_884 any = A_arbace_classes_types_A_const_117.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp10 any; var root_889 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_891 lang.IFn
																if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = sym__6; if linked_890 == nil { tmp10 = ifn_891.Invoke_O__O(arg_892) } else { tmp10 = linked_890.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_889, arg_892) }; var tmp11 any = tmp10; var tmp12 any; var tmp13 any; var root_893 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_895 lang.IFn
																if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = bounds__7; if linked_894 == nil { tmp13 = ifn_895.Invoke_O__O(arg_896) } else { tmp13 = linked_894.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_893, arg_896) }; if jrt.J2g_Truth(tmp13) { tmp12 = Lit_58 } else {

		var root_897 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_901 any; var root_902 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_904 lang.IFn
		if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any; var fnbody__927 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(t.F_interface_QMARK_); var tmp14 *jrt.Class; var fncls__926 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class
		if fncls__926 == nil { var fncls__926d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__927); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class = fncls__926d; tmp14 = fncls__926d } else { tmp14 = fncls__926 }; arg_905 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__927, tmp14, nil)
//line :262:1
		var arg_906 any = bounds__7; if linked_903 == nil { arg_901 = ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { arg_901 = linked_903.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) }
//line :261:1
		if linked_898 == nil { tmp12 = ifn_899.Invoke_O_O__O(arg_900, arg_901) } else { tmp12 = linked_898.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_897, arg_900, arg_901) } }
//line :258:1
	arg_887 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12)).Ref()
//line :257:1
	var arg_888 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); var tmp16 any; var root_928 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = s__48000104__3; if linked_929 == nil { tmp16 = ifn_930.Invoke_O__O(arg_931) } else { tmp16 = linked_929.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_928, arg_931) }; arg_888 = tmp15.Invoke_O__O(tmp16); if linked_885 == nil { return ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { return linked_885.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Ctor_O_O_I_O(c__interface_QMARK_, c__b__48000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_interface_QMARK_ = c__interface_QMARK_; t.F_b__48000106 = c__b__48000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Invoke_O__O(self any) any { { var i__48000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__48000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__48000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__48000105__1)); var map__48000110__3 any; if lang.ISeq_InstanceOf(map__48000110__2) { var tmp2 any; var root_780 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = map__48000110__2; if linked_781 == nil { tmp2 = ifn_782.Invoke_O__O(arg_783) } else { tmp2 = linked_781.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_780, arg_783) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_784 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = map__48000110__2; if linked_785 == nil { tmp3 = ifn_786.Invoke_O__O(arg_787) } else { tmp3 = linked_785.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_784, arg_787) }; map__48000110__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_788 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = map__48000110__2; if linked_789 == nil { tmp4 = ifn_790.Invoke_O__O(arg_791) } else { tmp4 = linked_789.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_788, arg_791) }; if jrt.J2g_Truth(tmp4) { var root_792 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = map__48000110__2; if linked_793 == nil { map__48000110__3 = ifn_794.Invoke_O__O(arg_795) } else { map__48000110__3 = linked_793.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_792, arg_795) } } else { map__48000110__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000110__3 = map__48000110__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_63); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_105); var root_796 any = A_arbace_classes_types_A_const_112.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = t.F_b__48000106; var arg_800 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 any; var root_801 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_803 lang.IFn
																	if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = sym__4; if linked_802 == nil { tmp6 = ifn_803.Invoke_O__O(arg_804) } else { tmp6 = linked_802.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_801, arg_804) }; var tmp7 any = tmp6; var tmp8 any; var tmp9 any; var root_805 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_807 lang.IFn
																	if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = bounds__5; if linked_806 == nil { tmp9 = ifn_807.Invoke_O__O(arg_808) } else { tmp9 = linked_806.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_805, arg_808) }; if jrt.J2g_Truth(tmp9) { tmp8 = Lit_58 } else {

		var root_809 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_813 any; var root_814 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_816 lang.IFn
		if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any; var fnbody__839 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(t.F_interface_QMARK_); var tmp10 *jrt.Class; var fncls__838 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class
		if fncls__838 == nil { var fncls__838d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__839); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class = fncls__838d; tmp10 = fncls__838d } else { tmp10 = fncls__838 }; arg_817 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__839, tmp10, nil)
//line :262:1
		var arg_818 any = bounds__5; if linked_815 == nil { arg_813 = ifn_816.Invoke_O_O__O(arg_817, arg_818) } else { arg_813 = linked_815.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_814, arg_817, arg_818) }
//line :261:1
		if linked_810 == nil { tmp8 = ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { tmp8 = linked_810.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_809, arg_812, arg_813) } }
//line :258:1
	arg_800 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref()
//line :257:1
	if linked_797 == nil { ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { linked_797.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_796, arg_799, arg_800) }; i__48000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__48000105__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Invoke_O_O_O__O(self, i__1, b__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, b__2) } else {
																					var tmp1 any; var and__1927000168__auto____3 bool; var na_819 any = i__1; if jrt.Long_InstanceOf(na_819) { var n0_820 int64 = jrt.NN(jrt.Long_Cast(na_819)).LongValue__J(); and__1927000168__auto____3 = n0_820 == 0 } else { if jrt.Double_InstanceOf(na_819) { var n0_820_2 float64 = jrt.NN(jrt.Double_Cast(na_819)).DoubleValue__D(); and__1927000168__auto____3 = n0_820_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_819) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
																						var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_821 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, A_arbace_classes_types_signature_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = b__2; if linked_822 == nil { tmp5 = ifn_823.Invoke_O__O(arg_824) } else { tmp5 = linked_822.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_821, arg_824) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
																							var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_825 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, A_arbace_classes_types_signature_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = b__2; if linked_826 == nil { tmp7 = ifn_827.Invoke_O__O(arg_828) } else { tmp7 = linked_826.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_825, arg_828) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } } }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var n0_829 int64 = i__1_l; and__1927000168__auto____3 = n0_829 == 0; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_830 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, A_arbace_classes_types_signature_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = b__2; if linked_831 == nil { tmp5 = ifn_832.Invoke_O__O(arg_833) } else { tmp5 = linked_831.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_830, arg_833) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_834 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, A_arbace_classes_types_signature_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = b__2; if linked_835 == nil { tmp7 = ifn_836.Invoke_O__O(arg_837) } else { tmp7 = linked_835.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_834, arg_837) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } }
//line :263:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Invoke_O_O_O__O(self, i__1, b__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, b__2) } else {
																			var tmp1 any; var and__1927000168__auto____3 bool; var na_907 any = i__1; if jrt.Long_InstanceOf(na_907) { var n0_908 int64 = jrt.NN(jrt.Long_Cast(na_907)).LongValue__J(); and__1927000168__auto____3 = n0_908 == 0 } else { if jrt.Double_InstanceOf(na_907) { var n0_908_2 float64 = jrt.NN(jrt.Double_Cast(na_907)).DoubleValue__D(); and__1927000168__auto____3 = n0_908_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_907) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
																				var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_909 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_classes_types_signature_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = b__2; if linked_910 == nil { tmp5 = ifn_911.Invoke_O__O(arg_912) } else { tmp5 = linked_910.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_909, arg_912) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
																					var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_913 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, A_arbace_classes_types_signature_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = b__2; if linked_914 == nil { tmp7 = ifn_915.Invoke_O__O(arg_916) } else { tmp7 = linked_914.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_913, arg_916) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } } }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var n0_917 int64 = i__1_l; and__1927000168__auto____3 = n0_917 == 0; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_918 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, A_arbace_classes_types_signature_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = b__2; if linked_919 == nil { tmp5 = ifn_920.Invoke_O__O(arg_921) } else { tmp5 = linked_919.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_918, arg_921) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_922 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, A_arbace_classes_types_signature_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = b__2; if linked_923 == nil { tmp7 = ifn_924.Invoke_O__O(arg_925) } else { tmp7 = linked_923.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_922, arg_925) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref()
		}
}

func A_arbace_classes_types_bounds_map_A_New() *A_arbace_classes_types_bounds_map_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Invoke_O_O__O(self, tps__0 any) any { var root_936 any = A_arbace_classes_types_A_const_40.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_940 any; var root_941 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any; var fnbody__963 any = A_arbace_classes_types_bounds_map_fn__48000123_A_New(); var tmp1 *jrt.Class; var fncls__962 *jrt.Class = A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class; if fncls__962 == nil { var fncls__962d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class = fncls__962d; tmp1 = fncls__962d } else { tmp1 = fncls__962 }; arg_944 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__963, tmp1, nil); var arg_945 any = tps__0; if linked_942 == nil { arg_940 = ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { arg_940 = linked_942.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) }; if linked_937 == nil { return ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { return linked_937.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) } }
//line :270:1
func A_arbace_classes_types_bounds_map_fn__48000123_A_New() *A_arbace_classes_types_bounds_map_fn__48000123_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_fn__48000123_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Invoke_O_O__O(self, p__48000122__1 any) any { var map__48000124__2 any = p__48000122__1; var map__48000124__3 any; if lang.ISeq_InstanceOf(map__48000124__2) { var tmp1 any; var root_946 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = map__48000124__2; if linked_947 == nil { tmp1 = ifn_948.Invoke_O__O(arg_949) } else { tmp1 = linked_947.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_946, arg_949) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_950 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = map__48000124__2; if linked_951 == nil { tmp2 = ifn_952.Invoke_O__O(arg_953) } else { tmp2 = linked_951.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_950, arg_953) }; map__48000124__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_954 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = map__48000124__2; if linked_955 == nil { tmp3 = ifn_956.Invoke_O__O(arg_957) } else { tmp3 = linked_955.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_954, arg_957) }; if jrt.J2g_Truth(tmp3) { var root_958 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = map__48000124__2; if linked_959 == nil { map__48000124__3 = ifn_960.Invoke_O__O(arg_961) } else { map__48000124__3 = linked_959.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_958, arg_961) } } else { map__48000124__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000124__3 = map__48000124__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_63); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_105); return lang.Tuple_Create_O_O__IPersistentVector(sym__4, bounds__5) }

func A_arbace_classes_types_desc__GT_tnode_A_New() *A_arbace_classes_types_desc__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_tnode_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Invoke_O_O__O(self, d__0 any) any {
	var tmp1 any; var root_964 any = A_arbace_classes_types_A_const_71.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = d__0; if linked_965 == nil { tmp1 = ifn_966.Invoke_O__O(arg_967) } else { tmp1 = linked_965.(*A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_964, arg_967) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { var tmp2 any; var root_968 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_970 lang.IFn

		if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = d__0; if linked_969 == nil { tmp2 = ifn_970.Invoke_O__O(arg_971) } else { tmp2 = linked_969.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_968, arg_971) }
//line :273:1
		if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_classes_types_A_const_46; var tmp4 any = A_arbace_classes_types_A_const_52; var tmp5 any = A_arbace_classes_types_A_const_53; var tmp6 any; var root_972 any = A_arbace_classes_types_A_const_118.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, A_arbace_classes_types_desc__GT_tnode_A_fn_class); var ifn_974 lang.IFn

			if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var root_976 any = A_arbace_classes_types_A_const_119.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_classes_types_elem_type_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = d__0; if linked_977 == nil { arg_975 = ifn_978.Invoke_O__O(arg_979) } else { arg_975 = linked_977.(*A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_976, arg_979) }; if linked_973 == nil { tmp6 = ifn_974.Invoke_O__O(arg_975) } else { tmp6 = linked_973.(*A_arbace_classes_types_desc__GT_tnode_A).Invoke_O_O__O(root_972, arg_975) }
//line :273:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6)) } else { if A_arbace_classes_types_A_const_32 != nil { var tmp7 any = A_arbace_classes_types_A_const_46; var tmp8 any = A_arbace_classes_types_A_const_56; var tmp9 any = A_arbace_classes_types_A_const_57; var tmp10 any; var root_980 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_982 lang.IFn


				if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = d__0; if linked_981 == nil { tmp10 = ifn_982.Invoke_O__O(arg_983) } else { tmp10 = linked_981.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_980, arg_983) }
//line :273:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { return nil
				}
			}
	}
	} }
func A_arbace_classes_types_reflect__GT_tnode_A_New() *A_arbace_classes_types_reflect__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_reflect__GT_tnode_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Ctor() {}
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Invoke_O_O__O(self, ty__0 any) any {


	if jrt.Class_InstanceOf(ty__0) {
		var root_984 any = A_arbace_classes_types_A_const_118.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, A_arbace_classes_types_desc__GT_tnode_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any; var root_988 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = ty__0; if linked_989 == nil { arg_987 = ifn_990.Invoke_O__O(arg_991) } else { arg_987 = linked_989.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_988, arg_991) }; if linked_985 == nil { return ifn_986.Invoke_O__O(arg_987) } else { return linked_985.(*A_arbace_classes_types_desc__GT_tnode_A).Invoke_O_O__O(root_984, arg_987) } } else {
//line :281:1
			if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)).IsInstance_O__Z(ty__0) { var pt__2 any = ty__0; var tmp1 any = A_arbace_classes_types_A_const_46; var tmp2 any = A_arbace_classes_types_A_const_56; var tmp3 any = A_arbace_classes_types_A_const_57; var tmp4 any; var root_992 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_994 lang.IFn



				if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any; var root_996 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_31, jrt.RefArrayOf(jrt.Object_class)); if linked_997 == nil { arg_995 = ifn_998.Invoke_O__O(arg_999) } else { arg_995 = linked_997.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_996, arg_999) }; if linked_993 == nil { tmp4 = ifn_994.Invoke_O__O(arg_995) } else { tmp4 = linked_993.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_992, arg_995) }
//line :281:1
				var tmp5 any = tmp4; var tmp6 any = A_arbace_classes_types_A_const_58; var tmp7 any; var root_1000 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1002 lang.IFn




				if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var arg_1004 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_32, jrt.RefArrayOf(jrt.Object_class)); if linked_1001 == nil { tmp7 = ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { tmp7 = linked_1001.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) }
//line :281:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp7)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)).IsInstance_O__Z(ty__0) { var tmp8 any = A_arbace_classes_types_A_const_46; var tmp9 any = A_arbace_classes_types_A_const_62; var tmp10 any = A_arbace_classes_types_A_const_63; var tmp11 any; var root_1005 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1007 lang.IFn






					if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33), Lit_34, jrt.RefArrayOf(jrt.Object_class)); if linked_1006 == nil { tmp11 = ifn_1007.Invoke_O__O(arg_1008) } else { tmp11 = linked_1006.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1005, arg_1008) }
//line :281:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, tmp11)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35)).IsInstance_O__Z(ty__0) { var tmp12 any = A_arbace_classes_types_A_const_46; var tmp13 any = A_arbace_classes_types_A_const_52; var tmp14 any = A_arbace_classes_types_A_const_53; var tmp15 any; var root_1009 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_1011 lang.IFn








						if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35), Lit_36, jrt.RefArrayOf(jrt.Object_class)); if linked_1010 == nil { tmp15 = ifn_1011.Invoke_O__O(arg_1012) } else { tmp15 = linked_1010.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_1009, arg_1012) }
//line :281:1
						return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37)).IsInstance_O__Z(ty__0) { var w__2 any = ty__0; var lo__3 any; var root_1013 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1015 lang.IFn











							if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_38, jrt.RefArrayOf(jrt.Object_class)); if linked_1014 == nil { lo__3 = ifn_1015.Invoke_O__O(arg_1016) } else { lo__3 = linked_1014.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1013, arg_1016) }
//line :281:1
							var up__4 any; var root_1017 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1019 lang.IFn











							if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_39, jrt.RefArrayOf(jrt.Object_class)); if linked_1018 == nil { up__4 = ifn_1019.Invoke_O__O(arg_1020) } else { up__4 = linked_1018.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1017, arg_1020) }
							if jrt.J2g_Truth(lo__3) { var tmp16 any = A_arbace_classes_types_A_const_46; var tmp17 any = A_arbace_classes_types_A_const_79; var tmp18 any = A_arbace_classes_types_A_const_80; var tmp19 any = A_arbace_classes_types_A_const_100; var tmp20 any = A_arbace_classes_types_A_const_82; var tmp21 any; var root_1021 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any; var root_1025 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = lo__3; if linked_1026 == nil { arg_1024 = ifn_1027.Invoke_O__O(arg_1028) } else { arg_1024 = linked_1026.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1025, arg_1028) }; if linked_1022 == nil { tmp21 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp21 = linked_1022.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_1021, arg_1024) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21)) } else { var tmp22 any; var and__1927000168__auto____5 any = up__4
								if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1029 any = A_arbace_classes_types_A_const_12.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = A_arbace_classes_types_A_const_121; var arg_1033 any; var root_1034 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = up__4; if linked_1035 == nil { arg_1033 = ifn_1036.Invoke_O__O(arg_1037) } else { arg_1033 = linked_1035.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1034, arg_1037) }; if linked_1030 == nil { tmp22 = ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { tmp22 = linked_1030.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) } } else { tmp22 = and__1927000168__auto____5 }
//line :294:1
								if jrt.J2g_Truth(tmp22) { var tmp23 any = A_arbace_classes_types_A_const_46; var tmp24 any = A_arbace_classes_types_A_const_79; var tmp25 any = A_arbace_classes_types_A_const_80; var tmp26 any = A_arbace_classes_types_A_const_93; var tmp27 any = A_arbace_classes_types_A_const_82; var tmp28 any; var root_1038 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_1040 lang.IFn
									if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any; var root_1042 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = up__4; if linked_1043 == nil { arg_1041 = ifn_1044.Invoke_O__O(arg_1045) } else { arg_1041 = linked_1043.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1042, arg_1045) }; if linked_1039 == nil { tmp28 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp28 = linked_1039.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_1038, arg_1041) }
//line :294:1
									return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28)) } else { if A_arbace_classes_types_A_const_32 != nil { return A_arbace_classes_types_A_const_122 } else { return nil } } } } else {
//line :281:1
										if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, Lit_18, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { return nil
										}
									}
						}
					}
				}
		}
}










func A_arbace_classes_types_subst_A_New() *A_arbace_classes_types_subst_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_classes_types_subst_A) Ctor() {}
//line :299:1
func (t *A_arbace_classes_types_subst_A) Invoke_O_O_O__O(self, env__0, tn__1 any) any { var G__48000135__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000135__3_) >> 9 & 7 { case 0: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_79) {




		if jrt.J2g_Truth(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1)) { var root_1047 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = tn__1; var arg_1051 any = A_arbace_classes_types_A_const_82; var arg_1052 any; var fnbody__1059 any = A_arbace_classes_types_subst_fn__48000136_A_New_O(env__0); var tmp1 *jrt.Class; var fncls__1058 *jrt.Class = A_arbace_classes_types_subst_fn__48000136_A_fn_class; if fncls__1058 == nil { var fncls__1058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1059); A_arbace_classes_types_subst_fn__48000136_A_fn_class = fncls__1058d; tmp1 = fncls__1058d } else { tmp1 = fncls__1058 }; arg_1052 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1059, tmp1, nil); if linked_1048 == nil { return ifn_1049.Invoke_O_O_O__O(arg_1050, arg_1051, arg_1052) } else { return linked_1048.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1047, arg_1050, arg_1051, arg_1052) } } else { return tn__1 } }
//line :302:1
	case 2: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_56) { var G__48000138__4_ any; var root_1060 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1062 lang.IFn

		if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = tn__1; var arg_1064 any = A_arbace_classes_types_A_const_58; var arg_1065 any; var root_1066 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any; var fnbody__1077 any = A_arbace_classes_types_subst_fn__48000139_A_New_O(env__0); var tmp2 *jrt.Class; var fncls__1076 *jrt.Class = A_arbace_classes_types_subst_fn__48000139_A_fn_class; if fncls__1076 == nil { var fncls__1076d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__1077); A_arbace_classes_types_subst_fn__48000139_A_fn_class = fncls__1076d; tmp2 = fncls__1076d } else { tmp2 = fncls__1076 }; arg_1069 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1077, tmp2, nil); var arg_1070 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__1); if linked_1067 == nil { arg_1065 = ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { arg_1065 = linked_1067.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) }; if linked_1061 == nil { G__48000138__4_ = ifn_1062.Invoke_O_O_O__O(arg_1063, arg_1064, arg_1065) } else { G__48000138__4_ = linked_1061.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1060, arg_1063, arg_1064, arg_1065) }; if jrt.J2g_Truth(A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1)) {
			var root_1078 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = G__48000138__4_; var arg_1082 any = A_arbace_classes_types_A_const_66; var arg_1083 any; var fnbody__1090 any = A_arbace_classes_types_subst_fn__48000141_A_New_O(env__0); var tmp3 *jrt.Class; var fncls__1089 *jrt.Class = A_arbace_classes_types_subst_fn__48000141_A_fn_class; if fncls__1089 == nil { var fncls__1089d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__1090); A_arbace_classes_types_subst_fn__48000141_A_fn_class = fncls__1089d; tmp3 = fncls__1089d } else { tmp3 = fncls__1089 }; arg_1083 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1090, tmp3, nil); if linked_1079 == nil { return ifn_1080.Invoke_O_O_O__O(arg_1081, arg_1082, arg_1083) } else { return linked_1079.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1078, arg_1081, arg_1082, arg_1083) } } else {
//line :304:1
				return G__48000138__4_ } }
//line :302:1
	case 3: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_84) {





		var root_1091 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = tn__1; var arg_1095 any = A_arbace_classes_types_A_const_85; var arg_1096 any; var fnbody__1108 any = A_arbace_classes_types_subst_fn__48000143_A_New_O(env__0); var tmp4 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_classes_types_subst_fn__48000143_A_fn_class; if fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__1108); A_arbace_classes_types_subst_fn__48000143_A_fn_class = fncls__1107d; tmp4 = fncls__1107d } else { tmp4 = fncls__1107 }; arg_1096 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1108, tmp4, nil); if linked_1092 == nil { return ifn_1093.Invoke_O_O_O__O(arg_1094, arg_1095, arg_1096) } else { return linked_1092.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1091, arg_1094, arg_1095, arg_1096) } }
//line :302:1
	case 4: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_52) {



		var root_1109 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = tn__1; var arg_1113 any = A_arbace_classes_types_A_const_53; var arg_1114 any; var fnbody__1121 any = A_arbace_classes_types_subst_fn__48000145_A_New_O(env__0); var tmp5 *jrt.Class; var fncls__1120 *jrt.Class = A_arbace_classes_types_subst_fn__48000145_A_fn_class; if fncls__1120 == nil { var fncls__1120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__1121); A_arbace_classes_types_subst_fn__48000145_A_fn_class = fncls__1120d; tmp5 = fncls__1120d } else { tmp5 = fncls__1120 }; arg_1114 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1121, tmp5, nil); if linked_1110 == nil { return ifn_1111.Invoke_O_O_O__O(arg_1112, arg_1113, arg_1114) } else { return linked_1110.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1109, arg_1112, arg_1113, arg_1114) } }
//line :302:1
	case 7: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_62) {
		return lang.RT_Get_O_O_O__O_NoInit(env__0, A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1), tn__1) }
//line :302:1
	default:}; return tn__1 }

func A_arbace_classes_types_subst_fn__48000139_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000139_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000139_A{}; t.Ctor_O(p0); return t }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Invoke_O_O__O(self, p1__48000130_SHARP___1 any) any { var root_1071 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, A_arbace_classes_types_subst_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = t.F_env; var arg_1075 any = p1__48000130_SHARP___1; if linked_1072 == nil { return ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { return linked_1072.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) } }
func A_arbace_classes_types_subst_fn__48000141_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000141_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000141_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Invoke_O_O__O(self, p1__48000131_SHARP___1 any) any { var root_1084 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, A_arbace_classes_types_subst_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = t.F_env; var arg_1088 any = p1__48000131_SHARP___1; if linked_1085 == nil { return ifn_1086.Invoke_O_O__O(arg_1087, arg_1088) } else { return linked_1085.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1084, arg_1087, arg_1088) } }
func A_arbace_classes_types_subst_fn__48000145_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000145_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000145_A{}; t.Ctor_O(p0); return t }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Invoke_O_O__O(self, p1__48000132_SHARP___1 any) any { var root_1115 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_classes_types_subst_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = t.F_env; var arg_1119 any = p1__48000132_SHARP___1; if linked_1116 == nil { return ifn_1117.Invoke_O_O__O(arg_1118, arg_1119) } else { return linked_1116.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1115, arg_1118, arg_1119) } }
func A_arbace_classes_types_subst_fn__48000136_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000136_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000136_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Invoke_O_O__O(self, p1__48000133_SHARP___1 any) any { var root_1053 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, A_arbace_classes_types_subst_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = t.F_env; var arg_1057 any = p1__48000133_SHARP___1; if linked_1054 == nil { return ifn_1055.Invoke_O_O__O(arg_1056, arg_1057) } else { return linked_1054.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1053, arg_1056, arg_1057) } }
func A_arbace_classes_types_subst_fn__48000143_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000143_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000143_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Invoke_O_O__O(self, p1__48000134_SHARP___1 any) any { var root_1097 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any; var root_1102 any = A_arbace_classes_types_A_const_125.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var arg_1106 any = t.F_env; if linked_1103 == nil { arg_1100 = ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { arg_1100 = linked_1103.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) }; var arg_1101 any = p1__48000134_SHARP___1; if linked_1098 == nil { return ifn_1099.Invoke_O_O__O(arg_1100, arg_1101) } else { return linked_1098.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1097, arg_1100, arg_1101) } }


func A_arbace_classes_types_type_anns_A_New() *A_arbace_classes_types_type_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Ctor() {}
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Invoke_O_O__O(self, tn__0 any) any { var body_walk__2 *A_arbace_classes_types_type_anns_walk__48000148_A = A_arbace_classes_types_type_anns_walk__48000148_A_New(); var walk__2 any; var fnbody__1146 any = any(body_walk__2); var tmp1 *jrt.Class; var fncls__1145 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_A_fn_class; if fncls__1145 == nil { var fncls__1145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); A_arbace_classes_types_type_anns_walk__48000148_A_fn_class = fncls__1145d; tmp1 = fncls__1145d } else { tmp1 = fncls__1145 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1146, tmp1, nil); return /*line :326:1*/ lang.IFn_Cast(walk__2).Invoke_O_O__O(tn__0, Lit_9) }
//line :315:1
func A_arbace_classes_types_type_anns_walk__48000148_A_New() *A_arbace_classes_types_type_anns_walk__48000148_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Ctor() {}
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Invoke_O_O_O__O(self, tn__1, path__2 any) any {
	var root_1122 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any; var tmp1 any; var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))
	if and__1927000168__auto____3 { tmp1 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { arg_1125 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1), path__2) } else { arg_1125 = nil }
//line :316:1
	var arg_1126 any; var path__3 any; var tmp3 any; var tmp4 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))

	if and__1927000168__auto____3_2 { tmp3 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3_2).Ref() }; if jrt.J2g_Truth(tmp3) { path__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, path__2, nil)).Ref() } else { path__3 = path__2 }
	var root_1127 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any; var temp__1927000414__auto____4 any = A_arbace_classes_types_A_const_44.Invoke_O__O(tn__1)
	if jrt.J2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; arg_1130 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(path__3, a__5)) } else { arg_1130 = nil }
//line :319:1
	var arg_1131 any; var G__48000149__4_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1)

L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__48000149__4_) >> 0 & 3 { case 0: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_56) {

	var root_1133 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var arg_1137 any; var root_1138 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any; var fnbody__1144 any = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(path__3, self); var tmp5 *jrt.Class; var fncls__1143 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class; if fncls__1143 == nil { var fncls__1143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__1144); A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class = fncls__1143d; tmp5 = fncls__1143d } else { tmp5 = fncls__1143 }; arg_1141 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1144, tmp5, nil); var arg_1142 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__1); if linked_1139 == nil { arg_1137 = ifn_1140.Invoke_O_O__O(arg_1141, arg_1142) } else { arg_1137 = linked_1139.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1138, arg_1141, arg_1142) }; if linked_1134 == nil { arg_1131 = ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { arg_1131 = linked_1134.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) }
//line :321:1
	break L1 }; case 2: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_79) {


		if jrt.J2g_Truth(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1)) { arg_1131 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref()) } else { arg_1131 = nil }
//line :321:1
		break L1 }; case 3: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_52) {
			arg_1131 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref())
//line :321:1
			break L1 }; default:}; arg_1131 = nil}
//line :319:1
	if linked_1128 == nil { arg_1126 = ifn_1129.Invoke_O_O__O(arg_1130, arg_1131) } else { arg_1126 = linked_1128.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1127, arg_1130, arg_1131) }
//line :316:1
	if linked_1123 == nil { return ifn_1124.Invoke_O_O__O(arg_1125, arg_1126) } else { return linked_1123.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1122, arg_1125, arg_1126)
	}
}




func A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(p0, p1 any) *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Ctor_O_O(c__path, c__walk any) { t.F_path = c__path; t.F_walk = c__walk }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Invoke_O_O_O__O(self, i__1, a__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp1.Invoke_O_O__O(a__2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, t.F_path, i__1, nil)).Ref()) }




func A_arbace_classes_types_element_path_A_New() *A_arbace_classes_types_element_path_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_element_path_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Ctor() {}
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Invoke_O_O__O(self, tn__0 any) any { { var tn__2 any = tn__0; var path__3 any = Lit_9; L1: for {




	var tmp1 any = A_arbace_classes_types_A_const_52; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__2)) { tn__2, path__3 = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref(); continue L1 } else { return path__3 } } }; /*line :328:1*/panic("j2g: unreachable") }
















































































type A_arbace_classes_types_A struct{ jrt.Object }

var A_arbace_classes_types_A_const_pool *jrt.RefArray

var A_arbace_classes_types_A_const_0 *lang.Var

var A_arbace_classes_types_A_const_1 any

var A_arbace_classes_types_A_const_2 *lang.Var

var A_arbace_classes_types_A_const_3 any

var A_arbace_classes_types_A_const_4 *lang.Var

var A_arbace_classes_types_A_const_5 *lang.Var

var A_arbace_classes_types_A_const_6 *lang.Var

var A_arbace_classes_types_A_const_7 *lang.Var

var A_arbace_classes_types_A_const_8 any

var A_arbace_classes_types_A_const_9 *lang.Var

var A_arbace_classes_types_A_const_10 *lang.Var

var A_arbace_classes_types_A_const_11 *lang.Var

var A_arbace_classes_types_A_const_12 *lang.Var

var A_arbace_classes_types_A_const_13 *lang.Var

var A_arbace_classes_types_A_const_14 *lang.Keyword

var A_arbace_classes_types_A_const_15 *lang.Var

var A_arbace_classes_types_A_const_16 *lang.Var

var A_arbace_classes_types_A_const_17 any

var A_arbace_classes_types_A_const_18 *lang.Var

var A_arbace_classes_types_A_const_19 any

var A_arbace_classes_types_A_const_20 any

var A_arbace_classes_types_A_const_21 any

var A_arbace_classes_types_A_const_22 *lang.Var

var A_arbace_classes_types_A_const_23 any

var A_arbace_classes_types_A_const_24 any

var A_arbace_classes_types_A_const_25 *lang.Var

var A_arbace_classes_types_A_const_26 *lang.Var

var A_arbace_classes_types_A_const_27 *lang.Var

var A_arbace_classes_types_A_const_28 *lang.Var

var A_arbace_classes_types_A_const_29 any

var A_arbace_classes_types_A_const_30 any

var A_arbace_classes_types_A_const_31 *lang.Var

var A_arbace_classes_types_A_const_32 *lang.Keyword

var A_arbace_classes_types_A_const_33 *lang.Var

var A_arbace_classes_types_A_const_34 *lang.Var

var A_arbace_classes_types_A_const_35 *lang.Var

var A_arbace_classes_types_A_const_36 *lang.Var

var A_arbace_classes_types_A_const_37 *lang.Var

var A_arbace_classes_types_A_const_38 *lang.Var

var A_arbace_classes_types_A_const_39 any

var A_arbace_classes_types_A_const_40 *lang.Var

var A_arbace_classes_types_A_const_41 *lang.Var

var A_arbace_classes_types_A_const_42 *lang.Var

var A_arbace_classes_types_A_const_43 *lang.Var

var A_arbace_classes_types_A_const_44 *lang.Keyword

var A_arbace_classes_types_A_const_45 *lang.Var

var A_arbace_classes_types_A_const_46 *lang.Keyword

var A_arbace_classes_types_A_const_47 *lang.Keyword

var A_arbace_classes_types_A_const_48 *lang.Keyword

var A_arbace_classes_types_A_const_49 *lang.Var

var A_arbace_classes_types_A_const_50 *lang.Var

var A_arbace_classes_types_A_const_51 *lang.Var

var A_arbace_classes_types_A_const_52 *lang.Keyword

var A_arbace_classes_types_A_const_53 *lang.Keyword

var A_arbace_classes_types_A_const_54 *lang.Var

var A_arbace_classes_types_A_const_55 *lang.Var

var A_arbace_classes_types_A_const_56 *lang.Keyword

var A_arbace_classes_types_A_const_57 *lang.Keyword

var A_arbace_classes_types_A_const_58 *lang.Keyword

var A_arbace_classes_types_A_const_59 any

var A_arbace_classes_types_A_const_60 any

var A_arbace_classes_types_A_const_61 *lang.Keyword

var A_arbace_classes_types_A_const_62 *lang.Keyword

var A_arbace_classes_types_A_const_63 *lang.Keyword

var A_arbace_classes_types_A_const_64 *lang.Keyword

var A_arbace_classes_types_A_const_65 *lang.Keyword

var A_arbace_classes_types_A_const_66 *lang.Keyword

var A_arbace_classes_types_A_const_67 *lang.Var

var A_arbace_classes_types_A_const_68 *lang.Keyword

var A_arbace_classes_types_A_const_69 *lang.Var

var A_arbace_classes_types_A_const_70 *lang.Var

var A_arbace_classes_types_A_const_71 *lang.Var

var A_arbace_classes_types_A_const_72 *lang.Var

var A_arbace_classes_types_A_const_73 *lang.Var

var A_arbace_classes_types_A_const_74 *lang.Var

var A_arbace_classes_types_A_const_75 any

var A_arbace_classes_types_A_const_76 *lang.Var

var A_arbace_classes_types_A_const_77 *lang.Var

var A_arbace_classes_types_A_const_78 any

var A_arbace_classes_types_A_const_79 *lang.Keyword

var A_arbace_classes_types_A_const_80 *lang.Keyword

var A_arbace_classes_types_A_const_81 *lang.Var

var A_arbace_classes_types_A_const_82 *lang.Keyword

var A_arbace_classes_types_A_const_83 any

var A_arbace_classes_types_A_const_84 *lang.Keyword

var A_arbace_classes_types_A_const_85 *lang.Keyword

var A_arbace_classes_types_A_const_86 *lang.Var

var A_arbace_classes_types_A_const_87 *lang.Var

var A_arbace_classes_types_A_const_88 any

var A_arbace_classes_types_A_const_89 *lang.Var

var A_arbace_classes_types_A_const_90 *lang.Var

var A_arbace_classes_types_A_const_91 *lang.Var

var A_arbace_classes_types_A_const_92 *lang.Var

var A_arbace_classes_types_A_const_93 *lang.Keyword

var A_arbace_classes_types_A_const_94 *lang.Var

var A_arbace_classes_types_A_const_95 *lang.Var

var A_arbace_classes_types_A_const_96 *lang.Var

var A_arbace_classes_types_A_const_97 *lang.Var

var A_arbace_classes_types_A_const_98 *lang.Var

var A_arbace_classes_types_A_const_99 any

var A_arbace_classes_types_A_const_100 *lang.Keyword

var A_arbace_classes_types_A_const_101 *lang.Var

var A_arbace_classes_types_A_const_102 *lang.Var

var A_arbace_classes_types_A_const_103 *lang.Var

var A_arbace_classes_types_A_const_104 *lang.Var

var A_arbace_classes_types_A_const_105 *lang.Keyword

var A_arbace_classes_types_A_const_106 any

var A_arbace_classes_types_A_const_107 *lang.Var

var A_arbace_classes_types_A_const_108 *lang.Var

var A_arbace_classes_types_A_const_109 *lang.Var

var A_arbace_classes_types_A_const_110 *lang.Var

var A_arbace_classes_types_A_const_111 *lang.Var

var A_arbace_classes_types_A_const_112 *lang.Var

var A_arbace_classes_types_A_const_113 *lang.Var

var A_arbace_classes_types_A_const_114 *lang.Var

var A_arbace_classes_types_A_const_115 *lang.Var

var A_arbace_classes_types_A_const_116 *lang.Var

var A_arbace_classes_types_A_const_117 *lang.Var

var A_arbace_classes_types_A_const_118 *lang.Var

var A_arbace_classes_types_A_const_119 *lang.Var

var A_arbace_classes_types_A_const_120 *lang.Var

var A_arbace_classes_types_A_const_121 *jrt.Class

var A_arbace_classes_types_A_const_122 any

var A_arbace_classes_types_A_const_123 *lang.Var

var A_arbace_classes_types_A_const_124 *lang.Var

var A_arbace_classes_types_A_const_125 *lang.Var

var A_arbace_classes_types_A_const_126 *lang.Var

var A_arbace_classes_types_A_init jrt.ClassInit

func A_arbace_classes_types_A_Init() { if !A_arbace_classes_types_A_init.Done() { A_arbace_classes_types_A_init.Run(A_arbace_classes_types_A_clinit) } }

func A_arbace_classes_types_A_clinit() { A_arbace_classes_types_A_clinit_p0(); A_arbace_classes_types_A_clinit_p1(); A_arbace_classes_types_A_clinit_p2(); A_arbace_classes_types_A_clinit_p3(); A_arbace_classes_types_A_clinit_p4(); A_arbace_classes_types_A_clinit_p5(); A_arbace_classes_types_A_clinit_p6(); A_arbace_classes_types_A_clinit_p7(); A_arbace_classes_types_A_clinit_p8(); A_arbace_classes_types_A_clinit_p9(); A_arbace_classes_types_A_clinit_p10() }

func A_arbace_classes_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 163); A_arbace_classes_types_A_const_0 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[36]); A_arbace_classes_types_A_const_1 = A_arbace_classes_types_A_const_pool.A[37]; A_arbace_classes_types_A_const_2 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[38]); A_arbace_classes_types_A_const_3 = A_arbace_classes_types_A_const_pool.A[39]; A_arbace_classes_types_A_const_4 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[40]); A_arbace_classes_types_A_const_5 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[41]); A_arbace_classes_types_A_const_6 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[42]); A_arbace_classes_types_A_const_7 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[43]); A_arbace_classes_types_A_const_8 = A_arbace_classes_types_A_const_pool.A[44]; A_arbace_classes_types_A_const_9 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[45]); A_arbace_classes_types_A_const_10 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[46]); A_arbace_classes_types_A_const_11 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[47]) }

func A_arbace_classes_types_A_clinit_p1() { A_arbace_classes_types_A_const_12 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[48]); A_arbace_classes_types_A_const_13 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[49]); A_arbace_classes_types_A_const_14 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[50]); A_arbace_classes_types_A_const_15 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[51]); A_arbace_classes_types_A_const_16 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[52]); A_arbace_classes_types_A_const_17 = A_arbace_classes_types_A_const_pool.A[53]; A_arbace_classes_types_A_const_18 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[54]); A_arbace_classes_types_A_const_19 = A_arbace_classes_types_A_const_pool.A[55]; A_arbace_classes_types_A_const_20 = A_arbace_classes_types_A_const_pool.A[56]; A_arbace_classes_types_A_const_21 = A_arbace_classes_types_A_const_pool.A[57]; A_arbace_classes_types_A_const_22 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[58]); A_arbace_classes_types_A_const_23 = A_arbace_classes_types_A_const_pool.A[59]; A_arbace_classes_types_A_const_24 = A_arbace_classes_types_A_const_pool.A[60] }

func A_arbace_classes_types_A_clinit_p2() { A_arbace_classes_types_A_const_25 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[61]); A_arbace_classes_types_A_const_26 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[62]); A_arbace_classes_types_A_const_27 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[63]); A_arbace_classes_types_A_const_28 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[64]); A_arbace_classes_types_A_const_29 = A_arbace_classes_types_A_const_pool.A[65]; A_arbace_classes_types_A_const_30 = A_arbace_classes_types_A_const_pool.A[66]; A_arbace_classes_types_A_const_31 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[67]); A_arbace_classes_types_A_const_32 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[68]); A_arbace_classes_types_A_const_33 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[69]); A_arbace_classes_types_A_const_34 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[70]); A_arbace_classes_types_A_const_35 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[71]); A_arbace_classes_types_A_const_36 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[72]) }

func A_arbace_classes_types_A_clinit_p3() { A_arbace_classes_types_A_const_37 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[73]); A_arbace_classes_types_A_const_38 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[74]); A_arbace_classes_types_A_const_39 = A_arbace_classes_types_A_const_pool.A[75]; A_arbace_classes_types_A_const_40 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[76]); A_arbace_classes_types_A_const_41 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[77]); A_arbace_classes_types_A_const_42 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[78]); A_arbace_classes_types_A_const_43 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[79]); A_arbace_classes_types_A_const_44 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[80]); A_arbace_classes_types_A_const_45 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[81]); A_arbace_classes_types_A_const_46 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[82]); A_arbace_classes_types_A_const_47 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[83]); A_arbace_classes_types_A_const_48 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[84]) }

func A_arbace_classes_types_A_clinit_p4() { A_arbace_classes_types_A_const_49 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[85]); A_arbace_classes_types_A_const_50 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[86]); A_arbace_classes_types_A_const_51 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[87]); A_arbace_classes_types_A_const_52 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[88]); A_arbace_classes_types_A_const_53 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[89]); A_arbace_classes_types_A_const_54 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[90]); A_arbace_classes_types_A_const_55 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[91]); A_arbace_classes_types_A_const_56 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[92]); A_arbace_classes_types_A_const_57 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[93]); A_arbace_classes_types_A_const_58 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[94]); A_arbace_classes_types_A_const_59 = A_arbace_classes_types_A_const_pool.A[95]; A_arbace_classes_types_A_const_60 = A_arbace_classes_types_A_const_pool.A[96] }

func A_arbace_classes_types_A_clinit_p5() { A_arbace_classes_types_A_const_61 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[97]); A_arbace_classes_types_A_const_62 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[98]); A_arbace_classes_types_A_const_63 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[99]); A_arbace_classes_types_A_const_64 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[100]); A_arbace_classes_types_A_const_65 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[101]); A_arbace_classes_types_A_const_66 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[102]); A_arbace_classes_types_A_const_67 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[103]); A_arbace_classes_types_A_const_68 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[104]); A_arbace_classes_types_A_const_69 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[105]); A_arbace_classes_types_A_const_70 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[106]); A_arbace_classes_types_A_const_71 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[107]); A_arbace_classes_types_A_const_72 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[108]) }

func A_arbace_classes_types_A_clinit_p6() { A_arbace_classes_types_A_const_73 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[109]); A_arbace_classes_types_A_const_74 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[110]); A_arbace_classes_types_A_const_75 = A_arbace_classes_types_A_const_pool.A[111]; A_arbace_classes_types_A_const_76 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[112]); A_arbace_classes_types_A_const_77 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[113]); A_arbace_classes_types_A_const_78 = A_arbace_classes_types_A_const_pool.A[114]; A_arbace_classes_types_A_const_79 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[115]); A_arbace_classes_types_A_const_80 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[116]); A_arbace_classes_types_A_const_81 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[117]); A_arbace_classes_types_A_const_82 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[118]); A_arbace_classes_types_A_const_83 = A_arbace_classes_types_A_const_pool.A[119]; A_arbace_classes_types_A_const_84 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[120]) }

func A_arbace_classes_types_A_clinit_p7() { A_arbace_classes_types_A_const_85 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[121]); A_arbace_classes_types_A_const_86 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[122]); A_arbace_classes_types_A_const_87 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[123]); A_arbace_classes_types_A_const_88 = A_arbace_classes_types_A_const_pool.A[124]; A_arbace_classes_types_A_const_89 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[125]); A_arbace_classes_types_A_const_90 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[126]); A_arbace_classes_types_A_const_91 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[127]); A_arbace_classes_types_A_const_92 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[128]); A_arbace_classes_types_A_const_93 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[129]); A_arbace_classes_types_A_const_94 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[130]); A_arbace_classes_types_A_const_95 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[131]); A_arbace_classes_types_A_const_96 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[132]) }

func A_arbace_classes_types_A_clinit_p8() { A_arbace_classes_types_A_const_97 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[133]); A_arbace_classes_types_A_const_98 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[134]); A_arbace_classes_types_A_const_99 = A_arbace_classes_types_A_const_pool.A[135]; A_arbace_classes_types_A_const_100 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[136]); A_arbace_classes_types_A_const_101 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[137]); A_arbace_classes_types_A_const_102 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[138]); A_arbace_classes_types_A_const_103 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[139]); A_arbace_classes_types_A_const_104 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[140]); A_arbace_classes_types_A_const_105 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[141]); A_arbace_classes_types_A_const_106 = A_arbace_classes_types_A_const_pool.A[142]; A_arbace_classes_types_A_const_107 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[143]); A_arbace_classes_types_A_const_108 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[144]) }

func A_arbace_classes_types_A_clinit_p9() { A_arbace_classes_types_A_const_109 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[145]); A_arbace_classes_types_A_const_110 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[146]); A_arbace_classes_types_A_const_111 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[147]); A_arbace_classes_types_A_const_112 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[148]); A_arbace_classes_types_A_const_113 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[149]); A_arbace_classes_types_A_const_114 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[150]); A_arbace_classes_types_A_const_115 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[151]); A_arbace_classes_types_A_const_116 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[152]); A_arbace_classes_types_A_const_117 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[153]); A_arbace_classes_types_A_const_118 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[154]); A_arbace_classes_types_A_const_119 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[155]); A_arbace_classes_types_A_const_120 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[156]) }

func A_arbace_classes_types_A_clinit_p10() { A_arbace_classes_types_A_const_121 = jrt.Class_Cast(A_arbace_classes_types_A_const_pool.A[157]); A_arbace_classes_types_A_const_122 = A_arbace_classes_types_A_const_pool.A[158]; A_arbace_classes_types_A_const_123 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[159]); A_arbace_classes_types_A_const_124 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[160]); A_arbace_classes_types_A_const_125 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[161]); A_arbace_classes_types_A_const_126 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[162]) }

func A_arbace_classes_types_A_New() *A_arbace_classes_types_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_A) Ctor() {}

func (t *A_arbace_classes_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_A_class }

func (t *A_arbace_classes_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_A); return ok }

func A_arbace_classes_types_A_Cast(x any) *A_arbace_classes_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_A_class)) }; return v }



type A_arbace_classes_types_array_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_fn__48000030_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_fn__48000030_A_fn_class *jrt.Class



type A_arbace_classes_types_array_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_of_A_fn_class *jrt.Class



type A_arbace_classes_types_array_sym_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_sym_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_fn__48000123_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class *jrt.Class



type A_arbace_classes_types_class__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_class__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_class_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_class_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_class_name_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_class_name_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_internal_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_elem_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_elem_type_A_fn_class *jrt.Class



type A_arbace_classes_types_element_path_A struct{ j2g_header uint64 }

var A_arbace_classes_types_element_path_A_fn_class *jrt.Class



type A_arbace_classes_types_erase_A struct{ j2g_header uint64 }

var A_arbace_classes_types_erase_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000004_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000004_A_New() *A_arbace_classes_types_eval48000004_A { t := &A_arbace_classes_types_eval48000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000004_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000004_A_class }

func (t *A_arbace_classes_types_eval48000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000004_A); return ok }

func A_arbace_classes_types_eval48000004_A_Cast(x any) *A_arbace_classes_types_eval48000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000004_A_class)) }; return v }



type A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000008_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000008_A_New() *A_arbace_classes_types_eval48000008_A { t := &A_arbace_classes_types_eval48000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000008_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000008_A_class }

func (t *A_arbace_classes_types_eval48000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000008_A); return ok }

func A_arbace_classes_types_eval48000008_A_Cast(x any) *A_arbace_classes_types_eval48000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000008_A_class)) }; return v }



type A_arbace_classes_types_eval48000008_fn__48000009_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000013_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000013_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000037_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000037_A_fn_class *jrt.Class



type A_arbace_classes_types_generic_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_generic_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_int_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_int_like_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_internal__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_internal__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_class_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_class_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_local_class_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_local_class_name_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_package_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_package_of_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_A struct{ j2g_header uint64; F_d any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A struct{ j2g_header uint64; F_d, F_i any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000065_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_fn__48000065_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000073_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000073_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000082_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000082_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_p__48000068_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_p__48000068_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_params_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class *jrt.Class



type A_arbace_classes_types_prim_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_prim_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_ref_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_ref_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_reflect__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_reflect__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_simple_name_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_simple_name_of_A_fn_class *jrt.Class



type A_arbace_classes_types_size_A struct{ j2g_header uint64 }

var A_arbace_classes_types_size_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_A struct{ j2g_header uint64 }

var A_arbace_classes_types_subst_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000136_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000136_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000139_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000139_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000141_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000141_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000143_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000143_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000145_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000145_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_walk__48000148_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A struct{ j2g_header uint64; F_path, F_walk any }

var A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_params_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A struct{ j2g_header uint64; F_iter__48000103, F_interface_QMARK_, F_s__48000104 any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A struct{ j2g_header uint64; F_interface_QMARK_, F_b__48000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class *jrt.Class



type A_arbace_classes_types_void_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_void_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_fn__48000056_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_fn__48000056_A_fn_class *jrt.Class
