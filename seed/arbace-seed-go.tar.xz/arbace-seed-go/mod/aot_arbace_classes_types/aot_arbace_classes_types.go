//line aot_arbace_classes_types.ae:1
package aot_arbace_classes_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New() *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_types_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_types_eval48000008_fn__48000009_A_New() *A_arbace_classes_types_eval48000008_fn__48000009_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000008_fn__48000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_8), A_arbace_classes_types_A_const_6.GetRawRoot__O(), A_arbace_classes_types_A_const_7) }















func A_arbace_classes_types_fn__48000013_A_New() *A_arbace_classes_types_fn__48000013_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000013_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Ctor() {}
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Invoke_O_O__O(self, p__48000012__0 any) any { var vec__48000014__2 any = p__48000012__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(v__4, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(k__3)) }













func A_arbace_classes_types_lang_class_A_New() *A_arbace_classes_types_lang_class_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_class_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Ctor() {}
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0)).Ref() }
func A_arbace_classes_types_lang_desc_A_New() *A_arbace_classes_types_lang_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_desc_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Ctor() {}
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_5, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0, nil)).Ref() }

func A_arbace_classes_types_prim_QMARK__A_New() *A_arbace_classes_types_prim_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_prim_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(t__0))); if and__1927000168__auto____3 { return lang.IFn_Cast(A_arbace_classes_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_8) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_void_QMARK__A_New() *A_arbace_classes_types_void_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_void_QMARK__A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Ctor() {}
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8)).Ref() }
func A_arbace_classes_types_array_QMARK__A_New() *A_arbace_classes_types_array_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_1) } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_ref_QMARK__A_New() *A_arbace_classes_types_ref_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_ref_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_classes_types_A_const_14); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_6); if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(t__0) } } else { return and__1927000168__auto____3 } } }
func A_arbace_classes_types_class_desc_QMARK__A_New() *A_arbace_classes_types_class_desc_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class_desc_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_6) } else { return and__1927000168__auto____2 } }

func A_arbace_classes_types_internal__GT_desc_A_New() *A_arbace_classes_types_internal__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_internal__GT_desc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Invoke_O_O__O(self, n__0 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_1)) { return n__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref() } }
func A_arbace_classes_types_desc__GT_internal_A_New() *A_arbace_classes_types_desc__GT_internal_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_internal_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Ctor() {}
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Invoke_O_O__O(self, d__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__0, Lit_6)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_17; return tmp1.Invoke_O_O_O__O(d__0, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(d__0)))).Ref()) } else { return d__0
	} }
func A_arbace_classes_types_elem_type_A_New() *A_arbace_classes_types_elem_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_elem_type_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(d__0, A_arbace_classes_types_A_const_17) }
func A_arbace_classes_types_array_of_A_New() *A_arbace_classes_types_array_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_of_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Invoke_O_O__O(self, d__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__0)).Ref() }
func A_arbace_classes_types_array_dims_A_New() *A_arbace_classes_types_array_dims_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_18.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_array_dims_fn__48000030_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_types_array_dims_fn__48000030_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_types_array_dims_fn__48000030_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), d__0))).Ref() }
//line :48:1
func A_arbace_classes_types_array_dims_fn__48000030_A_New() *A_arbace_classes_types_array_dims_fn__48000030_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_fn__48000030_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Invoke_O_O__O(self, p1__48000029_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_19, p1__48000029_SHARP___1)).Ref() }

func A_arbace_classes_types_size_A_New() *A_arbace_classes_types_size_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_size_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_classes_types_size_A) Ctor() {}
//line :50:1
func (t *A_arbace_classes_types_size_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_46); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_47) }; if tmp1 { return A_arbace_classes_types_A_const_20 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8) { return A_arbace_classes_types_A_const_21 } else { return A_arbace_classes_types_A_const_17 } } }

func A_arbace_classes_types_int_like_QMARK__A_New() *A_arbace_classes_types_int_like_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_int_like_QMARK__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_23, t__0) }
func A_arbace_classes_types_numeric_QMARK__A_New() *A_arbace_classes_types_numeric_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_24, t__0) }




func A_arbace_classes_types_fn__48000037_A_New() *A_arbace_classes_types_fn__48000037_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000037_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Ctor() {}
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Invoke_O_O__O(self, p__48000036__0 any) any { var vec__48000038__2 any = p__48000036__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_classes_types_A_const_25.GetRawRoot__O()).Invoke_O__O(v__4), k__3) }

func A_arbace_classes_types_method_desc_A_New() *A_arbace_classes_types_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_method_desc_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Invoke_O_O_O__O(self, params__0, ret__1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_27.GetRawRoot__O(), params__0), nil, ret__1)).Ref() }






func A_arbace_classes_types_parse_method_desc_A_New() *A_arbace_classes_types_parse_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Ctor() {}
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Invoke_O_O__O(self, d__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Get_O__O(d__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var tmp1 any = A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class
		if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; r__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()





		jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Put_O_O__O(d__0, r__3)
//line :70:1
		return r__3 } }
func A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(p0 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Invoke_O__O(self any) any { { var i__1 any = lang.RT_Box_J__Number_NoInit(1); var ps__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_29)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()); var tmp3 any = t.F_d; var tmp4 jrt.Number_I; var na_7 any = i__1
													if jrt.Long_InstanceOf(na_7) { var n0_8 int64 = jrt.NN(jrt.Long_Cast(na_7)).LongValue__J(); if n0_8 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_7) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_8 + 1)) } } else { if jrt.Double_InstanceOf(na_7) { var n0_8_2 float64 = jrt.NN(jrt.Double_Cast(na_7)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_8_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_7) } }
//line :72:1
		return lang.Tuple_Create_O_O__IPersistentVector(ps__2, tmp2.Invoke_O_O__O(tmp3, tmp4)) } else { var j__3 any; var tmp5 any = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(t.F_d, i__1); var tmp6 *jrt.Class
			var fncls__4 /*line :72:1*/*jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class

			if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class = fncls__4d; tmp6 = fncls__4d } else { tmp6 = fncls__4 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :72:1
			var end__4 any; var tmp7 *jrt.String = jrt.String_Cast(t.F_d)


			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_30)).CharValue__C(), jrt.NN(tmp7).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__3))) { var tmp8 *jrt.String = jrt.String_Cast(t.F_d); end__4 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(tmp8).IndexOf_String_I__I(Lit_7, lang.RT_IntCast_O__I_NoInit(j__3))))).Ref() } else { var na_5 any = j__3; if jrt.Long_InstanceOf(na_5) { var n0_6 int64 = jrt.NN(jrt.Long_Cast(na_5)).LongValue__J(); if n0_6 == 9223372036854775807 { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_5) } else { end__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_6 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_5) { var n0_6_2 float64 = jrt.NN(jrt.Double_Cast(na_5)).DoubleValue__D(); end__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_6_2 + 1.0).Ref() } else { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_5) } } }
			i__1, ps__2 = end__4, lang.IFn_Cast(A_arbace_classes_types_A_const_6.GetRawRoot__O()).Invoke_O_O__O(ps__2, lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(t.F_d, i__1, end__4)); continue L1 } } }; /*line :71:1*/panic("j2g: unreachable") }


func A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(p0, p1 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_19)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) { var tmp2 jrt.Number_I; var na_2 any = j__1; if jrt.Long_InstanceOf(na_2) { var n0_3 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); if n0_3 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_2) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_3 + 1)) } } else { if jrt.Double_InstanceOf(na_2) { var n0_3_2 float64 = jrt.NN(jrt.Double_Cast(na_2)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_3_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_2) } }; j__1 = tmp2; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_package_of_A_New() *A_arbace_classes_types_package_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_package_of_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Invoke_O_O__O(self, internal__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5); if
											lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_9 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_21; return tmp1.Invoke_O_O_O__O(internal__0, tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref()) } }

func A_arbace_classes_types_simple_name_of_A_New() *A_arbace_classes_types_simple_name_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_simple_name_of_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Ctor() {}
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Invoke_O_O__O(self, internal__0 any) any { var n__2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(internal__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5)))).Ref()); return /*line :85:1*/ lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(n__2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(n__2)).LastIndexOf_String__I(Lit_11)))).Ref()) }

func A_arbace_classes_types_desc__GT_class_name_A_New() *A_arbace_classes_types_desc__GT_class_name_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_class_name_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Ctor() {}
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Invoke_O_O__O(self, d__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(d__0)) { return lang.IFn_Cast(A_arbace_classes_types_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(d__0, Lit_5, Lit_4) } else { if A_arbace_classes_types_A_const_32 != nil {
		return lang.IFn_Cast(A_arbace_classes_types_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_33.GetRawRoot__O()).Invoke_O__O(d__0), Lit_5, Lit_4) } else {
//line :90:1
			return nil
		}
	} }
func A_arbace_classes_types_class__GT_desc_A_New() *A_arbace_classes_types_class__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class__GT_desc_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Ctor() {}
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.NN(jrt.Class_Cast(c__0)).IsPrimitive__Z() { return lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref())) } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {
		return lang.IFn_Cast(A_arbace_classes_types_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_4, Lit_5) } else {
//line :94:1
			if A_arbace_classes_types_A_const_32 != nil {

				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_4, Lit_5), nil)).Ref() } else {
//line :94:1
					return nil
				}
		}
	}
}











func A_arbace_classes_types_array_sym_QMARK__A_New() *A_arbace_classes_types_array_sym_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_sym_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(s__0); if
											jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_37.GetRawRoot__O()).Invoke_O__O(s__0); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_39; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(s__0)) } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_classes_types_with_anns_A_New() *A_arbace_classes_types_with_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Ctor() {}
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Invoke_O_O_O__O(self, tn__0, form__1 any) any { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__1); var anns__4 any; if

	jrt.J2g_Truth(m__3) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()); var tmp2 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_43.GetRawRoot__O()); var tmp4 any = A_arbace_classes_types_with_anns_fn__48000056_A_New(); var tmp5 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_types_with_anns_fn__48000056_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_classes_types_with_anns_fn__48000056_A_fn_class = fncls__10d; tmp5 = fncls__10d } else { tmp5 = fncls__10 }; anns__4 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), m__3)) } else { anns__4 = nil }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(anns__4)) { return lang.IFn_Cast(A_arbace_classes_types_A_const_42.GetRawRoot__O()).Invoke_O_O_O__O(tn__0, A_arbace_classes_types_A_const_44, anns__4) } else { return tn__0 } }
//line :117:1
func A_arbace_classes_types_with_anns_fn__48000056_A_New() *A_arbace_classes_types_with_anns_fn__48000056_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_fn__48000056_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Ctor() {}
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Invoke_O_O__O(self, p__48000055__1 any) any { var vec__48000057__2 any = p__48000055__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(k__3) }


func A_arbace_classes_types_parse_type_A_New() *A_arbace_classes_types_parse_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Ctor() {}
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Invoke_O_O_O__O(self, scope__0, form__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_45.GetRawRoot__O()); var tmp2 any; var tmp3 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(form__1)

	if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_classes_types_A_const_37.GetRawRoot__O()).Invoke_O__O(form__1), nil)).Ref() } else { tmp3 = and__1927000168__auto____4 } } else { tmp3 = and__1927000168__auto____3 }
//line :125:1
	if jrt.J2g_Truth(tmp3) { var tmp4 any = A_arbace_classes_types_A_const_46; var tmp5 any = A_arbace_classes_types_A_const_47; var tmp6 any = A_arbace_classes_types_A_const_48; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1))) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_49.GetRawRoot__O()).Invoke_O__O(form__1)) { var base__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_37.GetRawRoot__O()).Invoke_O__O(form__1)); var n__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(form__1)); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_51.GetRawRoot__O()); var tmp8 any = A_arbace_classes_types_parse_type_fn__48000065_A_New(); var tmp9 *jrt.Class
		var fncls__12 /*line :125:1*/*jrt.Class = A_arbace_classes_types_parse_type_fn__48000065_A_fn_class






		if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_classes_types_parse_type_fn__48000065_A_fn_class = fncls__12d; tmp9 = fncls__12d } else { tmp9 = fncls__12 }; tmp2 = lang.RT_Nth_O_I__O_NoInit(tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(scope__0, base__3)), lang.RT_IntCast_O__I_NoInit(n__4)) } else {
//line :125:1
			var tmp10 any; var and__1927000168__auto____3_2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(form__1)








			if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp10 = lang.IFn_Cast(A_arbace_classes_types_A_const_52.GetRawRoot__O()).Invoke_O__O(form__1) } else { tmp10 = and__1927000168__auto____3_2 }
//line :125:1
			if jrt.J2g_Truth(tmp10) { var d__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_52.GetRawRoot__O()).Invoke_O__O(form__1)










				if lang.Util_Equiv_O_O__Z_NoInit(d__3, Lit_17) { var tmp11 any = A_arbace_classes_types_A_const_46; var tmp12 any = A_arbace_classes_types_A_const_53; var tmp13 any = A_arbace_classes_types_A_const_54; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_55, A_arbace_classes_types_A_const_56, Lit_18, A_arbace_classes_types_A_const_57, lang.PersistentVector_EMPTY.Ref())))) } else { var tmp14 any = A_arbace_classes_types_A_const_46; var tmp15 any = A_arbace_classes_types_A_const_53; var tmp16 any = A_arbace_classes_types_A_const_54; var tmp17 any = A_arbace_classes_types_A_const_46; var tmp18 any = A_arbace_classes_types_A_const_47; var tmp19 any = A_arbace_classes_types_A_const_48; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(d__3, A_arbace_classes_types_A_const_17))))) } } else {
//line :125:1
					if lang.Util_Equiv_O_O__Z_NoInit(form__1, A_arbace_classes_types_A_const_58) { tmp2 = A_arbace_classes_types_A_const_59 } else { var tmp20 any; var and__1927000168__auto____3_3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(form__1)
















						if jrt.J2g_Truth(and__1927000168__auto____3_3) { tmp20 = lang.IFn_Cast(A_arbace_classes_types_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_82.Invoke_O__O(scope__0), form__1) } else { tmp20 = and__1927000168__auto____3_3 }
//line :125:1
						if jrt.J2g_Truth(tmp20) { tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_60, A_arbace_classes_types_A_const_61, form__1)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(form__1)) { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_62.Invoke_O__O(scope__0)).Invoke_O__O(form__1)




















							if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4_2 any = temp__1927000408__auto____3; var o__5 any; var temp__1927000414__auto____5 any = A_arbace_classes_types_A_const_63.Invoke_O__O(scope__0)
								if jrt.J2g_Truth(temp__1927000414__auto____5) { var f__6 any = temp__1927000414__auto____5; o__5 = lang.IFn_Cast(f__6).Invoke_O__O(n__4_2) } else { o__5 = nil }
//line :146:1
								var G__48000067__6_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_55, A_arbace_classes_types_A_const_56, n__4_2, A_arbace_classes_types_A_const_57, lang.PersistentVector_EMPTY.Ref()))

								if jrt.J2g_Truth(o__5) { tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_42.GetRawRoot__O()).Invoke_O_O_O__O(G__48000067__6_, A_arbace_classes_types_A_const_83, o__5) } else { tmp2 = G__48000067__6_ } } else {
//line :146:1
									panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_84, form__1)))))) } } else {
//line :125:1
										if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(form__1)) { var d__3_2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(form__1, Lit_4, Lit_5)



























											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__3_2, Lit_1)) { var body_p__4 *A_arbace_classes_types_parse_type_p__48000068_A = A_arbace_classes_types_parse_type_p__48000068_A_New(); var p__4 any; var tmp21 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_types_parse_type_p__48000068_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_types_parse_type_p__48000068_A_fn_class = fncls__11d; tmp21 = fncls__11d } else { tmp21 = fncls__11 }; p__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_p__4), tmp21, nil)



												tmp2 = lang.IFn_Cast(p__4).Invoke_O__O(d__3_2) } else {
													tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(form__1)) } } else {
//line :125:1
														if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_66.GetRawRoot__O()).Invoke_O__O(form__1)) { var d__3_3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(form__1); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()); var tmp23 any



































															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_85.GetRawRoot__O()).Invoke_O__O(d__3_3)) { tmp23 = lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_87.GetRawRoot__O()).Invoke_O__O(d__3_3)) } else {
																if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(d__3_3)) { tmp23 = lang.IFn_Cast(A_arbace_classes_types_A_const_86.GetRawRoot__O()).Invoke_O__O(d__3_3) } else { tmp23 = lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(form__1)).GetName__String().Ref()) } }
//line :161:1
															tmp2 = tmp22.Invoke_O_O__O(scope__0, tmp23) } else {
//line :125:1
																var tmp24 any; var and__1927000168__auto____3_4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_68.GetRawRoot__O()).Invoke_O__O(form__1)






































																if jrt.J2g_Truth(and__1927000168__auto____3_4) { var tmp25 any = A_arbace_classes_types_A_const_69; tmp24 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp25, lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp24 = and__1927000168__auto____3_4 }
//line :125:1
																if jrt.J2g_Truth(tmp24) { var tmp26 any = A_arbace_classes_types_A_const_46; var tmp27 any = A_arbace_classes_types_A_const_53; var tmp28 any = A_arbace_classes_types_A_const_54; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp27, tmp28, lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_88.GetRawRoot__O()).Invoke_O__O(form__1)))) } else { var tmp29 any; var and__1927000168__auto____3_5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_68.GetRawRoot__O()).Invoke_O__O(form__1)









































																	if jrt.J2g_Truth(and__1927000168__auto____3_5) { var tmp30 any = A_arbace_classes_types_A_const_71; tmp29 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp30, lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp29 = and__1927000168__auto____3_5 }
//line :125:1
																	if jrt.J2g_Truth(tmp29) { var vec__48000070__3 any = form__1; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(1), nil); var b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp31 any = A_arbace_classes_types_A_const_46; var tmp32 any = A_arbace_classes_types_A_const_72; var tmp33 any = A_arbace_classes_types_A_const_73; var tmp34 any = lang.IFn_Cast(A_arbace_classes_types_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(k__5)); var tmp35 any = A_arbace_classes_types_A_const_75; _ = ___4; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32, tmp33, tmp34, tmp35, lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(scope__0, b__6))) } else { var tmp36 any; var and__1927000168__auto____3_6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_68.GetRawRoot__O()).Invoke_O__O(form__1)













































																		if jrt.J2g_Truth(and__1927000168__auto____3_6) { var tmp37 any = A_arbace_classes_types_A_const_76; tmp36 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp37, lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp36 = and__1927000168__auto____3_6 }
//line :125:1
																		if jrt.J2g_Truth(tmp36) { var tmp38 any = A_arbace_classes_types_A_const_46; var tmp39 any = A_arbace_classes_types_A_const_77; var tmp40 any = A_arbace_classes_types_A_const_78; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()); var tmp42 any = A_arbace_classes_types_parse_type_fn__48000073_A_New_O(scope__0); var tmp43 *jrt.Class
																			var fncls__13 /*line :125:1*/*jrt.Class = A_arbace_classes_types_parse_type_fn__48000073_A_fn_class














































																			if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_types_parse_type_fn__48000073_A_fn_class = fncls__13d; tmp43 = fncls__13d } else { tmp43 = fncls__13 }
//line :125:1
																			tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp38, tmp39, tmp40, tmp41.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(form__1)))) } else { var tmp44 any; var and__1927000168__auto____3_7 any = lang.IFn_Cast(A_arbace_classes_types_A_const_68.GetRawRoot__O()).Invoke_O__O(form__1)
















































																				if jrt.J2g_Truth(and__1927000168__auto____3_7) { var tmp45 any = A_arbace_classes_types_A_const_80; tmp44 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp45, lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp44 = and__1927000168__auto____3_7 }
//line :125:1
																				if jrt.J2g_Truth(tmp44) {

















































																					var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_81.GetRawRoot__O()); var tmp47 any = A_arbace_classes_types_parse_type_fn__48000075_A_New_O(scope__0); var tmp48 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_types_parse_type_fn__48000075_A_fn_class = fncls__15d; tmp48 = fncls__15d } else { tmp48 = fncls__15 }; tmp2 = tmp46.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_88.GetRawRoot__O()).Invoke_O__O(form__1)), lang.IFn_Cast(A_arbace_classes_types_A_const_91.GetRawRoot__O()).Invoke_O__O(form__1)) } else {
//line :125:1
																						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_68.GetRawRoot__O()).Invoke_O__O(form__1)) { var c__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(form__1))
																							var tmp49 any = A_arbace_classes_types_A_const_55

























































																							if lang.Util_Equiv_O_O__Z_NoInit(tmp49, A_arbace_classes_types_A_const_46.Invoke_O__O(c__3)) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(), lang.PersistentArrayMap_EMPTY.Ref())))) }
																							var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_42.GetRawRoot__O()); var tmp51 any = A_arbace_classes_types_A_const_57; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()); var tmp53 any = A_arbace_classes_types_parse_type_fn__48000082_A_New_O(scope__0); var tmp54 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000082_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_types_parse_type_fn__48000082_A_fn_class = fncls__16d; tmp54 = fncls__16d } else { tmp54 = fncls__16 }; tmp2 = tmp50.Invoke_O_O_O__O(c__3, tmp51, tmp52.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(form__1))) } else {
//line :125:1
																								if A_arbace_classes_types_A_const_32 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_92.GetRawRoot__O()).Invoke_O__O(form__1))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_84, form__1)))))) } else { tmp2 = nil } } } } } } } } } } } } } }
//line :124:1
	return tmp1.Invoke_O_O__O(tmp2, form__1)
}






func A_arbace_classes_types_parse_type_fn__48000065_A_New() *A_arbace_classes_types_parse_type_fn__48000065_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000065_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Ctor() {}
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Invoke_O_O__O(self, e__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_53, A_arbace_classes_types_A_const_54, e__1)) }





















func A_arbace_classes_types_parse_type_p__48000068_A_New() *A_arbace_classes_types_parse_type_p__48000068_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_p__48000068_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Ctor() {}
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Invoke_O_O__O(self, d__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__1, Lit_1)) { var tmp1 any = A_arbace_classes_types_A_const_46; var tmp2 any = A_arbace_classes_types_A_const_53; var tmp3 any = A_arbace_classes_types_A_const_54; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.IFn_Cast(self).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(d__1, A_arbace_classes_types_A_const_17)))) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__1, Lit_6)) { var tmp4 any = A_arbace_classes_types_A_const_46; var tmp5 any = A_arbace_classes_types_A_const_55; var tmp6 any = A_arbace_classes_types_A_const_56; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_classes_types_A_const_33.GetRawRoot__O()).Invoke_O__O(d__1), A_arbace_classes_types_A_const_57, lang.PersistentVector_EMPTY.Ref())) } else { if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__1)) } else { return nil } } } }

















func A_arbace_classes_types_parse_type_fn__48000073_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Invoke_O_O__O(self, p1__48000062_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000062_SHARP___1) }


func A_arbace_classes_types_parse_type_fn__48000075_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_A{}; t.Ctor_O(p0); return t }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Invoke_O_O_O__O(self, outer__1, f__2 any) any { var vec__48000076__3 any; if
														jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_68.GetRawRoot__O()).Invoke_O__O(f__2)) { vec__48000076__3 = f__2 } else { vec__48000076__3 = lang.Tuple_Create_O__IPersistentVector(f__2) }; var seq__48000077__4 any = /*line :175:1*/lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(vec__48000076__3); var first__48000078__5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__48000077__4); var seq__48000077__6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_90.GetRawRoot__O()).Invoke_O__O(seq__48000077__4); var c__7 any = first__48000078__5; var args__8 any = seq__48000077__6; var n__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_56.Invoke_O__O(outer__1), nil, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(c__7))).Ref(); var tmp1 any = A_arbace_classes_types_A_const_46; var tmp2 any = A_arbace_classes_types_A_const_55; var tmp3 any = A_arbace_classes_types_A_const_56; var tmp4 any = A_arbace_classes_types_A_const_57; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(t.F_scope); var tmp7 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class; if


	fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class = fncls__14d; tmp7 = fncls__14d } else { tmp7 = fncls__14 }; return /*line :175:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, n__9, tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), args__8), A_arbace_classes_types_A_const_83, outer__1)) }


func A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Invoke_O_O__O(self, p1__48000063_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000063_SHARP___1) }






func A_arbace_classes_types_parse_type_fn__48000082_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000082_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000082_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Invoke_O_O__O(self, p1__48000064_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000064_SHARP___1) }




func A_arbace_classes_types_erase_A_New() *A_arbace_classes_types_erase_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_erase_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_classes_types_erase_A) Ctor() {}
//line :190:1
func (t *A_arbace_classes_types_erase_A) Invoke_O_O_O__O(self, bounds__0, tn__1 any) any { var G__48000085__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000085__3_) >> 9 & 7 { case 0: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_72) {





		var tmp1 any = A_arbace_classes_types_A_const_93; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_73.Invoke_O__O(tn__1)) { return lang.IFn_Cast(A_arbace_classes_types_A_const_94.GetRawRoot__O()).Invoke_O_O__O(bounds__0, A_arbace_classes_types_A_const_75.Invoke_O__O(tn__1)) } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	case 1: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__1) }
//line :193:1
	case 2: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_55) {

		return lang.IFn_Cast(A_arbace_classes_types_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_56.Invoke_O__O(tn__1)) }
//line :193:1
	case 3: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_77) {




		return lang.IFn_Cast(A_arbace_classes_types_A_const_94.GetRawRoot__O()).Invoke_O_O__O(bounds__0, lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_78.Invoke_O__O(tn__1))) }
//line :193:1
	case 4: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_53) {


		return lang.IFn_Cast(A_arbace_classes_types_A_const_96.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_94.GetRawRoot__O()).Invoke_O_O__O(bounds__0, A_arbace_classes_types_A_const_54.Invoke_O__O(tn__1))) }
//line :193:1
	case 7: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_60) { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(bounds__0, A_arbace_classes_types_A_const_61.Invoke_O__O(tn__1)))



		if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; return lang.IFn_Cast(A_arbace_classes_types_A_const_94.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_97.GetRawRoot__O()).Invoke_O_O__O(bounds__0, A_arbace_classes_types_A_const_61.Invoke_O__O(tn__1)), b__5) } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000085__3_))))) }







func A_arbace_classes_types_generic_QMARK__A_New() *A_arbace_classes_types_generic_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_generic_QMARK__A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Ctor() {}
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Invoke_O_O__O(self, tn__0 any) any { var G__48000087__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000087__2_) >> 9 & 7 { case 0: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_72) { return jrt.Boolean_TRUE.Ref() }; case 1: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_47) { return jrt.Boolean_FALSE.Ref() }; case 2: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_55) { var or__1927000174__auto____3 bool = lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0)))

		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var and__1927000168__auto____4 any = A_arbace_classes_types_A_const_83.Invoke_O__O(tn__0); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_classes_types_A_const_98.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_83.Invoke_O__O(tn__0)) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :204:1
	case 3: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_77) { return jrt.Boolean_TRUE.Ref() }; case 4: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_53) {


		return lang.IFn_Cast(A_arbace_classes_types_A_const_98.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_54.Invoke_O__O(tn__0)) }
//line :204:1
	case 7: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_60) { return jrt.Boolean_TRUE.Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000087__2_))))) }







func A_arbace_classes_types_local_class_name_QMARK__A_New() *A_arbace_classes_types_local_class_name_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_local_class_name_QMARK__A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Ctor() {}
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Invoke_O_O_O__O(self, n__0, outer__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = outer__1; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(n__0, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, outer__1, nil)).Ref()); if jrt.J2g_Truth(and__1927000168__auto____4) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_38.GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_A_const_99; tmp1 = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(n__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(outer__1)))).Ref())) } else {
//line :216:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_types_signature_A_New() *A_arbace_classes_types_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_signature_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_classes_types_signature_A) Ctor() {}
//line :219:1
func (t *A_arbace_classes_types_signature_A) Invoke_O_O__O(self, tn__0 any) any { var G__48000090__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000090__2_) >> 9 & 7 { case 0: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_72) { var G__48000091__3_ any = A_arbace_classes_types_A_const_73.Invoke_O__O(tn__0)









		switch lang.Util_Hash_O__I_NoInit(G__48000091__3_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, nil) { return Lit_40 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_100) {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_75.Invoke_O__O(tn__0)))).Ref() }
//line :232:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_93) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_75.Invoke_O__O(tn__0)))).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000091__3_))))) }
//line :222:1
	case 1: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__0) }
//line :222:1
	case 2: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_55) { var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_102.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_103.GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0); var tmp4 any; var G__48000092__3_ any = A_arbace_classes_types_A_const_83.Invoke_O__O(tn__0)

		if lang.Util_Identical_O_O__Z_NoInit(G__48000092__3_, nil) { tmp4 = nil } else { tmp4 = A_arbace_classes_types_A_const_56.Invoke_O__O(G__48000092__3_) }; and__1927000168__auto____3 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4)); if jrt.J2g_Truth(and__1927000168__auto____3) { temp__1927000408__auto____3 = A_arbace_classes_types_A_const_83.Invoke_O__O(tn__0) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var o__4 any = temp__1927000408__auto____3; var os__5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(o__4); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_4, nil, nil, Lit_7); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()); var tmp7 any = A_arbace_classes_types_A_const_21; var tmp8 any = tmp6.Invoke_O_O_O__O(os__5, tmp7, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(os__5)))).Ref()); var tmp9 any = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_classes_types_A_const_56.Invoke_O__O(o__4))))).Ref()); var tmp10 *jrt.String


			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0))) { tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_27.GetRawRoot__O(), lang.IFn_Cast(A_arbace_classes_types_A_const_104.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_101.GetRawRoot__O(), A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0))), nil)) } else { tmp10 = nil }
//line :226:1
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, tmp10.Ref(), nil)).Ref() } else {

				var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, nil, Lit_7); var tmp12 any = A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0); var tmp13 *jrt.String
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0))) { tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_27.GetRawRoot__O(), lang.IFn_Cast(A_arbace_classes_types_A_const_104.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_101.GetRawRoot__O(), A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0))), nil)) } else { tmp13 = nil }
//line :228:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13.Ref(), nil)).Ref() } }
//line :222:1
	case 3: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_77) {











		return lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_78.Invoke_O__O(tn__0))) }
//line :222:1
	case 4: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_53) {







		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_54.Invoke_O__O(tn__0)))).Ref() }
//line :222:1
	case 7: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_60) {








		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_61.Invoke_O__O(tn__0)), nil)).Ref() }
//line :222:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000090__2_))))) }













func A_arbace_classes_types_parse_type_params_A_New() *A_arbace_classes_types_parse_type_params_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Ctor() {}
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Invoke_O_O_O__O(self, scope__0, tps__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(scope__0); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tps__1) }
//line :241:1
func A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Invoke_O_O__O(self, tp__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(tp__1)) { var tmp1 any = A_arbace_classes_types_A_const_61; var tmp2 any = A_arbace_classes_types_A_const_105; var tmp3 any = lang.PersistentVector_EMPTY.Ref(); var tmp4 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tp__1, tmp2, tmp3, tmp4, lang.RT_Meta_O__IPersistentMap_NoInit(tp__1))) } else { var vec__48000096__2 any = tp__1; var seq__48000097__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(vec__48000096__2); var first__48000098__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__48000097__3); var seq__48000097__5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_90.GetRawRoot__O()).Invoke_O__O(seq__48000097__3); var s__6 any = first__48000098__4; var first__48000098__7 any = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__48000097__5); var seq__48000097__8 any = lang.IFn_Cast(A_arbace_classes_types_A_const_90.GetRawRoot__O()).Invoke_O__O(seq__48000097__5)
		var kw__9 any = first__48000098__7
		var bs__10 any = seq__48000097__8
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_106, kw__9) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, tp__1)).Ref(), lang.PersistentArrayMap_EMPTY.Ref())))) }
//line :242:1
		var tmp5 any = A_arbace_classes_types_A_const_61; var tmp6 any = A_arbace_classes_types_A_const_105; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(t.F_scope); var tmp9 *jrt.Class
		var fncls__21 /*line :242:1*/*jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class



		if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class = fncls__21d; tmp9 = fncls__21d } else { tmp9 = fncls__21 }
//line :242:1
		var tmp10 any = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), bs__10); var tmp11 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, s__6, tmp6, tmp10, tmp11, lang.RT_Meta_O__IPersistentMap_NoInit(s__6)))
	}
}

func A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Invoke_O_O__O(self, p1__48000094_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000094_SHARP___1) }


func A_arbace_classes_types_type_params_signature_A_New() *A_arbace_classes_types_type_params_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Ctor() {}
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Invoke_O_O_O__O(self, interface_QMARK___0, tps__1 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_107.GetRawRoot__O()).Invoke_O__O(tps__1)) { return Lit_9 } else {

		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var tmp4 any; var iter__1927001039__auto____6 any; var tmp5 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(interface_QMARK___0); var tmp6 *jrt.Class
		var fncls__31 /*line :255:1*/*jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class

		if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class = fncls__31d; tmp6 = fncls__31d } else { tmp6 = fncls__31 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(tps__1)
//line :255:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2.Invoke_O_O__O(tmp3, tmp4), nil)).Ref()
	} }
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Invoke_O_O__O(self, s__48000104__1 any) any { var tmp1 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(self, t.F_interface_QMARK_, s__48000104__1); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Ctor_O_O_O(c__iter__48000103, c__interface_QMARK_, c__s__48000104 any) { t.F_iter__48000103 = c__iter__48000103; t.F_interface_QMARK_ = c__interface_QMARK_; t.F_s__48000104 = c__s__48000104 }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Invoke_O__O(self any) any { { var s__48000104__1 any; var t_ any = t.F_s__48000104; t.F_s__48000104 = nil; s__48000104__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(s__48000104__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__48000104__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_108.GetRawRoot__O()).Invoke_O__O(s__48000104__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_109.GetRawRoot__O()).Invoke_O__O(s__48000104__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__48000106__6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_110.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(t.F_interface_QMARK_, b__48000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); return lang.IFn_Cast(A_arbace_classes_types_A_const_114.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_116.GetRawRoot__O()).Invoke_O__O(b__48000106__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_117.GetRawRoot__O()).Invoke_O__O(s__48000104__3))) } else { return lang.IFn_Cast(A_arbace_classes_types_A_const_114.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_116.GetRawRoot__O()).Invoke_O__O(b__48000106__6), nil) } } else { var map__48000115__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(s__48000104__3); var map__48000115__5 any; if lang.ISeq_InstanceOf(map__48000115__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_90.GetRawRoot__O()).Invoke_O__O(map__48000115__4)) { map__48000115__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_types_A_const_111.GetRawRoot__O()).Invoke_O__O(map__48000115__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(map__48000115__4)) { map__48000115__5 = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(map__48000115__4) } else { map__48000115__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000115__5 = map__48000115__4 }; var sym__6 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_61); var bounds__7 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_105); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_115.GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(sym__6); var tmp7 any

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_107.GetRawRoot__O()).Invoke_O__O(bounds__7)) { tmp7 = Lit_58 } else {

		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp9 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_113.GetRawRoot__O()); var tmp11 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(t.F_interface_QMARK_); var tmp12 *jrt.Class
		var fncls__29 /*line :261:1*/*jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class

		if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class = fncls__29d; tmp12 = fncls__29d } else { tmp12 = fncls__29 }
//line :261:1
		tmp7 = tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), bounds__7)) }
//line :257:1
	var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); return tmp4.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)).Ref(), tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(s__48000104__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Ctor_O_O_I_O(c__interface_QMARK_, c__b__48000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_interface_QMARK_ = c__interface_QMARK_; t.F_b__48000106 = c__b__48000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Invoke_O__O(self any) any { { var i__48000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__48000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__48000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__48000105__1)); var map__48000110__3 any; if lang.ISeq_InstanceOf(map__48000110__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_90.GetRawRoot__O()).Invoke_O__O(map__48000110__2)) { map__48000110__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_types_A_const_111.GetRawRoot__O()).Invoke_O__O(map__48000110__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(map__48000110__2)) { map__48000110__3 = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(map__48000110__2) } else { map__48000110__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000110__3 = map__48000110__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_61); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_105); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_112.GetRawRoot__O()); var tmp3 any = t.F_b__48000106; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(sym__4); var tmp6 any

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_107.GetRawRoot__O()).Invoke_O__O(bounds__5)) { tmp6 = Lit_58 } else {

		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp8 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_113.GetRawRoot__O()); var tmp10 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(t.F_interface_QMARK_); var tmp11 *jrt.Class
		var fncls__25 /*line :261:1*/*jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class

		if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class = fncls__25d; tmp11 = fncls__25d } else { tmp11 = fncls__25 }
//line :261:1
		tmp6 = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), bounds__5)) }
//line :257:1
	tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6)).Ref()); i__48000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__48000105__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var na_23 any = i__1; if jrt.Long_InstanceOf(na_23) { var n0_24 int64 = jrt.NN(jrt.Long_Cast(na_23)).LongValue__J(); and__1927000168__auto____3 = n0_24 == 0 } else { if jrt.Double_InstanceOf(na_23) { var n0_24_2 float64 = jrt.NN(jrt.Double_Cast(na_23)).DoubleValue__D(); and__1927000168__auto____3 = n0_24_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_23) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_55; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_56.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } }
//line :263:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var na_27 any = i__1; if jrt.Long_InstanceOf(na_27) { var n0_28 int64 = jrt.NN(jrt.Long_Cast(na_27)).LongValue__J(); and__1927000168__auto____3 = n0_28 == 0 } else { if jrt.Double_InstanceOf(na_27) { var n0_28_2 float64 = jrt.NN(jrt.Double_Cast(na_27)).DoubleValue__D(); and__1927000168__auto____3 = n0_28_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_27) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_55; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_56.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()).Invoke_O__O(b__2))).Ref()
		}
}

func A_arbace_classes_types_bounds_map_A_New() *A_arbace_classes_types_bounds_map_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Invoke_O_O__O(self, tps__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()); var tmp2 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_104.GetRawRoot__O()); var tmp4 any = A_arbace_classes_types_bounds_map_fn__48000123_A_New(); var tmp5 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class = fncls__32d; tmp5 = fncls__32d } else { tmp5 = fncls__32 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), tps__0)) }
//line :270:1
func A_arbace_classes_types_bounds_map_fn__48000123_A_New() *A_arbace_classes_types_bounds_map_fn__48000123_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_fn__48000123_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Invoke_O_O__O(self, p__48000122__1 any) any { var map__48000124__2 any = p__48000122__1; var map__48000124__3 any; if lang.ISeq_InstanceOf(map__48000124__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_90.GetRawRoot__O()).Invoke_O__O(map__48000124__2)) { map__48000124__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_types_A_const_111.GetRawRoot__O()).Invoke_O__O(map__48000124__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(map__48000124__2)) { map__48000124__3 = lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(map__48000124__2) } else { map__48000124__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000124__3 = map__48000124__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_61); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_105); return lang.Tuple_Create_O_O__IPersistentVector(sym__4, bounds__5) }

func A_arbace_classes_types_desc__GT_tnode_A_New() *A_arbace_classes_types_desc__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_tnode_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Invoke_O_O__O(self, d__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_85.GetRawRoot__O()).Invoke_O__O(d__0)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(d__0)) { var tmp1 any = A_arbace_classes_types_A_const_46; var tmp2 any = A_arbace_classes_types_A_const_53; var tmp3 any = A_arbace_classes_types_A_const_54; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.IFn_Cast(A_arbace_classes_types_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_119.GetRawRoot__O()).Invoke_O__O(d__0)))) } else { if A_arbace_classes_types_A_const_32 != nil { var tmp4 any = A_arbace_classes_types_A_const_46; var tmp5 any = A_arbace_classes_types_A_const_55; var tmp6 any = A_arbace_classes_types_A_const_56; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_classes_types_A_const_33.GetRawRoot__O()).Invoke_O__O(d__0), A_arbace_classes_types_A_const_57, lang.PersistentVector_EMPTY.Ref())) } else { return nil
	}
	}
	}
	} }
func A_arbace_classes_types_reflect__GT_tnode_A_New() *A_arbace_classes_types_reflect__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_reflect__GT_tnode_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Ctor() {}
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Invoke_O_O__O(self, ty__0 any) any {


	if jrt.Class_InstanceOf(ty__0) {
		return lang.IFn_Cast(A_arbace_classes_types_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(ty__0)) } else {
//line :281:1
			if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)).IsInstance_O__Z(ty__0) { var pt__2 any = ty__0; var tmp1 any = A_arbace_classes_types_A_const_46; var tmp2 any = A_arbace_classes_types_A_const_55; var tmp3 any = A_arbace_classes_types_A_const_56; var tmp4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_31, jrt.RefArrayOf(jrt.Object_class)))); var tmp5 any = A_arbace_classes_types_A_const_57; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_120.GetRawRoot__O(), lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_32, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)).IsInstance_O__Z(ty__0) { var tmp6 any = A_arbace_classes_types_A_const_46; var tmp7 any = A_arbace_classes_types_A_const_60; var tmp8 any = A_arbace_classes_types_A_const_61; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33), Lit_34, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35)).IsInstance_O__Z(ty__0) { var tmp9 any = A_arbace_classes_types_A_const_46; var tmp10 any = A_arbace_classes_types_A_const_53; var tmp11 any = A_arbace_classes_types_A_const_54; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, lang.IFn_Cast(A_arbace_classes_types_A_const_120.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35), Lit_36, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37)).IsInstance_O__Z(ty__0) { var w__2 any = ty__0; var lo__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_38, jrt.RefArrayOf(jrt.Object_class))); var up__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_39, jrt.RefArrayOf(jrt.Object_class)))












				if jrt.J2g_Truth(lo__3) { var tmp12 any = A_arbace_classes_types_A_const_46; var tmp13 any = A_arbace_classes_types_A_const_72; var tmp14 any = A_arbace_classes_types_A_const_73; var tmp15 any = A_arbace_classes_types_A_const_100; var tmp16 any = A_arbace_classes_types_A_const_75; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15, tmp16, lang.IFn_Cast(A_arbace_classes_types_A_const_120.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(lo__3)))) } else { var tmp17 any; var and__1927000168__auto____5 any = up__4
					if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_12.GetRawRoot__O()); var tmp19 any = A_arbace_classes_types_A_const_122; tmp17 = tmp18.Invoke_O_O__O(tmp19, lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(up__4)) } else { tmp17 = and__1927000168__auto____5 }
//line :294:1
					if jrt.J2g_Truth(tmp17) { var tmp20 any = A_arbace_classes_types_A_const_46; var tmp21 any = A_arbace_classes_types_A_const_72; var tmp22 any = A_arbace_classes_types_A_const_73; var tmp23 any = A_arbace_classes_types_A_const_93; var tmp24 any = A_arbace_classes_types_A_const_75; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21, tmp22, tmp23, tmp24, lang.IFn_Cast(A_arbace_classes_types_A_const_120.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_70.GetRawRoot__O()).Invoke_O__O(up__4)))) } else { if A_arbace_classes_types_A_const_32 != nil { return A_arbace_classes_types_A_const_121 } else { return nil } } } } else {
//line :281:1
						if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_55, A_arbace_classes_types_A_const_56, Lit_18, A_arbace_classes_types_A_const_57, lang.PersistentVector_EMPTY.Ref())) } else { return nil
						}
					}
			}
			}
			}
		}
}










func A_arbace_classes_types_subst_A_New() *A_arbace_classes_types_subst_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_classes_types_subst_A) Ctor() {}
//line :299:1
func (t *A_arbace_classes_types_subst_A) Invoke_O_O_O__O(self, env__0, tn__1 any) any { var G__48000135__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000135__3_) >> 9 & 7 { case 0: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_72) {




		if jrt.J2g_Truth(A_arbace_classes_types_A_const_75.Invoke_O__O(tn__1)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_75; var tmp3 any = A_arbace_classes_types_subst_fn__48000136_A_New_O(env__0); var tmp4 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_classes_types_subst_fn__48000136_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_types_subst_fn__48000136_A_fn_class = fncls__34d; tmp4 = fncls__34d } else { tmp4 = fncls__34 }; return tmp1.Invoke_O_O_O__O(tn__1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } else { return tn__1 } }
//line :302:1
	case 2: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_55) { var G__48000138__4_ any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_42.GetRawRoot__O()); var tmp6 any = A_arbace_classes_types_A_const_57; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_classes_types_subst_fn__48000139_A_New_O(env__0); var tmp9 *jrt.Class
		var fncls__35 /*line :302:1*/*jrt.Class = A_arbace_classes_types_subst_fn__48000139_A_fn_class

		if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_types_subst_fn__48000139_A_fn_class = fncls__35d; tmp9 = fncls__35d } else { tmp9 = fncls__35 }; G__48000138__4_ = tmp5.Invoke_O_O_O__O(tn__1, tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), A_arbace_classes_types_A_const_57.Invoke_O__O(tn__1))); if jrt.J2g_Truth(A_arbace_classes_types_A_const_83.Invoke_O__O(tn__1)) {
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()); var tmp11 any = A_arbace_classes_types_A_const_83; var tmp12 any = A_arbace_classes_types_subst_fn__48000141_A_New_O(env__0); var tmp13 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_classes_types_subst_fn__48000141_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_types_subst_fn__48000141_A_fn_class = fncls__36d; tmp13 = fncls__36d } else { tmp13 = fncls__36 }; return tmp10.Invoke_O_O_O__O(G__48000138__4_, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)) } else {
//line :304:1
				return G__48000138__4_ } }
//line :302:1
	case 3: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_77) {





		var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()); var tmp15 any = A_arbace_classes_types_A_const_78; var tmp16 any = A_arbace_classes_types_subst_fn__48000143_A_New_O(env__0); var tmp17 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_types_subst_fn__48000143_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_types_subst_fn__48000143_A_fn_class = fncls__37d; tmp17 = fncls__37d } else { tmp17 = fncls__37 }; return tmp14.Invoke_O_O_O__O(tn__1, tmp15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil)) }
//line :302:1
	case 4: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_53) {



		var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()); var tmp19 any = A_arbace_classes_types_A_const_54; var tmp20 any = A_arbace_classes_types_subst_fn__48000145_A_New_O(env__0); var tmp21 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_classes_types_subst_fn__48000145_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_classes_types_subst_fn__48000145_A_fn_class = fncls__38d; tmp21 = fncls__38d } else { tmp21 = fncls__38 }; return tmp18.Invoke_O_O_O__O(tn__1, tmp19, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil)) }
//line :302:1
	case 7: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_60) {
		return lang.RT_Get_O_O_O__O_NoInit(env__0, A_arbace_classes_types_A_const_61.Invoke_O__O(tn__1), tn__1) }
//line :302:1
	default:}; return tn__1 }

func A_arbace_classes_types_subst_fn__48000139_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000139_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000139_A{}; t.Ctor_O(p0); return t }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Invoke_O_O__O(self, p1__48000130_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000130_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000141_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000141_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000141_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Invoke_O_O__O(self, p1__48000131_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000131_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000145_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000145_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000145_A{}; t.Ctor_O(p0); return t }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Invoke_O_O__O(self, p1__48000132_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000132_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000136_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000136_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000136_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Invoke_O_O__O(self, p1__48000133_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000133_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000143_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000143_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000143_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Invoke_O_O__O(self, p1__48000134_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_125.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_124.GetRawRoot__O(), t.F_env), p1__48000134_SHARP___1) }


func A_arbace_classes_types_type_anns_A_New() *A_arbace_classes_types_type_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Ctor() {}
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Invoke_O_O__O(self, tn__0 any) any { var body_walk__2 *A_arbace_classes_types_type_anns_walk__48000148_A = A_arbace_classes_types_type_anns_walk__48000148_A_New(); var walk__2 any; var tmp1 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_types_type_anns_walk__48000148_A_fn_class = fncls__41d; tmp1 = fncls__41d } else { tmp1 = fncls__41 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__2), tmp1, nil); return /*line :326:1*/ lang.IFn_Cast(walk__2).Invoke_O_O__O(tn__0, Lit_9) }
//line :315:1
func A_arbace_classes_types_type_anns_walk__48000148_A_New() *A_arbace_classes_types_type_anns_walk__48000148_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Ctor() {}
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Invoke_O_O_O__O(self, tn__1, path__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_126.GetRawRoot__O()); var tmp2 any; var tmp3 any; var tmp4 any = A_arbace_classes_types_A_const_55; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))
	if and__1927000168__auto____3 { tmp3 = A_arbace_classes_types_A_const_83.Invoke_O__O(tn__1) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp3) { tmp2 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_83.Invoke_O__O(tn__1), path__2) } else { tmp2 = nil }
//line :316:1
	var tmp5 any = tmp2; var tmp6 any; var path__3 any; var tmp7 any; var tmp8 any = A_arbace_classes_types_A_const_55; var and__1927000168__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp8, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))

	if and__1927000168__auto____3_2 { tmp7 = A_arbace_classes_types_A_const_83.Invoke_O__O(tn__1) } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3_2).Ref() }; if jrt.J2g_Truth(tmp7) { path__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, path__2, nil)).Ref() } else { path__3 = path__2 }
	var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_126.GetRawRoot__O()); var tmp10 lang.IPersistentVector; var temp__1927000414__auto____4 any = A_arbace_classes_types_A_const_44.Invoke_O__O(tn__1)
	if jrt.J2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; tmp10 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(path__3, a__5)) } else { tmp10 = nil }
//line :319:1
	var tmp11 any = tmp10; var tmp12 any; var G__48000149__4_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1)

L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__48000149__4_) >> 0 & 3 { case 0: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_55) {

	var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp14 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_113.GetRawRoot__O()); var tmp16 any = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(path__3, self); var tmp17 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class = fncls__40d; tmp17 = fncls__40d } else { tmp17 = fncls__40 }; tmp12 = tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), A_arbace_classes_types_A_const_57.Invoke_O__O(tn__1)))
//line :321:1
	break L1 }; case 2: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_72) {


		if jrt.J2g_Truth(A_arbace_classes_types_A_const_75.Invoke_O__O(tn__1)) { tmp12 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_75.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref()) } else { tmp12 = nil }
//line :321:1
		break L1 }; case 3: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_53) {
			tmp12 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_54.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref())
//line :321:1
			break L1 }; default:}; tmp12 = nil}
//line :319:1
	tmp6 = tmp9.Invoke_O_O__O(tmp11, tmp12)
//line :316:1
	return tmp1.Invoke_O_O__O(tmp5, tmp6)
}





func A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(p0, p1 any) *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Ctor_O_O(c__path, c__walk any) { t.F_path = c__path; t.F_walk = c__walk }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Invoke_O_O_O__O(self, i__1, a__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp1.Invoke_O_O__O(a__2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, t.F_path, i__1, nil)).Ref()) }




func A_arbace_classes_types_element_path_A_New() *A_arbace_classes_types_element_path_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_element_path_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Ctor() {}
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Invoke_O_O__O(self, tn__0 any) any { { var tn__2 any = tn__0; var path__3 any = Lit_9; L1: for {




	var tmp1 any = A_arbace_classes_types_A_const_53; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__2)) { tn__2, path__3 = A_arbace_classes_types_A_const_54.Invoke_O__O(tn__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref(); continue L1 } else { return path__3 } } }; /*line :328:1*/panic("j2g: unreachable") }












































































type A_arbace_classes_types_A struct{ jrt.Object }

var A_arbace_classes_types_A_const_pool *jrt.RefArray

var A_arbace_classes_types_A_const_0 *lang.Var

var A_arbace_classes_types_A_const_1 *lang.Var

var A_arbace_classes_types_A_const_2 any

var A_arbace_classes_types_A_const_3 any

var A_arbace_classes_types_A_const_4 *lang.Var

var A_arbace_classes_types_A_const_5 *lang.Var

var A_arbace_classes_types_A_const_6 *lang.Var

var A_arbace_classes_types_A_const_7 any

var A_arbace_classes_types_A_const_8 *lang.Var

var A_arbace_classes_types_A_const_9 *lang.Var

var A_arbace_classes_types_A_const_10 *lang.Var

var A_arbace_classes_types_A_const_11 *lang.Var

var A_arbace_classes_types_A_const_12 *lang.Var

var A_arbace_classes_types_A_const_13 *lang.Var

var A_arbace_classes_types_A_const_14 *lang.Keyword

var A_arbace_classes_types_A_const_15 *lang.Var

var A_arbace_classes_types_A_const_16 *lang.Var

var A_arbace_classes_types_A_const_17 any

var A_arbace_classes_types_A_const_18 *lang.Var

var A_arbace_classes_types_A_const_19 any

var A_arbace_classes_types_A_const_20 any

var A_arbace_classes_types_A_const_21 any

var A_arbace_classes_types_A_const_22 *lang.Var

var A_arbace_classes_types_A_const_23 any

var A_arbace_classes_types_A_const_24 any

var A_arbace_classes_types_A_const_25 *lang.Var

var A_arbace_classes_types_A_const_26 *lang.Var

var A_arbace_classes_types_A_const_27 *lang.Var

var A_arbace_classes_types_A_const_28 *lang.Var

var A_arbace_classes_types_A_const_29 any

var A_arbace_classes_types_A_const_30 any

var A_arbace_classes_types_A_const_31 *lang.Var

var A_arbace_classes_types_A_const_32 *lang.Keyword

var A_arbace_classes_types_A_const_33 *lang.Var

var A_arbace_classes_types_A_const_34 *lang.Var

var A_arbace_classes_types_A_const_35 *lang.Var

var A_arbace_classes_types_A_const_36 *lang.Var

var A_arbace_classes_types_A_const_37 *lang.Var

var A_arbace_classes_types_A_const_38 *lang.Var

var A_arbace_classes_types_A_const_39 any

var A_arbace_classes_types_A_const_40 *lang.Var

var A_arbace_classes_types_A_const_41 *lang.Var

var A_arbace_classes_types_A_const_42 *lang.Var

var A_arbace_classes_types_A_const_43 *lang.Var

var A_arbace_classes_types_A_const_44 *lang.Keyword

var A_arbace_classes_types_A_const_45 *lang.Var

var A_arbace_classes_types_A_const_46 *lang.Keyword

var A_arbace_classes_types_A_const_47 *lang.Keyword

var A_arbace_classes_types_A_const_48 *lang.Keyword

var A_arbace_classes_types_A_const_49 *lang.Var

var A_arbace_classes_types_A_const_50 *lang.Var

var A_arbace_classes_types_A_const_51 *lang.Var

var A_arbace_classes_types_A_const_52 *lang.Var

var A_arbace_classes_types_A_const_53 *lang.Keyword

var A_arbace_classes_types_A_const_54 *lang.Keyword

var A_arbace_classes_types_A_const_55 *lang.Keyword

var A_arbace_classes_types_A_const_56 *lang.Keyword

var A_arbace_classes_types_A_const_57 *lang.Keyword

var A_arbace_classes_types_A_const_58 any

var A_arbace_classes_types_A_const_59 any

var A_arbace_classes_types_A_const_60 *lang.Keyword

var A_arbace_classes_types_A_const_61 *lang.Keyword

var A_arbace_classes_types_A_const_62 *lang.Keyword

var A_arbace_classes_types_A_const_63 *lang.Keyword

var A_arbace_classes_types_A_const_64 *lang.Var

var A_arbace_classes_types_A_const_65 *lang.Var

var A_arbace_classes_types_A_const_66 *lang.Var

var A_arbace_classes_types_A_const_67 *lang.Var

var A_arbace_classes_types_A_const_68 *lang.Var

var A_arbace_classes_types_A_const_69 any

var A_arbace_classes_types_A_const_70 *lang.Var

var A_arbace_classes_types_A_const_71 any

var A_arbace_classes_types_A_const_72 *lang.Keyword

var A_arbace_classes_types_A_const_73 *lang.Keyword

var A_arbace_classes_types_A_const_74 *lang.Var

var A_arbace_classes_types_A_const_75 *lang.Keyword

var A_arbace_classes_types_A_const_76 any

var A_arbace_classes_types_A_const_77 *lang.Keyword

var A_arbace_classes_types_A_const_78 *lang.Keyword

var A_arbace_classes_types_A_const_79 *lang.Var

var A_arbace_classes_types_A_const_80 any

var A_arbace_classes_types_A_const_81 *lang.Var

var A_arbace_classes_types_A_const_82 *lang.Keyword

var A_arbace_classes_types_A_const_83 *lang.Keyword

var A_arbace_classes_types_A_const_84 *lang.Keyword

var A_arbace_classes_types_A_const_85 *lang.Var

var A_arbace_classes_types_A_const_86 *lang.Var

var A_arbace_classes_types_A_const_87 *lang.Var

var A_arbace_classes_types_A_const_88 *lang.Var

var A_arbace_classes_types_A_const_89 *lang.Var

var A_arbace_classes_types_A_const_90 *lang.Var

var A_arbace_classes_types_A_const_91 *lang.Var

var A_arbace_classes_types_A_const_92 *lang.Var

var A_arbace_classes_types_A_const_93 *lang.Keyword

var A_arbace_classes_types_A_const_94 *lang.Var

var A_arbace_classes_types_A_const_95 *lang.Var

var A_arbace_classes_types_A_const_96 *lang.Var

var A_arbace_classes_types_A_const_97 *lang.Var

var A_arbace_classes_types_A_const_98 *lang.Var

var A_arbace_classes_types_A_const_99 any

var A_arbace_classes_types_A_const_100 *lang.Keyword

var A_arbace_classes_types_A_const_101 *lang.Var

var A_arbace_classes_types_A_const_102 *lang.Var

var A_arbace_classes_types_A_const_103 *lang.Var

var A_arbace_classes_types_A_const_104 *lang.Var

var A_arbace_classes_types_A_const_105 *lang.Keyword

var A_arbace_classes_types_A_const_106 any

var A_arbace_classes_types_A_const_107 *lang.Var

var A_arbace_classes_types_A_const_108 *lang.Var

var A_arbace_classes_types_A_const_109 *lang.Var

var A_arbace_classes_types_A_const_110 *lang.Var

var A_arbace_classes_types_A_const_111 *lang.Var

var A_arbace_classes_types_A_const_112 *lang.Var

var A_arbace_classes_types_A_const_113 *lang.Var

var A_arbace_classes_types_A_const_114 *lang.Var

var A_arbace_classes_types_A_const_115 *lang.Var

var A_arbace_classes_types_A_const_116 *lang.Var

var A_arbace_classes_types_A_const_117 *lang.Var

var A_arbace_classes_types_A_const_118 *lang.Var

var A_arbace_classes_types_A_const_119 *lang.Var

var A_arbace_classes_types_A_const_120 *lang.Var

var A_arbace_classes_types_A_const_121 any

var A_arbace_classes_types_A_const_122 *jrt.Class

var A_arbace_classes_types_A_const_123 *lang.Var

var A_arbace_classes_types_A_const_124 *lang.Var

var A_arbace_classes_types_A_const_125 *lang.Var

var A_arbace_classes_types_A_const_126 *lang.Var

var A_arbace_classes_types_A_init jrt.ClassInit

func A_arbace_classes_types_A_Init() { if !A_arbace_classes_types_A_init.Done() { A_arbace_classes_types_A_init.Run(A_arbace_classes_types_A_clinit) } }

func A_arbace_classes_types_A_clinit() { A_arbace_classes_types_A_clinit_p0(); A_arbace_classes_types_A_clinit_p1(); A_arbace_classes_types_A_clinit_p2(); A_arbace_classes_types_A_clinit_p3(); A_arbace_classes_types_A_clinit_p4(); A_arbace_classes_types_A_clinit_p5(); A_arbace_classes_types_A_clinit_p6(); A_arbace_classes_types_A_clinit_p7(); A_arbace_classes_types_A_clinit_p8(); A_arbace_classes_types_A_clinit_p9(); A_arbace_classes_types_A_clinit_p10() }

func A_arbace_classes_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 163); A_arbace_classes_types_A_const_0 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[36]); A_arbace_classes_types_A_const_1 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[37]); A_arbace_classes_types_A_const_2 = A_arbace_classes_types_A_const_pool.A[38]; A_arbace_classes_types_A_const_3 = A_arbace_classes_types_A_const_pool.A[39]; A_arbace_classes_types_A_const_4 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[40]); A_arbace_classes_types_A_const_5 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[41]); A_arbace_classes_types_A_const_6 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[42]); A_arbace_classes_types_A_const_7 = A_arbace_classes_types_A_const_pool.A[43]; A_arbace_classes_types_A_const_8 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[44]); A_arbace_classes_types_A_const_9 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[45]); A_arbace_classes_types_A_const_10 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[46]); A_arbace_classes_types_A_const_11 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[47]) }

func A_arbace_classes_types_A_clinit_p1() { A_arbace_classes_types_A_const_12 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[48]); A_arbace_classes_types_A_const_13 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[49]); A_arbace_classes_types_A_const_14 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[50]); A_arbace_classes_types_A_const_15 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[51]); A_arbace_classes_types_A_const_16 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[52]); A_arbace_classes_types_A_const_17 = A_arbace_classes_types_A_const_pool.A[53]; A_arbace_classes_types_A_const_18 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[54]); A_arbace_classes_types_A_const_19 = A_arbace_classes_types_A_const_pool.A[55]; A_arbace_classes_types_A_const_20 = A_arbace_classes_types_A_const_pool.A[56]; A_arbace_classes_types_A_const_21 = A_arbace_classes_types_A_const_pool.A[57]; A_arbace_classes_types_A_const_22 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[58]); A_arbace_classes_types_A_const_23 = A_arbace_classes_types_A_const_pool.A[59]; A_arbace_classes_types_A_const_24 = A_arbace_classes_types_A_const_pool.A[60] }

func A_arbace_classes_types_A_clinit_p2() { A_arbace_classes_types_A_const_25 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[61]); A_arbace_classes_types_A_const_26 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[62]); A_arbace_classes_types_A_const_27 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[63]); A_arbace_classes_types_A_const_28 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[64]); A_arbace_classes_types_A_const_29 = A_arbace_classes_types_A_const_pool.A[65]; A_arbace_classes_types_A_const_30 = A_arbace_classes_types_A_const_pool.A[66]; A_arbace_classes_types_A_const_31 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[67]); A_arbace_classes_types_A_const_32 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[68]); A_arbace_classes_types_A_const_33 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[69]); A_arbace_classes_types_A_const_34 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[70]); A_arbace_classes_types_A_const_35 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[71]); A_arbace_classes_types_A_const_36 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[72]) }

func A_arbace_classes_types_A_clinit_p3() { A_arbace_classes_types_A_const_37 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[73]); A_arbace_classes_types_A_const_38 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[74]); A_arbace_classes_types_A_const_39 = A_arbace_classes_types_A_const_pool.A[75]; A_arbace_classes_types_A_const_40 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[76]); A_arbace_classes_types_A_const_41 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[77]); A_arbace_classes_types_A_const_42 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[78]); A_arbace_classes_types_A_const_43 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[79]); A_arbace_classes_types_A_const_44 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[80]); A_arbace_classes_types_A_const_45 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[81]); A_arbace_classes_types_A_const_46 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[82]); A_arbace_classes_types_A_const_47 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[83]); A_arbace_classes_types_A_const_48 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[84]) }

func A_arbace_classes_types_A_clinit_p4() { A_arbace_classes_types_A_const_49 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[85]); A_arbace_classes_types_A_const_50 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[86]); A_arbace_classes_types_A_const_51 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[87]); A_arbace_classes_types_A_const_52 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[88]); A_arbace_classes_types_A_const_53 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[89]); A_arbace_classes_types_A_const_54 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[90]); A_arbace_classes_types_A_const_55 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[91]); A_arbace_classes_types_A_const_56 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[92]); A_arbace_classes_types_A_const_57 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[93]); A_arbace_classes_types_A_const_58 = A_arbace_classes_types_A_const_pool.A[94]; A_arbace_classes_types_A_const_59 = A_arbace_classes_types_A_const_pool.A[95]; A_arbace_classes_types_A_const_60 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[96]) }

func A_arbace_classes_types_A_clinit_p5() { A_arbace_classes_types_A_const_61 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[97]); A_arbace_classes_types_A_const_62 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[98]); A_arbace_classes_types_A_const_63 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[99]); A_arbace_classes_types_A_const_64 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[100]); A_arbace_classes_types_A_const_65 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[101]); A_arbace_classes_types_A_const_66 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[102]); A_arbace_classes_types_A_const_67 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[103]); A_arbace_classes_types_A_const_68 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[104]); A_arbace_classes_types_A_const_69 = A_arbace_classes_types_A_const_pool.A[105]; A_arbace_classes_types_A_const_70 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[106]); A_arbace_classes_types_A_const_71 = A_arbace_classes_types_A_const_pool.A[107]; A_arbace_classes_types_A_const_72 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[108]) }

func A_arbace_classes_types_A_clinit_p6() { A_arbace_classes_types_A_const_73 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[109]); A_arbace_classes_types_A_const_74 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[110]); A_arbace_classes_types_A_const_75 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[111]); A_arbace_classes_types_A_const_76 = A_arbace_classes_types_A_const_pool.A[112]; A_arbace_classes_types_A_const_77 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[113]); A_arbace_classes_types_A_const_78 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[114]); A_arbace_classes_types_A_const_79 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[115]); A_arbace_classes_types_A_const_80 = A_arbace_classes_types_A_const_pool.A[116]; A_arbace_classes_types_A_const_81 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[117]); A_arbace_classes_types_A_const_82 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[118]); A_arbace_classes_types_A_const_83 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[119]); A_arbace_classes_types_A_const_84 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[120]) }

func A_arbace_classes_types_A_clinit_p7() { A_arbace_classes_types_A_const_85 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[121]); A_arbace_classes_types_A_const_86 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[122]); A_arbace_classes_types_A_const_87 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[123]); A_arbace_classes_types_A_const_88 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[124]); A_arbace_classes_types_A_const_89 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[125]); A_arbace_classes_types_A_const_90 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[126]); A_arbace_classes_types_A_const_91 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[127]); A_arbace_classes_types_A_const_92 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[128]); A_arbace_classes_types_A_const_93 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[129]); A_arbace_classes_types_A_const_94 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[130]); A_arbace_classes_types_A_const_95 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[131]); A_arbace_classes_types_A_const_96 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[132]) }

func A_arbace_classes_types_A_clinit_p8() { A_arbace_classes_types_A_const_97 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[133]); A_arbace_classes_types_A_const_98 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[134]); A_arbace_classes_types_A_const_99 = A_arbace_classes_types_A_const_pool.A[135]; A_arbace_classes_types_A_const_100 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[136]); A_arbace_classes_types_A_const_101 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[137]); A_arbace_classes_types_A_const_102 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[138]); A_arbace_classes_types_A_const_103 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[139]); A_arbace_classes_types_A_const_104 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[140]); A_arbace_classes_types_A_const_105 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[141]); A_arbace_classes_types_A_const_106 = A_arbace_classes_types_A_const_pool.A[142]; A_arbace_classes_types_A_const_107 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[143]); A_arbace_classes_types_A_const_108 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[144]) }

func A_arbace_classes_types_A_clinit_p9() { A_arbace_classes_types_A_const_109 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[145]); A_arbace_classes_types_A_const_110 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[146]); A_arbace_classes_types_A_const_111 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[147]); A_arbace_classes_types_A_const_112 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[148]); A_arbace_classes_types_A_const_113 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[149]); A_arbace_classes_types_A_const_114 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[150]); A_arbace_classes_types_A_const_115 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[151]); A_arbace_classes_types_A_const_116 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[152]); A_arbace_classes_types_A_const_117 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[153]); A_arbace_classes_types_A_const_118 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[154]); A_arbace_classes_types_A_const_119 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[155]); A_arbace_classes_types_A_const_120 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[156]) }

func A_arbace_classes_types_A_clinit_p10() { A_arbace_classes_types_A_const_121 = A_arbace_classes_types_A_const_pool.A[157]; A_arbace_classes_types_A_const_122 = jrt.Class_Cast(A_arbace_classes_types_A_const_pool.A[158]); A_arbace_classes_types_A_const_123 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[159]); A_arbace_classes_types_A_const_124 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[160]); A_arbace_classes_types_A_const_125 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[161]); A_arbace_classes_types_A_const_126 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[162]) }

func A_arbace_classes_types_A_New() *A_arbace_classes_types_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_A) Ctor() {}

func (t *A_arbace_classes_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_A_class }

func (t *A_arbace_classes_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_A); return ok }

func A_arbace_classes_types_A_Cast(x any) *A_arbace_classes_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_A_class)) }; return v }



type A_arbace_classes_types_array_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_fn__48000030_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_fn__48000030_A_fn_class *jrt.Class



type A_arbace_classes_types_array_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_of_A_fn_class *jrt.Class



type A_arbace_classes_types_array_sym_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_sym_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_fn__48000123_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class *jrt.Class



type A_arbace_classes_types_class__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_class__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_class_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_class_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_class_name_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_class_name_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_internal_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_elem_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_elem_type_A_fn_class *jrt.Class



type A_arbace_classes_types_element_path_A struct{ j2g_header uint64 }

var A_arbace_classes_types_element_path_A_fn_class *jrt.Class



type A_arbace_classes_types_erase_A struct{ j2g_header uint64 }

var A_arbace_classes_types_erase_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000004_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000004_A_New() *A_arbace_classes_types_eval48000004_A { t := &A_arbace_classes_types_eval48000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000004_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000004_A_class }

func (t *A_arbace_classes_types_eval48000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000004_A); return ok }

func A_arbace_classes_types_eval48000004_A_Cast(x any) *A_arbace_classes_types_eval48000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000004_A_class)) }; return v }



type A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000008_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000008_A_New() *A_arbace_classes_types_eval48000008_A { t := &A_arbace_classes_types_eval48000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000008_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000008_A_class }

func (t *A_arbace_classes_types_eval48000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000008_A); return ok }

func A_arbace_classes_types_eval48000008_A_Cast(x any) *A_arbace_classes_types_eval48000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000008_A_class)) }; return v }



type A_arbace_classes_types_eval48000008_fn__48000009_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000013_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000013_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000037_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000037_A_fn_class *jrt.Class



type A_arbace_classes_types_generic_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_generic_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_int_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_int_like_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_internal__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_internal__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_class_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_class_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_local_class_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_local_class_name_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_package_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_package_of_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_A struct{ j2g_header uint64; F_d any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A struct{ j2g_header uint64; F_d, F_i any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000065_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_fn__48000065_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000073_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000073_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000082_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000082_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_p__48000068_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_p__48000068_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_params_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class *jrt.Class



type A_arbace_classes_types_prim_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_prim_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_ref_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_ref_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_reflect__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_reflect__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_simple_name_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_simple_name_of_A_fn_class *jrt.Class



type A_arbace_classes_types_size_A struct{ j2g_header uint64 }

var A_arbace_classes_types_size_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_A struct{ j2g_header uint64 }

var A_arbace_classes_types_subst_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000136_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000136_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000139_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000139_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000141_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000141_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000143_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000143_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000145_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000145_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_walk__48000148_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A struct{ j2g_header uint64; F_path, F_walk any }

var A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_params_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A struct{ j2g_header uint64; F_iter__48000103, F_interface_QMARK_, F_s__48000104 any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A struct{ j2g_header uint64; F_interface_QMARK_, F_b__48000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class *jrt.Class



type A_arbace_classes_types_void_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_void_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_fn__48000056_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_fn__48000056_A_fn_class *jrt.Class
