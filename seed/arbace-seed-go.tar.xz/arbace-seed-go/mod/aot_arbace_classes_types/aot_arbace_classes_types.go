//line aot_arbace_classes_types.ae:1
package aot_arbace_classes_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New() *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_types_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_classes_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_3); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_classes_types_eval48000008_fn__48000009_A_New() *A_arbace_classes_types_eval48000008_fn__48000009_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000008_fn__48000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_8), A_arbace_classes_types_A_const_6.GetRawRoot__O(), A_arbace_classes_types_A_const_7) }















func A_arbace_classes_types_fn__48000013_A_New() *A_arbace_classes_types_fn__48000013_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000013_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Ctor() {}
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Invoke_O_O__O(self, p__48000012__0 any) any { var vec__48000014__2 any = p__48000012__0; var k__3 any = lang.RT_Nth_O_I_O__O(vec__48000014__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__48000014__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(v__4, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(k__3)) }













func A_arbace_classes_types_lang_class_A_New() *A_arbace_classes_types_lang_class_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_class_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Ctor() {}
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0)).Ref() }
func A_arbace_classes_types_lang_desc_A_New() *A_arbace_classes_types_lang_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_desc_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Ctor() {}
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_5, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0, nil)).Ref() }

func A_arbace_classes_types_prim_QMARK__A_New() *A_arbace_classes_types_prim_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_prim_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(t__0))); if and__1927000168__auto____3 { return lang.IFn_Cast(A_arbace_classes_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_8) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_void_QMARK__A_New() *A_arbace_classes_types_void_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_void_QMARK__A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Ctor() {}
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(t__0, Lit_8)).Ref() }
func A_arbace_classes_types_array_QMARK__A_New() *A_arbace_classes_types_array_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_1) } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_ref_QMARK__A_New() *A_arbace_classes_types_ref_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_ref_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z(t__0, A_arbace_classes_types_A_const_14); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_6); if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(t__0) } } else { return and__1927000168__auto____3 } } }
func A_arbace_classes_types_class_desc_QMARK__A_New() *A_arbace_classes_types_class_desc_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class_desc_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(t__0); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_6) } else { return and__1927000168__auto____2 } }

func A_arbace_classes_types_internal__GT_desc_A_New() *A_arbace_classes_types_internal__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_internal__GT_desc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Invoke_O_O__O(self, n__0 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_1)) { return n__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref() } }
func A_arbace_classes_types_desc__GT_internal_A_New() *A_arbace_classes_types_desc__GT_internal_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_internal_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Ctor() {}
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Invoke_O_O__O(self, d__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__0, Lit_6)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_17; return tmp1.Invoke_O_O_O__O(d__0, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(d__0)))).Ref()) } else { return d__0
	} }
func A_arbace_classes_types_elem_type_A_New() *A_arbace_classes_types_elem_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_elem_type_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(d__0, A_arbace_classes_types_A_const_17) }
func A_arbace_classes_types_array_of_A_New() *A_arbace_classes_types_array_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_of_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Invoke_O_O__O(self, d__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__0)).Ref() }
func A_arbace_classes_types_array_dims_A_New() *A_arbace_classes_types_array_dims_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_18.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_array_dims_fn__48000030_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_types_array_dims_fn__48000030_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_classes_types_array_dims_fn__48000030_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), d__0))).Ref() }
//line :48:1
func A_arbace_classes_types_array_dims_fn__48000030_A_New() *A_arbace_classes_types_array_dims_fn__48000030_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_fn__48000030_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Invoke_O_O__O(self, p1__48000029_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_classes_types_A_const_19, p1__48000029_SHARP___1)).Ref() }

func A_arbace_classes_types_size_A_New() *A_arbace_classes_types_size_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_size_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_classes_types_size_A) Ctor() {}
//line :50:1
func (t *A_arbace_classes_types_size_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z(t__0, Lit_45); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z(t__0, Lit_46) }; if tmp1 { return A_arbace_classes_types_A_const_20 } else { if lang.Util_Equiv_O_O__Z(t__0, Lit_8) { return A_arbace_classes_types_A_const_21 } else { return A_arbace_classes_types_A_const_17 } } }

func A_arbace_classes_types_int_like_QMARK__A_New() *A_arbace_classes_types_int_like_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_int_like_QMARK__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_23, t__0) }
func A_arbace_classes_types_numeric_QMARK__A_New() *A_arbace_classes_types_numeric_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_24, t__0) }




func A_arbace_classes_types_fn__48000037_A_New() *A_arbace_classes_types_fn__48000037_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000037_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Ctor() {}
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Invoke_O_O__O(self, p__48000036__0 any) any { var vec__48000038__2 any = p__48000036__0; var k__3 any = lang.RT_Nth_O_I_O__O(vec__48000038__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__48000038__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_classes_types_A_const_25.GetRawRoot__O()).Invoke_O__O(v__4), k__3) }

func A_arbace_classes_types_method_desc_A_New() *A_arbace_classes_types_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_method_desc_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Invoke_O_O_O__O(self, params__0, ret__1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_27.GetRawRoot__O(), params__0), nil, ret__1)).Ref() }

func A_arbace_classes_types_parse_method_desc_A_New() *A_arbace_classes_types_parse_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_types_parse_method_desc_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_types_parse_method_desc_A) Invoke_O_O__O(self, d__0 any) any { { var i__2 any = lang.RT_Box_J__Number(1); var ps__3 any; lang.PersistentVector_Init(); ps__3 = lang.PersistentVector_EMPTY.Ref(); L1: for {



	if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_28)).CharValue__C(), jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__2))) { return lang.Tuple_Create_O_O__IPersistentVector(ps__3, lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(d__0, lang.Numbers_Inc_O__Number(i__2))) } else { var j__4 any; var tmp1 any = A_arbace_classes_types_parse_method_desc_fn__48000045_A_New_O_O(d__0, i__2); var tmp2 *jrt.Class
		var fncls__2 /*line :66:1*/*jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000045_A_fn_class

		if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_classes_types_parse_method_desc_fn__48000045_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; j__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :66:1
		var end__5 any


		if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_29)).CharValue__C(), jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))) { end__5 = jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(d__0)).IndexOf_String_I__I(Lit_7, lang.RT_IntCast_O__I(j__4))))).Ref() } else { end__5 = lang.Numbers_Inc_O__Number(j__4) }
		i__2, ps__3 = end__5, lang.IFn_Cast(A_arbace_classes_types_A_const_6.GetRawRoot__O()).Invoke_O_O__O(ps__3, lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(d__0, i__2, end__5)); continue L1 } } }; /*line :62:1*/panic("a2g: unreachable") }





func A_arbace_classes_types_parse_method_desc_fn__48000045_A_New_O_O(p0, p1 any) *A_arbace_classes_types_parse_method_desc_fn__48000045_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :68:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :68:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000045_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_19)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I(j__1))) { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; panic("a2g: unreachable") }



func A_arbace_classes_types_package_of_A_New() *A_arbace_classes_types_package_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_package_of_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_classes_types_package_of_A) Ctor() {}
//line :72:1
func (t *A_arbace_classes_types_package_of_A) Invoke_O_O__O(self, internal__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5); if
											lang.Numbers_IsNeg_J__Z(int64(i__2)) { return Lit_9 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_21; return tmp1.Invoke_O_O_O__O(internal__0, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_classes_types_simple_name_of_A_New() *A_arbace_classes_types_simple_name_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_simple_name_of_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_types_simple_name_of_A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_types_simple_name_of_A) Invoke_O_O__O(self, internal__0 any) any { var n__2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(internal__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5)))).Ref()); return /*line :77:1*/ lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(n__2, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(n__2)).LastIndexOf_String__I(Lit_11)))).Ref()) }

func A_arbace_classes_types_desc__GT_class_name_A_New() *A_arbace_classes_types_desc__GT_class_name_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_class_name_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Ctor() {}
//line :79:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Invoke_O_O__O(self, d__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(d__0)) { return lang.IFn_Cast(A_arbace_classes_types_A_const_30.GetRawRoot__O()).Invoke_O_O_O__O(d__0, Lit_5, Lit_4) } else { if A_arbace_classes_types_A_const_31 != nil {
		return lang.IFn_Cast(A_arbace_classes_types_A_const_30.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_32.GetRawRoot__O()).Invoke_O__O(d__0), Lit_5, Lit_4) } else {
//line :82:1
			return nil
		}
	} }
func A_arbace_classes_types_class__GT_desc_A_New() *A_arbace_classes_types_class__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class__GT_desc_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_classes_types_class__GT_desc_A) Ctor() {}
//line :85:1
func (t *A_arbace_classes_types_class__GT_desc_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.NN(jrt.Class_Cast(c__0)).IsPrimitive__Z() { return lang.IFn_Cast(A_arbace_classes_types_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref())) } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {
		return lang.IFn_Cast(A_arbace_classes_types_A_const_30.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_4, Lit_5) } else {
//line :86:1
			if A_arbace_classes_types_A_const_31 != nil {

				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_30.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_4, Lit_5), nil)).Ref() } else {
//line :86:1
					return nil
				}
		}
	}
}











func A_arbace_classes_types_array_sym_QMARK__A_New() *A_arbace_classes_types_array_sym_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_sym_QMARK__A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Ctor() {}
//line :102:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(s__0); if
											jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(s__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_37.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_38; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(s__0)) } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_classes_types_with_anns_A_New() *A_arbace_classes_types_with_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_classes_types_with_anns_A) Ctor() {}
//line :107:1
func (t *A_arbace_classes_types_with_anns_A) Invoke_O_O_O__O(self, tn__0, form__1 any) any { var m__3 any = lang.RT_Meta_O__IPersistentMap(form__1); var anns__4 any; if

	jrt.A2g_Truth(m__3) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_39.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_42.GetRawRoot__O()); var tmp5 any = A_arbace_classes_types_with_anns_fn__48000054_A_New(); var tmp6 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_types_with_anns_fn__48000054_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_classes_types_with_anns_fn__48000054_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; anns__4 = tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), m__3)) } else { anns__4 = nil }; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(anns__4)) { return lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(tn__0, A_arbace_classes_types_A_const_43, anns__4) } else { return tn__0 } }
//line :109:1
func A_arbace_classes_types_with_anns_fn__48000054_A_New() *A_arbace_classes_types_with_anns_fn__48000054_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_fn__48000054_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_classes_types_with_anns_fn__48000054_A) Ctor() {}
//line :109:1
func (t *A_arbace_classes_types_with_anns_fn__48000054_A) Invoke_O_O__O(self, p__48000053__1 any) any { var vec__48000055__2 any = p__48000053__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__48000055__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__48000055__2, lang.RT_IntCast_J__I(1), nil); _ = ___4; return lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(k__3) }


func A_arbace_classes_types_parse_type_A_New() *A_arbace_classes_types_parse_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_classes_types_parse_type_A) Ctor() {}
//line :112:1
func (t *A_arbace_classes_types_parse_type_A) Invoke_O_O_O__O(self, scope__0, form__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_44.GetRawRoot__O()); var tmp2 any; var tmp3 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(form__1)

	if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_33.GetRawRoot__O()).Invoke_O__O(form__1); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(form__1), nil)).Ref() } else { tmp3 = and__1927000168__auto____4 } } else { tmp3 = and__1927000168__auto____3 }
//line :117:1
	if jrt.A2g_Truth(tmp3) { var tmp4 any = A_arbace_classes_types_A_const_45; var tmp5 any = A_arbace_classes_types_A_const_46; var tmp6 any = A_arbace_classes_types_A_const_47; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_classes_types_A_const_33.GetRawRoot__O()).Invoke_O__O(form__1))) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_48.GetRawRoot__O()).Invoke_O__O(form__1)) { var base__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_36.GetRawRoot__O()).Invoke_O__O(form__1)); var n__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(form__1)); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_50.GetRawRoot__O()); var tmp8 any = A_arbace_classes_types_parse_type_fn__48000063_A_New(); var tmp9 *jrt.Class
		var fncls__5 /*line :117:1*/*jrt.Class = A_arbace_classes_types_parse_type_fn__48000063_A_fn_class






		if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_classes_types_parse_type_fn__48000063_A_fn_class = fncls__5d; tmp9 = fncls__5d } else { tmp9 = fncls__5 }; tmp2 = lang.RT_Nth_O_I__O(tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(scope__0, base__3)), lang.RT_IntCast_O__I(n__4)) } else {
//line :117:1
			var tmp10 any; var and__1927000168__auto____3_2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(form__1)








			if jrt.A2g_Truth(and__1927000168__auto____3_2) { tmp10 = lang.IFn_Cast(A_arbace_classes_types_A_const_51.GetRawRoot__O()).Invoke_O__O(form__1) } else { tmp10 = and__1927000168__auto____3_2 }
//line :117:1
			if jrt.A2g_Truth(tmp10) { var d__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_51.GetRawRoot__O()).Invoke_O__O(form__1)










				if lang.Util_Equiv_O_O__Z(d__3, Lit_16) { var tmp11 any = A_arbace_classes_types_A_const_45; var tmp12 any = A_arbace_classes_types_A_const_52; var tmp13 any = A_arbace_classes_types_A_const_53; var tmp14 any = A_arbace_classes_types_A_const_45; var tmp15 any = A_arbace_classes_types_A_const_54; var tmp16 any = A_arbace_classes_types_A_const_55; var tmp17 any = A_arbace_classes_types_A_const_56; var tmp18 *lang.PersistentVector; lang.PersistentVector_Init(); tmp18 = lang.PersistentVector_EMPTY; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, Lit_17, tmp17, tmp18.Ref())))) } else { var tmp19 any = A_arbace_classes_types_A_const_45; var tmp20 any = A_arbace_classes_types_A_const_52; var tmp21 any = A_arbace_classes_types_A_const_53; var tmp22 any = A_arbace_classes_types_A_const_45; var tmp23 any = A_arbace_classes_types_A_const_46; var tmp24 any = A_arbace_classes_types_A_const_47; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp20, tmp21, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(d__3, A_arbace_classes_types_A_const_17))))) } } else {
//line :117:1
					if lang.Util_Equiv_O_O__Z(form__1, A_arbace_classes_types_A_const_57) { tmp2 = A_arbace_classes_types_A_const_58 } else { var tmp25 any; var and__1927000168__auto____3_3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(form__1)
















						if jrt.A2g_Truth(and__1927000168__auto____3_3) { tmp25 = lang.IFn_Cast(A_arbace_classes_types_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_81.Invoke_O__O(scope__0), form__1) } else { tmp25 = and__1927000168__auto____3_3 }
//line :117:1
						if jrt.A2g_Truth(tmp25) { tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_45, A_arbace_classes_types_A_const_59, A_arbace_classes_types_A_const_60, form__1)) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(form__1)) { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_61.Invoke_O__O(scope__0)).Invoke_O__O(form__1)




















							if jrt.A2g_Truth(temp__1927000408__auto____3) { var n__4_2 any = temp__1927000408__auto____3; var o__5 any; var temp__1927000414__auto____5 any = A_arbace_classes_types_A_const_62.Invoke_O__O(scope__0)
								if jrt.A2g_Truth(temp__1927000414__auto____5) { var f__6 any = temp__1927000414__auto____5; o__5 = lang.IFn_Cast(f__6).Invoke_O__O(n__4_2) } else { o__5 = nil }
//line :138:1
								var G__48000065__6_ any; var tmp26 any = A_arbace_classes_types_A_const_45; var tmp27 any = A_arbace_classes_types_A_const_54; var tmp28 any = A_arbace_classes_types_A_const_55; var tmp29 any = A_arbace_classes_types_A_const_56; var tmp30 *lang.PersistentVector; lang.PersistentVector_Init(); tmp30 = lang.PersistentVector_EMPTY; G__48000065__6_ = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp27, tmp28, n__4_2, tmp29, tmp30.Ref()))

								if jrt.A2g_Truth(o__5) { tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(G__48000065__6_, A_arbace_classes_types_A_const_82, o__5) } else { tmp2 = G__48000065__6_ } } else {
//line :138:1
									panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_types_A_const_63.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_83, form__1)))))) } } else {
//line :117:1
										if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_11.GetRawRoot__O()).Invoke_O__O(form__1)) { var d__3_2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_30.GetRawRoot__O()).Invoke_O_O_O__O(form__1, Lit_4, Lit_5)



























											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__3_2, Lit_1)) { var body_p__4 *A_arbace_classes_types_parse_type_p__48000066_A = A_arbace_classes_types_parse_type_p__48000066_A_New(); var p__4 any; var tmp31 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_types_parse_type_p__48000066_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_classes_types_parse_type_p__48000066_A_fn_class = fncls__4d; tmp31 = fncls__4d } else { tmp31 = fncls__4 }; p__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_p__4), tmp31, nil)



												tmp2 = lang.IFn_Cast(p__4).Invoke_O__O(d__3_2) } else {
													tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1)) } } else {
//line :117:1
														if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_65.GetRawRoot__O()).Invoke_O__O(form__1)) { var d__3_3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_66.GetRawRoot__O()).Invoke_O__O(form__1); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()); var tmp33 any



































															if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_84.GetRawRoot__O()).Invoke_O__O(d__3_3)) { tmp33 = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_86.GetRawRoot__O()).Invoke_O__O(d__3_3)) } else {
																if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(d__3_3)) { tmp33 = lang.IFn_Cast(A_arbace_classes_types_A_const_85.GetRawRoot__O()).Invoke_O__O(d__3_3) } else { tmp33 = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(form__1)).GetName__String().Ref()) } }
//line :153:1
															tmp2 = tmp32.Invoke_O_O__O(scope__0, tmp33) } else {
//line :117:1
																var tmp34 any; var and__1927000168__auto____3_4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(form__1)






































																if jrt.A2g_Truth(and__1927000168__auto____3_4) { var tmp35 any = A_arbace_classes_types_A_const_68; tmp34 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp35, lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp34 = and__1927000168__auto____3_4 }
//line :117:1
																if jrt.A2g_Truth(tmp34) { var tmp36 any = A_arbace_classes_types_A_const_45; var tmp37 any = A_arbace_classes_types_A_const_52; var tmp38 any = A_arbace_classes_types_A_const_53; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp36, tmp37, tmp38, lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_87.GetRawRoot__O()).Invoke_O__O(form__1)))) } else { var tmp39 any; var and__1927000168__auto____3_5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(form__1)









































																	if jrt.A2g_Truth(and__1927000168__auto____3_5) { var tmp40 any = A_arbace_classes_types_A_const_70; tmp39 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp40, lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp39 = and__1927000168__auto____3_5 }
//line :117:1
																	if jrt.A2g_Truth(tmp39) { var vec__48000068__3 any = form__1; var ___4 any = lang.RT_Nth_O_I_O__O(vec__48000068__3, lang.RT_IntCast_J__I(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O(vec__48000068__3, lang.RT_IntCast_J__I(1), nil); var b__6 any = lang.RT_Nth_O_I_O__O(vec__48000068__3, lang.RT_IntCast_J__I(2), nil); var tmp41 any = A_arbace_classes_types_A_const_45; var tmp42 any = A_arbace_classes_types_A_const_71; var tmp43 any = A_arbace_classes_types_A_const_72; var tmp44 any = lang.IFn_Cast(A_arbace_classes_types_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(k__5)); var tmp45 any = A_arbace_classes_types_A_const_74; _ = ___4; tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp41, tmp42, tmp43, tmp44, tmp45, lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(scope__0, b__6))) } else { var tmp46 any; var and__1927000168__auto____3_6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(form__1)













































																		if jrt.A2g_Truth(and__1927000168__auto____3_6) { var tmp47 any = A_arbace_classes_types_A_const_75; tmp46 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp47, lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp46 = and__1927000168__auto____3_6 }
//line :117:1
																		if jrt.A2g_Truth(tmp46) { var tmp48 any = A_arbace_classes_types_A_const_45; var tmp49 any = A_arbace_classes_types_A_const_76; var tmp50 any = A_arbace_classes_types_A_const_77; var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()); var tmp52 any = A_arbace_classes_types_parse_type_fn__48000071_A_New_O(scope__0); var tmp53 *jrt.Class
																			var fncls__6 /*line :117:1*/*jrt.Class = A_arbace_classes_types_parse_type_fn__48000071_A_fn_class














































																			if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_classes_types_parse_type_fn__48000071_A_fn_class = fncls__6d; tmp53 = fncls__6d } else { tmp53 = fncls__6 }
//line :117:1
																			tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp51.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_88.GetRawRoot__O()).Invoke_O__O(form__1)))) } else { var tmp54 any; var and__1927000168__auto____3_7 any = lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(form__1)
















































																				if jrt.A2g_Truth(and__1927000168__auto____3_7) { var tmp55 any = A_arbace_classes_types_A_const_79; tmp54 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp55, lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp54 = and__1927000168__auto____3_7 }
//line :117:1
																				if jrt.A2g_Truth(tmp54) {

















































																					var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_80.GetRawRoot__O()); var tmp57 any = A_arbace_classes_types_parse_type_fn__48000073_A_New_O(scope__0); var tmp58 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000073_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_classes_types_parse_type_fn__48000073_A_fn_class = fncls__8d; tmp58 = fncls__8d } else { tmp58 = fncls__8 }; tmp2 = tmp56.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_87.GetRawRoot__O()).Invoke_O__O(form__1)), lang.IFn_Cast(A_arbace_classes_types_A_const_90.GetRawRoot__O()).Invoke_O__O(form__1)) } else {
//line :117:1
																						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(form__1)) { var c__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(scope__0, lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(form__1))
																							var tmp59 any = A_arbace_classes_types_A_const_54

























































																							if lang.Util_Equiv_O_O__Z(tmp59, A_arbace_classes_types_A_const_45.Invoke_O__O(c__3)) { } else { var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_63.GetRawRoot__O()); var tmp61 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var tmp62 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp62 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp60.Invoke_O_O__O(tmp61, tmp62.Ref())))) }
																							var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()); var tmp64 any = A_arbace_classes_types_A_const_56; var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()); var tmp66 any = A_arbace_classes_types_parse_type_fn__48000080_A_New_O(scope__0); var tmp67 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000080_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_classes_types_parse_type_fn__48000080_A_fn_class = fncls__9d; tmp67 = fncls__9d } else { tmp67 = fncls__9 }; tmp2 = tmp63.Invoke_O_O_O__O(c__3, tmp64, tmp65.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp66, tmp67, nil), lang.IFn_Cast(A_arbace_classes_types_A_const_88.GetRawRoot__O()).Invoke_O__O(form__1))) } else {
//line :117:1
																								if A_arbace_classes_types_A_const_31 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_types_A_const_63.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_91.GetRawRoot__O()).Invoke_O__O(form__1))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_83, form__1)))))) } else { tmp2 = nil } } } } } } } } } } } } } }
//line :116:1
	return tmp1.Invoke_O_O__O(tmp2, form__1)
}






func A_arbace_classes_types_parse_type_fn__48000063_A_New() *A_arbace_classes_types_parse_type_fn__48000063_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000063_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_classes_types_parse_type_fn__48000063_A) Ctor() {}
//line :124:1
func (t *A_arbace_classes_types_parse_type_fn__48000063_A) Invoke_O_O__O(self, e__1 any) any { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_45, A_arbace_classes_types_A_const_52, A_arbace_classes_types_A_const_53, e__1)) }





















func A_arbace_classes_types_parse_type_p__48000066_A_New() *A_arbace_classes_types_parse_type_p__48000066_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_p__48000066_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_classes_types_parse_type_p__48000066_A) Ctor() {}
//line :146:1
func (t *A_arbace_classes_types_parse_type_p__48000066_A) Invoke_O_O__O(self, d__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__1, Lit_1)) { var tmp1 any = A_arbace_classes_types_A_const_45; var tmp2 any = A_arbace_classes_types_A_const_52; var tmp3 any = A_arbace_classes_types_A_const_53; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.IFn_Cast(self).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(d__1, A_arbace_classes_types_A_const_17)))) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(d__1, Lit_6)) { var tmp4 any = A_arbace_classes_types_A_const_45; var tmp5 any = A_arbace_classes_types_A_const_54; var tmp6 any = A_arbace_classes_types_A_const_55; var tmp7 any = lang.IFn_Cast(A_arbace_classes_types_A_const_32.GetRawRoot__O()).Invoke_O__O(d__1); var tmp8 any = A_arbace_classes_types_A_const_56; var tmp9 *lang.PersistentVector; lang.PersistentVector_Init(); tmp9 = lang.PersistentVector_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9.Ref())) } else { if A_arbace_classes_types_A_const_31 != nil { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_45, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, d__1)) } else { return nil } } } }

















func A_arbace_classes_types_parse_type_fn__48000071_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000071_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000071_A{}; t.Ctor_O(p0); return t }
//line :164:1
func (t *A_arbace_classes_types_parse_type_fn__48000071_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :164:1
func (t *A_arbace_classes_types_parse_type_fn__48000071_A) Invoke_O_O__O(self, p1__48000060_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000060_SHARP___1) }


func A_arbace_classes_types_parse_type_fn__48000073_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :167:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Invoke_O_O_O__O(self, outer__1, f__2 any) any { var vec__48000074__3 any; if
														jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_67.GetRawRoot__O()).Invoke_O__O(f__2)) { vec__48000074__3 = f__2 } else { vec__48000074__3 = lang.Tuple_Create_O__IPersistentVector(f__2) }; var seq__48000075__4 any = /*line :167:1*/lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(vec__48000074__3); var first__48000076__5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(seq__48000075__4); var seq__48000075__6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(seq__48000075__4); var c__7 any = first__48000076__5; var args__8 any = seq__48000075__6; var n__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_55.Invoke_O__O(outer__1), nil, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(c__7))).Ref(); var tmp1 any = A_arbace_classes_types_A_const_45; var tmp2 any = A_arbace_classes_types_A_const_54; var tmp3 any = A_arbace_classes_types_A_const_55; var tmp4 any = A_arbace_classes_types_A_const_56; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()); var tmp6 any = A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_New_O(t.F_scope); var tmp7 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_fn_class; if


	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_fn_class = fncls__7d; tmp7 = fncls__7d } else { tmp7 = fncls__7 }; return /*line :167:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, n__9, tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), args__8), A_arbace_classes_types_A_const_82, outer__1)) }


func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A{}; t.Ctor_O(p0); return t }
//line :170:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :170:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A) Invoke_O_O__O(self, p1__48000061_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000061_SHARP___1) }






func A_arbace_classes_types_parse_type_fn__48000080_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000080_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000080_A{}; t.Ctor_O(p0); return t }
//line :177:1
func (t *A_arbace_classes_types_parse_type_fn__48000080_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :177:1
func (t *A_arbace_classes_types_parse_type_fn__48000080_A) Invoke_O_O__O(self, p1__48000062_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000062_SHARP___1) }




func A_arbace_classes_types_erase_A_New() *A_arbace_classes_types_erase_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_erase_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_classes_types_erase_A) Ctor() {}
//line :182:1
func (t *A_arbace_classes_types_erase_A) Invoke_O_O_O__O(self, bounds__0, tn__1 any) any { var G__48000083__3_ any = A_arbace_classes_types_A_const_45.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I(G__48000083__3_) >> 9 & 7 { case 0: if any(G__48000083__3_) == any(A_arbace_classes_types_A_const_71) {





		var tmp1 any = A_arbace_classes_types_A_const_92; if lang.Util_Equiv_O_O__Z(tmp1, A_arbace_classes_types_A_const_72.Invoke_O__O(tn__1)) { return lang.IFn_Cast(A_arbace_classes_types_A_const_93.GetRawRoot__O()).Invoke_O_O__O(bounds__0, A_arbace_classes_types_A_const_74.Invoke_O__O(tn__1)) } else { return A_arbace_classes_types_A_const_94.GetRawRoot__O() } }
//line :185:1
	case 1: if any(G__48000083__3_) == any(A_arbace_classes_types_A_const_46) {
		return A_arbace_classes_types_A_const_47.Invoke_O__O(tn__1) }
//line :185:1
	case 2: if any(G__48000083__3_) == any(A_arbace_classes_types_A_const_54) {

		return lang.IFn_Cast(A_arbace_classes_types_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_55.Invoke_O__O(tn__1)) }
//line :185:1
	case 3: if any(G__48000083__3_) == any(A_arbace_classes_types_A_const_76) {




		return lang.IFn_Cast(A_arbace_classes_types_A_const_93.GetRawRoot__O()).Invoke_O_O__O(bounds__0, lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_77.Invoke_O__O(tn__1))) }
//line :185:1
	case 4: if any(G__48000083__3_) == any(A_arbace_classes_types_A_const_52) {


		return lang.IFn_Cast(A_arbace_classes_types_A_const_95.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_93.GetRawRoot__O()).Invoke_O_O__O(bounds__0, A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1))) }
//line :185:1
	case 7: if any(G__48000083__3_) == any(A_arbace_classes_types_A_const_59) { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O(bounds__0, A_arbace_classes_types_A_const_60.Invoke_O__O(tn__1)))



		if jrt.A2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; return lang.IFn_Cast(A_arbace_classes_types_A_const_93.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_96.GetRawRoot__O()).Invoke_O_O__O(bounds__0, A_arbace_classes_types_A_const_60.Invoke_O__O(tn__1)), b__5) } else { return A_arbace_classes_types_A_const_94.GetRawRoot__O() } }
//line :185:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000083__3_))))) }







func A_arbace_classes_types_generic_QMARK__A_New() *A_arbace_classes_types_generic_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_generic_QMARK__A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_classes_types_generic_QMARK__A) Ctor() {}
//line :193:1
func (t *A_arbace_classes_types_generic_QMARK__A) Invoke_O_O__O(self, tn__0 any) any { var G__48000085__2_ any = A_arbace_classes_types_A_const_45.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I(G__48000085__2_) >> 9 & 7 { case 0: if any(G__48000085__2_) == any(A_arbace_classes_types_A_const_71) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 1: if any(G__48000085__2_) == any(A_arbace_classes_types_A_const_46) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() }; case 2: if any(G__48000085__2_) == any(A_arbace_classes_types_A_const_54) { var or__1927000174__auto____3 bool = lang.RT_BooleanCast_O__Z(lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0)))

		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var tmp1 any; var and__1927000168__auto____4 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_classes_types_A_const_97.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0)) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref() } }
//line :196:1
	case 3: if any(G__48000085__2_) == any(A_arbace_classes_types_A_const_76) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 4: if any(G__48000085__2_) == any(A_arbace_classes_types_A_const_52) {


		return lang.IFn_Cast(A_arbace_classes_types_A_const_97.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0)) }
//line :196:1
	case 7: if any(G__48000085__2_) == any(A_arbace_classes_types_A_const_59) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000085__2_))))) }







func A_arbace_classes_types_local_class_name_QMARK__A_New() *A_arbace_classes_types_local_class_name_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_local_class_name_QMARK__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Ctor() {}
//line :204:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Invoke_O_O_O__O(self, n__0, outer__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = outer__1; if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_13.GetRawRoot__O()).Invoke_O_O__O(n__0, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, outer__1, nil)).Ref()); if jrt.A2g_Truth(and__1927000168__auto____4) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_37.GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_A_const_98; tmp1 = tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(n__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(outer__1)))).Ref())) } else {
//line :208:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref()
}

func A_arbace_classes_types_signature_A_New() *A_arbace_classes_types_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_signature_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_classes_types_signature_A) Ctor() {}
//line :211:1
func (t *A_arbace_classes_types_signature_A) Invoke_O_O__O(self, tn__0 any) any { var G__48000088__2_ any = A_arbace_classes_types_A_const_45.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I(G__48000088__2_) >> 9 & 7 { case 0: if any(G__48000088__2_) == any(A_arbace_classes_types_A_const_71) { var G__48000089__3_ any = A_arbace_classes_types_A_const_72.Invoke_O__O(tn__0)









		switch lang.Util_Hash_O__I(G__48000089__3_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z(G__48000089__3_, nil) { return Lit_39 }; case 1: if lang.Util_Equiv_O_O__Z(G__48000089__3_, A_arbace_classes_types_A_const_99) {
			return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_74.Invoke_O__O(tn__0)))).Ref() }
//line :224:1
		case 3: if lang.Util_Equiv_O_O__Z(G__48000089__3_, A_arbace_classes_types_A_const_92) { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_74.Invoke_O__O(tn__0)))).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000089__3_))))) }
//line :214:1
	case 1: if any(G__48000088__2_) == any(A_arbace_classes_types_A_const_46) {
		return A_arbace_classes_types_A_const_47.Invoke_O__O(tn__0) }
//line :214:1
	case 2: if any(G__48000088__2_) == any(A_arbace_classes_types_A_const_54) { var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_101.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_102.GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_A_const_55.Invoke_O__O(tn__0); var tmp4 any; var G__48000090__3_ any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0)

		if lang.Util_Identical_O_O__Z(G__48000090__3_, nil) { tmp4 = nil } else { tmp4 = A_arbace_classes_types_A_const_55.Invoke_O__O(G__48000090__3_) }; and__1927000168__auto____3 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4)); if jrt.A2g_Truth(and__1927000168__auto____3) { temp__1927000408__auto____3 = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.A2g_Truth(temp__1927000408__auto____3) { var o__4 any = temp__1927000408__auto____3; var os__5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(o__4); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_4, nil, nil, Lit_7); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()); var tmp7 any = A_arbace_classes_types_A_const_21; var tmp8 any = tmp6.Invoke_O_O_O__O(os__5, tmp7, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(os__5)))).Ref()); var tmp9 any = lang.IFn_Cast(A_arbace_classes_types_A_const_16.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_55.Invoke_O__O(tn__0), jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(A_arbace_classes_types_A_const_55.Invoke_O__O(o__4))))).Ref()); var tmp10 *jrt.String


			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0))) { tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_27.GetRawRoot__O(), lang.IFn_Cast(A_arbace_classes_types_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_100.GetRawRoot__O(), A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0))), nil)) } else { tmp10 = nil }
//line :218:1
			return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, tmp10.Ref(), nil)).Ref() } else {

				var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, nil, Lit_7); var tmp12 any = A_arbace_classes_types_A_const_55.Invoke_O__O(tn__0); var tmp13 *jrt.String
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0))) { tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_27.GetRawRoot__O(), lang.IFn_Cast(A_arbace_classes_types_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_100.GetRawRoot__O(), A_arbace_classes_types_A_const_56.Invoke_O__O(tn__0))), nil)) } else { tmp13 = nil }
//line :220:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13.Ref(), nil)).Ref() } }
//line :214:1
	case 3: if any(G__48000088__2_) == any(A_arbace_classes_types_A_const_76) {











		return lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_77.Invoke_O__O(tn__0))) }
//line :214:1
	case 4: if any(G__48000088__2_) == any(A_arbace_classes_types_A_const_52) {







		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0)))).Ref() }
//line :214:1
	case 7: if any(G__48000088__2_) == any(A_arbace_classes_types_A_const_59) {








		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_44, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_60.Invoke_O__O(tn__0)), nil)).Ref() }
//line :214:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000088__2_))))) }













func A_arbace_classes_types_parse_type_params_A_New() *A_arbace_classes_types_parse_type_params_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_classes_types_parse_type_params_A) Ctor() {}
//line :228:1
func (t *A_arbace_classes_types_parse_type_params_A) Invoke_O_O_O__O(self, scope__0, tps__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_parse_type_params_fn__48000093_A_New_O(scope__0); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000093_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_classes_types_parse_type_params_fn__48000093_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tps__1) }
//line :233:1
func A_arbace_classes_types_parse_type_params_fn__48000093_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000093_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000093_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :233:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_A) Invoke_O_O__O(self, tp__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_35.GetRawRoot__O()).Invoke_O__O(tp__1)) { var tmp1 any = A_arbace_classes_types_A_const_60; var tmp2 any = A_arbace_classes_types_A_const_104; var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any = A_arbace_classes_types_A_const_43; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tp__1, tmp2, tmp4, tmp5, lang.RT_Meta_O__IPersistentMap(tp__1))) } else { var vec__48000094__2 any = tp__1; var seq__48000095__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(vec__48000094__2); var first__48000096__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(seq__48000095__3); var seq__48000095__5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(seq__48000095__3); var s__6 any = first__48000096__4; var first__48000096__7 any = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(seq__48000095__5); var seq__48000095__8 any = lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(seq__48000095__5)
		var kw__9 any = first__48000096__7
		var bs__10 any = seq__48000095__8
		if lang.Util_Equiv_O_O__Z(A_arbace_classes_types_A_const_105, kw__9) { } else { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_63.GetRawRoot__O()); var tmp7 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, tp__1)).Ref(); var tmp8 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp8 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp6.Invoke_O_O__O(tmp7, tmp8.Ref())))) }
//line :234:1
		var tmp9 any = A_arbace_classes_types_A_const_60; var tmp10 any = A_arbace_classes_types_A_const_104; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()); var tmp12 any = A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_New_O(t.F_scope); var tmp13 *jrt.Class
		var fncls__14 /*line :234:1*/*jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_fn_class



		if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_fn_class = fncls__14d; tmp13 = fncls__14d } else { tmp13 = fncls__14 }
//line :234:1
		var tmp14 any = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), bs__10); var tmp15 any = A_arbace_classes_types_A_const_43; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, s__6, tmp10, tmp14, tmp15, lang.RT_Meta_O__IPersistentMap(s__6)))
	}
}

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A{}; t.Ctor_O(p0); return t }
//line :238:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :238:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A) Invoke_O_O__O(self, p1__48000092_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_64.GetRawRoot__O()).Invoke_O_O__O(t.F_scope, p1__48000092_SHARP___1) }


func A_arbace_classes_types_type_params_signature_A_New() *A_arbace_classes_types_type_params_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_classes_types_type_params_signature_A) Ctor() {}
//line :241:1
func (t *A_arbace_classes_types_type_params_signature_A) Invoke_O_O_O__O(self, interface_QMARK___0, tps__1 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_106.GetRawRoot__O()).Invoke_O__O(tps__1)) { return Lit_9 } else {

		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp3 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var tmp4 any; var iter__1927001039__auto____6 any; var tmp5 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_New_O(interface_QMARK___0); var tmp6 *jrt.Class
		var fncls__20 /*line :247:1*/*jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_fn_class

		if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_fn_class = fncls__20d; tmp6 = fncls__20d } else { tmp6 = fncls__20 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(tps__1)
//line :247:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2.Invoke_O_O__O(tmp3, tmp4), nil)).Ref()
	} }
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A{}; t.Ctor_O(p0); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A) Invoke_O_O__O(self, s__48000102__1 any) any { var tmp1 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_New_O_O_O(t.F_interface_QMARK_, s__48000102__1, self); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :249:1
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) Ctor_O_O_O(c__interface_QMARK_, c__s__48000102, c__iter__48000101 any) { t.F_interface_QMARK_ = c__interface_QMARK_; t.F_s__48000102 = c__s__48000102; t.F_iter__48000101 = c__iter__48000101 }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A) Invoke_O__O(self any) any { { var s__48000102__1 any; var t_ any = t.F_s__48000102; t.F_s__48000102 = nil; s__48000102__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(s__48000102__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__48000102__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_107.GetRawRoot__O()).Invoke_O__O(s__48000102__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_108.GetRawRoot__O()).Invoke_O__O(s__48000102__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__48000104__6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_109.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_New_O_O_I_O(b__48000104__6, t.F_interface_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__48000101); return lang.IFn_Cast(A_arbace_classes_types_A_const_113.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_115.GetRawRoot__O()).Invoke_O__O(b__48000104__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_116.GetRawRoot__O()).Invoke_O__O(s__48000102__3))) } else { return lang.IFn_Cast(A_arbace_classes_types_A_const_113.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_115.GetRawRoot__O()).Invoke_O__O(b__48000104__6), nil) } } else { var map__48000113__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(s__48000102__3); var map__48000113__5 any; if lang.ISeq_InstanceOf(map__48000113__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(map__48000113__4)) { map__48000113__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_types_A_const_110.GetRawRoot__O()).Invoke_O__O(map__48000113__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(map__48000113__4)) { map__48000113__5 = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(map__48000113__4) } else { lang.PersistentArrayMap_Init(); map__48000113__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000113__5 = map__48000113__4 }; var sym__6 any = lang.RT_Get_O_O__O(map__48000113__5, A_arbace_classes_types_A_const_60); var bounds__7 any = lang.RT_Get_O_O__O(map__48000113__5, A_arbace_classes_types_A_const_104); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_114.GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 any = lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(sym__6); var tmp7 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_106.GetRawRoot__O()).Invoke_O__O(bounds__7)) { tmp7 = Lit_57 } else {

		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp9 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_112.GetRawRoot__O()); var tmp11 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_New_O(t.F_interface_QMARK_); var tmp12 *jrt.Class
		var fncls__18 /*line :253:1*/*jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_fn_class

		if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_fn_class = fncls__18d; tmp12 = fncls__18d } else { tmp12 = fncls__18 }
//line :253:1
		tmp7 = tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), bounds__7)) }
//line :249:1
	var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__48000101); return tmp4.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)).Ref(), tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_88.GetRawRoot__O()).Invoke_O__O(s__48000102__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :249:1
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) Ctor_O_O_I_O(c__b__48000104, c__interface_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__48000104 = c__b__48000104; t.F_interface_QMARK_ = c__interface_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A) Invoke_O__O(self any) any { { var i__48000103__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__48000103__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__48000108__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__48000103__1)); var map__48000108__3 any; if lang.ISeq_InstanceOf(map__48000108__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(map__48000108__2)) { map__48000108__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_types_A_const_110.GetRawRoot__O()).Invoke_O__O(map__48000108__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(map__48000108__2)) { map__48000108__3 = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(map__48000108__2) } else { lang.PersistentArrayMap_Init(); map__48000108__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000108__3 = map__48000108__2 }; var sym__4 any = lang.RT_Get_O_O__O(map__48000108__3, A_arbace_classes_types_A_const_60); var bounds__5 any = lang.RT_Get_O_O__O(map__48000108__3, A_arbace_classes_types_A_const_104); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_111.GetRawRoot__O()); var tmp3 any = t.F_b__48000104; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp5 any = lang.IFn_Cast(A_arbace_classes_types_A_const_9.GetRawRoot__O()).Invoke_O__O(sym__4); var tmp6 any

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_106.GetRawRoot__O()).Invoke_O__O(bounds__5)) { tmp6 = Lit_57 } else {

		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp8 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_112.GetRawRoot__O()); var tmp10 any = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_New_O(t.F_interface_QMARK_); var tmp11 *jrt.Class
		var fncls__16 /*line :253:1*/*jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_fn_class

		if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_fn_class = fncls__16d; tmp11 = fncls__16d } else { tmp11 = fncls__16 }
//line :253:1
		tmp6 = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), bounds__5)) }
//line :249:1
	tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6)).Ref()); i__48000103__1 = lang.Numbers_Unchecked_inc_J__J(i__48000103__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A{}; t.Ctor_O(p0); return t }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool = lang.Numbers_IsZero_O__Z(i__1); if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_54; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_classes_types_A_const_45.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_55.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } }
//line :255:1
func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A{}; t.Ctor_O(p0); return t }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :255:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool = lang.Numbers_IsZero_O__Z(i__1); if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_54; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_classes_types_A_const_45.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_55.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(b__2))).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_100.GetRawRoot__O()).Invoke_O__O(b__2))).Ref()
		}
}

func A_arbace_classes_types_bounds_map_A_New() *A_arbace_classes_types_bounds_map_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_classes_types_bounds_map_A) Ctor() {}
//line :262:1
func (t *A_arbace_classes_types_bounds_map_A) Invoke_O_O__O(self, tps__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_39.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_103.GetRawRoot__O()); var tmp5 any = A_arbace_classes_types_bounds_map_fn__48000121_A_New(); var tmp6 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_types_bounds_map_fn__48000121_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_classes_types_bounds_map_fn__48000121_A_fn_class = fncls__21d; tmp6 = fncls__21d } else { tmp6 = fncls__21 }; return tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), tps__0)) }
//line :262:1
func A_arbace_classes_types_bounds_map_fn__48000121_A_New() *A_arbace_classes_types_bounds_map_fn__48000121_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_fn__48000121_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) Ctor() {}
//line :262:1
func (t *A_arbace_classes_types_bounds_map_fn__48000121_A) Invoke_O_O__O(self, p__48000120__1 any) any { var map__48000122__2 any = p__48000120__1; var map__48000122__3 any; if lang.ISeq_InstanceOf(map__48000122__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_89.GetRawRoot__O()).Invoke_O__O(map__48000122__2)) { map__48000122__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_types_A_const_110.GetRawRoot__O()).Invoke_O__O(map__48000122__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(map__48000122__2)) { map__48000122__3 = lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(map__48000122__2) } else { lang.PersistentArrayMap_Init(); map__48000122__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000122__3 = map__48000122__2 }; var sym__4 any = lang.RT_Get_O_O__O(map__48000122__3, A_arbace_classes_types_A_const_60); var bounds__5 any = lang.RT_Get_O_O__O(map__48000122__3, A_arbace_classes_types_A_const_104); return lang.Tuple_Create_O_O__IPersistentVector(sym__4, bounds__5) }

func A_arbace_classes_types_desc__GT_tnode_A_New() *A_arbace_classes_types_desc__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_tnode_A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Ctor() {}
//line :264:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Invoke_O_O__O(self, d__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_84.GetRawRoot__O()).Invoke_O__O(d__0)) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_45, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, d__0)) } else { if lang.Util_Equiv_O_O__Z(d__0, Lit_8) { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_45, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, d__0)) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_types_A_const_15.GetRawRoot__O()).Invoke_O__O(d__0)) { var tmp1 any = A_arbace_classes_types_A_const_45; var tmp2 any = A_arbace_classes_types_A_const_52; var tmp3 any = A_arbace_classes_types_A_const_53; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.IFn_Cast(A_arbace_classes_types_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_118.GetRawRoot__O()).Invoke_O__O(d__0)))) } else { if A_arbace_classes_types_A_const_31 != nil { var tmp4 any = A_arbace_classes_types_A_const_45; var tmp5 any = A_arbace_classes_types_A_const_54; var tmp6 any = A_arbace_classes_types_A_const_55; var tmp7 any = lang.IFn_Cast(A_arbace_classes_types_A_const_32.GetRawRoot__O()).Invoke_O__O(d__0); var tmp8 any = A_arbace_classes_types_A_const_56; var tmp9 *lang.PersistentVector; lang.PersistentVector_Init(); tmp9 = lang.PersistentVector_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9.Ref())) } else { return nil
	}
	}
	}
	} }
func A_arbace_classes_types_reflect__GT_tnode_A_New() *A_arbace_classes_types_reflect__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_reflect__GT_tnode_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Invoke_O_O__O(self, ty__0 any) any {


	if jrt.Class_InstanceOf(ty__0) {
		return lang.IFn_Cast(A_arbace_classes_types_A_const_117.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_66.GetRawRoot__O()).Invoke_O__O(ty__0)) } else {
//line :273:1
			if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_29)).IsInstance_O__Z(ty__0) { var pt__2 any = ty__0; var tmp1 any = A_arbace_classes_types_A_const_45; var tmp2 any = A_arbace_classes_types_A_const_54; var tmp3 any = A_arbace_classes_types_A_const_55; var tmp4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_66.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_29), Lit_30, jrt.RefArrayOf(jrt.Object_class)))); var tmp5 any = A_arbace_classes_types_A_const_56; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_119.GetRawRoot__O(), lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_29), Lit_31, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_32)).IsInstance_O__Z(ty__0) { var tmp6 any = A_arbace_classes_types_A_const_45; var tmp7 any = A_arbace_classes_types_A_const_59; var tmp8 any = A_arbace_classes_types_A_const_60; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class(Lit_32), Lit_33, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_34)).IsInstance_O__Z(ty__0) { var tmp9 any = A_arbace_classes_types_A_const_45; var tmp10 any = A_arbace_classes_types_A_const_52; var tmp11 any = A_arbace_classes_types_A_const_53; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, lang.IFn_Cast(A_arbace_classes_types_A_const_119.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class(Lit_34), Lit_35, jrt.RefArrayOf(jrt.Object_class))))) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class(Lit_36)).IsInstance_O__Z(ty__0) { var w__2 any = ty__0; var lo__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_36), Lit_37, jrt.RefArrayOf(jrt.Object_class))); var up__4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class(Lit_36), Lit_38, jrt.RefArrayOf(jrt.Object_class)))












				if jrt.A2g_Truth(lo__3) { var tmp12 any = A_arbace_classes_types_A_const_45; var tmp13 any = A_arbace_classes_types_A_const_71; var tmp14 any = A_arbace_classes_types_A_const_72; var tmp15 any = A_arbace_classes_types_A_const_99; var tmp16 any = A_arbace_classes_types_A_const_74; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15, tmp16, lang.IFn_Cast(A_arbace_classes_types_A_const_119.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(lo__3)))) } else { var tmp17 any; var and__1927000168__auto____5 any = up__4
					if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_12.GetRawRoot__O()); var tmp19 any = A_arbace_classes_types_A_const_121; tmp17 = tmp18.Invoke_O_O__O(tmp19, lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(up__4)) } else { tmp17 = and__1927000168__auto____5 }
//line :286:1
					if jrt.A2g_Truth(tmp17) { var tmp20 any = A_arbace_classes_types_A_const_45; var tmp21 any = A_arbace_classes_types_A_const_71; var tmp22 any = A_arbace_classes_types_A_const_72; var tmp23 any = A_arbace_classes_types_A_const_92; var tmp24 any = A_arbace_classes_types_A_const_74; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21, tmp22, tmp23, tmp24, lang.IFn_Cast(A_arbace_classes_types_A_const_119.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_69.GetRawRoot__O()).Invoke_O__O(up__4)))) } else { if A_arbace_classes_types_A_const_31 != nil { return A_arbace_classes_types_A_const_120 } else { return nil } } } } else {
//line :273:1
						if A_arbace_classes_types_A_const_31 != nil { var tmp25 any = A_arbace_classes_types_A_const_45; var tmp26 any = A_arbace_classes_types_A_const_54; var tmp27 any = A_arbace_classes_types_A_const_55; var tmp28 any = A_arbace_classes_types_A_const_56; var tmp29 *lang.PersistentVector; lang.PersistentVector_Init(); tmp29 = lang.PersistentVector_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp26, tmp27, Lit_17, tmp28, tmp29.Ref())) } else { return nil
						}
					}
			}
			}
			}
		}
}










func A_arbace_classes_types_subst_A_New() *A_arbace_classes_types_subst_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_classes_types_subst_A) Ctor() {}
//line :291:1
func (t *A_arbace_classes_types_subst_A) Invoke_O_O_O__O(self, env__0, tn__1 any) any { var G__48000133__3_ any = A_arbace_classes_types_A_const_45.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I(G__48000133__3_) >> 9 & 7 { case 0: if any(G__48000133__3_) == any(A_arbace_classes_types_A_const_71) {




		if jrt.A2g_Truth(A_arbace_classes_types_A_const_74.Invoke_O__O(tn__1)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_122.GetRawRoot__O()); var tmp2 any = A_arbace_classes_types_A_const_74; var tmp3 any = A_arbace_classes_types_subst_fn__48000134_A_New_O(env__0); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_types_subst_fn__48000134_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_classes_types_subst_fn__48000134_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; return tmp1.Invoke_O_O_O__O(tn__1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } else { return tn__1 } }
//line :294:1
	case 2: if any(G__48000133__3_) == any(A_arbace_classes_types_A_const_54) { var G__48000136__4_ any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_41.GetRawRoot__O()); var tmp6 any = A_arbace_classes_types_A_const_56; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()); var tmp8 any = A_arbace_classes_types_subst_fn__48000137_A_New_O(env__0); var tmp9 *jrt.Class
		var fncls__24 /*line :294:1*/*jrt.Class = A_arbace_classes_types_subst_fn__48000137_A_fn_class

		if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_classes_types_subst_fn__48000137_A_fn_class = fncls__24d; tmp9 = fncls__24d } else { tmp9 = fncls__24 }; G__48000136__4_ = tmp5.Invoke_O_O_O__O(tn__1, tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), A_arbace_classes_types_A_const_56.Invoke_O__O(tn__1))); if jrt.A2g_Truth(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1)) {
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_122.GetRawRoot__O()); var tmp11 any = A_arbace_classes_types_A_const_82; var tmp12 any = A_arbace_classes_types_subst_fn__48000139_A_New_O(env__0); var tmp13 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_types_subst_fn__48000139_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_classes_types_subst_fn__48000139_A_fn_class = fncls__25d; tmp13 = fncls__25d } else { tmp13 = fncls__25 }; return tmp10.Invoke_O_O_O__O(G__48000136__4_, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)) } else {
//line :296:1
				return G__48000136__4_ } }
//line :294:1
	case 3: if any(G__48000133__3_) == any(A_arbace_classes_types_A_const_76) {





		var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_122.GetRawRoot__O()); var tmp15 any = A_arbace_classes_types_A_const_77; var tmp16 any = A_arbace_classes_types_subst_fn__48000141_A_New_O(env__0); var tmp17 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_types_subst_fn__48000141_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_classes_types_subst_fn__48000141_A_fn_class = fncls__26d; tmp17 = fncls__26d } else { tmp17 = fncls__26 }; return tmp14.Invoke_O_O_O__O(tn__1, tmp15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil)) }
//line :294:1
	case 4: if any(G__48000133__3_) == any(A_arbace_classes_types_A_const_52) {



		var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_122.GetRawRoot__O()); var tmp19 any = A_arbace_classes_types_A_const_53; var tmp20 any = A_arbace_classes_types_subst_fn__48000143_A_New_O(env__0); var tmp21 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_types_subst_fn__48000143_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_classes_types_subst_fn__48000143_A_fn_class = fncls__27d; tmp21 = fncls__27d } else { tmp21 = fncls__27 }; return tmp18.Invoke_O_O_O__O(tn__1, tmp19, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil)) }
//line :294:1
	case 7: if any(G__48000133__3_) == any(A_arbace_classes_types_A_const_59) {
		return lang.RT_Get_O_O_O__O(env__0, A_arbace_classes_types_A_const_60.Invoke_O__O(tn__1), tn__1) }
//line :294:1
	default:}; return tn__1 }

func A_arbace_classes_types_subst_fn__48000137_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000137_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000137_A{}; t.Ctor_O(p0); return t }
//line :296:1
func (t *A_arbace_classes_types_subst_fn__48000137_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :296:1
func (t *A_arbace_classes_types_subst_fn__48000137_A) Invoke_O_O__O(self, p1__48000128_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000128_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000139_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000139_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000139_A{}; t.Ctor_O(p0); return t }
//line :297:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :297:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Invoke_O_O__O(self, p1__48000129_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000129_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000143_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000143_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000143_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :298:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Invoke_O_O__O(self, p1__48000130_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000130_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000134_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000134_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000134_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_classes_types_subst_fn__48000134_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :299:1
func (t *A_arbace_classes_types_subst_fn__48000134_A) Invoke_O_O__O(self, p1__48000131_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_123.GetRawRoot__O()).Invoke_O_O__O(t.F_env, p1__48000131_SHARP___1) }
func A_arbace_classes_types_subst_fn__48000141_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000141_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000141_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :300:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Invoke_O_O__O(self, p1__48000132_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_types_A_const_78.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_types_A_const_124.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_types_A_const_123.GetRawRoot__O(), t.F_env), p1__48000132_SHARP___1) }


func A_arbace_classes_types_type_anns_A_New() *A_arbace_classes_types_type_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_classes_types_type_anns_A) Ctor() {}
//line :303:1
func (t *A_arbace_classes_types_type_anns_A) Invoke_O_O__O(self, tn__0 any) any { var body_walk__2 *A_arbace_classes_types_type_anns_walk__48000146_A = A_arbace_classes_types_type_anns_walk__48000146_A_New(); var walk__2 any; var tmp1 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000146_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_classes_types_type_anns_walk__48000146_A_fn_class = fncls__30d; tmp1 = fncls__30d } else { tmp1 = fncls__30 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__2), tmp1, nil); return /*line :318:1*/ lang.IFn_Cast(walk__2).Invoke_O_O__O(tn__0, Lit_9) }
//line :307:1
func A_arbace_classes_types_type_anns_walk__48000146_A_New() *A_arbace_classes_types_type_anns_walk__48000146_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000146_A{}; t.Ctor(); return t }
//line :307:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_A) Ctor() {}
//line :307:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_A) Invoke_O_O_O__O(self, tn__1, path__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_125.GetRawRoot__O()); var tmp2 any; var tmp3 any; var tmp4 any = A_arbace_classes_types_A_const_54; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp4, A_arbace_classes_types_A_const_45.Invoke_O__O(tn__1))
	if and__1927000168__auto____3 { tmp3 = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp3) { tmp2 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1), path__2) } else { tmp2 = nil }
//line :308:1
	var tmp5 any = tmp2; var tmp6 any; var path__3 any; var tmp7 any; var tmp8 any = A_arbace_classes_types_A_const_54; var and__1927000168__auto____3_2 bool = lang.Util_Equiv_O_O__Z(tmp8, A_arbace_classes_types_A_const_45.Invoke_O__O(tn__1))

	if and__1927000168__auto____3_2 { tmp7 = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1) } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3_2).Ref() }; if jrt.A2g_Truth(tmp7) { path__3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, path__2, nil)).Ref() } else { path__3 = path__2 }
	var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_125.GetRawRoot__O()); var tmp10 lang.IPersistentVector; var temp__1927000414__auto____4 any = A_arbace_classes_types_A_const_43.Invoke_O__O(tn__1)
	if jrt.A2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; tmp10 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(path__3, a__5)) } else { tmp10 = nil }
//line :311:1
	var tmp11 any = tmp10; var tmp12 any; var G__48000147__4_ any = A_arbace_classes_types_A_const_45.Invoke_O__O(tn__1)

L1: switch { default: switch lang.Util_Hash_O__I(G__48000147__4_) >> 0 & 3 { case 0: if any(G__48000147__4_) == any(A_arbace_classes_types_A_const_54) {

	var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_26.GetRawRoot__O()); var tmp14 any = A_arbace_classes_types_A_const_125.GetRawRoot__O(); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_112.GetRawRoot__O()); var tmp16 any = A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_New_O_O(path__3, self); var tmp17 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_fn_class = fncls__29d; tmp17 = fncls__29d } else { tmp17 = fncls__29 }; tmp12 = tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), A_arbace_classes_types_A_const_56.Invoke_O__O(tn__1)))
//line :313:1
	break L1 }; case 2: if any(G__48000147__4_) == any(A_arbace_classes_types_A_const_71) {


		if jrt.A2g_Truth(A_arbace_classes_types_A_const_74.Invoke_O__O(tn__1)) { tmp12 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_74.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_39), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref()) } else { tmp12 = nil }
//line :313:1
		break L1 }; case 3: if any(G__48000147__4_) == any(A_arbace_classes_types_A_const_52) {
			tmp12 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref())
//line :313:1
			break L1 }; default:}; tmp12 = nil}
//line :311:1
	tmp6 = tmp9.Invoke_O_O__O(tmp11, tmp12)
//line :308:1
	return tmp1.Invoke_O_O__O(tmp5, tmp6)
}





func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_New_O_O(p0, p1 any) *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A{}; t.Ctor_O_O(p0, p1); return t }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) Ctor_O_O(c__path, c__walk any) { t.F_path = c__path; t.F_walk = c__walk }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A) Invoke_O_O_O__O(self, i__1, a__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp1.Invoke_O_O__O(a__2, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, t.F_path, i__1, nil)).Ref()) }




func A_arbace_classes_types_element_path_A_New() *A_arbace_classes_types_element_path_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_element_path_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_classes_types_element_path_A) Ctor() {}
//line :320:1
func (t *A_arbace_classes_types_element_path_A) Invoke_O_O__O(self, tn__0 any) any { { var tn__2 any = tn__0; var path__3 any = Lit_9; L1: for {




	var tmp1 any = A_arbace_classes_types_A_const_52; if lang.Util_Equiv_O_O__Z(tmp1, A_arbace_classes_types_A_const_45.Invoke_O__O(tn__2)) { tn__2, path__3 = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__2), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref(); continue L1 } else { return path__3 } } }; /*line :320:1*/panic("a2g: unreachable") }














































































type A_arbace_classes_types_A struct{ jrt.Object }

var A_arbace_classes_types_A_const_pool *jrt.RefArray

var A_arbace_classes_types_A_const_0 *lang.Var

var A_arbace_classes_types_A_const_1 *lang.Var

var A_arbace_classes_types_A_const_2 any

var A_arbace_classes_types_A_const_3 any

var A_arbace_classes_types_A_const_4 *lang.Var

var A_arbace_classes_types_A_const_5 *lang.Var

var A_arbace_classes_types_A_const_6 *lang.Var

var A_arbace_classes_types_A_const_7 any

var A_arbace_classes_types_A_const_8 *lang.Var

var A_arbace_classes_types_A_const_9 *lang.Var

var A_arbace_classes_types_A_const_10 *lang.Var

var A_arbace_classes_types_A_const_11 *lang.Var

var A_arbace_classes_types_A_const_12 *lang.Var

var A_arbace_classes_types_A_const_13 *lang.Var

var A_arbace_classes_types_A_const_14 *lang.Keyword

var A_arbace_classes_types_A_const_15 *lang.Var

var A_arbace_classes_types_A_const_16 *lang.Var

var A_arbace_classes_types_A_const_17 any

var A_arbace_classes_types_A_const_18 *lang.Var

var A_arbace_classes_types_A_const_19 any

var A_arbace_classes_types_A_const_20 any

var A_arbace_classes_types_A_const_21 any

var A_arbace_classes_types_A_const_22 *lang.Var

var A_arbace_classes_types_A_const_23 any

var A_arbace_classes_types_A_const_24 any

var A_arbace_classes_types_A_const_25 *lang.Var

var A_arbace_classes_types_A_const_26 *lang.Var

var A_arbace_classes_types_A_const_27 *lang.Var

var A_arbace_classes_types_A_const_28 any

var A_arbace_classes_types_A_const_29 any

var A_arbace_classes_types_A_const_30 *lang.Var

var A_arbace_classes_types_A_const_31 *lang.Keyword

var A_arbace_classes_types_A_const_32 *lang.Var

var A_arbace_classes_types_A_const_33 *lang.Var

var A_arbace_classes_types_A_const_34 *lang.Var

var A_arbace_classes_types_A_const_35 *lang.Var

var A_arbace_classes_types_A_const_36 *lang.Var

var A_arbace_classes_types_A_const_37 *lang.Var

var A_arbace_classes_types_A_const_38 any

var A_arbace_classes_types_A_const_39 *lang.Var

var A_arbace_classes_types_A_const_40 *lang.Var

var A_arbace_classes_types_A_const_41 *lang.Var

var A_arbace_classes_types_A_const_42 *lang.Var

var A_arbace_classes_types_A_const_43 *lang.Keyword

var A_arbace_classes_types_A_const_44 *lang.Var

var A_arbace_classes_types_A_const_45 *lang.Keyword

var A_arbace_classes_types_A_const_46 *lang.Keyword

var A_arbace_classes_types_A_const_47 *lang.Keyword

var A_arbace_classes_types_A_const_48 *lang.Var

var A_arbace_classes_types_A_const_49 *lang.Var

var A_arbace_classes_types_A_const_50 *lang.Var

var A_arbace_classes_types_A_const_51 *lang.Var

var A_arbace_classes_types_A_const_52 *lang.Keyword

var A_arbace_classes_types_A_const_53 *lang.Keyword

var A_arbace_classes_types_A_const_54 *lang.Keyword

var A_arbace_classes_types_A_const_55 *lang.Keyword

var A_arbace_classes_types_A_const_56 *lang.Keyword

var A_arbace_classes_types_A_const_57 any

var A_arbace_classes_types_A_const_58 any

var A_arbace_classes_types_A_const_59 *lang.Keyword

var A_arbace_classes_types_A_const_60 *lang.Keyword

var A_arbace_classes_types_A_const_61 *lang.Keyword

var A_arbace_classes_types_A_const_62 *lang.Keyword

var A_arbace_classes_types_A_const_63 *lang.Var

var A_arbace_classes_types_A_const_64 *lang.Var

var A_arbace_classes_types_A_const_65 *lang.Var

var A_arbace_classes_types_A_const_66 *lang.Var

var A_arbace_classes_types_A_const_67 *lang.Var

var A_arbace_classes_types_A_const_68 any

var A_arbace_classes_types_A_const_69 *lang.Var

var A_arbace_classes_types_A_const_70 any

var A_arbace_classes_types_A_const_71 *lang.Keyword

var A_arbace_classes_types_A_const_72 *lang.Keyword

var A_arbace_classes_types_A_const_73 *lang.Var

var A_arbace_classes_types_A_const_74 *lang.Keyword

var A_arbace_classes_types_A_const_75 any

var A_arbace_classes_types_A_const_76 *lang.Keyword

var A_arbace_classes_types_A_const_77 *lang.Keyword

var A_arbace_classes_types_A_const_78 *lang.Var

var A_arbace_classes_types_A_const_79 any

var A_arbace_classes_types_A_const_80 *lang.Var

var A_arbace_classes_types_A_const_81 *lang.Keyword

var A_arbace_classes_types_A_const_82 *lang.Keyword

var A_arbace_classes_types_A_const_83 *lang.Keyword

var A_arbace_classes_types_A_const_84 *lang.Var

var A_arbace_classes_types_A_const_85 *lang.Var

var A_arbace_classes_types_A_const_86 *lang.Var

var A_arbace_classes_types_A_const_87 *lang.Var

var A_arbace_classes_types_A_const_88 *lang.Var

var A_arbace_classes_types_A_const_89 *lang.Var

var A_arbace_classes_types_A_const_90 *lang.Var

var A_arbace_classes_types_A_const_91 *lang.Var

var A_arbace_classes_types_A_const_92 *lang.Keyword

var A_arbace_classes_types_A_const_93 *lang.Var

var A_arbace_classes_types_A_const_94 *lang.Var

var A_arbace_classes_types_A_const_95 *lang.Var

var A_arbace_classes_types_A_const_96 *lang.Var

var A_arbace_classes_types_A_const_97 *lang.Var

var A_arbace_classes_types_A_const_98 any

var A_arbace_classes_types_A_const_99 *lang.Keyword

var A_arbace_classes_types_A_const_100 *lang.Var

var A_arbace_classes_types_A_const_101 *lang.Var

var A_arbace_classes_types_A_const_102 *lang.Var

var A_arbace_classes_types_A_const_103 *lang.Var

var A_arbace_classes_types_A_const_104 *lang.Keyword

var A_arbace_classes_types_A_const_105 any

var A_arbace_classes_types_A_const_106 *lang.Var

var A_arbace_classes_types_A_const_107 *lang.Var

var A_arbace_classes_types_A_const_108 *lang.Var

var A_arbace_classes_types_A_const_109 *lang.Var

var A_arbace_classes_types_A_const_110 *lang.Var

var A_arbace_classes_types_A_const_111 *lang.Var

var A_arbace_classes_types_A_const_112 *lang.Var

var A_arbace_classes_types_A_const_113 *lang.Var

var A_arbace_classes_types_A_const_114 *lang.Var

var A_arbace_classes_types_A_const_115 *lang.Var

var A_arbace_classes_types_A_const_116 *lang.Var

var A_arbace_classes_types_A_const_117 *lang.Var

var A_arbace_classes_types_A_const_118 *lang.Var

var A_arbace_classes_types_A_const_119 *lang.Var

var A_arbace_classes_types_A_const_120 any

var A_arbace_classes_types_A_const_121 *jrt.Class

var A_arbace_classes_types_A_const_122 *lang.Var

var A_arbace_classes_types_A_const_123 *lang.Var

var A_arbace_classes_types_A_const_124 *lang.Var

var A_arbace_classes_types_A_const_125 *lang.Var

var A_arbace_classes_types_A_init jrt.ClassInit

func A_arbace_classes_types_A_Init() { if !A_arbace_classes_types_A_init.Done() { A_arbace_classes_types_A_init.Run(A_arbace_classes_types_A_clinit) } }

func A_arbace_classes_types_A_clinit() { A_arbace_classes_types_A_clinit_p0(); A_arbace_classes_types_A_clinit_p1(); A_arbace_classes_types_A_clinit_p2(); A_arbace_classes_types_A_clinit_p3(); A_arbace_classes_types_A_clinit_p4(); A_arbace_classes_types_A_clinit_p5(); A_arbace_classes_types_A_clinit_p6(); A_arbace_classes_types_A_clinit_p7(); A_arbace_classes_types_A_clinit_p8(); A_arbace_classes_types_A_clinit_p9(); A_arbace_classes_types_A_clinit_p10() }

func A_arbace_classes_types_A_clinit_p0() { A_arbace_classes_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 162); A_arbace_classes_types_A_const_0 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[36]); A_arbace_classes_types_A_const_1 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[37]); A_arbace_classes_types_A_const_2 = A_arbace_classes_types_A_const_pool.A[38]; A_arbace_classes_types_A_const_3 = A_arbace_classes_types_A_const_pool.A[39]; A_arbace_classes_types_A_const_4 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[40]); A_arbace_classes_types_A_const_5 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[41]); A_arbace_classes_types_A_const_6 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[42]); A_arbace_classes_types_A_const_7 = A_arbace_classes_types_A_const_pool.A[43]; A_arbace_classes_types_A_const_8 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[44]); A_arbace_classes_types_A_const_9 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[45]); A_arbace_classes_types_A_const_10 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[46]); A_arbace_classes_types_A_const_11 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[47]) }

func A_arbace_classes_types_A_clinit_p1() { A_arbace_classes_types_A_const_12 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[48]); A_arbace_classes_types_A_const_13 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[49]); A_arbace_classes_types_A_const_14 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[50]); A_arbace_classes_types_A_const_15 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[51]); A_arbace_classes_types_A_const_16 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[52]); A_arbace_classes_types_A_const_17 = A_arbace_classes_types_A_const_pool.A[53]; A_arbace_classes_types_A_const_18 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[54]); A_arbace_classes_types_A_const_19 = A_arbace_classes_types_A_const_pool.A[55]; A_arbace_classes_types_A_const_20 = A_arbace_classes_types_A_const_pool.A[56]; A_arbace_classes_types_A_const_21 = A_arbace_classes_types_A_const_pool.A[57]; A_arbace_classes_types_A_const_22 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[58]); A_arbace_classes_types_A_const_23 = A_arbace_classes_types_A_const_pool.A[59]; A_arbace_classes_types_A_const_24 = A_arbace_classes_types_A_const_pool.A[60] }

func A_arbace_classes_types_A_clinit_p2() { A_arbace_classes_types_A_const_25 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[61]); A_arbace_classes_types_A_const_26 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[62]); A_arbace_classes_types_A_const_27 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[63]); A_arbace_classes_types_A_const_28 = A_arbace_classes_types_A_const_pool.A[64]; A_arbace_classes_types_A_const_29 = A_arbace_classes_types_A_const_pool.A[65]; A_arbace_classes_types_A_const_30 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[66]); A_arbace_classes_types_A_const_31 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[67]); A_arbace_classes_types_A_const_32 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[68]); A_arbace_classes_types_A_const_33 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[69]); A_arbace_classes_types_A_const_34 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[70]); A_arbace_classes_types_A_const_35 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[71]); A_arbace_classes_types_A_const_36 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[72]) }

func A_arbace_classes_types_A_clinit_p3() { A_arbace_classes_types_A_const_37 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[73]); A_arbace_classes_types_A_const_38 = A_arbace_classes_types_A_const_pool.A[74]; A_arbace_classes_types_A_const_39 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[75]); A_arbace_classes_types_A_const_40 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[76]); A_arbace_classes_types_A_const_41 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[77]); A_arbace_classes_types_A_const_42 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[78]); A_arbace_classes_types_A_const_43 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[79]); A_arbace_classes_types_A_const_44 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[80]); A_arbace_classes_types_A_const_45 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[81]); A_arbace_classes_types_A_const_46 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[82]); A_arbace_classes_types_A_const_47 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[83]); A_arbace_classes_types_A_const_48 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[84]) }

func A_arbace_classes_types_A_clinit_p4() { A_arbace_classes_types_A_const_49 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[85]); A_arbace_classes_types_A_const_50 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[86]); A_arbace_classes_types_A_const_51 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[87]); A_arbace_classes_types_A_const_52 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[88]); A_arbace_classes_types_A_const_53 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[89]); A_arbace_classes_types_A_const_54 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[90]); A_arbace_classes_types_A_const_55 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[91]); A_arbace_classes_types_A_const_56 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[92]); A_arbace_classes_types_A_const_57 = A_arbace_classes_types_A_const_pool.A[93]; A_arbace_classes_types_A_const_58 = A_arbace_classes_types_A_const_pool.A[94]; A_arbace_classes_types_A_const_59 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[95]); A_arbace_classes_types_A_const_60 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[96]) }

func A_arbace_classes_types_A_clinit_p5() { A_arbace_classes_types_A_const_61 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[97]); A_arbace_classes_types_A_const_62 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[98]); A_arbace_classes_types_A_const_63 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[99]); A_arbace_classes_types_A_const_64 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[100]); A_arbace_classes_types_A_const_65 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[101]); A_arbace_classes_types_A_const_66 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[102]); A_arbace_classes_types_A_const_67 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[103]); A_arbace_classes_types_A_const_68 = A_arbace_classes_types_A_const_pool.A[104]; A_arbace_classes_types_A_const_69 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[105]); A_arbace_classes_types_A_const_70 = A_arbace_classes_types_A_const_pool.A[106]; A_arbace_classes_types_A_const_71 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[107]); A_arbace_classes_types_A_const_72 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[108]) }

func A_arbace_classes_types_A_clinit_p6() { A_arbace_classes_types_A_const_73 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[109]); A_arbace_classes_types_A_const_74 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[110]); A_arbace_classes_types_A_const_75 = A_arbace_classes_types_A_const_pool.A[111]; A_arbace_classes_types_A_const_76 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[112]); A_arbace_classes_types_A_const_77 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[113]); A_arbace_classes_types_A_const_78 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[114]); A_arbace_classes_types_A_const_79 = A_arbace_classes_types_A_const_pool.A[115]; A_arbace_classes_types_A_const_80 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[116]); A_arbace_classes_types_A_const_81 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[117]); A_arbace_classes_types_A_const_82 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[118]); A_arbace_classes_types_A_const_83 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[119]); A_arbace_classes_types_A_const_84 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[120]) }

func A_arbace_classes_types_A_clinit_p7() { A_arbace_classes_types_A_const_85 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[121]); A_arbace_classes_types_A_const_86 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[122]); A_arbace_classes_types_A_const_87 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[123]); A_arbace_classes_types_A_const_88 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[124]); A_arbace_classes_types_A_const_89 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[125]); A_arbace_classes_types_A_const_90 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[126]); A_arbace_classes_types_A_const_91 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[127]); A_arbace_classes_types_A_const_92 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[128]); A_arbace_classes_types_A_const_93 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[129]); A_arbace_classes_types_A_const_94 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[130]); A_arbace_classes_types_A_const_95 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[131]); A_arbace_classes_types_A_const_96 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[132]) }

func A_arbace_classes_types_A_clinit_p8() { A_arbace_classes_types_A_const_97 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[133]); A_arbace_classes_types_A_const_98 = A_arbace_classes_types_A_const_pool.A[134]; A_arbace_classes_types_A_const_99 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[135]); A_arbace_classes_types_A_const_100 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[136]); A_arbace_classes_types_A_const_101 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[137]); A_arbace_classes_types_A_const_102 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[138]); A_arbace_classes_types_A_const_103 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[139]); A_arbace_classes_types_A_const_104 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[140]); A_arbace_classes_types_A_const_105 = A_arbace_classes_types_A_const_pool.A[141]; A_arbace_classes_types_A_const_106 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[142]); A_arbace_classes_types_A_const_107 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[143]); A_arbace_classes_types_A_const_108 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[144]) }

func A_arbace_classes_types_A_clinit_p9() { A_arbace_classes_types_A_const_109 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[145]); A_arbace_classes_types_A_const_110 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[146]); A_arbace_classes_types_A_const_111 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[147]); A_arbace_classes_types_A_const_112 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[148]); A_arbace_classes_types_A_const_113 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[149]); A_arbace_classes_types_A_const_114 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[150]); A_arbace_classes_types_A_const_115 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[151]); A_arbace_classes_types_A_const_116 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[152]); A_arbace_classes_types_A_const_117 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[153]); A_arbace_classes_types_A_const_118 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[154]); A_arbace_classes_types_A_const_119 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[155]); A_arbace_classes_types_A_const_120 = A_arbace_classes_types_A_const_pool.A[156] }

func A_arbace_classes_types_A_clinit_p10() { A_arbace_classes_types_A_const_121 = jrt.Class_Cast(A_arbace_classes_types_A_const_pool.A[157]); A_arbace_classes_types_A_const_122 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[158]); A_arbace_classes_types_A_const_123 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[159]); A_arbace_classes_types_A_const_124 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[160]); A_arbace_classes_types_A_const_125 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[161]) }

func A_arbace_classes_types_A_New() *A_arbace_classes_types_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_A) Ctor() {}

func (t *A_arbace_classes_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_A_class }

func (t *A_arbace_classes_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_A); return ok }

func A_arbace_classes_types_A_Cast(x any) *A_arbace_classes_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_A_class)) }; return v }



type A_arbace_classes_types_array_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_array_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_A struct{ a2g_header uint64 }

var A_arbace_classes_types_array_dims_A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_fn__48000030_A struct{ a2g_header uint64 }

var A_arbace_classes_types_array_dims_fn__48000030_A_fn_class *jrt.Class



type A_arbace_classes_types_array_of_A struct{ a2g_header uint64 }

var A_arbace_classes_types_array_of_A_fn_class *jrt.Class



type A_arbace_classes_types_array_sym_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_array_sym_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_A struct{ a2g_header uint64 }

var A_arbace_classes_types_bounds_map_A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_fn__48000121_A struct{ a2g_header uint64 }

var A_arbace_classes_types_bounds_map_fn__48000121_A_fn_class *jrt.Class



type A_arbace_classes_types_class__GT_desc_A struct{ a2g_header uint64 }

var A_arbace_classes_types_class__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_class_desc_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_class_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_class_name_A struct{ a2g_header uint64 }

var A_arbace_classes_types_desc__GT_class_name_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_internal_A struct{ a2g_header uint64 }

var A_arbace_classes_types_desc__GT_internal_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_tnode_A struct{ a2g_header uint64 }

var A_arbace_classes_types_desc__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_elem_type_A struct{ a2g_header uint64 }

var A_arbace_classes_types_elem_type_A_fn_class *jrt.Class



type A_arbace_classes_types_element_path_A struct{ a2g_header uint64 }

var A_arbace_classes_types_element_path_A_fn_class *jrt.Class



type A_arbace_classes_types_erase_A struct{ a2g_header uint64 }

var A_arbace_classes_types_erase_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000004_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000004_A_New() *A_arbace_classes_types_eval48000004_A { t := &A_arbace_classes_types_eval48000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000004_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000004_A_class }

func (t *A_arbace_classes_types_eval48000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000004_A); return ok }

func A_arbace_classes_types_eval48000004_A_Cast(x any) *A_arbace_classes_types_eval48000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000004_A_class)) }; return v }



type A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A struct{ a2g_header uint64 }

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000008_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000008_A_New() *A_arbace_classes_types_eval48000008_A { t := &A_arbace_classes_types_eval48000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000008_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000008_A_class }

func (t *A_arbace_classes_types_eval48000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000008_A); return ok }

func A_arbace_classes_types_eval48000008_A_Cast(x any) *A_arbace_classes_types_eval48000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000008_A_class)) }; return v }



type A_arbace_classes_types_eval48000008_fn__48000009_A struct{ a2g_header uint64 }

var A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000013_A struct{ a2g_header uint64 }

var A_arbace_classes_types_fn__48000013_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000037_A struct{ a2g_header uint64 }

var A_arbace_classes_types_fn__48000037_A_fn_class *jrt.Class



type A_arbace_classes_types_generic_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_generic_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_int_like_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_int_like_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_internal__GT_desc_A struct{ a2g_header uint64 }

var A_arbace_classes_types_internal__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_class_A struct{ a2g_header uint64 }

var A_arbace_classes_types_lang_class_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_desc_A struct{ a2g_header uint64 }

var A_arbace_classes_types_lang_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_local_class_name_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_local_class_name_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_method_desc_A struct{ a2g_header uint64 }

var A_arbace_classes_types_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_numeric_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_package_of_A struct{ a2g_header uint64 }

var A_arbace_classes_types_package_of_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_A struct{ a2g_header uint64 }

var A_arbace_classes_types_parse_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000045_A struct{ a2g_header uint64; F_d, F_i any }

var A_arbace_classes_types_parse_method_desc_fn__48000045_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_A struct{ a2g_header uint64 }

var A_arbace_classes_types_parse_type_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000063_A struct{ a2g_header uint64 }

var A_arbace_classes_types_parse_type_fn__48000063_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000071_A struct{ a2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000071_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000073_A struct{ a2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000073_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A struct{ a2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000080_A struct{ a2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000080_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_p__48000066_A struct{ a2g_header uint64 }

var A_arbace_classes_types_parse_type_p__48000066_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_A struct{ a2g_header uint64 }

var A_arbace_classes_types_parse_type_params_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000093_A struct{ a2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000093_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A struct{ a2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_fn_class *jrt.Class



type A_arbace_classes_types_prim_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_prim_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_ref_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_ref_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_reflect__GT_tnode_A struct{ a2g_header uint64 }

var A_arbace_classes_types_reflect__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_signature_A struct{ a2g_header uint64 }

var A_arbace_classes_types_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_simple_name_of_A struct{ a2g_header uint64 }

var A_arbace_classes_types_simple_name_of_A_fn_class *jrt.Class



type A_arbace_classes_types_size_A struct{ a2g_header uint64 }

var A_arbace_classes_types_size_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_A struct{ a2g_header uint64 }

var A_arbace_classes_types_subst_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000134_A struct{ a2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000134_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000137_A struct{ a2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000137_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000139_A struct{ a2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000139_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000141_A struct{ a2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000141_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000143_A struct{ a2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000143_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_A struct{ a2g_header uint64 }

var A_arbace_classes_types_type_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000146_A struct{ a2g_header uint64 }

var A_arbace_classes_types_type_anns_walk__48000146_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A struct{ a2g_header uint64; F_path, F_walk any }

var A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_A struct{ a2g_header uint64 }

var A_arbace_classes_types_type_params_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A struct{ a2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A struct{ a2g_header uint64; F_interface_QMARK_, F_s__48000102, F_iter__48000101 any }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A struct{ a2g_header uint64; F_b__48000104, F_interface_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A struct{ a2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A struct{ a2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_fn_class *jrt.Class



type A_arbace_classes_types_void_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_types_void_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_A struct{ a2g_header uint64 }

var A_arbace_classes_types_with_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_fn__48000054_A struct{ a2g_header uint64 }

var A_arbace_classes_types_with_anns_fn__48000054_A_fn_class *jrt.Class
