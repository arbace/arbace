//line aot_arbace_classes_types.ae:1
package aot_arbace_classes_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New() *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_types_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_classes_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_types_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_types_eval48000008_fn__48000009_A_New() *A_arbace_classes_types_eval48000008_fn__48000009_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_eval48000008_fn__48000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_types_eval48000008_fn__48000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_classes_types_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_classes_types_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_types_A_const_7.GetRawRoot__O(), A_arbace_classes_types_A_const_8) }















func A_arbace_classes_types_fn__48000013_A_New() *A_arbace_classes_types_fn__48000013_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000013_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Ctor() {}
//line :17:1
func (t *A_arbace_classes_types_fn__48000013_A) Invoke_O_O__O(self, p__48000012__0 any) any { var vec__48000014__2 any = p__48000012__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000014__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_19 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = k__3; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_19, arg_22) }; return lang.Tuple_Create_O_O__IPersistentVector(v__4, tmp1) }













func A_arbace_classes_types_lang_class_A_New() *A_arbace_classes_types_lang_class_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_class_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Ctor() {}
//line :31:1
func (t *A_arbace_classes_types_lang_class_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0)).Ref() }
func A_arbace_classes_types_lang_desc_A_New() *A_arbace_classes_types_lang_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_lang_desc_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Ctor() {}
//line :32:1
func (t *A_arbace_classes_types_lang_desc_A) Invoke_O_O__O(self, simple__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_5, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_classes_types_A_const_10.GetRawRoot__O(), nil, simple__0, nil)).Ref() }

func A_arbace_classes_types_prim_QMARK__A_New() *A_arbace_classes_types_prim_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_prim_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_classes_types_prim_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_23 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = t__0; if linked_24 == nil { and__1927000168__auto____2 = ifn_25.Invoke_O__O(arg_26) } else { and__1927000168__auto____2 = linked_24.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_23, arg_26) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(t__0))); if and__1927000168__auto____3 { var root_27 any = A_arbace_classes_types_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = t__0; var arg_31 any = Lit_8; if linked_28 == nil { return ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { return linked_28.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_27, arg_30, arg_31) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_void_QMARK__A_New() *A_arbace_classes_types_void_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_void_QMARK__A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Ctor() {}
//line :35:1
func (t *A_arbace_classes_types_void_QMARK__A) Invoke_O_O__O(self, t__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8)).Ref() }
func A_arbace_classes_types_array_QMARK__A_New() *A_arbace_classes_types_array_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_classes_types_array_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_32 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = t__0; if linked_33 == nil { and__1927000168__auto____2 = ifn_34.Invoke_O__O(arg_35) } else { and__1927000168__auto____2 = linked_33.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_36 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = t__0; var arg_40 any = Lit_1; if linked_37 == nil { return ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { return linked_37.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) } } else { return and__1927000168__auto____2 } }
func A_arbace_classes_types_ref_QMARK__A_New() *A_arbace_classes_types_ref_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_ref_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_types_ref_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, A_arbace_classes_types_A_const_14); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var and__1927000168__auto____3 any; var root_41 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = t__0; if linked_42 == nil { and__1927000168__auto____3 = ifn_43.Invoke_O__O(arg_44) } else { and__1927000168__auto____3 = linked_42.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_45 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = t__0; var arg_49 any = Lit_6; if linked_46 == nil { or__1927000174__auto____4 = ifn_47.Invoke_O_O__O(arg_48, arg_49) } else { or__1927000174__auto____4 = linked_46.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_45, arg_48, arg_49) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_50 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = t__0; if linked_51 == nil { return ifn_52.Invoke_O__O(arg_53) } else { return linked_51.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_50, arg_53) } } } else { return and__1927000168__auto____3 } } }
func A_arbace_classes_types_class_desc_QMARK__A_New() *A_arbace_classes_types_class_desc_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class_desc_QMARK__A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_types_class_desc_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_54 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = t__0; if linked_55 == nil { and__1927000168__auto____2 = ifn_56.Invoke_O__O(arg_57) } else { and__1927000168__auto____2 = linked_55.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_54, arg_57) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_58 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = t__0; var arg_62 any = Lit_6; if linked_59 == nil { return ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { return linked_59.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_58, arg_61, arg_62) } } else { return and__1927000168__auto____2 } }

func A_arbace_classes_types_internal__GT_desc_A_New() *A_arbace_classes_types_internal__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_internal__GT_desc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_types_internal__GT_desc_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var root_63 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = n__0; var arg_67 any = Lit_1; if linked_64 == nil { tmp1 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { tmp1 = linked_64.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if jrt.J2g_Truth(tmp1) { return n__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref() } }
func A_arbace_classes_types_desc__GT_internal_A_New() *A_arbace_classes_types_desc__GT_internal_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_internal_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Ctor() {}
//line :41:1
func (t *A_arbace_classes_types_desc__GT_internal_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_68 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = d__0; var arg_72 any = Lit_6; if linked_69 == nil { tmp1 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp1 = linked_69.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; if jrt.J2g_Truth(tmp1) { var root_73 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = d__0; var arg_77 any = A_arbace_classes_types_A_const_17; var arg_78 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(d__0)))).Ref(); if linked_74 == nil { return ifn_75.Invoke_O_O_O__O(arg_76, arg_77, arg_78) } else { return linked_74.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_73, arg_76, arg_77, arg_78) } } else { return d__0
	} }
func A_arbace_classes_types_elem_type_A_New() *A_arbace_classes_types_elem_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_elem_type_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_types_elem_type_A) Invoke_O_O__O(self, d__0 any) any { var root_79 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = d__0; var arg_83 any = A_arbace_classes_types_A_const_17; if linked_80 == nil { return ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { return linked_80.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) } }
func A_arbace_classes_types_array_of_A_New() *A_arbace_classes_types_array_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_of_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_types_array_of_A) Invoke_O_O__O(self, d__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__0)).Ref() }
func A_arbace_classes_types_array_dims_A_New() *A_arbace_classes_types_array_dims_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 any; var root_85 any = A_arbace_classes_types_A_const_18.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any; var tmp2 any = A_arbace_classes_types_array_dims_fn__48000030_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_classes_types_array_dims_fn__48000030_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_types_array_dims_fn__48000030_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; arg_88 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_89 any = d__0; if linked_86 == nil { tmp1 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { tmp1 = linked_86.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref() }
//line :48:1
func A_arbace_classes_types_array_dims_fn__48000030_A_New() *A_arbace_classes_types_array_dims_fn__48000030_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_dims_fn__48000030_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Ctor() {}
//line :48:1
func (t *A_arbace_classes_types_array_dims_fn__48000030_A) Invoke_O_O__O(self, p1__48000029_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_19, p1__48000029_SHARP___1)).Ref() }

func A_arbace_classes_types_size_A_New() *A_arbace_classes_types_size_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_size_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_classes_types_size_A) Ctor() {}
//line :50:1
func (t *A_arbace_classes_types_size_A) Invoke_O_O__O(self, t__0 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_46); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_47) }; if tmp1 { return A_arbace_classes_types_A_const_20 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__0, Lit_8) { return A_arbace_classes_types_A_const_21 } else { return A_arbace_classes_types_A_const_17 } } }

func A_arbace_classes_types_int_like_QMARK__A_New() *A_arbace_classes_types_int_like_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_int_like_QMARK__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Ctor() {}
//line :52:1
func (t *A_arbace_classes_types_int_like_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_90 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_classes_types_A_const_23; var arg_94 any = t__0; if linked_91 == nil { return ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { return linked_91.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_90, arg_93, arg_94) } }
func A_arbace_classes_types_numeric_QMARK__A_New() *A_arbace_classes_types_numeric_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_classes_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_95 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = A_arbace_classes_types_A_const_24; var arg_99 any = t__0; if linked_96 == nil { return ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { return linked_96.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_95, arg_98, arg_99) } }




func A_arbace_classes_types_fn__48000037_A_New() *A_arbace_classes_types_fn__48000037_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_fn__48000037_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Ctor() {}
//line :58:1
func (t *A_arbace_classes_types_fn__48000037_A) Invoke_O_O__O(self, p__48000036__0 any) any { var vec__48000038__2 any = p__48000036__0; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_100 any = A_arbace_classes_types_A_const_25.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = v__4; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_100, arg_103) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, k__3) }

func A_arbace_classes_types_method_desc_A_New() *A_arbace_classes_types_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_method_desc_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_types_method_desc_A) Invoke_O_O_O__O(self, params__0, ret__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13, nil); var tmp2 any; var root_104 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_108 any = params__0; if linked_105 == nil { tmp2 = ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { tmp2 = linked_105.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, ret__1)).Ref() }






func A_arbace_classes_types_parse_method_desc_A_New() *A_arbace_classes_types_parse_method_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Ctor() {}
//line :67:1
func (t *A_arbace_classes_types_parse_method_desc_A) Invoke_O_O__O(self, d__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Get_O__O(d__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var r__3 any; var tmp1 any = A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class
		if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class = fncls__132d; tmp2 = fncls__132d } else { tmp2 = fncls__132 }; r__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()





		jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_types_A_const_28.GetRawRoot__O())).Put_O_O__O(d__0, r__3)
//line :70:1
		return r__3 } }
func A_arbace_classes_types_parse_method_desc_fn__48000043_A_New_O(p0 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :71:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_A) Invoke_O__O(self any) any { { var i__1 any = lang.RT_Box_J__Number_NoInit(1); var ps__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_29)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))) { var tmp2 any; var root_116 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_118 lang.IFn
													if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = t.F_d; var arg_120 any; var na_114 any = i__1; if jrt.Long_InstanceOf(na_114) { var n0_115 int64 = jrt.NN(jrt.Long_Cast(na_114)).LongValue__J(); if n0_115 == 9223372036854775807 { arg_120 = lang.Numbers_Inc_O__Number_NoInit(na_114) } else { arg_120 = jrt.Long_ValueOf_J__Long_NoInit(n0_115 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_114) { var n0_115_2 float64 = jrt.NN(jrt.Double_Cast(na_114)).DoubleValue__D(); arg_120 = jrt.Double_ValueOf_D__Double_NoInit(n0_115_2 + 1.0).Ref() } else { arg_120 = lang.Numbers_Inc_O__Number_NoInit(na_114) } }; if linked_117 == nil { tmp2 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp2 = linked_117.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) }
//line :72:1
		return lang.Tuple_Create_O_O__IPersistentVector(ps__2, tmp2) } else { var j__3 any; var tmp3 any = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(t.F_d, i__1); var tmp4 *jrt.Class
			var fncls__111 /*line :72:1*/*jrt.Class = A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class

			if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class = fncls__111d; tmp4 = fncls__111d } else { tmp4 = fncls__111 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :72:1
			var end__4 any; var tmp5 *jrt.String = jrt.String_Cast(t.F_d)


			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_30)).CharValue__C(), jrt.NN(tmp5).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__3))) { var tmp6 *jrt.String = jrt.String_Cast(t.F_d); end__4 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(tmp6).IndexOf_String_I__I(Lit_7, lang.RT_IntCast_O__I_NoInit(j__3))))).Ref() } else { var na_112 any = j__3; if jrt.Long_InstanceOf(na_112) { var n0_113 int64 = jrt.NN(jrt.Long_Cast(na_112)).LongValue__J(); if n0_113 == 9223372036854775807 { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_112) } else { end__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_113 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_112) { var n0_113_2 float64 = jrt.NN(jrt.Double_Cast(na_112)).DoubleValue__D(); end__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_113_2 + 1.0).Ref() } else { end__4 = lang.Numbers_Inc_O__Number_NoInit(na_112) } } }
			var tmp7 any; var root_127 any = A_arbace_classes_types_A_const_7.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = ps__2; var arg_131 any; var root_121 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = t.F_d; var arg_125 any = i__1; var arg_126 any = end__4; if linked_122 == nil { arg_131 = ifn_123.Invoke_O_O_O__O(arg_124, arg_125, arg_126) } else { arg_131 = linked_122.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_121, arg_124, arg_125, arg_126) }; if linked_128 == nil { tmp7 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp7 = linked_128.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; i__1, ps__2 = end__4, tmp7; continue L1 } } }; /*line :71:1*/panic("j2g: unreachable") }


func A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_New_O_O(p0, p1 any) *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Ctor_O_O(c__d, c__i any) { t.F_d = c__d; t.F_i = c__i }
//line :74:1
func (t *A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 *jrt.String = jrt.String_Cast(t.F_d); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_classes_types_A_const_19)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) { var tmp2 jrt.Number_I; var na_109 any = j__1; if jrt.Long_InstanceOf(na_109) { var n0_110 int64 = jrt.NN(jrt.Long_Cast(na_109)).LongValue__J(); if n0_110 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_109) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_110 + 1)) } } else { if jrt.Double_InstanceOf(na_109) { var n0_110_2 float64 = jrt.NN(jrt.Double_Cast(na_109)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_110_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_109) } }; j__1 = tmp2; continue L1 } else { return j__1 } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_package_of_A_New() *A_arbace_classes_types_package_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_package_of_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_types_package_of_A) Invoke_O_O__O(self, internal__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5); if
											lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_9 } else { var root_133 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = internal__0; var arg_137 any = A_arbace_classes_types_A_const_21; var arg_138 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_134 == nil { return ifn_135.Invoke_O_O_O__O(arg_136, arg_137, arg_138) } else { return linked_134.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_133, arg_136, arg_137, arg_138) } } }

func A_arbace_classes_types_simple_name_of_A_New() *A_arbace_classes_types_simple_name_of_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_simple_name_of_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Ctor() {}
//line :83:1
func (t *A_arbace_classes_types_simple_name_of_A) Invoke_O_O__O(self, internal__0 any) any { var n__2 any; var root_139 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_141 lang.IFn; if
												linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = internal__0; var arg_143 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_5)))).Ref(); if linked_140 == nil { n__2 = ifn_141.Invoke_O_O__O(arg_142, arg_143) } else { n__2 = linked_140.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_139, arg_142, arg_143) }; var root_144 any =
												A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = n__2; var arg_148 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(n__2)).LastIndexOf_String__I(Lit_11)))).Ref(); if linked_145 == nil { return ifn_146.Invoke_O_O__O(arg_147, arg_148) } else { return linked_145.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_144, arg_147, arg_148) } }

func A_arbace_classes_types_desc__GT_class_name_A_New() *A_arbace_classes_types_desc__GT_class_name_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_class_name_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Ctor() {}
//line :87:1
func (t *A_arbace_classes_types_desc__GT_class_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_149 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = d__0; if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_149, arg_152) }; if jrt.J2g_Truth(tmp1) { var root_153 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = d__0; var arg_157 any = Lit_5; var arg_158 any = Lit_4; if linked_154 == nil { return ifn_155.Invoke_O_O_O__O(arg_156, arg_157, arg_158) } else { return linked_154.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_153, arg_156, arg_157, arg_158) } } else { if A_arbace_classes_types_A_const_32 != nil {
		var root_163 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var root_159 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = d__0; if linked_160 == nil { arg_166 = ifn_161.Invoke_O__O(arg_162) } else { arg_166 = linked_160.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_159, arg_162) }; var arg_167 any = Lit_5; var arg_168 any = Lit_4; if linked_164 == nil { return ifn_165.Invoke_O_O_O__O(arg_166, arg_167, arg_168) } else { return linked_164.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_163, arg_166, arg_167, arg_168) } } else {
//line :90:1
			return nil
		}
	} }
func A_arbace_classes_types_class__GT_desc_A_New() *A_arbace_classes_types_class__GT_desc_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_class__GT_desc_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Ctor() {}
//line :93:1
func (t *A_arbace_classes_types_class__GT_desc_A) Invoke_O_O__O(self, c__0 any) any {
	if jrt.NN(jrt.Class_Cast(c__0)).IsPrimitive__Z() { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()); var tmp2 any; var root_181 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); if linked_182 == nil { tmp2 = ifn_183.Invoke_O__O(arg_184) } else { tmp2 = linked_182.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_181, arg_184) }; return tmp1.Invoke_O__O(tmp2) } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {
		var root_169 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_173 any = Lit_4; var arg_174 any = Lit_5; if linked_170 == nil { return ifn_171.Invoke_O_O_O__O(arg_172, arg_173, arg_174) } else { return linked_170.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_169, arg_172, arg_173, arg_174) } } else {
//line :94:1
			if A_arbace_classes_types_A_const_32 != nil {

				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7); var tmp4 any; var root_175 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_179 any = Lit_4; var arg_180 any = Lit_5; if linked_176 == nil { tmp4 = ifn_177.Invoke_O_O_O__O(arg_178, arg_179, arg_180) } else { tmp4 = linked_176.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_175, arg_178, arg_179, arg_180) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil)).Ref() } else {
//line :94:1
					return nil
				}
		}
	}
}











func A_arbace_classes_types_array_sym_QMARK__A_New() *A_arbace_classes_types_array_sym_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_array_sym_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_classes_types_array_sym_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any; var root_185 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_187 lang.IFn; if
											linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = s__0; if linked_186 == nil { and__1927000168__auto____2 = ifn_187.Invoke_O__O(arg_188) } else { and__1927000168__auto____2 = linked_186.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_185, arg_188) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_189 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__0; if linked_190 == nil { and__1927000168__auto____3 = ifn_191.Invoke_O__O(arg_192) } else { and__1927000168__auto____3 = linked_190.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_197 any = A_arbace_classes_types_A_const_38.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = A_arbace_classes_types_A_const_39; var arg_201 any; var root_193 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = s__0; if linked_194 == nil { arg_201 = ifn_195.Invoke_O__O(arg_196) } else { arg_201 = linked_194.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_193, arg_196) }; if linked_198 == nil { return ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { return linked_198.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_classes_types_with_anns_A_New() *A_arbace_classes_types_with_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Ctor() {}
//line :115:1
func (t *A_arbace_classes_types_with_anns_A) Invoke_O_O_O__O(self, tn__0, form__1 any) any { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(form__1); var anns__4 any; if

	jrt.J2g_Truth(m__3) { var root_212 any = A_arbace_classes_types_A_const_40.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_216 any; var root_207 any = A_arbace_classes_types_A_const_41.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any; var tmp1 any = A_arbace_classes_types_with_anns_fn__48000056_A_New(); var tmp2 *jrt.Class; var fncls__206 *jrt.Class = A_arbace_classes_types_with_anns_fn__48000056_A_fn_class; if fncls__206 == nil { var fncls__206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_classes_types_with_anns_fn__48000056_A_fn_class = fncls__206d; tmp2 = fncls__206d } else { tmp2 = fncls__206 }; arg_210 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_211 any = m__3; if linked_208 == nil { arg_216 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { arg_216 = linked_208.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }; if linked_213 == nil { anns__4 = ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { anns__4 = linked_213.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) } } else { anns__4 = nil }; var tmp3 any; var root_217 any =
	A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = anns__4; if linked_218 == nil { tmp3 = ifn_219.Invoke_O__O(arg_220) } else { tmp3 = linked_218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_217, arg_220) }; if jrt.J2g_Truth(tmp3) { var root_221 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = tn__0; var arg_225 any = A_arbace_classes_types_A_const_44; var arg_226 any = anns__4; if linked_222 == nil { return ifn_223.Invoke_O_O_O__O(arg_224, arg_225, arg_226) } else { return linked_222.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_221, arg_224, arg_225, arg_226) } } else { return tn__0 } }
//line :117:1
func A_arbace_classes_types_with_anns_fn__48000056_A_New() *A_arbace_classes_types_with_anns_fn__48000056_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_with_anns_fn__48000056_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Ctor() {}
//line :117:1
func (t *A_arbace_classes_types_with_anns_fn__48000056_A) Invoke_O_O__O(self, p__48000055__1 any) any { var vec__48000057__2 any = p__48000055__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_202 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_204 lang.IFn; _ = ___4; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = k__3; if linked_203 == nil { return ifn_204.Invoke_O__O(arg_205) } else { return linked_203.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_202, arg_205) } }


func A_arbace_classes_types_parse_type_A_New() *A_arbace_classes_types_parse_type_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Ctor() {}
//line :120:1
func (t *A_arbace_classes_types_parse_type_A) Invoke_O_O_O__O(self, scope__0, form__1 any) any {



	var root_544 any = A_arbace_classes_types_A_const_45.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_classes_types_with_anns_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any; var tmp1 any; var and__1927000168__auto____3 any; var root_227 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_229 lang.IFn

	if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = form__1; if linked_228 == nil { and__1927000168__auto____3 = ifn_229.Invoke_O__O(arg_230) } else { and__1927000168__auto____3 = linked_228.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_227, arg_230) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any; var root_231 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = form__1; if linked_232 == nil { tmp2 = ifn_233.Invoke_O__O(arg_234) } else { tmp2 = linked_232.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_231, arg_234) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }
//line :125:1
	if jrt.J2g_Truth(tmp1) { var tmp3 any = A_arbace_classes_types_A_const_46; var tmp4 any = A_arbace_classes_types_A_const_47; var tmp5 any = A_arbace_classes_types_A_const_48; arg_547 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_classes_types_A_const_34.GetRawRoot__O()).Invoke_O__O(form__1))) } else { var tmp6 any; var root_235 any = A_arbace_classes_types_A_const_49.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_classes_types_array_sym_QMARK__A_fn_class); var ifn_237 lang.IFn



		if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = form__1; if linked_236 == nil { tmp6 = ifn_237.Invoke_O__O(arg_238) } else { tmp6 = linked_236.(*A_arbace_classes_types_array_sym_QMARK__A).Invoke_O_O__O(root_235, arg_238) }
//line :125:1
		if jrt.J2g_Truth(tmp6) { var base__3 any; var root_243 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_245 lang.IFn




			if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var root_239 any = A_arbace_classes_types_A_const_37.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = form__1; if linked_240 == nil { arg_246 = ifn_241.Invoke_O__O(arg_242) } else { arg_246 = linked_240.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_239, arg_242) }; if linked_244 == nil { base__3 = ifn_245.Invoke_O__O(arg_246) } else { base__3 = linked_244.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_243, arg_246) }
//line :125:1
			var n__4 any; var root_251 any = A_arbace_classes_types_A_const_50.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_parse_long_A_fn_class); var ifn_253 lang.IFn





			if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var root_247 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = form__1; if linked_248 == nil { arg_254 = ifn_249.Invoke_O__O(arg_250) } else { arg_254 = linked_248.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_247, arg_250) }; if linked_252 == nil { n__4 = ifn_253.Invoke_O__O(arg_254) } else { n__4 = linked_252.(*aot_arbace_core.A_arbace_core_parse_long_A).Invoke_O_O__O(root_251, arg_254) }
			var tmp7 any; var root_261 any = A_arbace_classes_types_A_const_51.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var tmp8 any = A_arbace_classes_types_parse_type_fn__48000065_A_New(); var tmp9 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000065_A_fn_class; if fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_classes_types_parse_type_fn__48000065_A_fn_class = fncls__255d; tmp9 = fncls__255d } else { tmp9 = fncls__255 }; arg_264 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_265 any; var root_256 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, A_arbace_classes_types_parse_type_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = scope__0; var arg_260 any = base__3; if linked_257 == nil { arg_265 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { arg_265 = linked_257.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }; if linked_262 == nil { tmp7 = ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { tmp7 = linked_262.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) }; arg_547 = lang.RT_Nth_O_I__O_NoInit(tmp7, lang.RT_IntCast_O__I_NoInit(n__4)) } else {
//line :125:1
				var tmp10 any; var and__1927000168__auto____3_2 any; var root_266 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_268 lang.IFn








				if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = form__1; if linked_267 == nil { and__1927000168__auto____3_2 = ifn_268.Invoke_O__O(arg_269) } else { and__1927000168__auto____3_2 = linked_267.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_266, arg_269) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp10 = lang.IFn_Cast(A_arbace_classes_types_A_const_55.GetRawRoot__O()).Invoke_O__O(form__1) } else { tmp10 = and__1927000168__auto____3_2 }
//line :125:1
				if jrt.J2g_Truth(tmp10) { var d__3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_55.GetRawRoot__O()).Invoke_O__O(form__1)










					if lang.Util_Equiv_O_O__Z_NoInit(d__3, Lit_17) { var tmp11 any = A_arbace_classes_types_A_const_46; var tmp12 any = A_arbace_classes_types_A_const_52; var tmp13 any = A_arbace_classes_types_A_const_53; arg_547 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, Lit_18, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())))) } else { var tmp14 any = A_arbace_classes_types_A_const_46; var tmp15 any = A_arbace_classes_types_A_const_52; var tmp16 any = A_arbace_classes_types_A_const_53; var tmp17 any = A_arbace_classes_types_A_const_46; var tmp18 any = A_arbace_classes_types_A_const_47; var tmp19 any = A_arbace_classes_types_A_const_48; var tmp20 any; var root_270 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_272 lang.IFn

						if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = d__3; var arg_274 any = A_arbace_classes_types_A_const_17; if linked_271 == nil { tmp20 = ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { tmp20 = linked_271.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) }
//line :136:1
						arg_547 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp20)))) } } else {
//line :125:1
							if lang.Util_Equiv_O_O__Z_NoInit(form__1, A_arbace_classes_types_A_const_59) { arg_547 = A_arbace_classes_types_A_const_60 } else { var tmp21 any; var and__1927000168__auto____3_3 any; var root_275 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_277 lang.IFn
















								if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = form__1; if linked_276 == nil { and__1927000168__auto____3_3 = ifn_277.Invoke_O__O(arg_278) } else { and__1927000168__auto____3_3 = linked_276.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_275, arg_278) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_279 any = A_arbace_classes_types_A_const_22.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_classes_types_A_const_61.Invoke_O__O(scope__0); var arg_283 any = form__1; if linked_280 == nil { tmp21 = ifn_281.Invoke_O_O__O(arg_282, arg_283) } else { tmp21 = linked_280.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_279, arg_282, arg_283) } } else { tmp21 = and__1927000168__auto____3_3 }
//line :125:1
								if jrt.J2g_Truth(tmp21) { arg_547 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_62, A_arbace_classes_types_A_const_63, form__1)) } else { var tmp22 any; var root_284 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_286 lang.IFn



















									if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = form__1; if linked_285 == nil { tmp22 = ifn_286.Invoke_O__O(arg_287) } else { tmp22 = linked_285.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_284, arg_287) }
//line :125:1
									if jrt.J2g_Truth(tmp22) { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_classes_types_A_const_64.Invoke_O__O(scope__0)).Invoke_O__O(form__1)




















										if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4_2 any = temp__1927000408__auto____3; var o__5 any; var temp__1927000414__auto____5 any = A_arbace_classes_types_A_const_65.Invoke_O__O(scope__0)
											if jrt.J2g_Truth(temp__1927000414__auto____5) { var f__6 any = temp__1927000414__auto____5; o__5 = lang.IFn_Cast(f__6).Invoke_O__O(n__4_2) } else { o__5 = nil }
//line :146:1
											var G__48000067__6_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, n__4_2, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref()))

											if jrt.J2g_Truth(o__5) { var root_288 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = G__48000067__6_; var arg_292 any = A_arbace_classes_types_A_const_66; var arg_293 any = o__5; if linked_289 == nil { arg_547 = ifn_290.Invoke_O_O_O__O(arg_291, arg_292, arg_293) } else { arg_547 = linked_289.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_288, arg_291, arg_292, arg_293) } } else { arg_547 = G__48000067__6_ } } else {
//line :146:1
												var tmp23 any; var root_294 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_296 lang.IFn


												if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var arg_298 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_68, form__1)); if linked_295 == nil { tmp23 = ifn_296.Invoke_O_O__O(arg_297, arg_298) } else { tmp23 = linked_295.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_294, arg_297, arg_298) }
//line :146:1
												panic(jrt.Thrown(jrt.Throwable_Cast(tmp23))) } } else {
//line :125:1
													var tmp24 any; var root_299 any = A_arbace_classes_types_A_const_11.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_301 lang.IFn

























													if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = form__1; if linked_300 == nil { tmp24 = ifn_301.Invoke_O__O(arg_302) } else { tmp24 = linked_300.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_299, arg_302) }
//line :125:1
													if jrt.J2g_Truth(tmp24) { var d__3_2 any; var root_303 any = A_arbace_classes_types_A_const_31.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_305 lang.IFn


























														if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = form__1; var arg_307 any = Lit_4; var arg_308 any = Lit_5; if linked_304 == nil { d__3_2 = ifn_305.Invoke_O_O_O__O(arg_306, arg_307, arg_308) } else { d__3_2 = linked_304.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_303, arg_306, arg_307, arg_308) }
														var tmp25 any; var root_309 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = d__3_2; var arg_313 any = Lit_1; if linked_310 == nil { tmp25 = ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { tmp25 = linked_310.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_309, arg_312, arg_313) }; if jrt.J2g_Truth(tmp25) { var body_p__4 *A_arbace_classes_types_parse_type_p__48000068_A = A_arbace_classes_types_parse_type_p__48000068_A_New(); var p__4 any; var tmp26 *jrt.Class; var fncls__333 *jrt.Class = A_arbace_classes_types_parse_type_p__48000068_A_fn_class; if fncls__333 == nil { var fncls__333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_types_parse_type_p__48000068_A_fn_class = fncls__333d; tmp26 = fncls__333d } else { tmp26 = fncls__333 }; p__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_p__4), tmp26, nil)



															arg_547 = lang.IFn_Cast(p__4).Invoke_O__O(d__3_2) } else {
																var root_338 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_classes_types_parse_type_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = scope__0; var arg_342 any; var root_334 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = form__1; if linked_335 == nil { arg_342 = ifn_336.Invoke_O__O(arg_337) } else { arg_342 = linked_335.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_334, arg_337) }; if linked_339 == nil { arg_547 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { arg_547 = linked_339.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) } } } else {
//line :125:1
																	var tmp27 any; var root_343 any = A_arbace_classes_types_A_const_69.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_class_QMARK__A_fn_class); var ifn_345 lang.IFn


































																	if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = form__1; if linked_344 == nil { tmp27 = ifn_345.Invoke_O__O(arg_346) } else { tmp27 = linked_344.(*aot_arbace_core.A_arbace_core_class_QMARK__A).Invoke_O_O__O(root_343, arg_346) }
//line :125:1
																	if jrt.J2g_Truth(tmp27) { var d__3_3 any; var root_347 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_349 lang.IFn


































																		if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = form__1; if linked_348 == nil { d__3_3 = ifn_349.Invoke_O__O(arg_350) } else { d__3_3 = linked_348.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_347, arg_350) }
																		var root_371 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, A_arbace_classes_types_parse_type_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = scope__0; var arg_375 any; var tmp28 any; var root_351 any = A_arbace_classes_types_A_const_71.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = d__3_3; if linked_352 == nil { tmp28 = ifn_353.Invoke_O__O(arg_354) } else { tmp28 = linked_352.(*A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_351, arg_354) }; if jrt.J2g_Truth(tmp28) { var root_355 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = lang.IFn_Cast(A_arbace_classes_types_A_const_72.GetRawRoot__O()).Invoke_O__O(d__3_3); if linked_356 == nil { arg_375 = ifn_357.Invoke_O__O(arg_358) } else { arg_375 = linked_356.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_355, arg_358) } } else {
																			var tmp29 any; var root_359 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = d__3_3; if linked_360 == nil { tmp29 = ifn_361.Invoke_O__O(arg_362) } else { tmp29 = linked_360.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_359, arg_362) }; if jrt.J2g_Truth(tmp29) { var root_363 any = A_arbace_classes_types_A_const_73.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, A_arbace_classes_types_desc__GT_class_name_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = d__3_3; if linked_364 == nil { arg_375 = ifn_365.Invoke_O__O(arg_366) } else { arg_375 = linked_364.(*A_arbace_classes_types_desc__GT_class_name_A).Invoke_O_O__O(root_363, arg_366) } } else { var root_367 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = jrt.NN(jrt.Class_Cast(form__1)).GetName__String().Ref(); if linked_368 == nil { arg_375 = ifn_369.Invoke_O__O(arg_370) } else { arg_375 = linked_368.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_367, arg_370) } } }
//line :161:1
																		if linked_372 == nil { arg_547 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { arg_547 = linked_372.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) } } else {
//line :125:1
																			var tmp30 any; var and__1927000168__auto____3_4 any; var root_376 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_378 lang.IFn






































																			if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = form__1; if linked_377 == nil { and__1927000168__auto____3_4 = ifn_378.Invoke_O__O(arg_379) } else { and__1927000168__auto____3_4 = linked_377.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_376, arg_379) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var tmp31 any = A_arbace_classes_types_A_const_75; var tmp32 any; var root_380 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = form__1; if linked_381 == nil { tmp32 = ifn_382.Invoke_O__O(arg_383) } else { tmp32 = linked_381.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_380, arg_383) }; tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp31, tmp32)).Ref() } else { tmp30 = and__1927000168__auto____3_4 }
//line :125:1
																			if jrt.J2g_Truth(tmp30) { var tmp33 any = A_arbace_classes_types_A_const_46; var tmp34 any = A_arbace_classes_types_A_const_52; var tmp35 any = A_arbace_classes_types_A_const_53; var tmp36 any; var root_388 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, A_arbace_classes_types_parse_type_A_fn_class); var ifn_390 lang.IFn







































																				if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = scope__0; var arg_392 any; var root_384 any = A_arbace_classes_types_A_const_77.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = form__1; if linked_385 == nil { arg_392 = ifn_386.Invoke_O__O(arg_387) } else { arg_392 = linked_385.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_384, arg_387) }; if linked_389 == nil { tmp36 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { tmp36 = linked_389.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }
//line :125:1
																				arg_547 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, tmp35, tmp36)) } else { var tmp37 any; var and__1927000168__auto____3_5 any; var root_393 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_395 lang.IFn









































																					if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = form__1; if linked_394 == nil { and__1927000168__auto____3_5 = ifn_395.Invoke_O__O(arg_396) } else { and__1927000168__auto____3_5 = linked_394.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_393, arg_396) }; if jrt.J2g_Truth(and__1927000168__auto____3_5) { var tmp38 any = A_arbace_classes_types_A_const_78; var tmp39 any; var root_397 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = form__1; if linked_398 == nil { tmp39 = ifn_399.Invoke_O__O(arg_400) } else { tmp39 = linked_398.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_397, arg_400) }; tmp37 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp38, tmp39)).Ref() } else { tmp37 = and__1927000168__auto____3_5 }
//line :125:1
																					if jrt.J2g_Truth(tmp37) { var vec__48000070__3 any = form__1; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(1), nil); var b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__48000070__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp40 any = A_arbace_classes_types_A_const_46; var tmp41 any = A_arbace_classes_types_A_const_79; var tmp42 any = A_arbace_classes_types_A_const_80; var tmp43 any; var root_405 any = A_arbace_classes_types_A_const_81.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_407 lang.IFn; _ = ___4











































																						if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any; var root_401 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = k__5; if linked_402 == nil { arg_408 = ifn_403.Invoke_O__O(arg_404) } else { arg_408 = linked_402.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_401, arg_404) }; if linked_406 == nil { tmp43 = ifn_407.Invoke_O__O(arg_408) } else { tmp43 = linked_406.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_405, arg_408) }
//line :125:1
																						var tmp44 any = tmp43; var tmp45 any = A_arbace_classes_types_A_const_82; var tmp46 any; var root_409 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_classes_types_parse_type_A_fn_class); var ifn_411 lang.IFn











































																						if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = scope__0; var arg_413 any = b__6; if linked_410 == nil { tmp46 = ifn_411.Invoke_O_O__O(arg_412, arg_413) } else { tmp46 = linked_410.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_409, arg_412, arg_413) }
//line :125:1
																						arg_547 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp41, tmp42, tmp44, tmp45, tmp46)) } else { var tmp47 any; var and__1927000168__auto____3_6 any; var root_414 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_416 lang.IFn













































																							if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = form__1; if linked_415 == nil { and__1927000168__auto____3_6 = ifn_416.Invoke_O__O(arg_417) } else { and__1927000168__auto____3_6 = linked_415.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_414, arg_417) }; if jrt.J2g_Truth(and__1927000168__auto____3_6) { var tmp48 any = A_arbace_classes_types_A_const_83; var tmp49 any; var root_418 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = form__1; if linked_419 == nil { tmp49 = ifn_420.Invoke_O__O(arg_421) } else { tmp49 = linked_419.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_418, arg_421) }; tmp47 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp48, tmp49)).Ref() } else { tmp47 = and__1927000168__auto____3_6 }
//line :125:1
																							if jrt.J2g_Truth(tmp47) { var tmp50 any = A_arbace_classes_types_A_const_46; var tmp51 any = A_arbace_classes_types_A_const_84; var tmp52 any = A_arbace_classes_types_A_const_85; var tmp53 any; var root_432 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_434 lang.IFn














































																								if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any; var tmp54 any = A_arbace_classes_types_parse_type_fn__48000073_A_New_O(scope__0); var tmp55 *jrt.Class; var fncls__427 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000073_A_fn_class; if fncls__427 == nil { var fncls__427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_types_parse_type_fn__48000073_A_fn_class = fncls__427d; tmp55 = fncls__427d } else { tmp55 = fncls__427 }; arg_435 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp54, tmp55, nil); var arg_436 any; var root_428 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = form__1; if linked_429 == nil { arg_436 = ifn_430.Invoke_O__O(arg_431) } else { arg_436 = linked_429.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_428, arg_431) }; if linked_433 == nil { tmp53 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { tmp53 = linked_433.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }
//line :125:1
																								arg_547 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp51, tmp52, tmp53)) } else { var tmp56 any; var and__1927000168__auto____3_7 any; var root_437 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_439 lang.IFn
















































																									if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = form__1; if linked_438 == nil { and__1927000168__auto____3_7 = ifn_439.Invoke_O__O(arg_440) } else { and__1927000168__auto____3_7 = linked_438.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_437, arg_440) }; if jrt.J2g_Truth(and__1927000168__auto____3_7) { var tmp57 any = A_arbace_classes_types_A_const_88; var tmp58 any; var root_441 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = form__1; if linked_442 == nil { tmp58 = ifn_443.Invoke_O__O(arg_444) } else { tmp58 = linked_442.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_441, arg_444) }; tmp56 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp57, tmp58)).Ref() } else { tmp56 = and__1927000168__auto____3_7 }
//line :125:1
																									if jrt.J2g_Truth(tmp56) {

















































																										var root_490 any = A_arbace_classes_types_A_const_89.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any; var tmp59 any = A_arbace_classes_types_parse_type_fn__48000075_A_New_O(scope__0); var tmp60 *jrt.Class; var fncls__476 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_A_fn_class; if fncls__476 == nil { var fncls__476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_types_parse_type_fn__48000075_A_fn_class = fncls__476d; tmp60 = fncls__476d } else { tmp60 = fncls__476 }; arg_493 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil); var arg_494 any; var root_481 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_classes_types_parse_type_A_fn_class); var ifn_483 lang.IFn



																										if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = scope__0; var arg_485 any; var root_477 any = A_arbace_classes_types_A_const_77.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = form__1; if linked_478 == nil { arg_485 = ifn_479.Invoke_O__O(arg_480) } else { arg_485 = linked_478.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_477, arg_480) }; if linked_482 == nil { arg_494 = ifn_483.Invoke_O_O__O(arg_484, arg_485) } else { arg_494 = linked_482.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_481, arg_484, arg_485) }
//line :175:1
																										var arg_495 any; var root_486 any = A_arbace_classes_types_A_const_91.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_488 lang.IFn




																										if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = form__1; if linked_487 == nil { arg_495 = ifn_488.Invoke_O__O(arg_489) } else { arg_495 = linked_487.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_486, arg_489) }
//line :175:1
																										if linked_491 == nil { arg_547 = ifn_492.Invoke_O_O_O__O(arg_493, arg_494, arg_495) } else { arg_547 = linked_491.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_490, arg_493, arg_494, arg_495) } } else {
//line :125:1
																											var tmp61 any; var root_496 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_498 lang.IFn
























































																											if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = form__1; if linked_497 == nil { tmp61 = ifn_498.Invoke_O__O(arg_499) } else { tmp61 = linked_497.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_496, arg_499) }
//line :125:1
																											if jrt.J2g_Truth(tmp61) { var c__3 any; var root_504 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, A_arbace_classes_types_parse_type_A_fn_class); var ifn_506 lang.IFn

























































																												if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = scope__0; var arg_508 any; var root_500 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = form__1; if linked_501 == nil { arg_508 = ifn_502.Invoke_O__O(arg_503) } else { arg_508 = linked_501.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_500, arg_503) }; if linked_505 == nil { c__3 = ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { c__3 = linked_505.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }
																												var tmp62 any = A_arbace_classes_types_A_const_56; if lang.Util_Equiv_O_O__Z_NoInit(tmp62, A_arbace_classes_types_A_const_46.Invoke_O__O(c__3)) { } else { var tmp63 any; var root_539 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, form__1)).Ref(); var arg_543 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_540 == nil { tmp63 = ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { tmp63 = linked_540.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp63))) }
																												var root_524 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = c__3; var arg_528 any = A_arbace_classes_types_A_const_58; var arg_529 any; var root_519 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var tmp64 any = A_arbace_classes_types_parse_type_fn__48000082_A_New_O(scope__0); var tmp65 *jrt.Class; var fncls__514 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000082_A_fn_class; if fncls__514 == nil { var fncls__514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_types_parse_type_fn__48000082_A_fn_class = fncls__514d; tmp65 = fncls__514d } else { tmp65 = fncls__514 }; arg_522 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil); var arg_523 any; var root_515 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = form__1; if linked_516 == nil { arg_523 = ifn_517.Invoke_O__O(arg_518) } else { arg_523 = linked_516.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_515, arg_518) }; if linked_520 == nil { arg_529 = ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { arg_529 = linked_520.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_519, arg_522, arg_523) }; if linked_525 == nil { arg_547 = ifn_526.Invoke_O_O_O__O(arg_527, arg_528, arg_529) } else { arg_547 = linked_525.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_524, arg_527, arg_528, arg_529) } } else {
//line :125:1
																													if A_arbace_classes_types_A_const_32 != nil { var tmp66 any; var root_534 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_536 lang.IFn





























































																														if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_types_A_const_92.GetRawRoot__O()).Invoke_O__O(form__1))).Ref(); var arg_538 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_68, form__1)); if linked_535 == nil { tmp66 = ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { tmp66 = linked_535.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) }
//line :125:1
																														panic(jrt.Thrown(jrt.Throwable_Cast(tmp66))) } else { arg_547 = nil } } } } } } } } } } } } } }
//line :124:1
	var arg_548 any = form__1; if linked_545 == nil { return ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { return linked_545.(*A_arbace_classes_types_with_anns_A).Invoke_O_O_O__O(root_544, arg_547, arg_548)
	}
}





func A_arbace_classes_types_parse_type_fn__48000065_A_New() *A_arbace_classes_types_parse_type_fn__48000065_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000065_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Ctor() {}
//line :132:1
func (t *A_arbace_classes_types_parse_type_fn__48000065_A) Invoke_O_O__O(self, e__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_52, A_arbace_classes_types_A_const_53, e__1)) }





















func A_arbace_classes_types_parse_type_p__48000068_A_New() *A_arbace_classes_types_parse_type_p__48000068_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_p__48000068_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Ctor() {}
//line :154:1
func (t *A_arbace_classes_types_parse_type_p__48000068_A) Invoke_O_O__O(self, d__1 any) any { var tmp1 any; var root_314 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = d__1; var arg_318 any = Lit_1; if linked_315 == nil { tmp1 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { tmp1 = linked_315.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_314, arg_317, arg_318) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_types_A_const_46; var tmp3 any = A_arbace_classes_types_A_const_52; var tmp4 any = A_arbace_classes_types_A_const_53; var tmp5 lang.IFn = lang.IFn_Cast(self); var tmp6 any; var root_328 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = d__1; var arg_332 any = A_arbace_classes_types_A_const_17; if linked_329 == nil { tmp6 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { tmp6 = linked_329.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5.Invoke_O__O(tmp6))) } else { var tmp7 any; var root_319 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_321 lang.IFn
												if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = d__1; var arg_323 any = Lit_6; if linked_320 == nil { tmp7 = ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { tmp7 = linked_320.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }
//line :154:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any = A_arbace_classes_types_A_const_46; var tmp9 any = A_arbace_classes_types_A_const_56; var tmp10 any = A_arbace_classes_types_A_const_57; var tmp11 any; var root_324 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_326 lang.IFn
		if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = d__1; if linked_325 == nil { tmp11 = ifn_326.Invoke_O__O(arg_327) } else { tmp11 = linked_325.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_324, arg_327) }
//line :154:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, tmp11, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__1)) } else { return nil } } } }

















func A_arbace_classes_types_parse_type_fn__48000073_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000073_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000073_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :172:1
func (t *A_arbace_classes_types_parse_type_fn__48000073_A) Invoke_O_O__O(self, p1__48000062_SHARP___1 any) any { var root_422 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, A_arbace_classes_types_parse_type_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = t.F_scope; var arg_426 any = p1__48000062_SHARP___1; if linked_423 == nil { return ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { return linked_423.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) } }


func A_arbace_classes_types_parse_type_fn__48000075_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_A{}; t.Ctor_O(p0); return t }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :175:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_A) Invoke_O_O_O__O(self, outer__1, f__2 any) any { var vec__48000076__3 any; var tmp1 any; var root_445 any = A_arbace_classes_types_A_const_74.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_447 lang.IFn; if
														linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = f__2; if linked_446 == nil { tmp1 = ifn_447.Invoke_O__O(arg_448) } else { tmp1 = linked_446.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_445, arg_448) }; if jrt.J2g_Truth(tmp1) { vec__48000076__3 = f__2 } else { vec__48000076__3 = lang.Tuple_Create_O__IPersistentVector(f__2) }; var seq__48000077__4 any; var root_449 any = /*line :175:1*/A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_451 lang.IFn; if
														linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = vec__48000076__3; if linked_450 == nil { seq__48000077__4 = ifn_451.Invoke_O__O(arg_452) } else { seq__48000077__4 = linked_450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_449, arg_452) }; var first__48000078__5 any; var root_453 any = /*line :175:1*/A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_455 lang.IFn; if
														linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = seq__48000077__4; if linked_454 == nil { first__48000078__5 = ifn_455.Invoke_O__O(arg_456) } else { first__48000078__5 = linked_454.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_453, arg_456) }; var seq__48000077__6 any; var root_457 any = /*line :175:1*/A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_459 lang.IFn; if
														linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = seq__48000077__4; if linked_458 == nil { seq__48000077__6 = ifn_459.Invoke_O__O(arg_460) } else { seq__48000077__6 = linked_458.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_457, arg_460) }; var c__7 any = first__48000078__5; var args__8 any = seq__48000077__6; var n__9 any; var tmp2 /*line :175:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil); var tmp3 any = A_arbace_classes_types_A_const_57.Invoke_O__O(outer__1); var tmp4 any; var root_461 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_463 lang.IFn; if

	linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = c__7; if linked_462 == nil { tmp4 = ifn_463.Invoke_O__O(arg_464) } else { tmp4 = linked_462.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_461, arg_464) }; n__9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref(); var tmp5 any = A_arbace_classes_types_A_const_46; var tmp6 any = A_arbace_classes_types_A_const_56; var tmp7 any = A_arbace_classes_types_A_const_57; var tmp8 any = A_arbace_classes_types_A_const_58; var tmp9 any; var root_471 any = /*line :175:1*/A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_473 lang.IFn; if


	linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any; var tmp10 any = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(t.F_scope); var tmp11 *jrt.Class; var fncls__470 *jrt.Class = A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class; if fncls__470 == nil { var fncls__470d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class = fncls__470d; tmp11 = fncls__470d } else { tmp11 = fncls__470 }; arg_474 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_475 any = args__8; if linked_472 == nil { tmp9 = ifn_473.Invoke_O_O__O(arg_474, arg_475) } else { tmp9 = linked_472.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_471, arg_474, arg_475) }; return /*line :175:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, n__9, tmp8, tmp9, A_arbace_classes_types_A_const_66, outer__1)) }


func A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :178:1
func (t *A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A) Invoke_O_O__O(self, p1__48000063_SHARP___1 any) any { var root_465 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, A_arbace_classes_types_parse_type_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = t.F_scope; var arg_469 any = p1__48000063_SHARP___1; if linked_466 == nil { return ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { return linked_466.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) } }






func A_arbace_classes_types_parse_type_fn__48000082_A_New_O(p0 any) *A_arbace_classes_types_parse_type_fn__48000082_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_fn__48000082_A{}; t.Ctor_O(p0); return t }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :185:1
func (t *A_arbace_classes_types_parse_type_fn__48000082_A) Invoke_O_O__O(self, p1__48000064_SHARP___1 any) any { var root_509 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, A_arbace_classes_types_parse_type_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = t.F_scope; var arg_513 any = p1__48000064_SHARP___1; if linked_510 == nil { return ifn_511.Invoke_O_O__O(arg_512, arg_513) } else { return linked_510.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_509, arg_512, arg_513) } }




func A_arbace_classes_types_erase_A_New() *A_arbace_classes_types_erase_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_erase_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_classes_types_erase_A) Ctor() {}
//line :190:1
func (t *A_arbace_classes_types_erase_A) Invoke_O_O_O__O(self, bounds__0, tn__1 any) any { var G__48000085__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000085__3_) >> 9 & 7 { case 0: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_79) {





		var tmp1 any = A_arbace_classes_types_A_const_93; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_80.Invoke_O__O(tn__1)) { var root_550 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, A_arbace_classes_types_erase_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = bounds__0; var arg_554 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1); if linked_551 == nil { return ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { return linked_551.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) } } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	case 1: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__1) }
//line :193:1
	case 2: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_56) {

		var root_555 any = A_arbace_classes_types_A_const_25.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__1); if linked_556 == nil { return ifn_557.Invoke_O__O(arg_558) } else { return linked_556.(*A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_555, arg_558) } }
//line :193:1
	case 3: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_84) {




		var root_563 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_classes_types_erase_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = bounds__0; var arg_567 any; var root_559 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = A_arbace_classes_types_A_const_85.Invoke_O__O(tn__1); if linked_560 == nil { arg_567 = ifn_561.Invoke_O__O(arg_562) } else { arg_567 = linked_560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_559, arg_562) }; if linked_564 == nil { return ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { return linked_564.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_563, arg_566, arg_567) } }
//line :193:1
	case 4: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_52) {


		var root_573 any = A_arbace_classes_types_A_const_96.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_classes_types_array_of_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var root_568 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_classes_types_erase_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = bounds__0; var arg_572 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1); if linked_569 == nil { arg_576 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { arg_576 = linked_569.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; if linked_574 == nil { return ifn_575.Invoke_O__O(arg_576) } else { return linked_574.(*A_arbace_classes_types_array_of_A).Invoke_O_O__O(root_573, arg_576) } }
//line :193:1
	case 7: if any(G__48000085__3_) == any(A_arbace_classes_types_A_const_62) { var temp__1927000408__auto____4 any; var root_577 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_579 lang.IFn



		if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = lang.RT_Get_O_O__O_NoInit(bounds__0, A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1)); if linked_578 == nil { temp__1927000408__auto____4 = ifn_579.Invoke_O__O(arg_580) } else { temp__1927000408__auto____4 = linked_578.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_577, arg_580) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var root_586 any = A_arbace_classes_types_A_const_94.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, A_arbace_classes_types_erase_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any; var root_581 any = A_arbace_classes_types_A_const_97.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = bounds__0; var arg_585 any = A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1); if linked_582 == nil { arg_589 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { arg_589 = linked_582.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }; var arg_590 any = b__5; if linked_587 == nil { return ifn_588.Invoke_O_O__O(arg_589, arg_590) } else { return linked_587.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(root_586, arg_589, arg_590) } } else { return A_arbace_classes_types_A_const_95.GetRawRoot__O() } }
//line :193:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000085__3_))))) }







func A_arbace_classes_types_generic_QMARK__A_New() *A_arbace_classes_types_generic_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_generic_QMARK__A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Ctor() {}
//line :201:1
func (t *A_arbace_classes_types_generic_QMARK__A) Invoke_O_O__O(self, tn__0 any) any { var G__48000087__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000087__2_) >> 9 & 7 { case 0: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_79) { return jrt.Boolean_TRUE.Ref() }; case 1: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_47) { return jrt.Boolean_FALSE.Ref() }; case 2: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_56) { var or__1927000174__auto____3 bool; var tmp1 any; var root_592 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_594 lang.IFn

		if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_593 == nil { tmp1 = ifn_594.Invoke_O__O(arg_595) } else { tmp1 = linked_593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_592, arg_595) }; or__1927000174__auto____3 = lang.RT_BooleanCast_O__Z_NoInit(tmp1); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp2 any; var and__1927000168__auto____4 any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_596 any = A_arbace_classes_types_A_const_98.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, A_arbace_classes_types_generic_QMARK__A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if linked_597 == nil { tmp2 = ifn_598.Invoke_O__O(arg_599) } else { tmp2 = linked_597.(*A_arbace_classes_types_generic_QMARK__A).Invoke_O_O__O(root_596, arg_599) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } }
//line :204:1
	case 3: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_84) { return jrt.Boolean_TRUE.Ref() }; case 4: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_52) {


		var root_600 any = A_arbace_classes_types_A_const_98.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, A_arbace_classes_types_generic_QMARK__A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0); if linked_601 == nil { return ifn_602.Invoke_O__O(arg_603) } else { return linked_601.(*A_arbace_classes_types_generic_QMARK__A).Invoke_O_O__O(root_600, arg_603) } }
//line :204:1
	case 7: if any(G__48000087__2_) == any(A_arbace_classes_types_A_const_62) { return jrt.Boolean_TRUE.Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000087__2_))))) }







func A_arbace_classes_types_local_class_name_QMARK__A_New() *A_arbace_classes_types_local_class_name_QMARK__A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_local_class_name_QMARK__A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Ctor() {}
//line :212:1
func (t *A_arbace_classes_types_local_class_name_QMARK__A) Invoke_O_O_O__O(self, n__0, outer__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = outer__1; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_604 any = A_arbace_classes_types_A_const_13.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = n__0; var arg_608 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, outer__1, nil)).Ref(); if linked_605 == nil { and__1927000168__auto____4 = ifn_606.Invoke_O_O__O(arg_607, arg_608) } else { and__1927000168__auto____4 = linked_605.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_604, arg_607, arg_608) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_614 any = A_arbace_classes_types_A_const_38.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = A_arbace_classes_types_A_const_99; var arg_618 any; var root_609 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = n__0; var arg_613 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(outer__1)))).Ref(); if linked_610 == nil { arg_618 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { arg_618 = linked_610.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }; if linked_615 == nil { tmp1 = ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { tmp1 = linked_615.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) } } else {
//line :216:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_types_signature_A_New() *A_arbace_classes_types_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_signature_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_classes_types_signature_A) Ctor() {}
//line :219:1
func (t *A_arbace_classes_types_signature_A) Invoke_O_O__O(self, tn__0 any) any { var G__48000090__2_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__0); switch


	lang.Util_Hash_O__I_NoInit(G__48000090__2_) >> 9 & 7 { case 0: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_79) { var G__48000091__3_ any = A_arbace_classes_types_A_const_80.Invoke_O__O(tn__0)









		switch lang.Util_Hash_O__I_NoInit(G__48000091__3_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, nil) { return Lit_40 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_100) {
			var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil); var tmp2 any; var root_621 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, A_arbace_classes_types_signature_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0); if linked_622 == nil { tmp2 = ifn_623.Invoke_O__O(arg_624) } else { tmp2 = linked_622.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_621, arg_624) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :232:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__48000091__3_, A_arbace_classes_types_A_const_93) { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil); var tmp4 any; var root_625 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, A_arbace_classes_types_signature_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_classes_types_A_const_82.Invoke_O__O(tn__0); if linked_626 == nil { tmp4 = ifn_627.Invoke_O__O(arg_628) } else { tmp4 = linked_626.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_625, arg_628) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000091__3_))))) }
//line :222:1
	case 1: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_47) {
		return A_arbace_classes_types_A_const_48.Invoke_O__O(tn__0) }
//line :222:1
	case 2: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_56) { var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any; var root_634 any = A_arbace_classes_types_A_const_102.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_636 lang.IFn

		if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any; var root_629 any = A_arbace_classes_types_A_const_103.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_classes_types_local_class_name_QMARK__A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var arg_633 any; var G__48000092__3_ any = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0); if lang.Util_Identical_O_O__Z_NoInit(G__48000092__3_, nil) { arg_633 = nil } else { arg_633 = A_arbace_classes_types_A_const_57.Invoke_O__O(G__48000092__3_) }; if linked_630 == nil { arg_637 = ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { arg_637 = linked_630.(*A_arbace_classes_types_local_class_name_QMARK__A).Invoke_O_O_O__O(root_629, arg_632, arg_633) }; if linked_635 == nil { and__1927000168__auto____3 = ifn_636.Invoke_O__O(arg_637) } else { and__1927000168__auto____3 = linked_635.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_634, arg_637) }; if jrt.J2g_Truth(and__1927000168__auto____3) { temp__1927000408__auto____3 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__0) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var o__4 any = temp__1927000408__auto____3; var os__5 any; var root_638 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, A_arbace_classes_types_signature_A_fn_class); var ifn_640 lang.IFn
			if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = o__4; if linked_639 == nil { os__5 = ifn_640.Invoke_O__O(arg_641) } else { os__5 = linked_639.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_638, arg_641) }
			var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_4, nil, nil, Lit_7); var tmp6 any; var root_642 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = os__5; var arg_646 any = A_arbace_classes_types_A_const_21; var arg_647 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(os__5)))).Ref(); if linked_643 == nil { tmp6 = ifn_644.Invoke_O_O_O__O(arg_645, arg_646, arg_647) } else { tmp6 = linked_643.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_642, arg_645, arg_646, arg_647) }; var tmp7 any = tmp6; var tmp8 any; var root_648 any = A_arbace_classes_types_A_const_16.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var arg_652 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_classes_types_A_const_57.Invoke_O__O(o__4))))).Ref(); if linked_649 == nil { tmp8 = ifn_650.Invoke_O_O__O(arg_651, arg_652) } else { tmp8 = linked_649.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_648, arg_651, arg_652) }; var tmp9 any = tmp8; var tmp10 *jrt.String; var tmp11 any; var root_653 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_655 lang.IFn
			if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_654 == nil { tmp11 = ifn_655.Invoke_O__O(arg_656) } else { tmp11 = linked_654.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_653, arg_656) }; if jrt.J2g_Truth(tmp11) { var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp13 any; var root_662 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_666 any; var root_657 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var arg_661 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_658 == nil { arg_666 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { arg_666 = linked_658.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }; if linked_663 == nil { tmp13 = ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { tmp13 = linked_663.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil)) } else { tmp10 = nil }
//line :226:1
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, tmp9, tmp10.Ref(), nil)).Ref() } else {

				var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil, nil, Lit_7); var tmp15 any = A_arbace_classes_types_A_const_57.Invoke_O__O(tn__0); var tmp16 *jrt.String; var tmp17 any; var root_667 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn
				if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_668 == nil { tmp17 = ifn_669.Invoke_O__O(arg_670) } else { tmp17 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(tmp17) { var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp19 any; var root_676 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_680 any; var root_671 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var arg_675 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__0); if linked_672 == nil { arg_680 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { arg_680 = linked_672.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; if linked_677 == nil { tmp19 = ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { tmp19 = linked_677.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_676, arg_679, arg_680) }; tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil)) } else { tmp16 = nil }
//line :228:1
				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, tmp16.Ref(), nil)).Ref() } }
//line :222:1
	case 3: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_84) {











		var root_685 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, A_arbace_classes_types_signature_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any; var root_681 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = A_arbace_classes_types_A_const_85.Invoke_O__O(tn__0); if linked_682 == nil { arg_688 = ifn_683.Invoke_O__O(arg_684) } else { arg_688 = linked_682.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_681, arg_684) }; if linked_686 == nil { return ifn_687.Invoke_O__O(arg_688) } else { return linked_686.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_685, arg_688) } }
//line :222:1
	case 4: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_52) {







		var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp21 any; var root_689 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, A_arbace_classes_types_signature_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__0); if linked_690 == nil { tmp21 = ifn_691.Invoke_O__O(arg_692) } else { tmp21 = linked_690.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_689, arg_692) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21)).Ref() }
//line :222:1
	case 7: if any(G__48000090__2_) == any(A_arbace_classes_types_A_const_62) {








		var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_7); var tmp23 any; var root_693 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = A_arbace_classes_types_A_const_63.Invoke_O__O(tn__0); if linked_694 == nil { tmp23 = ifn_695.Invoke_O__O(arg_696) } else { tmp23 = linked_694.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_693, arg_696) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, nil)).Ref() }
//line :222:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__48000090__2_))))) }













func A_arbace_classes_types_parse_type_params_A_New() *A_arbace_classes_types_parse_type_params_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Ctor() {}
//line :236:1
func (t *A_arbace_classes_types_parse_type_params_A) Invoke_O_O_O__O(self, scope__0, tps__1 any) any {




	var root_738 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any; var tmp1 any = A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(scope__0); var tmp2 *jrt.Class; var fncls__737 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class; if fncls__737 == nil { var fncls__737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class = fncls__737d; tmp2 = fncls__737d } else { tmp2 = fncls__737 }; arg_741 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_742 any = tps__1; if linked_739 == nil { return ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { return linked_739.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_738, arg_741, arg_742) } }
//line :241:1
func A_arbace_classes_types_parse_type_params_fn__48000095_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :241:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_A) Invoke_O_O__O(self, tp__1 any) any {
	var tmp1 any; var root_697 any = A_arbace_classes_types_A_const_36.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = tp__1; if linked_698 == nil { tmp1 = ifn_699.Invoke_O__O(arg_700) } else { tmp1 = linked_698.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_697, arg_700) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_classes_types_A_const_63; var tmp3 any = A_arbace_classes_types_A_const_105; var tmp4 any = lang.PersistentVector_EMPTY.Ref(); var tmp5 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tp__1, tmp3, tmp4, tmp5, lang.RT_Meta_O__IPersistentMap_NoInit(tp__1))) } else { var vec__48000096__2 any = tp__1; var seq__48000097__3 any; var root_701 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_703 lang.IFn

		if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = vec__48000096__2; if linked_702 == nil { seq__48000097__3 = ifn_703.Invoke_O__O(arg_704) } else { seq__48000097__3 = linked_702.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_701, arg_704) }
//line :242:1
		var first__48000098__4 any; var root_705 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_707 lang.IFn

		if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = seq__48000097__3; if linked_706 == nil { first__48000098__4 = ifn_707.Invoke_O__O(arg_708) } else { first__48000098__4 = linked_706.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_705, arg_708) }
//line :242:1
		var seq__48000097__5 any; var root_709 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_711 lang.IFn

		if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seq__48000097__3; if linked_710 == nil { seq__48000097__5 = ifn_711.Invoke_O__O(arg_712) } else { seq__48000097__5 = linked_710.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_709, arg_712) }
//line :242:1
		var s__6 any = first__48000098__4; var first__48000098__7 any; var root_713 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_715 lang.IFn

		if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq__48000097__5; if linked_714 == nil { first__48000098__7 = ifn_715.Invoke_O__O(arg_716) } else { first__48000098__7 = linked_714.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_713, arg_716) }
//line :242:1
		var seq__48000097__8 any; var root_717 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_719 lang.IFn

		if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq__48000097__5; if linked_718 == nil { seq__48000097__8 = ifn_719.Invoke_O__O(arg_720) } else { seq__48000097__8 = linked_718.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_717, arg_720) }
//line :242:1
		var kw__9 any = first__48000098__7
		var bs__10 any = seq__48000097__8

		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_classes_types_A_const_106, kw__9) { } else { var tmp6 any; var root_732 any = A_arbace_classes_types_A_const_67.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, tp__1)).Ref(); var arg_736 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_733 == nil { tmp6 = ifn_734.Invoke_O_O__O(arg_735, arg_736) } else { tmp6 = linked_733.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_732, arg_735, arg_736) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }
//line :242:1
		var tmp7 any = A_arbace_classes_types_A_const_63; var tmp8 any = A_arbace_classes_types_A_const_105; var tmp9 any; var root_727 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_729 lang.IFn



		if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any; var tmp10 any = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(t.F_scope); var tmp11 *jrt.Class; var fncls__726 *jrt.Class = A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class; if fncls__726 == nil { var fncls__726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class = fncls__726d; tmp11 = fncls__726d } else { tmp11 = fncls__726 }; arg_730 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_731 any = bs__10; if linked_728 == nil { tmp9 = ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { tmp9 = linked_728.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_727, arg_730, arg_731) }
//line :242:1
		var tmp12 any = tmp9; var tmp13 any = A_arbace_classes_types_A_const_44; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, s__6, tmp8, tmp12, tmp13, lang.RT_Meta_O__IPersistentMap_NoInit(s__6)))
	}
}

func A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_New_O(p0 any) *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Ctor_O(c__scope any) { t.F_scope = c__scope }
//line :246:1
func (t *A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A) Invoke_O_O__O(self, p1__48000094_SHARP___1 any) any { var root_721 any = A_arbace_classes_types_A_const_54.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, A_arbace_classes_types_parse_type_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = t.F_scope; var arg_725 any = p1__48000094_SHARP___1; if linked_722 == nil { return ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { return linked_722.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) } }


func A_arbace_classes_types_type_params_signature_A_New() *A_arbace_classes_types_type_params_signature_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Ctor() {}
//line :249:1
func (t *A_arbace_classes_types_type_params_signature_A) Invoke_O_O_O__O(self, interface_QMARK___0, tps__1 any) any {



	var tmp1 any; var root_743 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = tps__1; if linked_744 == nil { tmp1 = ifn_745.Invoke_O__O(arg_746) } else { tmp1 = linked_744.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_743, arg_746) }; if jrt.J2g_Truth(tmp1) { return Lit_9 } else {

		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_44); var tmp3 any; var root_896 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_898 lang.IFn
		if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_900 any; var iter__1927001039__auto____6 any; var tmp4 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(interface_QMARK___0); var tmp5 *jrt.Class; var fncls__895 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class
		if fncls__895 == nil { var fncls__895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class = fncls__895d; tmp5 = fncls__895d } else { tmp5 = fncls__895 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_900 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(tps__1)
//line :256:1
		if linked_897 == nil { tmp3 = ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { tmp3 = linked_897.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) }
//line :255:1
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()
	} }
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A) Invoke_O_O__O(self, s__48000104__1 any) any { var tmp1 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(self, t.F_interface_QMARK_, s__48000104__1); var tmp2 *jrt.Class; var fncls__894 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class; if fncls__894 == nil { var fncls__894d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class = fncls__894d; tmp2 = fncls__894d } else { tmp2 = fncls__894 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Ctor_O_O_O(c__iter__48000103, c__interface_QMARK_, c__s__48000104 any) { t.F_iter__48000103 = c__iter__48000103; t.F_interface_QMARK_ = c__interface_QMARK_; t.F_s__48000104 = c__s__48000104 }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A) Invoke_O__O(self any) any { { var s__48000104__1 any; var t_ any = t.F_s__48000104; t.F_s__48000104 = nil; s__48000104__1 = t_; for { var temp__1927000414__auto____2 any; var root_747 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = s__48000104__1; if linked_748 == nil { temp__1927000414__auto____2 = ifn_749.Invoke_O__O(arg_750) } else { temp__1927000414__auto____2 = linked_748.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_747, arg_750) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__48000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_751 any = A_arbace_classes_types_A_const_108.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = s__48000104__3; if linked_752 == nil { tmp1 = ifn_753.Invoke_O__O(arg_754) } else { tmp1 = linked_752.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_751, arg_754) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_755 any = A_arbace_classes_types_A_const_109.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = s__48000104__3; if linked_756 == nil { c__1927001037__auto____4 = ifn_757.Invoke_O__O(arg_758) } else { c__1927001037__auto____4 = linked_756.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_755, arg_758) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__48000106__6 any; var root_759 any = A_arbace_classes_types_A_const_110.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_760 == nil { b__48000106__6 = ifn_761.Invoke_O__O(arg_762) } else { b__48000106__6 = linked_760.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_759, arg_762) }; var tmp2 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(t.F_interface_QMARK_, b__48000106__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__813 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class; if fncls__813 == nil { var fncls__813d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class = fncls__813d; tmp3 = fncls__813d } else { tmp3 = fncls__813 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_822 any = A_arbace_classes_types_A_const_114.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any; var root_814 any = A_arbace_classes_types_A_const_115.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = b__48000106__6; if linked_815 == nil { arg_825 = ifn_816.Invoke_O__O(arg_817) } else { arg_825 = linked_815.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_814, arg_817) }; var arg_826 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); var tmp5 any; var root_818 any = A_arbace_classes_types_A_const_116.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = s__48000104__3; if linked_819 == nil { tmp5 = ifn_820.Invoke_O__O(arg_821) } else { tmp5 = linked_819.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_818, arg_821) }; arg_826 = tmp4.Invoke_O__O(tmp5); if linked_823 == nil { return ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { return linked_823.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_822, arg_825, arg_826) } } else { var root_831 any = A_arbace_classes_types_A_const_114.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var root_827 any = A_arbace_classes_types_A_const_115.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = b__48000106__6; if linked_828 == nil { arg_834 = ifn_829.Invoke_O__O(arg_830) } else { arg_834 = linked_828.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_827, arg_830) }; var arg_835 any; if linked_832 == nil { return ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { return linked_832.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } } } else { var map__48000115__4 any; var root_836 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = s__48000104__3; if linked_837 == nil { map__48000115__4 = ifn_838.Invoke_O__O(arg_839) } else { map__48000115__4 = linked_837.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_836, arg_839) }; var map__48000115__5 any; if lang.ISeq_InstanceOf(map__48000115__4) { var tmp6 any; var root_840 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = map__48000115__4; if linked_841 == nil { tmp6 = ifn_842.Invoke_O__O(arg_843) } else { tmp6 = linked_841.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_840, arg_843) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_844 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = map__48000115__4; if linked_845 == nil { tmp7 = ifn_846.Invoke_O__O(arg_847) } else { tmp7 = linked_845.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_844, arg_847) }; map__48000115__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp7, jrt.Object_class.ArrayClass())).Ref() } else { var tmp8 any; var root_848 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = map__48000115__4; if linked_849 == nil { tmp8 = ifn_850.Invoke_O__O(arg_851) } else { tmp8 = linked_849.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_848, arg_851) }; if jrt.J2g_Truth(tmp8) { var root_852 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = map__48000115__4; if linked_853 == nil { map__48000115__5 = ifn_854.Invoke_O__O(arg_855) } else { map__48000115__5 = linked_853.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_852, arg_855) } } else { map__48000115__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000115__5 = map__48000115__4 }; var sym__6 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_63); var bounds__7 any = lang.RT_Get_O_O__O_NoInit(map__48000115__5, A_arbace_classes_types_A_const_105); var root_889 any = A_arbace_classes_types_A_const_117.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp10 any; var root_856 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_858 lang.IFn
																if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = sym__6; if linked_857 == nil { tmp10 = ifn_858.Invoke_O__O(arg_859) } else { tmp10 = linked_857.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_856, arg_859) }; var tmp11 any = tmp10; var tmp12 any; var tmp13 any; var root_860 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_862 lang.IFn
																if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = bounds__7; if linked_861 == nil { tmp13 = ifn_862.Invoke_O__O(arg_863) } else { tmp13 = linked_861.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_860, arg_863) }; if jrt.J2g_Truth(tmp13) { tmp12 = Lit_58 } else {

		var root_880 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_884 any; var root_875 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_877 lang.IFn
		if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any; var tmp14 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(t.F_interface_QMARK_); var tmp15 *jrt.Class; var fncls__874 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class
		if fncls__874 == nil { var fncls__874d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class = fncls__874d; tmp15 = fncls__874d } else { tmp15 = fncls__874 }; arg_878 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)
//line :262:1
		var arg_879 any = bounds__7; if linked_876 == nil { arg_884 = ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { arg_884 = linked_876.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) }
//line :261:1
		if linked_881 == nil { tmp12 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { tmp12 = linked_881.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) } }
//line :258:1
	arg_892 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12)).Ref()
//line :257:1
	var arg_893 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__48000103); var tmp17 any; var root_885 any = A_arbace_classes_types_A_const_87.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = s__48000104__3; if linked_886 == nil { tmp17 = ifn_887.Invoke_O__O(arg_888) } else { tmp17 = linked_886.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_885, arg_888) }; arg_893 = tmp16.Invoke_O__O(tmp17); if linked_890 == nil { return ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { return linked_890.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :257:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Ctor_O_O_I_O(c__interface_QMARK_, c__b__48000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_interface_QMARK_ = c__interface_QMARK_; t.F_b__48000106 = c__b__48000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :257:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A) Invoke_O__O(self any) any { { var i__48000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__48000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__48000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__48000105__1)); var map__48000110__3 any; if lang.ISeq_InstanceOf(map__48000110__2) { var tmp2 any; var root_763 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = map__48000110__2; if linked_764 == nil { tmp2 = ifn_765.Invoke_O__O(arg_766) } else { tmp2 = linked_764.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_763, arg_766) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_767 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = map__48000110__2; if linked_768 == nil { tmp3 = ifn_769.Invoke_O__O(arg_770) } else { tmp3 = linked_768.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_767, arg_770) }; map__48000110__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_771 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = map__48000110__2; if linked_772 == nil { tmp4 = ifn_773.Invoke_O__O(arg_774) } else { tmp4 = linked_772.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_771, arg_774) }; if jrt.J2g_Truth(tmp4) { var root_775 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = map__48000110__2; if linked_776 == nil { map__48000110__3 = ifn_777.Invoke_O__O(arg_778) } else { map__48000110__3 = linked_776.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_775, arg_778) } } else { map__48000110__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000110__3 = map__48000110__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_63); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000110__3, A_arbace_classes_types_A_const_105); var root_808 any = A_arbace_classes_types_A_const_112.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = t.F_b__48000106; var arg_812 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 any; var root_779 any = A_arbace_classes_types_A_const_9.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_781 lang.IFn
																	if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = sym__4; if linked_780 == nil { tmp6 = ifn_781.Invoke_O__O(arg_782) } else { tmp6 = linked_780.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_779, arg_782) }; var tmp7 any = tmp6; var tmp8 any; var tmp9 any; var root_783 any = A_arbace_classes_types_A_const_107.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_785 lang.IFn
																	if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = bounds__5; if linked_784 == nil { tmp9 = ifn_785.Invoke_O__O(arg_786) } else { tmp9 = linked_784.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_783, arg_786) }; if jrt.J2g_Truth(tmp9) { tmp8 = Lit_58 } else {

		var root_803 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = A_arbace_classes_types_A_const_27.GetRawRoot__O(); var arg_807 any; var root_798 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_800 lang.IFn
		if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var tmp10 any = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(t.F_interface_QMARK_); var tmp11 *jrt.Class; var fncls__797 *jrt.Class = A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class
		if fncls__797 == nil { var fncls__797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class = fncls__797d; tmp11 = fncls__797d } else { tmp11 = fncls__797 }; arg_801 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :262:1
		var arg_802 any = bounds__5; if linked_799 == nil { arg_807 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { arg_807 = linked_799.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }
//line :261:1
		if linked_804 == nil { tmp8 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { tmp8 = linked_804.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) } }
//line :258:1
	arg_812 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref()
//line :257:1
	if linked_809 == nil { ifn_810.Invoke_O_O__O(arg_811, arg_812) } else { linked_809.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_808, arg_811, arg_812) }; i__48000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__48000105__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var na_787 any = i__1; if jrt.Long_InstanceOf(na_787) { var n0_788 int64 = jrt.NN(jrt.Long_Cast(na_787)).LongValue__J(); and__1927000168__auto____3 = n0_788 == 0 } else { if jrt.Double_InstanceOf(na_787) { var n0_788_2 float64 = jrt.NN(jrt.Double_Cast(na_787)).DoubleValue__D(); and__1927000168__auto____3 = n0_788_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_787) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_789 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, A_arbace_classes_types_signature_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = b__2; if linked_790 == nil { tmp5 = ifn_791.Invoke_O__O(arg_792) } else { tmp5 = linked_790.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_789, arg_792) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_793 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_classes_types_signature_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = b__2; if linked_794 == nil { tmp7 = ifn_795.Invoke_O__O(arg_796) } else { tmp7 = linked_794.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_793, arg_796) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } }
//line :263:1
func A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_New_O(p0 any) *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Ctor_O(c__interface_QMARK_ any) { t.F_interface_QMARK_ = c__interface_QMARK_ }
//line :263:1
func (t *A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A) Invoke_O_O_O__O(self, i__1, b__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 bool; var na_864 any = i__1; if jrt.Long_InstanceOf(na_864) { var n0_865 int64 = jrt.NN(jrt.Long_Cast(na_864)).LongValue__J(); and__1927000168__auto____3 = n0_865 == 0 } else { if jrt.Double_InstanceOf(na_864) { var n0_865_2 float64 = jrt.NN(jrt.Double_Cast(na_864)).DoubleValue__D(); and__1927000168__auto____3 = n0_865_2 == 0.0 } else { and__1927000168__auto____3 = lang.Numbers_IsZero_O__Z_NoInit(na_864) } }; if and__1927000168__auto____3 { var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(b__2)); if and__1927000168__auto____4 { var tmp3 lang.IFn = lang.IFn_Cast(t.F_interface_QMARK_); tmp1 = tmp3.Invoke_O__O(A_arbace_classes_types_A_const_57.Invoke_O__O(b__2)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) {
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp5 any; var root_866 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, A_arbace_classes_types_signature_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = b__2; if linked_867 == nil { tmp5 = ifn_868.Invoke_O__O(arg_869) } else { tmp5 = linked_867.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_866, arg_869) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
			var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_870 any = A_arbace_classes_types_A_const_101.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, A_arbace_classes_types_signature_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = b__2; if linked_871 == nil { tmp7 = ifn_872.Invoke_O__O(arg_873) } else { tmp7 = linked_871.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(root_870, arg_873) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref()
		}
}

func A_arbace_classes_types_bounds_map_A_New() *A_arbace_classes_types_bounds_map_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_A) Invoke_O_O__O(self, tps__0 any) any { var root_923 any = A_arbace_classes_types_A_const_40.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_927 any; var root_918 any = A_arbace_classes_types_A_const_104.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any; var tmp1 any = A_arbace_classes_types_bounds_map_fn__48000123_A_New(); var tmp2 *jrt.Class; var fncls__917 *jrt.Class = A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class; if fncls__917 == nil { var fncls__917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class = fncls__917d; tmp2 = fncls__917d } else { tmp2 = fncls__917 }; arg_921 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_922 any = tps__0; if linked_919 == nil { arg_927 = ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { arg_927 = linked_919.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) }; if linked_924 == nil { return ifn_925.Invoke_O_O__O(arg_926, arg_927) } else { return linked_924.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_923, arg_926, arg_927) } }
//line :270:1
func A_arbace_classes_types_bounds_map_fn__48000123_A_New() *A_arbace_classes_types_bounds_map_fn__48000123_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_bounds_map_fn__48000123_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_types_bounds_map_fn__48000123_A) Invoke_O_O__O(self, p__48000122__1 any) any { var map__48000124__2 any = p__48000122__1; var map__48000124__3 any; if lang.ISeq_InstanceOf(map__48000124__2) { var tmp1 any; var root_901 any = A_arbace_classes_types_A_const_90.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = map__48000124__2; if linked_902 == nil { tmp1 = ifn_903.Invoke_O__O(arg_904) } else { tmp1 = linked_902.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_901, arg_904) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_905 any = A_arbace_classes_types_A_const_111.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = map__48000124__2; if linked_906 == nil { tmp2 = ifn_907.Invoke_O__O(arg_908) } else { tmp2 = linked_906.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_905, arg_908) }; map__48000124__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_909 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = map__48000124__2; if linked_910 == nil { tmp3 = ifn_911.Invoke_O__O(arg_912) } else { tmp3 = linked_910.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_909, arg_912) }; if jrt.J2g_Truth(tmp3) { var root_913 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = map__48000124__2; if linked_914 == nil { map__48000124__3 = ifn_915.Invoke_O__O(arg_916) } else { map__48000124__3 = linked_914.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_913, arg_916) } } else { map__48000124__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__48000124__3 = map__48000124__2 }; var sym__4 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_63); var bounds__5 any = lang.RT_Get_O_O__O_NoInit(map__48000124__3, A_arbace_classes_types_A_const_105); return lang.Tuple_Create_O_O__IPersistentVector(sym__4, bounds__5) }

func A_arbace_classes_types_desc__GT_tnode_A_New() *A_arbace_classes_types_desc__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_desc__GT_tnode_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_types_desc__GT_tnode_A) Invoke_O_O__O(self, d__0 any) any {
	var tmp1 any; var root_928 any = A_arbace_classes_types_A_const_71.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = d__0; if linked_929 == nil { tmp1 = ifn_930.Invoke_O__O(arg_931) } else { tmp1 = linked_929.(*A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_928, arg_931) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__0, Lit_8) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_47, A_arbace_classes_types_A_const_48, d__0)) } else { var tmp2 any; var root_932 any = A_arbace_classes_types_A_const_15.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_934 lang.IFn

		if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = d__0; if linked_933 == nil { tmp2 = ifn_934.Invoke_O__O(arg_935) } else { tmp2 = linked_933.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_932, arg_935) }
//line :273:1
		if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_classes_types_A_const_46; var tmp4 any = A_arbace_classes_types_A_const_52; var tmp5 any = A_arbace_classes_types_A_const_53; var tmp6 any; var root_940 any = A_arbace_classes_types_A_const_118.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, A_arbace_classes_types_desc__GT_tnode_A_fn_class); var ifn_942 lang.IFn

			if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any; var root_936 any = A_arbace_classes_types_A_const_119.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, A_arbace_classes_types_elem_type_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = d__0; if linked_937 == nil { arg_943 = ifn_938.Invoke_O__O(arg_939) } else { arg_943 = linked_937.(*A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_936, arg_939) }; if linked_941 == nil { tmp6 = ifn_942.Invoke_O__O(arg_943) } else { tmp6 = linked_941.(*A_arbace_classes_types_desc__GT_tnode_A).Invoke_O_O__O(root_940, arg_943) }
//line :273:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6)) } else { if A_arbace_classes_types_A_const_32 != nil { var tmp7 any = A_arbace_classes_types_A_const_46; var tmp8 any = A_arbace_classes_types_A_const_56; var tmp9 any = A_arbace_classes_types_A_const_57; var tmp10 any; var root_944 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_946 lang.IFn


				if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = d__0; if linked_945 == nil { tmp10 = ifn_946.Invoke_O__O(arg_947) } else { tmp10 = linked_945.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_944, arg_947) }
//line :273:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { return nil
				}
			}
	}
	} }
func A_arbace_classes_types_reflect__GT_tnode_A_New() *A_arbace_classes_types_reflect__GT_tnode_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_reflect__GT_tnode_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Ctor() {}
//line :278:1
func (t *A_arbace_classes_types_reflect__GT_tnode_A) Invoke_O_O__O(self, ty__0 any) any {


	if jrt.Class_InstanceOf(ty__0) {
		var root_952 any = A_arbace_classes_types_A_const_118.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, A_arbace_classes_types_desc__GT_tnode_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any; var root_948 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = ty__0; if linked_949 == nil { arg_955 = ifn_950.Invoke_O__O(arg_951) } else { arg_955 = linked_949.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_948, arg_951) }; if linked_953 == nil { return ifn_954.Invoke_O__O(arg_955) } else { return linked_953.(*A_arbace_classes_types_desc__GT_tnode_A).Invoke_O_O__O(root_952, arg_955) } } else {
//line :281:1
			if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)).IsInstance_O__Z(ty__0) { var pt__2 any = ty__0; var tmp1 any = A_arbace_classes_types_A_const_46; var tmp2 any = A_arbace_classes_types_A_const_56; var tmp3 any = A_arbace_classes_types_A_const_57; var tmp4 any; var root_960 any = A_arbace_classes_types_A_const_33.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_962 lang.IFn



				if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any; var root_956 any = A_arbace_classes_types_A_const_70.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_31, jrt.RefArrayOf(jrt.Object_class)); if linked_957 == nil { arg_963 = ifn_958.Invoke_O__O(arg_959) } else { arg_963 = linked_957.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_956, arg_959) }; if linked_961 == nil { tmp4 = ifn_962.Invoke_O__O(arg_963) } else { tmp4 = linked_961.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_960, arg_963) }
//line :281:1
				var tmp5 any = tmp4; var tmp6 any = A_arbace_classes_types_A_const_58; var tmp7 any; var root_964 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_966 lang.IFn




				if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var arg_968 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(pt__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30), Lit_32, jrt.RefArrayOf(jrt.Object_class)); if linked_965 == nil { tmp7 = ifn_966.Invoke_O_O__O(arg_967, arg_968) } else { tmp7 = linked_965.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_964, arg_967, arg_968) }
//line :281:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp7)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)).IsInstance_O__Z(ty__0) { var tmp8 any = A_arbace_classes_types_A_const_46; var tmp9 any = A_arbace_classes_types_A_const_62; var tmp10 any = A_arbace_classes_types_A_const_63; var tmp11 any; var root_969 any = A_arbace_classes_types_A_const_35.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_971 lang.IFn






					if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33), Lit_34, jrt.RefArrayOf(jrt.Object_class)); if linked_970 == nil { tmp11 = ifn_971.Invoke_O__O(arg_972) } else { tmp11 = linked_970.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_969, arg_972) }
//line :281:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, tmp11)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35)).IsInstance_O__Z(ty__0) { var tmp12 any = A_arbace_classes_types_A_const_46; var tmp13 any = A_arbace_classes_types_A_const_52; var tmp14 any = A_arbace_classes_types_A_const_53; var tmp15 any; var root_973 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_975 lang.IFn








						if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ty__0, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35), Lit_36, jrt.RefArrayOf(jrt.Object_class)); if linked_974 == nil { tmp15 = ifn_975.Invoke_O__O(arg_976) } else { tmp15 = linked_974.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_973, arg_976) }
//line :281:1
						return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15)) } else { if jrt.NN(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37)).IsInstance_O__Z(ty__0) { var w__2 any = ty__0; var lo__3 any; var root_977 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_979 lang.IFn











							if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_38, jrt.RefArrayOf(jrt.Object_class)); if linked_978 == nil { lo__3 = ifn_979.Invoke_O__O(arg_980) } else { lo__3 = linked_978.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_977, arg_980) }
//line :281:1
							var up__4 any; var root_981 any = A_arbace_classes_types_A_const_42.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_983 lang.IFn











							if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(w__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_37), Lit_39, jrt.RefArrayOf(jrt.Object_class)); if linked_982 == nil { up__4 = ifn_983.Invoke_O__O(arg_984) } else { up__4 = linked_982.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_981, arg_984) }
							if jrt.J2g_Truth(lo__3) { var tmp16 any = A_arbace_classes_types_A_const_46; var tmp17 any = A_arbace_classes_types_A_const_79; var tmp18 any = A_arbace_classes_types_A_const_80; var tmp19 any = A_arbace_classes_types_A_const_100; var tmp20 any = A_arbace_classes_types_A_const_82; var tmp21 any; var root_989 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any; var root_985 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = lo__3; if linked_986 == nil { arg_992 = ifn_987.Invoke_O__O(arg_988) } else { arg_992 = linked_986.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_985, arg_988) }; if linked_990 == nil { tmp21 = ifn_991.Invoke_O__O(arg_992) } else { tmp21 = linked_990.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_989, arg_992) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21)) } else { var tmp22 any; var and__1927000168__auto____5 any = up__4
								if jrt.J2g_Truth(and__1927000168__auto____5) { var root_997 any = A_arbace_classes_types_A_const_12.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = A_arbace_classes_types_A_const_121; var arg_1001 any; var root_993 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = up__4; if linked_994 == nil { arg_1001 = ifn_995.Invoke_O__O(arg_996) } else { arg_1001 = linked_994.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_993, arg_996) }; if linked_998 == nil { tmp22 = ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { tmp22 = linked_998.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) } } else { tmp22 = and__1927000168__auto____5 }
//line :294:1
								if jrt.J2g_Truth(tmp22) { var tmp23 any = A_arbace_classes_types_A_const_46; var tmp24 any = A_arbace_classes_types_A_const_79; var tmp25 any = A_arbace_classes_types_A_const_80; var tmp26 any = A_arbace_classes_types_A_const_93; var tmp27 any = A_arbace_classes_types_A_const_82; var tmp28 any; var root_1006 any = A_arbace_classes_types_A_const_120.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_1008 lang.IFn
									if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any; var root_1002 any = A_arbace_classes_types_A_const_76.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = up__4; if linked_1003 == nil { arg_1009 = ifn_1004.Invoke_O__O(arg_1005) } else { arg_1009 = linked_1003.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1002, arg_1005) }; if linked_1007 == nil { tmp28 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp28 = linked_1007.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_1006, arg_1009) }
//line :294:1
									return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28)) } else { if A_arbace_classes_types_A_const_32 != nil { return A_arbace_classes_types_A_const_122 } else { return nil } } } } else {
//line :281:1
										if A_arbace_classes_types_A_const_32 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_types_A_const_46, A_arbace_classes_types_A_const_56, A_arbace_classes_types_A_const_57, Lit_18, A_arbace_classes_types_A_const_58, lang.PersistentVector_EMPTY.Ref())) } else { return nil
										}
									}
						}
					}
				}
		}
}










func A_arbace_classes_types_subst_A_New() *A_arbace_classes_types_subst_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_classes_types_subst_A) Ctor() {}
//line :299:1
func (t *A_arbace_classes_types_subst_A) Invoke_O_O_O__O(self, env__0, tn__1 any) any { var G__48000135__3_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1); switch


	lang.Util_Hash_O__I_NoInit(G__48000135__3_) >> 9 & 7 { case 0: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_79) {




		if jrt.J2g_Truth(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1)) { var root_1017 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = tn__1; var arg_1021 any = A_arbace_classes_types_A_const_82; var arg_1022 any; var tmp1 any = A_arbace_classes_types_subst_fn__48000136_A_New_O(env__0); var tmp2 *jrt.Class; var fncls__1016 *jrt.Class = A_arbace_classes_types_subst_fn__48000136_A_fn_class; if fncls__1016 == nil { var fncls__1016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_types_subst_fn__48000136_A_fn_class = fncls__1016d; tmp2 = fncls__1016d } else { tmp2 = fncls__1016 }; arg_1022 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1018 == nil { return ifn_1019.Invoke_O_O_O__O(arg_1020, arg_1021, arg_1022) } else { return linked_1018.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1017, arg_1020, arg_1021, arg_1022) } } else { return tn__1 } }
//line :302:1
	case 2: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_56) { var G__48000138__4_ any; var root_1034 any = A_arbace_classes_types_A_const_43.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1036 lang.IFn

		if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = tn__1; var arg_1038 any = A_arbace_classes_types_A_const_58; var arg_1039 any; var root_1029 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any; var tmp3 any = A_arbace_classes_types_subst_fn__48000139_A_New_O(env__0); var tmp4 *jrt.Class; var fncls__1028 *jrt.Class = A_arbace_classes_types_subst_fn__48000139_A_fn_class; if fncls__1028 == nil { var fncls__1028d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_types_subst_fn__48000139_A_fn_class = fncls__1028d; tmp4 = fncls__1028d } else { tmp4 = fncls__1028 }; arg_1032 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1033 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__1); if linked_1030 == nil { arg_1039 = ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { arg_1039 = linked_1030.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) }; if linked_1035 == nil { G__48000138__4_ = ifn_1036.Invoke_O_O_O__O(arg_1037, arg_1038, arg_1039) } else { G__48000138__4_ = linked_1035.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1034, arg_1037, arg_1038, arg_1039) }; if jrt.J2g_Truth(A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1)) {
			var root_1046 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = G__48000138__4_; var arg_1050 any = A_arbace_classes_types_A_const_66; var arg_1051 any; var tmp5 any = A_arbace_classes_types_subst_fn__48000141_A_New_O(env__0); var tmp6 *jrt.Class; var fncls__1045 *jrt.Class = A_arbace_classes_types_subst_fn__48000141_A_fn_class; if fncls__1045 == nil { var fncls__1045d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_types_subst_fn__48000141_A_fn_class = fncls__1045d; tmp6 = fncls__1045d } else { tmp6 = fncls__1045 }; arg_1051 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_1047 == nil { return ifn_1048.Invoke_O_O_O__O(arg_1049, arg_1050, arg_1051) } else { return linked_1047.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1046, arg_1049, arg_1050, arg_1051) } } else {
//line :304:1
				return G__48000138__4_ } }
//line :302:1
	case 3: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_84) {





		var root_1063 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = tn__1; var arg_1067 any = A_arbace_classes_types_A_const_85; var arg_1068 any; var tmp7 any = A_arbace_classes_types_subst_fn__48000143_A_New_O(env__0); var tmp8 *jrt.Class; var fncls__1062 *jrt.Class = A_arbace_classes_types_subst_fn__48000143_A_fn_class; if fncls__1062 == nil { var fncls__1062d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_types_subst_fn__48000143_A_fn_class = fncls__1062d; tmp8 = fncls__1062d } else { tmp8 = fncls__1062 }; arg_1068 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_1064 == nil { return ifn_1065.Invoke_O_O_O__O(arg_1066, arg_1067, arg_1068) } else { return linked_1064.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1063, arg_1066, arg_1067, arg_1068) } }
//line :302:1
	case 4: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_52) {



		var root_1075 any = A_arbace_classes_types_A_const_123.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = tn__1; var arg_1079 any = A_arbace_classes_types_A_const_53; var arg_1080 any; var tmp9 any = A_arbace_classes_types_subst_fn__48000145_A_New_O(env__0); var tmp10 *jrt.Class; var fncls__1074 *jrt.Class = A_arbace_classes_types_subst_fn__48000145_A_fn_class; if fncls__1074 == nil { var fncls__1074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_classes_types_subst_fn__48000145_A_fn_class = fncls__1074d; tmp10 = fncls__1074d } else { tmp10 = fncls__1074 }; arg_1080 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1076 == nil { return ifn_1077.Invoke_O_O_O__O(arg_1078, arg_1079, arg_1080) } else { return linked_1076.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1075, arg_1078, arg_1079, arg_1080) } }
//line :302:1
	case 7: if any(G__48000135__3_) == any(A_arbace_classes_types_A_const_62) {
		return lang.RT_Get_O_O_O__O_NoInit(env__0, A_arbace_classes_types_A_const_63.Invoke_O__O(tn__1), tn__1) }
//line :302:1
	default:}; return tn__1 }

func A_arbace_classes_types_subst_fn__48000139_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000139_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000139_A{}; t.Ctor_O(p0); return t }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :304:1
func (t *A_arbace_classes_types_subst_fn__48000139_A) Invoke_O_O__O(self, p1__48000130_SHARP___1 any) any { var root_1023 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, A_arbace_classes_types_subst_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = t.F_env; var arg_1027 any = p1__48000130_SHARP___1; if linked_1024 == nil { return ifn_1025.Invoke_O_O__O(arg_1026, arg_1027) } else { return linked_1024.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1023, arg_1026, arg_1027) } }
func A_arbace_classes_types_subst_fn__48000141_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000141_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000141_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :305:1
func (t *A_arbace_classes_types_subst_fn__48000141_A) Invoke_O_O__O(self, p1__48000131_SHARP___1 any) any { var root_1040 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, A_arbace_classes_types_subst_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = t.F_env; var arg_1044 any = p1__48000131_SHARP___1; if linked_1041 == nil { return ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { return linked_1041.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) } }
func A_arbace_classes_types_subst_fn__48000145_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000145_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000145_A{}; t.Ctor_O(p0); return t }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :306:1
func (t *A_arbace_classes_types_subst_fn__48000145_A) Invoke_O_O__O(self, p1__48000132_SHARP___1 any) any { var root_1069 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, A_arbace_classes_types_subst_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = t.F_env; var arg_1073 any = p1__48000132_SHARP___1; if linked_1070 == nil { return ifn_1071.Invoke_O_O__O(arg_1072, arg_1073) } else { return linked_1070.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1069, arg_1072, arg_1073) } }
func A_arbace_classes_types_subst_fn__48000136_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000136_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000136_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :307:1
func (t *A_arbace_classes_types_subst_fn__48000136_A) Invoke_O_O__O(self, p1__48000133_SHARP___1 any) any { var root_1011 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, A_arbace_classes_types_subst_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = t.F_env; var arg_1015 any = p1__48000133_SHARP___1; if linked_1012 == nil { return ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { return linked_1012.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) } }
func A_arbace_classes_types_subst_fn__48000143_A_New_O(p0 any) *A_arbace_classes_types_subst_fn__48000143_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_subst_fn__48000143_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :308:1
func (t *A_arbace_classes_types_subst_fn__48000143_A) Invoke_O_O__O(self, p1__48000134_SHARP___1 any) any { var root_1057 any = A_arbace_classes_types_A_const_86.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any; var root_1052 any = A_arbace_classes_types_A_const_125.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_partial_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = A_arbace_classes_types_A_const_124.GetRawRoot__O(); var arg_1056 any = t.F_env; if linked_1053 == nil { arg_1060 = ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { arg_1060 = linked_1053.(*aot_arbace_core.A_arbace_core_partial_A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) }; var arg_1061 any = p1__48000134_SHARP___1; if linked_1058 == nil { return ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { return linked_1058.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) } }


func A_arbace_classes_types_type_anns_A_New() *A_arbace_classes_types_type_anns_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Ctor() {}
//line :311:1
func (t *A_arbace_classes_types_type_anns_A) Invoke_O_O__O(self, tn__0 any) any { var body_walk__2 *A_arbace_classes_types_type_anns_walk__48000148_A = A_arbace_classes_types_type_anns_walk__48000148_A_New(); var walk__2 any; var tmp1 *jrt.Class; var fncls__1103 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_A_fn_class; if fncls__1103 == nil { var fncls__1103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_types_type_anns_walk__48000148_A_fn_class = fncls__1103d; tmp1 = fncls__1103d } else { tmp1 = fncls__1103 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__2), tmp1, nil); return /*line :326:1*/ lang.IFn_Cast(walk__2).Invoke_O_O__O(tn__0, Lit_9) }
//line :315:1
func A_arbace_classes_types_type_anns_walk__48000148_A_New() *A_arbace_classes_types_type_anns_walk__48000148_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Ctor() {}
//line :315:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_A) Invoke_O_O_O__O(self, tn__1, path__2 any) any {
	var root_1098 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any; var tmp1 any; var tmp2 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))
	if and__1927000168__auto____3 { tmp1 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { arg_1101 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1), path__2) } else { arg_1101 = nil }
//line :316:1
	var arg_1102 any; var path__3 any; var tmp3 any; var tmp4 any = A_arbace_classes_types_A_const_56; var and__1927000168__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1))

	if and__1927000168__auto____3_2 { tmp3 = A_arbace_classes_types_A_const_66.Invoke_O__O(tn__1) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3_2).Ref() }; if jrt.J2g_Truth(tmp3) { path__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, path__2, nil)).Ref() } else { path__3 = path__2 }
	var root_1093 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any; var temp__1927000414__auto____4 any = A_arbace_classes_types_A_const_44.Invoke_O__O(tn__1)
	if jrt.J2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; arg_1096 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(path__3, a__5)) } else { arg_1096 = nil }
//line :319:1
	var arg_1097 any; var G__48000149__4_ any = A_arbace_classes_types_A_const_46.Invoke_O__O(tn__1)

L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__48000149__4_) >> 0 & 3 { case 0: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_56) {

	var root_1088 any = A_arbace_classes_types_A_const_26.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = A_arbace_classes_types_A_const_126.GetRawRoot__O(); var arg_1092 any; var root_1083 any = A_arbace_classes_types_A_const_113.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any; var tmp5 any = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(path__3, self); var tmp6 *jrt.Class; var fncls__1082 *jrt.Class = A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class; if fncls__1082 == nil { var fncls__1082d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class = fncls__1082d; tmp6 = fncls__1082d } else { tmp6 = fncls__1082 }; arg_1086 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1087 any = A_arbace_classes_types_A_const_58.Invoke_O__O(tn__1); if linked_1084 == nil { arg_1092 = ifn_1085.Invoke_O_O__O(arg_1086, arg_1087) } else { arg_1092 = linked_1084.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1083, arg_1086, arg_1087) }; if linked_1089 == nil { arg_1097 = ifn_1090.Invoke_O_O__O(arg_1091, arg_1092) } else { arg_1097 = linked_1089.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1088, arg_1091, arg_1092) }
//line :321:1
	break L1 }; case 2: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_79) {


		if jrt.J2g_Truth(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1)) { arg_1097 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_82.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref()) } else { arg_1097 = nil }
//line :321:1
		break L1 }; case 3: if any(G__48000149__4_) == any(A_arbace_classes_types_A_const_52) {
			arg_1097 = lang.IFn_Cast(self).Invoke_O_O__O(A_arbace_classes_types_A_const_53.Invoke_O__O(tn__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref())
//line :321:1
			break L1 }; default:}; arg_1097 = nil}
//line :319:1
	if linked_1094 == nil { arg_1102 = ifn_1095.Invoke_O_O__O(arg_1096, arg_1097) } else { arg_1102 = linked_1094.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1093, arg_1096, arg_1097) }
//line :316:1
	if linked_1099 == nil { return ifn_1100.Invoke_O_O__O(arg_1101, arg_1102) } else { return linked_1099.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1098, arg_1101, arg_1102)
	}
}




func A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_New_O_O(p0, p1 any) *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Ctor_O_O(c__path, c__walk any) { t.F_path = c__path; t.F_walk = c__walk }
//line :323:1
func (t *A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A) Invoke_O_O_O__O(self, i__1, a__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_walk); return tmp1.Invoke_O_O__O(a__2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, t.F_path, i__1, nil)).Ref()) }




func A_arbace_classes_types_element_path_A_New() *A_arbace_classes_types_element_path_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_element_path_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Ctor() {}
//line :328:1
func (t *A_arbace_classes_types_element_path_A) Invoke_O_O__O(self, tn__0 any) any { { var tn__2 any = tn__0; var path__3 any = Lit_9; L1: for {




	var tmp1 any = A_arbace_classes_types_A_const_52; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_types_A_const_46.Invoke_O__O(tn__2)) { tn__2, path__3 = A_arbace_classes_types_A_const_53.Invoke_O__O(tn__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, path__3, nil)).Ref(); continue L1 } else { return path__3 } } }; /*line :328:1*/panic("j2g: unreachable") }












































































type A_arbace_classes_types_A struct{ jrt.Object }

var A_arbace_classes_types_A_const_pool *jrt.RefArray

var A_arbace_classes_types_A_const_0 *lang.Var

var A_arbace_classes_types_A_const_1 any

var A_arbace_classes_types_A_const_2 *lang.Var

var A_arbace_classes_types_A_const_3 any

var A_arbace_classes_types_A_const_4 *lang.Var

var A_arbace_classes_types_A_const_5 *lang.Var

var A_arbace_classes_types_A_const_6 *lang.Var

var A_arbace_classes_types_A_const_7 *lang.Var

var A_arbace_classes_types_A_const_8 any

var A_arbace_classes_types_A_const_9 *lang.Var

var A_arbace_classes_types_A_const_10 *lang.Var

var A_arbace_classes_types_A_const_11 *lang.Var

var A_arbace_classes_types_A_const_12 *lang.Var

var A_arbace_classes_types_A_const_13 *lang.Var

var A_arbace_classes_types_A_const_14 *lang.Keyword

var A_arbace_classes_types_A_const_15 *lang.Var

var A_arbace_classes_types_A_const_16 *lang.Var

var A_arbace_classes_types_A_const_17 any

var A_arbace_classes_types_A_const_18 *lang.Var

var A_arbace_classes_types_A_const_19 any

var A_arbace_classes_types_A_const_20 any

var A_arbace_classes_types_A_const_21 any

var A_arbace_classes_types_A_const_22 *lang.Var

var A_arbace_classes_types_A_const_23 any

var A_arbace_classes_types_A_const_24 any

var A_arbace_classes_types_A_const_25 *lang.Var

var A_arbace_classes_types_A_const_26 *lang.Var

var A_arbace_classes_types_A_const_27 *lang.Var

var A_arbace_classes_types_A_const_28 *lang.Var

var A_arbace_classes_types_A_const_29 any

var A_arbace_classes_types_A_const_30 any

var A_arbace_classes_types_A_const_31 *lang.Var

var A_arbace_classes_types_A_const_32 *lang.Keyword

var A_arbace_classes_types_A_const_33 *lang.Var

var A_arbace_classes_types_A_const_34 *lang.Var

var A_arbace_classes_types_A_const_35 *lang.Var

var A_arbace_classes_types_A_const_36 *lang.Var

var A_arbace_classes_types_A_const_37 *lang.Var

var A_arbace_classes_types_A_const_38 *lang.Var

var A_arbace_classes_types_A_const_39 any

var A_arbace_classes_types_A_const_40 *lang.Var

var A_arbace_classes_types_A_const_41 *lang.Var

var A_arbace_classes_types_A_const_42 *lang.Var

var A_arbace_classes_types_A_const_43 *lang.Var

var A_arbace_classes_types_A_const_44 *lang.Keyword

var A_arbace_classes_types_A_const_45 *lang.Var

var A_arbace_classes_types_A_const_46 *lang.Keyword

var A_arbace_classes_types_A_const_47 *lang.Keyword

var A_arbace_classes_types_A_const_48 *lang.Keyword

var A_arbace_classes_types_A_const_49 *lang.Var

var A_arbace_classes_types_A_const_50 *lang.Var

var A_arbace_classes_types_A_const_51 *lang.Var

var A_arbace_classes_types_A_const_52 *lang.Keyword

var A_arbace_classes_types_A_const_53 *lang.Keyword

var A_arbace_classes_types_A_const_54 *lang.Var

var A_arbace_classes_types_A_const_55 *lang.Var

var A_arbace_classes_types_A_const_56 *lang.Keyword

var A_arbace_classes_types_A_const_57 *lang.Keyword

var A_arbace_classes_types_A_const_58 *lang.Keyword

var A_arbace_classes_types_A_const_59 any

var A_arbace_classes_types_A_const_60 any

var A_arbace_classes_types_A_const_61 *lang.Keyword

var A_arbace_classes_types_A_const_62 *lang.Keyword

var A_arbace_classes_types_A_const_63 *lang.Keyword

var A_arbace_classes_types_A_const_64 *lang.Keyword

var A_arbace_classes_types_A_const_65 *lang.Keyword

var A_arbace_classes_types_A_const_66 *lang.Keyword

var A_arbace_classes_types_A_const_67 *lang.Var

var A_arbace_classes_types_A_const_68 *lang.Keyword

var A_arbace_classes_types_A_const_69 *lang.Var

var A_arbace_classes_types_A_const_70 *lang.Var

var A_arbace_classes_types_A_const_71 *lang.Var

var A_arbace_classes_types_A_const_72 *lang.Var

var A_arbace_classes_types_A_const_73 *lang.Var

var A_arbace_classes_types_A_const_74 *lang.Var

var A_arbace_classes_types_A_const_75 any

var A_arbace_classes_types_A_const_76 *lang.Var

var A_arbace_classes_types_A_const_77 *lang.Var

var A_arbace_classes_types_A_const_78 any

var A_arbace_classes_types_A_const_79 *lang.Keyword

var A_arbace_classes_types_A_const_80 *lang.Keyword

var A_arbace_classes_types_A_const_81 *lang.Var

var A_arbace_classes_types_A_const_82 *lang.Keyword

var A_arbace_classes_types_A_const_83 any

var A_arbace_classes_types_A_const_84 *lang.Keyword

var A_arbace_classes_types_A_const_85 *lang.Keyword

var A_arbace_classes_types_A_const_86 *lang.Var

var A_arbace_classes_types_A_const_87 *lang.Var

var A_arbace_classes_types_A_const_88 any

var A_arbace_classes_types_A_const_89 *lang.Var

var A_arbace_classes_types_A_const_90 *lang.Var

var A_arbace_classes_types_A_const_91 *lang.Var

var A_arbace_classes_types_A_const_92 *lang.Var

var A_arbace_classes_types_A_const_93 *lang.Keyword

var A_arbace_classes_types_A_const_94 *lang.Var

var A_arbace_classes_types_A_const_95 *lang.Var

var A_arbace_classes_types_A_const_96 *lang.Var

var A_arbace_classes_types_A_const_97 *lang.Var

var A_arbace_classes_types_A_const_98 *lang.Var

var A_arbace_classes_types_A_const_99 any

var A_arbace_classes_types_A_const_100 *lang.Keyword

var A_arbace_classes_types_A_const_101 *lang.Var

var A_arbace_classes_types_A_const_102 *lang.Var

var A_arbace_classes_types_A_const_103 *lang.Var

var A_arbace_classes_types_A_const_104 *lang.Var

var A_arbace_classes_types_A_const_105 *lang.Keyword

var A_arbace_classes_types_A_const_106 any

var A_arbace_classes_types_A_const_107 *lang.Var

var A_arbace_classes_types_A_const_108 *lang.Var

var A_arbace_classes_types_A_const_109 *lang.Var

var A_arbace_classes_types_A_const_110 *lang.Var

var A_arbace_classes_types_A_const_111 *lang.Var

var A_arbace_classes_types_A_const_112 *lang.Var

var A_arbace_classes_types_A_const_113 *lang.Var

var A_arbace_classes_types_A_const_114 *lang.Var

var A_arbace_classes_types_A_const_115 *lang.Var

var A_arbace_classes_types_A_const_116 *lang.Var

var A_arbace_classes_types_A_const_117 *lang.Var

var A_arbace_classes_types_A_const_118 *lang.Var

var A_arbace_classes_types_A_const_119 *lang.Var

var A_arbace_classes_types_A_const_120 *lang.Var

var A_arbace_classes_types_A_const_121 *jrt.Class

var A_arbace_classes_types_A_const_122 any

var A_arbace_classes_types_A_const_123 *lang.Var

var A_arbace_classes_types_A_const_124 *lang.Var

var A_arbace_classes_types_A_const_125 *lang.Var

var A_arbace_classes_types_A_const_126 *lang.Var

var A_arbace_classes_types_A_init jrt.ClassInit

func A_arbace_classes_types_A_Init() { if !A_arbace_classes_types_A_init.Done() { A_arbace_classes_types_A_init.Run(A_arbace_classes_types_A_clinit) } }

func A_arbace_classes_types_A_clinit() { A_arbace_classes_types_A_clinit_p0(); A_arbace_classes_types_A_clinit_p1(); A_arbace_classes_types_A_clinit_p2(); A_arbace_classes_types_A_clinit_p3(); A_arbace_classes_types_A_clinit_p4(); A_arbace_classes_types_A_clinit_p5(); A_arbace_classes_types_A_clinit_p6(); A_arbace_classes_types_A_clinit_p7(); A_arbace_classes_types_A_clinit_p8(); A_arbace_classes_types_A_clinit_p9(); A_arbace_classes_types_A_clinit_p10() }

func A_arbace_classes_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 163); A_arbace_classes_types_A_const_0 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[36]); A_arbace_classes_types_A_const_1 = A_arbace_classes_types_A_const_pool.A[37]; A_arbace_classes_types_A_const_2 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[38]); A_arbace_classes_types_A_const_3 = A_arbace_classes_types_A_const_pool.A[39]; A_arbace_classes_types_A_const_4 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[40]); A_arbace_classes_types_A_const_5 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[41]); A_arbace_classes_types_A_const_6 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[42]); A_arbace_classes_types_A_const_7 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[43]); A_arbace_classes_types_A_const_8 = A_arbace_classes_types_A_const_pool.A[44]; A_arbace_classes_types_A_const_9 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[45]); A_arbace_classes_types_A_const_10 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[46]); A_arbace_classes_types_A_const_11 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[47]) }

func A_arbace_classes_types_A_clinit_p1() { A_arbace_classes_types_A_const_12 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[48]); A_arbace_classes_types_A_const_13 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[49]); A_arbace_classes_types_A_const_14 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[50]); A_arbace_classes_types_A_const_15 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[51]); A_arbace_classes_types_A_const_16 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[52]); A_arbace_classes_types_A_const_17 = A_arbace_classes_types_A_const_pool.A[53]; A_arbace_classes_types_A_const_18 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[54]); A_arbace_classes_types_A_const_19 = A_arbace_classes_types_A_const_pool.A[55]; A_arbace_classes_types_A_const_20 = A_arbace_classes_types_A_const_pool.A[56]; A_arbace_classes_types_A_const_21 = A_arbace_classes_types_A_const_pool.A[57]; A_arbace_classes_types_A_const_22 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[58]); A_arbace_classes_types_A_const_23 = A_arbace_classes_types_A_const_pool.A[59]; A_arbace_classes_types_A_const_24 = A_arbace_classes_types_A_const_pool.A[60] }

func A_arbace_classes_types_A_clinit_p2() { A_arbace_classes_types_A_const_25 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[61]); A_arbace_classes_types_A_const_26 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[62]); A_arbace_classes_types_A_const_27 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[63]); A_arbace_classes_types_A_const_28 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[64]); A_arbace_classes_types_A_const_29 = A_arbace_classes_types_A_const_pool.A[65]; A_arbace_classes_types_A_const_30 = A_arbace_classes_types_A_const_pool.A[66]; A_arbace_classes_types_A_const_31 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[67]); A_arbace_classes_types_A_const_32 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[68]); A_arbace_classes_types_A_const_33 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[69]); A_arbace_classes_types_A_const_34 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[70]); A_arbace_classes_types_A_const_35 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[71]); A_arbace_classes_types_A_const_36 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[72]) }

func A_arbace_classes_types_A_clinit_p3() { A_arbace_classes_types_A_const_37 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[73]); A_arbace_classes_types_A_const_38 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[74]); A_arbace_classes_types_A_const_39 = A_arbace_classes_types_A_const_pool.A[75]; A_arbace_classes_types_A_const_40 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[76]); A_arbace_classes_types_A_const_41 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[77]); A_arbace_classes_types_A_const_42 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[78]); A_arbace_classes_types_A_const_43 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[79]); A_arbace_classes_types_A_const_44 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[80]); A_arbace_classes_types_A_const_45 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[81]); A_arbace_classes_types_A_const_46 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[82]); A_arbace_classes_types_A_const_47 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[83]); A_arbace_classes_types_A_const_48 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[84]) }

func A_arbace_classes_types_A_clinit_p4() { A_arbace_classes_types_A_const_49 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[85]); A_arbace_classes_types_A_const_50 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[86]); A_arbace_classes_types_A_const_51 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[87]); A_arbace_classes_types_A_const_52 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[88]); A_arbace_classes_types_A_const_53 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[89]); A_arbace_classes_types_A_const_54 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[90]); A_arbace_classes_types_A_const_55 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[91]); A_arbace_classes_types_A_const_56 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[92]); A_arbace_classes_types_A_const_57 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[93]); A_arbace_classes_types_A_const_58 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[94]); A_arbace_classes_types_A_const_59 = A_arbace_classes_types_A_const_pool.A[95]; A_arbace_classes_types_A_const_60 = A_arbace_classes_types_A_const_pool.A[96] }

func A_arbace_classes_types_A_clinit_p5() { A_arbace_classes_types_A_const_61 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[97]); A_arbace_classes_types_A_const_62 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[98]); A_arbace_classes_types_A_const_63 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[99]); A_arbace_classes_types_A_const_64 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[100]); A_arbace_classes_types_A_const_65 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[101]); A_arbace_classes_types_A_const_66 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[102]); A_arbace_classes_types_A_const_67 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[103]); A_arbace_classes_types_A_const_68 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[104]); A_arbace_classes_types_A_const_69 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[105]); A_arbace_classes_types_A_const_70 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[106]); A_arbace_classes_types_A_const_71 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[107]); A_arbace_classes_types_A_const_72 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[108]) }

func A_arbace_classes_types_A_clinit_p6() { A_arbace_classes_types_A_const_73 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[109]); A_arbace_classes_types_A_const_74 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[110]); A_arbace_classes_types_A_const_75 = A_arbace_classes_types_A_const_pool.A[111]; A_arbace_classes_types_A_const_76 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[112]); A_arbace_classes_types_A_const_77 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[113]); A_arbace_classes_types_A_const_78 = A_arbace_classes_types_A_const_pool.A[114]; A_arbace_classes_types_A_const_79 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[115]); A_arbace_classes_types_A_const_80 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[116]); A_arbace_classes_types_A_const_81 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[117]); A_arbace_classes_types_A_const_82 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[118]); A_arbace_classes_types_A_const_83 = A_arbace_classes_types_A_const_pool.A[119]; A_arbace_classes_types_A_const_84 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[120]) }

func A_arbace_classes_types_A_clinit_p7() { A_arbace_classes_types_A_const_85 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[121]); A_arbace_classes_types_A_const_86 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[122]); A_arbace_classes_types_A_const_87 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[123]); A_arbace_classes_types_A_const_88 = A_arbace_classes_types_A_const_pool.A[124]; A_arbace_classes_types_A_const_89 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[125]); A_arbace_classes_types_A_const_90 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[126]); A_arbace_classes_types_A_const_91 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[127]); A_arbace_classes_types_A_const_92 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[128]); A_arbace_classes_types_A_const_93 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[129]); A_arbace_classes_types_A_const_94 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[130]); A_arbace_classes_types_A_const_95 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[131]); A_arbace_classes_types_A_const_96 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[132]) }

func A_arbace_classes_types_A_clinit_p8() { A_arbace_classes_types_A_const_97 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[133]); A_arbace_classes_types_A_const_98 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[134]); A_arbace_classes_types_A_const_99 = A_arbace_classes_types_A_const_pool.A[135]; A_arbace_classes_types_A_const_100 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[136]); A_arbace_classes_types_A_const_101 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[137]); A_arbace_classes_types_A_const_102 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[138]); A_arbace_classes_types_A_const_103 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[139]); A_arbace_classes_types_A_const_104 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[140]); A_arbace_classes_types_A_const_105 = lang.Keyword_Cast(A_arbace_classes_types_A_const_pool.A[141]); A_arbace_classes_types_A_const_106 = A_arbace_classes_types_A_const_pool.A[142]; A_arbace_classes_types_A_const_107 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[143]); A_arbace_classes_types_A_const_108 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[144]) }

func A_arbace_classes_types_A_clinit_p9() { A_arbace_classes_types_A_const_109 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[145]); A_arbace_classes_types_A_const_110 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[146]); A_arbace_classes_types_A_const_111 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[147]); A_arbace_classes_types_A_const_112 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[148]); A_arbace_classes_types_A_const_113 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[149]); A_arbace_classes_types_A_const_114 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[150]); A_arbace_classes_types_A_const_115 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[151]); A_arbace_classes_types_A_const_116 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[152]); A_arbace_classes_types_A_const_117 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[153]); A_arbace_classes_types_A_const_118 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[154]); A_arbace_classes_types_A_const_119 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[155]); A_arbace_classes_types_A_const_120 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[156]) }

func A_arbace_classes_types_A_clinit_p10() { A_arbace_classes_types_A_const_121 = jrt.Class_Cast(A_arbace_classes_types_A_const_pool.A[157]); A_arbace_classes_types_A_const_122 = A_arbace_classes_types_A_const_pool.A[158]; A_arbace_classes_types_A_const_123 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[159]); A_arbace_classes_types_A_const_124 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[160]); A_arbace_classes_types_A_const_125 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[161]); A_arbace_classes_types_A_const_126 = lang.Var_Cast(A_arbace_classes_types_A_const_pool.A[162]) }

func A_arbace_classes_types_A_New() *A_arbace_classes_types_A { A_arbace_classes_types_A_Init(); t := &A_arbace_classes_types_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_A) Ctor() {}

func (t *A_arbace_classes_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_A_class }

func (t *A_arbace_classes_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_A); return ok }

func A_arbace_classes_types_A_Cast(x any) *A_arbace_classes_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_A_class)) }; return v }



type A_arbace_classes_types_array_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_A_fn_class *jrt.Class



type A_arbace_classes_types_array_dims_fn__48000030_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_dims_fn__48000030_A_fn_class *jrt.Class



type A_arbace_classes_types_array_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_of_A_fn_class *jrt.Class



type A_arbace_classes_types_array_sym_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_array_sym_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_A_fn_class *jrt.Class



type A_arbace_classes_types_bounds_map_fn__48000123_A struct{ j2g_header uint64 }

var A_arbace_classes_types_bounds_map_fn__48000123_A_fn_class *jrt.Class



type A_arbace_classes_types_class__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_class__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_class_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_class_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_class_name_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_class_name_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_internal_A_fn_class *jrt.Class



type A_arbace_classes_types_desc__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_desc__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_elem_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_elem_type_A_fn_class *jrt.Class



type A_arbace_classes_types_element_path_A struct{ j2g_header uint64 }

var A_arbace_classes_types_element_path_A_fn_class *jrt.Class



type A_arbace_classes_types_erase_A struct{ j2g_header uint64 }

var A_arbace_classes_types_erase_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000004_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000004_A_New() *A_arbace_classes_types_eval48000004_A { t := &A_arbace_classes_types_eval48000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000004_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000004_A_class }

func (t *A_arbace_classes_types_eval48000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000004_A); return ok }

func A_arbace_classes_types_eval48000004_A_Cast(x any) *A_arbace_classes_types_eval48000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000004_A_class)) }; return v }



type A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class *jrt.Class



type A_arbace_classes_types_eval48000008_A struct{ jrt.Object }

func A_arbace_classes_types_eval48000008_A_New() *A_arbace_classes_types_eval48000008_A { t := &A_arbace_classes_types_eval48000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_types_eval48000008_A) Ctor() {}

func (t *A_arbace_classes_types_eval48000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_types_eval48000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_types_eval48000008_A_class }

func (t *A_arbace_classes_types_eval48000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_types_eval48000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_types_eval48000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_types_eval48000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_types_eval48000008_A); return ok }

func A_arbace_classes_types_eval48000008_A_Cast(x any) *A_arbace_classes_types_eval48000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_types_eval48000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_types_eval48000008_A_class)) }; return v }



type A_arbace_classes_types_eval48000008_fn__48000009_A struct{ j2g_header uint64 }

var A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000013_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000013_A_fn_class *jrt.Class



type A_arbace_classes_types_fn__48000037_A struct{ j2g_header uint64 }

var A_arbace_classes_types_fn__48000037_A_fn_class *jrt.Class



type A_arbace_classes_types_generic_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_generic_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_int_like_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_int_like_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_internal__GT_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_internal__GT_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_class_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_class_A_fn_class *jrt.Class



type A_arbace_classes_types_lang_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_lang_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_local_class_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_local_class_name_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_package_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_package_of_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_method_desc_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_A struct{ j2g_header uint64; F_d any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A struct{ j2g_header uint64; F_d, F_i any }

var A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000065_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_fn__48000065_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000073_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000073_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_fn__48000082_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_fn__48000082_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_p__48000068_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_p__48000068_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_A struct{ j2g_header uint64 }

var A_arbace_classes_types_parse_type_params_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_A_fn_class *jrt.Class



type A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A struct{ j2g_header uint64; F_scope any }

var A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_fn_class *jrt.Class



type A_arbace_classes_types_prim_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_prim_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_ref_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_ref_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_reflect__GT_tnode_A struct{ j2g_header uint64 }

var A_arbace_classes_types_reflect__GT_tnode_A_fn_class *jrt.Class



type A_arbace_classes_types_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_simple_name_of_A struct{ j2g_header uint64 }

var A_arbace_classes_types_simple_name_of_A_fn_class *jrt.Class



type A_arbace_classes_types_size_A struct{ j2g_header uint64 }

var A_arbace_classes_types_size_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_A struct{ j2g_header uint64 }

var A_arbace_classes_types_subst_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000136_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000136_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000139_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000139_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000141_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000141_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000143_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000143_A_fn_class *jrt.Class



type A_arbace_classes_types_subst_fn__48000145_A struct{ j2g_header uint64; F_env any }

var A_arbace_classes_types_subst_fn__48000145_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_anns_walk__48000148_A_fn_class *jrt.Class



type A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A struct{ j2g_header uint64; F_path, F_walk any }

var A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_A struct{ j2g_header uint64 }

var A_arbace_classes_types_type_params_signature_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A struct{ j2g_header uint64; F_iter__48000103, F_interface_QMARK_, F_s__48000104 any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A struct{ j2g_header uint64; F_interface_QMARK_, F_b__48000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_fn_class *jrt.Class



type A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A struct{ j2g_header uint64; F_interface_QMARK_ any }

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_fn_class *jrt.Class



type A_arbace_classes_types_void_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_types_void_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_A_fn_class *jrt.Class



type A_arbace_classes_types_with_anns_fn__48000056_A struct{ j2g_header uint64 }

var A_arbace_classes_types_with_anns_fn__48000056_A_fn_class *jrt.Class
