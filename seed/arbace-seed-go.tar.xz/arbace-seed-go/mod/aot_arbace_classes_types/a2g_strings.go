//line a2g_strings.ae:1
package aot_arbace_classes_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("Types of the class forms (SPEC §4.3): type forms as data, their erasure to JVM descriptors\n  and their generic `Signature` strings.\n\n  Code generation works on descriptors: \"I\", \"J\", \"Ljava/lang/String;\", \"[I\", \"V\".\n  Two pseudo types are keywords: :null (the type of nil) and :none (a form that does not\n  complete). Class names are internal names (\"java/lang/String\").")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("name")

var Lit_14 *jrt.String = jrt.Intern("lang")

var Lit_15 *jrt.String = jrt.Intern("string?")

var Lit_16 *jrt.String = jrt.Intern("not=")

var Lit_17 *jrt.String = jrt.Intern("starts-with?")

var Lit_18 *jrt.String = jrt.Intern("null")

var Lit_19 *jrt.String = jrt.Intern("array?")

var Lit_20 *jrt.String = jrt.Intern("subs")

var Lit_21 *jrt.String = jrt.Intern("take-while")

var Lit_22 *jrt.String = jrt.Intern("contains?")

var Lit_23 *jrt.String = jrt.Intern("internal->desc")

var Lit_24 *jrt.String = jrt.Intern("apply")

var Lit_25 *jrt.String = jrt.Intern("replace")

var Lit_26 *jrt.String = jrt.Intern("else")

var Lit_27 *jrt.String = jrt.Intern("desc->internal")

var Lit_28 *jrt.String = jrt.Intern("prim-names")

var Lit_29 *jrt.String = jrt.Intern("symbol")

var Lit_30 *jrt.String = jrt.Intern("symbol?")

var Lit_31 *jrt.String = jrt.Intern("namespace")

var Lit_32 *jrt.String = jrt.Intern("re-matches")

var Lit_33 *jrt.String = jrt.Intern("[1-9]")

var Lit_34 *jrt.String = jrt.Intern("into")

var Lit_35 *jrt.String = jrt.Intern("seq")

var Lit_36 *jrt.String = jrt.Intern("assoc")

var Lit_37 *jrt.String = jrt.Intern("filter")

var Lit_38 *jrt.String = jrt.Intern("anns")

var Lit_39 *jrt.String = jrt.Intern("with-anns")

var Lit_40 *jrt.String = jrt.Intern("t")

var Lit_41 *jrt.String = jrt.Intern("prim")

var Lit_42 *jrt.String = jrt.Intern("desc")

var Lit_43 *jrt.String = jrt.Intern("array-sym?")

var Lit_44 *jrt.String = jrt.Intern("parse-long")

var Lit_45 *jrt.String = jrt.Intern("iterate")

var Lit_46 *jrt.String = jrt.Intern("clojure-array-hints")

var Lit_47 *jrt.String = jrt.Intern("array")

var Lit_48 *jrt.String = jrt.Intern("elem")

var Lit_49 *jrt.String = jrt.Intern("class")

var Lit_50 *jrt.String = jrt.Intern("args")

var Lit_51 *jrt.String = jrt.Intern("?")

var Lit_52 *jrt.String = jrt.Intern("wild")

var Lit_53 *jrt.String = jrt.Intern("kind")

var Lit_54 *jrt.String = jrt.Intern("tvar")

var Lit_55 *jrt.String = jrt.Intern("sym")

var Lit_56 *jrt.String = jrt.Intern("resolve")

var Lit_57 *jrt.String = jrt.Intern("implicit-outer")

var Lit_58 *jrt.String = jrt.Intern("ex-info")

var Lit_59 *jrt.String = jrt.Intern("parse-type")

var Lit_60 *jrt.String = jrt.Intern("class?")

var Lit_61 *jrt.String = jrt.Intern("class->desc")

var Lit_62 *jrt.String = jrt.Intern("seq?")

var Lit_63 *jrt.String = jrt.Intern("first")

var Lit_64 *jrt.String = jrt.Intern("keyword")

var Lit_65 *jrt.String = jrt.Intern("bound")

var Lit_66 *jrt.String = jrt.Intern("&")

var Lit_67 *jrt.String = jrt.Intern("inter")

var Lit_68 *jrt.String = jrt.Intern("types")

var Lit_69 *jrt.String = jrt.Intern("mapv")

var Lit_70 *jrt.String = jrt.Intern("..")

var Lit_71 *jrt.String = jrt.Intern("reduce")

var Lit_72 *jrt.String = jrt.Intern("tvars")

var Lit_73 *jrt.String = jrt.Intern("outer")

var Lit_74 *jrt.String = jrt.Intern("form")

var Lit_75 *jrt.String = jrt.Intern("prim?")

var Lit_76 *jrt.String = jrt.Intern("desc->class-name")

var Lit_77 *jrt.String = jrt.Intern("prim-desc->name")

var Lit_78 *jrt.String = jrt.Intern("second")

var Lit_79 *jrt.String = jrt.Intern("rest")

var Lit_80 *jrt.String = jrt.Intern("next")

var Lit_81 *jrt.String = jrt.Intern("nnext")

var Lit_82 *jrt.String = jrt.Intern("pr-str")

var Lit_83 *jrt.String = jrt.Intern("extends")

var Lit_84 *jrt.String = jrt.Intern("erase")

var Lit_85 *jrt.String = jrt.Intern("object-desc")

var Lit_86 *jrt.String = jrt.Intern("array-of")

var Lit_87 *jrt.String = jrt.Intern("dissoc")

var Lit_88 *jrt.String = jrt.Intern("generic?")

var Lit_89 *jrt.String = jrt.Intern("[0-9].*")

var Lit_90 *jrt.String = jrt.Intern("super")

var Lit_91 *jrt.String = jrt.Intern("signature")

var Lit_92 *jrt.String = jrt.Intern("not")

var Lit_93 *jrt.String = jrt.Intern("local-class-name?")

var Lit_94 *jrt.String = jrt.Intern("map")

var Lit_95 *jrt.String = jrt.Intern("bounds")

var Lit_96 *jrt.String = jrt.Intern("empty?")

var Lit_97 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_98 *jrt.String = jrt.Intern("chunk-first")

var Lit_99 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_100 *jrt.String = jrt.Intern("to-array")

var Lit_101 *jrt.String = jrt.Intern("chunk-append")

var Lit_102 *jrt.String = jrt.Intern("map-indexed")

var Lit_103 *jrt.String = jrt.Intern("chunk-cons")

var Lit_104 *jrt.String = jrt.Intern("cons")

var Lit_105 *jrt.String = jrt.Intern("chunk")

var Lit_106 *jrt.String = jrt.Intern("chunk-rest")

var Lit_107 *jrt.String = jrt.Intern("desc->tnode")

var Lit_108 *jrt.String = jrt.Intern("elem-type")

var Lit_109 *jrt.String = jrt.Intern("reflect->tnode")

var Lit_110 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_111 *jrt.String = jrt.Intern("update")

var Lit_112 *jrt.String = jrt.Intern("subst")

var Lit_113 *jrt.String = jrt.Intern("partial")

var Lit_114 *jrt.String = jrt.Intern("concat")

var Lit_115 *jrt.String = jrt.Intern("arbace.classes.types$array_QMARK_")

var Lit_116 *jrt.String = jrt.Intern("[")

var Lit_117 *jrt.String = jrt.Intern("arbace.classes.types$array_dims")

var Lit_118 *jrt.String = jrt.Intern("arbace.classes.types$array_dims$fn__48000030")

var Lit_119 *jrt.String = jrt.Intern("arbace.classes.types$array_of")

var Lit_120 *jrt.String = jrt.Intern("arbace.classes.types$array_sym_QMARK_")

var Lit_121 *jrt.String = jrt.Intern("arbace.classes.types$bounds_map")

var Lit_122 *jrt.String = jrt.Intern("arbace.classes.types$bounds_map$fn__48000121")

var Lit_123 *jrt.String = jrt.Intern("arbace.classes.types$class__GT_desc")

var Lit_124 *jrt.String = jrt.Intern(".")

var Lit_125 *jrt.String = jrt.Intern("/")

var Lit_126 *jrt.String = jrt.Intern("L")

var Lit_127 *jrt.String = jrt.Intern(";")

var Lit_128 *jrt.String = jrt.Intern("arbace.classes.types$class_desc_QMARK_")

var Lit_129 *jrt.String = jrt.Intern("arbace.classes.types$desc__GT_class_name")

var Lit_130 *jrt.String = jrt.Intern("arbace.classes.types$desc__GT_internal")

var Lit_131 *jrt.String = jrt.Intern("arbace.classes.types$desc__GT_tnode")

var Lit_132 *jrt.String = jrt.Intern("V")

var Lit_133 *jrt.String = jrt.Intern("arbace.classes.types$elem_type")

var Lit_134 *jrt.String = jrt.Intern("arbace.classes.types$element_path")

var Lit_135 *jrt.String = jrt.Intern("")

var Lit_136 *jrt.String = jrt.Intern("arbace.classes.types$erase")

var Lit_137 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_138 *jrt.String = jrt.Intern("arbace.classes.types$eval48000004$loading__1927001464__auto____48000005")

var Lit_139 *jrt.String = jrt.Intern("arbace.classes.types$eval48000008$fn__48000009")

var Lit_140 *jrt.String = jrt.Intern("arbace.classes.types$fn__48000013")

var Lit_141 *jrt.String = jrt.Intern("arbace.classes.types$fn__48000037")

var Lit_142 *jrt.String = jrt.Intern("arbace.classes.types$generic_QMARK_")

var Lit_143 *jrt.String = jrt.Intern("arbace.classes.types$int_like_QMARK_")

var Lit_144 *jrt.String = jrt.Intern("arbace.classes.types$internal__GT_desc")

var Lit_145 *jrt.String = jrt.Intern("arbace.classes.types$lang_class")

var Lit_146 *jrt.String = jrt.Intern("arbace.classes.types$lang_desc")

var Lit_147 *jrt.String = jrt.Intern("arbace.classes.types$local_class_name_QMARK_")

var Lit_148 *jrt.String = jrt.Intern("$")

var Lit_149 *jrt.String = jrt.Intern("arbace.classes.types$method_desc")

var Lit_150 *jrt.String = jrt.Intern("(")

var Lit_151 *jrt.String = jrt.Intern(")")

var Lit_152 *jrt.String = jrt.Intern("arbace.classes.types$numeric_QMARK_")

var Lit_153 *jrt.String = jrt.Intern("arbace.classes.types$package_of")

var Lit_154 *jrt.String = jrt.Intern("arbace.classes.types$parse_method_desc")

var Lit_155 *jrt.String = jrt.Intern("indexOf")

var Lit_156 *jrt.String = jrt.Intern("arbace.classes.types$parse_method_desc$fn__48000045")

var Lit_157 *jrt.String = jrt.Intern("arbace.classes.types$parse_type")

var Lit_158 *jrt.String = jrt.Intern("[Ljava/lang/Object;")

var Lit_159 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_160 *jrt.String = jrt.Intern("Unknown type: ")

var Lit_161 *jrt.String = jrt.Intern("Not a generic class: ")

var Lit_162 *jrt.String = jrt.Intern("Bad type form: ")

var Lit_163 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000063")

var Lit_164 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000071")

var Lit_165 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000073")

var Lit_166 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000073$fn__48000077")

var Lit_167 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000080")

var Lit_168 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$p__48000066")

var Lit_169 *jrt.String = jrt.Intern("arbace.classes.types$parse_type_params")

var Lit_170 *jrt.String = jrt.Intern("arbace.classes.types$parse_type_params$fn__48000093")

var Lit_171 *jrt.String = jrt.Intern("Bad type parameter: ")

var Lit_172 *jrt.String = jrt.Intern("arbace.classes.types$parse_type_params$fn__48000093$fn__48000097")

var Lit_173 *jrt.String = jrt.Intern("arbace.classes.types$prim_QMARK_")

var Lit_174 *jrt.String = jrt.Intern("arbace.classes.types$ref_QMARK_")

var Lit_175 *jrt.String = jrt.Intern("arbace.classes.types$reflect__GT_tnode")

var Lit_176 *jrt.String = jrt.Intern("java.lang.reflect.ParameterizedType")

var Lit_177 *jrt.String = jrt.Intern("getRawType")

var Lit_178 *jrt.String = jrt.Intern("getActualTypeArguments")

var Lit_179 *jrt.String = jrt.Intern("java.lang.reflect.TypeVariable")

var Lit_180 *jrt.String = jrt.Intern("getName")

var Lit_181 *jrt.String = jrt.Intern("java.lang.reflect.GenericArrayType")

var Lit_182 *jrt.String = jrt.Intern("getGenericComponentType")

var Lit_183 *jrt.String = jrt.Intern("java.lang.reflect.WildcardType")

var Lit_184 *jrt.String = jrt.Intern("getLowerBounds")

var Lit_185 *jrt.String = jrt.Intern("getUpperBounds")

var Lit_186 *jrt.String = jrt.Intern("arbace.classes.types$signature")

var Lit_187 *jrt.String = jrt.Intern("*")

var Lit_188 *jrt.String = jrt.Intern("-")

var Lit_189 *jrt.String = jrt.Intern("+")

var Lit_190 *jrt.String = jrt.Intern("<")

var Lit_191 *jrt.String = jrt.Intern(">")

var Lit_192 *jrt.String = jrt.Intern("T")

var Lit_193 *jrt.String = jrt.Intern("arbace.classes.types$simple_name_of")

var Lit_194 *jrt.String = jrt.Intern("arbace.classes.types$size")

var Lit_195 *jrt.String = jrt.Intern("J")

var Lit_196 *jrt.String = jrt.Intern("D")

var Lit_197 *jrt.String = jrt.Intern("arbace.classes.types$subst")

var Lit_198 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000134")

var Lit_199 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000137")

var Lit_200 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000139")

var Lit_201 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000141")

var Lit_202 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000143")

var Lit_203 *jrt.String = jrt.Intern("arbace.classes.types$type_anns")

var Lit_204 *jrt.String = jrt.Intern("arbace.classes.types$type_anns$walk__48000146")

var Lit_205 *jrt.String = jrt.Intern("arbace.classes.types$type_anns$walk__48000146$fn__48000148")

var Lit_206 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature")

var Lit_207 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000101__48000105")

var Lit_208 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106")

var Lit_209 *jrt.String = jrt.Intern(":Ljava/lang/Object;")

var Lit_210 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106$fn__48000107")

var Lit_211 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106$fn__48000107$fn__48000110")

var Lit_212 *jrt.String = jrt.Intern("::")

var Lit_213 *jrt.String = jrt.Intern(":")

var Lit_214 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106$fn__48000115")

var Lit_215 *jrt.String = jrt.Intern("arbace.classes.types$void_QMARK_")

var Lit_216 *jrt.String = jrt.Intern("arbace.classes.types$with_anns")

var Lit_217 *jrt.String = jrt.Intern("arbace.classes.types$with_anns$fn__48000054")

var Lit_218 *jrt.String = jrt.Intern("in-ns")

var Lit_219 *jrt.String = jrt.Intern("boolean")

var Lit_220 *jrt.String = jrt.Intern("Z")

var Lit_221 *jrt.String = jrt.Intern("char")

var Lit_222 *jrt.String = jrt.Intern("C")

var Lit_223 *jrt.String = jrt.Intern("long")

var Lit_224 *jrt.String = jrt.Intern("double")

var Lit_225 *jrt.String = jrt.Intern("short")

var Lit_226 *jrt.String = jrt.Intern("S")

var Lit_227 *jrt.String = jrt.Intern("int")

var Lit_228 *jrt.String = jrt.Intern("I")

var Lit_229 *jrt.String = jrt.Intern("float")

var Lit_230 *jrt.String = jrt.Intern("F")

var Lit_231 *jrt.String = jrt.Intern("void")

var Lit_232 *jrt.String = jrt.Intern("byte")

var Lit_233 *jrt.String = jrt.Intern("B")

var Lit_234 *jrt.String = jrt.Intern("line")

var Lit_235 *jrt.String = jrt.Intern("column")

var Lit_236 *jrt.String = jrt.Intern("file")

var Lit_237 *jrt.String = jrt.Intern("arbace/classes/types.ae")

var Lit_238 *jrt.String = jrt.Intern("floats")

var Lit_239 *jrt.String = jrt.Intern("[F")

var Lit_240 *jrt.String = jrt.Intern("booleans")

var Lit_241 *jrt.String = jrt.Intern("[Z")

var Lit_242 *jrt.String = jrt.Intern("longs")

var Lit_243 *jrt.String = jrt.Intern("[J")

var Lit_244 *jrt.String = jrt.Intern("objects")

var Lit_245 *jrt.String = jrt.Intern("doubles")

var Lit_246 *jrt.String = jrt.Intern("[D")

var Lit_247 *jrt.String = jrt.Intern("chars")

var Lit_248 *jrt.String = jrt.Intern("[C")

var Lit_249 *jrt.String = jrt.Intern("ints")

var Lit_250 *jrt.String = jrt.Intern("[I")

var Lit_251 *jrt.String = jrt.Intern("shorts")

var Lit_252 *jrt.String = jrt.Intern("[S")

var Lit_253 *jrt.String = jrt.Intern("bytes")

var Lit_254 *jrt.String = jrt.Intern("[B")

var Lit_255 *jrt.String = jrt.Intern("string-desc")

var Lit_256 *jrt.String = jrt.Intern("The internal name of the runtime's package arbace.lang (until the freeze, clojure/lang at stage\n  0, the frozen Clojure; the Go build's classes have no Package objects).")

var Lit_257 *jrt.String = jrt.Intern("lang-class")

var Lit_258 *jrt.String = jrt.Intern("arglists")

var Lit_259 *jrt.String = jrt.Intern("simple")

var Lit_260 *jrt.String = jrt.Intern("The internal name of class `simple` of arbace.lang.")

var Lit_261 *jrt.String = jrt.Intern("lang-desc")

var Lit_262 *jrt.String = jrt.Intern("The descriptor of class `simple` of arbace.lang.")

var Lit_263 *jrt.String = jrt.Intern("void?")

var Lit_264 *jrt.String = jrt.Intern("ref?")

var Lit_265 *jrt.String = jrt.Intern("class-desc?")

var Lit_266 *jrt.String = jrt.Intern("n")

var Lit_267 *jrt.String = jrt.Intern("d")

var Lit_268 *jrt.String = jrt.Intern("Internal name of a reference descriptor (array descriptors stay as they are).")

var Lit_269 *jrt.String = jrt.Intern("array-dims")

var Lit_270 *jrt.String = jrt.Intern("size")

var Lit_271 *jrt.String = jrt.Intern("int-like?")

var Lit_272 *jrt.String = jrt.Intern("numeric?")

var Lit_273 *jrt.String = jrt.Intern("box-of")

var Lit_274 *jrt.String = jrt.Intern("unbox-of")

var Lit_275 *jrt.String = jrt.Intern("method-desc")

var Lit_276 *jrt.String = jrt.Intern("params")

var Lit_277 *jrt.String = jrt.Intern("ret")

var Lit_278 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_279 *jrt.String = jrt.Intern("tag")

var Lit_280 *jrt.String = jrt.Intern("String")

var Lit_281 *jrt.String = jrt.Intern("[param-descs ret-desc] of a method descriptor.")

var Lit_282 *jrt.String = jrt.Intern("package-of")

var Lit_283 *jrt.String = jrt.Intern("internal")

var Lit_284 *jrt.String = jrt.Intern("simple-name-of")

var Lit_285 *jrt.String = jrt.Intern("The Java binary name for Class.forName: java.lang.String, [I, [Ljava.lang.String;")

var Lit_286 *jrt.String = jrt.Intern("c")

var Lit_287 *jrt.String = jrt.Intern("Class")

var Lit_288 *jrt.String = jrt.Intern("private")

var Lit_289 *jrt.String = jrt.Intern("s")

var Lit_290 *jrt.String = jrt.Intern("declared")

var Lit_291 *jrt.String = jrt.Intern("tn")

var Lit_292 *jrt.String = jrt.Intern("scope")

var Lit_293 *jrt.String = jrt.Intern("Parses a type form in `scope`: {:resolve (fn [sym] internal-name or nil) :tvars #{syms}}.\n  Throws on unknown names.")

var Lit_294 *jrt.String = jrt.Intern("The descriptor of a parsed type. `bounds` maps type variable symbols to their bound tnodes.")

var Lit_295 *jrt.String = jrt.Intern("Does a type need a Signature: does it involve type arguments or type variables?")

var Lit_296 *jrt.String = jrt.Intern("Is n, a class nested in outer, a local or anonymous one (Outer$1Local)? javac's\n  signatures name those alone, without their generic outer type.")

var Lit_297 *jrt.String = jrt.Intern("The generic signature string of a parsed type.")

var Lit_298 *jrt.String = jrt.Intern("parse-type-params")

var Lit_299 *jrt.String = jrt.Intern("tps")

var Lit_300 *jrt.String = jrt.Intern("Parses a :type-params vector: [T (U extends Number) (V extends Object Comparable)].\n  Returns [{:sym T :bounds [tnode...]} ...]. The type variables themselves must already be in\n  the scope's :tvars.")

var Lit_301 *jrt.String = jrt.Intern("type-params-signature")

var Lit_302 *jrt.String = jrt.Intern("interface?")

var Lit_303 *jrt.String = jrt.Intern("<T:Ljava/lang/Object;U::Ljava/lang/Comparable<TU;>;> -- `interface?` tells whether a class\n  name is an interface (an interface first bound leaves the class bound empty).")

var Lit_304 *jrt.String = jrt.Intern("bounds-map")

var Lit_305 *jrt.String = jrt.Intern("ty")

var Lit_306 *jrt.String = jrt.Intern("java.lang.reflect.Type")

var Lit_307 *jrt.String = jrt.Intern("A parsed type of a java.lang.reflect.Type.")

var Lit_308 *jrt.String = jrt.Intern("env")

var Lit_309 *jrt.String = jrt.Intern("Replaces type variables of a parsed type by the parsed types in env {sym tnode}.")

var Lit_310 *jrt.String = jrt.Intern("type-anns")

var Lit_311 *jrt.String = jrt.Intern("The annotations inside a parsed type: [[type-path anns-map] ...], type paths in ASM's string\n  form (\"[\" array element, \".\" inner type, \"*\" wildcard bound, \"N;\" type argument N).")

var Lit_312 *jrt.String = jrt.Intern("element-path")

var Lit_313 *jrt.String = jrt.Intern("The type path of the type a declaration annotation applies to: the innermost element type of\n  an array type (JLS 9.7.4).")

var Lit_314 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_315 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_316 *jrt.String = jrt.Intern("arbace/lang")
