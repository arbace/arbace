//line j2g_strings.ae:1
package aot_arbace_classes_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn4,nullkn4,elsekn4,annskn1,tkn4,primkn4,desckn5,arraykn4,elemkn5,classkn4,namekn4,argsyn1,?kn4,wildkn4,kindkn4,tvarkn3,symkn7,resolvekn14,implicit-outeryn5,arraykn5,boundyn1,&kn5,interkn5,typesyn2,..kn5,tvarskn5,outerkn4,formkn7,extendskn5,superkn6,boundsyn7,extendsv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn20,arbace.classes.typesm2,R4,s369,Types of the Java forms (SPEC §4.3): type forms as data, their erasure to JVM descriptors\n  and their generic `Signature` strings.\n\n  Code generation works on descriptors: \"I\", \"J\", \"Ljava/lang/String;\", \"[I\", \"V\".\n  Two pseudo types are keywords: :null (the type of nil) and :none (a form that does not\n  complete). Class names are internal names (\"java/lang/String\").v11,arbace.core13,*loaded-libs*v11,arbace.core4,namev20,arbace.classes.types4,langv11,arbace.core7,string?v11,arbace.core4,not=v13,arbace.string12,starts-with?R5,v20,arbace.classes.types6,array?v11,arbace.core4,subsl1,v11,arbace.core10,take-whilec91,l2,l0,v11,arbace.core9,contains?S4,s1,Ss1,Cs1,Bs1,IS7,s1,Js1,Ss1,Cs1,Fs1,Bs1,Is1,Dv20,arbace.classes.types14,internal->descv11,arbace.core5,applyv11,arbace.core3,strv20,arbace.classes.types12,method-descsc41,c76,v13,arbace.string7,replaceR6,v20,arbace.classes.types14,desc->internalv20,arbace.classes.types10,prim-namesv11,arbace.core6,symbolv11,arbace.core7,symbol?v11,arbace.core9,namespacev11,arbace.core10,re-matchesp5,[1-9]v11,arbace.core4,intov11,arbace.core3,seqv11,arbace.core5,assocv11,arbace.core6,filterR7,v20,arbace.classes.types9,with-annsR8,R9,R10,v20,arbace.classes.types10,array-sym?v11,arbace.core10,parse-longv11,arbace.core7,iteratev20,arbace.classes.types19,clojure-array-hintsR11,R12,R13,R14,R15,R16,m4,R8,R17,R18,nR19,R20,R21,R22,v11,arbace.core7,ex-infov20,arbace.classes.types10,parse-typev11,arbace.core6,class?v20,arbace.classes.types11,class->descv11,arbace.core4,seq?R23,v11,arbace.core5,firstR16,R17,R18,v11,arbace.core7,keywordR24,R25,R26,R27,v11,arbace.core4,mapvR28,v11,arbace.core6,reduceR29,R30,R31,v20,arbace.classes.types5,prim?v20,arbace.classes.types16,desc->class-namev20,arbace.classes.types15,prim-desc->namev11,arbace.core6,secondv11,arbace.core4,restv11,arbace.core4,nextv11,arbace.core5,nnextv11,arbace.core6,pr-strR32,v20,arbace.classes.types5,erasev20,arbace.classes.types11,object-descv20,arbace.classes.types8,array-ofv11,arbace.core6,dissocv20,arbace.classes.types8,generic?p7,[0-9].*R33,v20,arbace.classes.types9,signaturev11,arbace.core3,notv20,arbace.classes.types17,local-class-name?v11,arbace.core3,mapR34,R35,v11,arbace.core6,empty?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core8,to-arrayv11,arbace.core12,chunk-appendv11,arbace.core11,map-indexedv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv20,arbace.classes.types11,desc->tnodev20,arbace.classes.types9,elem-typev20,arbace.classes.types14,reflect->tnodem4,R8,R17,R18,nC16,java.lang.Objectv11,arbace.core6,updatev20,arbace.classes.types5,substv11,arbace.core7,partialv11,arbace.core6,concat")

var Lit_1 *jrt.String = jrt.Intern("[")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.types$array_dims$fn__48000030")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.types$bounds_map$fn__48000123")

var Lit_4 *jrt.String = jrt.Intern(".")

var Lit_5 *jrt.String = jrt.Intern("/")

var Lit_6 *jrt.String = jrt.Intern("L")

var Lit_7 *jrt.String = jrt.Intern(";")

var Lit_8 *jrt.String = jrt.Intern("V")

var Lit_9 *jrt.String = jrt.Intern("")

var Lit_10 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_11 *jrt.String = jrt.Intern("$")

var Lit_12 *jrt.String = jrt.Intern("(")

var Lit_13 *jrt.String = jrt.Intern(")")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.types$parse_method_desc$fn__48000043")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.types$parse_method_desc$fn__48000043$fn__48000046")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000065")

var Lit_17 *jrt.String = jrt.Intern("[Ljava/lang/Object;")

var Lit_18 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_19 *jrt.String = jrt.Intern("Unknown type: ")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$p__48000068")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000073")

var Lit_22 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000075")

var Lit_23 *jrt.String = jrt.Intern("Not a generic class: ")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000082")

var Lit_25 *jrt.String = jrt.Intern("Bad type form: ")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.types$parse_type$fn__48000075$fn__48000079")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.types$parse_type_params$fn__48000095")

var Lit_28 *jrt.String = jrt.Intern("Bad type parameter: ")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.types$parse_type_params$fn__48000095$fn__48000099")

var Lit_30 *jrt.String = jrt.Intern("java.lang.reflect.ParameterizedType")

var Lit_31 *jrt.String = jrt.Intern("getRawType")

var Lit_32 *jrt.String = jrt.Intern("getActualTypeArguments")

var Lit_33 *jrt.String = jrt.Intern("java.lang.reflect.TypeVariable")

var Lit_34 *jrt.String = jrt.Intern("getName")

var Lit_35 *jrt.String = jrt.Intern("java.lang.reflect.GenericArrayType")

var Lit_36 *jrt.String = jrt.Intern("getGenericComponentType")

var Lit_37 *jrt.String = jrt.Intern("java.lang.reflect.WildcardType")

var Lit_38 *jrt.String = jrt.Intern("getLowerBounds")

var Lit_39 *jrt.String = jrt.Intern("getUpperBounds")

var Lit_40 *jrt.String = jrt.Intern("*")

var Lit_41 *jrt.String = jrt.Intern("-")

var Lit_42 *jrt.String = jrt.Intern("+")

var Lit_43 *jrt.String = jrt.Intern("<")

var Lit_44 *jrt.String = jrt.Intern(">")

var Lit_45 *jrt.String = jrt.Intern("T")

var Lit_46 *jrt.String = jrt.Intern("J")

var Lit_47 *jrt.String = jrt.Intern("D")

var Lit_48 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000136")

var Lit_49 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000139")

var Lit_50 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000141")

var Lit_51 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000143")

var Lit_52 *jrt.String = jrt.Intern("arbace.classes.types$subst$fn__48000145")

var Lit_53 *jrt.String = jrt.Intern("arbace.classes.types$type_anns$walk__48000148")

var Lit_54 *jrt.String = jrt.Intern("arbace.classes.types$type_anns$walk__48000148$fn__48000150")

var Lit_55 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000103__48000107")

var Lit_56 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108")

var Lit_57 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108$fn__48000109")

var Lit_58 *jrt.String = jrt.Intern(":Ljava/lang/Object;")

var Lit_59 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108$fn__48000117")

var Lit_60 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108$fn__48000109$fn__48000112")

var Lit_61 *jrt.String = jrt.Intern("::")

var Lit_62 *jrt.String = jrt.Intern(":")

var Lit_63 *jrt.String = jrt.Intern("arbace.classes.types$with_anns$fn__48000056")

var Lit_64 *jrt.String = jrt.Intern("kn3,docyn11,arbace.coreyn7,booleanyn4,charyn4,longyn6,doubleyn5,shortyn3,intyn5,floatyn4,voidyn4,bytekn4,linekn6,columnkn4,fileyn6,floatsyn8,booleansyn5,longsyn7,objectsyn7,doublesyn5,charsyn4,intsyn6,shortsyn5,byteskn8,arglistsyn6,simpleyn1,tyn1,nyn1,dyn6,paramsyn3,retkn3,tagkn7,privateyn6,Stringyn8,internalyn5,Classyn1,skn8,declaredyn2,tnyn4,formyn5,scopeyn6,boundsyn3,tpsyn10,interface?yn22,java.lang.reflect.Typeyn3,envv11,arbace.core5,in-nsMyn20,arbace.classes.typesm2,R0,s369,Types of the Java forms (SPEC §4.3): type forms as data, their erasure to JVM descriptors\n  and their generic `Signature` strings.\n\n  Code generation works on descriptors: \"I\", \"J\", \"Ljava/lang/String;\", \"[I\", \"V\".\n  Two pseudo types are keywords: :null (the type of nil) and :none (a form that does not\n  complete). Class names are internal names (\"java/lang/String\").m2,R0,s369,Types of the Java forms (SPEC §4.3): type forms as data, their erasure to JVM descriptors\n  and their generic `Signature` strings.\n\n  Code generation works on descriptors: \"I\", \"J\", \"Ljava/lang/String;\", \"[I\", \"V\".\n  Two pseudo types are keywords: :null (the type of nil) and :none (a form that does not\n  complete). Class names are internal names (\"java/lang/String\").R1,v20,arbace.classes.types10,prim-namesm18,R2,s1,ZR3,s1,CR4,s1,JR5,s1,DR6,s1,SR7,s1,IR8,s1,FR9,s1,VR10,s1,Bm6,R11,i13,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types15,prim-desc->namev11,arbace.core4,intom6,R11,i17,R12,i1,R13,s23,arbace/classes/types.aev11,arbace.core3,mapv20,arbace.classes.types19,clojure-array-hintsm18,R14,s2,[FR15,s2,[ZR16,s2,[JR17,s19,[Ljava/lang/Object;R18,s2,[DR19,s2,[CR20,s2,[IR21,s2,[SR22,s2,[Bm6,R11,i19,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types11,object-descm6,R11,i23,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types11,string-descm6,R11,i24,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types4,langm8,R11,i26,R12,i1,R13,s23,arbace/classes/types.aeR0,s169,The internal name of the runtime's package arbace.lang (until the freeze, clojure/lang at stage\n  0, the frozen Clojure; the Go build's classes have no Package objects).v20,arbace.classes.types10,lang-classm10,R23,L1,V1,R24,R0,s51,The internal name of class `simple` of arbace.lang.R11,i31,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types9,lang-descm10,R23,L1,V1,R24,R0,s48,The descriptor of class `simple` of arbace.lang.R11,i32,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types5,prim?m8,R23,L1,V1,R25,R11,i34,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types5,void?m8,R23,L1,V1,R25,R11,i35,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types6,array?m8,R23,L1,V1,R25,R11,i36,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types4,ref?m8,R23,L1,V1,R25,R11,i37,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types11,class-desc?m8,R23,L1,V1,R25,R11,i38,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types14,internal->descm8,R23,L1,V1,R26,R11,i40,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types14,desc->internalm10,R23,L1,V1,R27,R0,s77,Internal name of a reference descriptor (array descriptors stay as they are).R11,i41,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types9,elem-typem8,R23,L1,V1,R27,R11,i46,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types8,array-ofm8,R23,L1,V1,R27,R11,i47,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types10,array-dimsm8,R23,L1,V1,R27,R11,i48,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types4,sizem8,R23,L1,V1,R25,R11,i50,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types9,int-like?m8,R23,L1,V1,R25,R11,i52,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types8,numeric?m8,R23,L1,V1,R25,R11,i53,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types6,box-ofm16,s1,Is17,java/lang/Integers1,Js14,java/lang/Longs1,Ss15,java/lang/Shorts1,Bs14,java/lang/Bytes1,Cs19,java/lang/Characters1,Fs15,java/lang/Floats1,Ds16,java/lang/Doubles1,Zs17,java/lang/Booleanm6,R11,i55,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types8,unbox-ofm6,R11,i58,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types11,method-descm8,R23,L1,V2,R28,R29,R11,i60,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types12,method-descsm10,R30,C38,java.util.concurrent.ConcurrentHashMapR31,TR11,i62,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types17,parse-method-descm10,R23,L1,V1,Myn1,dm2,R30,R32,R0,s46,[param-descs ret-desc] of a method descriptor.R11,i67,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types10,package-ofm8,R23,L1,V1,R33,R11,i80,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types14,simple-name-ofm8,R23,L1,V1,R33,R11,i83,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types16,desc->class-namem10,R23,L1,V1,R27,R0,s81,The Java binary name for Class.forName: java.lang.String, [I, [Ljava.lang.String;R11,i87,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types11,class->descm8,R23,L1,V1,Myn1,cm2,R30,R34,R11,i93,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types10,array-sym?m10,R31,TR23,L1,V1,R35,R11,i110,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types10,parse-typem8,R36,TR11,i113,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types9,with-annsm10,R31,TR23,L1,V2,R37,R38,R11,i115,R12,i1,R13,s23,arbace/classes/types.aem10,R23,L1,V2,R39,R38,R0,s116,Parses a type form in `scope`: {:resolve (fn [sym] internal-name or nil) :tvars #{syms}}.\n  Throws on unknown names.R11,i120,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types5,erasem10,R23,L1,V2,R40,R37,R0,s91,The descriptor of a parsed type. `bounds` maps type variable symbols to their bound tnodes.R11,i190,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types8,generic?m10,R23,L1,V1,R37,R0,s79,Does a type need a Signature: does it involve type arguments or type variables?R11,i201,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types17,local-class-name?m12,R31,TR23,L1,V2,Myn1,nm2,R30,R32,Myn5,outerm2,R30,R32,R0,s144,Is n, a class nested in outer, a local or anonymous one (Outer$1Local)? javac's\n  signatures name those alone, without their generic outer type.R11,i212,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types9,signaturem10,R23,L1,V1,R37,R0,s46,The generic signature string of a parsed type.R11,i219,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types17,parse-type-paramsm10,R23,L1,V2,R39,R41,R0,s199,Parses a :type-params vector: [T (U extends Number) (V extends Object Comparable)].\n  Returns [{:sym T :bounds [tnode...]} ...]. The type variables themselves must already be in\n  the scope's :tvars.R11,i236,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types21,type-params-signaturem10,R23,L1,V2,R42,R41,R0,s170,<T:Ljava/lang/Object;U::Ljava/lang/Comparable<TU;>;> -- `interface?` tells whether a class\n  name is an interface (an interface first bound leaves the class bound empty).R11,i249,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types10,bounds-mapm8,R23,L1,V1,R41,R11,i270,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types11,desc->tnodem8,R23,L1,V1,R27,R11,i272,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types14,reflect->tnodem10,R23,L1,V1,Myn2,tym2,R30,R43,R0,s42,A parsed type of a java.lang.reflect.Type.R11,i278,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types5,substm10,R23,L1,V2,R44,R37,R0,s80,Replaces type variables of a parsed type by the parsed types in env {sym tnode}.R11,i299,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types9,type-annsm10,R23,L1,V1,R37,R0,s178,The annotations inside a parsed type: [[type-path anns-map] ...], type paths in ASM's string\n  form (\"[\" array element, \".\" inner type, \"*\" wildcard bound, \"N;\" type argument N).R11,i311,R12,i1,R13,s23,arbace/classes/types.aev20,arbace.classes.types12,element-pathm10,R23,L1,V1,R37,R0,s121,The type path of the type a declaration annotation applies to: the innermost element type of\n  an array type (JLS 9.7.4).R11,i328,R12,i1,R13,s23,arbace/classes/types.ae")

var Lit_65 *jrt.String = jrt.Intern("arbace.classes.types$eval48000004$loading__1927001464__auto____48000005")

var Lit_66 *jrt.String = jrt.Intern("arbace.classes.types$eval48000008$fn__48000009")

var Lit_67 *jrt.String = jrt.Intern("arbace.classes.types$fn__48000013")

var Lit_68 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_69 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_70 *jrt.String = jrt.Intern("arbace/lang")

var Lit_71 *jrt.String = jrt.Intern("arbace.classes.types$lang_class")

var Lit_72 *jrt.String = jrt.Intern("arbace.classes.types$lang_desc")

var Lit_73 *jrt.String = jrt.Intern("arbace.classes.types$prim_QMARK_")

var Lit_74 *jrt.String = jrt.Intern("arbace.classes.types$void_QMARK_")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.types$array_QMARK_")

var Lit_76 *jrt.String = jrt.Intern("arbace.classes.types$ref_QMARK_")

var Lit_77 *jrt.String = jrt.Intern("arbace.classes.types$class_desc_QMARK_")

var Lit_78 *jrt.String = jrt.Intern("arbace.classes.types$internal__GT_desc")

var Lit_79 *jrt.String = jrt.Intern("arbace.classes.types$desc__GT_internal")

var Lit_80 *jrt.String = jrt.Intern("arbace.classes.types$elem_type")

var Lit_81 *jrt.String = jrt.Intern("arbace.classes.types$array_of")

var Lit_82 *jrt.String = jrt.Intern("arbace.classes.types$array_dims")

var Lit_83 *jrt.String = jrt.Intern("arbace.classes.types$size")

var Lit_84 *jrt.String = jrt.Intern("arbace.classes.types$int_like_QMARK_")

var Lit_85 *jrt.String = jrt.Intern("arbace.classes.types$numeric_QMARK_")

var Lit_86 *jrt.String = jrt.Intern("arbace.classes.types$fn__48000037")

var Lit_87 *jrt.String = jrt.Intern("arbace.classes.types$method_desc")

var Lit_88 *jrt.String = jrt.Intern("arbace.classes.types$parse_method_desc")

var Lit_89 *jrt.String = jrt.Intern("arbace.classes.types$package_of")

var Lit_90 *jrt.String = jrt.Intern("arbace.classes.types$simple_name_of")

var Lit_91 *jrt.String = jrt.Intern("arbace.classes.types$desc__GT_class_name")

var Lit_92 *jrt.String = jrt.Intern("arbace.classes.types$class__GT_desc")

var Lit_93 *jrt.String = jrt.Intern("arbace.classes.types$array_sym_QMARK_")

var Lit_94 *jrt.String = jrt.Intern("arbace.classes.types$with_anns")

var Lit_95 *jrt.String = jrt.Intern("arbace.classes.types$parse_type")

var Lit_96 *jrt.String = jrt.Intern("arbace.classes.types$erase")

var Lit_97 *jrt.String = jrt.Intern("arbace.classes.types$generic_QMARK_")

var Lit_98 *jrt.String = jrt.Intern("arbace.classes.types$local_class_name_QMARK_")

var Lit_99 *jrt.String = jrt.Intern("arbace.classes.types$signature")

var Lit_100 *jrt.String = jrt.Intern("arbace.classes.types$parse_type_params")

var Lit_101 *jrt.String = jrt.Intern("arbace.classes.types$type_params_signature")

var Lit_102 *jrt.String = jrt.Intern("arbace.classes.types$bounds_map")

var Lit_103 *jrt.String = jrt.Intern("arbace.classes.types$desc__GT_tnode")

var Lit_104 *jrt.String = jrt.Intern("arbace.classes.types$reflect__GT_tnode")

var Lit_105 *jrt.String = jrt.Intern("arbace.classes.types$subst")

var Lit_106 *jrt.String = jrt.Intern("arbace.classes.types$type_anns")

var Lit_107 *jrt.String = jrt.Intern("arbace.classes.types$element_path")
