//line a2g_classes.ae:1
package aot_arbace_classes_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_classes_types_array_QMARK__A_class, Name: "arbace.classes.types$array_QMARK_", Modifiers: 25, Simple: "array_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_array_dims_A_class, Name: "arbace.classes.types$array_dims", Modifiers: 25, Simple: "array_dims", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_dims_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_array_dims_fn__48000030_A_class, Name: "arbace.classes.types$array_dims$fn__48000030", Modifiers: 25, Simple: "fn__48000030", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_dims_fn__48000030_A", Source: "types.ae", Declaring: &A_arbace_classes_types_array_dims_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_array_of_A_class, Name: "arbace.classes.types$array_of", Modifiers: 25, Simple: "array_of", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_of_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_array_sym_QMARK__A_class, Name: "arbace.classes.types$array_sym_QMARK_", Modifiers: 25, Simple: "array_sym_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_sym_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_bounds_map_A_class, Name: "arbace.classes.types$bounds_map", Modifiers: 25, Simple: "bounds_map", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_bounds_map_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_bounds_map_fn__48000123_A_class, Name: "arbace.classes.types$bounds_map$fn__48000123", Modifiers: 25, Simple: "fn__48000123", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_bounds_map_fn__48000123_A", Source: "types.ae", Declaring: &A_arbace_classes_types_bounds_map_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_class__GT_desc_A_class, Name: "arbace.classes.types$class__GT_desc", Modifiers: 25, Simple: "class__GT_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_class_desc_QMARK__A_class, Name: "arbace.classes.types$class_desc_QMARK_", Modifiers: 25, Simple: "class_desc_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_desc__GT_class_name_A_class, Name: "arbace.classes.types$desc__GT_class_name", Modifiers: 25, Simple: "desc__GT_class_name", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_desc__GT_class_name_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_desc__GT_internal_A_class, Name: "arbace.classes.types$desc__GT_internal", Modifiers: 25, Simple: "desc__GT_internal", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_desc__GT_tnode_A_class, Name: "arbace.classes.types$desc__GT_tnode", Modifiers: 25, Simple: "desc__GT_tnode", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_desc__GT_tnode_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_elem_type_A_class, Name: "arbace.classes.types$elem_type", Modifiers: 25, Simple: "elem_type", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_elem_type_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_element_path_A_class, Name: "arbace.classes.types$element_path", Modifiers: 25, Simple: "element_path", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_element_path_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_erase_A_class, Name: "arbace.classes.types$erase", Modifiers: 25, Simple: "erase", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_erase_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_class, Name: "arbace.classes.types$eval48000004$loading__1927001464__auto____48000005", Modifiers: 25, Simple: "loading__1927001464__auto____48000005", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A", Source: "types.ae", Declaring: &A_arbace_classes_types_eval48000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_eval48000008_fn__48000009_A_class, Name: "arbace.classes.types$eval48000008$fn__48000009", Modifiers: 25, Simple: "fn__48000009", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000008_fn__48000009_A", Source: "types.ae", Declaring: &A_arbace_classes_types_eval48000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_fn__48000013_A_class, Name: "arbace.classes.types$fn__48000013", Modifiers: 25, Simple: "fn__48000013", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_fn__48000013_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_fn__48000037_A_class, Name: "arbace.classes.types$fn__48000037", Modifiers: 25, Simple: "fn__48000037", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_fn__48000037_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_generic_QMARK__A_class, Name: "arbace.classes.types$generic_QMARK_", Modifiers: 25, Simple: "generic_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_generic_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_int_like_QMARK__A_class, Name: "arbace.classes.types$int_like_QMARK_", Modifiers: 25, Simple: "int_like_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_int_like_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_internal__GT_desc_A_class, Name: "arbace.classes.types$internal__GT_desc", Modifiers: 25, Simple: "internal__GT_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_lang_class_A_class, Name: "arbace.classes.types$lang_class", Modifiers: 25, Simple: "lang_class", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_lang_class_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_lang_desc_A_class, Name: "arbace.classes.types$lang_desc", Modifiers: 25, Simple: "lang_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_lang_desc_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_local_class_name_QMARK__A_class, Name: "arbace.classes.types$local_class_name_QMARK_", Modifiers: 25, Simple: "local_class_name_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_local_class_name_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_method_desc_A_class, Name: "arbace.classes.types$method_desc", Modifiers: 25, Simple: "method_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_method_desc_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_numeric_QMARK__A_class, Name: "arbace.classes.types$numeric_QMARK_", Modifiers: 25, Simple: "numeric_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_numeric_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_package_of_A_class, Name: "arbace.classes.types$package_of", Modifiers: 25, Simple: "package_of", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_package_of_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_method_desc_A_class, Name: "arbace.classes.types$parse_method_desc", Modifiers: 25, Simple: "parse_method_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_method_desc_fn__48000043_A_class, Name: "arbace.classes.types$parse_method_desc$fn__48000043", Modifiers: 25, Simple: "fn__48000043", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_fn__48000043_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_method_desc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_class, Name: "arbace.classes.types$parse_method_desc$fn__48000043$fn__48000046", Modifiers: 25, Simple: "fn__48000046", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_method_desc_fn__48000043_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_A_class, Name: "arbace.classes.types$parse_type", Modifiers: 25, Simple: "parse_type", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_fn__48000065_A_class, Name: "arbace.classes.types$parse_type$fn__48000065", Modifiers: 25, Simple: "fn__48000065", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000065_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_fn__48000073_A_class, Name: "arbace.classes.types$parse_type$fn__48000073", Modifiers: 25, Simple: "fn__48000073", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000073_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_fn__48000075_A_class, Name: "arbace.classes.types$parse_type$fn__48000075", Modifiers: 25, Simple: "fn__48000075", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000075_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_class, Name: "arbace.classes.types$parse_type$fn__48000075$fn__48000079", Modifiers: 25, Simple: "fn__48000079", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_fn__48000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_fn__48000082_A_class, Name: "arbace.classes.types$parse_type$fn__48000082", Modifiers: 25, Simple: "fn__48000082", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000082_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_p__48000068_A_class, Name: "arbace.classes.types$parse_type$p__48000068", Modifiers: 25, Simple: "p__48000068", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_p__48000068_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_params_A_class, Name: "arbace.classes.types$parse_type_params", Modifiers: 25, Simple: "parse_type_params", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_params_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_params_fn__48000095_A_class, Name: "arbace.classes.types$parse_type_params$fn__48000095", Modifiers: 25, Simple: "fn__48000095", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_params_fn__48000095_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_params_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_class, Name: "arbace.classes.types$parse_type_params$fn__48000095$fn__48000099", Modifiers: 25, Simple: "fn__48000099", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A", Source: "types.ae", Declaring: &A_arbace_classes_types_parse_type_params_fn__48000095_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_prim_QMARK__A_class, Name: "arbace.classes.types$prim_QMARK_", Modifiers: 25, Simple: "prim_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_ref_QMARK__A_class, Name: "arbace.classes.types$ref_QMARK_", Modifiers: 25, Simple: "ref_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_reflect__GT_tnode_A_class, Name: "arbace.classes.types$reflect__GT_tnode", Modifiers: 25, Simple: "reflect__GT_tnode", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_reflect__GT_tnode_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_signature_A_class, Name: "arbace.classes.types$signature", Modifiers: 25, Simple: "signature", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_signature_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_simple_name_of_A_class, Name: "arbace.classes.types$simple_name_of", Modifiers: 25, Simple: "simple_name_of", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_simple_name_of_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_size_A_class, Name: "arbace.classes.types$size", Modifiers: 25, Simple: "size", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_size_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_subst_A_class, Name: "arbace.classes.types$subst", Modifiers: 25, Simple: "subst", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_subst_fn__48000136_A_class, Name: "arbace.classes.types$subst$fn__48000136", Modifiers: 25, Simple: "fn__48000136", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000136_A", Source: "types.ae", Declaring: &A_arbace_classes_types_subst_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_subst_fn__48000139_A_class, Name: "arbace.classes.types$subst$fn__48000139", Modifiers: 25, Simple: "fn__48000139", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000139_A", Source: "types.ae", Declaring: &A_arbace_classes_types_subst_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_subst_fn__48000141_A_class, Name: "arbace.classes.types$subst$fn__48000141", Modifiers: 25, Simple: "fn__48000141", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000141_A", Source: "types.ae", Declaring: &A_arbace_classes_types_subst_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_subst_fn__48000143_A_class, Name: "arbace.classes.types$subst$fn__48000143", Modifiers: 25, Simple: "fn__48000143", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000143_A", Source: "types.ae", Declaring: &A_arbace_classes_types_subst_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_subst_fn__48000145_A_class, Name: "arbace.classes.types$subst$fn__48000145", Modifiers: 25, Simple: "fn__48000145", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000145_A", Source: "types.ae", Declaring: &A_arbace_classes_types_subst_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_anns_A_class, Name: "arbace.classes.types$type_anns", Modifiers: 25, Simple: "type_anns", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_anns_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_anns_walk__48000148_A_class, Name: "arbace.classes.types$type_anns$walk__48000148", Modifiers: 25, Simple: "walk__48000148", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_anns_walk__48000148_A", Source: "types.ae", Declaring: &A_arbace_classes_types_type_anns_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_class, Name: "arbace.classes.types$type_anns$walk__48000148$fn__48000150", Modifiers: 25, Simple: "fn__48000150", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A", Source: "types.ae", Declaring: &A_arbace_classes_types_type_anns_walk__48000148_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_params_signature_A_class, Name: "arbace.classes.types$type_params_signature", Modifiers: 25, Simple: "type_params_signature", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_class, Name: "arbace.classes.types$type_params_signature$iter__48000103__48000107", Modifiers: 25, Simple: "iter__48000103__48000107", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A", Source: "types.ae", Declaring: &A_arbace_classes_types_type_params_signature_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_class, Name: "arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108", Modifiers: 25, Simple: "fn__48000108", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A", Source: "types.ae", Declaring: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_class, Name: "arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108$fn__48000109", Modifiers: 25, Simple: "fn__48000109", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A", Source: "types.ae", Declaring: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_class, Name: "arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108$fn__48000109$fn__48000112", Modifiers: 25, Simple: "fn__48000112", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A", Source: "types.ae", Declaring: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_class, Name: "arbace.classes.types$type_params_signature$iter__48000103__48000107$fn__48000108$fn__48000117", Modifiers: 25, Simple: "fn__48000117", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A", Source: "types.ae", Declaring: &A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_void_QMARK__A_class, Name: "arbace.classes.types$void_QMARK_", Modifiers: 25, Simple: "void_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_void_QMARK__A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_with_anns_A_class, Name: "arbace.classes.types$with_anns", Modifiers: 25, Simple: "with_anns", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_with_anns_A", Source: "types.ae", Declaring: &A_arbace_classes_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_types_with_anns_fn__48000056_A_class, Name: "arbace.classes.types$with_anns$fn__48000056", Modifiers: 25, Simple: "fn__48000056", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_with_anns_fn__48000056_A", Source: "types.ae", Declaring: &A_arbace_classes_types_with_anns_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_classes_types_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_A_New()}; return nil }

var A_arbace_classes_types_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_types_A_new}

var A_arbace_classes_types_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_A"})

func init() { i := A_arbace_classes_types_A_class.Info(); i.IsInstance = A_arbace_classes_types_A_InstanceOf; i.Init = A_arbace_classes_types_A_Init; i.Table = A_arbace_classes_types_A_members }

var A_arbace_classes_types_array_QMARK__A_class *jrt.Class

var A_arbace_classes_types_array_dims_A_class *jrt.Class

var A_arbace_classes_types_array_dims_fn__48000030_A_class *jrt.Class

var A_arbace_classes_types_array_of_A_class *jrt.Class

var A_arbace_classes_types_array_sym_QMARK__A_class *jrt.Class

var A_arbace_classes_types_bounds_map_A_class *jrt.Class

var A_arbace_classes_types_bounds_map_fn__48000123_A_class *jrt.Class

var A_arbace_classes_types_class__GT_desc_A_class *jrt.Class

var A_arbace_classes_types_class_desc_QMARK__A_class *jrt.Class

var A_arbace_classes_types_desc__GT_class_name_A_class *jrt.Class

var A_arbace_classes_types_desc__GT_internal_A_class *jrt.Class

var A_arbace_classes_types_desc__GT_tnode_A_class *jrt.Class

var A_arbace_classes_types_elem_type_A_class *jrt.Class

var A_arbace_classes_types_element_path_A_class *jrt.Class

var A_arbace_classes_types_erase_A_class *jrt.Class

func A_arbace_classes_types_eval48000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_eval48000004_A_New()}; return nil }

var A_arbace_classes_types_eval48000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_types_eval48000004_A_new}

var A_arbace_classes_types_eval48000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$eval48000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_types_A_class, Simple: "eval48000004", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000004_A"})

func init() { i := A_arbace_classes_types_eval48000004_A_class.Info(); i.IsInstance = A_arbace_classes_types_eval48000004_A_InstanceOf; i.Table = A_arbace_classes_types_eval48000004_A_members }

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_class *jrt.Class

func A_arbace_classes_types_eval48000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_eval48000008_A_New()}; return nil }

var A_arbace_classes_types_eval48000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_types_eval48000008_A_new}

var A_arbace_classes_types_eval48000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$eval48000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_types_A_class, Simple: "eval48000008", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000008_A"})

func init() { i := A_arbace_classes_types_eval48000008_A_class.Info(); i.IsInstance = A_arbace_classes_types_eval48000008_A_InstanceOf; i.Table = A_arbace_classes_types_eval48000008_A_members }

var A_arbace_classes_types_eval48000008_fn__48000009_A_class *jrt.Class

var A_arbace_classes_types_fn__48000013_A_class *jrt.Class

var A_arbace_classes_types_fn__48000037_A_class *jrt.Class

var A_arbace_classes_types_generic_QMARK__A_class *jrt.Class

var A_arbace_classes_types_int_like_QMARK__A_class *jrt.Class

var A_arbace_classes_types_internal__GT_desc_A_class *jrt.Class

var A_arbace_classes_types_lang_class_A_class *jrt.Class

var A_arbace_classes_types_lang_desc_A_class *jrt.Class

var A_arbace_classes_types_local_class_name_QMARK__A_class *jrt.Class

var A_arbace_classes_types_method_desc_A_class *jrt.Class

var A_arbace_classes_types_numeric_QMARK__A_class *jrt.Class

var A_arbace_classes_types_package_of_A_class *jrt.Class

var A_arbace_classes_types_parse_method_desc_A_class *jrt.Class

var A_arbace_classes_types_parse_method_desc_fn__48000043_A_class *jrt.Class

var A_arbace_classes_types_parse_method_desc_fn__48000043_fn__48000046_A_class *jrt.Class

var A_arbace_classes_types_parse_type_A_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000065_A_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000073_A_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000075_A_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000075_fn__48000079_A_class *jrt.Class

var A_arbace_classes_types_parse_type_fn__48000082_A_class *jrt.Class

var A_arbace_classes_types_parse_type_p__48000068_A_class *jrt.Class

var A_arbace_classes_types_parse_type_params_A_class *jrt.Class

var A_arbace_classes_types_parse_type_params_fn__48000095_A_class *jrt.Class

var A_arbace_classes_types_parse_type_params_fn__48000095_fn__48000099_A_class *jrt.Class

var A_arbace_classes_types_prim_QMARK__A_class *jrt.Class

var A_arbace_classes_types_ref_QMARK__A_class *jrt.Class

var A_arbace_classes_types_reflect__GT_tnode_A_class *jrt.Class

var A_arbace_classes_types_signature_A_class *jrt.Class

var A_arbace_classes_types_simple_name_of_A_class *jrt.Class

var A_arbace_classes_types_size_A_class *jrt.Class

var A_arbace_classes_types_subst_A_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000136_A_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000139_A_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000141_A_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000143_A_class *jrt.Class

var A_arbace_classes_types_subst_fn__48000145_A_class *jrt.Class

var A_arbace_classes_types_type_anns_A_class *jrt.Class

var A_arbace_classes_types_type_anns_walk__48000148_A_class *jrt.Class

var A_arbace_classes_types_type_anns_walk__48000148_fn__48000150_A_class *jrt.Class

var A_arbace_classes_types_type_params_signature_A_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_A_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_A_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_A_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000109_fn__48000112_A_class *jrt.Class

var A_arbace_classes_types_type_params_signature_iter__48000103__48000107_fn__48000108_fn__48000117_A_class *jrt.Class

var A_arbace_classes_types_void_QMARK__A_class *jrt.Class

var A_arbace_classes_types_with_anns_A_class *jrt.Class

var A_arbace_classes_types_with_anns_fn__48000056_A_class *jrt.Class

func A_arbace_classes_types__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_types__init_A_Load__O()}; return nil }

func A_arbace_classes_types__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types__init_A_New()}; return nil }

var A_arbace_classes_types__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_types__init_A_invoke, New: A_arbace_classes_types__init_A_new}

var A_arbace_classes_types__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types__init_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types__init_A_class.Info(); i.IsInstance = A_arbace_classes_types__init_A_InstanceOf; i.Init = A_arbace_classes_types__init_A_Init; i.Table = A_arbace_classes_types__init_A_members }
