//line a2g_classes.ae:1
package aot_arbace_classes_types

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_types_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_A_New()}; return nil }

var A_arbace_classes_types_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_types_A_new}

var A_arbace_classes_types_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_A"})

func init() { i := A_arbace_classes_types_A_class.Info(); i.IsInstance = A_arbace_classes_types_A_InstanceOf; i.Init = A_arbace_classes_types_A_Init; i.Table = A_arbace_classes_types_A_members; jrt.RegisterGoType(A_arbace_classes_types_A_class, reflect.TypeFor[A_arbace_classes_types_A]()) }

func A_arbace_classes_types_array_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_array_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_array_QMARK__A_New()}; return nil }

func A_arbace_classes_types_array_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_array_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_array_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_array_QMARK__A_invoke, New: A_arbace_classes_types_array_QMARK__A_new, Get: A_arbace_classes_types_array_QMARK__A_get}

var A_arbace_classes_types_array_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$array_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "array_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_array_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_array_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_array_QMARK__A_Init; i.Table = A_arbace_classes_types_array_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_array_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_array_QMARK__A]()) }

func A_arbace_classes_types_array_dims_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_array_dims_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_array_dims_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_array_dims_A_New()}; return nil }

func A_arbace_classes_types_array_dims_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_array_dims_A_fn_class)}; return nil }

var A_arbace_classes_types_array_dims_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_array_dims_A_invoke, New: A_arbace_classes_types_array_dims_A_new, Get: A_arbace_classes_types_array_dims_A_get}

var A_arbace_classes_types_array_dims_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$array_dims", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "array_dims", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_dims_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_array_dims_A_class.Info(); i.IsInstance = A_arbace_classes_types_array_dims_A_InstanceOf; i.Init = A_arbace_classes_types_array_dims_A_Init; i.Table = A_arbace_classes_types_array_dims_A_members; jrt.RegisterGoType(A_arbace_classes_types_array_dims_A_class, reflect.TypeFor[A_arbace_classes_types_array_dims_A]()) }

func A_arbace_classes_types_array_dims_fn__48000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_array_dims_fn__48000030_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_array_dims_fn__48000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_array_dims_fn__48000030_A_New()}; return nil }

func A_arbace_classes_types_array_dims_fn__48000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_array_dims_fn__48000030_A_fn_class)}; return nil }

var A_arbace_classes_types_array_dims_fn__48000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_array_dims_fn__48000030_A_invoke, New: A_arbace_classes_types_array_dims_fn__48000030_A_new, Get: A_arbace_classes_types_array_dims_fn__48000030_A_get}

var A_arbace_classes_types_array_dims_fn__48000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$array_dims$fn__48000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_array_dims_A_class, Simple: "fn__48000030", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_dims_fn__48000030_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_array_dims_fn__48000030_A_class.Info(); i.IsInstance = A_arbace_classes_types_array_dims_fn__48000030_A_InstanceOf; i.Init = A_arbace_classes_types_array_dims_fn__48000030_A_Init; i.Table = A_arbace_classes_types_array_dims_fn__48000030_A_members; jrt.RegisterGoType(A_arbace_classes_types_array_dims_fn__48000030_A_class, reflect.TypeFor[A_arbace_classes_types_array_dims_fn__48000030_A]()) }

func A_arbace_classes_types_array_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_array_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_array_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_array_of_A_New()}; return nil }

func A_arbace_classes_types_array_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_array_of_A_fn_class)}; return nil }

var A_arbace_classes_types_array_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_array_of_A_invoke, New: A_arbace_classes_types_array_of_A_new, Get: A_arbace_classes_types_array_of_A_get}

var A_arbace_classes_types_array_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$array_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "array_of", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_of_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_array_of_A_class.Info(); i.IsInstance = A_arbace_classes_types_array_of_A_InstanceOf; i.Init = A_arbace_classes_types_array_of_A_Init; i.Table = A_arbace_classes_types_array_of_A_members; jrt.RegisterGoType(A_arbace_classes_types_array_of_A_class, reflect.TypeFor[A_arbace_classes_types_array_of_A]()) }

func A_arbace_classes_types_array_sym_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_array_sym_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_array_sym_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_array_sym_QMARK__A_New()}; return nil }

func A_arbace_classes_types_array_sym_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_array_sym_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_array_sym_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_array_sym_QMARK__A_invoke, New: A_arbace_classes_types_array_sym_QMARK__A_new, Get: A_arbace_classes_types_array_sym_QMARK__A_get}

var A_arbace_classes_types_array_sym_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$array_sym_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "array_sym_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_array_sym_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_array_sym_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_array_sym_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_array_sym_QMARK__A_Init; i.Table = A_arbace_classes_types_array_sym_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_array_sym_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_array_sym_QMARK__A]()) }

func A_arbace_classes_types_bounds_map_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_bounds_map_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_bounds_map_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_bounds_map_A_New()}; return nil }

func A_arbace_classes_types_bounds_map_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_bounds_map_A_fn_class)}; return nil }

var A_arbace_classes_types_bounds_map_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_bounds_map_A_invoke, New: A_arbace_classes_types_bounds_map_A_new, Get: A_arbace_classes_types_bounds_map_A_get}

var A_arbace_classes_types_bounds_map_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$bounds_map", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "bounds_map", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_bounds_map_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_bounds_map_A_class.Info(); i.IsInstance = A_arbace_classes_types_bounds_map_A_InstanceOf; i.Init = A_arbace_classes_types_bounds_map_A_Init; i.Table = A_arbace_classes_types_bounds_map_A_members; jrt.RegisterGoType(A_arbace_classes_types_bounds_map_A_class, reflect.TypeFor[A_arbace_classes_types_bounds_map_A]()) }

func A_arbace_classes_types_bounds_map_fn__48000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_bounds_map_fn__48000121_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_bounds_map_fn__48000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_bounds_map_fn__48000121_A_New()}; return nil }

func A_arbace_classes_types_bounds_map_fn__48000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_bounds_map_fn__48000121_A_fn_class)}; return nil }

var A_arbace_classes_types_bounds_map_fn__48000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_bounds_map_fn__48000121_A_invoke, New: A_arbace_classes_types_bounds_map_fn__48000121_A_new, Get: A_arbace_classes_types_bounds_map_fn__48000121_A_get}

var A_arbace_classes_types_bounds_map_fn__48000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$bounds_map$fn__48000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_bounds_map_A_class, Simple: "fn__48000121", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_bounds_map_fn__48000121_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_bounds_map_fn__48000121_A_class.Info(); i.IsInstance = A_arbace_classes_types_bounds_map_fn__48000121_A_InstanceOf; i.Init = A_arbace_classes_types_bounds_map_fn__48000121_A_Init; i.Table = A_arbace_classes_types_bounds_map_fn__48000121_A_members; jrt.RegisterGoType(A_arbace_classes_types_bounds_map_fn__48000121_A_class, reflect.TypeFor[A_arbace_classes_types_bounds_map_fn__48000121_A]()) }

func A_arbace_classes_types_class__GT_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_class__GT_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_class__GT_desc_A_New()}; return nil }

func A_arbace_classes_types_class__GT_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_class__GT_desc_A_fn_class)}; return nil }

var A_arbace_classes_types_class__GT_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_class__GT_desc_A_invoke, New: A_arbace_classes_types_class__GT_desc_A_new, Get: A_arbace_classes_types_class__GT_desc_A_get}

var A_arbace_classes_types_class__GT_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$class__GT_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "class__GT_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_class__GT_desc_A_class.Info(); i.IsInstance = A_arbace_classes_types_class__GT_desc_A_InstanceOf; i.Init = A_arbace_classes_types_class__GT_desc_A_Init; i.Table = A_arbace_classes_types_class__GT_desc_A_members; jrt.RegisterGoType(A_arbace_classes_types_class__GT_desc_A_class, reflect.TypeFor[A_arbace_classes_types_class__GT_desc_A]()) }

func A_arbace_classes_types_class_desc_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_class_desc_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_class_desc_QMARK__A_New()}; return nil }

func A_arbace_classes_types_class_desc_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_class_desc_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_class_desc_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_class_desc_QMARK__A_invoke, New: A_arbace_classes_types_class_desc_QMARK__A_new, Get: A_arbace_classes_types_class_desc_QMARK__A_get}

var A_arbace_classes_types_class_desc_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$class_desc_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "class_desc_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_class_desc_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_class_desc_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_class_desc_QMARK__A_Init; i.Table = A_arbace_classes_types_class_desc_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_class_desc_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_class_desc_QMARK__A]()) }

func A_arbace_classes_types_desc__GT_class_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_desc__GT_class_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_desc__GT_class_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_desc__GT_class_name_A_New()}; return nil }

func A_arbace_classes_types_desc__GT_class_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_desc__GT_class_name_A_fn_class)}; return nil }

var A_arbace_classes_types_desc__GT_class_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_desc__GT_class_name_A_invoke, New: A_arbace_classes_types_desc__GT_class_name_A_new, Get: A_arbace_classes_types_desc__GT_class_name_A_get}

var A_arbace_classes_types_desc__GT_class_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$desc__GT_class_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "desc__GT_class_name", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_desc__GT_class_name_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_desc__GT_class_name_A_class.Info(); i.IsInstance = A_arbace_classes_types_desc__GT_class_name_A_InstanceOf; i.Init = A_arbace_classes_types_desc__GT_class_name_A_Init; i.Table = A_arbace_classes_types_desc__GT_class_name_A_members; jrt.RegisterGoType(A_arbace_classes_types_desc__GT_class_name_A_class, reflect.TypeFor[A_arbace_classes_types_desc__GT_class_name_A]()) }

func A_arbace_classes_types_desc__GT_internal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_desc__GT_internal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_desc__GT_internal_A_New()}; return nil }

func A_arbace_classes_types_desc__GT_internal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_desc__GT_internal_A_fn_class)}; return nil }

var A_arbace_classes_types_desc__GT_internal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_desc__GT_internal_A_invoke, New: A_arbace_classes_types_desc__GT_internal_A_new, Get: A_arbace_classes_types_desc__GT_internal_A_get}

var A_arbace_classes_types_desc__GT_internal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$desc__GT_internal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "desc__GT_internal", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_desc__GT_internal_A_class.Info(); i.IsInstance = A_arbace_classes_types_desc__GT_internal_A_InstanceOf; i.Init = A_arbace_classes_types_desc__GT_internal_A_Init; i.Table = A_arbace_classes_types_desc__GT_internal_A_members; jrt.RegisterGoType(A_arbace_classes_types_desc__GT_internal_A_class, reflect.TypeFor[A_arbace_classes_types_desc__GT_internal_A]()) }

func A_arbace_classes_types_desc__GT_tnode_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_desc__GT_tnode_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_desc__GT_tnode_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_desc__GT_tnode_A_New()}; return nil }

func A_arbace_classes_types_desc__GT_tnode_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_desc__GT_tnode_A_fn_class)}; return nil }

var A_arbace_classes_types_desc__GT_tnode_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_desc__GT_tnode_A_invoke, New: A_arbace_classes_types_desc__GT_tnode_A_new, Get: A_arbace_classes_types_desc__GT_tnode_A_get}

var A_arbace_classes_types_desc__GT_tnode_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$desc__GT_tnode", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "desc__GT_tnode", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_desc__GT_tnode_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_desc__GT_tnode_A_class.Info(); i.IsInstance = A_arbace_classes_types_desc__GT_tnode_A_InstanceOf; i.Init = A_arbace_classes_types_desc__GT_tnode_A_Init; i.Table = A_arbace_classes_types_desc__GT_tnode_A_members; jrt.RegisterGoType(A_arbace_classes_types_desc__GT_tnode_A_class, reflect.TypeFor[A_arbace_classes_types_desc__GT_tnode_A]()) }

func A_arbace_classes_types_elem_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_elem_type_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_elem_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_elem_type_A_New()}; return nil }

func A_arbace_classes_types_elem_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_elem_type_A_fn_class)}; return nil }

var A_arbace_classes_types_elem_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_elem_type_A_invoke, New: A_arbace_classes_types_elem_type_A_new, Get: A_arbace_classes_types_elem_type_A_get}

var A_arbace_classes_types_elem_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$elem_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "elem_type", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_elem_type_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_elem_type_A_class.Info(); i.IsInstance = A_arbace_classes_types_elem_type_A_InstanceOf; i.Init = A_arbace_classes_types_elem_type_A_Init; i.Table = A_arbace_classes_types_elem_type_A_members; jrt.RegisterGoType(A_arbace_classes_types_elem_type_A_class, reflect.TypeFor[A_arbace_classes_types_elem_type_A]()) }

func A_arbace_classes_types_element_path_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_element_path_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_element_path_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_element_path_A_New()}; return nil }

func A_arbace_classes_types_element_path_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_element_path_A_fn_class)}; return nil }

var A_arbace_classes_types_element_path_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_element_path_A_invoke, New: A_arbace_classes_types_element_path_A_new, Get: A_arbace_classes_types_element_path_A_get}

var A_arbace_classes_types_element_path_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$element_path", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "element_path", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_element_path_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_element_path_A_class.Info(); i.IsInstance = A_arbace_classes_types_element_path_A_InstanceOf; i.Init = A_arbace_classes_types_element_path_A_Init; i.Table = A_arbace_classes_types_element_path_A_members; jrt.RegisterGoType(A_arbace_classes_types_element_path_A_class, reflect.TypeFor[A_arbace_classes_types_element_path_A]()) }

func A_arbace_classes_types_erase_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_erase_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_erase_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_erase_A_New()}; return nil }

func A_arbace_classes_types_erase_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_erase_A_fn_class)}; return nil }

var A_arbace_classes_types_erase_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_erase_A_invoke, New: A_arbace_classes_types_erase_A_new, Get: A_arbace_classes_types_erase_A_get}

var A_arbace_classes_types_erase_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$erase", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "erase", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_erase_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_erase_A_class.Info(); i.IsInstance = A_arbace_classes_types_erase_A_InstanceOf; i.Init = A_arbace_classes_types_erase_A_Init; i.Table = A_arbace_classes_types_erase_A_members; jrt.RegisterGoType(A_arbace_classes_types_erase_A_class, reflect.TypeFor[A_arbace_classes_types_erase_A]()) }

func A_arbace_classes_types_eval48000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_eval48000004_A_New()}; return nil }

var A_arbace_classes_types_eval48000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_types_eval48000004_A_new}

var A_arbace_classes_types_eval48000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$eval48000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_types_A_class, Simple: "eval48000004", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000004_A"})

func init() { i := A_arbace_classes_types_eval48000004_A_class.Info(); i.IsInstance = A_arbace_classes_types_eval48000004_A_InstanceOf; i.Table = A_arbace_classes_types_eval48000004_A_members; jrt.RegisterGoType(A_arbace_classes_types_eval48000004_A_class, reflect.TypeFor[A_arbace_classes_types_eval48000004_A]()) }

func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_New()}; return nil }

func A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_fn_class)}; return nil }

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_invoke, New: A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_new, Get: A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_get}

var A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$eval48000004$loading__1927001464__auto____48000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_types_eval48000004_A_class, Simple: "loading__1927001464__auto____48000005", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_class.Info(); i.IsInstance = A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_InstanceOf; i.Init = A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_Init; i.Table = A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_members; jrt.RegisterGoType(A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A_class, reflect.TypeFor[A_arbace_classes_types_eval48000004_loading__1927001464__auto____48000005_A]()) }

func A_arbace_classes_types_eval48000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_eval48000008_A_New()}; return nil }

var A_arbace_classes_types_eval48000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_types_eval48000008_A_new}

var A_arbace_classes_types_eval48000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$eval48000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_types_A_class, Simple: "eval48000008", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000008_A"})

func init() { i := A_arbace_classes_types_eval48000008_A_class.Info(); i.IsInstance = A_arbace_classes_types_eval48000008_A_InstanceOf; i.Table = A_arbace_classes_types_eval48000008_A_members; jrt.RegisterGoType(A_arbace_classes_types_eval48000008_A_class, reflect.TypeFor[A_arbace_classes_types_eval48000008_A]()) }

func A_arbace_classes_types_eval48000008_fn__48000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_eval48000008_fn__48000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_types_eval48000008_fn__48000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_eval48000008_fn__48000009_A_New()}; return nil }

func A_arbace_classes_types_eval48000008_fn__48000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_eval48000008_fn__48000009_A_fn_class)}; return nil }

var A_arbace_classes_types_eval48000008_fn__48000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_eval48000008_fn__48000009_A_invoke, New: A_arbace_classes_types_eval48000008_fn__48000009_A_new, Get: A_arbace_classes_types_eval48000008_fn__48000009_A_get}

var A_arbace_classes_types_eval48000008_fn__48000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$eval48000008$fn__48000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_types_eval48000008_A_class, Simple: "fn__48000009", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_eval48000008_fn__48000009_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_eval48000008_fn__48000009_A_class.Info(); i.IsInstance = A_arbace_classes_types_eval48000008_fn__48000009_A_InstanceOf; i.Init = A_arbace_classes_types_eval48000008_fn__48000009_A_Init; i.Table = A_arbace_classes_types_eval48000008_fn__48000009_A_members; jrt.RegisterGoType(A_arbace_classes_types_eval48000008_fn__48000009_A_class, reflect.TypeFor[A_arbace_classes_types_eval48000008_fn__48000009_A]()) }

func A_arbace_classes_types_fn__48000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_fn__48000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_fn__48000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_fn__48000013_A_New()}; return nil }

func A_arbace_classes_types_fn__48000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_fn__48000013_A_fn_class)}; return nil }

var A_arbace_classes_types_fn__48000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_fn__48000013_A_invoke, New: A_arbace_classes_types_fn__48000013_A_new, Get: A_arbace_classes_types_fn__48000013_A_get}

var A_arbace_classes_types_fn__48000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$fn__48000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "fn__48000013", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_fn__48000013_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_fn__48000013_A_class.Info(); i.IsInstance = A_arbace_classes_types_fn__48000013_A_InstanceOf; i.Init = A_arbace_classes_types_fn__48000013_A_Init; i.Table = A_arbace_classes_types_fn__48000013_A_members; jrt.RegisterGoType(A_arbace_classes_types_fn__48000013_A_class, reflect.TypeFor[A_arbace_classes_types_fn__48000013_A]()) }

func A_arbace_classes_types_fn__48000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_fn__48000037_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_fn__48000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_fn__48000037_A_New()}; return nil }

func A_arbace_classes_types_fn__48000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_fn__48000037_A_fn_class)}; return nil }

var A_arbace_classes_types_fn__48000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_fn__48000037_A_invoke, New: A_arbace_classes_types_fn__48000037_A_new, Get: A_arbace_classes_types_fn__48000037_A_get}

var A_arbace_classes_types_fn__48000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$fn__48000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "fn__48000037", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_fn__48000037_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_fn__48000037_A_class.Info(); i.IsInstance = A_arbace_classes_types_fn__48000037_A_InstanceOf; i.Init = A_arbace_classes_types_fn__48000037_A_Init; i.Table = A_arbace_classes_types_fn__48000037_A_members; jrt.RegisterGoType(A_arbace_classes_types_fn__48000037_A_class, reflect.TypeFor[A_arbace_classes_types_fn__48000037_A]()) }

func A_arbace_classes_types_generic_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_generic_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_generic_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_generic_QMARK__A_New()}; return nil }

func A_arbace_classes_types_generic_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_generic_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_generic_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_generic_QMARK__A_invoke, New: A_arbace_classes_types_generic_QMARK__A_new, Get: A_arbace_classes_types_generic_QMARK__A_get}

var A_arbace_classes_types_generic_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$generic_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "generic_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_generic_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_generic_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_generic_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_generic_QMARK__A_Init; i.Table = A_arbace_classes_types_generic_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_generic_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_generic_QMARK__A]()) }

func A_arbace_classes_types_int_like_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_int_like_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_int_like_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_int_like_QMARK__A_New()}; return nil }

func A_arbace_classes_types_int_like_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_int_like_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_int_like_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_int_like_QMARK__A_invoke, New: A_arbace_classes_types_int_like_QMARK__A_new, Get: A_arbace_classes_types_int_like_QMARK__A_get}

var A_arbace_classes_types_int_like_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$int_like_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "int_like_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_int_like_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_int_like_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_int_like_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_int_like_QMARK__A_Init; i.Table = A_arbace_classes_types_int_like_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_int_like_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_int_like_QMARK__A]()) }

func A_arbace_classes_types_internal__GT_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_internal__GT_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_internal__GT_desc_A_New()}; return nil }

func A_arbace_classes_types_internal__GT_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_internal__GT_desc_A_fn_class)}; return nil }

var A_arbace_classes_types_internal__GT_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_internal__GT_desc_A_invoke, New: A_arbace_classes_types_internal__GT_desc_A_new, Get: A_arbace_classes_types_internal__GT_desc_A_get}

var A_arbace_classes_types_internal__GT_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$internal__GT_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "internal__GT_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_internal__GT_desc_A_class.Info(); i.IsInstance = A_arbace_classes_types_internal__GT_desc_A_InstanceOf; i.Init = A_arbace_classes_types_internal__GT_desc_A_Init; i.Table = A_arbace_classes_types_internal__GT_desc_A_members; jrt.RegisterGoType(A_arbace_classes_types_internal__GT_desc_A_class, reflect.TypeFor[A_arbace_classes_types_internal__GT_desc_A]()) }

func A_arbace_classes_types_lang_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_lang_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_lang_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_lang_class_A_New()}; return nil }

func A_arbace_classes_types_lang_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_lang_class_A_fn_class)}; return nil }

var A_arbace_classes_types_lang_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_lang_class_A_invoke, New: A_arbace_classes_types_lang_class_A_new, Get: A_arbace_classes_types_lang_class_A_get}

var A_arbace_classes_types_lang_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$lang_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "lang_class", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_lang_class_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_lang_class_A_class.Info(); i.IsInstance = A_arbace_classes_types_lang_class_A_InstanceOf; i.Init = A_arbace_classes_types_lang_class_A_Init; i.Table = A_arbace_classes_types_lang_class_A_members; jrt.RegisterGoType(A_arbace_classes_types_lang_class_A_class, reflect.TypeFor[A_arbace_classes_types_lang_class_A]()) }

func A_arbace_classes_types_lang_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_lang_desc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_lang_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_lang_desc_A_New()}; return nil }

func A_arbace_classes_types_lang_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_lang_desc_A_fn_class)}; return nil }

var A_arbace_classes_types_lang_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_lang_desc_A_invoke, New: A_arbace_classes_types_lang_desc_A_new, Get: A_arbace_classes_types_lang_desc_A_get}

var A_arbace_classes_types_lang_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$lang_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "lang_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_lang_desc_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_lang_desc_A_class.Info(); i.IsInstance = A_arbace_classes_types_lang_desc_A_InstanceOf; i.Init = A_arbace_classes_types_lang_desc_A_Init; i.Table = A_arbace_classes_types_lang_desc_A_members; jrt.RegisterGoType(A_arbace_classes_types_lang_desc_A_class, reflect.TypeFor[A_arbace_classes_types_lang_desc_A]()) }

func A_arbace_classes_types_local_class_name_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_local_class_name_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_local_class_name_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_local_class_name_QMARK__A_New()}; return nil }

func A_arbace_classes_types_local_class_name_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_local_class_name_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_local_class_name_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_local_class_name_QMARK__A_invoke, New: A_arbace_classes_types_local_class_name_QMARK__A_new, Get: A_arbace_classes_types_local_class_name_QMARK__A_get}

var A_arbace_classes_types_local_class_name_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$local_class_name_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "local_class_name_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_local_class_name_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_local_class_name_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_local_class_name_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_local_class_name_QMARK__A_Init; i.Table = A_arbace_classes_types_local_class_name_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_local_class_name_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_local_class_name_QMARK__A]()) }

func A_arbace_classes_types_method_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_method_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_method_desc_A_New()}; return nil }

func A_arbace_classes_types_method_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_method_desc_A_fn_class)}; return nil }

var A_arbace_classes_types_method_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_method_desc_A_invoke, New: A_arbace_classes_types_method_desc_A_new, Get: A_arbace_classes_types_method_desc_A_get}

var A_arbace_classes_types_method_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$method_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "method_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_method_desc_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_method_desc_A_class.Info(); i.IsInstance = A_arbace_classes_types_method_desc_A_InstanceOf; i.Init = A_arbace_classes_types_method_desc_A_Init; i.Table = A_arbace_classes_types_method_desc_A_members; jrt.RegisterGoType(A_arbace_classes_types_method_desc_A_class, reflect.TypeFor[A_arbace_classes_types_method_desc_A]()) }

func A_arbace_classes_types_numeric_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_numeric_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_numeric_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_numeric_QMARK__A_New()}; return nil }

func A_arbace_classes_types_numeric_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_numeric_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_numeric_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_numeric_QMARK__A_invoke, New: A_arbace_classes_types_numeric_QMARK__A_new, Get: A_arbace_classes_types_numeric_QMARK__A_get}

var A_arbace_classes_types_numeric_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$numeric_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "numeric_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_numeric_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_numeric_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_numeric_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_numeric_QMARK__A_Init; i.Table = A_arbace_classes_types_numeric_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_numeric_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_numeric_QMARK__A]()) }

func A_arbace_classes_types_package_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_package_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_package_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_package_of_A_New()}; return nil }

func A_arbace_classes_types_package_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_package_of_A_fn_class)}; return nil }

var A_arbace_classes_types_package_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_package_of_A_invoke, New: A_arbace_classes_types_package_of_A_new, Get: A_arbace_classes_types_package_of_A_get}

var A_arbace_classes_types_package_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$package_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "package_of", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_package_of_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_package_of_A_class.Info(); i.IsInstance = A_arbace_classes_types_package_of_A_InstanceOf; i.Init = A_arbace_classes_types_package_of_A_Init; i.Table = A_arbace_classes_types_package_of_A_members; jrt.RegisterGoType(A_arbace_classes_types_package_of_A_class, reflect.TypeFor[A_arbace_classes_types_package_of_A]()) }

func A_arbace_classes_types_parse_method_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_method_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_method_desc_A_New()}; return nil }

func A_arbace_classes_types_parse_method_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_method_desc_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_method_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_method_desc_A_invoke, New: A_arbace_classes_types_parse_method_desc_A_new, Get: A_arbace_classes_types_parse_method_desc_A_get}

var A_arbace_classes_types_parse_method_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_method_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "parse_method_desc", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_method_desc_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_method_desc_A_InstanceOf; i.Init = A_arbace_classes_types_parse_method_desc_A_Init; i.Table = A_arbace_classes_types_parse_method_desc_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_method_desc_A_class, reflect.TypeFor[A_arbace_classes_types_parse_method_desc_A]()) }

func A_arbace_classes_types_parse_method_desc_fn__48000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_method_desc_fn__48000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_types_parse_method_desc_fn__48000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_method_desc_fn__48000045_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_method_desc_fn__48000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_method_desc_fn__48000045_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_method_desc_fn__48000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_method_desc_fn__48000045_A_invoke, New: A_arbace_classes_types_parse_method_desc_fn__48000045_A_new, Get: A_arbace_classes_types_parse_method_desc_fn__48000045_A_get}

var A_arbace_classes_types_parse_method_desc_fn__48000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_method_desc$fn__48000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_types_parse_method_desc_A_class, Simple: "fn__48000045", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_fn__48000045_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_method_desc_fn__48000045_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_method_desc_fn__48000045_A_InstanceOf; i.Init = A_arbace_classes_types_parse_method_desc_fn__48000045_A_Init; i.Table = A_arbace_classes_types_parse_method_desc_fn__48000045_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_method_desc_fn__48000045_A_class, reflect.TypeFor[A_arbace_classes_types_parse_method_desc_fn__48000045_A]()) }

func A_arbace_classes_types_parse_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_parse_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_A_New()}; return nil }

func A_arbace_classes_types_parse_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_A_invoke, New: A_arbace_classes_types_parse_type_A_new, Get: A_arbace_classes_types_parse_type_A_get}

var A_arbace_classes_types_parse_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "parse_type", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_A_Init; i.Table = A_arbace_classes_types_parse_type_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_A]()) }

func A_arbace_classes_types_parse_type_fn__48000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_fn__48000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_fn__48000063_A_New()}; return nil }

func A_arbace_classes_types_parse_type_fn__48000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_fn__48000063_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_fn__48000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_fn__48000063_A_invoke, New: A_arbace_classes_types_parse_type_fn__48000063_A_new, Get: A_arbace_classes_types_parse_type_fn__48000063_A_get}

var A_arbace_classes_types_parse_type_fn__48000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type$fn__48000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_parse_type_A_class, Simple: "fn__48000063", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000063_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_fn__48000063_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_fn__48000063_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_fn__48000063_A_Init; i.Table = A_arbace_classes_types_parse_type_fn__48000063_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_fn__48000063_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_fn__48000063_A]()) }

func A_arbace_classes_types_parse_type_fn__48000071_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_fn__48000071_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_fn__48000071_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000071_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_fn__48000071_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_fn__48000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_fn__48000071_A_invoke, New: A_arbace_classes_types_parse_type_fn__48000071_A_new, Get: A_arbace_classes_types_parse_type_fn__48000071_A_get}

var A_arbace_classes_types_parse_type_fn__48000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type$fn__48000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_parse_type_A_class, Simple: "fn__48000071", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000071_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_fn__48000071_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_fn__48000071_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_fn__48000071_A_Init; i.Table = A_arbace_classes_types_parse_type_fn__48000071_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_fn__48000071_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_fn__48000071_A]()) }

func A_arbace_classes_types_parse_type_fn__48000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_fn__48000073_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_fn__48000073_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_fn__48000073_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_fn__48000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_fn__48000073_A_invoke, New: A_arbace_classes_types_parse_type_fn__48000073_A_new, Get: A_arbace_classes_types_parse_type_fn__48000073_A_get}

var A_arbace_classes_types_parse_type_fn__48000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type$fn__48000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_parse_type_A_class, Simple: "fn__48000073", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000073_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_fn__48000073_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_fn__48000073_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_fn__48000073_A_Init; i.Table = A_arbace_classes_types_parse_type_fn__48000073_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_fn__48000073_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_fn__48000073_A]()) }

func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_invoke, New: A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_new, Get: A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_get}

var A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type$fn__48000073$fn__48000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_parse_type_fn__48000073_A_class, Simple: "fn__48000077", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_Init; i.Table = A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_fn__48000073_fn__48000077_A]()) }

func A_arbace_classes_types_parse_type_fn__48000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_fn__48000080_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_fn__48000080_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_parse_type_fn__48000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_fn__48000080_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_fn__48000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_fn__48000080_A_invoke, New: A_arbace_classes_types_parse_type_fn__48000080_A_new, Get: A_arbace_classes_types_parse_type_fn__48000080_A_get}

var A_arbace_classes_types_parse_type_fn__48000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type$fn__48000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_parse_type_A_class, Simple: "fn__48000080", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_fn__48000080_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_fn__48000080_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_fn__48000080_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_fn__48000080_A_Init; i.Table = A_arbace_classes_types_parse_type_fn__48000080_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_fn__48000080_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_fn__48000080_A]()) }

func A_arbace_classes_types_parse_type_p__48000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_p__48000066_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_type_p__48000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_p__48000066_A_New()}; return nil }

func A_arbace_classes_types_parse_type_p__48000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_p__48000066_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_p__48000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_p__48000066_A_invoke, New: A_arbace_classes_types_parse_type_p__48000066_A_new, Get: A_arbace_classes_types_parse_type_p__48000066_A_get}

var A_arbace_classes_types_parse_type_p__48000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type$p__48000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_parse_type_A_class, Simple: "p__48000066", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_p__48000066_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_p__48000066_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_p__48000066_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_p__48000066_A_Init; i.Table = A_arbace_classes_types_parse_type_p__48000066_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_p__48000066_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_p__48000066_A]()) }

func A_arbace_classes_types_parse_type_params_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_params_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_parse_type_params_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_params_A_New()}; return nil }

func A_arbace_classes_types_parse_type_params_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_params_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_params_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_params_A_invoke, New: A_arbace_classes_types_parse_type_params_A_new, Get: A_arbace_classes_types_parse_type_params_A_get}

var A_arbace_classes_types_parse_type_params_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type_params", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "parse_type_params", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_params_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_params_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_params_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_params_A_Init; i.Table = A_arbace_classes_types_parse_type_params_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_params_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_params_A]()) }

func A_arbace_classes_types_parse_type_params_fn__48000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_params_fn__48000093_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_type_params_fn__48000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_params_fn__48000093_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_parse_type_params_fn__48000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_params_fn__48000093_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_params_fn__48000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_params_fn__48000093_A_invoke, New: A_arbace_classes_types_parse_type_params_fn__48000093_A_new, Get: A_arbace_classes_types_parse_type_params_fn__48000093_A_get}

var A_arbace_classes_types_parse_type_params_fn__48000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type_params$fn__48000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_parse_type_params_A_class, Simple: "fn__48000093", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_params_fn__48000093_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_params_fn__48000093_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_params_fn__48000093_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_params_fn__48000093_A_Init; i.Table = A_arbace_classes_types_parse_type_params_fn__48000093_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_params_fn__48000093_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_params_fn__48000093_A]()) }

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_fn_class)}; return nil }

var A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_invoke, New: A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_new, Get: A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_get}

var A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$parse_type_params$fn__48000093$fn__48000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_parse_type_params_fn__48000093_A_class, Simple: "fn__48000097", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_class.Info(); i.IsInstance = A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_InstanceOf; i.Init = A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_Init; i.Table = A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_members; jrt.RegisterGoType(A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A_class, reflect.TypeFor[A_arbace_classes_types_parse_type_params_fn__48000093_fn__48000097_A]()) }

func A_arbace_classes_types_prim_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_prim_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_prim_QMARK__A_New()}; return nil }

func A_arbace_classes_types_prim_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_prim_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_prim_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_prim_QMARK__A_invoke, New: A_arbace_classes_types_prim_QMARK__A_new, Get: A_arbace_classes_types_prim_QMARK__A_get}

var A_arbace_classes_types_prim_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$prim_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "prim_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_prim_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_prim_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_prim_QMARK__A_Init; i.Table = A_arbace_classes_types_prim_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_prim_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_prim_QMARK__A]()) }

func A_arbace_classes_types_ref_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_ref_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_ref_QMARK__A_New()}; return nil }

func A_arbace_classes_types_ref_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_ref_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_ref_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_ref_QMARK__A_invoke, New: A_arbace_classes_types_ref_QMARK__A_new, Get: A_arbace_classes_types_ref_QMARK__A_get}

var A_arbace_classes_types_ref_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$ref_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "ref_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_ref_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_ref_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_ref_QMARK__A_Init; i.Table = A_arbace_classes_types_ref_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_ref_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_ref_QMARK__A]()) }

func A_arbace_classes_types_reflect__GT_tnode_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_reflect__GT_tnode_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_reflect__GT_tnode_A_New()}; return nil }

func A_arbace_classes_types_reflect__GT_tnode_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_reflect__GT_tnode_A_fn_class)}; return nil }

var A_arbace_classes_types_reflect__GT_tnode_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_reflect__GT_tnode_A_invoke, New: A_arbace_classes_types_reflect__GT_tnode_A_new, Get: A_arbace_classes_types_reflect__GT_tnode_A_get}

var A_arbace_classes_types_reflect__GT_tnode_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$reflect__GT_tnode", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "reflect__GT_tnode", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_reflect__GT_tnode_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_reflect__GT_tnode_A_class.Info(); i.IsInstance = A_arbace_classes_types_reflect__GT_tnode_A_InstanceOf; i.Init = A_arbace_classes_types_reflect__GT_tnode_A_Init; i.Table = A_arbace_classes_types_reflect__GT_tnode_A_members; jrt.RegisterGoType(A_arbace_classes_types_reflect__GT_tnode_A_class, reflect.TypeFor[A_arbace_classes_types_reflect__GT_tnode_A]()) }

func A_arbace_classes_types_signature_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_signature_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_signature_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_signature_A_New()}; return nil }

func A_arbace_classes_types_signature_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_signature_A_fn_class)}; return nil }

var A_arbace_classes_types_signature_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_signature_A_invoke, New: A_arbace_classes_types_signature_A_new, Get: A_arbace_classes_types_signature_A_get}

var A_arbace_classes_types_signature_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$signature", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "signature", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_signature_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_signature_A_class.Info(); i.IsInstance = A_arbace_classes_types_signature_A_InstanceOf; i.Init = A_arbace_classes_types_signature_A_Init; i.Table = A_arbace_classes_types_signature_A_members; jrt.RegisterGoType(A_arbace_classes_types_signature_A_class, reflect.TypeFor[A_arbace_classes_types_signature_A]()) }

func A_arbace_classes_types_simple_name_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_simple_name_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_simple_name_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_simple_name_of_A_New()}; return nil }

func A_arbace_classes_types_simple_name_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_simple_name_of_A_fn_class)}; return nil }

var A_arbace_classes_types_simple_name_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_simple_name_of_A_invoke, New: A_arbace_classes_types_simple_name_of_A_new, Get: A_arbace_classes_types_simple_name_of_A_get}

var A_arbace_classes_types_simple_name_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$simple_name_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "simple_name_of", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_simple_name_of_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_simple_name_of_A_class.Info(); i.IsInstance = A_arbace_classes_types_simple_name_of_A_InstanceOf; i.Init = A_arbace_classes_types_simple_name_of_A_Init; i.Table = A_arbace_classes_types_simple_name_of_A_members; jrt.RegisterGoType(A_arbace_classes_types_simple_name_of_A_class, reflect.TypeFor[A_arbace_classes_types_simple_name_of_A]()) }

func A_arbace_classes_types_size_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_size_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_size_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_size_A_New()}; return nil }

func A_arbace_classes_types_size_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_size_A_fn_class)}; return nil }

var A_arbace_classes_types_size_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_size_A_invoke, New: A_arbace_classes_types_size_A_new, Get: A_arbace_classes_types_size_A_get}

var A_arbace_classes_types_size_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$size", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "size", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_size_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_size_A_class.Info(); i.IsInstance = A_arbace_classes_types_size_A_InstanceOf; i.Init = A_arbace_classes_types_size_A_Init; i.Table = A_arbace_classes_types_size_A_members; jrt.RegisterGoType(A_arbace_classes_types_size_A_class, reflect.TypeFor[A_arbace_classes_types_size_A]()) }

func A_arbace_classes_types_subst_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_subst_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_subst_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_subst_A_New()}; return nil }

func A_arbace_classes_types_subst_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_subst_A_fn_class)}; return nil }

var A_arbace_classes_types_subst_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_subst_A_invoke, New: A_arbace_classes_types_subst_A_new, Get: A_arbace_classes_types_subst_A_get}

var A_arbace_classes_types_subst_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$subst", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "subst", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_subst_A_class.Info(); i.IsInstance = A_arbace_classes_types_subst_A_InstanceOf; i.Init = A_arbace_classes_types_subst_A_Init; i.Table = A_arbace_classes_types_subst_A_members; jrt.RegisterGoType(A_arbace_classes_types_subst_A_class, reflect.TypeFor[A_arbace_classes_types_subst_A]()) }

func A_arbace_classes_types_subst_fn__48000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_subst_fn__48000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_subst_fn__48000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_subst_fn__48000134_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_subst_fn__48000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_subst_fn__48000134_A_fn_class)}; return nil }

var A_arbace_classes_types_subst_fn__48000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_subst_fn__48000134_A_invoke, New: A_arbace_classes_types_subst_fn__48000134_A_new, Get: A_arbace_classes_types_subst_fn__48000134_A_get}

var A_arbace_classes_types_subst_fn__48000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$subst$fn__48000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_subst_A_class, Simple: "fn__48000134", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000134_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_subst_fn__48000134_A_class.Info(); i.IsInstance = A_arbace_classes_types_subst_fn__48000134_A_InstanceOf; i.Init = A_arbace_classes_types_subst_fn__48000134_A_Init; i.Table = A_arbace_classes_types_subst_fn__48000134_A_members; jrt.RegisterGoType(A_arbace_classes_types_subst_fn__48000134_A_class, reflect.TypeFor[A_arbace_classes_types_subst_fn__48000134_A]()) }

func A_arbace_classes_types_subst_fn__48000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_subst_fn__48000137_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_subst_fn__48000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_subst_fn__48000137_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_subst_fn__48000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_subst_fn__48000137_A_fn_class)}; return nil }

var A_arbace_classes_types_subst_fn__48000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_subst_fn__48000137_A_invoke, New: A_arbace_classes_types_subst_fn__48000137_A_new, Get: A_arbace_classes_types_subst_fn__48000137_A_get}

var A_arbace_classes_types_subst_fn__48000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$subst$fn__48000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_subst_A_class, Simple: "fn__48000137", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000137_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_subst_fn__48000137_A_class.Info(); i.IsInstance = A_arbace_classes_types_subst_fn__48000137_A_InstanceOf; i.Init = A_arbace_classes_types_subst_fn__48000137_A_Init; i.Table = A_arbace_classes_types_subst_fn__48000137_A_members; jrt.RegisterGoType(A_arbace_classes_types_subst_fn__48000137_A_class, reflect.TypeFor[A_arbace_classes_types_subst_fn__48000137_A]()) }

func A_arbace_classes_types_subst_fn__48000139_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_subst_fn__48000139_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_subst_fn__48000139_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_subst_fn__48000139_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_subst_fn__48000139_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_subst_fn__48000139_A_fn_class)}; return nil }

var A_arbace_classes_types_subst_fn__48000139_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_subst_fn__48000139_A_invoke, New: A_arbace_classes_types_subst_fn__48000139_A_new, Get: A_arbace_classes_types_subst_fn__48000139_A_get}

var A_arbace_classes_types_subst_fn__48000139_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$subst$fn__48000139", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_subst_A_class, Simple: "fn__48000139", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000139_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_subst_fn__48000139_A_class.Info(); i.IsInstance = A_arbace_classes_types_subst_fn__48000139_A_InstanceOf; i.Init = A_arbace_classes_types_subst_fn__48000139_A_Init; i.Table = A_arbace_classes_types_subst_fn__48000139_A_members; jrt.RegisterGoType(A_arbace_classes_types_subst_fn__48000139_A_class, reflect.TypeFor[A_arbace_classes_types_subst_fn__48000139_A]()) }

func A_arbace_classes_types_subst_fn__48000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_subst_fn__48000141_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_subst_fn__48000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_subst_fn__48000141_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_subst_fn__48000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_subst_fn__48000141_A_fn_class)}; return nil }

var A_arbace_classes_types_subst_fn__48000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_subst_fn__48000141_A_invoke, New: A_arbace_classes_types_subst_fn__48000141_A_new, Get: A_arbace_classes_types_subst_fn__48000141_A_get}

var A_arbace_classes_types_subst_fn__48000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$subst$fn__48000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_subst_A_class, Simple: "fn__48000141", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000141_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_subst_fn__48000141_A_class.Info(); i.IsInstance = A_arbace_classes_types_subst_fn__48000141_A_InstanceOf; i.Init = A_arbace_classes_types_subst_fn__48000141_A_Init; i.Table = A_arbace_classes_types_subst_fn__48000141_A_members; jrt.RegisterGoType(A_arbace_classes_types_subst_fn__48000141_A_class, reflect.TypeFor[A_arbace_classes_types_subst_fn__48000141_A]()) }

func A_arbace_classes_types_subst_fn__48000143_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_subst_fn__48000143_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_subst_fn__48000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_subst_fn__48000143_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_subst_fn__48000143_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_subst_fn__48000143_A_fn_class)}; return nil }

var A_arbace_classes_types_subst_fn__48000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_subst_fn__48000143_A_invoke, New: A_arbace_classes_types_subst_fn__48000143_A_new, Get: A_arbace_classes_types_subst_fn__48000143_A_get}

var A_arbace_classes_types_subst_fn__48000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$subst$fn__48000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_subst_A_class, Simple: "fn__48000143", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_subst_fn__48000143_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_subst_fn__48000143_A_class.Info(); i.IsInstance = A_arbace_classes_types_subst_fn__48000143_A_InstanceOf; i.Init = A_arbace_classes_types_subst_fn__48000143_A_Init; i.Table = A_arbace_classes_types_subst_fn__48000143_A_members; jrt.RegisterGoType(A_arbace_classes_types_subst_fn__48000143_A_class, reflect.TypeFor[A_arbace_classes_types_subst_fn__48000143_A]()) }

func A_arbace_classes_types_type_anns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_anns_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_type_anns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_anns_A_New()}; return nil }

func A_arbace_classes_types_type_anns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_anns_A_fn_class)}; return nil }

var A_arbace_classes_types_type_anns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_anns_A_invoke, New: A_arbace_classes_types_type_anns_A_new, Get: A_arbace_classes_types_type_anns_A_get}

var A_arbace_classes_types_type_anns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_anns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "type_anns", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_anns_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_anns_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_anns_A_InstanceOf; i.Init = A_arbace_classes_types_type_anns_A_Init; i.Table = A_arbace_classes_types_type_anns_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_anns_A_class, reflect.TypeFor[A_arbace_classes_types_type_anns_A]()) }

func A_arbace_classes_types_type_anns_walk__48000146_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_anns_walk__48000146_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_type_anns_walk__48000146_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_anns_walk__48000146_A_New()}; return nil }

func A_arbace_classes_types_type_anns_walk__48000146_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_anns_walk__48000146_A_fn_class)}; return nil }

var A_arbace_classes_types_type_anns_walk__48000146_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_anns_walk__48000146_A_invoke, New: A_arbace_classes_types_type_anns_walk__48000146_A_new, Get: A_arbace_classes_types_type_anns_walk__48000146_A_get}

var A_arbace_classes_types_type_anns_walk__48000146_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_anns$walk__48000146", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_type_anns_A_class, Simple: "walk__48000146", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_anns_walk__48000146_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_anns_walk__48000146_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_anns_walk__48000146_A_InstanceOf; i.Init = A_arbace_classes_types_type_anns_walk__48000146_A_Init; i.Table = A_arbace_classes_types_type_anns_walk__48000146_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_anns_walk__48000146_A_class, reflect.TypeFor[A_arbace_classes_types_type_anns_walk__48000146_A]()) }

func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_fn_class)}; return nil }

var A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_invoke, New: A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_new, Get: A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_get}

var A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_anns$walk__48000146$fn__48000148", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_type_anns_walk__48000146_A_class, Simple: "fn__48000148", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_InstanceOf; i.Init = A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_Init; i.Table = A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A_class, reflect.TypeFor[A_arbace_classes_types_type_anns_walk__48000146_fn__48000148_A]()) }

func A_arbace_classes_types_type_params_signature_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_params_signature_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_type_params_signature_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_params_signature_A_New()}; return nil }

func A_arbace_classes_types_type_params_signature_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_params_signature_A_fn_class)}; return nil }

var A_arbace_classes_types_type_params_signature_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_params_signature_A_invoke, New: A_arbace_classes_types_type_params_signature_A_new, Get: A_arbace_classes_types_type_params_signature_A_get}

var A_arbace_classes_types_type_params_signature_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_params_signature", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "type_params_signature", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_params_signature_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_params_signature_A_InstanceOf; i.Init = A_arbace_classes_types_type_params_signature_A_Init; i.Table = A_arbace_classes_types_type_params_signature_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_params_signature_A_class, reflect.TypeFor[A_arbace_classes_types_type_params_signature_A]()) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_fn_class)}; return nil }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_invoke, New: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_new, Get: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_get}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_params_signature$iter__48000101__48000105", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_type_params_signature_A_class, Simple: "iter__48000101__48000105", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_InstanceOf; i.Init = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_Init; i.Table = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_class, reflect.TypeFor[A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A]()) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_fn_class)}; return nil }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_invoke, New: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_new, Get: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_get}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_A_class, Simple: "fn__48000106", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_InstanceOf; i.Init = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_Init; i.Table = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_class, reflect.TypeFor[A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A]()) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_fn_class)}; return nil }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_invoke, New: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_new, Get: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_get}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106$fn__48000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_class, Simple: "fn__48000107", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_InstanceOf; i.Init = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_Init; i.Table = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_class, reflect.TypeFor[A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A]()) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_fn_class)}; return nil }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_invoke, New: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_new, Get: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_get}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106$fn__48000107$fn__48000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_A_class, Simple: "fn__48000110", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_InstanceOf; i.Init = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_Init; i.Table = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A_class, reflect.TypeFor[A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000107_fn__48000110_A]()) }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_New_O(args[0])}; return nil }

func A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_fn_class)}; return nil }

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_invoke, New: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_new, Get: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_get}

var A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$type_params_signature$iter__48000101__48000105$fn__48000106$fn__48000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_A_class, Simple: "fn__48000115", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_class.Info(); i.IsInstance = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_InstanceOf; i.Init = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_Init; i.Table = A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_members; jrt.RegisterGoType(A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A_class, reflect.TypeFor[A_arbace_classes_types_type_params_signature_iter__48000101__48000105_fn__48000106_fn__48000115_A]()) }

func A_arbace_classes_types_void_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_void_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_void_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_void_QMARK__A_New()}; return nil }

func A_arbace_classes_types_void_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_void_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_types_void_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_void_QMARK__A_invoke, New: A_arbace_classes_types_void_QMARK__A_new, Get: A_arbace_classes_types_void_QMARK__A_get}

var A_arbace_classes_types_void_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$void_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_A_class, Simple: "void_QMARK_", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_void_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_void_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_types_void_QMARK__A_InstanceOf; i.Init = A_arbace_classes_types_void_QMARK__A_Init; i.Table = A_arbace_classes_types_void_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_types_void_QMARK__A_class, reflect.TypeFor[A_arbace_classes_types_void_QMARK__A]()) }

func A_arbace_classes_types_with_anns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_with_anns_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_types_with_anns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_with_anns_A_New()}; return nil }

func A_arbace_classes_types_with_anns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_with_anns_A_fn_class)}; return nil }

var A_arbace_classes_types_with_anns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_with_anns_A_invoke, New: A_arbace_classes_types_with_anns_A_new, Get: A_arbace_classes_types_with_anns_A_get}

var A_arbace_classes_types_with_anns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$with_anns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_types_A_class, Simple: "with_anns", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_with_anns_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_with_anns_A_class.Info(); i.IsInstance = A_arbace_classes_types_with_anns_A_InstanceOf; i.Init = A_arbace_classes_types_with_anns_A_Init; i.Table = A_arbace_classes_types_with_anns_A_members; jrt.RegisterGoType(A_arbace_classes_types_with_anns_A_class, reflect.TypeFor[A_arbace_classes_types_with_anns_A]()) }

func A_arbace_classes_types_with_anns_fn__48000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_types_with_anns_fn__48000054_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_types_with_anns_fn__48000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types_with_anns_fn__48000054_A_New()}; return nil }

func A_arbace_classes_types_with_anns_fn__48000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_types_with_anns_fn__48000054_A_fn_class)}; return nil }

var A_arbace_classes_types_with_anns_fn__48000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_types_with_anns_fn__48000054_A_invoke, New: A_arbace_classes_types_with_anns_fn__48000054_A_new, Get: A_arbace_classes_types_with_anns_fn__48000054_A_get}

var A_arbace_classes_types_with_anns_fn__48000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types$with_anns$fn__48000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_types_with_anns_A_class, Simple: "fn__48000054", Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types_with_anns_fn__48000054_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types_with_anns_fn__48000054_A_class.Info(); i.IsInstance = A_arbace_classes_types_with_anns_fn__48000054_A_InstanceOf; i.Init = A_arbace_classes_types_with_anns_fn__48000054_A_Init; i.Table = A_arbace_classes_types_with_anns_fn__48000054_A_members; jrt.RegisterGoType(A_arbace_classes_types_with_anns_fn__48000054_A_class, reflect.TypeFor[A_arbace_classes_types_with_anns_fn__48000054_A]()) }

func A_arbace_classes_types__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_types__init_A_Load__O(); case 1: return A_arbace_classes_types__init_A_Unit0__O(); case 2: return A_arbace_classes_types__init_A_Unit1__O(); case 3: return A_arbace_classes_types__init_A_Unit10__O(); case 4: return A_arbace_classes_types__init_A_Unit11__O(); case 5: return A_arbace_classes_types__init_A_Unit12__O(); case 6: return A_arbace_classes_types__init_A_Unit13__O(); case 7: return A_arbace_classes_types__init_A_Unit14__O(); case 8: return A_arbace_classes_types__init_A_Unit15__O(); case 9: return A_arbace_classes_types__init_A_Unit16__O(); case 10: return A_arbace_classes_types__init_A_Unit17__O(); case 11: return A_arbace_classes_types__init_A_Unit18__O(); case 12: return A_arbace_classes_types__init_A_Unit19__O(); case 13: return A_arbace_classes_types__init_A_Unit2__O(); case 14: return A_arbace_classes_types__init_A_Unit20__O(); case 15: return A_arbace_classes_types__init_A_Unit21__O(); case 16: return A_arbace_classes_types__init_A_Unit22__O(); case 17: return A_arbace_classes_types__init_A_Unit23__O(); case 18: return A_arbace_classes_types__init_A_Unit24__O(); case 19: return A_arbace_classes_types__init_A_Unit25__O(); case 20: return A_arbace_classes_types__init_A_Unit26__O(); case 21: return A_arbace_classes_types__init_A_Unit27__O(); case 22: return A_arbace_classes_types__init_A_Unit28__O(); case 23: return A_arbace_classes_types__init_A_Unit29__O(); case 24: return A_arbace_classes_types__init_A_Unit3__O(); case 25: return A_arbace_classes_types__init_A_Unit30__O(); case 26: return A_arbace_classes_types__init_A_Unit31__O(); case 27: return A_arbace_classes_types__init_A_Unit32__O(); case 28: return A_arbace_classes_types__init_A_Unit33__O(); case 29: return A_arbace_classes_types__init_A_Unit34__O(); case 30: return A_arbace_classes_types__init_A_Unit35__O(); case 31: return A_arbace_classes_types__init_A_Unit36__O(); case 32: return A_arbace_classes_types__init_A_Unit37__O(); case 33: return A_arbace_classes_types__init_A_Unit38__O(); case 34: return A_arbace_classes_types__init_A_Unit39__O(); case 35: return A_arbace_classes_types__init_A_Unit4__O(); case 36: return A_arbace_classes_types__init_A_Unit40__O(); case 37: return A_arbace_classes_types__init_A_Unit41__O(); case 38: return A_arbace_classes_types__init_A_Unit42__O(); case 39: return A_arbace_classes_types__init_A_Unit43__O(); case 40: return A_arbace_classes_types__init_A_Unit44__O(); case 41: return A_arbace_classes_types__init_A_Unit45__O(); case 42: return A_arbace_classes_types__init_A_Unit46__O(); case 43: return A_arbace_classes_types__init_A_Unit47__O(); case 44: return A_arbace_classes_types__init_A_Unit48__O(); case 45: return A_arbace_classes_types__init_A_Unit5__O(); case 46: return A_arbace_classes_types__init_A_Unit6__O(); case 47: return A_arbace_classes_types__init_A_Unit7__O(); case 48: return A_arbace_classes_types__init_A_Unit8__O(); case 49: return A_arbace_classes_types__init_A_Unit9__O()}; return nil }

func A_arbace_classes_types__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_types__init_A_New()}; return nil }

var A_arbace_classes_types__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_types__init_A_invoke, New: A_arbace_classes_types__init_A_new}

var A_arbace_classes_types__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.types__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_types.A_arbace_classes_types__init_A", Source: "types.ae"})

func init() { i := A_arbace_classes_types__init_A_class.Info(); i.IsInstance = A_arbace_classes_types__init_A_InstanceOf; i.Init = A_arbace_classes_types__init_A_Init; i.Table = A_arbace_classes_types__init_A_members; jrt.RegisterGoType(A_arbace_classes_types__init_A_class, reflect.TypeFor[A_arbace_classes_types__init_A]()) }
