//line aot_arbace_repr_clojure_rules__init.ae:1
package aot_arbace_repr_clojure_rules

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit0__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_clojure_rules__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules__init_A_const_1) }
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit1__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_clojure_rules__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_2)) }
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit2__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit3__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_clojure_rules__init_A_const_1)).Equals_O__Z(A_arbace_repr_clojure_rules__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_clojure_rules__init_A_Load__O() any { A_arbace_repr_clojure_rules__init_A_Init(); jrt.StartCheck(); A_arbace_repr_clojure_rules__init_A_Unit0__O(); A_arbace_repr_clojure_rules__init_A_Unit1__O(); A_arbace_repr_clojure_rules__init_A_Unit2__O(); A_arbace_repr_clojure_rules__init_A_Unit3__O(); A_arbace_repr_clojure_rules__init_A_Unit4__O(); A_arbace_repr_clojure_rules__init_A_Unit5__O(); A_arbace_repr_clojure_rules__init_A_Unit6__O(); A_arbace_repr_clojure_rules__init_A_Unit7__O(); A_arbace_repr_clojure_rules__init_A_Unit8__O(); A_arbace_repr_clojure_rules__init_A_Unit9__O(); A_arbace_repr_clojure_rules__init_A_Unit10__O(); A_arbace_repr_clojure_rules__init_A_Unit11__O(); A_arbace_repr_clojure_rules__init_A_Unit12__O(); A_arbace_repr_clojure_rules__init_A_Unit13__O(); A_arbace_repr_clojure_rules__init_A_Unit14__O(); A_arbace_repr_clojure_rules__init_A_Unit15__O(); A_arbace_repr_clojure_rules__init_A_Unit16__O(); A_arbace_repr_clojure_rules__init_A_Unit17__O(); A_arbace_repr_clojure_rules__init_A_Unit18__O(); A_arbace_repr_clojure_rules__init_A_Unit19__O(); A_arbace_repr_clojure_rules__init_A_Unit20__O(); A_arbace_repr_clojure_rules__init_A_Unit21__O(); A_arbace_repr_clojure_rules__init_A_Unit22__O(); A_arbace_repr_clojure_rules__init_A_Unit23__O(); A_arbace_repr_clojure_rules__init_A_Unit24__O(); A_arbace_repr_clojure_rules__init_A_Unit25__O(); return nil }

















func A_arbace_repr_clojure_rules__init_A_Unit4__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_4; var tmp2 any = A_arbace_repr_clojure_rules_clojure_source_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_5)); return A_arbace_repr_clojure_rules__init_A_const_4 }



func A_arbace_repr_clojure_rules__init_A_Unit5__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); A_arbace_repr_clojure_rules__init_A_const_6.BindRoot_O__V(A_arbace_repr_clojure_rules__init_A_const_7); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_8)); return A_arbace_repr_clojure_rules__init_A_const_6 }



func A_arbace_repr_clojure_rules__init_A_Unit6__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_9; var tmp2 any = A_arbace_repr_clojure_rules_proxy_methods_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_clojure_rules_proxy_methods_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_clojure_rules_proxy_methods_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_10)); return A_arbace_repr_clojure_rules__init_A_const_9 }




func A_arbace_repr_clojure_rules__init_A_Unit7__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); A_arbace_repr_clojure_rules__init_A_const_11.BindRoot_O__V(A_arbace_repr_clojure_rules__init_A_const_12); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_13)); return A_arbace_repr_clojure_rules__init_A_const_11 }



func A_arbace_repr_clojure_rules__init_A_Unit8__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_14; var tmp2 any = A_arbace_repr_clojure_rules_unproxy_methods_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_15)); return A_arbace_repr_clojure_rules__init_A_const_14 }






func A_arbace_repr_clojure_rules__init_A_Unit9__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); A_arbace_repr_clojure_rules__init_A_const_16.BindRoot_O__V(Lit_45); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_17)); return A_arbace_repr_clojure_rules__init_A_const_16 }

func A_arbace_repr_clojure_rules__init_A_Unit10__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_18; var tmp2 any = A_arbace_repr_clojure_rules_imports_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_19)); return A_arbace_repr_clojure_rules__init_A_const_18 }

func A_arbace_repr_clojure_rules__init_A_Unit11__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_20; var tmp2 any = A_arbace_repr_clojure_rules_security_manager_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_clojure_rules_security_manager_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_21)); return A_arbace_repr_clojure_rules__init_A_const_20 }





























func A_arbace_repr_clojure_rules__init_A_Unit12__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_22; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_repr_clojure_rules__init_A_const_23.GetRawRoot__O()).Invoke_O_O__O(Lit_25, A_arbace_repr_clojure_rules__init_A_const_16.GetRawRoot__O())); var tmp2 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_22; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_24)); return A_arbace_repr_clojure_rules__init_A_const_22 }

func A_arbace_repr_clojure_rules__init_A_Unit13__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_25; var tmp2 any = A_arbace_repr_clojure_rules_unqualify_security_manager_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_26)); return A_arbace_repr_clojure_rules__init_A_const_25 }































func A_arbace_repr_clojure_rules__init_A_Unit14__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_27; var tmp2 any = A_arbace_repr_clojure_rules_arbace_core_names_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_28)); return A_arbace_repr_clojure_rules__init_A_const_27 }






func A_arbace_repr_clojure_rules__init_A_Unit15__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); A_arbace_repr_clojure_rules__init_A_const_29.BindRoot_O__V(A_arbace_repr_clojure_rules__init_A_const_30); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_31)); return A_arbace_repr_clojure_rules__init_A_const_29 }



func A_arbace_repr_clojure_rules__init_A_Unit16__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_32; var tmp2 any = A_arbace_repr_clojure_rules_defined_names_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_clojure_rules_defined_names_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_33)); return A_arbace_repr_clojure_rules__init_A_const_32 }
















func A_arbace_repr_clojure_rules__init_A_Unit17__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_34; var tmp2 any = A_arbace_repr_clojure_rules_insert_at_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_clojure_rules_insert_at_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_repr_clojure_rules_insert_at_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_35)); return A_arbace_repr_clojure_rules__init_A_const_34 }

func A_arbace_repr_clojure_rules__init_A_Unit18__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_36; var tmp2 any = A_arbace_repr_clojure_rules_core_names_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repr_clojure_rules_core_names_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_clojure_rules_core_names_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_37)); return A_arbace_repr_clojure_rules__init_A_const_36 }



























func A_arbace_repr_clojure_rules__init_A_Unit19__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_38; var tmp2 any = A_arbace_repr_clojure_rules_cut_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_clojure_rules_cut_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_clojure_rules_cut_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_39)); return A_arbace_repr_clojure_rules__init_A_const_38 }

func A_arbace_repr_clojure_rules__init_A_Unit20__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_40; var tmp2 any = A_arbace_repr_clojure_rules_uncore_names_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_clojure_rules_uncore_names_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_repr_clojure_rules_uncore_names_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_41)); return A_arbace_repr_clojure_rules__init_A_const_40 }
































func A_arbace_repr_clojure_rules__init_A_Unit21__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_42; var tmp2 any = A_arbace_repr_clojure_rules__init_A_const_44; var tmp3 any = A_arbace_repr_clojure_rules__init_A_const_45; var tmp4 any = A_arbace_repr_clojure_rules__init_A_const_46; var tmp5 any = A_arbace_repr_clojure_rules__init_A_const_47; var tmp6 any = A_arbace_repr_clojure_rules_fn__1700000143_A_New(); var tmp7 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000143_A_fn_class; if





	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_repr_clojure_rules_fn__1700000143_A_fn_class = fncls__20d; tmp7 = fncls__20d } else { tmp7 = fncls__20 }; var tmp8 any = /*line :208:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_repr_clojure_rules__init_A_const_48; var tmp10 any = A_arbace_repr_clojure_rules_fn__1700000145_A_New(); var tmp11 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000145_A_fn_class; if






	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_repr_clojure_rules_fn__1700000145_A_fn_class = fncls__21d; tmp11 = fncls__21d } else { tmp11 = fncls__21 }; var tmp12 any = /*line :208:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp13 any = A_arbace_repr_clojure_rules__init_A_const_49; var tmp14 any = A_arbace_repr_clojure_rules__init_A_const_50; var tmp15 any = A_arbace_repr_clojure_rules__init_A_const_51; var tmp16 any = A_arbace_repr_clojure_rules__init_A_const_52; var tmp17 any = A_arbace_repr_clojure_rules_fn__1700000147_A_New(); var tmp18 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000147_A_fn_class; if











	fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_repr_clojure_rules_fn__1700000147_A_fn_class = fncls__22d; tmp18 = fncls__22d } else { tmp18 = fncls__22 }; var tmp19 any = /*line :208:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, Lit_55, tmp5, tmp8, tmp9, tmp12, tmp13, tmp14, tmp15, Lit_58, tmp16, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil))); var tmp20 any = A_arbace_repr_clojure_rules__init_A_const_44; var tmp21 any = A_arbace_repr_clojure_rules__init_A_const_53; var tmp22 any = A_arbace_repr_clojure_rules__init_A_const_46; var tmp23 any = A_arbace_repr_clojure_rules__init_A_const_47; var tmp24 any; var root_23 any = A_arbace_repr_clojure_rules__init_A_const_54.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_constantly_A_fn_class); var ifn_25 lang.IFn; if

















	linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = jrt.Boolean_TRUE.Ref(); if linked_24 == nil { tmp24 = ifn_25.Invoke_O__O(arg_26) } else { tmp24 = linked_24.(*aot_arbace_core.A_arbace_core_constantly_A).Invoke_O_O__O(root_23, arg_26) }; var tmp25 any = tmp24; var tmp26 any = A_arbace_repr_clojure_rules__init_A_const_48; var tmp27 any = /*line :208:1*/A_arbace_repr_clojure_rules_fn__1700000149_A_New(); var tmp28 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000149_A_fn_class; if


















	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_repr_clojure_rules_fn__1700000149_A_fn_class = fncls__27d; tmp28 = fncls__27d } else { tmp28 = fncls__27 }; var tmp29 any = /*line :208:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var tmp30 any = A_arbace_repr_clojure_rules__init_A_const_49; var tmp31 any = A_arbace_repr_clojure_rules__init_A_const_55; var tmp32 any = A_arbace_repr_clojure_rules__init_A_const_51; var tmp33 any = A_arbace_repr_clojure_rules__init_A_const_52; var tmp34 any = A_arbace_repr_clojure_rules_fn__1700000151_A_New(); var tmp35 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000151_A_fn_class; if






















	fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_repr_clojure_rules_fn__1700000151_A_fn_class = fncls__28d; tmp35 = fncls__28d } else { tmp35 = fncls__28 }; var tmp36 any = /*line :208:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21, tmp22, Lit_60, tmp23, tmp25, tmp26, tmp29, tmp30, tmp31, tmp32, Lit_62, tmp33, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil))); var tmp37 any = A_arbace_repr_clojure_rules__init_A_const_44; var tmp38 any = A_arbace_repr_clojure_rules__init_A_const_56; var tmp39 any = A_arbace_repr_clojure_rules__init_A_const_46; var tmp40 any = A_arbace_repr_clojure_rules__init_A_const_47; var tmp41 any; var root_29 any = A_arbace_repr_clojure_rules__init_A_const_54.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_constantly_A_fn_class); var ifn_31 lang.IFn; if



























	linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = jrt.Boolean_TRUE.Ref(); if linked_30 == nil { tmp41 = ifn_31.Invoke_O__O(arg_32) } else { tmp41 = linked_30.(*aot_arbace_core.A_arbace_core_constantly_A).Invoke_O_O__O(root_29, arg_32) }; var tmp42 any = tmp41; var tmp43 any = A_arbace_repr_clojure_rules__init_A_const_48; var tmp44 any = /*line :208:1*/A_arbace_repr_clojure_rules_fn__1700000153_A_New(); var tmp45 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000153_A_fn_class; if




























	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_repr_clojure_rules_fn__1700000153_A_fn_class = fncls__33d; tmp45 = fncls__33d } else { tmp45 = fncls__33 }; var tmp46 any = /*line :208:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil); var tmp47 any = A_arbace_repr_clojure_rules__init_A_const_49; var tmp48 any = A_arbace_repr_clojure_rules__init_A_const_55; var tmp49 any = A_arbace_repr_clojure_rules__init_A_const_51; var tmp50 any = A_arbace_repr_clojure_rules__init_A_const_52; var tmp51 any = A_arbace_repr_clojure_rules_fn__1700000155_A_New(); var tmp52 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000155_A_fn_class; if































	fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_repr_clojure_rules_fn__1700000155_A_fn_class = fncls__34d; tmp52 = fncls__34d } else { tmp52 = fncls__34 }; var tmp53 any = /*line :208:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp38, tmp39, Lit_64, tmp40, tmp42, tmp43, tmp46, tmp47, tmp48, tmp49, Lit_66, tmp50, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil))); var tmp54 any = A_arbace_repr_clojure_rules__init_A_const_44; var tmp55 any = A_arbace_repr_clojure_rules__init_A_const_57; var tmp56 any = A_arbace_repr_clojure_rules__init_A_const_46; var tmp57 any = A_arbace_repr_clojure_rules__init_A_const_47; var tmp58 any = A_arbace_repr_clojure_rules__init_A_const_4.GetRawRoot__O(); var tmp59 any = A_arbace_repr_clojure_rules__init_A_const_48; var tmp60 any = A_arbace_repr_clojure_rules_fn__1700000157_A_New(); var tmp61 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000157_A_fn_class; if





































	fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_repr_clojure_rules_fn__1700000157_A_fn_class = fncls__35d; tmp61 = fncls__35d } else { tmp61 = fncls__35 }; var tmp62 any = /*line :208:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil); var tmp63 any = A_arbace_repr_clojure_rules__init_A_const_49; var tmp64 any = A_arbace_repr_clojure_rules__init_A_const_55; var tmp65 any = A_arbace_repr_clojure_rules__init_A_const_51; var tmp66 any = A_arbace_repr_clojure_rules__init_A_const_52; var tmp67 any = A_arbace_repr_clojure_rules_fn__1700000159_A_New(); var tmp68 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000159_A_fn_class; if









































	fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_repr_clojure_rules_fn__1700000159_A_fn_class = fncls__36d; tmp68 = fncls__36d } else { tmp68 = fncls__36 }; var tmp69 any = /*line :208:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp54, tmp55, tmp56, Lit_68, tmp57, tmp58, tmp59, tmp62, tmp63, tmp64, tmp65, Lit_70, tmp66, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp67, tmp68, nil))); var tmp70 any = A_arbace_repr_clojure_rules__init_A_const_44; var tmp71 any = A_arbace_repr_clojure_rules__init_A_const_58; var tmp72 any = A_arbace_repr_clojure_rules__init_A_const_46; var tmp73 any = A_arbace_repr_clojure_rules__init_A_const_47; var tmp74 any = A_arbace_repr_clojure_rules__init_A_const_4.GetRawRoot__O(); var tmp75 any = A_arbace_repr_clojure_rules__init_A_const_48; var tmp76 any = A_arbace_repr_clojure_rules_fn__1700000161_A_New(); var tmp77 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000161_A_fn_class; if














































	fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_repr_clojure_rules_fn__1700000161_A_fn_class = fncls__37d; tmp77 = fncls__37d } else { tmp77 = fncls__37 }; var tmp78 any = /*line :208:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp76, tmp77, nil); var tmp79 any = A_arbace_repr_clojure_rules__init_A_const_49; var tmp80 any = A_arbace_repr_clojure_rules__init_A_const_50; var tmp81 any = A_arbace_repr_clojure_rules__init_A_const_51; var tmp82 any = A_arbace_repr_clojure_rules__init_A_const_52; var tmp83 any = A_arbace_repr_clojure_rules_fn__1700000163_A_New(); var tmp84 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000163_A_fn_class; if


















































	fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_repr_clojure_rules_fn__1700000163_A_fn_class = fncls__38d; tmp84 = fncls__38d } else { tmp84 = fncls__38 }; /*line :208:1*/tmp1.BindRoot_O__V(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp19, tmp36, tmp53, tmp69, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp71, tmp72, Lit_72, tmp73, tmp74, tmp75, tmp78, tmp79, tmp80, tmp81, Lit_74, tmp82, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp83, tmp84, nil))))); var tmp85 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_42; tmp85.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_43)); return A_arbace_repr_clojure_rules__init_A_const_42 }




















































func A_arbace_repr_clojure_rules__init_A_Unit22__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); A_arbace_repr_clojure_rules__init_A_const_59.BindRoot_O__V(A_arbace_repr_clojure_rules__init_A_const_60); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_61)); return A_arbace_repr_clojure_rules__init_A_const_59 }





























func A_arbace_repr_clojure_rules__init_A_Unit23__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_62; var tmp2 any = A_arbace_repr_clojure_rules_applicable_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_clojure_rules_applicable_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_repr_clojure_rules_applicable_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_63)); return A_arbace_repr_clojure_rules__init_A_const_62 }




func A_arbace_repr_clojure_rules__init_A_Unit24__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(296, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_64; var tmp2 any = A_arbace_repr_clojure_rules_print_text_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_repr_clojure_rules_print_text_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_clojure_rules_print_text_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_65)); return A_arbace_repr_clojure_rules__init_A_const_64 }







func A_arbace_repr_clojure_rules__init_A_Unit25__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_66; var tmp2 any = A_arbace_repr_clojure_rules_translate_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_clojure_rules_translate_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_clojure_rules_translate_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_67)); return A_arbace_repr_clojure_rules__init_A_const_66 }



type A_arbace_repr_clojure_rules__init_A struct{ jrt.Object }

var A_arbace_repr_clojure_rules__init_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rules__init_A_const_0 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_1 any

var A_arbace_repr_clojure_rules__init_A_const_2 any

var A_arbace_repr_clojure_rules__init_A_const_3 any

var A_arbace_repr_clojure_rules__init_A_const_4 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_5 any

var A_arbace_repr_clojure_rules__init_A_const_6 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_7 any

var A_arbace_repr_clojure_rules__init_A_const_8 any

var A_arbace_repr_clojure_rules__init_A_const_9 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_10 any

var A_arbace_repr_clojure_rules__init_A_const_11 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_12 any

var A_arbace_repr_clojure_rules__init_A_const_13 any

var A_arbace_repr_clojure_rules__init_A_const_14 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_15 any

var A_arbace_repr_clojure_rules__init_A_const_16 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_17 any

var A_arbace_repr_clojure_rules__init_A_const_18 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_19 any

var A_arbace_repr_clojure_rules__init_A_const_20 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_21 any

var A_arbace_repr_clojure_rules__init_A_const_22 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_23 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_24 any

var A_arbace_repr_clojure_rules__init_A_const_25 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_26 any

var A_arbace_repr_clojure_rules__init_A_const_27 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_28 any

var A_arbace_repr_clojure_rules__init_A_const_29 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_30 any

var A_arbace_repr_clojure_rules__init_A_const_31 any

var A_arbace_repr_clojure_rules__init_A_const_32 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_33 any

var A_arbace_repr_clojure_rules__init_A_const_34 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_35 any

var A_arbace_repr_clojure_rules__init_A_const_36 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_37 any

var A_arbace_repr_clojure_rules__init_A_const_38 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_39 any

var A_arbace_repr_clojure_rules__init_A_const_40 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_41 any

var A_arbace_repr_clojure_rules__init_A_const_42 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_43 any

var A_arbace_repr_clojure_rules__init_A_const_44 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_45 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_46 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_47 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_48 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_49 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_50 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_51 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_52 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_53 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_54 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_55 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_56 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_57 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_58 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_59 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_60 any

var A_arbace_repr_clojure_rules__init_A_const_61 any

var A_arbace_repr_clojure_rules__init_A_const_62 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_63 any

var A_arbace_repr_clojure_rules__init_A_const_64 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_65 any

var A_arbace_repr_clojure_rules__init_A_const_66 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_67 any

var A_arbace_repr_clojure_rules__init_A_init jrt.ClassInit

func A_arbace_repr_clojure_rules__init_A_Init() { if !A_arbace_repr_clojure_rules__init_A_init.Done() { A_arbace_repr_clojure_rules__init_A_init.Run(A_arbace_repr_clojure_rules__init_A_clinit) } }

func A_arbace_repr_clojure_rules__init_A_clinit() { A_arbace_repr_clojure_rules__init_A_clinit_p0(); A_arbace_repr_clojure_rules__init_A_clinit_p1(); A_arbace_repr_clojure_rules__init_A_clinit_p2(); A_arbace_repr_clojure_rules__init_A_clinit_p3(); A_arbace_repr_clojure_rules__init_A_clinit_p4(); A_arbace_repr_clojure_rules__init_A_clinit_p5() }

func A_arbace_repr_clojure_rules__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rules__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_39, 102); A_arbace_repr_clojure_rules__init_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[34]); A_arbace_repr_clojure_rules__init_A_const_1 = A_arbace_repr_clojure_rules__init_A_const_pool.A[35]; A_arbace_repr_clojure_rules__init_A_const_2 = A_arbace_repr_clojure_rules__init_A_const_pool.A[36]; A_arbace_repr_clojure_rules__init_A_const_3 = A_arbace_repr_clojure_rules__init_A_const_pool.A[37]; A_arbace_repr_clojure_rules__init_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[38]); A_arbace_repr_clojure_rules__init_A_const_5 = A_arbace_repr_clojure_rules__init_A_const_pool.A[39]; A_arbace_repr_clojure_rules__init_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[40]); A_arbace_repr_clojure_rules__init_A_const_7 = A_arbace_repr_clojure_rules__init_A_const_pool.A[41]; A_arbace_repr_clojure_rules__init_A_const_8 = A_arbace_repr_clojure_rules__init_A_const_pool.A[42]; A_arbace_repr_clojure_rules__init_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[43]); A_arbace_repr_clojure_rules__init_A_const_10 = A_arbace_repr_clojure_rules__init_A_const_pool.A[44]; A_arbace_repr_clojure_rules__init_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[45]); A_arbace_repr_clojure_rules__init_A_const_12 = A_arbace_repr_clojure_rules__init_A_const_pool.A[46] }

func A_arbace_repr_clojure_rules__init_A_clinit_p1() { A_arbace_repr_clojure_rules__init_A_const_13 = A_arbace_repr_clojure_rules__init_A_const_pool.A[47]; A_arbace_repr_clojure_rules__init_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[48]); A_arbace_repr_clojure_rules__init_A_const_15 = A_arbace_repr_clojure_rules__init_A_const_pool.A[49]; A_arbace_repr_clojure_rules__init_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[50]); A_arbace_repr_clojure_rules__init_A_const_17 = A_arbace_repr_clojure_rules__init_A_const_pool.A[51]; A_arbace_repr_clojure_rules__init_A_const_18 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[52]); A_arbace_repr_clojure_rules__init_A_const_19 = A_arbace_repr_clojure_rules__init_A_const_pool.A[53]; A_arbace_repr_clojure_rules__init_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[54]); A_arbace_repr_clojure_rules__init_A_const_21 = A_arbace_repr_clojure_rules__init_A_const_pool.A[55]; A_arbace_repr_clojure_rules__init_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[56]); A_arbace_repr_clojure_rules__init_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[57]); A_arbace_repr_clojure_rules__init_A_const_24 = A_arbace_repr_clojure_rules__init_A_const_pool.A[58]; A_arbace_repr_clojure_rules__init_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[59]) }

func A_arbace_repr_clojure_rules__init_A_clinit_p2() { A_arbace_repr_clojure_rules__init_A_const_26 = A_arbace_repr_clojure_rules__init_A_const_pool.A[60]; A_arbace_repr_clojure_rules__init_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[61]); A_arbace_repr_clojure_rules__init_A_const_28 = A_arbace_repr_clojure_rules__init_A_const_pool.A[62]; A_arbace_repr_clojure_rules__init_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[63]); A_arbace_repr_clojure_rules__init_A_const_30 = A_arbace_repr_clojure_rules__init_A_const_pool.A[64]; A_arbace_repr_clojure_rules__init_A_const_31 = A_arbace_repr_clojure_rules__init_A_const_pool.A[65]; A_arbace_repr_clojure_rules__init_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[66]); A_arbace_repr_clojure_rules__init_A_const_33 = A_arbace_repr_clojure_rules__init_A_const_pool.A[67]; A_arbace_repr_clojure_rules__init_A_const_34 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[68]); A_arbace_repr_clojure_rules__init_A_const_35 = A_arbace_repr_clojure_rules__init_A_const_pool.A[69]; A_arbace_repr_clojure_rules__init_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[70]); A_arbace_repr_clojure_rules__init_A_const_37 = A_arbace_repr_clojure_rules__init_A_const_pool.A[71]; A_arbace_repr_clojure_rules__init_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[72]); A_arbace_repr_clojure_rules__init_A_const_39 = A_arbace_repr_clojure_rules__init_A_const_pool.A[73] }

func A_arbace_repr_clojure_rules__init_A_clinit_p3() { A_arbace_repr_clojure_rules__init_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[74]); A_arbace_repr_clojure_rules__init_A_const_41 = A_arbace_repr_clojure_rules__init_A_const_pool.A[75]; A_arbace_repr_clojure_rules__init_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[76]); A_arbace_repr_clojure_rules__init_A_const_43 = A_arbace_repr_clojure_rules__init_A_const_pool.A[77]; A_arbace_repr_clojure_rules__init_A_const_44 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[78]); A_arbace_repr_clojure_rules__init_A_const_45 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[79]); A_arbace_repr_clojure_rules__init_A_const_46 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[80]); A_arbace_repr_clojure_rules__init_A_const_47 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[81]); A_arbace_repr_clojure_rules__init_A_const_48 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[82]); A_arbace_repr_clojure_rules__init_A_const_49 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[83]); A_arbace_repr_clojure_rules__init_A_const_50 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[84]); A_arbace_repr_clojure_rules__init_A_const_51 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[85]) }

func A_arbace_repr_clojure_rules__init_A_clinit_p4() { A_arbace_repr_clojure_rules__init_A_const_52 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[86]); A_arbace_repr_clojure_rules__init_A_const_53 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[87]); A_arbace_repr_clojure_rules__init_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[88]); A_arbace_repr_clojure_rules__init_A_const_55 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[89]); A_arbace_repr_clojure_rules__init_A_const_56 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[90]); A_arbace_repr_clojure_rules__init_A_const_57 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[91]); A_arbace_repr_clojure_rules__init_A_const_58 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[92]); A_arbace_repr_clojure_rules__init_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[93]); A_arbace_repr_clojure_rules__init_A_const_60 = A_arbace_repr_clojure_rules__init_A_const_pool.A[94]; A_arbace_repr_clojure_rules__init_A_const_61 = A_arbace_repr_clojure_rules__init_A_const_pool.A[95]; A_arbace_repr_clojure_rules__init_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[96]); A_arbace_repr_clojure_rules__init_A_const_63 = A_arbace_repr_clojure_rules__init_A_const_pool.A[97] }

func A_arbace_repr_clojure_rules__init_A_clinit_p5() { A_arbace_repr_clojure_rules__init_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[98]); A_arbace_repr_clojure_rules__init_A_const_65 = A_arbace_repr_clojure_rules__init_A_const_pool.A[99]; A_arbace_repr_clojure_rules__init_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[100]); A_arbace_repr_clojure_rules__init_A_const_67 = A_arbace_repr_clojure_rules__init_A_const_pool.A[101] }

func A_arbace_repr_clojure_rules__init_A_New() *A_arbace_repr_clojure_rules__init_A { A_arbace_repr_clojure_rules__init_A_Init(); t := &A_arbace_repr_clojure_rules__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules__init_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules__init_A_class }

func (t *A_arbace_repr_clojure_rules__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules__init_A); return ok }

func A_arbace_repr_clojure_rules__init_A_Cast(x any) *A_arbace_repr_clojure_rules__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules__init_A_class)) }; return v }
