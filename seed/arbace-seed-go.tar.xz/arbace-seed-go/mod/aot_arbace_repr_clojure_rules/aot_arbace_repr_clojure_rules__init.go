//line aot_arbace_repr_clojure_rules__init.ae:1
package aot_arbace_repr_clojure_rules

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit0__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_clojure_rules__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules__init_A_const_1) }
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit1__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_clojure_rules__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_2)) }
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit2__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_clojure_rules__init_A_Unit3__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_clojure_rules__init_A_const_1)).Equals_O__Z(A_arbace_repr_clojure_rules__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_clojure_rules__init_A_Load__O() any { A_arbace_repr_clojure_rules__init_A_Init(); jrt.StartCheck(); A_arbace_repr_clojure_rules__init_A_Unit0__O(); A_arbace_repr_clojure_rules__init_A_Unit1__O(); A_arbace_repr_clojure_rules__init_A_Unit2__O(); A_arbace_repr_clojure_rules__init_A_Unit3__O(); A_arbace_repr_clojure_rules__init_A_Unit4__O(); A_arbace_repr_clojure_rules__init_A_Unit5__O(); A_arbace_repr_clojure_rules__init_A_Unit6__O(); A_arbace_repr_clojure_rules__init_A_Unit7__O(); A_arbace_repr_clojure_rules__init_A_Unit8__O(); A_arbace_repr_clojure_rules__init_A_Unit9__O(); A_arbace_repr_clojure_rules__init_A_Unit10__O(); A_arbace_repr_clojure_rules__init_A_Unit11__O(); A_arbace_repr_clojure_rules__init_A_Unit12__O(); A_arbace_repr_clojure_rules__init_A_Unit13__O(); A_arbace_repr_clojure_rules__init_A_Unit14__O(); A_arbace_repr_clojure_rules__init_A_Unit15__O(); A_arbace_repr_clojure_rules__init_A_Unit16__O(); A_arbace_repr_clojure_rules__init_A_Unit17__O(); A_arbace_repr_clojure_rules__init_A_Unit18__O(); return nil }














func A_arbace_repr_clojure_rules__init_A_Unit4__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_4; var tmp2 any = A_arbace_repr_clojure_rules_clojure_source_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_5)); return A_arbace_repr_clojure_rules__init_A_const_4 }



func A_arbace_repr_clojure_rules__init_A_Unit5__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); A_arbace_repr_clojure_rules__init_A_const_6.BindRoot_O__V(A_arbace_repr_clojure_rules__init_A_const_7); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_8)); return A_arbace_repr_clojure_rules__init_A_const_6 }



func A_arbace_repr_clojure_rules__init_A_Unit6__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_9; var tmp2 any = A_arbace_repr_clojure_rules_proxy_methods_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_clojure_rules_proxy_methods_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_clojure_rules_proxy_methods_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_10)); return A_arbace_repr_clojure_rules__init_A_const_9 }






func A_arbace_repr_clojure_rules__init_A_Unit7__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); A_arbace_repr_clojure_rules__init_A_const_11.BindRoot_O__V(Lit_34); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_12)); return A_arbace_repr_clojure_rules__init_A_const_11 }

func A_arbace_repr_clojure_rules__init_A_Unit8__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_13; var tmp2 any = A_arbace_repr_clojure_rules_imports_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_14)); return A_arbace_repr_clojure_rules__init_A_const_13 }

func A_arbace_repr_clojure_rules__init_A_Unit9__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_15; var tmp2 any = A_arbace_repr_clojure_rules_security_manager_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_clojure_rules_security_manager_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_16)); return A_arbace_repr_clojure_rules__init_A_const_15 }





























func A_arbace_repr_clojure_rules__init_A_Unit10__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_17; var tmp2 any = A_arbace_repr_clojure_rules_arbace_core_names_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_18)); return A_arbace_repr_clojure_rules__init_A_const_17 }






func A_arbace_repr_clojure_rules__init_A_Unit11__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); A_arbace_repr_clojure_rules__init_A_const_19.BindRoot_O__V(A_arbace_repr_clojure_rules__init_A_const_20); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_19; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_21)); return A_arbace_repr_clojure_rules__init_A_const_19 }



func A_arbace_repr_clojure_rules__init_A_Unit12__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_22; var tmp2 any = A_arbace_repr_clojure_rules_defined_names_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_clojure_rules_defined_names_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_23)); return A_arbace_repr_clojure_rules__init_A_const_22 }
















func A_arbace_repr_clojure_rules__init_A_Unit13__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_24; var tmp2 any = A_arbace_repr_clojure_rules_insert_at_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_clojure_rules_insert_at_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_clojure_rules_insert_at_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_25)); return A_arbace_repr_clojure_rules__init_A_const_24 }

func A_arbace_repr_clojure_rules__init_A_Unit14__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_26; var tmp2 any = A_arbace_repr_clojure_rules_core_names_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_clojure_rules_core_names_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_clojure_rules_core_names_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_27)); return A_arbace_repr_clojure_rules__init_A_const_26 }



























func A_arbace_repr_clojure_rules__init_A_Unit15__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_28; var tmp2 any = A_arbace_repr_clojure_rules__init_A_const_30; var tmp3 any = A_arbace_repr_clojure_rules__init_A_const_31; var tmp4 any = A_arbace_repr_clojure_rules__init_A_const_32; var tmp5 any = A_arbace_repr_clojure_rules__init_A_const_33; var tmp6 any = A_arbace_repr_clojure_rules_fn__1700000090_A_New(); var tmp7 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000090_A_fn_class; if





	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_repr_clojure_rules_fn__1700000090_A_fn_class = fncls__11d; tmp7 = fncls__11d } else { tmp7 = fncls__11 }; var tmp8 any = /*line :127:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_repr_clojure_rules__init_A_const_34; var tmp10 any = A_arbace_repr_clojure_rules_fn__1700000092_A_New(); var tmp11 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000092_A_fn_class; if






	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_clojure_rules_fn__1700000092_A_fn_class = fncls__12d; tmp11 = fncls__12d } else { tmp11 = fncls__12 }; var tmp12 any = /*line :127:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, Lit_41, tmp5, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))); var tmp13 any = A_arbace_repr_clojure_rules__init_A_const_30; var tmp14 any = A_arbace_repr_clojure_rules__init_A_const_35; var tmp15 any = A_arbace_repr_clojure_rules__init_A_const_32; var tmp16 any = A_arbace_repr_clojure_rules__init_A_const_33; var tmp17 any = lang.IFn_Cast(A_arbace_repr_clojure_rules__init_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_TRUE.Ref()); var tmp18 any = A_arbace_repr_clojure_rules__init_A_const_34; var tmp19 any = A_arbace_repr_clojure_rules_fn__1700000094_A_New(); var tmp20 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000094_A_fn_class; if













	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_clojure_rules_fn__1700000094_A_fn_class = fncls__13d; tmp20 = fncls__13d } else { tmp20 = fncls__13 }; var tmp21 any = /*line :127:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, Lit_44, tmp16, tmp17, tmp18, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil))); var tmp22 any = A_arbace_repr_clojure_rules__init_A_const_30; var tmp23 any = A_arbace_repr_clojure_rules__init_A_const_37; var tmp24 any = A_arbace_repr_clojure_rules__init_A_const_32; var tmp25 any = A_arbace_repr_clojure_rules__init_A_const_33; var tmp26 any = lang.IFn_Cast(A_arbace_repr_clojure_rules__init_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_TRUE.Ref()); var tmp27 any = A_arbace_repr_clojure_rules__init_A_const_34; var tmp28 any = A_arbace_repr_clojure_rules_fn__1700000096_A_New(); var tmp29 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000096_A_fn_class; if



















	fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_clojure_rules_fn__1700000096_A_fn_class = fncls__14d; tmp29 = fncls__14d } else { tmp29 = fncls__14 }; var tmp30 any = /*line :127:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, Lit_46, tmp25, tmp26, tmp27, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil))); var tmp31 any = A_arbace_repr_clojure_rules__init_A_const_30; var tmp32 any = A_arbace_repr_clojure_rules__init_A_const_38; var tmp33 any = A_arbace_repr_clojure_rules__init_A_const_32; var tmp34 any = A_arbace_repr_clojure_rules__init_A_const_33; var tmp35 any = A_arbace_repr_clojure_rules__init_A_const_4.GetRawRoot__O(); var tmp36 any = A_arbace_repr_clojure_rules__init_A_const_34; var tmp37 any = A_arbace_repr_clojure_rules_fn__1700000098_A_New(); var tmp38 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000098_A_fn_class; if

























	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_clojure_rules_fn__1700000098_A_fn_class = fncls__15d; tmp38 = fncls__15d } else { tmp38 = fncls__15 }; var tmp39 any = /*line :127:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32, tmp33, Lit_48, tmp34, tmp35, tmp36, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil))); var tmp40 any = A_arbace_repr_clojure_rules__init_A_const_30; var tmp41 any = A_arbace_repr_clojure_rules__init_A_const_39; var tmp42 any = A_arbace_repr_clojure_rules__init_A_const_32; var tmp43 any = A_arbace_repr_clojure_rules__init_A_const_33; var tmp44 any = A_arbace_repr_clojure_rules__init_A_const_4.GetRawRoot__O(); var tmp45 any = A_arbace_repr_clojure_rules__init_A_const_34; var tmp46 any = A_arbace_repr_clojure_rules_fn__1700000100_A_New(); var tmp47 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_clojure_rules_fn__1700000100_A_fn_class; if






























	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_repr_clojure_rules_fn__1700000100_A_fn_class = fncls__16d; tmp47 = fncls__16d } else { tmp47 = fncls__16 }; /*line :127:1*/tmp1.BindRoot_O__V(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp12, tmp21, tmp30, tmp39, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp41, tmp42, Lit_50, tmp43, tmp44, tmp45, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil))))); var tmp48 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_28; tmp48.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_29)); return A_arbace_repr_clojure_rules__init_A_const_28 }
































func A_arbace_repr_clojure_rules__init_A_Unit16__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); A_arbace_repr_clojure_rules__init_A_const_40.BindRoot_O__V(A_arbace_repr_clojure_rules__init_A_const_41); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_42)); return A_arbace_repr_clojure_rules__init_A_const_40 }





























func A_arbace_repr_clojure_rules__init_A_Unit17__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_43; var tmp2 any = A_arbace_repr_clojure_rules_applicable_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repr_clojure_rules_applicable_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_clojure_rules_applicable_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_44)); return A_arbace_repr_clojure_rules__init_A_const_43 }




func A_arbace_repr_clojure_rules__init_A_Unit18__O() any { A_arbace_repr_clojure_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_45; var tmp2 any = A_arbace_repr_clojure_rules_translate_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_clojure_rules_translate_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_clojure_rules_translate_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rules__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rules__init_A_const_46)); return A_arbace_repr_clojure_rules__init_A_const_45 }



type A_arbace_repr_clojure_rules__init_A struct{ jrt.Object }

var A_arbace_repr_clojure_rules__init_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rules__init_A_const_0 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_1 any

var A_arbace_repr_clojure_rules__init_A_const_2 any

var A_arbace_repr_clojure_rules__init_A_const_3 any

var A_arbace_repr_clojure_rules__init_A_const_4 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_5 any

var A_arbace_repr_clojure_rules__init_A_const_6 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_7 any

var A_arbace_repr_clojure_rules__init_A_const_8 any

var A_arbace_repr_clojure_rules__init_A_const_9 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_10 any

var A_arbace_repr_clojure_rules__init_A_const_11 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_12 any

var A_arbace_repr_clojure_rules__init_A_const_13 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_14 any

var A_arbace_repr_clojure_rules__init_A_const_15 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_16 any

var A_arbace_repr_clojure_rules__init_A_const_17 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_18 any

var A_arbace_repr_clojure_rules__init_A_const_19 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_20 any

var A_arbace_repr_clojure_rules__init_A_const_21 any

var A_arbace_repr_clojure_rules__init_A_const_22 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_23 any

var A_arbace_repr_clojure_rules__init_A_const_24 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_25 any

var A_arbace_repr_clojure_rules__init_A_const_26 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_27 any

var A_arbace_repr_clojure_rules__init_A_const_28 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_29 any

var A_arbace_repr_clojure_rules__init_A_const_30 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_31 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_32 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_33 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_35 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_36 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_37 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_38 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_39 *lang.Keyword

var A_arbace_repr_clojure_rules__init_A_const_40 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_41 any

var A_arbace_repr_clojure_rules__init_A_const_42 any

var A_arbace_repr_clojure_rules__init_A_const_43 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_44 any

var A_arbace_repr_clojure_rules__init_A_const_45 *lang.Var

var A_arbace_repr_clojure_rules__init_A_const_46 any

var A_arbace_repr_clojure_rules__init_A_init jrt.ClassInit

func A_arbace_repr_clojure_rules__init_A_Init() { if !A_arbace_repr_clojure_rules__init_A_init.Done() { A_arbace_repr_clojure_rules__init_A_init.Run(A_arbace_repr_clojure_rules__init_A_clinit) } }

func A_arbace_repr_clojure_rules__init_A_clinit() { A_arbace_repr_clojure_rules__init_A_clinit_p0(); A_arbace_repr_clojure_rules__init_A_clinit_p1(); A_arbace_repr_clojure_rules__init_A_clinit_p2(); A_arbace_repr_clojure_rules__init_A_clinit_p3() }

func A_arbace_repr_clojure_rules__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rules__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_29, 74); A_arbace_repr_clojure_rules__init_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[27]); A_arbace_repr_clojure_rules__init_A_const_1 = A_arbace_repr_clojure_rules__init_A_const_pool.A[28]; A_arbace_repr_clojure_rules__init_A_const_2 = A_arbace_repr_clojure_rules__init_A_const_pool.A[29]; A_arbace_repr_clojure_rules__init_A_const_3 = A_arbace_repr_clojure_rules__init_A_const_pool.A[30]; A_arbace_repr_clojure_rules__init_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[31]); A_arbace_repr_clojure_rules__init_A_const_5 = A_arbace_repr_clojure_rules__init_A_const_pool.A[32]; A_arbace_repr_clojure_rules__init_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[33]); A_arbace_repr_clojure_rules__init_A_const_7 = A_arbace_repr_clojure_rules__init_A_const_pool.A[34]; A_arbace_repr_clojure_rules__init_A_const_8 = A_arbace_repr_clojure_rules__init_A_const_pool.A[35]; A_arbace_repr_clojure_rules__init_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[36]); A_arbace_repr_clojure_rules__init_A_const_10 = A_arbace_repr_clojure_rules__init_A_const_pool.A[37]; A_arbace_repr_clojure_rules__init_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[38]); A_arbace_repr_clojure_rules__init_A_const_12 = A_arbace_repr_clojure_rules__init_A_const_pool.A[39] }

func A_arbace_repr_clojure_rules__init_A_clinit_p1() { A_arbace_repr_clojure_rules__init_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[40]); A_arbace_repr_clojure_rules__init_A_const_14 = A_arbace_repr_clojure_rules__init_A_const_pool.A[41]; A_arbace_repr_clojure_rules__init_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[42]); A_arbace_repr_clojure_rules__init_A_const_16 = A_arbace_repr_clojure_rules__init_A_const_pool.A[43]; A_arbace_repr_clojure_rules__init_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[44]); A_arbace_repr_clojure_rules__init_A_const_18 = A_arbace_repr_clojure_rules__init_A_const_pool.A[45]; A_arbace_repr_clojure_rules__init_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[46]); A_arbace_repr_clojure_rules__init_A_const_20 = A_arbace_repr_clojure_rules__init_A_const_pool.A[47]; A_arbace_repr_clojure_rules__init_A_const_21 = A_arbace_repr_clojure_rules__init_A_const_pool.A[48]; A_arbace_repr_clojure_rules__init_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[49]); A_arbace_repr_clojure_rules__init_A_const_23 = A_arbace_repr_clojure_rules__init_A_const_pool.A[50]; A_arbace_repr_clojure_rules__init_A_const_24 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[51]); A_arbace_repr_clojure_rules__init_A_const_25 = A_arbace_repr_clojure_rules__init_A_const_pool.A[52] }

func A_arbace_repr_clojure_rules__init_A_clinit_p2() { A_arbace_repr_clojure_rules__init_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[53]); A_arbace_repr_clojure_rules__init_A_const_27 = A_arbace_repr_clojure_rules__init_A_const_pool.A[54]; A_arbace_repr_clojure_rules__init_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[55]); A_arbace_repr_clojure_rules__init_A_const_29 = A_arbace_repr_clojure_rules__init_A_const_pool.A[56]; A_arbace_repr_clojure_rules__init_A_const_30 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[57]); A_arbace_repr_clojure_rules__init_A_const_31 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[58]); A_arbace_repr_clojure_rules__init_A_const_32 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[59]); A_arbace_repr_clojure_rules__init_A_const_33 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[60]); A_arbace_repr_clojure_rules__init_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[61]); A_arbace_repr_clojure_rules__init_A_const_35 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[62]); A_arbace_repr_clojure_rules__init_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[63]); A_arbace_repr_clojure_rules__init_A_const_37 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[64]) }

func A_arbace_repr_clojure_rules__init_A_clinit_p3() { A_arbace_repr_clojure_rules__init_A_const_38 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[65]); A_arbace_repr_clojure_rules__init_A_const_39 = lang.Keyword_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[66]); A_arbace_repr_clojure_rules__init_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[67]); A_arbace_repr_clojure_rules__init_A_const_41 = A_arbace_repr_clojure_rules__init_A_const_pool.A[68]; A_arbace_repr_clojure_rules__init_A_const_42 = A_arbace_repr_clojure_rules__init_A_const_pool.A[69]; A_arbace_repr_clojure_rules__init_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[70]); A_arbace_repr_clojure_rules__init_A_const_44 = A_arbace_repr_clojure_rules__init_A_const_pool.A[71]; A_arbace_repr_clojure_rules__init_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_rules__init_A_const_pool.A[72]); A_arbace_repr_clojure_rules__init_A_const_46 = A_arbace_repr_clojure_rules__init_A_const_pool.A[73] }

func A_arbace_repr_clojure_rules__init_A_New() *A_arbace_repr_clojure_rules__init_A { A_arbace_repr_clojure_rules__init_A_Init(); t := &A_arbace_repr_clojure_rules__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules__init_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules__init_A_class }

func (t *A_arbace_repr_clojure_rules__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules__init_A); return ok }

func A_arbace_repr_clojure_rules__init_A_Cast(x any) *A_arbace_repr_clojure_rules__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules__init_A_class)) }; return v }
