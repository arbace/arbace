//line aot_arbace_repr_clojure_rules.ae:1
package aot_arbace_repr_clojure_rules

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_clojure_rename"
	"arbace/aot_arbace_repr_clojure_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_New() *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_rules_A_const_1, A_arbace_repr_clojure_rules_A_const_2, A_arbace_repr_clojure_rules_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_New() *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_repr_clojure_rules_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_repr_clojure_rules_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_rules_A_const_9.GetRawRoot__O(), A_arbace_repr_clojure_rules_A_const_10) }





















func A_arbace_repr_clojure_rules_clojure_source_QMARK__A_New() *A_arbace_repr_clojure_rules_clojure_source_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_clojure_source_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var root_21 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_repr_clojure_rules_A_const_12; var arg_25 any = A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0); if linked_22 == nil { return ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { return linked_22.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_21, arg_24, arg_25) } }







func A_arbace_repr_clojure_rules_proxy_methods_A_New() *A_arbace_repr_clojure_rules_proxy_methods_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var root_26 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var fnbody__39 any = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New(); var tmp1 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class = fncls__38d; tmp1 = fncls__38d } else { tmp1 = fncls__38 }; arg_29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__39, tmp1, nil); var arg_30 any = s__0; var arg_31 any = A_arbace_repr_clojure_rules_A_const_16.GetRawRoot__O(); if linked_27 == nil { return ifn_28.Invoke_O_O_O__O(arg_29, arg_30, arg_31) } else { return linked_27.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_26, arg_29, arg_30, arg_31) } }
//line :34:1
func A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New() *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Ctor() {}
//line :34:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Invoke_O_O_O__O(self, s__1, p__1700000013__2 any) any { var vec__1700000015__3 any = p__1700000013__2; var re__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_32 any = A_arbace_repr_clojure_rules_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = s__1; var arg_36 any = re__4; var arg_37 any = to__5; if linked_33 == nil { return ifn_34.Invoke_O_O_O__O(arg_35, arg_36, arg_37) } else { return linked_33.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_32, arg_35, arg_36, arg_37) } }





func A_arbace_repr_clojure_rules_unproxy_methods_A_New() *A_arbace_repr_clojure_rules_unproxy_methods_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unproxy_methods_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_A) Ctor() {}
//line :40:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var root_40 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var fnbody__53 any = A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_New(); var tmp1 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class = fncls__52d; tmp1 = fncls__52d } else { tmp1 = fncls__52 }; arg_43 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp1, nil); var arg_44 any = s__0; var arg_45 any = A_arbace_repr_clojure_rules_A_const_17.GetRawRoot__O(); if linked_41 == nil { return ifn_42.Invoke_O_O_O__O(arg_43, arg_44, arg_45) } else { return linked_41.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_40, arg_43, arg_44, arg_45) } }
//line :43:1
func A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_New() *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A) Invoke_O_O_O__O(self, s__1, p__1700000020__2 any) any { var vec__1700000022__3 any = p__1700000020__2; var re__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000022__3, lang.RT_IntCast_J__I_NoInit(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000022__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_46 any = A_arbace_repr_clojure_rules_A_const_15.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = s__1; var arg_50 any = re__4; var arg_51 any = to__5; if linked_47 == nil { return ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { return linked_47.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } }





func A_arbace_repr_clojure_rules_imports_QMARK__A_New() *A_arbace_repr_clojure_rules_imports_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_imports_QMARK__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Ctor() {}
//line :49:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Invoke_O_O__O(self, head__0 any) any { var root_54 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = A_arbace_repr_clojure_rules_A_const_18; var arg_58 any = head__0; if linked_55 == nil { return ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { return linked_55.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_54, arg_57, arg_58) } }

func A_arbace_repr_clojure_rules_security_manager_A_New() *A_arbace_repr_clojure_rules_security_manager_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var root_59 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_63 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = s__0; var arg_67 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_64 == nil { arg_62 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { arg_62 = linked_64.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if linked_60 == nil { tmp1 = ifn_61.Invoke_O__O(arg_62) } else { tmp1 = linked_60.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_59, arg_62) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var import_spans__2 any; var root_68 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_70 lang.IFn

		if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = s__0; var arg_72 any = A_arbace_repr_clojure_rules_A_const_23.GetRawRoot__O(); if linked_69 == nil { import_spans__2 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { import_spans__2 = linked_69.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }
//line :55:1
		var in_import_QMARK___3 any; var fnbody__91 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_New_O(import_spans__2); var tmp2 *jrt.Class
		var fncls__90 /*line :55:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class


		if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__91); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class = fncls__90d; tmp2 = fncls__90d } else { tmp2 = fncls__90 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__91, tmp2, nil)
//line :55:1
		var tokens__4 any; var root_92 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_94 lang.IFn



		if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var fnbody__109 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_New_O(s__0); var tmp3 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__109); A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class = fncls__108d; tmp3 = fncls__108d } else { tmp3 = fncls__108 }; arg_95 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__109, tmp3, nil); var arg_96 any; var root_110 any = A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = s__0; if linked_111 == nil { arg_96 = ifn_112.Invoke_O__O(arg_113) } else { arg_96 = linked_111.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A).Invoke_O_O__O(root_110, arg_113) }; if linked_93 == nil { tokens__4 = ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { tokens__4 = linked_93.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) }
//line :55:1
		var imported_QMARK___5 any; var root_114 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_116 lang.IFn




		if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any; var fnbody__131 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_New_O_O(s__0, in_import_QMARK___3); var tmp4 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__131); A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class = fncls__130d; tmp4 = fncls__130d } else { tmp4 = fncls__130 }; arg_117 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__131, tmp4, nil); var arg_118 any = tokens__4; if linked_115 == nil { imported_QMARK___5 = ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { imported_QMARK___5 = linked_115.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) }
//line :55:1
		var uses__6 any; var root_132 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_134 lang.IFn







		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var fnbody__153 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_New_O_O(s__0, in_import_QMARK___3); var tmp5 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__153); A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class = fncls__152d; tmp5 = fncls__152d } else { tmp5 = fncls__152 }; arg_135 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__153, tmp5, nil); var arg_136 any = tokens__4; if linked_133 == nil { uses__6 = ifn_134.Invoke_O_O__O(arg_135, arg_136) } else { uses__6 = linked_133.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_132, arg_135, arg_136)
		}



		var tmp6 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp6 = or__1927000174__auto____7 } else { var root_154 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = uses__6; if linked_155 == nil { tmp6 = ifn_156.Invoke_O__O(arg_157) } else { tmp6 = linked_155.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_154, arg_157) } }; if jrt.J2g_Truth(tmp6) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var root_158 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_160 lang.IFn


			if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var fnbody__165 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_New_O_O(sb__7, s__0); var tmp7 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__165); A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class = fncls__164d; tmp7 = fncls__164d } else { tmp7 = fncls__164 }; arg_161 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__165, tmp7, nil); var arg_162 any = A_arbace_repr_clojure_rules_A_const_30; var arg_163 any = uses__6; if linked_159 == nil { end__8 = ifn_160.Invoke_O_O_O__O(arg_161, arg_162, arg_163) } else { end__8 = linked_159.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_158, arg_161, arg_162, arg_163)
			}



			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(end__8), lang.RT_Count_O__I_NoInit(s__0))
			var root_166 any = A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = sb__7; if linked_167 == nil { return ifn_168.Invoke_O__O(arg_169) } else { return linked_167.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_166, arg_169) } } } }
//line :58:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A) Invoke_O_O__O(self, i__1 any) any { var root_73 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var fnbody__89 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_New_O(i__1); var tmp1 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__89); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class = fncls__88d; tmp1 = fncls__88d } else { tmp1 = fncls__88 }; arg_76 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__89, tmp1, nil); var arg_77 any = t.F_import_spans; if linked_74 == nil { return ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { return linked_74.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) } }
//line :58:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A) Invoke_O_O__O(self, p__1700000029__1 any) any { var vec__1700000031__2 any = p__1700000029__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 bool; var na_78 any = a__3; var na_79 any = t.F_i; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_78); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_79) }; tmp1 = tmp2; if tmp1 { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); and__1927000168__auto____5 = n0_80 <= n1_81 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_78); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_79) }; tmp3 = tmp4; if tmp3 { var n0_80_2 float64 = jrt.NN(jrt.Double_Cast(na_78)).DoubleValue__D(); var n1_81_2 float64 = jrt.NN(jrt.Double_Cast(na_79)).DoubleValue__D(); and__1927000168__auto____5 = n0_80_2 <= n1_81_2 } else { and__1927000168__auto____5 = lang.Numbers_Lte_O_O__Z_NoInit(na_78, na_79) } }; if and__1927000168__auto____5 { var tmp5 bool; var na_83 any = t.F_i; var na_84 any = b__4; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_83); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_84) }; tmp6 = tmp7; if tmp6 { var n0_85 int64 = jrt.NN(jrt.Long_Cast(na_83)).LongValue__J(); var n1_86 int64 = jrt.NN(jrt.Long_Cast(na_84)).LongValue__J(); tmp5 = n0_85 < n1_86 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_83); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_84) }; tmp8 = tmp9; if tmp8 { var n0_85_2 float64 = jrt.NN(jrt.Double_Cast(na_83)).DoubleValue__D(); var n1_86_2 float64 = jrt.NN(jrt.Double_Cast(na_84)).DoubleValue__D(); tmp5 = n0_85_2 < n1_86_2 } else { tmp5 = lang.Numbers_Lt_O_O__Z_NoInit(na_83, na_84) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A{}; t.Ctor_O(p0); return t }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A) Invoke_O_O__O(self, p__1700000036__1 any) any { var vec__1700000038__2 any = p__1700000036__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_97 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var root_102 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = t.F_s; var arg_106 any = a__3; var arg_107 any = b__4; if linked_103 == nil { arg_100 = ifn_104.Invoke_O_O_O__O(arg_105, arg_106, arg_107) } else { arg_100 = linked_103.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_102, arg_105, arg_106, arg_107) }; var arg_101 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_98 == nil { return ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { return linked_98.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_97, arg_100, arg_101) } }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :60:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :60:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A) Invoke_O_O__O(self, p__1700000042__1 any) any { var vec__1700000044__2 any = p__1700000042__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000044__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000044__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.J2g_Truth(and__1927000168__auto____5) {
															var root_119 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())).Ref())); var arg_123 any; var root_124 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = t.F_s; var arg_128 any = a__3; var arg_129 any = b__4; if linked_125 == nil { arg_123 = ifn_126.Invoke_O_O_O__O(arg_127, arg_128, arg_129) } else { arg_123 = linked_125.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_124, arg_127, arg_128, arg_129) }; if linked_120 == nil { return ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { return linked_120.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_119, arg_122, arg_123) } } else {
//line :60:1
		return and__1927000168__auto____5 } }


func A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :63:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A) Invoke_O_O__O(self, p__1700000048__1 any) any { var vec__1700000050__2 any = p__1700000048__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t__5 any; var root_137 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_139 lang.IFn; if
															linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = t.F_s; var arg_141 any = a__3; var arg_142 any = b__4; if linked_138 == nil { t__5 = ifn_139.Invoke_O_O_O__O(arg_140, arg_141, arg_142) } else { t__5 = linked_138.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_137, arg_140, arg_141, arg_142) }; var and__1927000168__auto____6 any; var root_143 any = /*line :63:1*/A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_145 lang.IFn; if

	linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if linked_144 == nil { and__1927000168__auto____6 = ifn_145.Invoke_O__O(arg_146) } else { and__1927000168__auto____6 = linked_144.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_143, arg_146) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_147 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = t__5; var arg_151 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), nil)).Ref(); if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } } } } else {
//line :65:1
			return and__1927000168__auto____6 } }





func A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :71:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :71:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A) Invoke_O_O_O__O(self, i__1, p__1700000054__2 any) any { var vec__1700000056__3 any = p__1700000054__2; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000056__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000056__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
																jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(i__1), lang.RT_IntCast_O__I_NoInit(a__4)); var tmp3 /*line :73:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp3).Append_String__StringBuilder(Lit_36); return a__4 }









func A_arbace_repr_clojure_rules_unqualify_security_manager_A_New() *A_arbace_repr_clojure_rules_unqualify_security_manager_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_A) Invoke_O_O__O(self, s__0 any) any {





	var tmp1 any; var root_170 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any; var root_174 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = s__0; var arg_178 any = A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(); if linked_175 == nil { arg_173 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { arg_173 = linked_175.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; if linked_171 == nil { tmp1 = ifn_172.Invoke_O__O(arg_173) } else { tmp1 = linked_171.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_170, arg_173) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var import_spans__2 any; var root_179 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_181 lang.IFn

		if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = s__0; var arg_183 any = A_arbace_repr_clojure_rules_A_const_23.GetRawRoot__O(); if linked_180 == nil { import_spans__2 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { import_spans__2 = linked_180.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }
//line :89:1
		var in_import_QMARK___3 any; var fnbody__202 any = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_New_O(import_spans__2); var tmp2 *jrt.Class
		var fncls__201 /*line :89:1*/*jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class


		if fncls__201 == nil { var fncls__201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__202); A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class = fncls__201d; tmp2 = fncls__201d } else { tmp2 = fncls__201 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__202, tmp2, nil)
//line :89:1
		var tokens__4 any; var root_203 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_205 lang.IFn



		if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var fnbody__220 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_New_O(s__0); var tmp3 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__220); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class = fncls__219d; tmp3 = fncls__219d } else { tmp3 = fncls__219 }; arg_206 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__220, tmp3, nil); var arg_207 any; var root_221 any = A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__0; if linked_222 == nil { arg_207 = ifn_223.Invoke_O__O(arg_224) } else { arg_207 = linked_222.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A).Invoke_O_O__O(root_221, arg_224) }; if linked_204 == nil { tokens__4 = ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { tokens__4 = linked_204.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) }
//line :89:1
		var imported_QMARK___5 any; var root_225 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_227 lang.IFn




		if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any; var fnbody__242 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_New_O_O(s__0, in_import_QMARK___3); var tmp4 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__242); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class = fncls__241d; tmp4 = fncls__241d } else { tmp4 = fncls__241 }; arg_228 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__242, tmp4, nil); var arg_229 any = tokens__4; if linked_226 == nil { imported_QMARK___5 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { imported_QMARK___5 = linked_226.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) }
//line :89:1
		var uses__6 any; var root_243 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_245 lang.IFn







		if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var fnbody__264 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_New_O_O(s__0, in_import_QMARK___3); var tmp5 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__264); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class = fncls__263d; tmp5 = fncls__263d } else { tmp5 = fncls__263 }; arg_246 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__264, tmp5, nil); var arg_247 any = tokens__4; if linked_244 == nil { uses__6 = ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { uses__6 = linked_244.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_243, arg_246, arg_247)
		}




		var tmp6 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp6 = or__1927000174__auto____7 } else { var root_265 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = uses__6; if linked_266 == nil { tmp6 = ifn_267.Invoke_O__O(arg_268) } else { tmp6 = linked_266.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_265, arg_268) } }; if jrt.J2g_Truth(tmp6) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var root_269 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_271 lang.IFn


			if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var fnbody__281 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_New_O_O(sb__7, s__0); var tmp7 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class; if fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__281); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class = fncls__280d; tmp7 = fncls__280d } else { tmp7 = fncls__280 }; arg_272 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__281, tmp7, nil); var arg_273 any = A_arbace_repr_clojure_rules_A_const_30; var arg_274 any = uses__6; if linked_270 == nil { end__8 = ifn_271.Invoke_O_O_O__O(arg_272, arg_273, arg_274) } else { end__8 = linked_270.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_269, arg_272, arg_273, arg_274)
			}


			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(end__8), lang.RT_Count_O__I_NoInit(s__0))
			var root_282 any = A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = sb__7; if linked_283 == nil { return ifn_284.Invoke_O__O(arg_285) } else { return linked_283.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_282, arg_285) } } } }
//line :92:1
func A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A) Invoke_O_O__O(self, i__1 any) any { var root_184 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var fnbody__200 any = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_New_O(i__1); var tmp1 *jrt.Class; var fncls__199 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class; if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__200); A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class = fncls__199d; tmp1 = fncls__199d } else { tmp1 = fncls__199 }; arg_187 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__200, tmp1, nil); var arg_188 any = t.F_import_spans; if linked_185 == nil { return ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { return linked_185.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) } }
//line :92:1
func A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A) Invoke_O_O__O(self, p__1700000062__1 any) any { var vec__1700000064__2 any = p__1700000062__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000064__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000064__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 bool; var na_189 any = a__3; var na_190 any = t.F_i; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_189); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_190) }; tmp1 = tmp2; if tmp1 { var n0_191 int64 = jrt.NN(jrt.Long_Cast(na_189)).LongValue__J(); var n1_192 int64 = jrt.NN(jrt.Long_Cast(na_190)).LongValue__J(); and__1927000168__auto____5 = n0_191 <= n1_192 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_189); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_190) }; tmp3 = tmp4; if tmp3 { var n0_191_2 float64 = jrt.NN(jrt.Double_Cast(na_189)).DoubleValue__D(); var n1_192_2 float64 = jrt.NN(jrt.Double_Cast(na_190)).DoubleValue__D(); and__1927000168__auto____5 = n0_191_2 <= n1_192_2 } else { and__1927000168__auto____5 = lang.Numbers_Lte_O_O__Z_NoInit(na_189, na_190) } }; if and__1927000168__auto____5 { var tmp5 bool; var na_194 any = t.F_i; var na_195 any = b__4; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_194); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_195) }; tmp6 = tmp7; if tmp6 { var n0_196 int64 = jrt.NN(jrt.Long_Cast(na_194)).LongValue__J(); var n1_197 int64 = jrt.NN(jrt.Long_Cast(na_195)).LongValue__J(); tmp5 = n0_196 < n1_197 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_194); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_195) }; tmp8 = tmp9; if tmp8 { var n0_196_2 float64 = jrt.NN(jrt.Double_Cast(na_194)).DoubleValue__D(); var n1_197_2 float64 = jrt.NN(jrt.Double_Cast(na_195)).DoubleValue__D(); tmp5 = n0_196_2 < n1_197_2 } else { tmp5 = lang.Numbers_Lt_O_O__Z_NoInit(na_194, na_195) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :93:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A) Invoke_O_O__O(self, p__1700000069__1 any) any { var vec__1700000071__2 any = p__1700000069__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000071__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000071__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_208 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var root_213 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = t.F_s; var arg_217 any = a__3; var arg_218 any = b__4; if linked_214 == nil { arg_211 = ifn_215.Invoke_O_O_O__O(arg_216, arg_217, arg_218) } else { arg_211 = linked_214.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_213, arg_216, arg_217, arg_218) }; var arg_212 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_209 == nil { return ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { return linked_209.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_208, arg_211, arg_212) } }
func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :94:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A) Invoke_O_O__O(self, p__1700000075__1 any) any { var vec__1700000077__2 any = p__1700000075__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000077__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000077__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.J2g_Truth(and__1927000168__auto____5) {
																var root_230 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())); var arg_234 any; var root_235 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = t.F_s; var arg_239 any = a__3; var arg_240 any = b__4; if linked_236 == nil { arg_234 = ifn_237.Invoke_O_O_O__O(arg_238, arg_239, arg_240) } else { arg_234 = linked_236.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_235, arg_238, arg_239, arg_240) }; if linked_231 == nil { return ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { return linked_231.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_230, arg_233, arg_234) } } else {
//line :94:1
		return and__1927000168__auto____5 } }


func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A{}; t.Ctor_O_O(p0, p1); return t }
//line :97:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :97:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A) Invoke_O_O__O(self, p__1700000081__1 any) any { var vec__1700000083__2 any = p__1700000081__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t__5 any; var root_248 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_250 lang.IFn; if
																linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = t.F_s; var arg_252 any = a__3; var arg_253 any = b__4; if linked_249 == nil { t__5 = ifn_250.Invoke_O_O_O__O(arg_251, arg_252, arg_253) } else { t__5 = linked_249.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_248, arg_251, arg_252, arg_253) }; var and__1927000168__auto____6 any; var root_254 any = /*line :97:1*/A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_256 lang.IFn; if

	linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if linked_255 == nil { and__1927000168__auto____6 = ifn_256.Invoke_O__O(arg_257) } else { and__1927000168__auto____6 = linked_255.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else {
			var root_258 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = t__5; var arg_262 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), nil)).Ref(); if linked_259 == nil { return ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { return linked_259.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_258, arg_261, arg_262) } } } } else {
//line :99:1
				return and__1927000168__auto____6 } }






func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :106:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :106:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A) Invoke_O_O_O__O(self, i__1, p__1700000087__2 any) any { var vec__1700000089__3 any = p__1700000087__2; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000089__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000089__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
																	jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(i__1), lang.RT_IntCast_O__I_NoInit(a__4)); var na_275 any = a__4; var na_276 int64 =
																	int64(lang.RT_Count_O__I_NoInit(Lit_36)); if jrt.Long_InstanceOf(na_275) { var n0_277 int64 = jrt.NN(jrt.Long_Cast(na_275)).LongValue__J(); var n1_278 int64 = na_276; var nr_279 int64 = n0_277 + n1_278; if (n0_277^nr_279)&(n1_278^nr_279) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_279).Ref() } else { return lang.Numbers_Add_O_J__Number_NoInit(na_275, na_276) } } else { return lang.Numbers_Add_O_J__Number_NoInit(na_275, na_276) } }






func A_arbace_repr_clojure_rules_arbace_core_names_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Invoke_O__O(self any) any {



	var root_286 any = A_arbace_repr_clojure_rules_A_const_33.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_290 any; var root_292 any = A_arbace_repr_clojure_rules_A_const_34.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any; var root_297 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any; var fnbody__302 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_New(); var tmp1 *jrt.Class; var fncls__301 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class; if fncls__301 == nil { var fncls__301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class = fncls__301d; tmp1 = fncls__301d } else { tmp1 = fncls__301 }; arg_300 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__302, tmp1, nil); if linked_298 == nil { arg_295 = ifn_299.Invoke_O__O(arg_300) } else { arg_295 = linked_298.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_297, arg_300) }; var arg_296 any; var root_303 any = A_arbace_repr_clojure_rules_A_const_36.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var fnbody__312 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_New(); var tmp2 *jrt.Class; var fncls__311 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class; if fncls__311 == nil { var fncls__311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class = fncls__311d; tmp2 = fncls__311d } else { tmp2 = fncls__311 }; arg_306 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__312, tmp2, nil); if linked_304 == nil { arg_296 = ifn_305.Invoke_O__O(arg_306) } else { arg_296 = linked_304.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_303, arg_306) }; if linked_293 == nil { arg_290 = ifn_294.Invoke_O_O__O(arg_295, arg_296) } else { arg_290 = linked_293.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_292, arg_295, arg_296) }; var arg_291 any; var root_313 any = A_arbace_repr_clojure_rules_A_const_38.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_315 lang.IFn
	if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any; var root_317 any = A_arbace_repr_clojure_rules_A_const_39.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = A_arbace_repr_clojure_rules_A_const_40; if linked_318 == nil { arg_316 = ifn_319.Invoke_O__O(arg_320) } else { arg_316 = linked_318.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_317, arg_320) }; if linked_314 == nil { arg_291 = ifn_315.Invoke_O__O(arg_316) } else { arg_291 = linked_314.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_313, arg_316) }
//line :119:1
	if linked_287 == nil { return ifn_288.Invoke_O_O_O__O(arg_289, arg_290, arg_291) } else { return linked_287.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_286, arg_289, arg_290, arg_291) } }
//line :119:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A) Invoke_O_O__O(self, p1__1700000094_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_clojure_rules_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1700000094_SHARP___1)))).Ref() }
//line :119:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A) Invoke_O_O__O(self, p1__1700000095_SHARP___1 any) any { var root_307 any = A_arbace_repr_clojure_rules_A_const_37.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = lang.Var_Cast(p1__1700000095_SHARP___1).F_sym.Ref(); if linked_308 == nil { return ifn_309.Invoke_O__O(arg_310) } else { return linked_308.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_307, arg_310) } }






func A_arbace_repr_clojure_rules_defined_names_A_New() *A_arbace_repr_clojure_rules_defined_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Invoke_O_O__O(self, s__0 any) any { var iter__1927001039__auto____2 any; var fnbody__538 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_New_O(s__0); var tmp1 *jrt.Class; var fncls__537 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class; if


	fncls__537 == nil { var fncls__537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__538); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class = fncls__537d; tmp1 = fncls__537d } else { tmp1 = fncls__537 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__538, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_539 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = s__0; var arg_543 any = A_arbace_repr_clojure_rules_A_const_57.GetRawRoot__O(); if linked_540 == nil { tmp3 = ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { tmp3 = linked_540.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) }; return tmp2.Invoke_O__O(tmp3) }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_New_O(p0 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A) Invoke_O_O__O(self, s__1700000102__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__536 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_New_O_O_O(self, t.F_s, s__1700000102__1); var tmp2 *jrt.Class; var fncls__535 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class; if fncls__535 == nil { var fncls__535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__536); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class = fncls__535d; tmp2 = fncls__535d } else { tmp2 = fncls__535 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__536, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A) Ctor_O_O_O(c__iter__1700000101, c__s, c__s__1700000102 any) { t.F_iter__1700000101 = c__iter__1700000101; t.F_s = c__s; t.F_s__1700000102 = c__s__1700000102 }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A) Invoke_O__O(self any) any { { var s__1700000102__1 any; var t_ any = t.F_s__1700000102; t.F_s__1700000102 = nil; s__1700000102__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_321 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = s__1700000102__1; if linked_322 == nil { temp__1927000414__auto____2 = ifn_323.Invoke_O__O(arg_324) } else { temp__1927000414__auto____2 = linked_322.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1700000102__3 any = temp__1927000414__auto____2; var tmp1 any; var root_325 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = s__1700000102__3; if linked_326 == nil { tmp1 = ifn_327.Invoke_O__O(arg_328) } else { tmp1 = linked_326.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_325, arg_328) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_329 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = s__1700000102__3; if linked_330 == nil { c__1927001037__auto____4 = ifn_331.Invoke_O__O(arg_332) } else { c__1927001037__auto____4 = linked_330.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_329, arg_332) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1700000104__6 any; var root_333 any = A_arbace_repr_clojure_rules_A_const_44.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_334 == nil { b__1700000104__6 = ifn_335.Invoke_O__O(arg_336) } else { b__1700000104__6 = linked_334.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_333, arg_336) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__419 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_New_O_O_I_O(b__1700000104__6, t.F_s, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__418 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class; if fncls__418 == nil { var fncls__418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__419); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class = fncls__418d; tmp3 = fncls__418d } else { tmp3 = fncls__418 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__419, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_420 any = A_arbace_repr_clojure_rules_A_const_51.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any; var root_425 any = A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = b__1700000104__6; if linked_426 == nil { arg_423 = ifn_427.Invoke_O__O(arg_428) } else { arg_423 = linked_426.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_425, arg_428) }; var arg_424 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1700000101); var tmp5 any; var root_429 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = s__1700000102__3; if linked_430 == nil { tmp5 = ifn_431.Invoke_O__O(arg_432) } else { tmp5 = linked_430.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_429, arg_432) }; arg_424 = tmp4.Invoke_O__O(tmp5); if linked_421 == nil { return ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { return linked_421.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) } } else { var root_433 any = A_arbace_repr_clojure_rules_A_const_51.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any; var root_438 any = A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = b__1700000104__6; if linked_439 == nil { arg_436 = ifn_440.Invoke_O__O(arg_441) } else { arg_436 = linked_439.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_438, arg_441) }; var arg_437 any; if linked_434 == nil { return ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { return linked_434.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) } } } else { var vec__1700000114__4 any; var root_442 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = s__1700000102__3; if linked_443 == nil { vec__1700000114__4 = ifn_444.Invoke_O__O(arg_445) } else { vec__1700000114__4 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000114__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000114__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any; var root_446 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_448 lang.IFn; _ = ___6
																if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = t.F_s; var arg_450 any; var na_451 any = a__5; if jrt.Long_InstanceOf(na_451) { var n0_452 int64 = jrt.NN(jrt.Long_Cast(na_451)).LongValue__J(); if n0_452 == 9223372036854775807 { arg_450 = lang.Numbers_Inc_O__Number_NoInit(na_451) } else { arg_450 = jrt.Long_ValueOf_J__Long_NoInit(n0_452 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_451) { var n0_452_2 float64 = jrt.NN(jrt.Double_Cast(na_451)).DoubleValue__D(); arg_450 = jrt.Double_ValueOf_D__Double_NoInit(n0_452_2 + 1.0).Ref() } else { arg_450 = lang.Numbers_Inc_O__Number_NoInit(na_451) } }; if linked_447 == nil { h__7 = ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { h__7 = linked_447.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_446, arg_449, arg_450) }
//line :129:1
	var j__8 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__506 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_New_O_O(h__7, t.F_s); var tmp7 *jrt.Class
	var fncls__505 /*line :129:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class

	if fncls__505 == nil { var fncls__505d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__506); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class = fncls__505d; tmp7 = fncls__505d } else { tmp7 = fncls__505 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__506, tmp7, nil); j__8 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :129:1
	var t__9 any; var root_507 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_509 lang.IFn









	if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = t.F_s; var arg_511 any = j__8; var arg_512 any; var root_513 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = t.F_s; var arg_517 any = j__8; if linked_514 == nil { arg_512 = ifn_515.Invoke_O_O__O(arg_516, arg_517) } else { arg_512 = linked_514.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_513, arg_516, arg_517) }; if linked_508 == nil { t__9 = ifn_509.Invoke_O_O_O__O(arg_510, arg_511, arg_512) } else { t__9 = linked_508.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_507, arg_510, arg_511, arg_512) }
//line :129:1
	var tmp8 any; var root_518 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_520 lang.IFn










	if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = t__9; if linked_519 == nil { tmp8 = ifn_520.Invoke_O__O(arg_521) } else { tmp8 = linked_519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_518, arg_521) }
//line :129:1
	if jrt.J2g_Truth(tmp8) { var root_522 any = A_arbace_repr_clojure_rules_A_const_55.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = t__9; var arg_526 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1700000101); var tmp10 any; var root_527 any = A_arbace_repr_clojure_rules_A_const_56.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = s__1700000102__3; if linked_528 == nil { tmp10 = ifn_529.Invoke_O__O(arg_530) } else { tmp10 = linked_528.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_527, arg_530) }; arg_526 = tmp9.Invoke_O__O(tmp10); if linked_523 == nil { return ifn_524.Invoke_O_O__O(arg_525, arg_526) } else { return linked_523.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_522, arg_525, arg_526) } } else { var tmp11 any; var root_531 any = A_arbace_repr_clojure_rules_A_const_56.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = s__1700000102__3; if linked_532 == nil { tmp11 = ifn_533.Invoke_O__O(arg_534) } else { tmp11 = linked_532.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_531, arg_534) }; s__1700000102__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A) Ctor_O_O_I_O(c__b__1700000104, c__s any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1700000104 = c__b__1700000104; t.F_s = c__s; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A) Invoke_O__O(self any) any { { var i__1700000103__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1700000103__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1700000108__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1700000103__1)); var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000108__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000108__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any; var root_337 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_339 lang.IFn; _ = ___4
																		if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = t.F_s; var arg_341 any; var na_342 any = a__3; if jrt.Long_InstanceOf(na_342) { var n0_343 int64 = jrt.NN(jrt.Long_Cast(na_342)).LongValue__J(); if n0_343 == 9223372036854775807 { arg_341 = lang.Numbers_Inc_O__Number_NoInit(na_342) } else { arg_341 = jrt.Long_ValueOf_J__Long_NoInit(n0_343 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_342) { var n0_343_2 float64 = jrt.NN(jrt.Double_Cast(na_342)).DoubleValue__D(); arg_341 = jrt.Double_ValueOf_D__Double_NoInit(n0_343_2 + 1.0).Ref() } else { arg_341 = lang.Numbers_Inc_O__Number_NoInit(na_342) } }; if linked_338 == nil { h__5 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { h__5 = linked_338.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }
//line :129:1
	var j__6 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__397 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_New_O_O(h__5, t.F_s); var tmp3 *jrt.Class
	var fncls__396 /*line :129:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class

	if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__397); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class = fncls__396d; tmp3 = fncls__396d } else { tmp3 = fncls__396 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__397, tmp3, nil); j__6 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :129:1
	var t__7 any; var root_398 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_400 lang.IFn









	if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = t.F_s; var arg_402 any = j__6; var arg_403 any; var root_404 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = t.F_s; var arg_408 any = j__6; if linked_405 == nil { arg_403 = ifn_406.Invoke_O_O__O(arg_407, arg_408) } else { arg_403 = linked_405.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_404, arg_407, arg_408) }; if linked_399 == nil { t__7 = ifn_400.Invoke_O_O_O__O(arg_401, arg_402, arg_403) } else { t__7 = linked_399.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_398, arg_401, arg_402, arg_403) }
//line :129:1
	var tmp4 any; var root_409 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_411 lang.IFn










	if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = t__7; if linked_410 == nil { tmp4 = ifn_411.Invoke_O__O(arg_412) } else { tmp4 = linked_410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_409, arg_412) }
//line :129:1
	if jrt.J2g_Truth(tmp4) { var root_413 any = A_arbace_repr_clojure_rules_A_const_50.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = t.F_b__1700000104; var arg_417 any = t__7; if linked_414 == nil { ifn_415.Invoke_O_O__O(arg_416, arg_417) } else { linked_414.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_413, arg_416, arg_417) }; i__1700000103__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000103__1); continue L1 } else { i__1700000103__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000103__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A) Invoke_O__O(self any) any { { var j__1 any; var root_344 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = t.F_s; var arg_348 any; var root_349 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = t.F_s; var arg_353 any; var t_ any = t.F_h; t.F_h = nil; arg_353 = t_; if linked_350 == nil { arg_348 = ifn_351.Invoke_O_O__O(arg_352, arg_353) } else { arg_348 = linked_350.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_349, arg_352, arg_353) }; if linked_345 == nil { j__1 = ifn_346.Invoke_O_O__O(arg_347, arg_348) } else { j__1 = linked_345.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_344, arg_347, arg_348) }; L1: for {

	var tmp1 bool; var na_354 any = j__1; var na_355 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_354) { var n0_356 int64 = jrt.NN(jrt.Long_Cast(na_354)).LongValue__J(); var n1_357 int64 = na_355; tmp1 = n0_356 >= n1_357 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_354, na_355) }; if tmp1 { return j__1 } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_47)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp3 any; var root_359 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = t.F_s; var arg_363 any; var root_364 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_364, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = t.F_s; var arg_368 any; var root_369 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = t.F_s; var arg_373 any; var na_374 any = j__1; if jrt.Long_InstanceOf(na_374) { var n0_375 int64 = jrt.NN(jrt.Long_Cast(na_374)).LongValue__J(); if n0_375 == 9223372036854775807 { arg_373 = lang.Numbers_Inc_O__Number_NoInit(na_374) } else { arg_373 = jrt.Long_ValueOf_J__Long_NoInit(n0_375 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_374) { var n0_375_2 float64 = jrt.NN(jrt.Double_Cast(na_374)).DoubleValue__D(); arg_373 = jrt.Double_ValueOf_D__Double_NoInit(n0_375_2 + 1.0).Ref() } else { arg_373 = lang.Numbers_Inc_O__Number_NoInit(na_374) } }; if linked_370 == nil { arg_368 = ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { arg_368 = linked_370.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_369, arg_372, arg_373) }; if linked_365 == nil { arg_363 = ifn_366.Invoke_O_O__O(arg_367, arg_368) } else { if jrt.Long_InstanceOf(arg_368) { arg_363 = linked_365.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_364, arg_367, jrt.NN(jrt.Long_Cast(arg_368)).LongValue__J(), arg_368) } else { arg_363 = linked_365.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_364, arg_367, arg_368) } }; if linked_360 == nil { tmp3 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp3 = linked_360.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; j__1 = tmp3; continue L1 } else {
//line :133:1
			var tmp4 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp4).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp5 any; var root_376 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = t.F_s; var arg_380 any; var root_381 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_381, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = t.F_s; var arg_385 any; var root_386 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = t.F_s; var arg_390 any; var na_391 any = j__1; var na_392 int64 = 2; if jrt.Long_InstanceOf(na_391) { var n0_393 int64 = jrt.NN(jrt.Long_Cast(na_391)).LongValue__J(); var n1_394 int64 = na_392; var nr_395 int64 = n0_393 + n1_394; if (n0_393^nr_395)&(n1_394^nr_395) >= 0 { arg_390 = jrt.Long_ValueOf_J__Long_NoInit(nr_395).Ref() } else { arg_390 = lang.Numbers_Add_O_J__Number_NoInit(na_391, na_392) } } else { arg_390 = lang.Numbers_Add_O_J__Number_NoInit(na_391, na_392) }; if linked_387 == nil { arg_385 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { arg_385 = linked_387.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }; if linked_382 == nil { arg_380 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { if jrt.Long_InstanceOf(arg_385) { arg_380 = linked_382.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_381, arg_384, jrt.NN(jrt.Long_Cast(arg_385)).LongValue__J(), arg_385) } else { arg_380 = linked_382.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) } }; if linked_377 == nil { tmp5 = ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { tmp5 = linked_377.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) }; j__1 = tmp5; continue L1 } else {
//line :133:1
					if A_arbace_repr_clojure_rules_A_const_48 != nil { return j__1 } else { return nil } } } } } }; /*line :131:1*/panic("j2g: unreachable") }
//line :131:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A) Invoke_O__O(self any) any { { var j__1 any; var root_453 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = t.F_s; var arg_457 any; var root_458 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = t.F_s; var arg_462 any; var t_ any = t.F_h; t.F_h = nil; arg_462 = t_; if linked_459 == nil { arg_457 = ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { arg_457 = linked_459.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }; if linked_454 == nil { j__1 = ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { j__1 = linked_454.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) }; L1: for {

	var tmp1 bool; var na_463 any = j__1; var na_464 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_463) { var n0_465 int64 = jrt.NN(jrt.Long_Cast(na_463)).LongValue__J(); var n1_466 int64 = na_464; tmp1 = n0_465 >= n1_466 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_463, na_464) }; if tmp1 { return j__1 } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_47)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp3 any; var root_468 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = t.F_s; var arg_472 any; var root_473 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_473, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = t.F_s; var arg_477 any; var root_478 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = t.F_s; var arg_482 any; var na_483 any = j__1; if jrt.Long_InstanceOf(na_483) { var n0_484 int64 = jrt.NN(jrt.Long_Cast(na_483)).LongValue__J(); if n0_484 == 9223372036854775807 { arg_482 = lang.Numbers_Inc_O__Number_NoInit(na_483) } else { arg_482 = jrt.Long_ValueOf_J__Long_NoInit(n0_484 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_483) { var n0_484_2 float64 = jrt.NN(jrt.Double_Cast(na_483)).DoubleValue__D(); arg_482 = jrt.Double_ValueOf_D__Double_NoInit(n0_484_2 + 1.0).Ref() } else { arg_482 = lang.Numbers_Inc_O__Number_NoInit(na_483) } }; if linked_479 == nil { arg_477 = ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { arg_477 = linked_479.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_478, arg_481, arg_482) }; if linked_474 == nil { arg_472 = ifn_475.Invoke_O_O__O(arg_476, arg_477) } else { if jrt.Long_InstanceOf(arg_477) { arg_472 = linked_474.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_473, arg_476, jrt.NN(jrt.Long_Cast(arg_477)).LongValue__J(), arg_477) } else { arg_472 = linked_474.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_473, arg_476, arg_477) } }; if linked_469 == nil { tmp3 = ifn_470.Invoke_O_O__O(arg_471, arg_472) } else { tmp3 = linked_469.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_468, arg_471, arg_472) }; j__1 = tmp3; continue L1 } else {
//line :133:1
			var tmp4 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp4).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp5 any; var root_485 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = t.F_s; var arg_489 any; var root_490 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_490, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = t.F_s; var arg_494 any; var root_495 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = t.F_s; var arg_499 any; var na_500 any = j__1; var na_501 int64 = 2; if jrt.Long_InstanceOf(na_500) { var n0_502 int64 = jrt.NN(jrt.Long_Cast(na_500)).LongValue__J(); var n1_503 int64 = na_501; var nr_504 int64 = n0_502 + n1_503; if (n0_502^nr_504)&(n1_503^nr_504) >= 0 { arg_499 = jrt.Long_ValueOf_J__Long_NoInit(nr_504).Ref() } else { arg_499 = lang.Numbers_Add_O_J__Number_NoInit(na_500, na_501) } } else { arg_499 = lang.Numbers_Add_O_J__Number_NoInit(na_500, na_501) }; if linked_496 == nil { arg_494 = ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { arg_494 = linked_496.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) }; if linked_491 == nil { arg_489 = ifn_492.Invoke_O_O__O(arg_493, arg_494) } else { if jrt.Long_InstanceOf(arg_494) { arg_489 = linked_491.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_490, arg_493, jrt.NN(jrt.Long_Cast(arg_494)).LongValue__J(), arg_494) } else { arg_489 = linked_491.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_490, arg_493, arg_494) } }; if linked_486 == nil { tmp5 = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { tmp5 = linked_486.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }; j__1 = tmp5; continue L1 } else {
//line :133:1
					if A_arbace_repr_clojure_rules_A_const_48 != nil { return j__1 } else { return nil } } } } } }; /*line :131:1*/panic("j2g: unreachable") }











func A_arbace_repr_clojure_rules_insert_at_A_New() *A_arbace_repr_clojure_rules_insert_at_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_insert_at_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Ctor() {}
//line :143:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Invoke_O_O_O_O__O(self, s__0, i__1, x__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 any; var root_544 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = s__0; var arg_548 any = A_arbace_repr_clojure_rules_A_const_30; var arg_549 any = i__1; if linked_545 == nil { tmp2 = ifn_546.Invoke_O_O_O__O(arg_547, arg_548, arg_549) } else { tmp2 = linked_545.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_544, arg_547, arg_548, arg_549) }; var tmp3 any = tmp2; var tmp4 any; var root_550 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = s__0; var arg_554 any = i__1; if linked_551 == nil { tmp4 = ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { tmp4 = linked_551.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, x__2, tmp4)).Ref() }

func A_arbace_repr_clojure_rules_core_names_A_New() *A_arbace_repr_clojure_rules_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_core_names_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Ctor() {}
//line :145:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any; var root_555 any = A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_557 lang.IFn; if






	linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any; var root_559 any = A_arbace_repr_clojure_rules_A_const_59.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any; var root_563 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = added__1; var arg_567 any; var root_568 any = A_arbace_repr_clojure_rules_A_const_60.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_repr_clojure_rules_defined_names_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = s__0; if linked_569 == nil { arg_567 = ifn_570.Invoke_O__O(arg_571) } else { arg_567 = linked_569.(*A_arbace_repr_clojure_rules_defined_names_A).Invoke_O_O__O(root_568, arg_571) }; if linked_564 == nil { arg_562 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { arg_562 = linked_564.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }; if linked_560 == nil { arg_558 = ifn_561.Invoke_O__O(arg_562) } else { arg_558 = linked_560.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_559, arg_562) }; if linked_556 == nil { names__3 = ifn_557.Invoke_O__O(arg_558) } else { names__3 = linked_556.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_555, arg_558) }; var vec__1700000123__4 any; var root_572 any = /*line :145:1*/A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_574 lang.IFn; if







	linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var root_576 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = s__0; var arg_580 any = A_arbace_repr_clojure_rules_A_const_61; if linked_577 == nil { arg_575 = ifn_578.Invoke_O_O__O(arg_579, arg_580) } else { arg_575 = linked_577.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_576, arg_579, arg_580) }; if linked_573 == nil { vec__1700000123__4 = ifn_574.Invoke_O__O(arg_575) } else { vec__1700000123__4 = linked_573.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_572, arg_575) }; var ns_a__5 any = /*line :145:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1700000123__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000123__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any; var root_581 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_583 lang.IFn; if








	linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = names__3; if linked_582 == nil { or__1927000174__auto____7 = ifn_583.Invoke_O__O(arg_584) } else { or__1927000174__auto____7 = linked_582.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ns_a__5, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var ns_text__7 any; var root_585 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_587 lang.IFn

		if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = s__0; var arg_589 any = ns_a__5; var arg_590 any = ns_b__6; if linked_586 == nil { ns_text__7 = ifn_587.Invoke_O_O_O__O(arg_588, arg_589, arg_590) } else { ns_text__7 = linked_586.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_585, arg_588, arg_589, arg_590) }
//line :154:1
		var names_text__8 any; var root_591 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_593 lang.IFn


		if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = Lit_5; var arg_595 any = names__3; if linked_592 == nil { names_text__8 = ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { names_text__8 = linked_592.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_591, arg_594, arg_595) }
//line :154:1
		var vec__1700000126__9 any; var root_596 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_598 lang.IFn



		if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any; var root_600 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = ns_text__7; var arg_604 any = A_arbace_repr_clojure_rules_A_const_63; if linked_601 == nil { arg_599 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { arg_599 = linked_601.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }; if linked_597 == nil { vec__1700000126__9 = ifn_598.Invoke_O__O(arg_599) } else { vec__1700000126__9 = linked_597.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_596, arg_599) }
//line :154:1
		var ra__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000126__9, lang.RT_IntCast_J__I_NoInit(0), nil); var rb__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000126__9, lang.RT_IntCast_J__I_NoInit(1), nil)




		if lang.Util_Identical_O_O__Z_NoInit(ra__10, nil) {

			var root_605 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = s__0; var arg_609 any; var na_611 any = ns_b__6; if jrt.Long_InstanceOf(na_611) { var n0_612 int64 = jrt.NN(jrt.Long_Cast(na_611)).LongValue__J(); if n0_612 == -9223372036854775808 { arg_609 = lang.Numbers_Dec_O__Number_NoInit(na_611) } else { arg_609 = jrt.Long_ValueOf_J__Long_NoInit(n0_612 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_611) { var n0_612_2 float64 = jrt.NN(jrt.Double_Cast(na_611)).DoubleValue__D(); arg_609 = jrt.Double_ValueOf_D__Double_NoInit(n0_612_2 - 1.0).Ref() } else { arg_609 = lang.Numbers_Dec_O__Number_NoInit(na_611) } }; var arg_610 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref(); if linked_606 == nil { return ifn_607.Invoke_O_O_O__O(arg_608, arg_609, arg_610) } else { return linked_606.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_605, arg_608, arg_609, arg_610) } } else {
//line :159:1
				var tmp2 any; var root_613 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_615 lang.IFn


				if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any; var root_618 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = ns_text__7; var arg_622 any = ra__10; var arg_623 any = rb__11; if linked_619 == nil { arg_616 = ifn_620.Invoke_O_O_O__O(arg_621, arg_622, arg_623) } else { arg_616 = linked_619.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_618, arg_621, arg_622, arg_623) }; var arg_617 any = Lit_8; if linked_614 == nil { tmp2 = ifn_615.Invoke_O_O__O(arg_616, arg_617) } else { tmp2 = linked_614.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_613, arg_616, arg_617) }
//line :159:1
				if jrt.J2g_Truth(tmp2) { return s__0 } else { if A_arbace_repr_clojure_rules_A_const_48 != nil { var rc__12 any; var root_624 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_626 lang.IFn





					if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = ns_text__7; var arg_628 any = ra__10; var arg_629 any = rb__11; if linked_625 == nil { rc__12 = ifn_626.Invoke_O_O_O__O(arg_627, arg_628, arg_629) } else { rc__12 = linked_625.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_624, arg_627, arg_628, arg_629) }
//line :159:1
					var ex__13 any; var root_630 any = A_arbace_repr_clojure_rules_A_const_65.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_632 lang.IFn






					if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = rc__12; var arg_634 any = Lit_9; if linked_631 == nil { ex__13 = ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { ex__13 = linked_631.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) }
					if lang.Util_Identical_O_O__Z_NoInit(ex__13, nil) {
						var root_635 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = s__0; var arg_639 any; var na_641 any; var na_643 any = ns_a__5; var na_644 any = ra__10; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_643); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_644) }; tmp3 = tmp4; if tmp3 { var n0_645 int64 = jrt.NN(jrt.Long_Cast(na_643)).LongValue__J(); var n1_646 int64 = jrt.NN(jrt.Long_Cast(na_644)).LongValue__J(); var nr_647 int64 = n0_645 + n1_646; if (n0_645^nr_647)&(n1_646^nr_647) >= 0 { na_641 = jrt.Long_ValueOf_J__Long_NoInit(nr_647).Ref() } else { na_641 = lang.Numbers_Add_O_O__Number_NoInit(na_643, na_644) } } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_643); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_644) }; tmp5 = tmp6; if tmp5 { var n0_645_2 float64 = jrt.NN(jrt.Double_Cast(na_643)).DoubleValue__D(); var n1_646_2 float64 = jrt.NN(jrt.Double_Cast(na_644)).DoubleValue__D(); na_641 = jrt.Double_ValueOf_D__Double_NoInit(n0_645_2 + n1_646_2).Ref() } else { na_641 = lang.Numbers_Add_O_O__Number_NoInit(na_643, na_644) } }; var na_642 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rc__12))); if jrt.Long_InstanceOf(na_641) { var n0_648 int64 = jrt.NN(jrt.Long_Cast(na_641)).LongValue__J(); var n1_649 int64 = na_642; var nr_650 int64 = n0_648 + n1_649; if (n0_648^nr_650)&(n1_649^nr_650) >= 0 { arg_639 = jrt.Long_ValueOf_J__Long_NoInit(nr_650).Ref() } else { arg_639 = lang.Numbers_Add_O_J__Number_NoInit(na_641, na_642) } } else { arg_639 = lang.Numbers_Add_O_J__Number_NoInit(na_641, na_642) }; var arg_640 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref(); if linked_636 == nil { return ifn_637.Invoke_O_O_O__O(arg_638, arg_639, arg_640) } else { return linked_636.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_635, arg_638, arg_639, arg_640) } } else {
//line :167:1
							var v__14 any; var root_651 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_653 lang.IFn

							if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = rc__12; var arg_655 any; var na_656 any = ex__13; var na_657 int64 = int64(lang.RT_Count_O__I_NoInit(Lit_9)); if jrt.Long_InstanceOf(na_656) { var n0_658 int64 = jrt.NN(jrt.Long_Cast(na_656)).LongValue__J(); var n1_659 int64 = na_657; var nr_660 int64 = n0_658 + n1_659; if (n0_658^nr_660)&(n1_659^nr_660) >= 0 { arg_655 = jrt.Long_ValueOf_J__Long_NoInit(nr_660).Ref() } else { arg_655 = lang.Numbers_Add_O_J__Number_NoInit(na_656, na_657) } } else { arg_655 = lang.Numbers_Add_O_J__Number_NoInit(na_656, na_657) }; if linked_652 == nil { v__14 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { v__14 = linked_652.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_651, arg_654, arg_655) }
//line :167:1
							var ve__15 any; var root_661 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_661, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_663 lang.IFn


							if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = rc__12; var arg_665 any = v__14; if linked_662 == nil { ve__15 = ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { if jrt.Long_InstanceOf(arg_665) { ve__15 = linked_662.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_661, arg_664, jrt.NN(jrt.Long_Cast(arg_665)).LongValue__J(), arg_665) } else { ve__15 = linked_662.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) } }
							var root_666 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = s__0; var arg_670 any; var na_672 any; var na_674 any = ns_a__5; var na_675 any = ra__10; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_674); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_675) }; tmp7 = tmp8; if tmp7 { var n0_676 int64 = jrt.NN(jrt.Long_Cast(na_674)).LongValue__J(); var n1_677 int64 = jrt.NN(jrt.Long_Cast(na_675)).LongValue__J(); var nr_678 int64 = n0_676 + n1_677; if (n0_676^nr_678)&(n1_677^nr_678) >= 0 { na_672 = jrt.Long_ValueOf_J__Long_NoInit(nr_678).Ref() } else { na_672 = lang.Numbers_Add_O_O__Number_NoInit(na_674, na_675) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_674); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_675) }; tmp9 = tmp10; if tmp9 { var n0_676_2 float64 = jrt.NN(jrt.Double_Cast(na_674)).DoubleValue__D(); var n1_677_2 float64 = jrt.NN(jrt.Double_Cast(na_675)).DoubleValue__D(); na_672 = jrt.Double_ValueOf_D__Double_NoInit(n0_676_2 + n1_677_2).Ref() } else { na_672 = lang.Numbers_Add_O_O__Number_NoInit(na_674, na_675) } }; var na_673 any; var na_679 any = ve__15; if jrt.Long_InstanceOf(na_679) { var n0_680 int64 = jrt.NN(jrt.Long_Cast(na_679)).LongValue__J(); if n0_680 == -9223372036854775808 { na_673 = lang.Numbers_Dec_O__Number_NoInit(na_679) } else { na_673 = jrt.Long_ValueOf_J__Long_NoInit(n0_680 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_679) { var n0_680_2 float64 = jrt.NN(jrt.Double_Cast(na_679)).DoubleValue__D(); na_673 = jrt.Double_ValueOf_D__Double_NoInit(n0_680_2 - 1.0).Ref() } else { na_673 = lang.Numbers_Dec_O__Number_NoInit(na_679) } }; var tmp11 bool; var tmp12 bool; tmp12 = jrt.Long_InstanceOf(na_672); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_673) }; tmp11 = tmp12; if tmp11 { var n0_681 int64 = jrt.NN(jrt.Long_Cast(na_672)).LongValue__J(); var n1_682 int64 = jrt.NN(jrt.Long_Cast(na_673)).LongValue__J(); var nr_683 int64 = n0_681 + n1_682; if (n0_681^nr_683)&(n1_682^nr_683) >= 0 { arg_670 = jrt.Long_ValueOf_J__Long_NoInit(nr_683).Ref() } else { arg_670 = lang.Numbers_Add_O_O__Number_NoInit(na_672, na_673) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_672); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_673) }; tmp13 = tmp14; if tmp13 { var n0_681_2 float64 = jrt.NN(jrt.Double_Cast(na_672)).DoubleValue__D(); var n1_682_2 float64 = jrt.NN(jrt.Double_Cast(na_673)).DoubleValue__D(); arg_670 = jrt.Double_ValueOf_D__Double_NoInit(n0_681_2 + n1_682_2).Ref() } else { arg_670 = lang.Numbers_Add_O_O__Number_NoInit(na_672, na_673) } }; var arg_671 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8)).Ref(); if linked_667 == nil { return ifn_668.Invoke_O_O_O__O(arg_669, arg_670, arg_671) } else { return linked_667.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_666, arg_669, arg_670, arg_671) } } } else {
//line :159:1
								return nil } } } } }













func A_arbace_repr_clojure_rules_cut_A_New() *A_arbace_repr_clojure_rules_cut_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_cut_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_clojure_rules_cut_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_clojure_rules_cut_A) Invoke_O_O_O_O__O(self, s__0, a__1, b__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_684 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = s__0; var arg_688 any = A_arbace_repr_clojure_rules_A_const_30; var arg_689 any = a__1; if linked_685 == nil { tmp2 = ifn_686.Invoke_O_O_O__O(arg_687, arg_688, arg_689) } else { tmp2 = linked_685.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_684, arg_687, arg_688, arg_689) }; var tmp3 any = tmp2; var tmp4 any; var root_690 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__0; var arg_694 any = b__2; if linked_691 == nil { tmp4 = ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { tmp4 = linked_691.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref() }

func A_arbace_repr_clojure_rules_uncore_names_A_New() *A_arbace_repr_clojure_rules_uncore_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_repr_clojure_rules_uncore_names_A) Ctor() {}
//line :175:1
func (t *A_arbace_repr_clojure_rules_uncore_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any; var root_695 any = A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_697 lang.IFn; if







	linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any; var root_699 any = A_arbace_repr_clojure_rules_A_const_59.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var root_703 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = added__1; var arg_707 any; var root_708 any = A_arbace_repr_clojure_rules_A_const_60.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, A_arbace_repr_clojure_rules_defined_names_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = s__0; if linked_709 == nil { arg_707 = ifn_710.Invoke_O__O(arg_711) } else { arg_707 = linked_709.(*A_arbace_repr_clojure_rules_defined_names_A).Invoke_O_O__O(root_708, arg_711) }; if linked_704 == nil { arg_702 = ifn_705.Invoke_O_O__O(arg_706, arg_707) } else { arg_702 = linked_704.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_703, arg_706, arg_707) }; if linked_700 == nil { arg_698 = ifn_701.Invoke_O__O(arg_702) } else { arg_698 = linked_700.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_699, arg_702) }; if linked_696 == nil { names__3 = ifn_697.Invoke_O__O(arg_698) } else { names__3 = linked_696.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_695, arg_698) }; var vec__1700000132__4 any; var root_712 any = /*line :175:1*/A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_714 lang.IFn; if








	linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any; var root_716 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__0; var arg_720 any = A_arbace_repr_clojure_rules_A_const_66; if linked_717 == nil { arg_715 = ifn_718.Invoke_O_O__O(arg_719, arg_720) } else { arg_715 = linked_717.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_716, arg_719, arg_720) }; if linked_713 == nil { vec__1700000132__4 = ifn_714.Invoke_O__O(arg_715) } else { vec__1700000132__4 = linked_713.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_712, arg_715) }; var ns_a__5 any = /*line :175:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1700000132__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000132__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any; var root_721 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_723 lang.IFn; if









	linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = names__3; if linked_722 == nil { or__1927000174__auto____7 = ifn_723.Invoke_O__O(arg_724) } else { or__1927000174__auto____7 = linked_722.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_721, arg_724) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ns_a__5, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var nt__7 any; var root_725 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_727 lang.IFn

		if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = Lit_5; var arg_729 any = names__3; if linked_726 == nil { nt__7 = ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { nt__7 = linked_726.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) }
//line :185:1
		var suffix_QMARK___8 any; var fnbody__761 any = A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_New_O(s__0); var tmp2 *jrt.Class
		var fncls__760 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class


		if fncls__760 == nil { var fncls__760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__761); A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class = fncls__760d; tmp2 = fncls__760d } else { tmp2 = fncls__760 }; suffix_QMARK___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__761, tmp2, nil)
//line :185:1
		var a__9 any; var x__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, nt__7, nil)).Ref(); var e__10 any
		var na_762 any = ns_b__6



		if jrt.Long_InstanceOf(na_762) { var n0_763 int64 = jrt.NN(jrt.Long_Cast(na_762)).LongValue__J(); if n0_763 == -9223372036854775808 { e__10 = lang.Numbers_Dec_O__Number_NoInit(na_762) } else { e__10 = jrt.Long_ValueOf_J__Long_NoInit(n0_763 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_762) { var n0_763_2 float64 = jrt.NN(jrt.Double_Cast(na_762)).DoubleValue__D(); e__10 = jrt.Double_ValueOf_D__Double_NoInit(n0_763_2 - 1.0).Ref() } else { e__10 = lang.Numbers_Dec_O__Number_NoInit(na_762) } }
		if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__10, x__9)) { var root_764 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = s__0; var arg_768 any; var na_770 any = e__10; var na_771 int64 = int64(lang.RT_Count_O__I_NoInit(x__9)); if jrt.Long_InstanceOf(na_770) { var n0_772 int64 = jrt.NN(jrt.Long_Cast(na_770)).LongValue__J(); var n1_773 int64 = na_771; var nr_774 int64 = n0_772 - n1_773; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_773 == -9223372036854775808); if tmp4 { tmp4 = (n0_772^n1_773)&(n0_772^nr_774) >= 0 }; tmp3 = tmp4; if tmp3 { arg_768 = jrt.Long_ValueOf_J__Long_NoInit(nr_774).Ref() } else { arg_768 = lang.Numbers_Minus_O_J__Number_NoInit(na_770, na_771) } } else { arg_768 = lang.Numbers_Minus_O_J__Number_NoInit(na_770, na_771) }; var arg_769 any = e__10; if linked_765 == nil { a__9 = ifn_766.Invoke_O_O_O__O(arg_767, arg_768, arg_769) } else { a__9 = linked_765.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_764, arg_767, arg_768, arg_769) } } else { a__9 = nil }
//line :185:1
		var ns_text__10 any; var root_775 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_777 lang.IFn






		if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = s__0; var arg_779 any = ns_a__5; var arg_780 any = ns_b__6; if linked_776 == nil { ns_text__10 = ifn_777.Invoke_O_O_O__O(arg_778, arg_779, arg_780) } else { ns_text__10 = linked_776.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_775, arg_778, arg_779, arg_780) }
//line :185:1
		var vec__1700000135__11 any; var root_781 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_783 lang.IFn







		if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var root_785 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = ns_text__10; var arg_789 any = A_arbace_repr_clojure_rules_A_const_68; if linked_786 == nil { arg_784 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { arg_784 = linked_786.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; if linked_782 == nil { vec__1700000135__11 = ifn_783.Invoke_O__O(arg_784) } else { vec__1700000135__11 = linked_782.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_781, arg_784) }
//line :185:1
		var ra__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000135__11, lang.RT_IntCast_J__I_NoInit(0), nil); var rb__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000135__11, lang.RT_IntCast_J__I_NoInit(1), nil); var b__14 any









		if jrt.J2g_Truth(ra__12) { var x__14 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, nt__7, nil)).Ref(); var e__15 any; var na_790 any = ns_a__5; var na_791 any; var na_792 any = rb__13
			if jrt.Long_InstanceOf(na_792) { var n0_793 int64 = jrt.NN(jrt.Long_Cast(na_792)).LongValue__J(); if n0_793 == -9223372036854775808 { na_791 = lang.Numbers_Dec_O__Number_NoInit(na_792) } else { na_791 = jrt.Long_ValueOf_J__Long_NoInit(n0_793 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_792) { var n0_793_2 float64 = jrt.NN(jrt.Double_Cast(na_792)).DoubleValue__D(); na_791 = jrt.Double_ValueOf_D__Double_NoInit(n0_793_2 - 1.0).Ref() } else { na_791 = lang.Numbers_Dec_O__Number_NoInit(na_792) } }; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_790); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_791) }; tmp5 = tmp6; if tmp5 { var n0_794 int64 = jrt.NN(jrt.Long_Cast(na_790)).LongValue__J(); var n1_795 int64 = jrt.NN(jrt.Long_Cast(na_791)).LongValue__J(); var nr_796 int64 = n0_794 + n1_795; if (n0_794^nr_796)&(n1_795^nr_796) >= 0 { e__15 = jrt.Long_ValueOf_J__Long_NoInit(nr_796).Ref() } else { e__15 = lang.Numbers_Add_O_O__Number_NoInit(na_790, na_791) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_790); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_791) }; tmp7 = tmp8; if tmp7 { var n0_794_2 float64 = jrt.NN(jrt.Double_Cast(na_790)).DoubleValue__D(); var n1_795_2 float64 = jrt.NN(jrt.Double_Cast(na_791)).DoubleValue__D(); e__15 = jrt.Double_ValueOf_D__Double_NoInit(n0_794_2 + n1_795_2).Ref() } else { e__15 = lang.Numbers_Add_O_O__Number_NoInit(na_790, na_791) } }
			if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__15, x__14)) { var root_797 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = s__0; var arg_801 any; var na_803 any = e__15; var na_804 int64 = int64(lang.RT_Count_O__I_NoInit(x__14)); if jrt.Long_InstanceOf(na_803) { var n0_805 int64 = jrt.NN(jrt.Long_Cast(na_803)).LongValue__J(); var n1_806 int64 = na_804; var nr_807 int64 = n0_805 - n1_806; var tmp9 bool; var tmp10 bool; tmp10 = !(n1_806 == -9223372036854775808); if tmp10 { tmp10 = (n0_805^n1_806)&(n0_805^nr_807) >= 0 }; tmp9 = tmp10; if tmp9 { arg_801 = jrt.Long_ValueOf_J__Long_NoInit(nr_807).Ref() } else { arg_801 = lang.Numbers_Minus_O_J__Number_NoInit(na_803, na_804) } } else { arg_801 = lang.Numbers_Minus_O_J__Number_NoInit(na_803, na_804) }; var arg_802 any = e__15; if linked_798 == nil { b__14 = ifn_799.Invoke_O_O_O__O(arg_800, arg_801, arg_802) } else { b__14 = linked_798.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_797, arg_800, arg_801, arg_802) } } else { b__14 = nil } } else {
//line :195:1
				b__14 = nil }
//line :185:1
		var c__15 any













		if jrt.J2g_Truth(ra__12) { var rc__15 any; var root_808 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_810 lang.IFn
			if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = ns_text__10; var arg_812 any = ra__12; var arg_813 any = rb__13; if linked_809 == nil { rc__15 = ifn_810.Invoke_O_O_O__O(arg_811, arg_812, arg_813) } else { rc__15 = linked_809.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_808, arg_811, arg_812, arg_813) }
//line :199:1
			var temp__1927000414__auto____16 any; var root_814 any = A_arbace_repr_clojure_rules_A_const_65.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_816 lang.IFn

			if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = rc__15; var arg_818 any = Lit_9; if linked_815 == nil { temp__1927000414__auto____16 = ifn_816.Invoke_O_O__O(arg_817, arg_818) } else { temp__1927000414__auto____16 = linked_815.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_814, arg_817, arg_818) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var ex__17 any = temp__1927000414__auto____16; var v__18 any; var root_819 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_821 lang.IFn
				if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = rc__15; var arg_823 any; var na_824 any = ex__17; var na_825 int64 = int64(lang.RT_Count_O__I_NoInit(Lit_9)); if jrt.Long_InstanceOf(na_824) { var n0_826 int64 = jrt.NN(jrt.Long_Cast(na_824)).LongValue__J(); var n1_827 int64 = na_825; var nr_828 int64 = n0_826 + n1_827; if (n0_826^nr_828)&(n1_827^nr_828) >= 0 { arg_823 = jrt.Long_ValueOf_J__Long_NoInit(nr_828).Ref() } else { arg_823 = lang.Numbers_Add_O_J__Number_NoInit(na_824, na_825) } } else { arg_823 = lang.Numbers_Add_O_J__Number_NoInit(na_824, na_825) }; if linked_820 == nil { v__18 = ifn_821.Invoke_O_O__O(arg_822, arg_823) } else { v__18 = linked_820.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_819, arg_822, arg_823) }
//line :201:1
				var ve__19 any; var root_829 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_829, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_831 lang.IFn

				if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = rc__15; var arg_833 any = v__18; if linked_830 == nil { ve__19 = ifn_831.Invoke_O_O__O(arg_832, arg_833) } else { if jrt.Long_InstanceOf(arg_833) { ve__19 = linked_830.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_829, arg_832, jrt.NN(jrt.Long_Cast(arg_833)).LongValue__J(), arg_833) } else { ve__19 = linked_830.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_829, arg_832, arg_833) } }
//line :201:1
				var x__20 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, nt__7)).Ref(); var e__21 any; var na_834 any; var na_836 any = ns_a__5; var na_837 any = ra__12; var tmp11 bool; var tmp12 bool


				tmp12 = jrt.Long_InstanceOf(na_836); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_837) }; tmp11 = tmp12; if tmp11 { var n0_838 int64 = jrt.NN(jrt.Long_Cast(na_836)).LongValue__J(); var n1_839 int64 = jrt.NN(jrt.Long_Cast(na_837)).LongValue__J(); var nr_840 int64 = n0_838 + n1_839; if (n0_838^nr_840)&(n1_839^nr_840) >= 0 { na_834 = jrt.Long_ValueOf_J__Long_NoInit(nr_840).Ref() } else { na_834 = lang.Numbers_Add_O_O__Number_NoInit(na_836, na_837) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_836); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_837) }; tmp13 = tmp14; if tmp13 { var n0_838_2 float64 = jrt.NN(jrt.Double_Cast(na_836)).DoubleValue__D(); var n1_839_2 float64 = jrt.NN(jrt.Double_Cast(na_837)).DoubleValue__D(); na_834 = jrt.Double_ValueOf_D__Double_NoInit(n0_838_2 + n1_839_2).Ref() } else { na_834 = lang.Numbers_Add_O_O__Number_NoInit(na_836, na_837) } }; var na_835 any; var na_841 any = ve__19; if jrt.Long_InstanceOf(na_841) { var n0_842 int64 = jrt.NN(jrt.Long_Cast(na_841)).LongValue__J(); if n0_842 == -9223372036854775808 { na_835 = lang.Numbers_Dec_O__Number_NoInit(na_841) } else { na_835 = jrt.Long_ValueOf_J__Long_NoInit(n0_842 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_841) { var n0_842_2 float64 = jrt.NN(jrt.Double_Cast(na_841)).DoubleValue__D(); na_835 = jrt.Double_ValueOf_D__Double_NoInit(n0_842_2 - 1.0).Ref() } else { na_835 = lang.Numbers_Dec_O__Number_NoInit(na_841) } }; var tmp15 bool; var tmp16 bool; tmp16 = jrt.Long_InstanceOf(na_834); if tmp16 { tmp16 = jrt.Long_InstanceOf(na_835) }; tmp15 = tmp16; if tmp15 { var n0_843 int64 = jrt.NN(jrt.Long_Cast(na_834)).LongValue__J(); var n1_844 int64 = jrt.NN(jrt.Long_Cast(na_835)).LongValue__J(); var nr_845 int64 = n0_843 + n1_844; if (n0_843^nr_845)&(n1_844^nr_845) >= 0 { e__21 = jrt.Long_ValueOf_J__Long_NoInit(nr_845).Ref() } else { e__21 = lang.Numbers_Add_O_O__Number_NoInit(na_834, na_835) } } else { var tmp17 bool; var tmp18 bool; tmp18 = jrt.Double_InstanceOf(na_834); if tmp18 { tmp18 = jrt.Double_InstanceOf(na_835) }; tmp17 = tmp18; if tmp17 { var n0_843_2 float64 = jrt.NN(jrt.Double_Cast(na_834)).DoubleValue__D(); var n1_844_2 float64 = jrt.NN(jrt.Double_Cast(na_835)).DoubleValue__D(); e__21 = jrt.Double_ValueOf_D__Double_NoInit(n0_843_2 + n1_844_2).Ref() } else { e__21 = lang.Numbers_Add_O_O__Number_NoInit(na_834, na_835) } }
				if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__21, x__20)) { var root_846 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = s__0; var arg_850 any; var na_852 any = e__21; var na_853 int64 = int64(lang.RT_Count_O__I_NoInit(x__20)); if jrt.Long_InstanceOf(na_852) { var n0_854 int64 = jrt.NN(jrt.Long_Cast(na_852)).LongValue__J(); var n1_855 int64 = na_853; var nr_856 int64 = n0_854 - n1_855; var tmp19 bool; var tmp20 bool; tmp20 = !(n1_855 == -9223372036854775808); if tmp20 { tmp20 = (n0_854^n1_855)&(n0_854^nr_856) >= 0 }; tmp19 = tmp20; if tmp19 { arg_850 = jrt.Long_ValueOf_J__Long_NoInit(nr_856).Ref() } else { arg_850 = lang.Numbers_Minus_O_J__Number_NoInit(na_852, na_853) } } else { arg_850 = lang.Numbers_Minus_O_J__Number_NoInit(na_852, na_853) }; var arg_851 any = e__21; if linked_847 == nil { c__15 = ifn_848.Invoke_O_O_O__O(arg_849, arg_850, arg_851) } else { c__15 = linked_847.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_846, arg_849, arg_850, arg_851) } } else { c__15 = nil } } else {
//line :201:1
					c__15 = nil } } else {
//line :199:1
						c__15 = nil }
//line :185:1
		var or__1927000174__auto____16 any; var root_857 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_859 lang.IFn




















		if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any; var fnbody__872 any = A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_New_O_O(s__0, added__1); var tmp21 *jrt.Class; var fncls__871 *jrt.Class = A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class; if fncls__871 == nil { var fncls__871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__872); A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class = fncls__871d; tmp21 = fncls__871d } else { tmp21 = fncls__871 }; arg_864 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__872, tmp21, nil); var arg_865 any = lang.Tuple_Create_O_O_O__IPersistentVector(a__9, b__14, c__15); if linked_862 == nil { arg_860 = ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }; if linked_858 == nil { or__1927000174__auto____16 = ifn_859.Invoke_O__O(arg_860) } else { or__1927000174__auto____16 = linked_858.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_857, arg_860) }; if jrt.J2g_Truth(or__1927000174__auto____16) { return or__1927000174__auto____16 } else { return s__0 } } }
//line :188:1
func A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_New_O(p0 any) *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) Invoke_O_O_O__O(self, end__1, x__2 any) any { if jrt.Long_InstanceOf(end__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(end__1)).LongValue__J(), end__1, x__2) } else { var and__1927000168__auto____3 bool; var na_730 any = end__1; var na_731 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); if jrt.Long_InstanceOf(na_730) { var n0_732 int64 = jrt.NN(jrt.Long_Cast(na_730)).LongValue__J(); var n1_733 int64 = na_731; and__1927000168__auto____3 = n0_732 >= n1_733 } else { and__1927000168__auto____3 = lang.Numbers_Gte_O_J__Z_NoInit(na_730, na_731) }; if and__1927000168__auto____3 { var tmp1 any; var root_735 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = t.F_s; var arg_739 any; var na_741 any = end__1; var na_742 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); if jrt.Long_InstanceOf(na_741) { var n0_743 int64 = jrt.NN(jrt.Long_Cast(na_741)).LongValue__J(); var n1_744 int64 = na_742; var nr_745 int64 = n0_743 - n1_744; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_744 == -9223372036854775808); if tmp3 { tmp3 = (n0_743^n1_744)&(n0_743^nr_745) >= 0 }; tmp2 = tmp3; if tmp2 { arg_739 = jrt.Long_ValueOf_J__Long_NoInit(nr_745).Ref() } else { arg_739 = lang.Numbers_Minus_O_J__Number_NoInit(na_741, na_742) } } else { arg_739 = lang.Numbers_Minus_O_J__Number_NoInit(na_741, na_742) }; var arg_740 any = end__1; if linked_736 == nil { tmp1 = ifn_737.Invoke_O_O_O__O(arg_738, arg_739, arg_740) } else { tmp1 = linked_736.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_735, arg_738, arg_739, arg_740) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__2, tmp1)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) InvokeSpec_O_J_O_O__O(self any, end__1_l int64, end__1_b, x__2 any) any { var and__1927000168__auto____3 bool; var na_746 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); var n0_747 int64 = end__1_l; var n1_748 int64 = na_746; and__1927000168__auto____3 = n0_747 >= n1_748; if and__1927000168__auto____3 { var tmp1 any; var root_750 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = t.F_s; var arg_754 any; var na_756 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); var n0_757 int64 = end__1_l; var n1_758 int64 = na_756; var nr_759 int64 = n0_757 - n1_758; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_758 == -9223372036854775808); if tmp3 { tmp3 = (n0_757^n1_758)&(n0_757^nr_759) >= 0 }; tmp2 = tmp3; if tmp2 { arg_754 = jrt.Long_ValueOf_J__Long_NoInit(nr_759).Ref() } else { var tmp4 any; if end__1_b == nil { end__1_b = jrt.Long_ValueOf_J__Long_NoInit(end__1_l).Ref(); tmp4 = end__1_b } else { tmp4 = end__1_b }; arg_754 = lang.Numbers_Minus_O_J__Number_NoInit(tmp4, na_756) }; var arg_755 any; if end__1_b == nil { end__1_b = jrt.Long_ValueOf_J__Long_NoInit(end__1_l).Ref(); arg_755 = end__1_b } else { arg_755 = end__1_b }; if linked_751 == nil { tmp1 = ifn_752.Invoke_O_O_O__O(arg_753, arg_754, arg_755) } else { tmp1 = linked_751.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_750, arg_753, arg_754, arg_755) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__2, tmp1)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

















func A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A{}; t.Ctor_O_O(p0, p1); return t }
//line :206:1
func (t *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A) Ctor_O_O(c__s, c__added any) { t.F_s = c__s; t.F_added = c__added }
//line :206:1
func (t *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A) Invoke_O_O__O(self, p1__1700000131_SHARP___1 any) any { var and__1927000168__auto____2 any = p1__1700000131_SHARP___1; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = t.F_s; var tmp2 any; var root_866 any = A_arbace_repr_clojure_rules_A_const_69.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, A_arbace_repr_clojure_rules_core_names_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = p1__1700000131_SHARP___1; var arg_870 any = t.F_added; if linked_867 == nil { tmp2 = ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { tmp2 = linked_867.(*A_arbace_repr_clojure_rules_core_names_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }







func A_arbace_repr_clojure_rules_fn__1700000143_A_New() *A_arbace_repr_clojure_rules_fn__1700000143_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000143_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repr_clojure_rules_fn__1700000143_A) Ctor() {}
//line :214:1
func (t *A_arbace_repr_clojure_rules_fn__1700000143_A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 any = A_arbace_repr_clojure_rules_A_const_70; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0)); if and__1927000168__auto____2 { return A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_repr_clojure_rules_fn__1700000145_A_New() *A_arbace_repr_clojure_rules_fn__1700000145_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000145_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_repr_clojure_rules_fn__1700000145_A) Ctor() {}
//line :215:1
func (t *A_arbace_repr_clojure_rules_fn__1700000145_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_873 any = A_arbace_repr_clojure_rules_A_const_72.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = s__0; var arg_877 any = A_arbace_repr_clojure_rules_A_const_73.Invoke_O__O(ctx__1); if linked_874 == nil { return ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { return linked_874.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) } }






func A_arbace_repr_clojure_rules_fn__1700000147_A_New() *A_arbace_repr_clojure_rules_fn__1700000147_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000147_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_repr_clojure_rules_fn__1700000147_A) Ctor() {}
//line :222:1
func (t *A_arbace_repr_clojure_rules_fn__1700000147_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return s__0 }






func A_arbace_repr_clojure_rules_fn__1700000149_A_New() *A_arbace_repr_clojure_rules_fn__1700000149_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000149_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_repr_clojure_rules_fn__1700000149_A) Ctor() {}
//line :229:1
func (t *A_arbace_repr_clojure_rules_fn__1700000149_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_878 any = A_arbace_repr_clojure_rules_A_const_74.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_rename_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = s__0; if linked_879 == nil { return ifn_880.Invoke_O__O(arg_881) } else { return linked_879.(*aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_rename_A).Invoke_O_O__O(root_878, arg_881) } }



func A_arbace_repr_clojure_rules_fn__1700000151_A_New() *A_arbace_repr_clojure_rules_fn__1700000151_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000151_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_repr_clojure_rules_fn__1700000151_A) Ctor() {}
//line :233:1
func (t *A_arbace_repr_clojure_rules_fn__1700000151_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_882 any = A_arbace_repr_clojure_rules_A_const_75.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_unrename_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = s__0; if linked_883 == nil { return ifn_884.Invoke_O__O(arg_885) } else { return linked_883.(*aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_unrename_A).Invoke_O_O__O(root_882, arg_885) } }





func A_arbace_repr_clojure_rules_fn__1700000153_A_New() *A_arbace_repr_clojure_rules_fn__1700000153_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000153_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_repr_clojure_rules_fn__1700000153_A) Ctor() {}
//line :239:1
func (t *A_arbace_repr_clojure_rules_fn__1700000153_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_886 any = A_arbace_repr_clojure_rules_A_const_76.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_repr_clojure_rules_proxy_methods_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = s__0; if linked_887 == nil { return ifn_888.Invoke_O__O(arg_889) } else { return linked_887.(*A_arbace_repr_clojure_rules_proxy_methods_A).Invoke_O_O__O(root_886, arg_889) } }


func A_arbace_repr_clojure_rules_fn__1700000155_A_New() *A_arbace_repr_clojure_rules_fn__1700000155_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000155_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_repr_clojure_rules_fn__1700000155_A) Ctor() {}
//line :242:1
func (t *A_arbace_repr_clojure_rules_fn__1700000155_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_890 any = A_arbace_repr_clojure_rules_A_const_77.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = s__0; if linked_891 == nil { return ifn_892.Invoke_O__O(arg_893) } else { return linked_891.(*A_arbace_repr_clojure_rules_unproxy_methods_A).Invoke_O_O__O(root_890, arg_893) } }





func A_arbace_repr_clojure_rules_fn__1700000157_A_New() *A_arbace_repr_clojure_rules_fn__1700000157_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000157_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_repr_clojure_rules_fn__1700000157_A) Ctor() {}
//line :248:1
func (t *A_arbace_repr_clojure_rules_fn__1700000157_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_894 any = A_arbace_repr_clojure_rules_A_const_69.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, A_arbace_repr_clojure_rules_core_names_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = s__0; var arg_898 any; var or__1927000174__auto____3 any = A_arbace_repr_clojure_rules_A_const_78.Invoke_O__O(ctx__1); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_898 = or__1927000174__auto____3 } else { var root_899 any = A_arbace_repr_clojure_rules_A_const_79.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; if linked_900 == nil { arg_898 = ifn_901.Invoke__O() } else { arg_898 = linked_900.(*A_arbace_repr_clojure_rules_arbace_core_names_A).Invoke_O__O(root_899) } }; if linked_895 == nil { return ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { return linked_895.(*A_arbace_repr_clojure_rules_core_names_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) } }



func A_arbace_repr_clojure_rules_fn__1700000159_A_New() *A_arbace_repr_clojure_rules_fn__1700000159_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000159_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_repr_clojure_rules_fn__1700000159_A) Ctor() {}
//line :252:1
func (t *A_arbace_repr_clojure_rules_fn__1700000159_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_902 any = A_arbace_repr_clojure_rules_A_const_80.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, A_arbace_repr_clojure_rules_uncore_names_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = s__0; var arg_906 any; var or__1927000174__auto____3 any = A_arbace_repr_clojure_rules_A_const_78.Invoke_O__O(ctx__1); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_906 = or__1927000174__auto____3 } else { var root_907 any = A_arbace_repr_clojure_rules_A_const_79.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; if linked_908 == nil { arg_906 = ifn_909.Invoke__O() } else { arg_906 = linked_908.(*A_arbace_repr_clojure_rules_arbace_core_names_A).Invoke_O__O(root_907) } }; if linked_903 == nil { return ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { return linked_903.(*A_arbace_repr_clojure_rules_uncore_names_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) } }




func A_arbace_repr_clojure_rules_fn__1700000161_A_New() *A_arbace_repr_clojure_rules_fn__1700000161_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000161_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_repr_clojure_rules_fn__1700000161_A) Ctor() {}
//line :257:1
func (t *A_arbace_repr_clojure_rules_fn__1700000161_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_910 any = A_arbace_repr_clojure_rules_A_const_81.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, A_arbace_repr_clojure_rules_security_manager_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = s__0; if linked_911 == nil { return ifn_912.Invoke_O__O(arg_913) } else { return linked_911.(*A_arbace_repr_clojure_rules_security_manager_A).Invoke_O_O__O(root_910, arg_913) } }



func A_arbace_repr_clojure_rules_fn__1700000163_A_New() *A_arbace_repr_clojure_rules_fn__1700000163_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000163_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_repr_clojure_rules_fn__1700000163_A) Ctor() {}
//line :261:1
func (t *A_arbace_repr_clojure_rules_fn__1700000163_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_914 any = A_arbace_repr_clojure_rules_A_const_82.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = s__0; if linked_915 == nil { return ifn_916.Invoke_O__O(arg_917) } else { return linked_915.(*A_arbace_repr_clojure_rules_unqualify_security_manager_A).Invoke_O_O__O(root_914, arg_917) } }































func A_arbace_repr_clojure_rules_applicable_A_New() *A_arbace_repr_clojure_rules_applicable_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Ctor() {}
//line :293:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Invoke_O_O_O__O(self, ctx__0, skip__1 any) any {


	var root_918 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any; var fnbody__933 any = A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_New_O_O(ctx__0, skip__1); var tmp1 *jrt.Class; var fncls__932 *jrt.Class = A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class; if fncls__932 == nil { var fncls__932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__933); A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class = fncls__932d; tmp1 = fncls__932d } else { tmp1 = fncls__932 }; arg_921 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__933, tmp1, nil); var arg_922 any = A_arbace_repr_clojure_rules_A_const_85.GetRawRoot__O(); if linked_919 == nil { return ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { return linked_919.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) } }
//line :296:1
func A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_fn__1700000166_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A) Ctor_O_O(c__ctx, c__skip any) { t.F_ctx = c__ctx; t.F_skip = c__skip }
//line :296:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A) Invoke_O_O__O(self, p1__1700000165_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_923 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any; var root_927 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = t.F_skip; var arg_931 any = A_arbace_repr_clojure_rules_A_const_83.Invoke_O__O(p1__1700000165_SHARP___1); if linked_928 == nil { arg_926 = ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { arg_926 = linked_928.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }; if linked_924 == nil { and__1927000168__auto____2 = ifn_925.Invoke_O__O(arg_926) } else { and__1927000168__auto____2 = linked_924.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_923, arg_926) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_84.Invoke_O__O(p1__1700000165_SHARP___1)).Invoke_O__O(t.F_ctx) } else { return and__1927000168__auto____2 } }











func A_arbace_repr_clojure_rules_full_block_A_New() *A_arbace_repr_clojure_rules_full_block_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_block_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_repr_clojure_rules_full_block_A) Ctor() {}
//line :308:1
func (t *A_arbace_repr_clojure_rules_full_block_A) Invoke_O_O__O(self, conditionals__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(jrt.String_Cast(A_arbace_repr_clojure_rules_A_const_86.GetRawRoot__O())); var seq_1700000169__3 any; var root_938 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_940 lang.IFn; if





	linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = conditionals__0; if linked_939 == nil { seq_1700000169__3 = ifn_940.Invoke_O__O(arg_941) } else { seq_1700000169__3 = linked_939.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_938, arg_941) }; var chunk_1700000170__4 any; var count_1700000171__5 int64 = 0; var i_1700000172__6 int64 = 0; L1:
//line :308:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1700000172__6, count_1700000171__5) { var map__1700000173__7 any = lang.Indexed_Cast(chunk_1700000170__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1700000172__6)); var map__1700000173__8 any; if lang.ISeq_InstanceOf(map__1700000173__7) { var tmp1 any; var root_942 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = map__1700000173__7; if linked_943 == nil { tmp1 = ifn_944.Invoke_O__O(arg_945) } else { tmp1 = linked_943.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_942, arg_945) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_946 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = map__1700000173__7; if linked_947 == nil { tmp2 = ifn_948.Invoke_O__O(arg_949) } else { tmp2 = linked_947.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_946, arg_949) }; map__1700000173__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_950 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = map__1700000173__7; if linked_951 == nil { tmp3 = ifn_952.Invoke_O__O(arg_953) } else { tmp3 = linked_951.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_950, arg_953) }; if jrt.J2g_Truth(tmp3) { var root_954 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = map__1700000173__7; if linked_955 == nil { map__1700000173__8 = ifn_956.Invoke_O__O(arg_957) } else { map__1700000173__8 = linked_955.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_954, arg_957) } } else { map__1700000173__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1700000173__8 = map__1700000173__7 }; var at__9 any = lang.RT_Get_O_O__O_NoInit(map__1700000173__8, A_arbace_repr_clojure_rules_A_const_89); var length__10 any = lang.RT_Get_O_O__O_NoInit(map__1700000173__8, A_arbace_repr_clojure_rules_A_const_90); var text__11 any = lang.RT_Get_O_O__O_NoInit(map__1700000173__8, A_arbace_repr_clojure_rules_A_const_91)
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_5, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, at__9, nil, length__10, nil)))
//line :314:1
			var seq_1700000175__12 any; var root_990 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_992 lang.IFn

			if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any; var root_994 any = A_arbace_repr_clojure_rules_A_const_92.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = text__11; var arg_998 any = A_arbace_repr_clojure_rules_A_const_93; var arg_999 any = A_arbace_repr_clojure_rules_A_const_94; if linked_995 == nil { arg_993 = ifn_996.Invoke_O_O_O__O(arg_997, arg_998, arg_999) } else { arg_993 = linked_995.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_994, arg_997, arg_998, arg_999) }; if linked_991 == nil { seq_1700000175__12 = ifn_992.Invoke_O__O(arg_993) } else { seq_1700000175__12 = linked_991.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_990, arg_993) }
//line :314:1
			var chunk_1700000176__13 any; var count_1700000177__14 int64 = 0; var i_1700000178__15 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1700000178__15, count_1700000177__14) { var l__16 any = lang.Indexed_Cast(chunk_1700000176__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1700000178__15)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__16, nil))); seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, i_1700000178__15 = seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1700000178__15); continue L2 } else { var temp__1927000414__auto____16 any; var root_1000 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = seq_1700000175__12; if linked_1001 == nil { temp__1927000414__auto____16 = ifn_1002.Invoke_O__O(arg_1003) } else { temp__1927000414__auto____16 = linked_1001.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1000, arg_1003) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1700000175__17 any = temp__1927000414__auto____16; var tmp4 any; var root_1004 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = seq_1700000175__17; if linked_1005 == nil { tmp4 = ifn_1006.Invoke_O__O(arg_1007) } else { tmp4 = linked_1005.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1004, arg_1007) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_1008 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = seq_1700000175__17; if linked_1009 == nil { c__1927000678__auto____18 = ifn_1010.Invoke_O__O(arg_1011) } else { c__1927000678__auto____18 = linked_1009.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1008, arg_1011) }; var tmp5 any; var root_1016 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = seq_1700000175__17; if linked_1017 == nil { tmp5 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp5 = linked_1017.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1016, arg_1019) }; seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, i_1700000178__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var l__18 any; var root_1012 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = seq_1700000175__17; if linked_1013 == nil { l__18 = ifn_1014.Invoke_O__O(arg_1015) } else { l__18 = linked_1013.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1012, arg_1015) }; jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__18, nil))); var tmp6 any; var root_1020 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = seq_1700000175__17; if linked_1021 == nil { tmp6 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp6 = linked_1021.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1020, arg_1023) }; seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, i_1700000178__15 = tmp6, nil, 0, 0; continue L2 } } }
//line :314:1
				break L2 }; seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, i_1700000172__6 = seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1700000172__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_958 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = seq_1700000169__3; if linked_959 == nil { temp__1927000414__auto____7 = ifn_960.Invoke_O__O(arg_961) } else { temp__1927000414__auto____7 = linked_959.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_958, arg_961) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1700000169__8 any = temp__1927000414__auto____7; var tmp7 any; var root_962 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = seq_1700000169__8; if linked_963 == nil { tmp7 = ifn_964.Invoke_O__O(arg_965) } else { tmp7 = linked_963.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_962, arg_965) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_966 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = seq_1700000169__8; if linked_967 == nil { c__1927000678__auto____9 = ifn_968.Invoke_O__O(arg_969) } else { c__1927000678__auto____9 = linked_967.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_966, arg_969) }; var tmp8 any; var root_1024 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = seq_1700000169__8; if linked_1025 == nil { tmp8 = ifn_1026.Invoke_O__O(arg_1027) } else { tmp8 = linked_1025.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1024, arg_1027) }; seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, i_1700000172__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var map__1700000179__9 any; var root_970 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = seq_1700000169__8; if linked_971 == nil { map__1700000179__9 = ifn_972.Invoke_O__O(arg_973) } else { map__1700000179__9 = linked_971.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_970, arg_973) }; var map__1700000179__10 any; if lang.ISeq_InstanceOf(map__1700000179__9) { var tmp9 any; var root_974 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = map__1700000179__9; if linked_975 == nil { tmp9 = ifn_976.Invoke_O__O(arg_977) } else { tmp9 = linked_975.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_974, arg_977) }; if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_978 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = map__1700000179__9; if linked_979 == nil { tmp10 = ifn_980.Invoke_O__O(arg_981) } else { tmp10 = linked_979.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_978, arg_981) }; map__1700000179__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp10)).Ref() } else { var tmp11 any; var root_982 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = map__1700000179__9; if linked_983 == nil { tmp11 = ifn_984.Invoke_O__O(arg_985) } else { tmp11 = linked_983.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_982, arg_985) }; if jrt.J2g_Truth(tmp11) { var root_986 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = map__1700000179__9; if linked_987 == nil { map__1700000179__10 = ifn_988.Invoke_O__O(arg_989) } else { map__1700000179__10 = linked_987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_986, arg_989) } } else { map__1700000179__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1700000179__10 = map__1700000179__9 }; var at__11 any = lang.RT_Get_O_O__O_NoInit(map__1700000179__10, A_arbace_repr_clojure_rules_A_const_89); var length__12 any = lang.RT_Get_O_O__O_NoInit(map__1700000179__10, A_arbace_repr_clojure_rules_A_const_90); var text__13 any = lang.RT_Get_O_O__O_NoInit(map__1700000179__10, A_arbace_repr_clojure_rules_A_const_91)
					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_5, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, at__11, nil, length__12, nil)))
//line :314:1
					var seq_1700000181__14 any; var root_1028 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1030 lang.IFn

					if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any; var root_1032 any = A_arbace_repr_clojure_rules_A_const_92.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = text__13; var arg_1036 any = A_arbace_repr_clojure_rules_A_const_93; var arg_1037 any = A_arbace_repr_clojure_rules_A_const_94; if linked_1033 == nil { arg_1031 = ifn_1034.Invoke_O_O_O__O(arg_1035, arg_1036, arg_1037) } else { arg_1031 = linked_1033.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_1032, arg_1035, arg_1036, arg_1037) }; if linked_1029 == nil { seq_1700000181__14 = ifn_1030.Invoke_O__O(arg_1031) } else { seq_1700000181__14 = linked_1029.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1028, arg_1031) }
//line :314:1
					var chunk_1700000182__15 any; var count_1700000183__16 int64 = 0; var i_1700000184__17 int64 = 0; L3: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1700000184__17, count_1700000183__16) { var l__18_2 any = lang.Indexed_Cast(chunk_1700000182__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1700000184__17)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__18_2, nil))); seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, i_1700000184__17 = seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1700000184__17); continue L3 } else { var temp__1927000414__auto____18 any; var root_1038 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = seq_1700000181__14; if linked_1039 == nil { temp__1927000414__auto____18 = ifn_1040.Invoke_O__O(arg_1041) } else { temp__1927000414__auto____18 = linked_1039.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1038, arg_1041) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1700000181__19 any = temp__1927000414__auto____18; var tmp12 any; var root_1042 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = seq_1700000181__19; if linked_1043 == nil { tmp12 = ifn_1044.Invoke_O__O(arg_1045) } else { tmp12 = linked_1043.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1042, arg_1045) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____20 any; var root_1046 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = seq_1700000181__19; if linked_1047 == nil { c__1927000678__auto____20 = ifn_1048.Invoke_O__O(arg_1049) } else { c__1927000678__auto____20 = linked_1047.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1046, arg_1049) }; var tmp13 any; var root_1054 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = seq_1700000181__19; if linked_1055 == nil { tmp13 = ifn_1056.Invoke_O__O(arg_1057) } else { tmp13 = linked_1055.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1054, arg_1057) }; seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, i_1700000184__17 = tmp13, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var l__20 any; var root_1050 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = seq_1700000181__19; if linked_1051 == nil { l__20 = ifn_1052.Invoke_O__O(arg_1053) } else { l__20 = linked_1051.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1050, arg_1053) }; jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__20, nil))); var tmp14 any; var root_1058 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = seq_1700000181__19; if linked_1059 == nil { tmp14 = ifn_1060.Invoke_O__O(arg_1061) } else { tmp14 = linked_1059.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1058, arg_1061) }; seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, i_1700000184__17 = tmp14, nil, 0, 0; continue L3 } } }
//line :314:1
						break L3 }; var tmp15 any; var root_1062 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = seq_1700000169__8; if linked_1063 == nil { tmp15 = ifn_1064.Invoke_O__O(arg_1065) } else { tmp15 = linked_1063.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1062, arg_1065) }; seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, i_1700000172__6 = tmp15, nil, 0, 0; continue L1 } } }
//line :308:1
		break L1 }; var root_934 any =








	A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = sb__2; if linked_935 == nil { return ifn_936.Invoke_O__O(arg_937) } else { return linked_935.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_934, arg_937) } }

func A_arbace_repr_clojure_rules_full_split_A_New() *A_arbace_repr_clojure_rules_full_split_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_repr_clojure_rules_full_split_A) Ctor() {}
//line :319:1
func (t *A_arbace_repr_clojure_rules_full_split_A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(jrt.String_Cast(A_arbace_repr_clojure_rules_A_const_86.GetRawRoot__O())); if





	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return nil } else { var rest__3 any; var root_1066 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1068 lang.IFn
		if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = s__0; var arg_1070 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__2), int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_clojure_rules_A_const_86.GetRawRoot__O())))).Ref(); if linked_1067 == nil { rest__3 = ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { rest__3 = linked_1067.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) }
//line :325:1
		var bad__4 any; var fnbody__1077 any = A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_New(); var tmp1 *jrt.Class; var fncls__1076 *jrt.Class = A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_fn_class
		if fncls__1076 == nil { var fncls__1076d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_fn_class = fncls__1076d; tmp1 = fncls__1076d } else { tmp1 = fncls__1076 }; bad__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1077, tmp1, nil)
//line :325:1
		var ___5 any; var tmp2 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_22, rest__3); _ = ___5


		if or__1927000174__auto____5 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1078 any = A_arbace_repr_clojure_rules_A_const_96.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = rest__3; var arg_1082 any = Lit_19; if linked_1079 == nil { tmp2 = ifn_1080.Invoke_O_O__O(arg_1081, arg_1082) } else { tmp2 = linked_1079.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1078, arg_1081, arg_1082) } }; if jrt.J2g_Truth(tmp2) { ___5 = nil } else { ___5 = lang.IFn_Cast(bad__4).Invoke_O__O(Lit_23) }
//line :325:1
		var lines__6 any



		if lang.Util_Equiv_O_O__Z_NoInit(Lit_22, rest__3) { lines__6 = lang.PersistentVector_EMPTY.Ref() } else { var root_1083 any = A_arbace_repr_clojure_rules_A_const_92.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any; var root_1089 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = rest__3; var arg_1093 any = A_arbace_repr_clojure_rules_A_const_30; var arg_1094 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rest__3)))).Ref(); if linked_1090 == nil { arg_1086 = ifn_1091.Invoke_O_O_O__O(arg_1092, arg_1093, arg_1094) } else { arg_1086 = linked_1090.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1089, arg_1092, arg_1093, arg_1094) }; var arg_1087 any = A_arbace_repr_clojure_rules_A_const_97; var arg_1088 any = A_arbace_repr_clojure_rules_A_const_94; if linked_1084 == nil { lines__6 = ifn_1085.Invoke_O_O_O__O(arg_1086, arg_1087, arg_1088) } else { lines__6 = linked_1084.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_1083, arg_1086, arg_1087, arg_1088) } }
//line :325:1
		var recs__7 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__1155 any = A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_New_O_O(bad__4, lines__6); var tmp4 *jrt.Class
		var fncls__1154 /*line :325:1*/*jrt.Class = A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_fn_class




		if fncls__1154 == nil { var fncls__1154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__1155); A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_fn_class = fncls__1154d; tmp4 = fncls__1154d } else { tmp4 = fncls__1154 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1155, tmp4, nil); recs__7 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
//line :325:1
		var tmp5 any; var root_1156 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1158 lang.IFn













		if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = s__0; var arg_1160 any = A_arbace_repr_clojure_rules_A_const_30; var arg_1161 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1157 == nil { tmp5 = ifn_1158.Invoke_O_O_O__O(arg_1159, arg_1160, arg_1161) } else { tmp5 = linked_1157.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1156, arg_1159, arg_1160, arg_1161) }
//line :325:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp5, recs__7) } }
func A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_New() *A_arbace_repr_clojure_rules_full_split_bad__1700000189_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_bad__1700000189_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_repr_clojure_rules_full_split_bad__1700000189_A) Ctor() {}
//line :326:1
func (t *A_arbace_repr_clojure_rules_full_split_bad__1700000189_A) Invoke_O_O__O(self, p1__1700000186_SHARP___1 any) any { var tmp1 any; var root_1071 any = A_arbace_repr_clojure_rules_A_const_95.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1073 lang.IFn; if
																linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__1700000186_SHARP___1)).Ref(); var arg_1075 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1072 == nil { tmp1 = ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { tmp1 = linked_1072.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) }; /*line :326:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }



func A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_full_split_fn__1700000191_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_fn__1700000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :330:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_A) Ctor_O_O(c__bad, c__lines any) { t.F_bad = c__bad; t.F_lines = c__lines }
//line :330:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_A) Invoke_O__O(self any) any { { var ls__1 any; var t_ any = t.F_lines; t.F_lines = nil; ls__1 = t_; var out__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp1 any; var root_1095 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = ls__1; if linked_1096 == nil { tmp1 = ifn_1097.Invoke_O__O(arg_1098) } else { tmp1 = linked_1096.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1095, arg_1098) }; if jrt.J2g_Truth(tmp1) { return out__2 } else { var vec__1700000192__3 any = ls__1; var seq__1700000193__4 any; var root_1099 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1101 lang.IFn

		if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = vec__1700000192__3; if linked_1100 == nil { seq__1700000193__4 = ifn_1101.Invoke_O__O(arg_1102) } else { seq__1700000193__4 = linked_1100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1099, arg_1102) }
//line :331:1
		var first__1700000194__5 any; var root_1103 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1105 lang.IFn

		if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = seq__1700000193__4; if linked_1104 == nil { first__1700000194__5 = ifn_1105.Invoke_O__O(arg_1106) } else { first__1700000194__5 = linked_1104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1103, arg_1106) }
//line :331:1
		var seq__1700000193__6 any; var root_1107 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1109 lang.IFn

		if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = seq__1700000193__4; if linked_1108 == nil { seq__1700000193__6 = ifn_1109.Invoke_O__O(arg_1110) } else { seq__1700000193__6 = linked_1108.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1107, arg_1110) }
//line :331:1
		var h__7 any = first__1700000194__5; var more__8 any = seq__1700000193__6; var vec__1700000195__9 any; var or__1927000174__auto____9 any; var root_1111 any = A_arbace_repr_clojure_rules_A_const_98.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1113 lang.IFn


		if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = A_arbace_repr_clojure_rules_A_const_99; var arg_1115 any = h__7; if linked_1112 == nil { or__1927000174__auto____9 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { or__1927000174__auto____9 = linked_1112.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }; if jrt.J2g_Truth(or__1927000174__auto____9) { vec__1700000195__9 = or__1927000174__auto____9 } else { vec__1700000195__9 = lang.IFn_Cast(t.F_bad).Invoke_O__O(h__7) }
//line :331:1
		var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000195__9, lang.RT_IntCast_J__I_NoInit(0), nil); var a__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000195__9, lang.RT_IntCast_J__I_NoInit(1), nil); var n__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000195__9, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__1700000198__13 any; var root_1116 any = A_arbace_repr_clojure_rules_A_const_100.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_1118 lang.IFn; _ = ___10



		if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any; var fnbody__1127 any = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_New(); var tmp2 *jrt.Class; var fncls__1126 *jrt.Class = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_fn_class; if fncls__1126 == nil { var fncls__1126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_fn_class = fncls__1126d; tmp2 = fncls__1126d } else { tmp2 = fncls__1126 }; arg_1119 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1127, tmp2, nil); var arg_1120 any = more__8; if linked_1117 == nil { vec__1700000198__13 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { vec__1700000198__13 = linked_1117.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }
//line :331:1
		var body__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000198__13, lang.RT_IntCast_J__I_NoInit(0), nil); var more__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000198__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 any; var root_1128 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1130 lang.IFn




		if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = body__14; if linked_1129 == nil { tmp3 = ifn_1130.Invoke_O__O(arg_1131) } else { tmp3 = linked_1129.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1128, arg_1131) }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_bad).Invoke_O__O(h__7) }
		var tmp4 any; var root_1132 any = A_arbace_repr_clojure_rules_A_const_9.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = out__2; var arg_1136 any; var tmp5 any = A_arbace_repr_clojure_rules_A_const_89; var tmp6 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(a__11))).Ref(); var tmp7 any = A_arbace_repr_clojure_rules_A_const_90; var tmp8 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__12))).Ref(); var tmp9 any = A_arbace_repr_clojure_rules_A_const_91; var tmp10 any; var root_1137 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1139 lang.IFn
		if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = Lit_19; var arg_1141 any; var root_1142 any = A_arbace_repr_clojure_rules_A_const_36.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any; var fnbody__1153 any = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_New(); var tmp11 *jrt.Class; var fncls__1152 *jrt.Class = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_fn_class; if fncls__1152 == nil { var fncls__1152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_fn_class = fncls__1152d; tmp11 = fncls__1152d } else { tmp11 = fncls__1152 }; arg_1145 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1153, tmp11, nil); var arg_1146 any = body__14; if linked_1143 == nil { arg_1141 = ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { arg_1141 = linked_1143.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) }; if linked_1138 == nil { tmp10 = ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { tmp10 = linked_1138.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) }
//line :337:1
		arg_1136 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10)); if linked_1133 == nil { tmp4 = ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { tmp4 = linked_1133.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) }; ls__1, out__2 = more__15, tmp4; continue L1 } } }; /*line :330:1*/panic("j2g: unreachable") }




func A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_New() *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A) Ctor() {}
//line :335:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A) Invoke_O_O__O(self, p1__1700000187_SHARP___1 any) any { var root_1121 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = p1__1700000187_SHARP___1; var arg_1125 any = Lit_20; if linked_1122 == nil { return ifn_1123.Invoke_O_O__O(arg_1124, arg_1125) } else { return linked_1122.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1121, arg_1124, arg_1125) } }


func A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_New() *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A) Ctor() {}
//line :338:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A) Invoke_O_O__O(self, p1__1700000188_SHARP___1 any) any { var root_1147 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = p1__1700000188_SHARP___1; var arg_1151 any = A_arbace_repr_clojure_rules_A_const_101; if linked_1148 == nil { return ifn_1149.Invoke_O_O__O(arg_1150, arg_1151) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1147, arg_1150, arg_1151) } }


func A_arbace_repr_clojure_rules_full_QMARK__A_New() *A_arbace_repr_clojure_rules_full_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_QMARK__A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_repr_clojure_rules_full_QMARK__A) Ctor() {}
//line :341:1
func (t *A_arbace_repr_clojure_rules_full_QMARK__A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 any; var root_1162 any = A_arbace_repr_clojure_rules_A_const_102.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, A_arbace_repr_clojure_rules_full_split_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = s__0; if linked_1163 == nil { tmp1 = ifn_1164.Invoke_O__O(arg_1165) } else { tmp1 = linked_1163.(*A_arbace_repr_clojure_rules_full_split_A).Invoke_O_O__O(root_1162, arg_1165) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_repr_clojure_rules_full_ctx_QMARK__A_New() *A_arbace_repr_clojure_rules_full_ctx_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_ctx_QMARK__A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_repr_clojure_rules_full_ctx_QMARK__A) Ctor() {}
//line :346:1
func (t *A_arbace_repr_clojure_rules_full_ctx_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var and__1927000168__auto____2 any = A_arbace_repr_clojure_rules_A_const_103.Invoke_O__O(ctx__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_repr_clojure_rules_A_const_70; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0)); if and__1927000168__auto____3 { return A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_repr_clojure_rules_print_text_A_New() *A_arbace_repr_clojure_rules_print_text_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Ctor() {}
//line :348:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any { var temp__1927000408__auto____4 any; if







	jrt.J2g_Truth(A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__1)) { var root_1166 any = A_arbace_repr_clojure_rules_A_const_102.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, A_arbace_repr_clojure_rules_full_split_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = s__0; if linked_1167 == nil { temp__1927000408__auto____4 = ifn_1168.Invoke_O__O(arg_1169) } else { temp__1927000408__auto____4 = linked_1167.(*A_arbace_repr_clojure_rules_full_split_A).Invoke_O_O__O(root_1166, arg_1169) } } else { temp__1927000408__auto____4 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var vec__1700000209__5 any = temp__1927000408__auto____4; var body__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000209__5, lang.RT_IntCast_J__I_NoInit(0), nil); var recs__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000209__5, lang.RT_IntCast_J__I_NoInit(1), nil); var ctx__8 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_104.GetRawRoot__O()).Invoke_O_O_O_O_O__O(ctx__1, A_arbace_repr_clojure_rules_A_const_13, A_arbace_repr_clojure_rules_A_const_70, A_arbace_repr_clojure_rules_A_const_71, jrt.Boolean_TRUE.Ref()); var t__9 any; var root_1178 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1180 lang.IFn

		if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any; var fnbody__1185 any = A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_New_O(ctx__8); var tmp1 *jrt.Class; var fncls__1184 *jrt.Class = A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_fn_class; if fncls__1184 == nil { var fncls__1184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__1185); A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_fn_class = fncls__1184d; tmp1 = fncls__1184d } else { tmp1 = fncls__1184 }; arg_1181 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1185, tmp1, nil); var arg_1182 any = body__6; var arg_1183 any; var root_1186 any = A_arbace_repr_clojure_rules_A_const_106.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var root_1190 any = A_arbace_repr_clojure_rules_A_const_107.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = ctx__8; var arg_1194 any = skip__2; if linked_1191 == nil { arg_1189 = ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { arg_1189 = linked_1191.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) }; if linked_1187 == nil { arg_1183 = ifn_1188.Invoke_O__O(arg_1189) } else { arg_1183 = linked_1187.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_1186, arg_1189) }; if linked_1179 == nil { t__9 = ifn_1180.Invoke_O_O_O__O(arg_1181, arg_1182, arg_1183) } else { t__9 = linked_1179.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1178, arg_1181, arg_1182, arg_1183) }
		var root_1195 any = A_arbace_repr_clojure_rules_A_const_108.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = t__9; var arg_1199 any = recs__7; var arg_1200 any = A_arbace_repr_clojure_rules_A_const_73.Invoke_O_O__O(ctx__8, A_arbace_repr_clojure_rules_A_const_109); if linked_1196 == nil { return ifn_1197.Invoke_O_O_O__O(arg_1198, arg_1199, arg_1200) } else { return linked_1196.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A).Invoke_O_O_O_O__O(root_1195, arg_1198, arg_1199, arg_1200) } } else {
			var root_1201 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any; var fnbody__1208 any = A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_New_O(ctx__1); var tmp2 *jrt.Class; var fncls__1207 *jrt.Class = A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_fn_class; if fncls__1207 == nil { var fncls__1207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__1208); A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_fn_class = fncls__1207d; tmp2 = fncls__1207d } else { tmp2 = fncls__1207 }; arg_1204 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1208, tmp2, nil); var arg_1205 any = s__0; var arg_1206 any; var root_1209 any = A_arbace_repr_clojure_rules_A_const_106.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any; var root_1213 any = A_arbace_repr_clojure_rules_A_const_107.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = ctx__1; var arg_1217 any = skip__2; if linked_1214 == nil { arg_1212 = ifn_1215.Invoke_O_O__O(arg_1216, arg_1217) } else { arg_1212 = linked_1214.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_1213, arg_1216, arg_1217) }; if linked_1210 == nil { arg_1206 = ifn_1211.Invoke_O__O(arg_1212) } else { arg_1206 = linked_1210.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_1209, arg_1212) }; if linked_1202 == nil { return ifn_1203.Invoke_O_O_O__O(arg_1204, arg_1205, arg_1206) } else { return linked_1202.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1201, arg_1204, arg_1205, arg_1206) } } }
//line :348:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {





	var root_1218 any = A_arbace_repr_clojure_rules_A_const_110.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_repr_clojure_rules_print_text_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = s__0; var arg_1222 any = ctx__1; var arg_1223 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1219 == nil { return ifn_1220.Invoke_O_O_O__O(arg_1221, arg_1222, arg_1223) } else { return linked_1219.(*A_arbace_repr_clojure_rules_print_text_A).Invoke_O_O_O_O__O(root_1218, arg_1221, arg_1222, arg_1223)
	}
}

func A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_New_O(p0 any) *A_arbace_repr_clojure_rules_print_text_fn__1700000212_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_fn__1700000212_A{}; t.Ctor_O(p0); return t }
//line :358:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000212_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :358:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000212_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_105.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

func A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_New_O(p0 any) *A_arbace_repr_clojure_rules_print_text_fn__1700000214_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_fn__1700000214_A{}; t.Ctor_O(p0); return t }
//line :360:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000214_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :360:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000214_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_105.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

func A_arbace_repr_clojure_rules_translate_A_New() *A_arbace_repr_clojure_rules_translate_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_clojure_rules_translate_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any { var t__4 any; var root_1224 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1226 lang.IFn; if






	linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any; var fnbody__1231 any = A_arbace_repr_clojure_rules_translate_fn__1700000217_A_New_O(ctx__1); var tmp1 *jrt.Class; var fncls__1230 *jrt.Class = A_arbace_repr_clojure_rules_translate_fn__1700000217_A_fn_class; if fncls__1230 == nil { var fncls__1230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1231); A_arbace_repr_clojure_rules_translate_fn__1700000217_A_fn_class = fncls__1230d; tmp1 = fncls__1230d } else { tmp1 = fncls__1230 }; arg_1227 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1231, tmp1, nil); var arg_1228 any = s__0; var arg_1229 any; var root_1232 any = A_arbace_repr_clojure_rules_A_const_107.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = ctx__1; var arg_1236 any = skip__2; if linked_1233 == nil { arg_1229 = ifn_1234.Invoke_O_O__O(arg_1235, arg_1236) } else { arg_1229 = linked_1233.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_1232, arg_1235, arg_1236) }; if linked_1225 == nil { t__4 = ifn_1226.Invoke_O_O_O__O(arg_1227, arg_1228, arg_1229) } else { t__4 = linked_1225.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1224, arg_1227, arg_1228, arg_1229) }; var tmp2 any; var root_1237 any =
	A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any; var root_1241 any = A_arbace_repr_clojure_rules_A_const_112.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, A_arbace_repr_clojure_rules_full_ctx_QMARK__A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = ctx__1; if linked_1242 == nil { arg_1240 = ifn_1243.Invoke_O__O(arg_1244) } else { arg_1240 = linked_1242.(*A_arbace_repr_clojure_rules_full_ctx_QMARK__A).Invoke_O_O__O(root_1241, arg_1244) }; if linked_1238 == nil { tmp2 = ifn_1239.Invoke_O__O(arg_1240) } else { tmp2 = linked_1238.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1237, arg_1240) }; if jrt.J2g_Truth(tmp2) { return t__4 } else { var features__5 any = A_arbace_repr_clojure_rules_A_const_73.Invoke_O_O__O(ctx__1, A_arbace_repr_clojure_rules_A_const_117); var map__1700000219__6 any; var tmp3 any; var root_1245 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1247 lang.IFn



		if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = skip__2; var arg_1249 any = A_arbace_repr_clojure_rules_A_const_113; if linked_1246 == nil { tmp3 = ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { tmp3 = linked_1246.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) }; if jrt.J2g_Truth(tmp3) { map__1700000219__6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_91, s__0, A_arbace_repr_clojure_rules_A_const_114, lang.PersistentVector_EMPTY.Ref())) } else {

			var root_1250 any = A_arbace_repr_clojure_rules_A_const_115.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_record_conditionals_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = s__0; var arg_1254 any = features__5; if linked_1251 == nil { map__1700000219__6 = ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { map__1700000219__6 = linked_1251.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_record_conditionals_A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) } }
//line :370:1
		var map__1700000219__7 any

		if lang.ISeq_InstanceOf(map__1700000219__6) { var tmp4 any; var root_1255 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = map__1700000219__6; if linked_1256 == nil { tmp4 = ifn_1257.Invoke_O__O(arg_1258) } else { tmp4 = linked_1256.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1255, arg_1258) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1259 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = map__1700000219__6; if linked_1260 == nil { tmp5 = ifn_1261.Invoke_O__O(arg_1262) } else { tmp5 = linked_1260.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1259, arg_1262) }; map__1700000219__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp5)).Ref() } else { var tmp6 any; var root_1263 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = map__1700000219__6; if linked_1264 == nil { tmp6 = ifn_1265.Invoke_O__O(arg_1266) } else { tmp6 = linked_1264.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1263, arg_1266) }; if jrt.J2g_Truth(tmp6) { var root_1267 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = map__1700000219__6; if linked_1268 == nil { map__1700000219__7 = ifn_1269.Invoke_O__O(arg_1270) } else { map__1700000219__7 = linked_1268.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1267, arg_1270) } } else { map__1700000219__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1700000219__7 = map__1700000219__6 }
//line :370:1
		var resolved__8 any = lang.RT_Get_O_O__O_NoInit(map__1700000219__7, A_arbace_repr_clojure_rules_A_const_91); var recs__9 any = lang.RT_Get_O_O__O_NoInit(map__1700000219__7, A_arbace_repr_clojure_rules_A_const_114); var tmp7 any; var root_1275 any = A_arbace_repr_clojure_rules_A_const_108.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A_fn_class); var ifn_1277 lang.IFn






		if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = resolved__8; var arg_1279 any = recs__9; var arg_1280 any = features__5; if linked_1276 == nil { tmp7 = ifn_1277.Invoke_O_O_O__O(arg_1278, arg_1279, arg_1280) } else { tmp7 = linked_1276.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A).Invoke_O_O_O_O__O(root_1275, arg_1278, arg_1279, arg_1280) }; if lang.Util_Equiv_O_O__Z_NoInit(s__0, tmp7) { } else { var tmp8 any; var root_1281 any = A_arbace_repr_clojure_rules_A_const_95.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1283 lang.IFn
			if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = Lit_41; var arg_1285 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1282 == nil { tmp8 = ifn_1283.Invoke_O_O__O(arg_1284, arg_1285) } else { tmp8 = linked_1282.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1281, arg_1284, arg_1285) }
//line :377:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp8)))
		}
		var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp10 any; var root_1271 any = A_arbace_repr_clojure_rules_A_const_116.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, A_arbace_repr_clojure_rules_full_block_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = recs__9; if linked_1272 == nil { tmp10 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp10 = linked_1272.(*A_arbace_repr_clojure_rules_full_block_A).Invoke_O_O__O(root_1271, arg_1274) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, t__4, tmp10)).Ref() } }
//line :362:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {




	var root_1286 any = A_arbace_repr_clojure_rules_A_const_118.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, A_arbace_repr_clojure_rules_translate_A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any = s__0; var arg_1290 any = ctx__1; var arg_1291 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1287 == nil { return ifn_1288.Invoke_O_O_O__O(arg_1289, arg_1290, arg_1291) } else { return linked_1287.(*A_arbace_repr_clojure_rules_translate_A).Invoke_O_O_O_O__O(root_1286, arg_1289, arg_1290, arg_1291)
	} }
func A_arbace_repr_clojure_rules_translate_fn__1700000217_A_New_O(p0 any) *A_arbace_repr_clojure_rules_translate_fn__1700000217_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_fn__1700000217_A{}; t.Ctor_O(p0); return t }
//line :369:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000217_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :369:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000217_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_111.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }




























type A_arbace_repr_clojure_rules_A struct{ jrt.Object }

var A_arbace_repr_clojure_rules_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rules_A_const_0 *lang.Var

var A_arbace_repr_clojure_rules_A_const_1 any

var A_arbace_repr_clojure_rules_A_const_2 any

var A_arbace_repr_clojure_rules_A_const_3 any

var A_arbace_repr_clojure_rules_A_const_4 *lang.Var

var A_arbace_repr_clojure_rules_A_const_5 any

var A_arbace_repr_clojure_rules_A_const_6 *lang.Var

var A_arbace_repr_clojure_rules_A_const_7 *lang.Var

var A_arbace_repr_clojure_rules_A_const_8 *lang.Var

var A_arbace_repr_clojure_rules_A_const_9 *lang.Var

var A_arbace_repr_clojure_rules_A_const_10 any

var A_arbace_repr_clojure_rules_A_const_11 *lang.Var

var A_arbace_repr_clojure_rules_A_const_12 any

var A_arbace_repr_clojure_rules_A_const_13 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_14 *lang.Var

var A_arbace_repr_clojure_rules_A_const_15 *lang.Var

var A_arbace_repr_clojure_rules_A_const_16 *lang.Var

var A_arbace_repr_clojure_rules_A_const_17 *lang.Var

var A_arbace_repr_clojure_rules_A_const_18 any

var A_arbace_repr_clojure_rules_A_const_19 *lang.Var

var A_arbace_repr_clojure_rules_A_const_20 *lang.Var

var A_arbace_repr_clojure_rules_A_const_21 *lang.Var

var A_arbace_repr_clojure_rules_A_const_22 *lang.Var

var A_arbace_repr_clojure_rules_A_const_23 *lang.Var

var A_arbace_repr_clojure_rules_A_const_24 *lang.Var

var A_arbace_repr_clojure_rules_A_const_25 *lang.Var

var A_arbace_repr_clojure_rules_A_const_26 *lang.Var

var A_arbace_repr_clojure_rules_A_const_27 *lang.Var

var A_arbace_repr_clojure_rules_A_const_28 *lang.Var

var A_arbace_repr_clojure_rules_A_const_29 *lang.Var

var A_arbace_repr_clojure_rules_A_const_30 any

var A_arbace_repr_clojure_rules_A_const_31 *lang.Var

var A_arbace_repr_clojure_rules_A_const_32 *lang.Var

var A_arbace_repr_clojure_rules_A_const_33 *lang.Var

var A_arbace_repr_clojure_rules_A_const_34 *lang.Var

var A_arbace_repr_clojure_rules_A_const_35 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_36 *lang.Var

var A_arbace_repr_clojure_rules_A_const_37 *lang.Var

var A_arbace_repr_clojure_rules_A_const_38 *lang.Var

var A_arbace_repr_clojure_rules_A_const_39 *lang.Var

var A_arbace_repr_clojure_rules_A_const_40 any

var A_arbace_repr_clojure_rules_A_const_41 *lang.Var

var A_arbace_repr_clojure_rules_A_const_42 *lang.Var

var A_arbace_repr_clojure_rules_A_const_43 *lang.Var

var A_arbace_repr_clojure_rules_A_const_44 *lang.Var

var A_arbace_repr_clojure_rules_A_const_45 *lang.Var

var A_arbace_repr_clojure_rules_A_const_46 *lang.Var

var A_arbace_repr_clojure_rules_A_const_47 any

var A_arbace_repr_clojure_rules_A_const_48 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_49 *lang.Var

var A_arbace_repr_clojure_rules_A_const_50 *lang.Var

var A_arbace_repr_clojure_rules_A_const_51 *lang.Var

var A_arbace_repr_clojure_rules_A_const_52 *lang.Var

var A_arbace_repr_clojure_rules_A_const_53 *lang.Var

var A_arbace_repr_clojure_rules_A_const_54 *lang.Var

var A_arbace_repr_clojure_rules_A_const_55 *lang.Var

var A_arbace_repr_clojure_rules_A_const_56 *lang.Var

var A_arbace_repr_clojure_rules_A_const_57 *lang.Var

var A_arbace_repr_clojure_rules_A_const_58 *lang.Var

var A_arbace_repr_clojure_rules_A_const_59 *lang.Var

var A_arbace_repr_clojure_rules_A_const_60 *lang.Var

var A_arbace_repr_clojure_rules_A_const_61 any

var A_arbace_repr_clojure_rules_A_const_62 *lang.Var

var A_arbace_repr_clojure_rules_A_const_63 any

var A_arbace_repr_clojure_rules_A_const_64 *lang.Var

var A_arbace_repr_clojure_rules_A_const_65 *lang.Var

var A_arbace_repr_clojure_rules_A_const_66 any

var A_arbace_repr_clojure_rules_A_const_67 *lang.Var

var A_arbace_repr_clojure_rules_A_const_68 any

var A_arbace_repr_clojure_rules_A_const_69 *lang.Var

var A_arbace_repr_clojure_rules_A_const_70 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_72 *lang.Var

var A_arbace_repr_clojure_rules_A_const_73 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_74 *lang.Var

var A_arbace_repr_clojure_rules_A_const_75 *lang.Var

var A_arbace_repr_clojure_rules_A_const_76 *lang.Var

var A_arbace_repr_clojure_rules_A_const_77 *lang.Var

var A_arbace_repr_clojure_rules_A_const_78 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_79 *lang.Var

var A_arbace_repr_clojure_rules_A_const_80 *lang.Var

var A_arbace_repr_clojure_rules_A_const_81 *lang.Var

var A_arbace_repr_clojure_rules_A_const_82 *lang.Var

var A_arbace_repr_clojure_rules_A_const_83 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_84 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_85 *lang.Var

var A_arbace_repr_clojure_rules_A_const_86 *lang.Var

var A_arbace_repr_clojure_rules_A_const_87 *lang.Var

var A_arbace_repr_clojure_rules_A_const_88 *lang.Var

var A_arbace_repr_clojure_rules_A_const_89 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_90 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_91 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_92 *lang.Var

var A_arbace_repr_clojure_rules_A_const_93 any

var A_arbace_repr_clojure_rules_A_const_94 any

var A_arbace_repr_clojure_rules_A_const_95 *lang.Var

var A_arbace_repr_clojure_rules_A_const_96 *lang.Var

var A_arbace_repr_clojure_rules_A_const_97 any

var A_arbace_repr_clojure_rules_A_const_98 *lang.Var

var A_arbace_repr_clojure_rules_A_const_99 any

var A_arbace_repr_clojure_rules_A_const_100 *lang.Var

var A_arbace_repr_clojure_rules_A_const_101 any

var A_arbace_repr_clojure_rules_A_const_102 *lang.Var

var A_arbace_repr_clojure_rules_A_const_103 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_104 *lang.Var

var A_arbace_repr_clojure_rules_A_const_105 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_106 *lang.Var

var A_arbace_repr_clojure_rules_A_const_107 *lang.Var

var A_arbace_repr_clojure_rules_A_const_108 *lang.Var

var A_arbace_repr_clojure_rules_A_const_109 any

var A_arbace_repr_clojure_rules_A_const_110 *lang.Var

var A_arbace_repr_clojure_rules_A_const_111 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_112 *lang.Var

var A_arbace_repr_clojure_rules_A_const_113 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_114 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_115 *lang.Var

var A_arbace_repr_clojure_rules_A_const_116 *lang.Var

var A_arbace_repr_clojure_rules_A_const_117 any

var A_arbace_repr_clojure_rules_A_const_118 *lang.Var

var A_arbace_repr_clojure_rules_A_init jrt.ClassInit

func A_arbace_repr_clojure_rules_A_Init() { if !A_arbace_repr_clojure_rules_A_init.Done() { A_arbace_repr_clojure_rules_A_init.Run(A_arbace_repr_clojure_rules_A_clinit) } }

func A_arbace_repr_clojure_rules_A_clinit() { A_arbace_repr_clojure_rules_A_clinit_p0(); A_arbace_repr_clojure_rules_A_clinit_p1(); A_arbace_repr_clojure_rules_A_clinit_p2(); A_arbace_repr_clojure_rules_A_clinit_p3(); A_arbace_repr_clojure_rules_A_clinit_p4(); A_arbace_repr_clojure_rules_A_clinit_p5(); A_arbace_repr_clojure_rules_A_clinit_p6(); A_arbace_repr_clojure_rules_A_clinit_p7(); A_arbace_repr_clojure_rules_A_clinit_p8(); A_arbace_repr_clojure_rules_A_clinit_p9() }

func A_arbace_repr_clojure_rules_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rules_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 146); A_arbace_repr_clojure_rules_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[27]); A_arbace_repr_clojure_rules_A_const_1 = A_arbace_repr_clojure_rules_A_const_pool.A[28]; A_arbace_repr_clojure_rules_A_const_2 = A_arbace_repr_clojure_rules_A_const_pool.A[29]; A_arbace_repr_clojure_rules_A_const_3 = A_arbace_repr_clojure_rules_A_const_pool.A[30]; A_arbace_repr_clojure_rules_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[31]); A_arbace_repr_clojure_rules_A_const_5 = A_arbace_repr_clojure_rules_A_const_pool.A[32]; A_arbace_repr_clojure_rules_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[33]); A_arbace_repr_clojure_rules_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[34]); A_arbace_repr_clojure_rules_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[35]); A_arbace_repr_clojure_rules_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[36]); A_arbace_repr_clojure_rules_A_const_10 = A_arbace_repr_clojure_rules_A_const_pool.A[37]; A_arbace_repr_clojure_rules_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[38]) }

func A_arbace_repr_clojure_rules_A_clinit_p1() { A_arbace_repr_clojure_rules_A_const_12 = A_arbace_repr_clojure_rules_A_const_pool.A[39]; A_arbace_repr_clojure_rules_A_const_13 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[40]); A_arbace_repr_clojure_rules_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[41]); A_arbace_repr_clojure_rules_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[42]); A_arbace_repr_clojure_rules_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[43]); A_arbace_repr_clojure_rules_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[44]); A_arbace_repr_clojure_rules_A_const_18 = A_arbace_repr_clojure_rules_A_const_pool.A[45]; A_arbace_repr_clojure_rules_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[46]); A_arbace_repr_clojure_rules_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[47]); A_arbace_repr_clojure_rules_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[48]); A_arbace_repr_clojure_rules_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[49]); A_arbace_repr_clojure_rules_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[50]) }

func A_arbace_repr_clojure_rules_A_clinit_p2() { A_arbace_repr_clojure_rules_A_const_24 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[51]); A_arbace_repr_clojure_rules_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[52]); A_arbace_repr_clojure_rules_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[53]); A_arbace_repr_clojure_rules_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[54]); A_arbace_repr_clojure_rules_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[55]); A_arbace_repr_clojure_rules_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[56]); A_arbace_repr_clojure_rules_A_const_30 = A_arbace_repr_clojure_rules_A_const_pool.A[57]; A_arbace_repr_clojure_rules_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[58]); A_arbace_repr_clojure_rules_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[59]); A_arbace_repr_clojure_rules_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[60]); A_arbace_repr_clojure_rules_A_const_34 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[61]); A_arbace_repr_clojure_rules_A_const_35 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[62]) }

func A_arbace_repr_clojure_rules_A_clinit_p3() { A_arbace_repr_clojure_rules_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[63]); A_arbace_repr_clojure_rules_A_const_37 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[64]); A_arbace_repr_clojure_rules_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[65]); A_arbace_repr_clojure_rules_A_const_39 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[66]); A_arbace_repr_clojure_rules_A_const_40 = A_arbace_repr_clojure_rules_A_const_pool.A[67]; A_arbace_repr_clojure_rules_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[68]); A_arbace_repr_clojure_rules_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[69]); A_arbace_repr_clojure_rules_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[70]); A_arbace_repr_clojure_rules_A_const_44 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[71]); A_arbace_repr_clojure_rules_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[72]); A_arbace_repr_clojure_rules_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[73]); A_arbace_repr_clojure_rules_A_const_47 = A_arbace_repr_clojure_rules_A_const_pool.A[74] }

func A_arbace_repr_clojure_rules_A_clinit_p4() { A_arbace_repr_clojure_rules_A_const_48 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[75]); A_arbace_repr_clojure_rules_A_const_49 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[76]); A_arbace_repr_clojure_rules_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[77]); A_arbace_repr_clojure_rules_A_const_51 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[78]); A_arbace_repr_clojure_rules_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[79]); A_arbace_repr_clojure_rules_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[80]); A_arbace_repr_clojure_rules_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[81]); A_arbace_repr_clojure_rules_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[82]); A_arbace_repr_clojure_rules_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[83]); A_arbace_repr_clojure_rules_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[84]); A_arbace_repr_clojure_rules_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[85]); A_arbace_repr_clojure_rules_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[86]) }

func A_arbace_repr_clojure_rules_A_clinit_p5() { A_arbace_repr_clojure_rules_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[87]); A_arbace_repr_clojure_rules_A_const_61 = A_arbace_repr_clojure_rules_A_const_pool.A[88]; A_arbace_repr_clojure_rules_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[89]); A_arbace_repr_clojure_rules_A_const_63 = A_arbace_repr_clojure_rules_A_const_pool.A[90]; A_arbace_repr_clojure_rules_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[91]); A_arbace_repr_clojure_rules_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[92]); A_arbace_repr_clojure_rules_A_const_66 = A_arbace_repr_clojure_rules_A_const_pool.A[93]; A_arbace_repr_clojure_rules_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[94]); A_arbace_repr_clojure_rules_A_const_68 = A_arbace_repr_clojure_rules_A_const_pool.A[95]; A_arbace_repr_clojure_rules_A_const_69 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[96]); A_arbace_repr_clojure_rules_A_const_70 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[97]); A_arbace_repr_clojure_rules_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[98]); A_arbace_repr_clojure_rules_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[99]) }

func A_arbace_repr_clojure_rules_A_clinit_p6() { A_arbace_repr_clojure_rules_A_const_73 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[100]); A_arbace_repr_clojure_rules_A_const_74 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[101]); A_arbace_repr_clojure_rules_A_const_75 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[102]); A_arbace_repr_clojure_rules_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[103]); A_arbace_repr_clojure_rules_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[104]); A_arbace_repr_clojure_rules_A_const_78 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[105]); A_arbace_repr_clojure_rules_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[106]); A_arbace_repr_clojure_rules_A_const_80 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[107]); A_arbace_repr_clojure_rules_A_const_81 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[108]); A_arbace_repr_clojure_rules_A_const_82 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[109]); A_arbace_repr_clojure_rules_A_const_83 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[110]); A_arbace_repr_clojure_rules_A_const_84 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[111]) }

func A_arbace_repr_clojure_rules_A_clinit_p7() { A_arbace_repr_clojure_rules_A_const_85 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[112]); A_arbace_repr_clojure_rules_A_const_86 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[113]); A_arbace_repr_clojure_rules_A_const_87 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[114]); A_arbace_repr_clojure_rules_A_const_88 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[115]); A_arbace_repr_clojure_rules_A_const_89 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[116]); A_arbace_repr_clojure_rules_A_const_90 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[117]); A_arbace_repr_clojure_rules_A_const_91 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[118]); A_arbace_repr_clojure_rules_A_const_92 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[119]); A_arbace_repr_clojure_rules_A_const_93 = A_arbace_repr_clojure_rules_A_const_pool.A[120]; A_arbace_repr_clojure_rules_A_const_94 = A_arbace_repr_clojure_rules_A_const_pool.A[121]; A_arbace_repr_clojure_rules_A_const_95 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[122]); A_arbace_repr_clojure_rules_A_const_96 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[123]) }

func A_arbace_repr_clojure_rules_A_clinit_p8() { A_arbace_repr_clojure_rules_A_const_97 = A_arbace_repr_clojure_rules_A_const_pool.A[124]; A_arbace_repr_clojure_rules_A_const_98 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[125]); A_arbace_repr_clojure_rules_A_const_99 = A_arbace_repr_clojure_rules_A_const_pool.A[126]; A_arbace_repr_clojure_rules_A_const_100 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[127]); A_arbace_repr_clojure_rules_A_const_101 = A_arbace_repr_clojure_rules_A_const_pool.A[128]; A_arbace_repr_clojure_rules_A_const_102 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[129]); A_arbace_repr_clojure_rules_A_const_103 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[130]); A_arbace_repr_clojure_rules_A_const_104 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[131]); A_arbace_repr_clojure_rules_A_const_105 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[132]); A_arbace_repr_clojure_rules_A_const_106 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[133]); A_arbace_repr_clojure_rules_A_const_107 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[134]); A_arbace_repr_clojure_rules_A_const_108 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[135]); A_arbace_repr_clojure_rules_A_const_109 = A_arbace_repr_clojure_rules_A_const_pool.A[136] }

func A_arbace_repr_clojure_rules_A_clinit_p9() { A_arbace_repr_clojure_rules_A_const_110 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[137]); A_arbace_repr_clojure_rules_A_const_111 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[138]); A_arbace_repr_clojure_rules_A_const_112 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[139]); A_arbace_repr_clojure_rules_A_const_113 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[140]); A_arbace_repr_clojure_rules_A_const_114 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[141]); A_arbace_repr_clojure_rules_A_const_115 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[142]); A_arbace_repr_clojure_rules_A_const_116 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[143]); A_arbace_repr_clojure_rules_A_const_117 = A_arbace_repr_clojure_rules_A_const_pool.A[144]; A_arbace_repr_clojure_rules_A_const_118 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[145]) }

func A_arbace_repr_clojure_rules_A_New() *A_arbace_repr_clojure_rules_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_A_class }

func (t *A_arbace_repr_clojure_rules_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_A); return ok }

func A_arbace_repr_clojure_rules_A_Cast(x any) *A_arbace_repr_clojure_rules_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_A_class)) }; return v }



type A_arbace_repr_clojure_rules_applicable_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_applicable_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_applicable_fn__1700000166_A struct{ j2g_header uint64; F_ctx, F_skip any }

var A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_clojure_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_cut_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_cut_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_defined_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A struct{ j2g_header uint64; F_iter__1700000101, F_s, F_s__1700000102 any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A struct{ j2g_header uint64; F_b__1700000104, F_s any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000004_A_New() *A_arbace_repr_clojure_rules_eval1700000004_A { t := &A_arbace_repr_clojure_rules_eval1700000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000004_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000004_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000004_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000008_A_New() *A_arbace_repr_clojure_rules_eval1700000008_A { t := &A_arbace_repr_clojure_rules_eval1700000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000008_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000008_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000008_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000143_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000143_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000145_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000145_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000147_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000147_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000149_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000149_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000151_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000151_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000153_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000153_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000155_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000155_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000157_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000157_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000159_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000159_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000161_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000161_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000163_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000163_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_block_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_block_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_ctx_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_ctx_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_bad__1700000189_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_fn__1700000191_A struct{ j2g_header uint64; F_bad, F_lines any }

var A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_imports_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_insert_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_insert_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_print_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_fn__1700000212_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_fn__1700000214_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_security_manager_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A struct{ j2g_header uint64; F_sb, F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A struct{ j2g_header uint64; F_import_spans any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_translate_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_fn__1700000217_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_translate_fn__1700000217_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_uncore_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A struct{ j2g_header uint64; F_s, F_added any }

var A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unproxy_methods_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A struct{ j2g_header uint64; F_sb, F_s any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A struct{ j2g_header uint64; F_import_spans any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class *jrt.Class
