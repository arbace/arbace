//line aot_arbace_repr_clojure_rules.ae:1
package aot_arbace_repr_clojure_rules

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_clojure_rename"
	"arbace/aot_arbace_repr_clojure_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_New() *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_rules_A_const_1, A_arbace_repr_clojure_rules_A_const_2, A_arbace_repr_clojure_rules_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_New() *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_repr_clojure_rules_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_repr_clojure_rules_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_rules_A_const_9.GetRawRoot__O(), A_arbace_repr_clojure_rules_A_const_10) }





















func A_arbace_repr_clojure_rules_clojure_source_QMARK__A_New() *A_arbace_repr_clojure_rules_clojure_source_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_clojure_source_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var root_21 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_repr_clojure_rules_A_const_12; var arg_25 any = A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0); if linked_22 == nil { return ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { return linked_22.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_21, arg_24, arg_25) } }







func A_arbace_repr_clojure_rules_proxy_methods_A_New() *A_arbace_repr_clojure_rules_proxy_methods_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var root_26 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var tmp1 any = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New(); var tmp2 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; arg_29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_30 any = s__0; var arg_31 any = A_arbace_repr_clojure_rules_A_const_16.GetRawRoot__O(); if linked_27 == nil { return ifn_28.Invoke_O_O_O__O(arg_29, arg_30, arg_31) } else { return linked_27.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_26, arg_29, arg_30, arg_31) } }
//line :34:1
func A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New() *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Ctor() {}
//line :34:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Invoke_O_O_O__O(self, s__1, p__1700000013__2 any) any { var vec__1700000015__3 any = p__1700000013__2; var re__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_32 any = A_arbace_repr_clojure_rules_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = s__1; var arg_36 any = re__4; var arg_37 any = to__5; if linked_33 == nil { return ifn_34.Invoke_O_O_O__O(arg_35, arg_36, arg_37) } else { return linked_33.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_32, arg_35, arg_36, arg_37) } }





func A_arbace_repr_clojure_rules_unproxy_methods_A_New() *A_arbace_repr_clojure_rules_unproxy_methods_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unproxy_methods_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_A) Ctor() {}
//line :40:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var root_39 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var tmp1 any = A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_New(); var tmp2 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class = fncls__51d; tmp2 = fncls__51d } else { tmp2 = fncls__51 }; arg_42 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_43 any = s__0; var arg_44 any = A_arbace_repr_clojure_rules_A_const_17.GetRawRoot__O(); if linked_40 == nil { return ifn_41.Invoke_O_O_O__O(arg_42, arg_43, arg_44) } else { return linked_40.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_39, arg_42, arg_43, arg_44) } }
//line :43:1
func A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_New() *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A) Invoke_O_O_O__O(self, s__1, p__1700000020__2 any) any { var vec__1700000022__3 any = p__1700000020__2; var re__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000022__3, lang.RT_IntCast_J__I_NoInit(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000022__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_45 any = A_arbace_repr_clojure_rules_A_const_15.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = s__1; var arg_49 any = re__4; var arg_50 any = to__5; if linked_46 == nil { return ifn_47.Invoke_O_O_O__O(arg_48, arg_49, arg_50) } else { return linked_46.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_45, arg_48, arg_49, arg_50) } }





func A_arbace_repr_clojure_rules_imports_QMARK__A_New() *A_arbace_repr_clojure_rules_imports_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_imports_QMARK__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Ctor() {}
//line :49:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Invoke_O_O__O(self, head__0 any) any { var root_52 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = A_arbace_repr_clojure_rules_A_const_18; var arg_56 any = head__0; if linked_53 == nil { return ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { return linked_53.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_52, arg_55, arg_56) } }

func A_arbace_repr_clojure_rules_security_manager_A_New() *A_arbace_repr_clojure_rules_security_manager_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var root_57 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_61 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = s__0; var arg_65 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_62 == nil { arg_60 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { arg_60 = linked_62.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }; if linked_58 == nil { tmp1 = ifn_59.Invoke_O__O(arg_60) } else { tmp1 = linked_58.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_57, arg_60) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var import_spans__2 any; var root_66 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_68 lang.IFn

		if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = s__0; var arg_70 any = A_arbace_repr_clojure_rules_A_const_23.GetRawRoot__O(); if linked_67 == nil { import_spans__2 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { import_spans__2 = linked_67.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }
//line :55:1
		var in_import_QMARK___3 any; var tmp2 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_New_O(import_spans__2); var tmp3 *jrt.Class
		var fncls__87 /*line :55:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class


		if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :55:1
		var tokens__4 any; var root_88 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_90 lang.IFn



		if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any; var tmp4 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_New_O(s__0); var tmp5 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class = fncls__104d; tmp5 = fncls__104d } else { tmp5 = fncls__104 }; arg_91 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_92 any; var root_105 any = A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = s__0; if linked_106 == nil { arg_92 = ifn_107.Invoke_O__O(arg_108) } else { arg_92 = linked_106.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A).Invoke_O_O__O(root_105, arg_108) }; if linked_89 == nil { tokens__4 = ifn_90.Invoke_O_O__O(arg_91, arg_92) } else { tokens__4 = linked_89.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_88, arg_91, arg_92) }
//line :55:1
		var imported_QMARK___5 any; var root_109 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_111 lang.IFn




		if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp6 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_New_O_O(s__0, in_import_QMARK___3); var tmp7 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class = fncls__125d; tmp7 = fncls__125d } else { tmp7 = fncls__125 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_113 any = tokens__4; if linked_110 == nil { imported_QMARK___5 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { imported_QMARK___5 = linked_110.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }
//line :55:1
		var uses__6 any; var root_126 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_128 lang.IFn







		if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any; var tmp8 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_New_O_O(s__0, in_import_QMARK___3); var tmp9 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class = fncls__146d; tmp9 = fncls__146d } else { tmp9 = fncls__146 }; arg_129 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_130 any = tokens__4; if linked_127 == nil { uses__6 = ifn_128.Invoke_O_O__O(arg_129, arg_130) } else { uses__6 = linked_127.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_126, arg_129, arg_130)
		}



		var tmp10 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp10 = or__1927000174__auto____7 } else { var root_147 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = uses__6; if linked_148 == nil { tmp10 = ifn_149.Invoke_O__O(arg_150) } else { tmp10 = linked_148.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_147, arg_150) } }; if jrt.J2g_Truth(tmp10) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var root_151 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_153 lang.IFn


			if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var tmp11 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_New_O_O(sb__7, s__0); var tmp12 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class = fncls__157d; tmp12 = fncls__157d } else { tmp12 = fncls__157 }; arg_154 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_155 any = A_arbace_repr_clojure_rules_A_const_30; var arg_156 any = uses__6; if linked_152 == nil { end__8 = ifn_153.Invoke_O_O_O__O(arg_154, arg_155, arg_156) } else { end__8 = linked_152.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_151, arg_154, arg_155, arg_156)
			}



			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(end__8), lang.RT_Count_O__I_NoInit(s__0))
			var root_158 any = A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = sb__7; if linked_159 == nil { return ifn_160.Invoke_O__O(arg_161) } else { return linked_159.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_158, arg_161) } } } }
//line :58:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A) Invoke_O_O__O(self, i__1 any) any { var root_71 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var tmp1 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class = fncls__86d; tmp2 = fncls__86d } else { tmp2 = fncls__86 }; arg_74 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_75 any = t.F_import_spans; if linked_72 == nil { return ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { return linked_72.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_71, arg_74, arg_75) } }
//line :58:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A) Invoke_O_O__O(self, p__1700000029__1 any) any { var vec__1700000031__2 any = p__1700000029__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 bool; var na_76 any = a__3; var na_77 any = t.F_i; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_76); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_77) }; tmp1 = tmp2; if tmp1 { var n0_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); var n1_79 int64 = jrt.NN(jrt.Long_Cast(na_77)).LongValue__J(); and__1927000168__auto____5 = n0_78 <= n1_79 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_76); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_77) }; tmp3 = tmp4; if tmp3 { var n0_78_2 float64 = jrt.NN(jrt.Double_Cast(na_76)).DoubleValue__D(); var n1_79_2 float64 = jrt.NN(jrt.Double_Cast(na_77)).DoubleValue__D(); and__1927000168__auto____5 = n0_78_2 <= n1_79_2 } else { and__1927000168__auto____5 = lang.Numbers_Lte_O_O__Z_NoInit(na_76, na_77) } }; if and__1927000168__auto____5 { var tmp5 bool; var na_81 any = t.F_i; var na_82 any = b__4; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_81); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_82) }; tmp6 = tmp7; if tmp6 { var n0_83 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); var n1_84 int64 = jrt.NN(jrt.Long_Cast(na_82)).LongValue__J(); tmp5 = n0_83 < n1_84 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_81); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_82) }; tmp8 = tmp9; if tmp8 { var n0_83_2 float64 = jrt.NN(jrt.Double_Cast(na_81)).DoubleValue__D(); var n1_84_2 float64 = jrt.NN(jrt.Double_Cast(na_82)).DoubleValue__D(); tmp5 = n0_83_2 < n1_84_2 } else { tmp5 = lang.Numbers_Lt_O_O__Z_NoInit(na_81, na_82) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A{}; t.Ctor_O(p0); return t }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A) Invoke_O_O__O(self, p__1700000036__1 any) any { var vec__1700000038__2 any = p__1700000036__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_93 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any; var root_98 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = t.F_s; var arg_102 any = a__3; var arg_103 any = b__4; if linked_99 == nil { arg_96 = ifn_100.Invoke_O_O_O__O(arg_101, arg_102, arg_103) } else { arg_96 = linked_99.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_98, arg_101, arg_102, arg_103) }; var arg_97 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_94 == nil { return ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { return linked_94.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :60:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :60:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A) Invoke_O_O__O(self, p__1700000042__1 any) any { var vec__1700000044__2 any = p__1700000042__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000044__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000044__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.J2g_Truth(and__1927000168__auto____5) {
															var root_114 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())).Ref())); var arg_118 any; var root_119 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = t.F_s; var arg_123 any = a__3; var arg_124 any = b__4; if linked_120 == nil { arg_118 = ifn_121.Invoke_O_O_O__O(arg_122, arg_123, arg_124) } else { arg_118 = linked_120.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_119, arg_122, arg_123, arg_124) }; if linked_115 == nil { return ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { return linked_115.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_114, arg_117, arg_118) } } else {
//line :60:1
		return and__1927000168__auto____5 } }


func A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :63:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A) Invoke_O_O__O(self, p__1700000048__1 any) any { var vec__1700000050__2 any = p__1700000048__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t__5 any; var root_131 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_133 lang.IFn; if
															linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = t.F_s; var arg_135 any = a__3; var arg_136 any = b__4; if linked_132 == nil { t__5 = ifn_133.Invoke_O_O_O__O(arg_134, arg_135, arg_136) } else { t__5 = linked_132.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_131, arg_134, arg_135, arg_136) }; var and__1927000168__auto____6 any; var root_137 any = /*line :63:1*/A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_139 lang.IFn; if

	linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if linked_138 == nil { and__1927000168__auto____6 = ifn_139.Invoke_O__O(arg_140) } else { and__1927000168__auto____6 = linked_138.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_141 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = t__5; var arg_145 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), nil)).Ref(); if linked_142 == nil { return ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { return linked_142.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_141, arg_144, arg_145) } } } } else {
//line :65:1
			return and__1927000168__auto____6 } }





func A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :71:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :71:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A) Invoke_O_O_O__O(self, i__1, p__1700000054__2 any) any { var vec__1700000056__3 any = p__1700000054__2; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000056__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000056__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
																jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(i__1), lang.RT_IntCast_O__I_NoInit(a__4)); var tmp3 /*line :73:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp3).Append_String__StringBuilder(Lit_36); return a__4 }









func A_arbace_repr_clojure_rules_unqualify_security_manager_A_New() *A_arbace_repr_clojure_rules_unqualify_security_manager_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_A) Invoke_O_O__O(self, s__0 any) any {





	var tmp1 any; var root_162 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any; var root_166 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = s__0; var arg_170 any = A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(); if linked_167 == nil { arg_165 = ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { arg_165 = linked_167.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_166, arg_169, arg_170) }; if linked_163 == nil { tmp1 = ifn_164.Invoke_O__O(arg_165) } else { tmp1 = linked_163.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var import_spans__2 any; var root_171 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_173 lang.IFn

		if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = s__0; var arg_175 any = A_arbace_repr_clojure_rules_A_const_23.GetRawRoot__O(); if linked_172 == nil { import_spans__2 = ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { import_spans__2 = linked_172.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) }
//line :89:1
		var in_import_QMARK___3 any; var tmp2 any = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_New_O(import_spans__2); var tmp3 *jrt.Class
		var fncls__192 /*line :89:1*/*jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class


		if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class = fncls__192d; tmp3 = fncls__192d } else { tmp3 = fncls__192 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :89:1
		var tokens__4 any; var root_193 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_195 lang.IFn



		if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any; var tmp4 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_New_O(s__0); var tmp5 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class = fncls__209d; tmp5 = fncls__209d } else { tmp5 = fncls__209 }; arg_196 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_197 any; var root_210 any = A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = s__0; if linked_211 == nil { arg_197 = ifn_212.Invoke_O__O(arg_213) } else { arg_197 = linked_211.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A).Invoke_O_O__O(root_210, arg_213) }; if linked_194 == nil { tokens__4 = ifn_195.Invoke_O_O__O(arg_196, arg_197) } else { tokens__4 = linked_194.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_193, arg_196, arg_197) }
//line :89:1
		var imported_QMARK___5 any; var root_214 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_216 lang.IFn




		if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any; var tmp6 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_New_O_O(s__0, in_import_QMARK___3); var tmp7 *jrt.Class; var fncls__230 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class; if fncls__230 == nil { var fncls__230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class = fncls__230d; tmp7 = fncls__230d } else { tmp7 = fncls__230 }; arg_217 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_218 any = tokens__4; if linked_215 == nil { imported_QMARK___5 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { imported_QMARK___5 = linked_215.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }
//line :89:1
		var uses__6 any; var root_231 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_233 lang.IFn







		if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var tmp8 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_New_O_O(s__0, in_import_QMARK___3); var tmp9 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class = fncls__251d; tmp9 = fncls__251d } else { tmp9 = fncls__251 }; arg_234 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_235 any = tokens__4; if linked_232 == nil { uses__6 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { uses__6 = linked_232.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_231, arg_234, arg_235)
		}




		var tmp10 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp10 = or__1927000174__auto____7 } else { var root_252 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = uses__6; if linked_253 == nil { tmp10 = ifn_254.Invoke_O__O(arg_255) } else { tmp10 = linked_253.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_252, arg_255) } }; if jrt.J2g_Truth(tmp10) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var root_256 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_258 lang.IFn


			if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var tmp11 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_New_O_O(sb__7, s__0); var tmp12 *jrt.Class; var fncls__267 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class; if fncls__267 == nil { var fncls__267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class = fncls__267d; tmp12 = fncls__267d } else { tmp12 = fncls__267 }; arg_259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_260 any = A_arbace_repr_clojure_rules_A_const_30; var arg_261 any = uses__6; if linked_257 == nil { end__8 = ifn_258.Invoke_O_O_O__O(arg_259, arg_260, arg_261) } else { end__8 = linked_257.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_256, arg_259, arg_260, arg_261)
			}


			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(end__8), lang.RT_Count_O__I_NoInit(s__0))
			var root_268 any = A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = sb__7; if linked_269 == nil { return ifn_270.Invoke_O__O(arg_271) } else { return linked_269.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_268, arg_271) } } } }
//line :92:1
func A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A) Invoke_O_O__O(self, i__1 any) any { var root_176 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any; var tmp1 any = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class = fncls__191d; tmp2 = fncls__191d } else { tmp2 = fncls__191 }; arg_179 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_180 any = t.F_import_spans; if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) } }
//line :92:1
func A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A) Invoke_O_O__O(self, p__1700000062__1 any) any { var vec__1700000064__2 any = p__1700000062__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000064__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000064__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 bool; var na_181 any = a__3; var na_182 any = t.F_i; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_181); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_182) }; tmp1 = tmp2; if tmp1 { var n0_183 int64 = jrt.NN(jrt.Long_Cast(na_181)).LongValue__J(); var n1_184 int64 = jrt.NN(jrt.Long_Cast(na_182)).LongValue__J(); and__1927000168__auto____5 = n0_183 <= n1_184 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_181); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_182) }; tmp3 = tmp4; if tmp3 { var n0_183_2 float64 = jrt.NN(jrt.Double_Cast(na_181)).DoubleValue__D(); var n1_184_2 float64 = jrt.NN(jrt.Double_Cast(na_182)).DoubleValue__D(); and__1927000168__auto____5 = n0_183_2 <= n1_184_2 } else { and__1927000168__auto____5 = lang.Numbers_Lte_O_O__Z_NoInit(na_181, na_182) } }; if and__1927000168__auto____5 { var tmp5 bool; var na_186 any = t.F_i; var na_187 any = b__4; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_186); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_187) }; tmp6 = tmp7; if tmp6 { var n0_188 int64 = jrt.NN(jrt.Long_Cast(na_186)).LongValue__J(); var n1_189 int64 = jrt.NN(jrt.Long_Cast(na_187)).LongValue__J(); tmp5 = n0_188 < n1_189 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_186); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_187) }; tmp8 = tmp9; if tmp8 { var n0_188_2 float64 = jrt.NN(jrt.Double_Cast(na_186)).DoubleValue__D(); var n1_189_2 float64 = jrt.NN(jrt.Double_Cast(na_187)).DoubleValue__D(); tmp5 = n0_188_2 < n1_189_2 } else { tmp5 = lang.Numbers_Lt_O_O__Z_NoInit(na_186, na_187) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :93:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A) Invoke_O_O__O(self, p__1700000069__1 any) any { var vec__1700000071__2 any = p__1700000069__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000071__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000071__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_198 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any; var root_203 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = t.F_s; var arg_207 any = a__3; var arg_208 any = b__4; if linked_204 == nil { arg_201 = ifn_205.Invoke_O_O_O__O(arg_206, arg_207, arg_208) } else { arg_201 = linked_204.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_203, arg_206, arg_207, arg_208) }; var arg_202 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_199 == nil { return ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { return linked_199.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_198, arg_201, arg_202) } }
func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :94:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A) Invoke_O_O__O(self, p__1700000075__1 any) any { var vec__1700000077__2 any = p__1700000075__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000077__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000077__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.J2g_Truth(and__1927000168__auto____5) {
																var root_219 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())); var arg_223 any; var root_224 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = t.F_s; var arg_228 any = a__3; var arg_229 any = b__4; if linked_225 == nil { arg_223 = ifn_226.Invoke_O_O_O__O(arg_227, arg_228, arg_229) } else { arg_223 = linked_225.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_224, arg_227, arg_228, arg_229) }; if linked_220 == nil { return ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { return linked_220.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_219, arg_222, arg_223) } } else {
//line :94:1
		return and__1927000168__auto____5 } }


func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A{}; t.Ctor_O_O(p0, p1); return t }
//line :97:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :97:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A) Invoke_O_O__O(self, p__1700000081__1 any) any { var vec__1700000083__2 any = p__1700000081__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t__5 any; var root_236 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_238 lang.IFn; if
																linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = t.F_s; var arg_240 any = a__3; var arg_241 any = b__4; if linked_237 == nil { t__5 = ifn_238.Invoke_O_O_O__O(arg_239, arg_240, arg_241) } else { t__5 = linked_237.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_236, arg_239, arg_240, arg_241) }; var and__1927000168__auto____6 any; var root_242 any = /*line :97:1*/A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_244 lang.IFn; if

	linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if linked_243 == nil { and__1927000168__auto____6 = ifn_244.Invoke_O__O(arg_245) } else { and__1927000168__auto____6 = linked_243.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_242, arg_245) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else {
			var root_246 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = t__5; var arg_250 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), nil)).Ref(); if linked_247 == nil { return ifn_248.Invoke_O_O__O(arg_249, arg_250) } else { return linked_247.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_246, arg_249, arg_250) } } } } else {
//line :99:1
				return and__1927000168__auto____6 } }






func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :106:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :106:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A) Invoke_O_O_O__O(self, i__1, p__1700000087__2 any) any { var vec__1700000089__3 any = p__1700000087__2; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000089__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000089__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
																	jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(i__1), lang.RT_IntCast_O__I_NoInit(a__4)); var na_262 any = a__4; var na_263 int64 =
																	int64(lang.RT_Count_O__I_NoInit(Lit_36)); if jrt.Long_InstanceOf(na_262) { var n0_264 int64 = jrt.NN(jrt.Long_Cast(na_262)).LongValue__J(); var n1_265 int64 = na_263; var nr_266 int64 = n0_264 + n1_265; if (n0_264^nr_266)&(n1_265^nr_266) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_266).Ref() } else { return lang.Numbers_Add_O_J__Number_NoInit(na_262, na_263) } } else { return lang.Numbers_Add_O_J__Number_NoInit(na_262, na_263) } }






func A_arbace_repr_clojure_rules_arbace_core_names_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Invoke_O__O(self any) any {



	var root_272 any = A_arbace_repr_clojure_rules_A_const_33.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_276 any; var root_278 any = A_arbace_repr_clojure_rules_A_const_34.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_283 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var tmp1 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_New(); var tmp2 *jrt.Class; var fncls__287 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class; if fncls__287 == nil { var fncls__287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class = fncls__287d; tmp2 = fncls__287d } else { tmp2 = fncls__287 }; arg_286 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_284 == nil { arg_281 = ifn_285.Invoke_O__O(arg_286) } else { arg_281 = linked_284.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_283, arg_286) }; var arg_282 any; var root_288 any = A_arbace_repr_clojure_rules_A_const_36.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any; var tmp3 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_New(); var tmp4 *jrt.Class; var fncls__296 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class; if fncls__296 == nil { var fncls__296d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class = fncls__296d; tmp4 = fncls__296d } else { tmp4 = fncls__296 }; arg_291 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_289 == nil { arg_282 = ifn_290.Invoke_O__O(arg_291) } else { arg_282 = linked_289.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_288, arg_291) }; if linked_279 == nil { arg_276 = ifn_280.Invoke_O_O__O(arg_281, arg_282) } else { arg_276 = linked_279.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_278, arg_281, arg_282) }; var arg_277 any; var root_297 any = A_arbace_repr_clojure_rules_A_const_38.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_299 lang.IFn
	if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any; var root_301 any = A_arbace_repr_clojure_rules_A_const_39.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = A_arbace_repr_clojure_rules_A_const_40; if linked_302 == nil { arg_300 = ifn_303.Invoke_O__O(arg_304) } else { arg_300 = linked_302.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_301, arg_304) }; if linked_298 == nil { arg_277 = ifn_299.Invoke_O__O(arg_300) } else { arg_277 = linked_298.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_297, arg_300) }
//line :119:1
	if linked_273 == nil { return ifn_274.Invoke_O_O_O__O(arg_275, arg_276, arg_277) } else { return linked_273.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_272, arg_275, arg_276, arg_277) } }
//line :119:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A) Invoke_O_O__O(self, p1__1700000094_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_clojure_rules_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1700000094_SHARP___1)))).Ref() }
//line :119:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A) Invoke_O_O__O(self, p1__1700000095_SHARP___1 any) any { var root_292 any = A_arbace_repr_clojure_rules_A_const_37.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = lang.Var_Cast(p1__1700000095_SHARP___1).F_sym.Ref(); if linked_293 == nil { return ifn_294.Invoke_O__O(arg_295) } else { return linked_293.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_292, arg_295) } }






func A_arbace_repr_clojure_rules_defined_names_A_New() *A_arbace_repr_clojure_rules_defined_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Invoke_O_O__O(self, s__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_New_O(s__0); var tmp2 *jrt.Class; var fncls__517 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class; if


	fncls__517 == nil { var fncls__517d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class = fncls__517d; tmp2 = fncls__517d } else { tmp2 = fncls__517 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_518 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = s__0; var arg_522 any = A_arbace_repr_clojure_rules_A_const_57.GetRawRoot__O(); if linked_519 == nil { tmp4 = ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { tmp4 = linked_519.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }; return tmp3.Invoke_O__O(tmp4) }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_New_O(p0 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A) Invoke_O_O__O(self, s__1700000102__1 any) any { var tmp1 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_New_O_O_O(self, t.F_s, s__1700000102__1); var tmp2 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class = fncls__516d; tmp2 = fncls__516d } else { tmp2 = fncls__516 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A) Ctor_O_O_O(c__iter__1700000101, c__s, c__s__1700000102 any) { t.F_iter__1700000101 = c__iter__1700000101; t.F_s = c__s; t.F_s__1700000102 = c__s__1700000102 }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A) Invoke_O__O(self any) any { { var s__1700000102__1 any; var t_ any = t.F_s__1700000102; t.F_s__1700000102 = nil; s__1700000102__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_305 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = s__1700000102__1; if linked_306 == nil { temp__1927000414__auto____2 = ifn_307.Invoke_O__O(arg_308) } else { temp__1927000414__auto____2 = linked_306.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_305, arg_308) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1700000102__3 any = temp__1927000414__auto____2; var tmp1 any; var root_309 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__1700000102__3; if linked_310 == nil { tmp1 = ifn_311.Invoke_O__O(arg_312) } else { tmp1 = linked_310.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_309, arg_312) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_313 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = s__1700000102__3; if linked_314 == nil { c__1927001037__auto____4 = ifn_315.Invoke_O__O(arg_316) } else { c__1927001037__auto____4 = linked_314.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_313, arg_316) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1700000104__6 any; var root_317 any = A_arbace_repr_clojure_rules_A_const_44.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_318 == nil { b__1700000104__6 = ifn_319.Invoke_O__O(arg_320) } else { b__1700000104__6 = linked_318.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_317, arg_320) }; var tmp2 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_New_O_O_I_O(b__1700000104__6, t.F_s, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__401 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class; if fncls__401 == nil { var fncls__401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class = fncls__401d; tmp3 = fncls__401d } else { tmp3 = fncls__401 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_402 any = A_arbace_repr_clojure_rules_A_const_51.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_407 any = A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = b__1700000104__6; if linked_408 == nil { arg_405 = ifn_409.Invoke_O__O(arg_410) } else { arg_405 = linked_408.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_407, arg_410) }; var arg_406 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1700000101); var tmp5 any; var root_411 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = s__1700000102__3; if linked_412 == nil { tmp5 = ifn_413.Invoke_O__O(arg_414) } else { tmp5 = linked_412.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_411, arg_414) }; arg_406 = tmp4.Invoke_O__O(tmp5); if linked_403 == nil { return ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { return linked_403.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) } } else { var root_415 any = A_arbace_repr_clojure_rules_A_const_51.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var root_420 any = A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = b__1700000104__6; if linked_421 == nil { arg_418 = ifn_422.Invoke_O__O(arg_423) } else { arg_418 = linked_421.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_420, arg_423) }; var arg_419 any; if linked_416 == nil { return ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { return linked_416.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) } } } else { var vec__1700000114__4 any; var root_424 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = s__1700000102__3; if linked_425 == nil { vec__1700000114__4 = ifn_426.Invoke_O__O(arg_427) } else { vec__1700000114__4 = linked_425.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_424, arg_427) }; var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000114__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000114__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any; var root_428 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_430 lang.IFn; _ = ___6
																if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = t.F_s; var arg_432 any; var na_433 any = a__5; if jrt.Long_InstanceOf(na_433) { var n0_434 int64 = jrt.NN(jrt.Long_Cast(na_433)).LongValue__J(); if n0_434 == 9223372036854775807 { arg_432 = lang.Numbers_Inc_O__Number_NoInit(na_433) } else { arg_432 = jrt.Long_ValueOf_J__Long_NoInit(n0_434 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_433) { var n0_434_2 float64 = jrt.NN(jrt.Double_Cast(na_433)).DoubleValue__D(); arg_432 = jrt.Double_ValueOf_D__Double_NoInit(n0_434_2 + 1.0).Ref() } else { arg_432 = lang.Numbers_Inc_O__Number_NoInit(na_433) } }; if linked_429 == nil { h__7 = ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { h__7 = linked_429.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) }
//line :129:1
	var j__8 any; var tmp6 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_New_O_O(h__7, t.F_s); var tmp7 *jrt.Class
	var fncls__487 /*line :129:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class

	if fncls__487 == nil { var fncls__487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class = fncls__487d; tmp7 = fncls__487d } else { tmp7 = fncls__487 }; j__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :129:1
	var t__9 any; var root_488 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_490 lang.IFn









	if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = t.F_s; var arg_492 any = j__8; var arg_493 any; var root_494 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = t.F_s; var arg_498 any = j__8; if linked_495 == nil { arg_493 = ifn_496.Invoke_O_O__O(arg_497, arg_498) } else { arg_493 = linked_495.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_494, arg_497, arg_498) }; if linked_489 == nil { t__9 = ifn_490.Invoke_O_O_O__O(arg_491, arg_492, arg_493) } else { t__9 = linked_489.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_488, arg_491, arg_492, arg_493) }
//line :129:1
	var tmp8 any; var root_499 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_501 lang.IFn










	if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = t__9; if linked_500 == nil { tmp8 = ifn_501.Invoke_O__O(arg_502) } else { tmp8 = linked_500.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_499, arg_502) }
//line :129:1
	if jrt.J2g_Truth(tmp8) { var root_503 any = A_arbace_repr_clojure_rules_A_const_55.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = t__9; var arg_507 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1700000101); var tmp10 any; var root_508 any = A_arbace_repr_clojure_rules_A_const_56.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = s__1700000102__3; if linked_509 == nil { tmp10 = ifn_510.Invoke_O__O(arg_511) } else { tmp10 = linked_509.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_508, arg_511) }; arg_507 = tmp9.Invoke_O__O(tmp10); if linked_504 == nil { return ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { return linked_504.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_503, arg_506, arg_507) } } else { var tmp11 any; var root_512 any = A_arbace_repr_clojure_rules_A_const_56.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = s__1700000102__3; if linked_513 == nil { tmp11 = ifn_514.Invoke_O__O(arg_515) } else { tmp11 = linked_513.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_512, arg_515) }; s__1700000102__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A) Ctor_O_O_I_O(c__b__1700000104, c__s any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1700000104 = c__b__1700000104; t.F_s = c__s; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A) Invoke_O__O(self any) any { { var i__1700000103__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1700000103__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1700000108__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1700000103__1)); var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000108__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000108__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any; var root_321 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_323 lang.IFn; _ = ___4
																		if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = t.F_s; var arg_325 any; var na_326 any = a__3; if jrt.Long_InstanceOf(na_326) { var n0_327 int64 = jrt.NN(jrt.Long_Cast(na_326)).LongValue__J(); if n0_327 == 9223372036854775807 { arg_325 = lang.Numbers_Inc_O__Number_NoInit(na_326) } else { arg_325 = jrt.Long_ValueOf_J__Long_NoInit(n0_327 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_326) { var n0_327_2 float64 = jrt.NN(jrt.Double_Cast(na_326)).DoubleValue__D(); arg_325 = jrt.Double_ValueOf_D__Double_NoInit(n0_327_2 + 1.0).Ref() } else { arg_325 = lang.Numbers_Inc_O__Number_NoInit(na_326) } }; if linked_322 == nil { h__5 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { h__5 = linked_322.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }
//line :129:1
	var j__6 any; var tmp2 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_New_O_O(h__5, t.F_s); var tmp3 *jrt.Class
	var fncls__380 /*line :129:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class

	if fncls__380 == nil { var fncls__380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class = fncls__380d; tmp3 = fncls__380d } else { tmp3 = fncls__380 }; j__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :129:1
	var t__7 any; var root_381 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_383 lang.IFn









	if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = t.F_s; var arg_385 any = j__6; var arg_386 any; var root_387 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = t.F_s; var arg_391 any = j__6; if linked_388 == nil { arg_386 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { arg_386 = linked_388.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if linked_382 == nil { t__7 = ifn_383.Invoke_O_O_O__O(arg_384, arg_385, arg_386) } else { t__7 = linked_382.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_381, arg_384, arg_385, arg_386) }
//line :129:1
	var tmp4 any; var root_392 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_394 lang.IFn










	if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = t__7; if linked_393 == nil { tmp4 = ifn_394.Invoke_O__O(arg_395) } else { tmp4 = linked_393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_392, arg_395) }
//line :129:1
	if jrt.J2g_Truth(tmp4) { var root_396 any = A_arbace_repr_clojure_rules_A_const_50.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = t.F_b__1700000104; var arg_400 any = t__7; if linked_397 == nil { ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { linked_397.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) }; i__1700000103__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000103__1); continue L1 } else { i__1700000103__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000103__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A) Invoke_O__O(self any) any { { var j__1 any; var root_328 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = t.F_s; var arg_332 any; var root_333 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = t.F_s; var arg_337 any; var t_ any = t.F_h; t.F_h = nil; arg_337 = t_; if linked_334 == nil { arg_332 = ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { arg_332 = linked_334.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) }; if linked_329 == nil { j__1 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { j__1 = linked_329.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; L1: for {

	var tmp1 bool; var na_338 any = j__1; var na_339 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_338) { var n0_340 int64 = jrt.NN(jrt.Long_Cast(na_338)).LongValue__J(); var n1_341 int64 = na_339; tmp1 = n0_340 >= n1_341 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_338, na_339) }; if tmp1 { return j__1 } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_47)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp3 any; var root_343 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = t.F_s; var arg_347 any; var root_348 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_348, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = t.F_s; var arg_352 any; var root_353 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = t.F_s; var arg_357 any; var na_358 any = j__1; if jrt.Long_InstanceOf(na_358) { var n0_359 int64 = jrt.NN(jrt.Long_Cast(na_358)).LongValue__J(); if n0_359 == 9223372036854775807 { arg_357 = lang.Numbers_Inc_O__Number_NoInit(na_358) } else { arg_357 = jrt.Long_ValueOf_J__Long_NoInit(n0_359 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_358) { var n0_359_2 float64 = jrt.NN(jrt.Double_Cast(na_358)).DoubleValue__D(); arg_357 = jrt.Double_ValueOf_D__Double_NoInit(n0_359_2 + 1.0).Ref() } else { arg_357 = lang.Numbers_Inc_O__Number_NoInit(na_358) } }; if linked_354 == nil { arg_352 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { arg_352 = linked_354.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) }; if linked_349 == nil { arg_347 = ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { if jrt.Long_InstanceOf(arg_352) { arg_347 = linked_349.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_348, arg_351, jrt.NN(jrt.Long_Cast(arg_352)).LongValue__J(), arg_352) } else { arg_347 = linked_349.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) } }; if linked_344 == nil { tmp3 = ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { tmp3 = linked_344.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) }; j__1 = tmp3; continue L1 } else {
//line :133:1
			var tmp4 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp4).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp5 any; var root_360 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = t.F_s; var arg_364 any; var root_365 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_365, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = t.F_s; var arg_369 any; var root_370 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = t.F_s; var arg_374 any; var na_375 any = j__1; var na_376 int64 = 2; if jrt.Long_InstanceOf(na_375) { var n0_377 int64 = jrt.NN(jrt.Long_Cast(na_375)).LongValue__J(); var n1_378 int64 = na_376; var nr_379 int64 = n0_377 + n1_378; if (n0_377^nr_379)&(n1_378^nr_379) >= 0 { arg_374 = jrt.Long_ValueOf_J__Long_NoInit(nr_379).Ref() } else { arg_374 = lang.Numbers_Add_O_J__Number_NoInit(na_375, na_376) } } else { arg_374 = lang.Numbers_Add_O_J__Number_NoInit(na_375, na_376) }; if linked_371 == nil { arg_369 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { arg_369 = linked_371.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; if linked_366 == nil { arg_364 = ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { if jrt.Long_InstanceOf(arg_369) { arg_364 = linked_366.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_365, arg_368, jrt.NN(jrt.Long_Cast(arg_369)).LongValue__J(), arg_369) } else { arg_364 = linked_366.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) } }; if linked_361 == nil { tmp5 = ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { tmp5 = linked_361.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) }; j__1 = tmp5; continue L1 } else {
//line :133:1
					if A_arbace_repr_clojure_rules_A_const_48 != nil { return j__1 } else { return nil } } } } } }; /*line :131:1*/panic("j2g: unreachable") }
//line :131:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A) Invoke_O__O(self any) any { { var j__1 any; var root_435 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = t.F_s; var arg_439 any; var root_440 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = t.F_s; var arg_444 any; var t_ any = t.F_h; t.F_h = nil; arg_444 = t_; if linked_441 == nil { arg_439 = ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { arg_439 = linked_441.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }; if linked_436 == nil { j__1 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { j__1 = linked_436.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; L1: for {

	var tmp1 bool; var na_445 any = j__1; var na_446 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_445) { var n0_447 int64 = jrt.NN(jrt.Long_Cast(na_445)).LongValue__J(); var n1_448 int64 = na_446; tmp1 = n0_447 >= n1_448 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_445, na_446) }; if tmp1 { return j__1 } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_47)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp3 any; var root_450 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = t.F_s; var arg_454 any; var root_455 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_455, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = t.F_s; var arg_459 any; var root_460 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = t.F_s; var arg_464 any; var na_465 any = j__1; if jrt.Long_InstanceOf(na_465) { var n0_466 int64 = jrt.NN(jrt.Long_Cast(na_465)).LongValue__J(); if n0_466 == 9223372036854775807 { arg_464 = lang.Numbers_Inc_O__Number_NoInit(na_465) } else { arg_464 = jrt.Long_ValueOf_J__Long_NoInit(n0_466 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_465) { var n0_466_2 float64 = jrt.NN(jrt.Double_Cast(na_465)).DoubleValue__D(); arg_464 = jrt.Double_ValueOf_D__Double_NoInit(n0_466_2 + 1.0).Ref() } else { arg_464 = lang.Numbers_Inc_O__Number_NoInit(na_465) } }; if linked_461 == nil { arg_459 = ifn_462.Invoke_O_O__O(arg_463, arg_464) } else { arg_459 = linked_461.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_460, arg_463, arg_464) }; if linked_456 == nil { arg_454 = ifn_457.Invoke_O_O__O(arg_458, arg_459) } else { if jrt.Long_InstanceOf(arg_459) { arg_454 = linked_456.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_455, arg_458, jrt.NN(jrt.Long_Cast(arg_459)).LongValue__J(), arg_459) } else { arg_454 = linked_456.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_455, arg_458, arg_459) } }; if linked_451 == nil { tmp3 = ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { tmp3 = linked_451.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) }; j__1 = tmp3; continue L1 } else {
//line :133:1
			var tmp4 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp4).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp5 any; var root_467 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = t.F_s; var arg_471 any; var root_472 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_472, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = t.F_s; var arg_476 any; var root_477 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = t.F_s; var arg_481 any; var na_482 any = j__1; var na_483 int64 = 2; if jrt.Long_InstanceOf(na_482) { var n0_484 int64 = jrt.NN(jrt.Long_Cast(na_482)).LongValue__J(); var n1_485 int64 = na_483; var nr_486 int64 = n0_484 + n1_485; if (n0_484^nr_486)&(n1_485^nr_486) >= 0 { arg_481 = jrt.Long_ValueOf_J__Long_NoInit(nr_486).Ref() } else { arg_481 = lang.Numbers_Add_O_J__Number_NoInit(na_482, na_483) } } else { arg_481 = lang.Numbers_Add_O_J__Number_NoInit(na_482, na_483) }; if linked_478 == nil { arg_476 = ifn_479.Invoke_O_O__O(arg_480, arg_481) } else { arg_476 = linked_478.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_477, arg_480, arg_481) }; if linked_473 == nil { arg_471 = ifn_474.Invoke_O_O__O(arg_475, arg_476) } else { if jrt.Long_InstanceOf(arg_476) { arg_471 = linked_473.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_472, arg_475, jrt.NN(jrt.Long_Cast(arg_476)).LongValue__J(), arg_476) } else { arg_471 = linked_473.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_472, arg_475, arg_476) } }; if linked_468 == nil { tmp5 = ifn_469.Invoke_O_O__O(arg_470, arg_471) } else { tmp5 = linked_468.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_467, arg_470, arg_471) }; j__1 = tmp5; continue L1 } else {
//line :133:1
					if A_arbace_repr_clojure_rules_A_const_48 != nil { return j__1 } else { return nil } } } } } }; /*line :131:1*/panic("j2g: unreachable") }











func A_arbace_repr_clojure_rules_insert_at_A_New() *A_arbace_repr_clojure_rules_insert_at_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_insert_at_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Ctor() {}
//line :143:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Invoke_O_O_O_O__O(self, s__0, i__1, x__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 any; var root_523 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = s__0; var arg_527 any = A_arbace_repr_clojure_rules_A_const_30; var arg_528 any = i__1; if linked_524 == nil { tmp2 = ifn_525.Invoke_O_O_O__O(arg_526, arg_527, arg_528) } else { tmp2 = linked_524.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_523, arg_526, arg_527, arg_528) }; var tmp3 any = tmp2; var tmp4 any; var root_529 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = s__0; var arg_533 any = i__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, x__2, tmp4)).Ref() }

func A_arbace_repr_clojure_rules_core_names_A_New() *A_arbace_repr_clojure_rules_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_core_names_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Ctor() {}
//line :145:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any; var root_534 any = A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_536 lang.IFn; if






	linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any; var root_538 any = A_arbace_repr_clojure_rules_A_const_59.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var root_542 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = added__1; var arg_546 any; var root_547 any = A_arbace_repr_clojure_rules_A_const_60.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_repr_clojure_rules_defined_names_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = s__0; if linked_548 == nil { arg_546 = ifn_549.Invoke_O__O(arg_550) } else { arg_546 = linked_548.(*A_arbace_repr_clojure_rules_defined_names_A).Invoke_O_O__O(root_547, arg_550) }; if linked_543 == nil { arg_541 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { arg_541 = linked_543.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) }; if linked_539 == nil { arg_537 = ifn_540.Invoke_O__O(arg_541) } else { arg_537 = linked_539.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_538, arg_541) }; if linked_535 == nil { names__3 = ifn_536.Invoke_O__O(arg_537) } else { names__3 = linked_535.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_534, arg_537) }; var vec__1700000123__4 any; var root_551 any = /*line :145:1*/A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_553 lang.IFn; if







	linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any; var root_555 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = s__0; var arg_559 any = A_arbace_repr_clojure_rules_A_const_61; if linked_556 == nil { arg_554 = ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { arg_554 = linked_556.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) }; if linked_552 == nil { vec__1700000123__4 = ifn_553.Invoke_O__O(arg_554) } else { vec__1700000123__4 = linked_552.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_551, arg_554) }; var ns_a__5 any = /*line :145:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1700000123__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000123__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any; var root_560 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_562 lang.IFn; if








	linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = names__3; if linked_561 == nil { or__1927000174__auto____7 = ifn_562.Invoke_O__O(arg_563) } else { or__1927000174__auto____7 = linked_561.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_560, arg_563) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ns_a__5, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var ns_text__7 any; var root_564 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_566 lang.IFn

		if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__0; var arg_568 any = ns_a__5; var arg_569 any = ns_b__6; if linked_565 == nil { ns_text__7 = ifn_566.Invoke_O_O_O__O(arg_567, arg_568, arg_569) } else { ns_text__7 = linked_565.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_564, arg_567, arg_568, arg_569) }
//line :154:1
		var names_text__8 any; var root_570 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_572 lang.IFn


		if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = Lit_5; var arg_574 any = names__3; if linked_571 == nil { names_text__8 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { names_text__8 = linked_571.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }
//line :154:1
		var vec__1700000126__9 any; var root_575 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_577 lang.IFn



		if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var root_579 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = ns_text__7; var arg_583 any = A_arbace_repr_clojure_rules_A_const_63; if linked_580 == nil { arg_578 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { arg_578 = linked_580.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_579, arg_582, arg_583) }; if linked_576 == nil { vec__1700000126__9 = ifn_577.Invoke_O__O(arg_578) } else { vec__1700000126__9 = linked_576.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_575, arg_578) }
//line :154:1
		var ra__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000126__9, lang.RT_IntCast_J__I_NoInit(0), nil); var rb__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000126__9, lang.RT_IntCast_J__I_NoInit(1), nil)




		if lang.Util_Identical_O_O__Z_NoInit(ra__10, nil) {

			var root_584 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = s__0; var arg_588 any; var na_590 any = ns_b__6; if jrt.Long_InstanceOf(na_590) { var n0_591 int64 = jrt.NN(jrt.Long_Cast(na_590)).LongValue__J(); if n0_591 == -9223372036854775808 { arg_588 = lang.Numbers_Dec_O__Number_NoInit(na_590) } else { arg_588 = jrt.Long_ValueOf_J__Long_NoInit(n0_591 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_590) { var n0_591_2 float64 = jrt.NN(jrt.Double_Cast(na_590)).DoubleValue__D(); arg_588 = jrt.Double_ValueOf_D__Double_NoInit(n0_591_2 - 1.0).Ref() } else { arg_588 = lang.Numbers_Dec_O__Number_NoInit(na_590) } }; var arg_589 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref(); if linked_585 == nil { return ifn_586.Invoke_O_O_O__O(arg_587, arg_588, arg_589) } else { return linked_585.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_584, arg_587, arg_588, arg_589) } } else {
//line :159:1
				var tmp2 any; var root_592 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_594 lang.IFn


				if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any; var root_597 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = ns_text__7; var arg_601 any = ra__10; var arg_602 any = rb__11; if linked_598 == nil { arg_595 = ifn_599.Invoke_O_O_O__O(arg_600, arg_601, arg_602) } else { arg_595 = linked_598.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_597, arg_600, arg_601, arg_602) }; var arg_596 any = Lit_8; if linked_593 == nil { tmp2 = ifn_594.Invoke_O_O__O(arg_595, arg_596) } else { tmp2 = linked_593.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_592, arg_595, arg_596) }
//line :159:1
				if jrt.J2g_Truth(tmp2) { return s__0 } else { if A_arbace_repr_clojure_rules_A_const_48 != nil { var rc__12 any; var root_603 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_605 lang.IFn





					if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = ns_text__7; var arg_607 any = ra__10; var arg_608 any = rb__11; if linked_604 == nil { rc__12 = ifn_605.Invoke_O_O_O__O(arg_606, arg_607, arg_608) } else { rc__12 = linked_604.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_603, arg_606, arg_607, arg_608) }
//line :159:1
					var ex__13 any; var root_609 any = A_arbace_repr_clojure_rules_A_const_65.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_611 lang.IFn






					if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = rc__12; var arg_613 any = Lit_9; if linked_610 == nil { ex__13 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { ex__13 = linked_610.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }
					if lang.Util_Identical_O_O__Z_NoInit(ex__13, nil) {
						var root_614 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = s__0; var arg_618 any; var na_620 any; var na_622 any = ns_a__5; var na_623 any = ra__10; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_622); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_623) }; tmp3 = tmp4; if tmp3 { var n0_624 int64 = jrt.NN(jrt.Long_Cast(na_622)).LongValue__J(); var n1_625 int64 = jrt.NN(jrt.Long_Cast(na_623)).LongValue__J(); var nr_626 int64 = n0_624 + n1_625; if (n0_624^nr_626)&(n1_625^nr_626) >= 0 { na_620 = jrt.Long_ValueOf_J__Long_NoInit(nr_626).Ref() } else { na_620 = lang.Numbers_Add_O_O__Number_NoInit(na_622, na_623) } } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_622); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_623) }; tmp5 = tmp6; if tmp5 { var n0_624_2 float64 = jrt.NN(jrt.Double_Cast(na_622)).DoubleValue__D(); var n1_625_2 float64 = jrt.NN(jrt.Double_Cast(na_623)).DoubleValue__D(); na_620 = jrt.Double_ValueOf_D__Double_NoInit(n0_624_2 + n1_625_2).Ref() } else { na_620 = lang.Numbers_Add_O_O__Number_NoInit(na_622, na_623) } }; var na_621 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rc__12))); if jrt.Long_InstanceOf(na_620) { var n0_627 int64 = jrt.NN(jrt.Long_Cast(na_620)).LongValue__J(); var n1_628 int64 = na_621; var nr_629 int64 = n0_627 + n1_628; if (n0_627^nr_629)&(n1_628^nr_629) >= 0 { arg_618 = jrt.Long_ValueOf_J__Long_NoInit(nr_629).Ref() } else { arg_618 = lang.Numbers_Add_O_J__Number_NoInit(na_620, na_621) } } else { arg_618 = lang.Numbers_Add_O_J__Number_NoInit(na_620, na_621) }; var arg_619 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref(); if linked_615 == nil { return ifn_616.Invoke_O_O_O__O(arg_617, arg_618, arg_619) } else { return linked_615.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_614, arg_617, arg_618, arg_619) } } else {
//line :167:1
							var v__14 any; var root_630 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_632 lang.IFn

							if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = rc__12; var arg_634 any; var na_635 any = ex__13; var na_636 int64 = int64(lang.RT_Count_O__I_NoInit(Lit_9)); if jrt.Long_InstanceOf(na_635) { var n0_637 int64 = jrt.NN(jrt.Long_Cast(na_635)).LongValue__J(); var n1_638 int64 = na_636; var nr_639 int64 = n0_637 + n1_638; if (n0_637^nr_639)&(n1_638^nr_639) >= 0 { arg_634 = jrt.Long_ValueOf_J__Long_NoInit(nr_639).Ref() } else { arg_634 = lang.Numbers_Add_O_J__Number_NoInit(na_635, na_636) } } else { arg_634 = lang.Numbers_Add_O_J__Number_NoInit(na_635, na_636) }; if linked_631 == nil { v__14 = ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { v__14 = linked_631.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) }
//line :167:1
							var ve__15 any; var root_640 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_640, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_642 lang.IFn


							if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = rc__12; var arg_644 any = v__14; if linked_641 == nil { ve__15 = ifn_642.Invoke_O_O__O(arg_643, arg_644) } else { if jrt.Long_InstanceOf(arg_644) { ve__15 = linked_641.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_640, arg_643, jrt.NN(jrt.Long_Cast(arg_644)).LongValue__J(), arg_644) } else { ve__15 = linked_641.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_640, arg_643, arg_644) } }
							var root_645 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = s__0; var arg_649 any; var na_651 any; var na_653 any = ns_a__5; var na_654 any = ra__10; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_653); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_654) }; tmp7 = tmp8; if tmp7 { var n0_655 int64 = jrt.NN(jrt.Long_Cast(na_653)).LongValue__J(); var n1_656 int64 = jrt.NN(jrt.Long_Cast(na_654)).LongValue__J(); var nr_657 int64 = n0_655 + n1_656; if (n0_655^nr_657)&(n1_656^nr_657) >= 0 { na_651 = jrt.Long_ValueOf_J__Long_NoInit(nr_657).Ref() } else { na_651 = lang.Numbers_Add_O_O__Number_NoInit(na_653, na_654) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_653); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_654) }; tmp9 = tmp10; if tmp9 { var n0_655_2 float64 = jrt.NN(jrt.Double_Cast(na_653)).DoubleValue__D(); var n1_656_2 float64 = jrt.NN(jrt.Double_Cast(na_654)).DoubleValue__D(); na_651 = jrt.Double_ValueOf_D__Double_NoInit(n0_655_2 + n1_656_2).Ref() } else { na_651 = lang.Numbers_Add_O_O__Number_NoInit(na_653, na_654) } }; var na_652 any; var na_658 any = ve__15; if jrt.Long_InstanceOf(na_658) { var n0_659 int64 = jrt.NN(jrt.Long_Cast(na_658)).LongValue__J(); if n0_659 == -9223372036854775808 { na_652 = lang.Numbers_Dec_O__Number_NoInit(na_658) } else { na_652 = jrt.Long_ValueOf_J__Long_NoInit(n0_659 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_658) { var n0_659_2 float64 = jrt.NN(jrt.Double_Cast(na_658)).DoubleValue__D(); na_652 = jrt.Double_ValueOf_D__Double_NoInit(n0_659_2 - 1.0).Ref() } else { na_652 = lang.Numbers_Dec_O__Number_NoInit(na_658) } }; var tmp11 bool; var tmp12 bool; tmp12 = jrt.Long_InstanceOf(na_651); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_652) }; tmp11 = tmp12; if tmp11 { var n0_660 int64 = jrt.NN(jrt.Long_Cast(na_651)).LongValue__J(); var n1_661 int64 = jrt.NN(jrt.Long_Cast(na_652)).LongValue__J(); var nr_662 int64 = n0_660 + n1_661; if (n0_660^nr_662)&(n1_661^nr_662) >= 0 { arg_649 = jrt.Long_ValueOf_J__Long_NoInit(nr_662).Ref() } else { arg_649 = lang.Numbers_Add_O_O__Number_NoInit(na_651, na_652) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_651); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_652) }; tmp13 = tmp14; if tmp13 { var n0_660_2 float64 = jrt.NN(jrt.Double_Cast(na_651)).DoubleValue__D(); var n1_661_2 float64 = jrt.NN(jrt.Double_Cast(na_652)).DoubleValue__D(); arg_649 = jrt.Double_ValueOf_D__Double_NoInit(n0_660_2 + n1_661_2).Ref() } else { arg_649 = lang.Numbers_Add_O_O__Number_NoInit(na_651, na_652) } }; var arg_650 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8)).Ref(); if linked_646 == nil { return ifn_647.Invoke_O_O_O__O(arg_648, arg_649, arg_650) } else { return linked_646.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_645, arg_648, arg_649, arg_650) } } } else {
//line :159:1
								return nil } } } } }













func A_arbace_repr_clojure_rules_cut_A_New() *A_arbace_repr_clojure_rules_cut_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_cut_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_clojure_rules_cut_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_clojure_rules_cut_A) Invoke_O_O_O_O__O(self, s__0, a__1, b__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_663 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = s__0; var arg_667 any = A_arbace_repr_clojure_rules_A_const_30; var arg_668 any = a__1; if linked_664 == nil { tmp2 = ifn_665.Invoke_O_O_O__O(arg_666, arg_667, arg_668) } else { tmp2 = linked_664.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_663, arg_666, arg_667, arg_668) }; var tmp3 any = tmp2; var tmp4 any; var root_669 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = s__0; var arg_673 any = b__2; if linked_670 == nil { tmp4 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp4 = linked_670.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref() }

func A_arbace_repr_clojure_rules_uncore_names_A_New() *A_arbace_repr_clojure_rules_uncore_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_repr_clojure_rules_uncore_names_A) Ctor() {}
//line :175:1
func (t *A_arbace_repr_clojure_rules_uncore_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any; var root_674 any = A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_676 lang.IFn; if







	linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any; var root_678 any = A_arbace_repr_clojure_rules_A_const_59.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any; var root_682 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = added__1; var arg_686 any; var root_687 any = A_arbace_repr_clojure_rules_A_const_60.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, A_arbace_repr_clojure_rules_defined_names_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = s__0; if linked_688 == nil { arg_686 = ifn_689.Invoke_O__O(arg_690) } else { arg_686 = linked_688.(*A_arbace_repr_clojure_rules_defined_names_A).Invoke_O_O__O(root_687, arg_690) }; if linked_683 == nil { arg_681 = ifn_684.Invoke_O_O__O(arg_685, arg_686) } else { arg_681 = linked_683.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_682, arg_685, arg_686) }; if linked_679 == nil { arg_677 = ifn_680.Invoke_O__O(arg_681) } else { arg_677 = linked_679.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_678, arg_681) }; if linked_675 == nil { names__3 = ifn_676.Invoke_O__O(arg_677) } else { names__3 = linked_675.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_674, arg_677) }; var vec__1700000132__4 any; var root_691 any = /*line :175:1*/A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_693 lang.IFn; if








	linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any; var root_695 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__0; var arg_699 any = A_arbace_repr_clojure_rules_A_const_66; if linked_696 == nil { arg_694 = ifn_697.Invoke_O_O__O(arg_698, arg_699) } else { arg_694 = linked_696.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_695, arg_698, arg_699) }; if linked_692 == nil { vec__1700000132__4 = ifn_693.Invoke_O__O(arg_694) } else { vec__1700000132__4 = linked_692.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_691, arg_694) }; var ns_a__5 any = /*line :175:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1700000132__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000132__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any; var root_700 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_702 lang.IFn; if









	linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = names__3; if linked_701 == nil { or__1927000174__auto____7 = ifn_702.Invoke_O__O(arg_703) } else { or__1927000174__auto____7 = linked_701.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_700, arg_703) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ns_a__5, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var nt__7 any; var root_704 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_706 lang.IFn

		if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = Lit_5; var arg_708 any = names__3; if linked_705 == nil { nt__7 = ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { nt__7 = linked_705.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) }
//line :185:1
		var suffix_QMARK___8 any; var tmp2 any = A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_New_O(s__0); var tmp3 *jrt.Class
		var fncls__739 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class


		if fncls__739 == nil { var fncls__739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class = fncls__739d; tmp3 = fncls__739d } else { tmp3 = fncls__739 }; suffix_QMARK___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :185:1
		var a__9 any; var x__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, nt__7, nil)).Ref(); var e__10 any
		var na_740 any = ns_b__6



		if jrt.Long_InstanceOf(na_740) { var n0_741 int64 = jrt.NN(jrt.Long_Cast(na_740)).LongValue__J(); if n0_741 == -9223372036854775808 { e__10 = lang.Numbers_Dec_O__Number_NoInit(na_740) } else { e__10 = jrt.Long_ValueOf_J__Long_NoInit(n0_741 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_740) { var n0_741_2 float64 = jrt.NN(jrt.Double_Cast(na_740)).DoubleValue__D(); e__10 = jrt.Double_ValueOf_D__Double_NoInit(n0_741_2 - 1.0).Ref() } else { e__10 = lang.Numbers_Dec_O__Number_NoInit(na_740) } }
		if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__10, x__9)) { var root_742 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = s__0; var arg_746 any; var na_748 any = e__10; var na_749 int64 = int64(lang.RT_Count_O__I_NoInit(x__9)); if jrt.Long_InstanceOf(na_748) { var n0_750 int64 = jrt.NN(jrt.Long_Cast(na_748)).LongValue__J(); var n1_751 int64 = na_749; var nr_752 int64 = n0_750 - n1_751; var tmp4 bool; var tmp5 bool; tmp5 = !(n1_751 == -9223372036854775808); if tmp5 { tmp5 = (n0_750^n1_751)&(n0_750^nr_752) >= 0 }; tmp4 = tmp5; if tmp4 { arg_746 = jrt.Long_ValueOf_J__Long_NoInit(nr_752).Ref() } else { arg_746 = lang.Numbers_Minus_O_J__Number_NoInit(na_748, na_749) } } else { arg_746 = lang.Numbers_Minus_O_J__Number_NoInit(na_748, na_749) }; var arg_747 any = e__10; if linked_743 == nil { a__9 = ifn_744.Invoke_O_O_O__O(arg_745, arg_746, arg_747) } else { a__9 = linked_743.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_742, arg_745, arg_746, arg_747) } } else { a__9 = nil }
//line :185:1
		var ns_text__10 any; var root_753 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_755 lang.IFn






		if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = s__0; var arg_757 any = ns_a__5; var arg_758 any = ns_b__6; if linked_754 == nil { ns_text__10 = ifn_755.Invoke_O_O_O__O(arg_756, arg_757, arg_758) } else { ns_text__10 = linked_754.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_753, arg_756, arg_757, arg_758) }
//line :185:1
		var vec__1700000135__11 any; var root_759 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_761 lang.IFn







		if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var root_763 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = ns_text__10; var arg_767 any = A_arbace_repr_clojure_rules_A_const_68; if linked_764 == nil { arg_762 = ifn_765.Invoke_O_O__O(arg_766, arg_767) } else { arg_762 = linked_764.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_763, arg_766, arg_767) }; if linked_760 == nil { vec__1700000135__11 = ifn_761.Invoke_O__O(arg_762) } else { vec__1700000135__11 = linked_760.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_759, arg_762) }
//line :185:1
		var ra__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000135__11, lang.RT_IntCast_J__I_NoInit(0), nil); var rb__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000135__11, lang.RT_IntCast_J__I_NoInit(1), nil); var b__14 any









		if jrt.J2g_Truth(ra__12) { var x__14 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, nt__7, nil)).Ref(); var e__15 any; var na_768 any = ns_a__5; var na_769 any; var na_770 any = rb__13
			if jrt.Long_InstanceOf(na_770) { var n0_771 int64 = jrt.NN(jrt.Long_Cast(na_770)).LongValue__J(); if n0_771 == -9223372036854775808 { na_769 = lang.Numbers_Dec_O__Number_NoInit(na_770) } else { na_769 = jrt.Long_ValueOf_J__Long_NoInit(n0_771 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_770) { var n0_771_2 float64 = jrt.NN(jrt.Double_Cast(na_770)).DoubleValue__D(); na_769 = jrt.Double_ValueOf_D__Double_NoInit(n0_771_2 - 1.0).Ref() } else { na_769 = lang.Numbers_Dec_O__Number_NoInit(na_770) } }; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_768); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_769) }; tmp6 = tmp7; if tmp6 { var n0_772 int64 = jrt.NN(jrt.Long_Cast(na_768)).LongValue__J(); var n1_773 int64 = jrt.NN(jrt.Long_Cast(na_769)).LongValue__J(); var nr_774 int64 = n0_772 + n1_773; if (n0_772^nr_774)&(n1_773^nr_774) >= 0 { e__15 = jrt.Long_ValueOf_J__Long_NoInit(nr_774).Ref() } else { e__15 = lang.Numbers_Add_O_O__Number_NoInit(na_768, na_769) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_768); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_769) }; tmp8 = tmp9; if tmp8 { var n0_772_2 float64 = jrt.NN(jrt.Double_Cast(na_768)).DoubleValue__D(); var n1_773_2 float64 = jrt.NN(jrt.Double_Cast(na_769)).DoubleValue__D(); e__15 = jrt.Double_ValueOf_D__Double_NoInit(n0_772_2 + n1_773_2).Ref() } else { e__15 = lang.Numbers_Add_O_O__Number_NoInit(na_768, na_769) } }
			if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__15, x__14)) { var root_775 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = s__0; var arg_779 any; var na_781 any = e__15; var na_782 int64 = int64(lang.RT_Count_O__I_NoInit(x__14)); if jrt.Long_InstanceOf(na_781) { var n0_783 int64 = jrt.NN(jrt.Long_Cast(na_781)).LongValue__J(); var n1_784 int64 = na_782; var nr_785 int64 = n0_783 - n1_784; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_784 == -9223372036854775808); if tmp11 { tmp11 = (n0_783^n1_784)&(n0_783^nr_785) >= 0 }; tmp10 = tmp11; if tmp10 { arg_779 = jrt.Long_ValueOf_J__Long_NoInit(nr_785).Ref() } else { arg_779 = lang.Numbers_Minus_O_J__Number_NoInit(na_781, na_782) } } else { arg_779 = lang.Numbers_Minus_O_J__Number_NoInit(na_781, na_782) }; var arg_780 any = e__15; if linked_776 == nil { b__14 = ifn_777.Invoke_O_O_O__O(arg_778, arg_779, arg_780) } else { b__14 = linked_776.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_775, arg_778, arg_779, arg_780) } } else { b__14 = nil } } else {
//line :195:1
				b__14 = nil }
//line :185:1
		var c__15 any













		if jrt.J2g_Truth(ra__12) { var rc__15 any; var root_786 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_788 lang.IFn
			if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = ns_text__10; var arg_790 any = ra__12; var arg_791 any = rb__13; if linked_787 == nil { rc__15 = ifn_788.Invoke_O_O_O__O(arg_789, arg_790, arg_791) } else { rc__15 = linked_787.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_786, arg_789, arg_790, arg_791) }
//line :199:1
			var temp__1927000414__auto____16 any; var root_792 any = A_arbace_repr_clojure_rules_A_const_65.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_794 lang.IFn

			if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = rc__15; var arg_796 any = Lit_9; if linked_793 == nil { temp__1927000414__auto____16 = ifn_794.Invoke_O_O__O(arg_795, arg_796) } else { temp__1927000414__auto____16 = linked_793.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_792, arg_795, arg_796) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var ex__17 any = temp__1927000414__auto____16; var v__18 any; var root_797 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_799 lang.IFn
				if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = rc__15; var arg_801 any; var na_802 any = ex__17; var na_803 int64 = int64(lang.RT_Count_O__I_NoInit(Lit_9)); if jrt.Long_InstanceOf(na_802) { var n0_804 int64 = jrt.NN(jrt.Long_Cast(na_802)).LongValue__J(); var n1_805 int64 = na_803; var nr_806 int64 = n0_804 + n1_805; if (n0_804^nr_806)&(n1_805^nr_806) >= 0 { arg_801 = jrt.Long_ValueOf_J__Long_NoInit(nr_806).Ref() } else { arg_801 = lang.Numbers_Add_O_J__Number_NoInit(na_802, na_803) } } else { arg_801 = lang.Numbers_Add_O_J__Number_NoInit(na_802, na_803) }; if linked_798 == nil { v__18 = ifn_799.Invoke_O_O__O(arg_800, arg_801) } else { v__18 = linked_798.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_797, arg_800, arg_801) }
//line :201:1
				var ve__19 any; var root_807 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_807, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_809 lang.IFn

				if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = rc__15; var arg_811 any = v__18; if linked_808 == nil { ve__19 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { if jrt.Long_InstanceOf(arg_811) { ve__19 = linked_808.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_807, arg_810, jrt.NN(jrt.Long_Cast(arg_811)).LongValue__J(), arg_811) } else { ve__19 = linked_808.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) } }
//line :201:1
				var x__20 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, nt__7)).Ref(); var e__21 any; var na_812 any; var na_814 any = ns_a__5; var na_815 any = ra__12; var tmp12 bool; var tmp13 bool


				tmp13 = jrt.Long_InstanceOf(na_814); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_815) }; tmp12 = tmp13; if tmp12 { var n0_816 int64 = jrt.NN(jrt.Long_Cast(na_814)).LongValue__J(); var n1_817 int64 = jrt.NN(jrt.Long_Cast(na_815)).LongValue__J(); var nr_818 int64 = n0_816 + n1_817; if (n0_816^nr_818)&(n1_817^nr_818) >= 0 { na_812 = jrt.Long_ValueOf_J__Long_NoInit(nr_818).Ref() } else { na_812 = lang.Numbers_Add_O_O__Number_NoInit(na_814, na_815) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_814); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_815) }; tmp14 = tmp15; if tmp14 { var n0_816_2 float64 = jrt.NN(jrt.Double_Cast(na_814)).DoubleValue__D(); var n1_817_2 float64 = jrt.NN(jrt.Double_Cast(na_815)).DoubleValue__D(); na_812 = jrt.Double_ValueOf_D__Double_NoInit(n0_816_2 + n1_817_2).Ref() } else { na_812 = lang.Numbers_Add_O_O__Number_NoInit(na_814, na_815) } }; var na_813 any; var na_819 any = ve__19; if jrt.Long_InstanceOf(na_819) { var n0_820 int64 = jrt.NN(jrt.Long_Cast(na_819)).LongValue__J(); if n0_820 == -9223372036854775808 { na_813 = lang.Numbers_Dec_O__Number_NoInit(na_819) } else { na_813 = jrt.Long_ValueOf_J__Long_NoInit(n0_820 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_819) { var n0_820_2 float64 = jrt.NN(jrt.Double_Cast(na_819)).DoubleValue__D(); na_813 = jrt.Double_ValueOf_D__Double_NoInit(n0_820_2 - 1.0).Ref() } else { na_813 = lang.Numbers_Dec_O__Number_NoInit(na_819) } }; var tmp16 bool; var tmp17 bool; tmp17 = jrt.Long_InstanceOf(na_812); if tmp17 { tmp17 = jrt.Long_InstanceOf(na_813) }; tmp16 = tmp17; if tmp16 { var n0_821 int64 = jrt.NN(jrt.Long_Cast(na_812)).LongValue__J(); var n1_822 int64 = jrt.NN(jrt.Long_Cast(na_813)).LongValue__J(); var nr_823 int64 = n0_821 + n1_822; if (n0_821^nr_823)&(n1_822^nr_823) >= 0 { e__21 = jrt.Long_ValueOf_J__Long_NoInit(nr_823).Ref() } else { e__21 = lang.Numbers_Add_O_O__Number_NoInit(na_812, na_813) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_812); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_813) }; tmp18 = tmp19; if tmp18 { var n0_821_2 float64 = jrt.NN(jrt.Double_Cast(na_812)).DoubleValue__D(); var n1_822_2 float64 = jrt.NN(jrt.Double_Cast(na_813)).DoubleValue__D(); e__21 = jrt.Double_ValueOf_D__Double_NoInit(n0_821_2 + n1_822_2).Ref() } else { e__21 = lang.Numbers_Add_O_O__Number_NoInit(na_812, na_813) } }
				if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__21, x__20)) { var root_824 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = s__0; var arg_828 any; var na_830 any = e__21; var na_831 int64 = int64(lang.RT_Count_O__I_NoInit(x__20)); if jrt.Long_InstanceOf(na_830) { var n0_832 int64 = jrt.NN(jrt.Long_Cast(na_830)).LongValue__J(); var n1_833 int64 = na_831; var nr_834 int64 = n0_832 - n1_833; var tmp20 bool; var tmp21 bool; tmp21 = !(n1_833 == -9223372036854775808); if tmp21 { tmp21 = (n0_832^n1_833)&(n0_832^nr_834) >= 0 }; tmp20 = tmp21; if tmp20 { arg_828 = jrt.Long_ValueOf_J__Long_NoInit(nr_834).Ref() } else { arg_828 = lang.Numbers_Minus_O_J__Number_NoInit(na_830, na_831) } } else { arg_828 = lang.Numbers_Minus_O_J__Number_NoInit(na_830, na_831) }; var arg_829 any = e__21; if linked_825 == nil { c__15 = ifn_826.Invoke_O_O_O__O(arg_827, arg_828, arg_829) } else { c__15 = linked_825.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_824, arg_827, arg_828, arg_829) } } else { c__15 = nil } } else {
//line :201:1
					c__15 = nil } } else {
//line :199:1
						c__15 = nil }
//line :185:1
		var or__1927000174__auto____16 any; var root_835 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_837 lang.IFn




















		if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any; var root_839 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var tmp22 any = A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_New_O_O(s__0, added__1); var tmp23 *jrt.Class; var fncls__849 *jrt.Class = A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class; if fncls__849 == nil { var fncls__849d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class = fncls__849d; tmp23 = fncls__849d } else { tmp23 = fncls__849 }; arg_842 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_843 any = lang.Tuple_Create_O_O_O__IPersistentVector(a__9, b__14, c__15); if linked_840 == nil { arg_838 = ifn_841.Invoke_O_O__O(arg_842, arg_843) } else { arg_838 = linked_840.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_839, arg_842, arg_843) }; if linked_836 == nil { or__1927000174__auto____16 = ifn_837.Invoke_O__O(arg_838) } else { or__1927000174__auto____16 = linked_836.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_835, arg_838) }; if jrt.J2g_Truth(or__1927000174__auto____16) { return or__1927000174__auto____16 } else { return s__0 } } }
//line :188:1
func A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_New_O(p0 any) *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) Invoke_O_O_O__O(self, end__1, x__2 any) any { if jrt.Long_InstanceOf(end__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(end__1)).LongValue__J(), end__1, x__2) } else { var and__1927000168__auto____3 bool; var na_709 any = end__1; var na_710 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); if jrt.Long_InstanceOf(na_709) { var n0_711 int64 = jrt.NN(jrt.Long_Cast(na_709)).LongValue__J(); var n1_712 int64 = na_710; and__1927000168__auto____3 = n0_711 >= n1_712 } else { and__1927000168__auto____3 = lang.Numbers_Gte_O_J__Z_NoInit(na_709, na_710) }; if and__1927000168__auto____3 { var tmp1 any; var root_714 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = t.F_s; var arg_718 any; var na_720 any = end__1; var na_721 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); if jrt.Long_InstanceOf(na_720) { var n0_722 int64 = jrt.NN(jrt.Long_Cast(na_720)).LongValue__J(); var n1_723 int64 = na_721; var nr_724 int64 = n0_722 - n1_723; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_723 == -9223372036854775808); if tmp3 { tmp3 = (n0_722^n1_723)&(n0_722^nr_724) >= 0 }; tmp2 = tmp3; if tmp2 { arg_718 = jrt.Long_ValueOf_J__Long_NoInit(nr_724).Ref() } else { arg_718 = lang.Numbers_Minus_O_J__Number_NoInit(na_720, na_721) } } else { arg_718 = lang.Numbers_Minus_O_J__Number_NoInit(na_720, na_721) }; var arg_719 any = end__1; if linked_715 == nil { tmp1 = ifn_716.Invoke_O_O_O__O(arg_717, arg_718, arg_719) } else { tmp1 = linked_715.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_714, arg_717, arg_718, arg_719) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__2, tmp1)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) InvokeSpec_O_J_O_O__O(self any, end__1_l int64, end__1_b, x__2 any) any { var and__1927000168__auto____3 bool; var na_725 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); var n0_726 int64 = end__1_l; var n1_727 int64 = na_725; and__1927000168__auto____3 = n0_726 >= n1_727; if and__1927000168__auto____3 { var tmp1 any; var root_729 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = t.F_s; var arg_733 any; var na_735 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); var n0_736 int64 = end__1_l; var n1_737 int64 = na_735; var nr_738 int64 = n0_736 - n1_737; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_737 == -9223372036854775808); if tmp3 { tmp3 = (n0_736^n1_737)&(n0_736^nr_738) >= 0 }; tmp2 = tmp3; if tmp2 { arg_733 = jrt.Long_ValueOf_J__Long_NoInit(nr_738).Ref() } else { var tmp4 any; if end__1_b == nil { end__1_b = jrt.Long_ValueOf_J__Long_NoInit(end__1_l).Ref(); tmp4 = end__1_b } else { tmp4 = end__1_b }; arg_733 = lang.Numbers_Minus_O_J__Number_NoInit(tmp4, na_735) }; var arg_734 any; if end__1_b == nil { end__1_b = jrt.Long_ValueOf_J__Long_NoInit(end__1_l).Ref(); arg_734 = end__1_b } else { arg_734 = end__1_b }; if linked_730 == nil { tmp1 = ifn_731.Invoke_O_O_O__O(arg_732, arg_733, arg_734) } else { tmp1 = linked_730.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_729, arg_732, arg_733, arg_734) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__2, tmp1)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

















func A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A{}; t.Ctor_O_O(p0, p1); return t }
//line :206:1
func (t *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A) Ctor_O_O(c__s, c__added any) { t.F_s = c__s; t.F_added = c__added }
//line :206:1
func (t *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A) Invoke_O_O__O(self, p1__1700000131_SHARP___1 any) any { var and__1927000168__auto____2 any = p1__1700000131_SHARP___1; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = t.F_s; var tmp2 any; var root_844 any = A_arbace_repr_clojure_rules_A_const_69.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_repr_clojure_rules_core_names_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = p1__1700000131_SHARP___1; var arg_848 any = t.F_added; if linked_845 == nil { tmp2 = ifn_846.Invoke_O_O__O(arg_847, arg_848) } else { tmp2 = linked_845.(*A_arbace_repr_clojure_rules_core_names_A).Invoke_O_O_O__O(root_844, arg_847, arg_848) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }







func A_arbace_repr_clojure_rules_fn__1700000143_A_New() *A_arbace_repr_clojure_rules_fn__1700000143_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000143_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repr_clojure_rules_fn__1700000143_A) Ctor() {}
//line :214:1
func (t *A_arbace_repr_clojure_rules_fn__1700000143_A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 any = A_arbace_repr_clojure_rules_A_const_70; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0)); if and__1927000168__auto____2 { return A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_repr_clojure_rules_fn__1700000145_A_New() *A_arbace_repr_clojure_rules_fn__1700000145_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000145_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_repr_clojure_rules_fn__1700000145_A) Ctor() {}
//line :215:1
func (t *A_arbace_repr_clojure_rules_fn__1700000145_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_850 any = A_arbace_repr_clojure_rules_A_const_72.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = s__0; var arg_854 any = A_arbace_repr_clojure_rules_A_const_73.Invoke_O__O(ctx__1); if linked_851 == nil { return ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { return linked_851.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) } }






func A_arbace_repr_clojure_rules_fn__1700000147_A_New() *A_arbace_repr_clojure_rules_fn__1700000147_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000147_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_repr_clojure_rules_fn__1700000147_A) Ctor() {}
//line :222:1
func (t *A_arbace_repr_clojure_rules_fn__1700000147_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return s__0 }






func A_arbace_repr_clojure_rules_fn__1700000149_A_New() *A_arbace_repr_clojure_rules_fn__1700000149_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000149_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_repr_clojure_rules_fn__1700000149_A) Ctor() {}
//line :229:1
func (t *A_arbace_repr_clojure_rules_fn__1700000149_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_855 any = A_arbace_repr_clojure_rules_A_const_74.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_rename_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = s__0; if linked_856 == nil { return ifn_857.Invoke_O__O(arg_858) } else { return linked_856.(*aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_rename_A).Invoke_O_O__O(root_855, arg_858) } }



func A_arbace_repr_clojure_rules_fn__1700000151_A_New() *A_arbace_repr_clojure_rules_fn__1700000151_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000151_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_repr_clojure_rules_fn__1700000151_A) Ctor() {}
//line :233:1
func (t *A_arbace_repr_clojure_rules_fn__1700000151_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_859 any = A_arbace_repr_clojure_rules_A_const_75.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_unrename_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = s__0; if linked_860 == nil { return ifn_861.Invoke_O__O(arg_862) } else { return linked_860.(*aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_unrename_A).Invoke_O_O__O(root_859, arg_862) } }





func A_arbace_repr_clojure_rules_fn__1700000153_A_New() *A_arbace_repr_clojure_rules_fn__1700000153_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000153_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_repr_clojure_rules_fn__1700000153_A) Ctor() {}
//line :239:1
func (t *A_arbace_repr_clojure_rules_fn__1700000153_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_863 any = A_arbace_repr_clojure_rules_A_const_76.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, A_arbace_repr_clojure_rules_proxy_methods_A_fn_class); var ifn_865 lang.IFn; if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = s__0; if linked_864 == nil { return ifn_865.Invoke_O__O(arg_866) } else { return linked_864.(*A_arbace_repr_clojure_rules_proxy_methods_A).Invoke_O_O__O(root_863, arg_866) } }


func A_arbace_repr_clojure_rules_fn__1700000155_A_New() *A_arbace_repr_clojure_rules_fn__1700000155_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000155_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_repr_clojure_rules_fn__1700000155_A) Ctor() {}
//line :242:1
func (t *A_arbace_repr_clojure_rules_fn__1700000155_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_867 any = A_arbace_repr_clojure_rules_A_const_77.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = s__0; if linked_868 == nil { return ifn_869.Invoke_O__O(arg_870) } else { return linked_868.(*A_arbace_repr_clojure_rules_unproxy_methods_A).Invoke_O_O__O(root_867, arg_870) } }





func A_arbace_repr_clojure_rules_fn__1700000157_A_New() *A_arbace_repr_clojure_rules_fn__1700000157_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000157_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_repr_clojure_rules_fn__1700000157_A) Ctor() {}
//line :248:1
func (t *A_arbace_repr_clojure_rules_fn__1700000157_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_871 any = A_arbace_repr_clojure_rules_A_const_69.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, A_arbace_repr_clojure_rules_core_names_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = s__0; var arg_875 any; var or__1927000174__auto____3 any = A_arbace_repr_clojure_rules_A_const_78.Invoke_O__O(ctx__1); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_875 = or__1927000174__auto____3 } else { var root_876 any = A_arbace_repr_clojure_rules_A_const_79.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; if linked_877 == nil { arg_875 = ifn_878.Invoke__O() } else { arg_875 = linked_877.(*A_arbace_repr_clojure_rules_arbace_core_names_A).Invoke_O__O(root_876) } }; if linked_872 == nil { return ifn_873.Invoke_O_O__O(arg_874, arg_875) } else { return linked_872.(*A_arbace_repr_clojure_rules_core_names_A).Invoke_O_O_O__O(root_871, arg_874, arg_875) } }



func A_arbace_repr_clojure_rules_fn__1700000159_A_New() *A_arbace_repr_clojure_rules_fn__1700000159_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000159_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_repr_clojure_rules_fn__1700000159_A) Ctor() {}
//line :252:1
func (t *A_arbace_repr_clojure_rules_fn__1700000159_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_879 any = A_arbace_repr_clojure_rules_A_const_80.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, A_arbace_repr_clojure_rules_uncore_names_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = s__0; var arg_883 any; var or__1927000174__auto____3 any = A_arbace_repr_clojure_rules_A_const_78.Invoke_O__O(ctx__1); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_883 = or__1927000174__auto____3 } else { var root_884 any = A_arbace_repr_clojure_rules_A_const_79.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; if linked_885 == nil { arg_883 = ifn_886.Invoke__O() } else { arg_883 = linked_885.(*A_arbace_repr_clojure_rules_arbace_core_names_A).Invoke_O__O(root_884) } }; if linked_880 == nil { return ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { return linked_880.(*A_arbace_repr_clojure_rules_uncore_names_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) } }




func A_arbace_repr_clojure_rules_fn__1700000161_A_New() *A_arbace_repr_clojure_rules_fn__1700000161_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000161_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_repr_clojure_rules_fn__1700000161_A) Ctor() {}
//line :257:1
func (t *A_arbace_repr_clojure_rules_fn__1700000161_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_887 any = A_arbace_repr_clojure_rules_A_const_81.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, A_arbace_repr_clojure_rules_security_manager_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = s__0; if linked_888 == nil { return ifn_889.Invoke_O__O(arg_890) } else { return linked_888.(*A_arbace_repr_clojure_rules_security_manager_A).Invoke_O_O__O(root_887, arg_890) } }



func A_arbace_repr_clojure_rules_fn__1700000163_A_New() *A_arbace_repr_clojure_rules_fn__1700000163_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000163_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_repr_clojure_rules_fn__1700000163_A) Ctor() {}
//line :261:1
func (t *A_arbace_repr_clojure_rules_fn__1700000163_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_891 any = A_arbace_repr_clojure_rules_A_const_82.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = s__0; if linked_892 == nil { return ifn_893.Invoke_O__O(arg_894) } else { return linked_892.(*A_arbace_repr_clojure_rules_unqualify_security_manager_A).Invoke_O_O__O(root_891, arg_894) } }































func A_arbace_repr_clojure_rules_applicable_A_New() *A_arbace_repr_clojure_rules_applicable_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Ctor() {}
//line :293:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Invoke_O_O_O__O(self, ctx__0, skip__1 any) any {


	var root_895 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any; var tmp1 any = A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_New_O_O(ctx__0, skip__1); var tmp2 *jrt.Class; var fncls__909 *jrt.Class = A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class; if fncls__909 == nil { var fncls__909d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class = fncls__909d; tmp2 = fncls__909d } else { tmp2 = fncls__909 }; arg_898 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_899 any = A_arbace_repr_clojure_rules_A_const_85.GetRawRoot__O(); if linked_896 == nil { return ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { return linked_896.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) } }
//line :296:1
func A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_fn__1700000166_A{}; t.Ctor_O_O(p0, p1); return t }
//line :296:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A) Ctor_O_O(c__ctx, c__skip any) { t.F_ctx = c__ctx; t.F_skip = c__skip }
//line :296:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A) Invoke_O_O__O(self, p1__1700000165_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_900 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var root_904 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = t.F_skip; var arg_908 any = A_arbace_repr_clojure_rules_A_const_83.Invoke_O__O(p1__1700000165_SHARP___1); if linked_905 == nil { arg_903 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { arg_903 = linked_905.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }; if linked_901 == nil { and__1927000168__auto____2 = ifn_902.Invoke_O__O(arg_903) } else { and__1927000168__auto____2 = linked_901.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_900, arg_903) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_84.Invoke_O__O(p1__1700000165_SHARP___1)).Invoke_O__O(t.F_ctx) } else { return and__1927000168__auto____2 } }











func A_arbace_repr_clojure_rules_full_block_A_New() *A_arbace_repr_clojure_rules_full_block_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_block_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_repr_clojure_rules_full_block_A) Ctor() {}
//line :308:1
func (t *A_arbace_repr_clojure_rules_full_block_A) Invoke_O_O__O(self, conditionals__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(jrt.String_Cast(A_arbace_repr_clojure_rules_A_const_86.GetRawRoot__O())); var seq_1700000169__3 any; var root_914 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_916 lang.IFn; if





	linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = conditionals__0; if linked_915 == nil { seq_1700000169__3 = ifn_916.Invoke_O__O(arg_917) } else { seq_1700000169__3 = linked_915.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_914, arg_917) }; var chunk_1700000170__4 any; var count_1700000171__5 int64 = 0; var i_1700000172__6 int64 = 0; L1:
//line :308:1
	for {





		if lang.Numbers_Lt_J_J__Z_NoInit(i_1700000172__6, count_1700000171__5) { var map__1700000173__7 any = lang.Indexed_Cast(chunk_1700000170__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1700000172__6)); var map__1700000173__8 any; if lang.ISeq_InstanceOf(map__1700000173__7) { var tmp1 any; var root_918 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = map__1700000173__7; if linked_919 == nil { tmp1 = ifn_920.Invoke_O__O(arg_921) } else { tmp1 = linked_919.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_918, arg_921) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_922 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = map__1700000173__7; if linked_923 == nil { tmp2 = ifn_924.Invoke_O__O(arg_925) } else { tmp2 = linked_923.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_922, arg_925) }; map__1700000173__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_926 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = map__1700000173__7; if linked_927 == nil { tmp3 = ifn_928.Invoke_O__O(arg_929) } else { tmp3 = linked_927.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_926, arg_929) }; if jrt.J2g_Truth(tmp3) { var root_930 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = map__1700000173__7; if linked_931 == nil { map__1700000173__8 = ifn_932.Invoke_O__O(arg_933) } else { map__1700000173__8 = linked_931.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_930, arg_933) } } else { map__1700000173__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1700000173__8 = map__1700000173__7 }; var at__9 any = lang.RT_Get_O_O__O_NoInit(map__1700000173__8, A_arbace_repr_clojure_rules_A_const_89); var length__10 any = lang.RT_Get_O_O__O_NoInit(map__1700000173__8, A_arbace_repr_clojure_rules_A_const_90); var text__11 any = lang.RT_Get_O_O__O_NoInit(map__1700000173__8, A_arbace_repr_clojure_rules_A_const_91)
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_5, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, at__9, nil, length__10, nil)))
//line :314:1
			var seq_1700000175__12 any; var root_966 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_968 lang.IFn

			if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var root_970 any = A_arbace_repr_clojure_rules_A_const_92.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = text__11; var arg_974 any = A_arbace_repr_clojure_rules_A_const_93; var arg_975 any = A_arbace_repr_clojure_rules_A_const_94; if linked_971 == nil { arg_969 = ifn_972.Invoke_O_O_O__O(arg_973, arg_974, arg_975) } else { arg_969 = linked_971.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_970, arg_973, arg_974, arg_975) }; if linked_967 == nil { seq_1700000175__12 = ifn_968.Invoke_O__O(arg_969) } else { seq_1700000175__12 = linked_967.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_966, arg_969) }
//line :314:1
			var chunk_1700000176__13 any; var count_1700000177__14 int64 = 0; var i_1700000178__15 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1700000178__15, count_1700000177__14) { var l__16 any = lang.Indexed_Cast(chunk_1700000176__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1700000178__15)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__16, nil))); seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, i_1700000178__15 = seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1700000178__15); continue L2 } else { var temp__1927000414__auto____16 any; var root_976 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = seq_1700000175__12; if linked_977 == nil { temp__1927000414__auto____16 = ifn_978.Invoke_O__O(arg_979) } else { temp__1927000414__auto____16 = linked_977.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_976, arg_979) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1700000175__17 any = temp__1927000414__auto____16; var tmp4 any; var root_980 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = seq_1700000175__17; if linked_981 == nil { tmp4 = ifn_982.Invoke_O__O(arg_983) } else { tmp4 = linked_981.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_980, arg_983) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_984 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = seq_1700000175__17; if linked_985 == nil { c__1927000678__auto____18 = ifn_986.Invoke_O__O(arg_987) } else { c__1927000678__auto____18 = linked_985.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_984, arg_987) }; var tmp5 any; var root_992 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = seq_1700000175__17; if linked_993 == nil { tmp5 = ifn_994.Invoke_O__O(arg_995) } else { tmp5 = linked_993.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_992, arg_995) }; seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, i_1700000178__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var l__18 any; var root_988 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = seq_1700000175__17; if linked_989 == nil { l__18 = ifn_990.Invoke_O__O(arg_991) } else { l__18 = linked_989.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_988, arg_991) }; jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__18, nil))); var tmp6 any; var root_996 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = seq_1700000175__17; if linked_997 == nil { tmp6 = ifn_998.Invoke_O__O(arg_999) } else { tmp6 = linked_997.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_996, arg_999) }; seq_1700000175__12, chunk_1700000176__13, count_1700000177__14, i_1700000178__15 = tmp6, nil, 0, 0; continue L2 } } }
//line :314:1
				break L2 }; seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, i_1700000172__6 = seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1700000172__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_934 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = seq_1700000169__3; if linked_935 == nil { temp__1927000414__auto____7 = ifn_936.Invoke_O__O(arg_937) } else { temp__1927000414__auto____7 = linked_935.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_934, arg_937) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1700000169__8 any = temp__1927000414__auto____7; var tmp7 any; var root_938 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = seq_1700000169__8; if linked_939 == nil { tmp7 = ifn_940.Invoke_O__O(arg_941) } else { tmp7 = linked_939.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_938, arg_941) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_942 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = seq_1700000169__8; if linked_943 == nil { c__1927000678__auto____9 = ifn_944.Invoke_O__O(arg_945) } else { c__1927000678__auto____9 = linked_943.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_942, arg_945) }; var tmp8 any; var root_1000 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = seq_1700000169__8; if linked_1001 == nil { tmp8 = ifn_1002.Invoke_O__O(arg_1003) } else { tmp8 = linked_1001.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1000, arg_1003) }; seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, i_1700000172__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var map__1700000179__9 any; var root_946 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = seq_1700000169__8; if linked_947 == nil { map__1700000179__9 = ifn_948.Invoke_O__O(arg_949) } else { map__1700000179__9 = linked_947.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_946, arg_949) }; var map__1700000179__10 any; if lang.ISeq_InstanceOf(map__1700000179__9) { var tmp9 any; var root_950 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = map__1700000179__9; if linked_951 == nil { tmp9 = ifn_952.Invoke_O__O(arg_953) } else { tmp9 = linked_951.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_950, arg_953) }; if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_954 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = map__1700000179__9; if linked_955 == nil { tmp10 = ifn_956.Invoke_O__O(arg_957) } else { tmp10 = linked_955.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_954, arg_957) }; map__1700000179__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp10, jrt.Object_class.ArrayClass())).Ref() } else { var tmp11 any; var root_958 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = map__1700000179__9; if linked_959 == nil { tmp11 = ifn_960.Invoke_O__O(arg_961) } else { tmp11 = linked_959.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_958, arg_961) }; if jrt.J2g_Truth(tmp11) { var root_962 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = map__1700000179__9; if linked_963 == nil { map__1700000179__10 = ifn_964.Invoke_O__O(arg_965) } else { map__1700000179__10 = linked_963.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_962, arg_965) } } else { map__1700000179__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1700000179__10 = map__1700000179__9 }; var at__11 any = lang.RT_Get_O_O__O_NoInit(map__1700000179__10, A_arbace_repr_clojure_rules_A_const_89); var length__12 any = lang.RT_Get_O_O__O_NoInit(map__1700000179__10, A_arbace_repr_clojure_rules_A_const_90); var text__13 any = lang.RT_Get_O_O__O_NoInit(map__1700000179__10, A_arbace_repr_clojure_rules_A_const_91)
					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil, Lit_5, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, at__11, nil, length__12, nil)))
//line :314:1
					var seq_1700000181__14 any; var root_1004 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1006 lang.IFn

					if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any; var root_1008 any = A_arbace_repr_clojure_rules_A_const_92.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = text__13; var arg_1012 any = A_arbace_repr_clojure_rules_A_const_93; var arg_1013 any = A_arbace_repr_clojure_rules_A_const_94; if linked_1009 == nil { arg_1007 = ifn_1010.Invoke_O_O_O__O(arg_1011, arg_1012, arg_1013) } else { arg_1007 = linked_1009.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_1008, arg_1011, arg_1012, arg_1013) }; if linked_1005 == nil { seq_1700000181__14 = ifn_1006.Invoke_O__O(arg_1007) } else { seq_1700000181__14 = linked_1005.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1004, arg_1007) }
//line :314:1
					var chunk_1700000182__15 any; var count_1700000183__16 int64 = 0; var i_1700000184__17 int64 = 0; L3: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1700000184__17, count_1700000183__16) { var l__18_2 any = lang.Indexed_Cast(chunk_1700000182__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1700000184__17)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__18_2, nil))); seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, i_1700000184__17 = seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1700000184__17); continue L3 } else { var temp__1927000414__auto____18 any; var root_1014 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = seq_1700000181__14; if linked_1015 == nil { temp__1927000414__auto____18 = ifn_1016.Invoke_O__O(arg_1017) } else { temp__1927000414__auto____18 = linked_1015.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1014, arg_1017) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1700000181__19 any = temp__1927000414__auto____18; var tmp12 any; var root_1018 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = seq_1700000181__19; if linked_1019 == nil { tmp12 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp12 = linked_1019.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1018, arg_1021) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____20 any; var root_1022 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = seq_1700000181__19; if linked_1023 == nil { c__1927000678__auto____20 = ifn_1024.Invoke_O__O(arg_1025) } else { c__1927000678__auto____20 = linked_1023.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1022, arg_1025) }; var tmp13 any; var root_1030 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = seq_1700000181__19; if linked_1031 == nil { tmp13 = ifn_1032.Invoke_O__O(arg_1033) } else { tmp13 = linked_1031.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1030, arg_1033) }; seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, i_1700000184__17 = tmp13, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var l__20 any; var root_1026 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = seq_1700000181__19; if linked_1027 == nil { l__20 = ifn_1028.Invoke_O__O(arg_1029) } else { l__20 = linked_1027.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1026, arg_1029) }; jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_19), jrt.RefArrayOf(jrt.Object_class, nil, l__20, nil))); var tmp14 any; var root_1034 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = seq_1700000181__19; if linked_1035 == nil { tmp14 = ifn_1036.Invoke_O__O(arg_1037) } else { tmp14 = linked_1035.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1034, arg_1037) }; seq_1700000181__14, chunk_1700000182__15, count_1700000183__16, i_1700000184__17 = tmp14, nil, 0, 0; continue L3 } } }
//line :314:1
						break L3 }; var tmp15 any; var root_1038 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = seq_1700000169__8; if linked_1039 == nil { tmp15 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp15 = linked_1039.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1038, arg_1041) }; seq_1700000169__3, chunk_1700000170__4, count_1700000171__5, i_1700000172__6 = tmp15, nil, 0, 0; continue L1 } } }
//line :308:1
		break L1 }; var root_910 any =








	A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = sb__2; if linked_911 == nil { return ifn_912.Invoke_O__O(arg_913) } else { return linked_911.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_910, arg_913) } }

func A_arbace_repr_clojure_rules_full_split_A_New() *A_arbace_repr_clojure_rules_full_split_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_repr_clojure_rules_full_split_A) Ctor() {}
//line :319:1
func (t *A_arbace_repr_clojure_rules_full_split_A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(jrt.String_Cast(A_arbace_repr_clojure_rules_A_const_86.GetRawRoot__O())); if





	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return nil } else { var rest__3 any; var root_1042 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1044 lang.IFn
		if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = s__0; var arg_1046 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(i__2), int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_clojure_rules_A_const_86.GetRawRoot__O())))).Ref(); if linked_1043 == nil { rest__3 = ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { rest__3 = linked_1043.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) }
//line :325:1
		var bad__4 any; var tmp1 any = A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_New(); var tmp2 *jrt.Class; var fncls__1052 *jrt.Class = A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_fn_class
		if fncls__1052 == nil { var fncls__1052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_fn_class = fncls__1052d; tmp2 = fncls__1052d } else { tmp2 = fncls__1052 }; bad__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :325:1
		var ___5 any; var tmp3 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_22, rest__3); _ = ___5


		if or__1927000174__auto____5 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1053 any = A_arbace_repr_clojure_rules_A_const_96.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = rest__3; var arg_1057 any = Lit_19; if linked_1054 == nil { tmp3 = ifn_1055.Invoke_O_O__O(arg_1056, arg_1057) } else { tmp3 = linked_1054.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1053, arg_1056, arg_1057) } }; if jrt.J2g_Truth(tmp3) { ___5 = nil } else { ___5 = lang.IFn_Cast(bad__4).Invoke_O__O(Lit_23) }
//line :325:1
		var lines__6 any



		if lang.Util_Equiv_O_O__Z_NoInit(Lit_22, rest__3) { lines__6 = lang.PersistentVector_EMPTY.Ref() } else { var root_1058 any = A_arbace_repr_clojure_rules_A_const_92.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any; var root_1064 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = rest__3; var arg_1068 any = A_arbace_repr_clojure_rules_A_const_30; var arg_1069 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rest__3)))).Ref(); if linked_1065 == nil { arg_1061 = ifn_1066.Invoke_O_O_O__O(arg_1067, arg_1068, arg_1069) } else { arg_1061 = linked_1065.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1064, arg_1067, arg_1068, arg_1069) }; var arg_1062 any = A_arbace_repr_clojure_rules_A_const_97; var arg_1063 any = A_arbace_repr_clojure_rules_A_const_94; if linked_1059 == nil { lines__6 = ifn_1060.Invoke_O_O_O__O(arg_1061, arg_1062, arg_1063) } else { lines__6 = linked_1059.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_1058, arg_1061, arg_1062, arg_1063) } }
//line :325:1
		var recs__7 any; var tmp4 any = A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_New_O_O(bad__4, lines__6); var tmp5 *jrt.Class
		var fncls__1127 /*line :325:1*/*jrt.Class = A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_fn_class




		if fncls__1127 == nil { var fncls__1127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_fn_class = fncls__1127d; tmp5 = fncls__1127d } else { tmp5 = fncls__1127 }; recs__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :325:1
		var tmp6 any; var root_1128 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1130 lang.IFn













		if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = s__0; var arg_1132 any = A_arbace_repr_clojure_rules_A_const_30; var arg_1133 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1129 == nil { tmp6 = ifn_1130.Invoke_O_O_O__O(arg_1131, arg_1132, arg_1133) } else { tmp6 = linked_1129.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1128, arg_1131, arg_1132, arg_1133) }
//line :325:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp6, recs__7) } }
func A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_New() *A_arbace_repr_clojure_rules_full_split_bad__1700000189_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_bad__1700000189_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_repr_clojure_rules_full_split_bad__1700000189_A) Ctor() {}
//line :326:1
func (t *A_arbace_repr_clojure_rules_full_split_bad__1700000189_A) Invoke_O_O__O(self, p1__1700000186_SHARP___1 any) any { var tmp1 any; var root_1047 any = A_arbace_repr_clojure_rules_A_const_95.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1049 lang.IFn; if
																linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__1700000186_SHARP___1)).Ref(); var arg_1051 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1048 == nil { tmp1 = ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { tmp1 = linked_1048.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) }; /*line :326:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }



func A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_full_split_fn__1700000191_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_fn__1700000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :330:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_A) Ctor_O_O(c__bad, c__lines any) { t.F_bad = c__bad; t.F_lines = c__lines }
//line :330:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_A) Invoke_O__O(self any) any { { var ls__1 any; var t_ any = t.F_lines; t.F_lines = nil; ls__1 = t_; var out__2 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
												var tmp1 any; var root_1070 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = ls__1; if linked_1071 == nil { tmp1 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp1 = linked_1071.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1070, arg_1073) }; if jrt.J2g_Truth(tmp1) { return out__2 } else { var vec__1700000192__3 any = ls__1; var seq__1700000193__4 any; var root_1074 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1076 lang.IFn

		if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = vec__1700000192__3; if linked_1075 == nil { seq__1700000193__4 = ifn_1076.Invoke_O__O(arg_1077) } else { seq__1700000193__4 = linked_1075.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1074, arg_1077) }
//line :331:1
		var first__1700000194__5 any; var root_1078 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1080 lang.IFn

		if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = seq__1700000193__4; if linked_1079 == nil { first__1700000194__5 = ifn_1080.Invoke_O__O(arg_1081) } else { first__1700000194__5 = linked_1079.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1078, arg_1081) }
//line :331:1
		var seq__1700000193__6 any; var root_1082 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1084 lang.IFn

		if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = seq__1700000193__4; if linked_1083 == nil { seq__1700000193__6 = ifn_1084.Invoke_O__O(arg_1085) } else { seq__1700000193__6 = linked_1083.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1082, arg_1085) }
//line :331:1
		var h__7 any = first__1700000194__5; var more__8 any = seq__1700000193__6; var vec__1700000195__9 any; var or__1927000174__auto____9 any; var root_1086 any = A_arbace_repr_clojure_rules_A_const_98.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1088 lang.IFn


		if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = A_arbace_repr_clojure_rules_A_const_99; var arg_1090 any = h__7; if linked_1087 == nil { or__1927000174__auto____9 = ifn_1088.Invoke_O_O__O(arg_1089, arg_1090) } else { or__1927000174__auto____9 = linked_1087.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1086, arg_1089, arg_1090) }; if jrt.J2g_Truth(or__1927000174__auto____9) { vec__1700000195__9 = or__1927000174__auto____9 } else { vec__1700000195__9 = lang.IFn_Cast(t.F_bad).Invoke_O__O(h__7) }
//line :331:1
		var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000195__9, lang.RT_IntCast_J__I_NoInit(0), nil); var a__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000195__9, lang.RT_IntCast_J__I_NoInit(1), nil); var n__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000195__9, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__1700000198__13 any; var root_1091 any = A_arbace_repr_clojure_rules_A_const_100.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_1093 lang.IFn; _ = ___10



		if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var tmp2 any = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_New(); var tmp3 *jrt.Class; var fncls__1101 *jrt.Class = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_fn_class; if fncls__1101 == nil { var fncls__1101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_fn_class = fncls__1101d; tmp3 = fncls__1101d } else { tmp3 = fncls__1101 }; arg_1094 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1095 any = more__8; if linked_1092 == nil { vec__1700000198__13 = ifn_1093.Invoke_O_O__O(arg_1094, arg_1095) } else { vec__1700000198__13 = linked_1092.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_1091, arg_1094, arg_1095) }
//line :331:1
		var body__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000198__13, lang.RT_IntCast_J__I_NoInit(0), nil); var more__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000198__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 any; var root_1102 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1104 lang.IFn




		if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = body__14; if linked_1103 == nil { tmp4 = ifn_1104.Invoke_O__O(arg_1105) } else { tmp4 = linked_1103.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1102, arg_1105) }; if jrt.J2g_Truth(tmp4) { lang.IFn_Cast(t.F_bad).Invoke_O__O(h__7) }
		var tmp5 any; var root_1106 any = A_arbace_repr_clojure_rules_A_const_9.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1106, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = out__2; var arg_1110 any; var tmp6 any = A_arbace_repr_clojure_rules_A_const_89; var tmp7 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(a__11))).Ref(); var tmp8 any = A_arbace_repr_clojure_rules_A_const_90; var tmp9 any = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__12))).Ref(); var tmp10 any = A_arbace_repr_clojure_rules_A_const_91; var tmp11 any; var root_1111 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1113 lang.IFn
		if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = Lit_19; var arg_1115 any; var root_1116 any = A_arbace_repr_clojure_rules_A_const_36.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any; var tmp12 any = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_New(); var tmp13 *jrt.Class; var fncls__1126 *jrt.Class = A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_fn_class; if fncls__1126 == nil { var fncls__1126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_fn_class = fncls__1126d; tmp13 = fncls__1126d } else { tmp13 = fncls__1126 }; arg_1119 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_1120 any = body__14; if linked_1117 == nil { arg_1115 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { arg_1115 = linked_1117.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }; if linked_1112 == nil { tmp11 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { tmp11 = linked_1112.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }
//line :337:1
		arg_1110 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11)); if linked_1107 == nil { tmp5 = ifn_1108.Invoke_O_O__O(arg_1109, arg_1110) } else { tmp5 = linked_1107.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1106, arg_1109, arg_1110) }; ls__1, out__2 = more__15, tmp5; continue L1 } } }; /*line :330:1*/panic("j2g: unreachable") }




func A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_New() *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A) Ctor() {}
//line :335:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A) Invoke_O_O__O(self, p1__1700000187_SHARP___1 any) any { var root_1096 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = p1__1700000187_SHARP___1; var arg_1100 any = Lit_20; if linked_1097 == nil { return ifn_1098.Invoke_O_O__O(arg_1099, arg_1100) } else { return linked_1097.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1096, arg_1099, arg_1100) } }


func A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_New() *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A) Ctor() {}
//line :338:1
func (t *A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A) Invoke_O_O__O(self, p1__1700000188_SHARP___1 any) any { var root_1121 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = p1__1700000188_SHARP___1; var arg_1125 any = A_arbace_repr_clojure_rules_A_const_101; if linked_1122 == nil { return ifn_1123.Invoke_O_O__O(arg_1124, arg_1125) } else { return linked_1122.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1121, arg_1124, arg_1125) } }


func A_arbace_repr_clojure_rules_full_QMARK__A_New() *A_arbace_repr_clojure_rules_full_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_QMARK__A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_repr_clojure_rules_full_QMARK__A) Ctor() {}
//line :341:1
func (t *A_arbace_repr_clojure_rules_full_QMARK__A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 any; var root_1134 any = A_arbace_repr_clojure_rules_A_const_102.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, A_arbace_repr_clojure_rules_full_split_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = s__0; if linked_1135 == nil { tmp1 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp1 = linked_1135.(*A_arbace_repr_clojure_rules_full_split_A).Invoke_O_O__O(root_1134, arg_1137) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_repr_clojure_rules_full_ctx_QMARK__A_New() *A_arbace_repr_clojure_rules_full_ctx_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_full_ctx_QMARK__A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_repr_clojure_rules_full_ctx_QMARK__A) Ctor() {}
//line :346:1
func (t *A_arbace_repr_clojure_rules_full_ctx_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var and__1927000168__auto____2 any = A_arbace_repr_clojure_rules_A_const_103.Invoke_O__O(ctx__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_repr_clojure_rules_A_const_70; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0)); if and__1927000168__auto____3 { return A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_repr_clojure_rules_print_text_A_New() *A_arbace_repr_clojure_rules_print_text_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Ctor() {}
//line :348:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any { var temp__1927000408__auto____4 any; if







	jrt.J2g_Truth(A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__1)) { var root_1138 any = A_arbace_repr_clojure_rules_A_const_102.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, A_arbace_repr_clojure_rules_full_split_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = s__0; if linked_1139 == nil { temp__1927000408__auto____4 = ifn_1140.Invoke_O__O(arg_1141) } else { temp__1927000408__auto____4 = linked_1139.(*A_arbace_repr_clojure_rules_full_split_A).Invoke_O_O__O(root_1138, arg_1141) } } else { temp__1927000408__auto____4 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var vec__1700000209__5 any = temp__1927000408__auto____4; var body__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000209__5, lang.RT_IntCast_J__I_NoInit(0), nil); var recs__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000209__5, lang.RT_IntCast_J__I_NoInit(1), nil); var ctx__8 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_104.GetRawRoot__O()).Invoke_O_O_O_O_O__O(ctx__1, A_arbace_repr_clojure_rules_A_const_13, A_arbace_repr_clojure_rules_A_const_70, A_arbace_repr_clojure_rules_A_const_71, jrt.Boolean_TRUE.Ref()); var t__9 any; var root_1150 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1152 lang.IFn

		if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any; var tmp1 any = A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_New_O(ctx__8); var tmp2 *jrt.Class; var fncls__1156 *jrt.Class = A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_fn_class; if fncls__1156 == nil { var fncls__1156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_fn_class = fncls__1156d; tmp2 = fncls__1156d } else { tmp2 = fncls__1156 }; arg_1153 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1154 any = body__6; var arg_1155 any; var root_1157 any = A_arbace_repr_clojure_rules_A_const_106.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any; var root_1161 any = A_arbace_repr_clojure_rules_A_const_107.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = ctx__8; var arg_1165 any = skip__2; if linked_1162 == nil { arg_1160 = ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { arg_1160 = linked_1162.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) }; if linked_1158 == nil { arg_1155 = ifn_1159.Invoke_O__O(arg_1160) } else { arg_1155 = linked_1158.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_1157, arg_1160) }; if linked_1151 == nil { t__9 = ifn_1152.Invoke_O_O_O__O(arg_1153, arg_1154, arg_1155) } else { t__9 = linked_1151.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1150, arg_1153, arg_1154, arg_1155) }
		var root_1166 any = A_arbace_repr_clojure_rules_A_const_108.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = t__9; var arg_1170 any = recs__7; var arg_1171 any = A_arbace_repr_clojure_rules_A_const_73.Invoke_O_O__O(ctx__8, A_arbace_repr_clojure_rules_A_const_109); if linked_1167 == nil { return ifn_1168.Invoke_O_O_O__O(arg_1169, arg_1170, arg_1171) } else { return linked_1167.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A).Invoke_O_O_O_O__O(root_1166, arg_1169, arg_1170, arg_1171) } } else {
			var root_1172 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any; var tmp3 any = A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_New_O(ctx__1); var tmp4 *jrt.Class; var fncls__1178 *jrt.Class = A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_fn_class; if fncls__1178 == nil { var fncls__1178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_fn_class = fncls__1178d; tmp4 = fncls__1178d } else { tmp4 = fncls__1178 }; arg_1175 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1176 any = s__0; var arg_1177 any; var root_1179 any = A_arbace_repr_clojure_rules_A_const_106.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any; var root_1183 any = A_arbace_repr_clojure_rules_A_const_107.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = ctx__1; var arg_1187 any = skip__2; if linked_1184 == nil { arg_1182 = ifn_1185.Invoke_O_O__O(arg_1186, arg_1187) } else { arg_1182 = linked_1184.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_1183, arg_1186, arg_1187) }; if linked_1180 == nil { arg_1177 = ifn_1181.Invoke_O__O(arg_1182) } else { arg_1177 = linked_1180.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_1179, arg_1182) }; if linked_1173 == nil { return ifn_1174.Invoke_O_O_O__O(arg_1175, arg_1176, arg_1177) } else { return linked_1173.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1172, arg_1175, arg_1176, arg_1177) } } }
//line :348:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {





	var root_1188 any = A_arbace_repr_clojure_rules_A_const_110.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, A_arbace_repr_clojure_rules_print_text_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = s__0; var arg_1192 any = ctx__1; var arg_1193 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1189 == nil { return ifn_1190.Invoke_O_O_O__O(arg_1191, arg_1192, arg_1193) } else { return linked_1189.(*A_arbace_repr_clojure_rules_print_text_A).Invoke_O_O_O_O__O(root_1188, arg_1191, arg_1192, arg_1193)
	}
}

func A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_New_O(p0 any) *A_arbace_repr_clojure_rules_print_text_fn__1700000212_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_fn__1700000212_A{}; t.Ctor_O(p0); return t }
//line :358:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000212_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :358:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000212_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_105.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

func A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_New_O(p0 any) *A_arbace_repr_clojure_rules_print_text_fn__1700000214_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_fn__1700000214_A{}; t.Ctor_O(p0); return t }
//line :360:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000214_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :360:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000214_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_105.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

func A_arbace_repr_clojure_rules_translate_A_New() *A_arbace_repr_clojure_rules_translate_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_clojure_rules_translate_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any { var t__4 any; var root_1194 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1196 lang.IFn; if






	linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any; var tmp1 any = A_arbace_repr_clojure_rules_translate_fn__1700000217_A_New_O(ctx__1); var tmp2 *jrt.Class; var fncls__1200 *jrt.Class = A_arbace_repr_clojure_rules_translate_fn__1700000217_A_fn_class; if fncls__1200 == nil { var fncls__1200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_clojure_rules_translate_fn__1700000217_A_fn_class = fncls__1200d; tmp2 = fncls__1200d } else { tmp2 = fncls__1200 }; arg_1197 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1198 any = s__0; var arg_1199 any; var root_1201 any = A_arbace_repr_clojure_rules_A_const_107.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = ctx__1; var arg_1205 any = skip__2; if linked_1202 == nil { arg_1199 = ifn_1203.Invoke_O_O__O(arg_1204, arg_1205) } else { arg_1199 = linked_1202.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_1201, arg_1204, arg_1205) }; if linked_1195 == nil { t__4 = ifn_1196.Invoke_O_O_O__O(arg_1197, arg_1198, arg_1199) } else { t__4 = linked_1195.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1194, arg_1197, arg_1198, arg_1199) }; var tmp3 any; var root_1206 any =
	A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any; var root_1210 any = A_arbace_repr_clojure_rules_A_const_112.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, A_arbace_repr_clojure_rules_full_ctx_QMARK__A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = ctx__1; if linked_1211 == nil { arg_1209 = ifn_1212.Invoke_O__O(arg_1213) } else { arg_1209 = linked_1211.(*A_arbace_repr_clojure_rules_full_ctx_QMARK__A).Invoke_O_O__O(root_1210, arg_1213) }; if linked_1207 == nil { tmp3 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp3 = linked_1207.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1206, arg_1209) }; if jrt.J2g_Truth(tmp3) { return t__4 } else { var features__5 any = A_arbace_repr_clojure_rules_A_const_73.Invoke_O_O__O(ctx__1, A_arbace_repr_clojure_rules_A_const_117); var map__1700000219__6 any; var tmp4 any; var root_1214 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1216 lang.IFn



		if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = skip__2; var arg_1218 any = A_arbace_repr_clojure_rules_A_const_113; if linked_1215 == nil { tmp4 = ifn_1216.Invoke_O_O__O(arg_1217, arg_1218) } else { tmp4 = linked_1215.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1214, arg_1217, arg_1218) }; if jrt.J2g_Truth(tmp4) { map__1700000219__6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_91, s__0, A_arbace_repr_clojure_rules_A_const_114, lang.PersistentVector_EMPTY.Ref())) } else {

			var root_1219 any = A_arbace_repr_clojure_rules_A_const_115.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_record_conditionals_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = s__0; var arg_1223 any = features__5; if linked_1220 == nil { map__1700000219__6 = ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { map__1700000219__6 = linked_1220.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_record_conditionals_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) } }
//line :370:1
		var map__1700000219__7 any

		if lang.ISeq_InstanceOf(map__1700000219__6) { var tmp5 any; var root_1224 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = map__1700000219__6; if linked_1225 == nil { tmp5 = ifn_1226.Invoke_O__O(arg_1227) } else { tmp5 = linked_1225.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1224, arg_1227) }; if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_1228 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = map__1700000219__6; if linked_1229 == nil { tmp6 = ifn_1230.Invoke_O__O(arg_1231) } else { tmp6 = linked_1229.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1228, arg_1231) }; map__1700000219__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp6, jrt.Object_class.ArrayClass())).Ref() } else { var tmp7 any; var root_1232 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = map__1700000219__6; if linked_1233 == nil { tmp7 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp7 = linked_1233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1232, arg_1235) }; if jrt.J2g_Truth(tmp7) { var root_1236 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = map__1700000219__6; if linked_1237 == nil { map__1700000219__7 = ifn_1238.Invoke_O__O(arg_1239) } else { map__1700000219__7 = linked_1237.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1236, arg_1239) } } else { map__1700000219__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1700000219__7 = map__1700000219__6 }
//line :370:1
		var resolved__8 any = lang.RT_Get_O_O__O_NoInit(map__1700000219__7, A_arbace_repr_clojure_rules_A_const_91); var recs__9 any = lang.RT_Get_O_O__O_NoInit(map__1700000219__7, A_arbace_repr_clojure_rules_A_const_114); var tmp8 any; var root_1244 any = A_arbace_repr_clojure_rules_A_const_108.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A_fn_class); var ifn_1246 lang.IFn






		if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = resolved__8; var arg_1248 any = recs__9; var arg_1249 any = features__5; if linked_1245 == nil { tmp8 = ifn_1246.Invoke_O_O_O__O(arg_1247, arg_1248, arg_1249) } else { tmp8 = linked_1245.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_restore_conditionals_A).Invoke_O_O_O_O__O(root_1244, arg_1247, arg_1248, arg_1249) }; if lang.Util_Equiv_O_O__Z_NoInit(s__0, tmp8) { } else { var tmp9 any; var root_1250 any = A_arbace_repr_clojure_rules_A_const_95.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1252 lang.IFn
			if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = Lit_41; var arg_1254 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1251 == nil { tmp9 = ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { tmp9 = linked_1251.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) }
//line :377:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp9)))
		}
		var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp11 any; var root_1240 any = A_arbace_repr_clojure_rules_A_const_116.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, A_arbace_repr_clojure_rules_full_block_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = recs__9; if linked_1241 == nil { tmp11 = ifn_1242.Invoke_O__O(arg_1243) } else { tmp11 = linked_1241.(*A_arbace_repr_clojure_rules_full_block_A).Invoke_O_O__O(root_1240, arg_1243) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, t__4, tmp11)).Ref() } }
//line :362:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {




	var root_1255 any = A_arbace_repr_clojure_rules_A_const_118.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, A_arbace_repr_clojure_rules_translate_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = s__0; var arg_1259 any = ctx__1; var arg_1260 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1256 == nil { return ifn_1257.Invoke_O_O_O__O(arg_1258, arg_1259, arg_1260) } else { return linked_1256.(*A_arbace_repr_clojure_rules_translate_A).Invoke_O_O_O_O__O(root_1255, arg_1258, arg_1259, arg_1260)
	} }
func A_arbace_repr_clojure_rules_translate_fn__1700000217_A_New_O(p0 any) *A_arbace_repr_clojure_rules_translate_fn__1700000217_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_fn__1700000217_A{}; t.Ctor_O(p0); return t }
//line :369:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000217_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :369:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000217_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_111.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }




























type A_arbace_repr_clojure_rules_A struct{ jrt.Object }

var A_arbace_repr_clojure_rules_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rules_A_const_0 *lang.Var

var A_arbace_repr_clojure_rules_A_const_1 any

var A_arbace_repr_clojure_rules_A_const_2 any

var A_arbace_repr_clojure_rules_A_const_3 any

var A_arbace_repr_clojure_rules_A_const_4 *lang.Var

var A_arbace_repr_clojure_rules_A_const_5 any

var A_arbace_repr_clojure_rules_A_const_6 *lang.Var

var A_arbace_repr_clojure_rules_A_const_7 *lang.Var

var A_arbace_repr_clojure_rules_A_const_8 *lang.Var

var A_arbace_repr_clojure_rules_A_const_9 *lang.Var

var A_arbace_repr_clojure_rules_A_const_10 any

var A_arbace_repr_clojure_rules_A_const_11 *lang.Var

var A_arbace_repr_clojure_rules_A_const_12 any

var A_arbace_repr_clojure_rules_A_const_13 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_14 *lang.Var

var A_arbace_repr_clojure_rules_A_const_15 *lang.Var

var A_arbace_repr_clojure_rules_A_const_16 *lang.Var

var A_arbace_repr_clojure_rules_A_const_17 *lang.Var

var A_arbace_repr_clojure_rules_A_const_18 any

var A_arbace_repr_clojure_rules_A_const_19 *lang.Var

var A_arbace_repr_clojure_rules_A_const_20 *lang.Var

var A_arbace_repr_clojure_rules_A_const_21 *lang.Var

var A_arbace_repr_clojure_rules_A_const_22 *lang.Var

var A_arbace_repr_clojure_rules_A_const_23 *lang.Var

var A_arbace_repr_clojure_rules_A_const_24 *lang.Var

var A_arbace_repr_clojure_rules_A_const_25 *lang.Var

var A_arbace_repr_clojure_rules_A_const_26 *lang.Var

var A_arbace_repr_clojure_rules_A_const_27 *lang.Var

var A_arbace_repr_clojure_rules_A_const_28 *lang.Var

var A_arbace_repr_clojure_rules_A_const_29 *lang.Var

var A_arbace_repr_clojure_rules_A_const_30 any

var A_arbace_repr_clojure_rules_A_const_31 *lang.Var

var A_arbace_repr_clojure_rules_A_const_32 *lang.Var

var A_arbace_repr_clojure_rules_A_const_33 *lang.Var

var A_arbace_repr_clojure_rules_A_const_34 *lang.Var

var A_arbace_repr_clojure_rules_A_const_35 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_36 *lang.Var

var A_arbace_repr_clojure_rules_A_const_37 *lang.Var

var A_arbace_repr_clojure_rules_A_const_38 *lang.Var

var A_arbace_repr_clojure_rules_A_const_39 *lang.Var

var A_arbace_repr_clojure_rules_A_const_40 any

var A_arbace_repr_clojure_rules_A_const_41 *lang.Var

var A_arbace_repr_clojure_rules_A_const_42 *lang.Var

var A_arbace_repr_clojure_rules_A_const_43 *lang.Var

var A_arbace_repr_clojure_rules_A_const_44 *lang.Var

var A_arbace_repr_clojure_rules_A_const_45 *lang.Var

var A_arbace_repr_clojure_rules_A_const_46 *lang.Var

var A_arbace_repr_clojure_rules_A_const_47 any

var A_arbace_repr_clojure_rules_A_const_48 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_49 *lang.Var

var A_arbace_repr_clojure_rules_A_const_50 *lang.Var

var A_arbace_repr_clojure_rules_A_const_51 *lang.Var

var A_arbace_repr_clojure_rules_A_const_52 *lang.Var

var A_arbace_repr_clojure_rules_A_const_53 *lang.Var

var A_arbace_repr_clojure_rules_A_const_54 *lang.Var

var A_arbace_repr_clojure_rules_A_const_55 *lang.Var

var A_arbace_repr_clojure_rules_A_const_56 *lang.Var

var A_arbace_repr_clojure_rules_A_const_57 *lang.Var

var A_arbace_repr_clojure_rules_A_const_58 *lang.Var

var A_arbace_repr_clojure_rules_A_const_59 *lang.Var

var A_arbace_repr_clojure_rules_A_const_60 *lang.Var

var A_arbace_repr_clojure_rules_A_const_61 any

var A_arbace_repr_clojure_rules_A_const_62 *lang.Var

var A_arbace_repr_clojure_rules_A_const_63 any

var A_arbace_repr_clojure_rules_A_const_64 *lang.Var

var A_arbace_repr_clojure_rules_A_const_65 *lang.Var

var A_arbace_repr_clojure_rules_A_const_66 any

var A_arbace_repr_clojure_rules_A_const_67 *lang.Var

var A_arbace_repr_clojure_rules_A_const_68 any

var A_arbace_repr_clojure_rules_A_const_69 *lang.Var

var A_arbace_repr_clojure_rules_A_const_70 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_72 *lang.Var

var A_arbace_repr_clojure_rules_A_const_73 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_74 *lang.Var

var A_arbace_repr_clojure_rules_A_const_75 *lang.Var

var A_arbace_repr_clojure_rules_A_const_76 *lang.Var

var A_arbace_repr_clojure_rules_A_const_77 *lang.Var

var A_arbace_repr_clojure_rules_A_const_78 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_79 *lang.Var

var A_arbace_repr_clojure_rules_A_const_80 *lang.Var

var A_arbace_repr_clojure_rules_A_const_81 *lang.Var

var A_arbace_repr_clojure_rules_A_const_82 *lang.Var

var A_arbace_repr_clojure_rules_A_const_83 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_84 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_85 *lang.Var

var A_arbace_repr_clojure_rules_A_const_86 *lang.Var

var A_arbace_repr_clojure_rules_A_const_87 *lang.Var

var A_arbace_repr_clojure_rules_A_const_88 *lang.Var

var A_arbace_repr_clojure_rules_A_const_89 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_90 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_91 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_92 *lang.Var

var A_arbace_repr_clojure_rules_A_const_93 any

var A_arbace_repr_clojure_rules_A_const_94 any

var A_arbace_repr_clojure_rules_A_const_95 *lang.Var

var A_arbace_repr_clojure_rules_A_const_96 *lang.Var

var A_arbace_repr_clojure_rules_A_const_97 any

var A_arbace_repr_clojure_rules_A_const_98 *lang.Var

var A_arbace_repr_clojure_rules_A_const_99 any

var A_arbace_repr_clojure_rules_A_const_100 *lang.Var

var A_arbace_repr_clojure_rules_A_const_101 any

var A_arbace_repr_clojure_rules_A_const_102 *lang.Var

var A_arbace_repr_clojure_rules_A_const_103 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_104 *lang.Var

var A_arbace_repr_clojure_rules_A_const_105 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_106 *lang.Var

var A_arbace_repr_clojure_rules_A_const_107 *lang.Var

var A_arbace_repr_clojure_rules_A_const_108 *lang.Var

var A_arbace_repr_clojure_rules_A_const_109 any

var A_arbace_repr_clojure_rules_A_const_110 *lang.Var

var A_arbace_repr_clojure_rules_A_const_111 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_112 *lang.Var

var A_arbace_repr_clojure_rules_A_const_113 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_114 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_115 *lang.Var

var A_arbace_repr_clojure_rules_A_const_116 *lang.Var

var A_arbace_repr_clojure_rules_A_const_117 any

var A_arbace_repr_clojure_rules_A_const_118 *lang.Var

var A_arbace_repr_clojure_rules_A_init jrt.ClassInit

func A_arbace_repr_clojure_rules_A_Init() { if !A_arbace_repr_clojure_rules_A_init.Done() { A_arbace_repr_clojure_rules_A_init.Run(A_arbace_repr_clojure_rules_A_clinit) } }

func A_arbace_repr_clojure_rules_A_clinit() { A_arbace_repr_clojure_rules_A_clinit_p0(); A_arbace_repr_clojure_rules_A_clinit_p1(); A_arbace_repr_clojure_rules_A_clinit_p2(); A_arbace_repr_clojure_rules_A_clinit_p3(); A_arbace_repr_clojure_rules_A_clinit_p4(); A_arbace_repr_clojure_rules_A_clinit_p5(); A_arbace_repr_clojure_rules_A_clinit_p6(); A_arbace_repr_clojure_rules_A_clinit_p7(); A_arbace_repr_clojure_rules_A_clinit_p8(); A_arbace_repr_clojure_rules_A_clinit_p9() }

func A_arbace_repr_clojure_rules_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rules_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 146); A_arbace_repr_clojure_rules_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[27]); A_arbace_repr_clojure_rules_A_const_1 = A_arbace_repr_clojure_rules_A_const_pool.A[28]; A_arbace_repr_clojure_rules_A_const_2 = A_arbace_repr_clojure_rules_A_const_pool.A[29]; A_arbace_repr_clojure_rules_A_const_3 = A_arbace_repr_clojure_rules_A_const_pool.A[30]; A_arbace_repr_clojure_rules_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[31]); A_arbace_repr_clojure_rules_A_const_5 = A_arbace_repr_clojure_rules_A_const_pool.A[32]; A_arbace_repr_clojure_rules_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[33]); A_arbace_repr_clojure_rules_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[34]); A_arbace_repr_clojure_rules_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[35]); A_arbace_repr_clojure_rules_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[36]); A_arbace_repr_clojure_rules_A_const_10 = A_arbace_repr_clojure_rules_A_const_pool.A[37]; A_arbace_repr_clojure_rules_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[38]) }

func A_arbace_repr_clojure_rules_A_clinit_p1() { A_arbace_repr_clojure_rules_A_const_12 = A_arbace_repr_clojure_rules_A_const_pool.A[39]; A_arbace_repr_clojure_rules_A_const_13 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[40]); A_arbace_repr_clojure_rules_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[41]); A_arbace_repr_clojure_rules_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[42]); A_arbace_repr_clojure_rules_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[43]); A_arbace_repr_clojure_rules_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[44]); A_arbace_repr_clojure_rules_A_const_18 = A_arbace_repr_clojure_rules_A_const_pool.A[45]; A_arbace_repr_clojure_rules_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[46]); A_arbace_repr_clojure_rules_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[47]); A_arbace_repr_clojure_rules_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[48]); A_arbace_repr_clojure_rules_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[49]); A_arbace_repr_clojure_rules_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[50]) }

func A_arbace_repr_clojure_rules_A_clinit_p2() { A_arbace_repr_clojure_rules_A_const_24 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[51]); A_arbace_repr_clojure_rules_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[52]); A_arbace_repr_clojure_rules_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[53]); A_arbace_repr_clojure_rules_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[54]); A_arbace_repr_clojure_rules_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[55]); A_arbace_repr_clojure_rules_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[56]); A_arbace_repr_clojure_rules_A_const_30 = A_arbace_repr_clojure_rules_A_const_pool.A[57]; A_arbace_repr_clojure_rules_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[58]); A_arbace_repr_clojure_rules_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[59]); A_arbace_repr_clojure_rules_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[60]); A_arbace_repr_clojure_rules_A_const_34 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[61]); A_arbace_repr_clojure_rules_A_const_35 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[62]) }

func A_arbace_repr_clojure_rules_A_clinit_p3() { A_arbace_repr_clojure_rules_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[63]); A_arbace_repr_clojure_rules_A_const_37 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[64]); A_arbace_repr_clojure_rules_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[65]); A_arbace_repr_clojure_rules_A_const_39 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[66]); A_arbace_repr_clojure_rules_A_const_40 = A_arbace_repr_clojure_rules_A_const_pool.A[67]; A_arbace_repr_clojure_rules_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[68]); A_arbace_repr_clojure_rules_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[69]); A_arbace_repr_clojure_rules_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[70]); A_arbace_repr_clojure_rules_A_const_44 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[71]); A_arbace_repr_clojure_rules_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[72]); A_arbace_repr_clojure_rules_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[73]); A_arbace_repr_clojure_rules_A_const_47 = A_arbace_repr_clojure_rules_A_const_pool.A[74] }

func A_arbace_repr_clojure_rules_A_clinit_p4() { A_arbace_repr_clojure_rules_A_const_48 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[75]); A_arbace_repr_clojure_rules_A_const_49 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[76]); A_arbace_repr_clojure_rules_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[77]); A_arbace_repr_clojure_rules_A_const_51 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[78]); A_arbace_repr_clojure_rules_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[79]); A_arbace_repr_clojure_rules_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[80]); A_arbace_repr_clojure_rules_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[81]); A_arbace_repr_clojure_rules_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[82]); A_arbace_repr_clojure_rules_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[83]); A_arbace_repr_clojure_rules_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[84]); A_arbace_repr_clojure_rules_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[85]); A_arbace_repr_clojure_rules_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[86]) }

func A_arbace_repr_clojure_rules_A_clinit_p5() { A_arbace_repr_clojure_rules_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[87]); A_arbace_repr_clojure_rules_A_const_61 = A_arbace_repr_clojure_rules_A_const_pool.A[88]; A_arbace_repr_clojure_rules_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[89]); A_arbace_repr_clojure_rules_A_const_63 = A_arbace_repr_clojure_rules_A_const_pool.A[90]; A_arbace_repr_clojure_rules_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[91]); A_arbace_repr_clojure_rules_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[92]); A_arbace_repr_clojure_rules_A_const_66 = A_arbace_repr_clojure_rules_A_const_pool.A[93]; A_arbace_repr_clojure_rules_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[94]); A_arbace_repr_clojure_rules_A_const_68 = A_arbace_repr_clojure_rules_A_const_pool.A[95]; A_arbace_repr_clojure_rules_A_const_69 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[96]); A_arbace_repr_clojure_rules_A_const_70 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[97]); A_arbace_repr_clojure_rules_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[98]); A_arbace_repr_clojure_rules_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[99]) }

func A_arbace_repr_clojure_rules_A_clinit_p6() { A_arbace_repr_clojure_rules_A_const_73 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[100]); A_arbace_repr_clojure_rules_A_const_74 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[101]); A_arbace_repr_clojure_rules_A_const_75 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[102]); A_arbace_repr_clojure_rules_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[103]); A_arbace_repr_clojure_rules_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[104]); A_arbace_repr_clojure_rules_A_const_78 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[105]); A_arbace_repr_clojure_rules_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[106]); A_arbace_repr_clojure_rules_A_const_80 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[107]); A_arbace_repr_clojure_rules_A_const_81 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[108]); A_arbace_repr_clojure_rules_A_const_82 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[109]); A_arbace_repr_clojure_rules_A_const_83 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[110]); A_arbace_repr_clojure_rules_A_const_84 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[111]) }

func A_arbace_repr_clojure_rules_A_clinit_p7() { A_arbace_repr_clojure_rules_A_const_85 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[112]); A_arbace_repr_clojure_rules_A_const_86 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[113]); A_arbace_repr_clojure_rules_A_const_87 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[114]); A_arbace_repr_clojure_rules_A_const_88 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[115]); A_arbace_repr_clojure_rules_A_const_89 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[116]); A_arbace_repr_clojure_rules_A_const_90 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[117]); A_arbace_repr_clojure_rules_A_const_91 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[118]); A_arbace_repr_clojure_rules_A_const_92 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[119]); A_arbace_repr_clojure_rules_A_const_93 = A_arbace_repr_clojure_rules_A_const_pool.A[120]; A_arbace_repr_clojure_rules_A_const_94 = A_arbace_repr_clojure_rules_A_const_pool.A[121]; A_arbace_repr_clojure_rules_A_const_95 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[122]); A_arbace_repr_clojure_rules_A_const_96 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[123]) }

func A_arbace_repr_clojure_rules_A_clinit_p8() { A_arbace_repr_clojure_rules_A_const_97 = A_arbace_repr_clojure_rules_A_const_pool.A[124]; A_arbace_repr_clojure_rules_A_const_98 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[125]); A_arbace_repr_clojure_rules_A_const_99 = A_arbace_repr_clojure_rules_A_const_pool.A[126]; A_arbace_repr_clojure_rules_A_const_100 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[127]); A_arbace_repr_clojure_rules_A_const_101 = A_arbace_repr_clojure_rules_A_const_pool.A[128]; A_arbace_repr_clojure_rules_A_const_102 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[129]); A_arbace_repr_clojure_rules_A_const_103 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[130]); A_arbace_repr_clojure_rules_A_const_104 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[131]); A_arbace_repr_clojure_rules_A_const_105 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[132]); A_arbace_repr_clojure_rules_A_const_106 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[133]); A_arbace_repr_clojure_rules_A_const_107 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[134]); A_arbace_repr_clojure_rules_A_const_108 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[135]); A_arbace_repr_clojure_rules_A_const_109 = A_arbace_repr_clojure_rules_A_const_pool.A[136] }

func A_arbace_repr_clojure_rules_A_clinit_p9() { A_arbace_repr_clojure_rules_A_const_110 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[137]); A_arbace_repr_clojure_rules_A_const_111 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[138]); A_arbace_repr_clojure_rules_A_const_112 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[139]); A_arbace_repr_clojure_rules_A_const_113 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[140]); A_arbace_repr_clojure_rules_A_const_114 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[141]); A_arbace_repr_clojure_rules_A_const_115 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[142]); A_arbace_repr_clojure_rules_A_const_116 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[143]); A_arbace_repr_clojure_rules_A_const_117 = A_arbace_repr_clojure_rules_A_const_pool.A[144]; A_arbace_repr_clojure_rules_A_const_118 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[145]) }

func A_arbace_repr_clojure_rules_A_New() *A_arbace_repr_clojure_rules_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_A_class }

func (t *A_arbace_repr_clojure_rules_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_A); return ok }

func A_arbace_repr_clojure_rules_A_Cast(x any) *A_arbace_repr_clojure_rules_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_A_class)) }; return v }



type A_arbace_repr_clojure_rules_applicable_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_applicable_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_applicable_fn__1700000166_A struct{ j2g_header uint64; F_ctx, F_skip any }

var A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_clojure_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_cut_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_cut_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_defined_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A struct{ j2g_header uint64; F_iter__1700000101, F_s, F_s__1700000102 any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A struct{ j2g_header uint64; F_b__1700000104, F_s any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000004_A_New() *A_arbace_repr_clojure_rules_eval1700000004_A { t := &A_arbace_repr_clojure_rules_eval1700000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000004_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000004_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000004_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000008_A_New() *A_arbace_repr_clojure_rules_eval1700000008_A { t := &A_arbace_repr_clojure_rules_eval1700000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000008_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000008_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000008_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000143_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000143_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000145_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000145_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000147_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000147_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000149_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000149_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000151_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000151_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000153_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000153_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000155_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000155_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000157_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000157_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000159_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000159_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000161_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000161_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000163_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000163_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_block_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_block_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_ctx_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_ctx_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_bad__1700000189_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_bad__1700000189_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_fn__1700000191_A struct{ j2g_header uint64; F_bad, F_lines any }

var A_arbace_repr_clojure_rules_full_split_fn__1700000191_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000201_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_full_split_fn__1700000191_fn__1700000203_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_imports_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_insert_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_insert_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_print_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_fn__1700000212_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_print_text_fn__1700000212_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_fn__1700000214_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_print_text_fn__1700000214_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_security_manager_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A struct{ j2g_header uint64; F_sb, F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A struct{ j2g_header uint64; F_import_spans any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_translate_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_fn__1700000217_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_translate_fn__1700000217_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_uncore_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A struct{ j2g_header uint64; F_s, F_added any }

var A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unproxy_methods_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A struct{ j2g_header uint64; F_sb, F_s any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A struct{ j2g_header uint64; F_import_spans any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class *jrt.Class
