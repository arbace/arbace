//line aot_arbace_repr_clojure_rules.ae:1
package aot_arbace_repr_clojure_rules

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_clojure_rename"
	"arbace/aot_arbace_repr_clojure_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_New() *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_rules_A_const_1, A_arbace_repr_clojure_rules_A_const_2, A_arbace_repr_clojure_rules_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_New() *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_6.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_repr_clojure_rules_A_const_7.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_repr_clojure_rules_A_const_8; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_rules_A_const_9.GetRawRoot__O(), A_arbace_repr_clojure_rules_A_const_10) }





















func A_arbace_repr_clojure_rules_clojure_source_QMARK__A_New() *A_arbace_repr_clojure_rules_clojure_source_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_clojure_source_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var root_21 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_repr_clojure_rules_A_const_12; var arg_25 any = A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0); if linked_22 == nil { return ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { return linked_22.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_21, arg_24, arg_25) } }







func A_arbace_repr_clojure_rules_proxy_methods_A_New() *A_arbace_repr_clojure_rules_proxy_methods_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var root_33 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any; var tmp1 any = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New(); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; arg_36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_37 any = s__0; var arg_38 any = A_arbace_repr_clojure_rules_A_const_16.GetRawRoot__O(); if linked_34 == nil { return ifn_35.Invoke_O_O_O__O(arg_36, arg_37, arg_38) } else { return linked_34.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_33, arg_36, arg_37, arg_38) } }
//line :34:1
func A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New() *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Ctor() {}
//line :34:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Invoke_O_O_O__O(self, s__1, p__1700000013__2 any) any { var vec__1700000015__3 any = p__1700000013__2; var re__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_26 any = A_arbace_repr_clojure_rules_A_const_15.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = s__1; var arg_30 any = re__4; var arg_31 any = to__5; if linked_27 == nil { return ifn_28.Invoke_O_O_O__O(arg_29, arg_30, arg_31) } else { return linked_27.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_26, arg_29, arg_30, arg_31) } }





func A_arbace_repr_clojure_rules_unproxy_methods_A_New() *A_arbace_repr_clojure_rules_unproxy_methods_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unproxy_methods_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_A) Ctor() {}
//line :40:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var root_46 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var tmp1 any = A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_New(); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; arg_49 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_50 any = s__0; var arg_51 any = A_arbace_repr_clojure_rules_A_const_17.GetRawRoot__O(); if linked_47 == nil { return ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { return linked_47.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } }
//line :43:1
func A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_New() *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A) Ctor() {}
//line :43:1
func (t *A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A) Invoke_O_O_O__O(self, s__1, p__1700000020__2 any) any { var vec__1700000022__3 any = p__1700000020__2; var re__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000022__3, lang.RT_IntCast_J__I_NoInit(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000022__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_39 any = A_arbace_repr_clojure_rules_A_const_15.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__1; var arg_43 any = re__4; var arg_44 any = to__5; if linked_40 == nil { return ifn_41.Invoke_O_O_O__O(arg_42, arg_43, arg_44) } else { return linked_40.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_39, arg_42, arg_43, arg_44) } }





func A_arbace_repr_clojure_rules_imports_QMARK__A_New() *A_arbace_repr_clojure_rules_imports_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_imports_QMARK__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Ctor() {}
//line :49:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Invoke_O_O__O(self, head__0 any) any { var root_52 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = A_arbace_repr_clojure_rules_A_const_18; var arg_56 any = head__0; if linked_53 == nil { return ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { return linked_53.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_52, arg_55, arg_56) } }

func A_arbace_repr_clojure_rules_security_manager_A_New() *A_arbace_repr_clojure_rules_security_manager_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var root_62 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var root_57 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = s__0; var arg_61 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_58 == nil { arg_65 = ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { arg_65 = linked_58.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_57, arg_60, arg_61) }; if linked_63 == nil { tmp1 = ifn_64.Invoke_O__O(arg_65) } else { tmp1 = linked_63.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var import_spans__2 any; var root_66 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_68 lang.IFn

		if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = s__0; var arg_70 any = A_arbace_repr_clojure_rules_A_const_23.GetRawRoot__O(); if linked_67 == nil { import_spans__2 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { import_spans__2 = linked_67.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }
//line :55:1
		var in_import_QMARK___3 any; var tmp2 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_New_O(import_spans__2); var tmp3 *jrt.Class
		var fncls__87 /*line :55:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class


		if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :55:1
		var tokens__4 any; var root_104 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_106 lang.IFn



		if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any; var tmp4 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_New_O(s__0); var tmp5 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class = fncls__99d; tmp5 = fncls__99d } else { tmp5 = fncls__99 }; arg_107 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_108 any; var root_100 any = A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = s__0; if linked_101 == nil { arg_108 = ifn_102.Invoke_O__O(arg_103) } else { arg_108 = linked_101.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A).Invoke_O_O__O(root_100, arg_103) }; if linked_105 == nil { tokens__4 = ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { tokens__4 = linked_105.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) }
//line :55:1
		var imported_QMARK___5 any; var root_121 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_123 lang.IFn




		if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var tmp6 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_New_O_O(s__0, in_import_QMARK___3); var tmp7 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class = fncls__120d; tmp7 = fncls__120d } else { tmp7 = fncls__120 }; arg_124 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_125 any = tokens__4; if linked_122 == nil { imported_QMARK___5 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { imported_QMARK___5 = linked_122.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }
//line :55:1
		var uses__6 any; var root_142 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_144 lang.IFn







		if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var tmp8 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_New_O_O(s__0, in_import_QMARK___3); var tmp9 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class = fncls__141d; tmp9 = fncls__141d } else { tmp9 = fncls__141 }; arg_145 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_146 any = tokens__4; if linked_143 == nil { uses__6 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { uses__6 = linked_143.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_142, arg_145, arg_146)
		}



		var tmp10 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp10 = or__1927000174__auto____7 } else { var root_147 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = uses__6; if linked_148 == nil { tmp10 = ifn_149.Invoke_O__O(arg_150) } else { tmp10 = linked_148.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_147, arg_150) } }; if jrt.J2g_Truth(tmp10) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var root_152 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_154 lang.IFn


			if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any; var tmp11 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_New_O_O(sb__7, s__0); var tmp12 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class = fncls__151d; tmp12 = fncls__151d } else { tmp12 = fncls__151 }; arg_155 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_156 any = A_arbace_repr_clojure_rules_A_const_30; var arg_157 any = uses__6; if linked_153 == nil { end__8 = ifn_154.Invoke_O_O_O__O(arg_155, arg_156, arg_157) } else { end__8 = linked_153.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_152, arg_155, arg_156, arg_157)
			}



			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(end__8), lang.RT_Count_O__I_NoInit(s__0))
			var root_158 any = A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = sb__7; if linked_159 == nil { return ifn_160.Invoke_O__O(arg_161) } else { return linked_159.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_158, arg_161) } } } }
//line :58:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A) Invoke_O_O__O(self, i__1 any) any { var root_82 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any; var tmp1 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class = fncls__81d; tmp2 = fncls__81d } else { tmp2 = fncls__81 }; arg_85 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_86 any = t.F_import_spans; if linked_83 == nil { return ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { return linked_83.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) } }
//line :58:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :58:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A) Invoke_O_O__O(self, p__1700000029__1 any) any { var vec__1700000031__2 any = p__1700000029__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 bool; var na_71 any = a__3; var na_72 any = t.F_i; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_71); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_72) }; tmp1 = tmp2; if tmp1 { var n0_73 int64 = jrt.NN(jrt.Long_Cast(na_71)).LongValue__J(); var n1_74 int64 = jrt.NN(jrt.Long_Cast(na_72)).LongValue__J(); and__1927000168__auto____5 = n0_73 <= n1_74 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_71); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_72) }; tmp3 = tmp4; if tmp3 { var n0_73_2 float64 = jrt.NN(jrt.Double_Cast(na_71)).DoubleValue__D(); var n1_74_2 float64 = jrt.NN(jrt.Double_Cast(na_72)).DoubleValue__D(); and__1927000168__auto____5 = n0_73_2 <= n1_74_2 } else { and__1927000168__auto____5 = lang.Numbers_Lte_O_O__Z_NoInit(na_71, na_72) } }; if and__1927000168__auto____5 { var tmp5 bool; var na_76 any = t.F_i; var na_77 any = b__4; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_76); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_77) }; tmp6 = tmp7; if tmp6 { var n0_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); var n1_79 int64 = jrt.NN(jrt.Long_Cast(na_77)).LongValue__J(); tmp5 = n0_78 < n1_79 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_76); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_77) }; tmp8 = tmp9; if tmp8 { var n0_78_2 float64 = jrt.NN(jrt.Double_Cast(na_76)).DoubleValue__D(); var n1_79_2 float64 = jrt.NN(jrt.Double_Cast(na_77)).DoubleValue__D(); tmp5 = n0_78_2 < n1_79_2 } else { tmp5 = lang.Numbers_Lt_O_O__Z_NoInit(na_76, na_77) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A{}; t.Ctor_O(p0); return t }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A) Invoke_O_O__O(self, p__1700000036__1 any) any { var vec__1700000038__2 any = p__1700000036__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_94 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_88 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = t.F_s; var arg_92 any = a__3; var arg_93 any = b__4; if linked_89 == nil { arg_97 = ifn_90.Invoke_O_O_O__O(arg_91, arg_92, arg_93) } else { arg_97 = linked_89.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_88, arg_91, arg_92, arg_93) }; var arg_98 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_95 == nil { return ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { return linked_95.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_94, arg_97, arg_98) } }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :60:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :60:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A) Invoke_O_O__O(self, p__1700000042__1 any) any { var vec__1700000044__2 any = p__1700000042__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000044__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000044__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.J2g_Truth(and__1927000168__auto____5) {
															var root_115 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())).Ref())); var arg_119 any; var root_109 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t.F_s; var arg_113 any = a__3; var arg_114 any = b__4; if linked_110 == nil { arg_119 = ifn_111.Invoke_O_O_O__O(arg_112, arg_113, arg_114) } else { arg_119 = linked_110.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_109, arg_112, arg_113, arg_114) }; if linked_116 == nil { return ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { return linked_116.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_115, arg_118, arg_119) } } else {
//line :60:1
		return and__1927000168__auto____5 } }


func A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :63:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A) Invoke_O_O__O(self, p__1700000048__1 any) any { var vec__1700000050__2 any = p__1700000048__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000050__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000050__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t__5 any; var root_126 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_128 lang.IFn; if
															linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = t.F_s; var arg_130 any = a__3; var arg_131 any = b__4; if linked_127 == nil { t__5 = ifn_128.Invoke_O_O_O__O(arg_129, arg_130, arg_131) } else { t__5 = linked_127.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_126, arg_129, arg_130, arg_131) }; var and__1927000168__auto____6 any; var root_132 any = /*line :63:1*/A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_134 lang.IFn; if

	linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if linked_133 == nil { and__1927000168__auto____6 = ifn_134.Invoke_O__O(arg_135) } else { and__1927000168__auto____6 = linked_133.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_132, arg_135) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_136 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t__5; var arg_140 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_27), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(), nil)).Ref(); if linked_137 == nil { return ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { return linked_137.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_136, arg_139, arg_140) } } } } else {
//line :65:1
			return and__1927000168__auto____6 } }





func A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :71:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :71:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A) Invoke_O_O_O__O(self, i__1, p__1700000054__2 any) any { var vec__1700000056__3 any = p__1700000054__2; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000056__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000056__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
																jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(i__1), lang.RT_IntCast_O__I_NoInit(a__4)); var tmp3 /*line :73:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp3).Append_String__StringBuilder(Lit_25); return a__4 }









func A_arbace_repr_clojure_rules_unqualify_security_manager_A_New() *A_arbace_repr_clojure_rules_unqualify_security_manager_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_A) Invoke_O_O__O(self, s__0 any) any {





	var tmp1 any; var root_167 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any; var root_162 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = s__0; var arg_166 any = A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(); if linked_163 == nil { arg_170 = ifn_164.Invoke_O_O__O(arg_165, arg_166) } else { arg_170 = linked_163.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_162, arg_165, arg_166) }; if linked_168 == nil { tmp1 = ifn_169.Invoke_O__O(arg_170) } else { tmp1 = linked_168.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_167, arg_170) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var import_spans__2 any; var root_171 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_173 lang.IFn

		if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = s__0; var arg_175 any = A_arbace_repr_clojure_rules_A_const_23.GetRawRoot__O(); if linked_172 == nil { import_spans__2 = ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { import_spans__2 = linked_172.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) }
//line :89:1
		var in_import_QMARK___3 any; var tmp2 any = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_New_O(import_spans__2); var tmp3 *jrt.Class
		var fncls__192 /*line :89:1*/*jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class


		if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class = fncls__192d; tmp3 = fncls__192d } else { tmp3 = fncls__192 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :89:1
		var tokens__4 any; var root_209 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_211 lang.IFn



		if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var tmp4 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_New_O(s__0); var tmp5 *jrt.Class; var fncls__204 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class; if fncls__204 == nil { var fncls__204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class = fncls__204d; tmp5 = fncls__204d } else { tmp5 = fncls__204 }; arg_212 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_213 any; var root_205 any = A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = s__0; if linked_206 == nil { arg_213 = ifn_207.Invoke_O__O(arg_208) } else { arg_213 = linked_206.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_code_tokens_A).Invoke_O_O__O(root_205, arg_208) }; if linked_210 == nil { tokens__4 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tokens__4 = linked_210.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }
//line :89:1
		var imported_QMARK___5 any; var root_226 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_228 lang.IFn




		if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any; var tmp6 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_New_O_O(s__0, in_import_QMARK___3); var tmp7 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class = fncls__225d; tmp7 = fncls__225d } else { tmp7 = fncls__225 }; arg_229 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_230 any = tokens__4; if linked_227 == nil { imported_QMARK___5 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { imported_QMARK___5 = linked_227.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_226, arg_229, arg_230) }
//line :89:1
		var uses__6 any; var root_247 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_249 lang.IFn







		if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any; var tmp8 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_New_O_O(s__0, in_import_QMARK___3); var tmp9 *jrt.Class; var fncls__246 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class; if fncls__246 == nil { var fncls__246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class = fncls__246d; tmp9 = fncls__246d } else { tmp9 = fncls__246 }; arg_250 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_251 any = tokens__4; if linked_248 == nil { uses__6 = ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { uses__6 = linked_248.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_247, arg_250, arg_251)
		}




		var tmp10 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp10 = or__1927000174__auto____7 } else { var root_252 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = uses__6; if linked_253 == nil { tmp10 = ifn_254.Invoke_O__O(arg_255) } else { tmp10 = linked_253.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_252, arg_255) } }; if jrt.J2g_Truth(tmp10) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var root_262 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_264 lang.IFn


			if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any; var tmp11 any = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_New_O_O(sb__7, s__0); var tmp12 *jrt.Class; var fncls__261 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class; if fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class = fncls__261d; tmp12 = fncls__261d } else { tmp12 = fncls__261 }; arg_265 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_266 any = A_arbace_repr_clojure_rules_A_const_30; var arg_267 any = uses__6; if linked_263 == nil { end__8 = ifn_264.Invoke_O_O_O__O(arg_265, arg_266, arg_267) } else { end__8 = linked_263.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_262, arg_265, arg_266, arg_267)
			}


			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(end__8), lang.RT_Count_O__I_NoInit(s__0))
			var root_268 any = A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = sb__7; if linked_269 == nil { return ifn_270.Invoke_O__O(arg_271) } else { return linked_269.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_268, arg_271) } } } }
//line :92:1
func A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A) Invoke_O_O__O(self, i__1 any) any { var root_187 any = A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any; var tmp1 any = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class = fncls__186d; tmp2 = fncls__186d } else { tmp2 = fncls__186 }; arg_190 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_191 any = t.F_import_spans; if linked_188 == nil { return ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { return linked_188.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) } }
//line :92:1
func A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :92:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A) Invoke_O_O__O(self, p__1700000062__1 any) any { var vec__1700000064__2 any = p__1700000062__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000064__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000064__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 bool; var na_176 any = a__3; var na_177 any = t.F_i; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_176); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_177) }; tmp1 = tmp2; if tmp1 { var n0_178 int64 = jrt.NN(jrt.Long_Cast(na_176)).LongValue__J(); var n1_179 int64 = jrt.NN(jrt.Long_Cast(na_177)).LongValue__J(); and__1927000168__auto____5 = n0_178 <= n1_179 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_176); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_177) }; tmp3 = tmp4; if tmp3 { var n0_178_2 float64 = jrt.NN(jrt.Double_Cast(na_176)).DoubleValue__D(); var n1_179_2 float64 = jrt.NN(jrt.Double_Cast(na_177)).DoubleValue__D(); and__1927000168__auto____5 = n0_178_2 <= n1_179_2 } else { and__1927000168__auto____5 = lang.Numbers_Lte_O_O__Z_NoInit(na_176, na_177) } }; if and__1927000168__auto____5 { var tmp5 bool; var na_181 any = t.F_i; var na_182 any = b__4; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_181); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_182) }; tmp6 = tmp7; if tmp6 { var n0_183 int64 = jrt.NN(jrt.Long_Cast(na_181)).LongValue__J(); var n1_184 int64 = jrt.NN(jrt.Long_Cast(na_182)).LongValue__J(); tmp5 = n0_183 < n1_184 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_181); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_182) }; tmp8 = tmp9; if tmp8 { var n0_183_2 float64 = jrt.NN(jrt.Double_Cast(na_181)).DoubleValue__D(); var n1_184_2 float64 = jrt.NN(jrt.Double_Cast(na_182)).DoubleValue__D(); tmp5 = n0_183_2 < n1_184_2 } else { tmp5 = lang.Numbers_Lt_O_O__Z_NoInit(na_181, na_182) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_New_O(p0 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :93:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A) Invoke_O_O__O(self, p__1700000069__1 any) any { var vec__1700000071__2 any = p__1700000069__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000071__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000071__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_199 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_193 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = t.F_s; var arg_197 any = a__3; var arg_198 any = b__4; if linked_194 == nil { arg_202 = ifn_195.Invoke_O_O_O__O(arg_196, arg_197, arg_198) } else { arg_202 = linked_194.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_193, arg_196, arg_197, arg_198) }; var arg_203 any = A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O(); if linked_200 == nil { return ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { return linked_200.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_199, arg_202, arg_203) } }
func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :94:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A) Invoke_O_O__O(self, p__1700000075__1 any) any { var vec__1700000077__2 any = p__1700000075__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000077__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000077__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.J2g_Truth(and__1927000168__auto____5) {
																var root_220 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O())); var arg_224 any; var root_214 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = t.F_s; var arg_218 any = a__3; var arg_219 any = b__4; if linked_215 == nil { arg_224 = ifn_216.Invoke_O_O_O__O(arg_217, arg_218, arg_219) } else { arg_224 = linked_215.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_214, arg_217, arg_218, arg_219) }; if linked_221 == nil { return ifn_222.Invoke_O_O__O(arg_223, arg_224) } else { return linked_221.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_220, arg_223, arg_224) } } else {
//line :94:1
		return and__1927000168__auto____5 } }


func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A{}; t.Ctor_O_O(p0, p1); return t }
//line :97:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :97:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A) Invoke_O_O__O(self, p__1700000081__1 any) any { var vec__1700000083__2 any = p__1700000081__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t__5 any; var root_231 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_233 lang.IFn; if
																linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = t.F_s; var arg_235 any = a__3; var arg_236 any = b__4; if linked_232 == nil { t__5 = ifn_233.Invoke_O_O_O__O(arg_234, arg_235, arg_236) } else { t__5 = linked_232.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_231, arg_234, arg_235, arg_236) }; var and__1927000168__auto____6 any; var root_237 any = /*line :97:1*/A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_239 lang.IFn; if

	linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if linked_238 == nil { and__1927000168__auto____6 = ifn_239.Invoke_O__O(arg_240) } else { and__1927000168__auto____6 = linked_238.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_237, arg_240) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else {
			var root_241 any = A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = t__5; var arg_245 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_27), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O(), nil)).Ref(); if linked_242 == nil { return ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { return linked_242.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_241, arg_244, arg_245) } } } } else {
//line :99:1
				return and__1927000168__auto____6 } }






func A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :106:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :106:1
func (t *A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A) Invoke_O_O_O__O(self, i__1, p__1700000087__2 any) any { var vec__1700000089__3 any = p__1700000087__2; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000089__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000089__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
																	jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(i__1), lang.RT_IntCast_O__I_NoInit(a__4)); var na_256 any = a__4; var na_257 int64 =
																	int64(lang.RT_Count_O__I_NoInit(Lit_25)); if jrt.Long_InstanceOf(na_256) { var n0_258 int64 = jrt.NN(jrt.Long_Cast(na_256)).LongValue__J(); var n1_259 int64 = na_257; var nr_260 int64 = n0_258 + n1_259; if (n0_258^nr_260)&(n1_259^nr_260) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_260).Ref() } else { return lang.Numbers_Add_O_J__Number_NoInit(na_256, na_257) } } else { return lang.Numbers_Add_O_J__Number_NoInit(na_256, na_257) } }






func A_arbace_repr_clojure_rules_arbace_core_names_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Invoke_O__O(self any) any {



	var root_299 any = A_arbace_repr_clojure_rules_A_const_33.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_303 any; var root_286 any = A_arbace_repr_clojure_rules_A_const_34.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any; var root_273 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any; var tmp1 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_New(); var tmp2 *jrt.Class; var fncls__272 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class; if fncls__272 == nil { var fncls__272d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class = fncls__272d; tmp2 = fncls__272d } else { tmp2 = fncls__272 }; arg_276 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_274 == nil { arg_289 = ifn_275.Invoke_O__O(arg_276) } else { arg_289 = linked_274.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_273, arg_276) }; var arg_290 any; var root_282 any = A_arbace_repr_clojure_rules_A_const_36.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var tmp3 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_New(); var tmp4 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class; if fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class = fncls__281d; tmp4 = fncls__281d } else { tmp4 = fncls__281 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_283 == nil { arg_290 = ifn_284.Invoke_O__O(arg_285) } else { arg_290 = linked_283.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_282, arg_285) }; if linked_287 == nil { arg_303 = ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { arg_303 = linked_287.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) }; var arg_304 any; var root_295 any = A_arbace_repr_clojure_rules_A_const_38.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_297 lang.IFn
	if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any; var root_291 any = A_arbace_repr_clojure_rules_A_const_39.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_repr_clojure_rules_A_const_40; if linked_292 == nil { arg_298 = ifn_293.Invoke_O__O(arg_294) } else { arg_298 = linked_292.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_291, arg_294) }; if linked_296 == nil { arg_304 = ifn_297.Invoke_O__O(arg_298) } else { arg_304 = linked_296.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_295, arg_298) }
//line :119:1
	if linked_300 == nil { return ifn_301.Invoke_O_O_O__O(arg_302, arg_303, arg_304) } else { return linked_300.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_299, arg_302, arg_303, arg_304) } }
//line :119:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A) Invoke_O_O__O(self, p1__1700000094_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_clojure_rules_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1700000094_SHARP___1)))).Ref() }
//line :119:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A) Invoke_O_O__O(self, p1__1700000095_SHARP___1 any) any { var root_277 any = A_arbace_repr_clojure_rules_A_const_37.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = lang.Var_Cast(p1__1700000095_SHARP___1).F_sym.Ref(); if linked_278 == nil { return ifn_279.Invoke_O__O(arg_280) } else { return linked_278.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_277, arg_280) } }






func A_arbace_repr_clojure_rules_defined_names_A_New() *A_arbace_repr_clojure_rules_defined_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Invoke_O_O__O(self, s__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_New_O(s__0); var tmp2 *jrt.Class; var fncls__517 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class; if


	fncls__517 == nil { var fncls__517d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class = fncls__517d; tmp2 = fncls__517d } else { tmp2 = fncls__517 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_518 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = s__0; var arg_522 any = A_arbace_repr_clojure_rules_A_const_57.GetRawRoot__O(); if linked_519 == nil { tmp4 = ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { tmp4 = linked_519.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }; return tmp3.Invoke_O__O(tmp4) }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_New_O(p0 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A) Invoke_O_O__O(self, s__1700000102__1 any) any { var tmp1 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_New_O_O_O(self, t.F_s, s__1700000102__1); var tmp2 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class = fncls__516d; tmp2 = fncls__516d } else { tmp2 = fncls__516 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A) Ctor_O_O_O(c__iter__1700000101, c__s, c__s__1700000102 any) { t.F_iter__1700000101 = c__iter__1700000101; t.F_s = c__s; t.F_s__1700000102 = c__s__1700000102 }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A) Invoke_O__O(self any) any { { var s__1700000102__1 any; var t_ any = t.F_s__1700000102; t.F_s__1700000102 = nil; s__1700000102__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_305 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = s__1700000102__1; if linked_306 == nil { temp__1927000414__auto____2 = ifn_307.Invoke_O__O(arg_308) } else { temp__1927000414__auto____2 = linked_306.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_305, arg_308) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1700000102__3 any = temp__1927000414__auto____2; var tmp1 any; var root_309 any = A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__1700000102__3; if linked_310 == nil { tmp1 = ifn_311.Invoke_O__O(arg_312) } else { tmp1 = linked_310.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_309, arg_312) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_313 any = A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = s__1700000102__3; if linked_314 == nil { c__1927001037__auto____4 = ifn_315.Invoke_O__O(arg_316) } else { c__1927001037__auto____4 = linked_314.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_313, arg_316) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1700000104__6 any; var root_317 any = A_arbace_repr_clojure_rules_A_const_44.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_318 == nil { b__1700000104__6 = ifn_319.Invoke_O__O(arg_320) } else { b__1700000104__6 = linked_318.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_317, arg_320) }; var tmp2 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_New_O_O_I_O(b__1700000104__6, t.F_s, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__401 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class; if fncls__401 == nil { var fncls__401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class = fncls__401d; tmp3 = fncls__401d } else { tmp3 = fncls__401 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_410 any = A_arbace_repr_clojure_rules_A_const_51.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var root_402 any = A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = b__1700000104__6; if linked_403 == nil { arg_413 = ifn_404.Invoke_O__O(arg_405) } else { arg_413 = linked_403.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_402, arg_405) }; var arg_414 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1700000101); var tmp5 any; var root_406 any = A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = s__1700000102__3; if linked_407 == nil { tmp5 = ifn_408.Invoke_O__O(arg_409) } else { tmp5 = linked_407.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_406, arg_409) }; arg_414 = tmp4.Invoke_O__O(tmp5); if linked_411 == nil { return ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { return linked_411.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) } } else { var root_419 any = A_arbace_repr_clojure_rules_A_const_51.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any; var root_415 any = A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = b__1700000104__6; if linked_416 == nil { arg_422 = ifn_417.Invoke_O__O(arg_418) } else { arg_422 = linked_416.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_415, arg_418) }; var arg_423 any; if linked_420 == nil { return ifn_421.Invoke_O_O__O(arg_422, arg_423) } else { return linked_420.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_419, arg_422, arg_423) } } } else { var vec__1700000114__4 any; var root_424 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = s__1700000102__3; if linked_425 == nil { vec__1700000114__4 = ifn_426.Invoke_O__O(arg_427) } else { vec__1700000114__4 = linked_425.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_424, arg_427) }; var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000114__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000114__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any; var root_430 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_432 lang.IFn; _ = ___6
																if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = t.F_s; var arg_434 any; var na_428 any = a__5; if jrt.Long_InstanceOf(na_428) { var n0_429 int64 = jrt.NN(jrt.Long_Cast(na_428)).LongValue__J(); if n0_429 == 9223372036854775807 { arg_434 = lang.Numbers_Inc_O__Number_NoInit(na_428) } else { arg_434 = jrt.Long_ValueOf_J__Long_NoInit(n0_429 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_428) { var n0_429_2 float64 = jrt.NN(jrt.Double_Cast(na_428)).DoubleValue__D(); arg_434 = jrt.Double_ValueOf_D__Double_NoInit(n0_429_2 + 1.0).Ref() } else { arg_434 = lang.Numbers_Inc_O__Number_NoInit(na_428) } }; if linked_431 == nil { h__7 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { h__7 = linked_431.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }
//line :129:1
	var j__8 any; var tmp6 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_New_O_O(h__7, t.F_s); var tmp7 *jrt.Class
	var fncls__487 /*line :129:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class

	if fncls__487 == nil { var fncls__487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class = fncls__487d; tmp7 = fncls__487d } else { tmp7 = fncls__487 }; j__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :129:1
	var t__9 any; var root_493 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_495 lang.IFn









	if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = t.F_s; var arg_497 any = j__8; var arg_498 any; var root_488 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = t.F_s; var arg_492 any = j__8; if linked_489 == nil { arg_498 = ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { arg_498 = linked_489.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) }; if linked_494 == nil { t__9 = ifn_495.Invoke_O_O_O__O(arg_496, arg_497, arg_498) } else { t__9 = linked_494.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_493, arg_496, arg_497, arg_498) }
//line :129:1
	var tmp8 any; var root_499 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_501 lang.IFn










	if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = t__9; if linked_500 == nil { tmp8 = ifn_501.Invoke_O__O(arg_502) } else { tmp8 = linked_500.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_499, arg_502) }
//line :129:1
	if jrt.J2g_Truth(tmp8) { var root_507 any = A_arbace_repr_clojure_rules_A_const_55.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = t__9; var arg_511 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1700000101); var tmp10 any; var root_503 any = A_arbace_repr_clojure_rules_A_const_56.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = s__1700000102__3; if linked_504 == nil { tmp10 = ifn_505.Invoke_O__O(arg_506) } else { tmp10 = linked_504.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_503, arg_506) }; arg_511 = tmp9.Invoke_O__O(tmp10); if linked_508 == nil { return ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { return linked_508.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) } } else { var tmp11 any; var root_512 any = A_arbace_repr_clojure_rules_A_const_56.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = s__1700000102__3; if linked_513 == nil { tmp11 = ifn_514.Invoke_O__O(arg_515) } else { tmp11 = linked_513.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_512, arg_515) }; s__1700000102__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :129:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A) Ctor_O_O_I_O(c__b__1700000104, c__s any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1700000104 = c__b__1700000104; t.F_s = c__s; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :129:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A) Invoke_O__O(self any) any { { var i__1700000103__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1700000103__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1700000108__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1700000103__1)); var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000108__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000108__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any; var root_323 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_325 lang.IFn; _ = ___4
																		if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = t.F_s; var arg_327 any; var na_321 any = a__3; if jrt.Long_InstanceOf(na_321) { var n0_322 int64 = jrt.NN(jrt.Long_Cast(na_321)).LongValue__J(); if n0_322 == 9223372036854775807 { arg_327 = lang.Numbers_Inc_O__Number_NoInit(na_321) } else { arg_327 = jrt.Long_ValueOf_J__Long_NoInit(n0_322 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_321) { var n0_322_2 float64 = jrt.NN(jrt.Double_Cast(na_321)).DoubleValue__D(); arg_327 = jrt.Double_ValueOf_D__Double_NoInit(n0_322_2 + 1.0).Ref() } else { arg_327 = lang.Numbers_Inc_O__Number_NoInit(na_321) } }; if linked_324 == nil { h__5 = ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { h__5 = linked_324.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_323, arg_326, arg_327) }
//line :129:1
	var j__6 any; var tmp2 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_New_O_O(h__5, t.F_s); var tmp3 *jrt.Class
	var fncls__380 /*line :129:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class

	if fncls__380 == nil { var fncls__380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class = fncls__380d; tmp3 = fncls__380d } else { tmp3 = fncls__380 }; j__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :129:1
	var t__7 any; var root_386 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_388 lang.IFn









	if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = t.F_s; var arg_390 any = j__6; var arg_391 any; var root_381 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = t.F_s; var arg_385 any = j__6; if linked_382 == nil { arg_391 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { arg_391 = linked_382.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) }; if linked_387 == nil { t__7 = ifn_388.Invoke_O_O_O__O(arg_389, arg_390, arg_391) } else { t__7 = linked_387.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_386, arg_389, arg_390, arg_391) }
//line :129:1
	var tmp4 any; var root_392 any = A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_394 lang.IFn










	if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = t__7; if linked_393 == nil { tmp4 = ifn_394.Invoke_O__O(arg_395) } else { tmp4 = linked_393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_392, arg_395) }
//line :129:1
	if jrt.J2g_Truth(tmp4) { var root_396 any = A_arbace_repr_clojure_rules_A_const_50.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = t.F_b__1700000104; var arg_400 any = t__7; if linked_397 == nil { ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { linked_397.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) }; i__1700000103__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000103__1); continue L1 } else { i__1700000103__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000103__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A) Invoke_O__O(self any) any { { var j__1 any; var root_333 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = t.F_s; var arg_337 any; var root_328 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = t.F_s; var arg_332 any; var t_ any = t.F_h; t.F_h = nil; arg_332 = t_; if linked_329 == nil { arg_337 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { arg_337 = linked_329.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; if linked_334 == nil { j__1 = ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { j__1 = linked_334.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) }; L1: for {

	var tmp1 bool; var na_338 any = j__1; var na_339 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_338) { var n0_340 int64 = jrt.NN(jrt.Long_Cast(na_338)).LongValue__J(); var n1_341 int64 = na_339; tmp1 = n0_340 >= n1_341 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_338, na_339) }; if tmp1 { return j__1 } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_47)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp3 any; var root_355 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = t.F_s; var arg_359 any; var root_350 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = t.F_s; var arg_354 any; var root_345 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = t.F_s; var arg_349 any; var na_343 any = j__1; if jrt.Long_InstanceOf(na_343) { var n0_344 int64 = jrt.NN(jrt.Long_Cast(na_343)).LongValue__J(); if n0_344 == 9223372036854775807 { arg_349 = lang.Numbers_Inc_O__Number_NoInit(na_343) } else { arg_349 = jrt.Long_ValueOf_J__Long_NoInit(n0_344 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_343) { var n0_344_2 float64 = jrt.NN(jrt.Double_Cast(na_343)).DoubleValue__D(); arg_349 = jrt.Double_ValueOf_D__Double_NoInit(n0_344_2 + 1.0).Ref() } else { arg_349 = lang.Numbers_Inc_O__Number_NoInit(na_343) } }; if linked_346 == nil { arg_354 = ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { arg_354 = linked_346.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) }; if linked_351 == nil { arg_359 = ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { arg_359 = linked_351.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) }; if linked_356 == nil { tmp3 = ifn_357.Invoke_O_O__O(arg_358, arg_359) } else { tmp3 = linked_356.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_355, arg_358, arg_359) }; j__1 = tmp3; continue L1 } else {
//line :133:1
			var tmp4 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp4).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp5 any; var root_375 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = t.F_s; var arg_379 any; var root_370 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = t.F_s; var arg_374 any; var root_365 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = t.F_s; var arg_369 any; var na_360 any = j__1; var na_361 int64 = 2; if jrt.Long_InstanceOf(na_360) { var n0_362 int64 = jrt.NN(jrt.Long_Cast(na_360)).LongValue__J(); var n1_363 int64 = na_361; var nr_364 int64 = n0_362 + n1_363; if (n0_362^nr_364)&(n1_363^nr_364) >= 0 { arg_369 = jrt.Long_ValueOf_J__Long_NoInit(nr_364).Ref() } else { arg_369 = lang.Numbers_Add_O_J__Number_NoInit(na_360, na_361) } } else { arg_369 = lang.Numbers_Add_O_J__Number_NoInit(na_360, na_361) }; if linked_366 == nil { arg_374 = ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { arg_374 = linked_366.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) }; if linked_371 == nil { arg_379 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { arg_379 = linked_371.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; if linked_376 == nil { tmp5 = ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { tmp5 = linked_376.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) }; j__1 = tmp5; continue L1 } else {
//line :133:1
					if A_arbace_repr_clojure_rules_A_const_48 != nil { return j__1 } else { return nil } } } } } }; /*line :131:1*/panic("j2g: unreachable") }
//line :131:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A) Invoke_O__O(self any) any { { var j__1 any; var root_440 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = t.F_s; var arg_444 any; var root_435 any = A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = t.F_s; var arg_439 any; var t_ any = t.F_h; t.F_h = nil; arg_439 = t_; if linked_436 == nil { arg_444 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { arg_444 = linked_436.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; if linked_441 == nil { j__1 = ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { j__1 = linked_441.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }; L1: for {

	var tmp1 bool; var na_445 any = j__1; var na_446 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_445) { var n0_447 int64 = jrt.NN(jrt.Long_Cast(na_445)).LongValue__J(); var n1_448 int64 = na_446; tmp1 = n0_447 >= n1_448 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_445, na_446) }; if tmp1 { return j__1 } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_47)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp3 any; var root_462 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = t.F_s; var arg_466 any; var root_457 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = t.F_s; var arg_461 any; var root_452 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = t.F_s; var arg_456 any; var na_450 any = j__1; if jrt.Long_InstanceOf(na_450) { var n0_451 int64 = jrt.NN(jrt.Long_Cast(na_450)).LongValue__J(); if n0_451 == 9223372036854775807 { arg_456 = lang.Numbers_Inc_O__Number_NoInit(na_450) } else { arg_456 = jrt.Long_ValueOf_J__Long_NoInit(n0_451 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_450) { var n0_451_2 float64 = jrt.NN(jrt.Double_Cast(na_450)).DoubleValue__D(); arg_456 = jrt.Double_ValueOf_D__Double_NoInit(n0_451_2 + 1.0).Ref() } else { arg_456 = lang.Numbers_Inc_O__Number_NoInit(na_450) } }; if linked_453 == nil { arg_461 = ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { arg_461 = linked_453.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_452, arg_455, arg_456) }; if linked_458 == nil { arg_466 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { arg_466 = linked_458.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }; if linked_463 == nil { tmp3 = ifn_464.Invoke_O_O__O(arg_465, arg_466) } else { tmp3 = linked_463.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_462, arg_465, arg_466) }; j__1 = tmp3; continue L1 } else {
//line :133:1
			var tmp4 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp4).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp5 any; var root_482 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = t.F_s; var arg_486 any; var root_477 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = t.F_s; var arg_481 any; var root_472 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = t.F_s; var arg_476 any; var na_467 any = j__1; var na_468 int64 = 2; if jrt.Long_InstanceOf(na_467) { var n0_469 int64 = jrt.NN(jrt.Long_Cast(na_467)).LongValue__J(); var n1_470 int64 = na_468; var nr_471 int64 = n0_469 + n1_470; if (n0_469^nr_471)&(n1_470^nr_471) >= 0 { arg_476 = jrt.Long_ValueOf_J__Long_NoInit(nr_471).Ref() } else { arg_476 = lang.Numbers_Add_O_J__Number_NoInit(na_467, na_468) } } else { arg_476 = lang.Numbers_Add_O_J__Number_NoInit(na_467, na_468) }; if linked_473 == nil { arg_481 = ifn_474.Invoke_O_O__O(arg_475, arg_476) } else { arg_481 = linked_473.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_472, arg_475, arg_476) }; if linked_478 == nil { arg_486 = ifn_479.Invoke_O_O__O(arg_480, arg_481) } else { arg_486 = linked_478.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_477, arg_480, arg_481) }; if linked_483 == nil { tmp5 = ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { tmp5 = linked_483.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) }; j__1 = tmp5; continue L1 } else {
//line :133:1
					if A_arbace_repr_clojure_rules_A_const_48 != nil { return j__1 } else { return nil } } } } } }; /*line :131:1*/panic("j2g: unreachable") }











func A_arbace_repr_clojure_rules_insert_at_A_New() *A_arbace_repr_clojure_rules_insert_at_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_insert_at_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Ctor() {}
//line :143:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Invoke_O_O_O_O__O(self, s__0, i__1, x__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 any; var root_523 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = s__0; var arg_527 any = A_arbace_repr_clojure_rules_A_const_30; var arg_528 any = i__1; if linked_524 == nil { tmp2 = ifn_525.Invoke_O_O_O__O(arg_526, arg_527, arg_528) } else { tmp2 = linked_524.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_523, arg_526, arg_527, arg_528) }; var tmp3 any = tmp2; var tmp4 any; var root_529 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = s__0; var arg_533 any = i__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, x__2, tmp4)).Ref() }

func A_arbace_repr_clojure_rules_core_names_A_New() *A_arbace_repr_clojure_rules_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_core_names_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Ctor() {}
//line :145:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any; var root_547 any = A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_549 lang.IFn; if






	linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var root_543 any = A_arbace_repr_clojure_rules_A_const_59.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any; var root_538 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = added__1; var arg_542 any; var root_534 any = A_arbace_repr_clojure_rules_A_const_60.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, A_arbace_repr_clojure_rules_defined_names_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = s__0; if linked_535 == nil { arg_542 = ifn_536.Invoke_O__O(arg_537) } else { arg_542 = linked_535.(*A_arbace_repr_clojure_rules_defined_names_A).Invoke_O_O__O(root_534, arg_537) }; if linked_539 == nil { arg_546 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { arg_546 = linked_539.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }; if linked_544 == nil { arg_550 = ifn_545.Invoke_O__O(arg_546) } else { arg_550 = linked_544.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_543, arg_546) }; if linked_548 == nil { names__3 = ifn_549.Invoke_O__O(arg_550) } else { names__3 = linked_548.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_547, arg_550) }; var vec__1700000123__4 any; var root_556 any = /*line :145:1*/A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_558 lang.IFn; if







	linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any; var root_551 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = s__0; var arg_555 any = A_arbace_repr_clojure_rules_A_const_61; if linked_552 == nil { arg_559 = ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { arg_559 = linked_552.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) }; if linked_557 == nil { vec__1700000123__4 = ifn_558.Invoke_O__O(arg_559) } else { vec__1700000123__4 = linked_557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_556, arg_559) }; var ns_a__5 any = /*line :145:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1700000123__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000123__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any; var root_560 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_562 lang.IFn; if








	linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = names__3; if linked_561 == nil { or__1927000174__auto____7 = ifn_562.Invoke_O__O(arg_563) } else { or__1927000174__auto____7 = linked_561.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_560, arg_563) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ns_a__5, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var ns_text__7 any; var root_564 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_566 lang.IFn

		if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__0; var arg_568 any = ns_a__5; var arg_569 any = ns_b__6; if linked_565 == nil { ns_text__7 = ifn_566.Invoke_O_O_O__O(arg_567, arg_568, arg_569) } else { ns_text__7 = linked_565.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_564, arg_567, arg_568, arg_569) }
//line :154:1
		var names_text__8 any; var root_570 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_572 lang.IFn


		if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = Lit_5; var arg_574 any = names__3; if linked_571 == nil { names_text__8 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { names_text__8 = linked_571.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }
//line :154:1
		var vec__1700000126__9 any; var root_580 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_582 lang.IFn



		if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any; var root_575 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = ns_text__7; var arg_579 any = A_arbace_repr_clojure_rules_A_const_63; if linked_576 == nil { arg_583 = ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { arg_583 = linked_576.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }; if linked_581 == nil { vec__1700000126__9 = ifn_582.Invoke_O__O(arg_583) } else { vec__1700000126__9 = linked_581.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_580, arg_583) }
//line :154:1
		var ra__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000126__9, lang.RT_IntCast_J__I_NoInit(0), nil); var rb__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000126__9, lang.RT_IntCast_J__I_NoInit(1), nil)




		if lang.Util_Identical_O_O__Z_NoInit(ra__10, nil) {

			var root_586 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = s__0; var arg_590 any; var na_584 any = ns_b__6; if jrt.Long_InstanceOf(na_584) { var n0_585 int64 = jrt.NN(jrt.Long_Cast(na_584)).LongValue__J(); if n0_585 == -9223372036854775808 { arg_590 = lang.Numbers_Dec_O__Number_NoInit(na_584) } else { arg_590 = jrt.Long_ValueOf_J__Long_NoInit(n0_585 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_584) { var n0_585_2 float64 = jrt.NN(jrt.Double_Cast(na_584)).DoubleValue__D(); arg_590 = jrt.Double_ValueOf_D__Double_NoInit(n0_585_2 - 1.0).Ref() } else { arg_590 = lang.Numbers_Dec_O__Number_NoInit(na_584) } }; var arg_591 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref(); if linked_587 == nil { return ifn_588.Invoke_O_O_O__O(arg_589, arg_590, arg_591) } else { return linked_587.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_586, arg_589, arg_590, arg_591) } } else {
//line :159:1
				var tmp2 any; var root_598 any = A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_600 lang.IFn


				if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any; var root_592 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = ns_text__7; var arg_596 any = ra__10; var arg_597 any = rb__11; if linked_593 == nil { arg_601 = ifn_594.Invoke_O_O_O__O(arg_595, arg_596, arg_597) } else { arg_601 = linked_593.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_592, arg_595, arg_596, arg_597) }; var arg_602 any = Lit_8; if linked_599 == nil { tmp2 = ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { tmp2 = linked_599.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_598, arg_601, arg_602) }
//line :159:1
				if jrt.J2g_Truth(tmp2) { return s__0 } else { if A_arbace_repr_clojure_rules_A_const_48 != nil { var rc__12 any; var root_603 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_605 lang.IFn





					if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = ns_text__7; var arg_607 any = ra__10; var arg_608 any = rb__11; if linked_604 == nil { rc__12 = ifn_605.Invoke_O_O_O__O(arg_606, arg_607, arg_608) } else { rc__12 = linked_604.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_603, arg_606, arg_607, arg_608) }
//line :159:1
					var ex__13 any; var root_609 any = A_arbace_repr_clojure_rules_A_const_65.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_611 lang.IFn






					if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = rc__12; var arg_613 any = Lit_9; if linked_610 == nil { ex__13 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { ex__13 = linked_610.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }
					if lang.Util_Identical_O_O__Z_NoInit(ex__13, nil) {
						var root_624 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = s__0; var arg_628 any; var na_614 any; var na_616 any = ns_a__5; var na_617 any = ra__10; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_616); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_617) }; tmp3 = tmp4; if tmp3 { var n0_618 int64 = jrt.NN(jrt.Long_Cast(na_616)).LongValue__J(); var n1_619 int64 = jrt.NN(jrt.Long_Cast(na_617)).LongValue__J(); var nr_620 int64 = n0_618 + n1_619; if (n0_618^nr_620)&(n1_619^nr_620) >= 0 { na_614 = jrt.Long_ValueOf_J__Long_NoInit(nr_620).Ref() } else { na_614 = lang.Numbers_Add_O_O__Number_NoInit(na_616, na_617) } } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_616); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_617) }; tmp5 = tmp6; if tmp5 { var n0_618_2 float64 = jrt.NN(jrt.Double_Cast(na_616)).DoubleValue__D(); var n1_619_2 float64 = jrt.NN(jrt.Double_Cast(na_617)).DoubleValue__D(); na_614 = jrt.Double_ValueOf_D__Double_NoInit(n0_618_2 + n1_619_2).Ref() } else { na_614 = lang.Numbers_Add_O_O__Number_NoInit(na_616, na_617) } }; var na_615 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rc__12))); if jrt.Long_InstanceOf(na_614) { var n0_621 int64 = jrt.NN(jrt.Long_Cast(na_614)).LongValue__J(); var n1_622 int64 = na_615; var nr_623 int64 = n0_621 + n1_622; if (n0_621^nr_623)&(n1_622^nr_623) >= 0 { arg_628 = jrt.Long_ValueOf_J__Long_NoInit(nr_623).Ref() } else { arg_628 = lang.Numbers_Add_O_J__Number_NoInit(na_614, na_615) } } else { arg_628 = lang.Numbers_Add_O_J__Number_NoInit(na_614, na_615) }; var arg_629 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref(); if linked_625 == nil { return ifn_626.Invoke_O_O_O__O(arg_627, arg_628, arg_629) } else { return linked_625.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_624, arg_627, arg_628, arg_629) } } else {
//line :167:1
							var v__14 any; var root_635 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_637 lang.IFn

							if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = rc__12; var arg_639 any; var na_630 any = ex__13; var na_631 int64 = int64(lang.RT_Count_O__I_NoInit(Lit_9)); if jrt.Long_InstanceOf(na_630) { var n0_632 int64 = jrt.NN(jrt.Long_Cast(na_630)).LongValue__J(); var n1_633 int64 = na_631; var nr_634 int64 = n0_632 + n1_633; if (n0_632^nr_634)&(n1_633^nr_634) >= 0 { arg_639 = jrt.Long_ValueOf_J__Long_NoInit(nr_634).Ref() } else { arg_639 = lang.Numbers_Add_O_J__Number_NoInit(na_630, na_631) } } else { arg_639 = lang.Numbers_Add_O_J__Number_NoInit(na_630, na_631) }; if linked_636 == nil { v__14 = ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { v__14 = linked_636.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) }
//line :167:1
							var ve__15 any; var root_640 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_642 lang.IFn


							if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = rc__12; var arg_644 any = v__14; if linked_641 == nil { ve__15 = ifn_642.Invoke_O_O__O(arg_643, arg_644) } else { ve__15 = linked_641.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_640, arg_643, arg_644) }
							var root_657 any = A_arbace_repr_clojure_rules_A_const_64.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_repr_clojure_rules_insert_at_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = s__0; var arg_661 any; var na_645 any; var na_647 any = ns_a__5; var na_648 any = ra__10; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_647); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_648) }; tmp7 = tmp8; if tmp7 { var n0_649 int64 = jrt.NN(jrt.Long_Cast(na_647)).LongValue__J(); var n1_650 int64 = jrt.NN(jrt.Long_Cast(na_648)).LongValue__J(); var nr_651 int64 = n0_649 + n1_650; if (n0_649^nr_651)&(n1_650^nr_651) >= 0 { na_645 = jrt.Long_ValueOf_J__Long_NoInit(nr_651).Ref() } else { na_645 = lang.Numbers_Add_O_O__Number_NoInit(na_647, na_648) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_647); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_648) }; tmp9 = tmp10; if tmp9 { var n0_649_2 float64 = jrt.NN(jrt.Double_Cast(na_647)).DoubleValue__D(); var n1_650_2 float64 = jrt.NN(jrt.Double_Cast(na_648)).DoubleValue__D(); na_645 = jrt.Double_ValueOf_D__Double_NoInit(n0_649_2 + n1_650_2).Ref() } else { na_645 = lang.Numbers_Add_O_O__Number_NoInit(na_647, na_648) } }; var na_646 any; var na_652 any = ve__15; if jrt.Long_InstanceOf(na_652) { var n0_653 int64 = jrt.NN(jrt.Long_Cast(na_652)).LongValue__J(); if n0_653 == -9223372036854775808 { na_646 = lang.Numbers_Dec_O__Number_NoInit(na_652) } else { na_646 = jrt.Long_ValueOf_J__Long_NoInit(n0_653 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_652) { var n0_653_2 float64 = jrt.NN(jrt.Double_Cast(na_652)).DoubleValue__D(); na_646 = jrt.Double_ValueOf_D__Double_NoInit(n0_653_2 - 1.0).Ref() } else { na_646 = lang.Numbers_Dec_O__Number_NoInit(na_652) } }; var tmp11 bool; var tmp12 bool; tmp12 = jrt.Long_InstanceOf(na_645); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_646) }; tmp11 = tmp12; if tmp11 { var n0_654 int64 = jrt.NN(jrt.Long_Cast(na_645)).LongValue__J(); var n1_655 int64 = jrt.NN(jrt.Long_Cast(na_646)).LongValue__J(); var nr_656 int64 = n0_654 + n1_655; if (n0_654^nr_656)&(n1_655^nr_656) >= 0 { arg_661 = jrt.Long_ValueOf_J__Long_NoInit(nr_656).Ref() } else { arg_661 = lang.Numbers_Add_O_O__Number_NoInit(na_645, na_646) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_645); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_646) }; tmp13 = tmp14; if tmp13 { var n0_654_2 float64 = jrt.NN(jrt.Double_Cast(na_645)).DoubleValue__D(); var n1_655_2 float64 = jrt.NN(jrt.Double_Cast(na_646)).DoubleValue__D(); arg_661 = jrt.Double_ValueOf_D__Double_NoInit(n0_654_2 + n1_655_2).Ref() } else { arg_661 = lang.Numbers_Add_O_O__Number_NoInit(na_645, na_646) } }; var arg_662 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8)).Ref(); if linked_658 == nil { return ifn_659.Invoke_O_O_O__O(arg_660, arg_661, arg_662) } else { return linked_658.(*A_arbace_repr_clojure_rules_insert_at_A).Invoke_O_O_O_O__O(root_657, arg_660, arg_661, arg_662) } } } else {
//line :159:1
								return nil } } } } }













func A_arbace_repr_clojure_rules_cut_A_New() *A_arbace_repr_clojure_rules_cut_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_cut_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_clojure_rules_cut_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_clojure_rules_cut_A) Invoke_O_O_O_O__O(self, s__0, a__1, b__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_663 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = s__0; var arg_667 any = A_arbace_repr_clojure_rules_A_const_30; var arg_668 any = a__1; if linked_664 == nil { tmp2 = ifn_665.Invoke_O_O_O__O(arg_666, arg_667, arg_668) } else { tmp2 = linked_664.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_663, arg_666, arg_667, arg_668) }; var tmp3 any = tmp2; var tmp4 any; var root_669 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = s__0; var arg_673 any = b__2; if linked_670 == nil { tmp4 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp4 = linked_670.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref() }

func A_arbace_repr_clojure_rules_uncore_names_A_New() *A_arbace_repr_clojure_rules_uncore_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_repr_clojure_rules_uncore_names_A) Ctor() {}
//line :175:1
func (t *A_arbace_repr_clojure_rules_uncore_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any; var root_687 any = A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_689 lang.IFn; if







	linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any; var root_683 any = A_arbace_repr_clojure_rules_A_const_59.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var root_678 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = added__1; var arg_682 any; var root_674 any = A_arbace_repr_clojure_rules_A_const_60.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_repr_clojure_rules_defined_names_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = s__0; if linked_675 == nil { arg_682 = ifn_676.Invoke_O__O(arg_677) } else { arg_682 = linked_675.(*A_arbace_repr_clojure_rules_defined_names_A).Invoke_O_O__O(root_674, arg_677) }; if linked_679 == nil { arg_686 = ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { arg_686 = linked_679.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) }; if linked_684 == nil { arg_690 = ifn_685.Invoke_O__O(arg_686) } else { arg_690 = linked_684.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_683, arg_686) }; if linked_688 == nil { names__3 = ifn_689.Invoke_O__O(arg_690) } else { names__3 = linked_688.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_687, arg_690) }; var vec__1700000132__4 any; var root_696 any = /*line :175:1*/A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_698 lang.IFn; if








	linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var root_691 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = s__0; var arg_695 any = A_arbace_repr_clojure_rules_A_const_66; if linked_692 == nil { arg_699 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { arg_699 = linked_692.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; if linked_697 == nil { vec__1700000132__4 = ifn_698.Invoke_O__O(arg_699) } else { vec__1700000132__4 = linked_697.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_696, arg_699) }; var ns_a__5 any = /*line :175:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1700000132__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000132__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any; var root_700 any = A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_702 lang.IFn; if









	linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = names__3; if linked_701 == nil { or__1927000174__auto____7 = ifn_702.Invoke_O__O(arg_703) } else { or__1927000174__auto____7 = linked_701.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_700, arg_703) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ns_a__5, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var nt__7 any; var root_704 any = A_arbace_repr_clojure_rules_A_const_62.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_706 lang.IFn

		if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = Lit_5; var arg_708 any = names__3; if linked_705 == nil { nt__7 = ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { nt__7 = linked_705.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) }
//line :185:1
		var suffix_QMARK___8 any; var tmp2 any = A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_New_O(s__0); var tmp3 *jrt.Class
		var fncls__725 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class


		if fncls__725 == nil { var fncls__725d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class = fncls__725d; tmp3 = fncls__725d } else { tmp3 = fncls__725 }; suffix_QMARK___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :185:1
		var a__9 any; var x__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, nt__7, nil)).Ref(); var e__10 any
		var na_726 any = ns_b__6



		if jrt.Long_InstanceOf(na_726) { var n0_727 int64 = jrt.NN(jrt.Long_Cast(na_726)).LongValue__J(); if n0_727 == -9223372036854775808 { e__10 = lang.Numbers_Dec_O__Number_NoInit(na_726) } else { e__10 = jrt.Long_ValueOf_J__Long_NoInit(n0_727 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_726) { var n0_727_2 float64 = jrt.NN(jrt.Double_Cast(na_726)).DoubleValue__D(); e__10 = jrt.Double_ValueOf_D__Double_NoInit(n0_727_2 - 1.0).Ref() } else { e__10 = lang.Numbers_Dec_O__Number_NoInit(na_726) } }
		if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__10, x__9)) { var root_733 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = s__0; var arg_737 any; var na_728 any = e__10; var na_729 int64 = int64(lang.RT_Count_O__I_NoInit(x__9)); if jrt.Long_InstanceOf(na_728) { var n0_730 int64 = jrt.NN(jrt.Long_Cast(na_728)).LongValue__J(); var n1_731 int64 = na_729; var nr_732 int64 = n0_730 - n1_731; var tmp4 bool; var tmp5 bool; tmp5 = !(n1_731 == -9223372036854775808); if tmp5 { tmp5 = (n0_730^n1_731)&(n0_730^nr_732) >= 0 }; tmp4 = tmp5; if tmp4 { arg_737 = jrt.Long_ValueOf_J__Long_NoInit(nr_732).Ref() } else { arg_737 = lang.Numbers_Minus_O_J__Number_NoInit(na_728, na_729) } } else { arg_737 = lang.Numbers_Minus_O_J__Number_NoInit(na_728, na_729) }; var arg_738 any = e__10; if linked_734 == nil { a__9 = ifn_735.Invoke_O_O_O__O(arg_736, arg_737, arg_738) } else { a__9 = linked_734.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_733, arg_736, arg_737, arg_738) } } else { a__9 = nil }
//line :185:1
		var ns_text__10 any; var root_739 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_741 lang.IFn






		if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = s__0; var arg_743 any = ns_a__5; var arg_744 any = ns_b__6; if linked_740 == nil { ns_text__10 = ifn_741.Invoke_O_O_O__O(arg_742, arg_743, arg_744) } else { ns_text__10 = linked_740.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_739, arg_742, arg_743, arg_744) }
//line :185:1
		var vec__1700000135__11 any; var root_750 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_752 lang.IFn







		if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any; var root_745 any = A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = ns_text__10; var arg_749 any = A_arbace_repr_clojure_rules_A_const_68; if linked_746 == nil { arg_753 = ifn_747.Invoke_O_O__O(arg_748, arg_749) } else { arg_753 = linked_746.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_list_spans_A).Invoke_O_O_O__O(root_745, arg_748, arg_749) }; if linked_751 == nil { vec__1700000135__11 = ifn_752.Invoke_O__O(arg_753) } else { vec__1700000135__11 = linked_751.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_750, arg_753) }
//line :185:1
		var ra__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000135__11, lang.RT_IntCast_J__I_NoInit(0), nil); var rb__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000135__11, lang.RT_IntCast_J__I_NoInit(1), nil); var b__14 any









		if jrt.J2g_Truth(ra__12) { var x__14 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, nt__7, nil)).Ref(); var e__15 any; var na_754 any = ns_a__5; var na_755 any; var na_756 any = rb__13
			if jrt.Long_InstanceOf(na_756) { var n0_757 int64 = jrt.NN(jrt.Long_Cast(na_756)).LongValue__J(); if n0_757 == -9223372036854775808 { na_755 = lang.Numbers_Dec_O__Number_NoInit(na_756) } else { na_755 = jrt.Long_ValueOf_J__Long_NoInit(n0_757 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_756) { var n0_757_2 float64 = jrt.NN(jrt.Double_Cast(na_756)).DoubleValue__D(); na_755 = jrt.Double_ValueOf_D__Double_NoInit(n0_757_2 - 1.0).Ref() } else { na_755 = lang.Numbers_Dec_O__Number_NoInit(na_756) } }; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_754); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_755) }; tmp6 = tmp7; if tmp6 { var n0_758 int64 = jrt.NN(jrt.Long_Cast(na_754)).LongValue__J(); var n1_759 int64 = jrt.NN(jrt.Long_Cast(na_755)).LongValue__J(); var nr_760 int64 = n0_758 + n1_759; if (n0_758^nr_760)&(n1_759^nr_760) >= 0 { e__15 = jrt.Long_ValueOf_J__Long_NoInit(nr_760).Ref() } else { e__15 = lang.Numbers_Add_O_O__Number_NoInit(na_754, na_755) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_754); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_755) }; tmp8 = tmp9; if tmp8 { var n0_758_2 float64 = jrt.NN(jrt.Double_Cast(na_754)).DoubleValue__D(); var n1_759_2 float64 = jrt.NN(jrt.Double_Cast(na_755)).DoubleValue__D(); e__15 = jrt.Double_ValueOf_D__Double_NoInit(n0_758_2 + n1_759_2).Ref() } else { e__15 = lang.Numbers_Add_O_O__Number_NoInit(na_754, na_755) } }
			if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__15, x__14)) { var root_766 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = s__0; var arg_770 any; var na_761 any = e__15; var na_762 int64 = int64(lang.RT_Count_O__I_NoInit(x__14)); if jrt.Long_InstanceOf(na_761) { var n0_763 int64 = jrt.NN(jrt.Long_Cast(na_761)).LongValue__J(); var n1_764 int64 = na_762; var nr_765 int64 = n0_763 - n1_764; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_764 == -9223372036854775808); if tmp11 { tmp11 = (n0_763^n1_764)&(n0_763^nr_765) >= 0 }; tmp10 = tmp11; if tmp10 { arg_770 = jrt.Long_ValueOf_J__Long_NoInit(nr_765).Ref() } else { arg_770 = lang.Numbers_Minus_O_J__Number_NoInit(na_761, na_762) } } else { arg_770 = lang.Numbers_Minus_O_J__Number_NoInit(na_761, na_762) }; var arg_771 any = e__15; if linked_767 == nil { b__14 = ifn_768.Invoke_O_O_O__O(arg_769, arg_770, arg_771) } else { b__14 = linked_767.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_766, arg_769, arg_770, arg_771) } } else { b__14 = nil } } else {
//line :195:1
				b__14 = nil }
//line :185:1
		var c__15 any













		if jrt.J2g_Truth(ra__12) { var rc__15 any; var root_772 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_774 lang.IFn
			if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = ns_text__10; var arg_776 any = ra__12; var arg_777 any = rb__13; if linked_773 == nil { rc__15 = ifn_774.Invoke_O_O_O__O(arg_775, arg_776, arg_777) } else { rc__15 = linked_773.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_772, arg_775, arg_776, arg_777) }
//line :199:1
			var temp__1927000414__auto____16 any; var root_778 any = A_arbace_repr_clojure_rules_A_const_65.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_780 lang.IFn

			if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = rc__15; var arg_782 any = Lit_9; if linked_779 == nil { temp__1927000414__auto____16 = ifn_780.Invoke_O_O__O(arg_781, arg_782) } else { temp__1927000414__auto____16 = linked_779.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_778, arg_781, arg_782) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var ex__17 any = temp__1927000414__auto____16; var v__18 any; var root_788 any = A_arbace_repr_clojure_rules_A_const_45.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_790 lang.IFn
				if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = rc__15; var arg_792 any; var na_783 any = ex__17; var na_784 int64 = int64(lang.RT_Count_O__I_NoInit(Lit_9)); if jrt.Long_InstanceOf(na_783) { var n0_785 int64 = jrt.NN(jrt.Long_Cast(na_783)).LongValue__J(); var n1_786 int64 = na_784; var nr_787 int64 = n0_785 + n1_786; if (n0_785^nr_787)&(n1_786^nr_787) >= 0 { arg_792 = jrt.Long_ValueOf_J__Long_NoInit(nr_787).Ref() } else { arg_792 = lang.Numbers_Add_O_J__Number_NoInit(na_783, na_784) } } else { arg_792 = lang.Numbers_Add_O_J__Number_NoInit(na_783, na_784) }; if linked_789 == nil { v__18 = ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { v__18 = linked_789.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_788, arg_791, arg_792) }
//line :201:1
				var ve__19 any; var root_793 any = A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_795 lang.IFn

				if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = rc__15; var arg_797 any = v__18; if linked_794 == nil { ve__19 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { ve__19 = linked_794.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }
//line :201:1
				var x__20 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, nt__7)).Ref(); var e__21 any; var na_798 any; var na_800 any = ns_a__5; var na_801 any = ra__12; var tmp12 bool; var tmp13 bool


				tmp13 = jrt.Long_InstanceOf(na_800); if tmp13 { tmp13 = jrt.Long_InstanceOf(na_801) }; tmp12 = tmp13; if tmp12 { var n0_802 int64 = jrt.NN(jrt.Long_Cast(na_800)).LongValue__J(); var n1_803 int64 = jrt.NN(jrt.Long_Cast(na_801)).LongValue__J(); var nr_804 int64 = n0_802 + n1_803; if (n0_802^nr_804)&(n1_803^nr_804) >= 0 { na_798 = jrt.Long_ValueOf_J__Long_NoInit(nr_804).Ref() } else { na_798 = lang.Numbers_Add_O_O__Number_NoInit(na_800, na_801) } } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Double_InstanceOf(na_800); if tmp15 { tmp15 = jrt.Double_InstanceOf(na_801) }; tmp14 = tmp15; if tmp14 { var n0_802_2 float64 = jrt.NN(jrt.Double_Cast(na_800)).DoubleValue__D(); var n1_803_2 float64 = jrt.NN(jrt.Double_Cast(na_801)).DoubleValue__D(); na_798 = jrt.Double_ValueOf_D__Double_NoInit(n0_802_2 + n1_803_2).Ref() } else { na_798 = lang.Numbers_Add_O_O__Number_NoInit(na_800, na_801) } }; var na_799 any; var na_805 any = ve__19; if jrt.Long_InstanceOf(na_805) { var n0_806 int64 = jrt.NN(jrt.Long_Cast(na_805)).LongValue__J(); if n0_806 == -9223372036854775808 { na_799 = lang.Numbers_Dec_O__Number_NoInit(na_805) } else { na_799 = jrt.Long_ValueOf_J__Long_NoInit(n0_806 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_805) { var n0_806_2 float64 = jrt.NN(jrt.Double_Cast(na_805)).DoubleValue__D(); na_799 = jrt.Double_ValueOf_D__Double_NoInit(n0_806_2 - 1.0).Ref() } else { na_799 = lang.Numbers_Dec_O__Number_NoInit(na_805) } }; var tmp16 bool; var tmp17 bool; tmp17 = jrt.Long_InstanceOf(na_798); if tmp17 { tmp17 = jrt.Long_InstanceOf(na_799) }; tmp16 = tmp17; if tmp16 { var n0_807 int64 = jrt.NN(jrt.Long_Cast(na_798)).LongValue__J(); var n1_808 int64 = jrt.NN(jrt.Long_Cast(na_799)).LongValue__J(); var nr_809 int64 = n0_807 + n1_808; if (n0_807^nr_809)&(n1_808^nr_809) >= 0 { e__21 = jrt.Long_ValueOf_J__Long_NoInit(nr_809).Ref() } else { e__21 = lang.Numbers_Add_O_O__Number_NoInit(na_798, na_799) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_798); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_799) }; tmp18 = tmp19; if tmp18 { var n0_807_2 float64 = jrt.NN(jrt.Double_Cast(na_798)).DoubleValue__D(); var n1_808_2 float64 = jrt.NN(jrt.Double_Cast(na_799)).DoubleValue__D(); e__21 = jrt.Double_ValueOf_D__Double_NoInit(n0_807_2 + n1_808_2).Ref() } else { e__21 = lang.Numbers_Add_O_O__Number_NoInit(na_798, na_799) } }
				if jrt.J2g_Truth(lang.IFn_Cast(suffix_QMARK___8).Invoke_O_O__O(e__21, x__20)) { var root_815 any = A_arbace_repr_clojure_rules_A_const_67.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, A_arbace_repr_clojure_rules_cut_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = s__0; var arg_819 any; var na_810 any = e__21; var na_811 int64 = int64(lang.RT_Count_O__I_NoInit(x__20)); if jrt.Long_InstanceOf(na_810) { var n0_812 int64 = jrt.NN(jrt.Long_Cast(na_810)).LongValue__J(); var n1_813 int64 = na_811; var nr_814 int64 = n0_812 - n1_813; var tmp20 bool; var tmp21 bool; tmp21 = !(n1_813 == -9223372036854775808); if tmp21 { tmp21 = (n0_812^n1_813)&(n0_812^nr_814) >= 0 }; tmp20 = tmp21; if tmp20 { arg_819 = jrt.Long_ValueOf_J__Long_NoInit(nr_814).Ref() } else { arg_819 = lang.Numbers_Minus_O_J__Number_NoInit(na_810, na_811) } } else { arg_819 = lang.Numbers_Minus_O_J__Number_NoInit(na_810, na_811) }; var arg_820 any = e__21; if linked_816 == nil { c__15 = ifn_817.Invoke_O_O_O__O(arg_818, arg_819, arg_820) } else { c__15 = linked_816.(*A_arbace_repr_clojure_rules_cut_A).Invoke_O_O_O_O__O(root_815, arg_818, arg_819, arg_820) } } else { c__15 = nil } } else {
//line :201:1
					c__15 = nil } } else {
//line :199:1
						c__15 = nil }
//line :185:1
		var or__1927000174__auto____16 any; var root_832 any = A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_834 lang.IFn




















		if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any; var root_827 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any; var tmp22 any = A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_New_O_O(s__0, added__1); var tmp23 *jrt.Class; var fncls__826 *jrt.Class = A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class; if fncls__826 == nil { var fncls__826d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class = fncls__826d; tmp23 = fncls__826d } else { tmp23 = fncls__826 }; arg_830 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_831 any = lang.Tuple_Create_O_O_O__IPersistentVector(a__9, b__14, c__15); if linked_828 == nil { arg_835 = ifn_829.Invoke_O_O__O(arg_830, arg_831) } else { arg_835 = linked_828.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_827, arg_830, arg_831) }; if linked_833 == nil { or__1927000174__auto____16 = ifn_834.Invoke_O__O(arg_835) } else { or__1927000174__auto____16 = linked_833.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_832, arg_835) }; if jrt.J2g_Truth(or__1927000174__auto____16) { return or__1927000174__auto____16 } else { return s__0 } } }
//line :188:1
func A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_New_O(p0 any) *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :188:1
func (t *A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A) Invoke_O_O_O__O(self, end__1, x__2 any) any { var and__1927000168__auto____3 bool; var na_709 any = end__1; var na_710 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); if jrt.Long_InstanceOf(na_709) { var n0_711 int64 = jrt.NN(jrt.Long_Cast(na_709)).LongValue__J(); var n1_712 int64 = na_710; and__1927000168__auto____3 = n0_711 >= n1_712 } else { and__1927000168__auto____3 = lang.Numbers_Gte_O_J__Z_NoInit(na_709, na_710) }; if and__1927000168__auto____3 { var tmp1 any; var root_719 any = A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = t.F_s; var arg_723 any; var na_714 any = end__1; var na_715 int64 = int64(lang.RT_Count_O__I_NoInit(x__2)); if jrt.Long_InstanceOf(na_714) { var n0_716 int64 = jrt.NN(jrt.Long_Cast(na_714)).LongValue__J(); var n1_717 int64 = na_715; var nr_718 int64 = n0_716 - n1_717; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_717 == -9223372036854775808); if tmp3 { tmp3 = (n0_716^n1_717)&(n0_716^nr_718) >= 0 }; tmp2 = tmp3; if tmp2 { arg_723 = jrt.Long_ValueOf_J__Long_NoInit(nr_718).Ref() } else { arg_723 = lang.Numbers_Minus_O_J__Number_NoInit(na_714, na_715) } } else { arg_723 = lang.Numbers_Minus_O_J__Number_NoInit(na_714, na_715) }; var arg_724 any = end__1; if linked_720 == nil { tmp1 = ifn_721.Invoke_O_O_O__O(arg_722, arg_723, arg_724) } else { tmp1 = linked_720.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_719, arg_722, arg_723, arg_724) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__2, tmp1)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }

















func A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A{}; t.Ctor_O_O(p0, p1); return t }
//line :206:1
func (t *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A) Ctor_O_O(c__s, c__added any) { t.F_s = c__s; t.F_added = c__added }
//line :206:1
func (t *A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A) Invoke_O_O__O(self, p1__1700000131_SHARP___1 any) any { var and__1927000168__auto____2 any = p1__1700000131_SHARP___1; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = t.F_s; var tmp2 any; var root_821 any = A_arbace_repr_clojure_rules_A_const_69.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, A_arbace_repr_clojure_rules_core_names_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = p1__1700000131_SHARP___1; var arg_825 any = t.F_added; if linked_822 == nil { tmp2 = ifn_823.Invoke_O_O__O(arg_824, arg_825) } else { tmp2 = linked_822.(*A_arbace_repr_clojure_rules_core_names_A).Invoke_O_O_O__O(root_821, arg_824, arg_825) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }







func A_arbace_repr_clojure_rules_fn__1700000143_A_New() *A_arbace_repr_clojure_rules_fn__1700000143_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000143_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repr_clojure_rules_fn__1700000143_A) Ctor() {}
//line :214:1
func (t *A_arbace_repr_clojure_rules_fn__1700000143_A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 any = A_arbace_repr_clojure_rules_A_const_70; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0)); if and__1927000168__auto____2 { return A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_repr_clojure_rules_fn__1700000145_A_New() *A_arbace_repr_clojure_rules_fn__1700000145_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000145_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_repr_clojure_rules_fn__1700000145_A) Ctor() {}
//line :215:1
func (t *A_arbace_repr_clojure_rules_fn__1700000145_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_836 any = A_arbace_repr_clojure_rules_A_const_72.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = s__0; var arg_840 any = A_arbace_repr_clojure_rules_A_const_73.Invoke_O__O(ctx__1); if linked_837 == nil { return ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { return linked_837.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) } }




func A_arbace_repr_clojure_rules_fn__1700000147_A_New() *A_arbace_repr_clojure_rules_fn__1700000147_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000147_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_clojure_rules_fn__1700000147_A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_clojure_rules_fn__1700000147_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return s__0 }






func A_arbace_repr_clojure_rules_fn__1700000149_A_New() *A_arbace_repr_clojure_rules_fn__1700000149_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000149_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_repr_clojure_rules_fn__1700000149_A) Ctor() {}
//line :227:1
func (t *A_arbace_repr_clojure_rules_fn__1700000149_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_841 any = A_arbace_repr_clojure_rules_A_const_74.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_rename_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = s__0; if linked_842 == nil { return ifn_843.Invoke_O__O(arg_844) } else { return linked_842.(*aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_rename_A).Invoke_O_O__O(root_841, arg_844) } }



func A_arbace_repr_clojure_rules_fn__1700000151_A_New() *A_arbace_repr_clojure_rules_fn__1700000151_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000151_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_repr_clojure_rules_fn__1700000151_A) Ctor() {}
//line :231:1
func (t *A_arbace_repr_clojure_rules_fn__1700000151_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_845 any = A_arbace_repr_clojure_rules_A_const_75.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_unrename_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = s__0; if linked_846 == nil { return ifn_847.Invoke_O__O(arg_848) } else { return linked_846.(*aot_arbace_repr_clojure_rename.A_arbace_repr_clojure_rename_unrename_A).Invoke_O_O__O(root_845, arg_848) } }





func A_arbace_repr_clojure_rules_fn__1700000153_A_New() *A_arbace_repr_clojure_rules_fn__1700000153_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000153_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_repr_clojure_rules_fn__1700000153_A) Ctor() {}
//line :237:1
func (t *A_arbace_repr_clojure_rules_fn__1700000153_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_849 any = A_arbace_repr_clojure_rules_A_const_76.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, A_arbace_repr_clojure_rules_proxy_methods_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = s__0; if linked_850 == nil { return ifn_851.Invoke_O__O(arg_852) } else { return linked_850.(*A_arbace_repr_clojure_rules_proxy_methods_A).Invoke_O_O__O(root_849, arg_852) } }


func A_arbace_repr_clojure_rules_fn__1700000155_A_New() *A_arbace_repr_clojure_rules_fn__1700000155_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000155_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_repr_clojure_rules_fn__1700000155_A) Ctor() {}
//line :240:1
func (t *A_arbace_repr_clojure_rules_fn__1700000155_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_853 any = A_arbace_repr_clojure_rules_A_const_77.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = s__0; if linked_854 == nil { return ifn_855.Invoke_O__O(arg_856) } else { return linked_854.(*A_arbace_repr_clojure_rules_unproxy_methods_A).Invoke_O_O__O(root_853, arg_856) } }





func A_arbace_repr_clojure_rules_fn__1700000157_A_New() *A_arbace_repr_clojure_rules_fn__1700000157_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000157_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_repr_clojure_rules_fn__1700000157_A) Ctor() {}
//line :246:1
func (t *A_arbace_repr_clojure_rules_fn__1700000157_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_860 any = A_arbace_repr_clojure_rules_A_const_69.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, A_arbace_repr_clojure_rules_core_names_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = s__0; var arg_864 any; var or__1927000174__auto____3 any = A_arbace_repr_clojure_rules_A_const_78.Invoke_O__O(ctx__1); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_864 = or__1927000174__auto____3 } else { var root_857 any = A_arbace_repr_clojure_rules_A_const_79.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; if linked_858 == nil { arg_864 = ifn_859.Invoke__O() } else { arg_864 = linked_858.(*A_arbace_repr_clojure_rules_arbace_core_names_A).Invoke_O__O(root_857) } }; if linked_861 == nil { return ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { return linked_861.(*A_arbace_repr_clojure_rules_core_names_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) } }



func A_arbace_repr_clojure_rules_fn__1700000159_A_New() *A_arbace_repr_clojure_rules_fn__1700000159_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000159_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_repr_clojure_rules_fn__1700000159_A) Ctor() {}
//line :250:1
func (t *A_arbace_repr_clojure_rules_fn__1700000159_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var root_868 any = A_arbace_repr_clojure_rules_A_const_80.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, A_arbace_repr_clojure_rules_uncore_names_A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = s__0; var arg_872 any; var or__1927000174__auto____3 any = A_arbace_repr_clojure_rules_A_const_78.Invoke_O__O(ctx__1); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_872 = or__1927000174__auto____3 } else { var root_865 any = A_arbace_repr_clojure_rules_A_const_79.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; if linked_866 == nil { arg_872 = ifn_867.Invoke__O() } else { arg_872 = linked_866.(*A_arbace_repr_clojure_rules_arbace_core_names_A).Invoke_O__O(root_865) } }; if linked_869 == nil { return ifn_870.Invoke_O_O__O(arg_871, arg_872) } else { return linked_869.(*A_arbace_repr_clojure_rules_uncore_names_A).Invoke_O_O_O__O(root_868, arg_871, arg_872) } }




func A_arbace_repr_clojure_rules_fn__1700000161_A_New() *A_arbace_repr_clojure_rules_fn__1700000161_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000161_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_repr_clojure_rules_fn__1700000161_A) Ctor() {}
//line :255:1
func (t *A_arbace_repr_clojure_rules_fn__1700000161_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_873 any = A_arbace_repr_clojure_rules_A_const_81.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, A_arbace_repr_clojure_rules_security_manager_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = s__0; if linked_874 == nil { return ifn_875.Invoke_O__O(arg_876) } else { return linked_874.(*A_arbace_repr_clojure_rules_security_manager_A).Invoke_O_O__O(root_873, arg_876) } }



func A_arbace_repr_clojure_rules_fn__1700000163_A_New() *A_arbace_repr_clojure_rules_fn__1700000163_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000163_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_repr_clojure_rules_fn__1700000163_A) Ctor() {}
//line :259:1
func (t *A_arbace_repr_clojure_rules_fn__1700000163_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var root_877 any = A_arbace_repr_clojure_rules_A_const_82.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = s__0; if linked_878 == nil { return ifn_879.Invoke_O__O(arg_880) } else { return linked_878.(*A_arbace_repr_clojure_rules_unqualify_security_manager_A).Invoke_O_O__O(root_877, arg_880) } }































func A_arbace_repr_clojure_rules_applicable_A_New() *A_arbace_repr_clojure_rules_applicable_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Ctor() {}
//line :291:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Invoke_O_O_O__O(self, ctx__0, skip__1 any) any {


	var root_891 any = A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any; var tmp1 any = A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_New_O_O(ctx__0, skip__1); var tmp2 *jrt.Class; var fncls__890 *jrt.Class = A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class; if fncls__890 == nil { var fncls__890d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class = fncls__890d; tmp2 = fncls__890d } else { tmp2 = fncls__890 }; arg_894 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_895 any = A_arbace_repr_clojure_rules_A_const_85.GetRawRoot__O(); if linked_892 == nil { return ifn_893.Invoke_O_O__O(arg_894, arg_895) } else { return linked_892.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_891, arg_894, arg_895) } }
//line :294:1
func A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_fn__1700000166_A{}; t.Ctor_O_O(p0, p1); return t }
//line :294:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A) Ctor_O_O(c__ctx, c__skip any) { t.F_ctx = c__ctx; t.F_skip = c__skip }
//line :294:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000166_A) Invoke_O_O__O(self, p1__1700000165_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_886 any = A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any; var root_881 any = A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = t.F_skip; var arg_885 any = A_arbace_repr_clojure_rules_A_const_83.Invoke_O__O(p1__1700000165_SHARP___1); if linked_882 == nil { arg_889 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { arg_889 = linked_882.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; if linked_887 == nil { and__1927000168__auto____2 = ifn_888.Invoke_O__O(arg_889) } else { and__1927000168__auto____2 = linked_887.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_886, arg_889) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_84.Invoke_O__O(p1__1700000165_SHARP___1)).Invoke_O__O(t.F_ctx) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_clojure_rules_print_text_A_New() *A_arbace_repr_clojure_rules_print_text_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Ctor() {}
//line :296:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any {





	var root_906 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any; var tmp1 any = A_arbace_repr_clojure_rules_print_text_fn__1700000169_A_New_O(ctx__1); var tmp2 *jrt.Class; var fncls__896 *jrt.Class = A_arbace_repr_clojure_rules_print_text_fn__1700000169_A_fn_class; if fncls__896 == nil { var fncls__896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_rules_print_text_fn__1700000169_A_fn_class = fncls__896d; tmp2 = fncls__896d } else { tmp2 = fncls__896 }; arg_909 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_910 any = s__0; var arg_911 any; var root_902 any = A_arbace_repr_clojure_rules_A_const_87.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any; var root_897 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = ctx__1; var arg_901 any = skip__2; if linked_898 == nil { arg_905 = ifn_899.Invoke_O_O__O(arg_900, arg_901) } else { arg_905 = linked_898.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_897, arg_900, arg_901) }; if linked_903 == nil { arg_911 = ifn_904.Invoke_O__O(arg_905) } else { arg_911 = linked_903.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_902, arg_905) }; if linked_907 == nil { return ifn_908.Invoke_O_O_O__O(arg_909, arg_910, arg_911) } else { return linked_907.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_906, arg_909, arg_910, arg_911) } }
//line :296:1
func (t *A_arbace_repr_clojure_rules_print_text_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {



	var root_912 any = A_arbace_repr_clojure_rules_A_const_89.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, A_arbace_repr_clojure_rules_print_text_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = s__0; var arg_916 any = ctx__1; var arg_917 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_913 == nil { return ifn_914.Invoke_O_O_O__O(arg_915, arg_916, arg_917) } else { return linked_913.(*A_arbace_repr_clojure_rules_print_text_A).Invoke_O_O_O_O__O(root_912, arg_915, arg_916, arg_917)
	} }
func A_arbace_repr_clojure_rules_print_text_fn__1700000169_A_New_O(p0 any) *A_arbace_repr_clojure_rules_print_text_fn__1700000169_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_print_text_fn__1700000169_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000169_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :302:1
func (t *A_arbace_repr_clojure_rules_print_text_fn__1700000169_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_86.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

func A_arbace_repr_clojure_rules_translate_A_New() *A_arbace_repr_clojure_rules_translate_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_repr_clojure_rules_translate_A) Ctor() {}
//line :304:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any {




	var root_924 any = A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any; var tmp1 any = A_arbace_repr_clojure_rules_translate_fn__1700000172_A_New_O(ctx__1); var tmp2 *jrt.Class; var fncls__918 *jrt.Class = A_arbace_repr_clojure_rules_translate_fn__1700000172_A_fn_class; if fncls__918 == nil { var fncls__918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_repr_clojure_rules_translate_fn__1700000172_A_fn_class = fncls__918d; tmp2 = fncls__918d } else { tmp2 = fncls__918 }; arg_927 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_928 any = s__0; var arg_929 any; var root_919 any = A_arbace_repr_clojure_rules_A_const_88.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, A_arbace_repr_clojure_rules_applicable_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = ctx__1; var arg_923 any = skip__2; if linked_920 == nil { arg_929 = ifn_921.Invoke_O_O__O(arg_922, arg_923) } else { arg_929 = linked_920.(*A_arbace_repr_clojure_rules_applicable_A).Invoke_O_O_O__O(root_919, arg_922, arg_923) }; if linked_925 == nil { return ifn_926.Invoke_O_O_O__O(arg_927, arg_928, arg_929) } else { return linked_925.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_924, arg_927, arg_928, arg_929) } }
//line :304:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {


	var root_930 any = A_arbace_repr_clojure_rules_A_const_91.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, A_arbace_repr_clojure_rules_translate_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = s__0; var arg_934 any = ctx__1; var arg_935 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_931 == nil { return ifn_932.Invoke_O_O_O__O(arg_933, arg_934, arg_935) } else { return linked_931.(*A_arbace_repr_clojure_rules_translate_A).Invoke_O_O_O_O__O(root_930, arg_933, arg_934, arg_935)
	} }
func A_arbace_repr_clojure_rules_translate_fn__1700000172_A_New_O(p0 any) *A_arbace_repr_clojure_rules_translate_fn__1700000172_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_fn__1700000172_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000172_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :309:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000172_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_90.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

































type A_arbace_repr_clojure_rules_A struct{ jrt.Object }

var A_arbace_repr_clojure_rules_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rules_A_const_0 *lang.Var

var A_arbace_repr_clojure_rules_A_const_1 any

var A_arbace_repr_clojure_rules_A_const_2 any

var A_arbace_repr_clojure_rules_A_const_3 any

var A_arbace_repr_clojure_rules_A_const_4 *lang.Var

var A_arbace_repr_clojure_rules_A_const_5 any

var A_arbace_repr_clojure_rules_A_const_6 *lang.Var

var A_arbace_repr_clojure_rules_A_const_7 *lang.Var

var A_arbace_repr_clojure_rules_A_const_8 *lang.Var

var A_arbace_repr_clojure_rules_A_const_9 *lang.Var

var A_arbace_repr_clojure_rules_A_const_10 any

var A_arbace_repr_clojure_rules_A_const_11 *lang.Var

var A_arbace_repr_clojure_rules_A_const_12 any

var A_arbace_repr_clojure_rules_A_const_13 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_14 *lang.Var

var A_arbace_repr_clojure_rules_A_const_15 *lang.Var

var A_arbace_repr_clojure_rules_A_const_16 *lang.Var

var A_arbace_repr_clojure_rules_A_const_17 *lang.Var

var A_arbace_repr_clojure_rules_A_const_18 any

var A_arbace_repr_clojure_rules_A_const_19 *lang.Var

var A_arbace_repr_clojure_rules_A_const_20 *lang.Var

var A_arbace_repr_clojure_rules_A_const_21 *lang.Var

var A_arbace_repr_clojure_rules_A_const_22 *lang.Var

var A_arbace_repr_clojure_rules_A_const_23 *lang.Var

var A_arbace_repr_clojure_rules_A_const_24 *lang.Var

var A_arbace_repr_clojure_rules_A_const_25 *lang.Var

var A_arbace_repr_clojure_rules_A_const_26 *lang.Var

var A_arbace_repr_clojure_rules_A_const_27 *lang.Var

var A_arbace_repr_clojure_rules_A_const_28 *lang.Var

var A_arbace_repr_clojure_rules_A_const_29 *lang.Var

var A_arbace_repr_clojure_rules_A_const_30 any

var A_arbace_repr_clojure_rules_A_const_31 *lang.Var

var A_arbace_repr_clojure_rules_A_const_32 *lang.Var

var A_arbace_repr_clojure_rules_A_const_33 *lang.Var

var A_arbace_repr_clojure_rules_A_const_34 *lang.Var

var A_arbace_repr_clojure_rules_A_const_35 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_36 *lang.Var

var A_arbace_repr_clojure_rules_A_const_37 *lang.Var

var A_arbace_repr_clojure_rules_A_const_38 *lang.Var

var A_arbace_repr_clojure_rules_A_const_39 *lang.Var

var A_arbace_repr_clojure_rules_A_const_40 any

var A_arbace_repr_clojure_rules_A_const_41 *lang.Var

var A_arbace_repr_clojure_rules_A_const_42 *lang.Var

var A_arbace_repr_clojure_rules_A_const_43 *lang.Var

var A_arbace_repr_clojure_rules_A_const_44 *lang.Var

var A_arbace_repr_clojure_rules_A_const_45 *lang.Var

var A_arbace_repr_clojure_rules_A_const_46 *lang.Var

var A_arbace_repr_clojure_rules_A_const_47 any

var A_arbace_repr_clojure_rules_A_const_48 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_49 *lang.Var

var A_arbace_repr_clojure_rules_A_const_50 *lang.Var

var A_arbace_repr_clojure_rules_A_const_51 *lang.Var

var A_arbace_repr_clojure_rules_A_const_52 *lang.Var

var A_arbace_repr_clojure_rules_A_const_53 *lang.Var

var A_arbace_repr_clojure_rules_A_const_54 *lang.Var

var A_arbace_repr_clojure_rules_A_const_55 *lang.Var

var A_arbace_repr_clojure_rules_A_const_56 *lang.Var

var A_arbace_repr_clojure_rules_A_const_57 *lang.Var

var A_arbace_repr_clojure_rules_A_const_58 *lang.Var

var A_arbace_repr_clojure_rules_A_const_59 *lang.Var

var A_arbace_repr_clojure_rules_A_const_60 *lang.Var

var A_arbace_repr_clojure_rules_A_const_61 any

var A_arbace_repr_clojure_rules_A_const_62 *lang.Var

var A_arbace_repr_clojure_rules_A_const_63 any

var A_arbace_repr_clojure_rules_A_const_64 *lang.Var

var A_arbace_repr_clojure_rules_A_const_65 *lang.Var

var A_arbace_repr_clojure_rules_A_const_66 any

var A_arbace_repr_clojure_rules_A_const_67 *lang.Var

var A_arbace_repr_clojure_rules_A_const_68 any

var A_arbace_repr_clojure_rules_A_const_69 *lang.Var

var A_arbace_repr_clojure_rules_A_const_70 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_72 *lang.Var

var A_arbace_repr_clojure_rules_A_const_73 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_74 *lang.Var

var A_arbace_repr_clojure_rules_A_const_75 *lang.Var

var A_arbace_repr_clojure_rules_A_const_76 *lang.Var

var A_arbace_repr_clojure_rules_A_const_77 *lang.Var

var A_arbace_repr_clojure_rules_A_const_78 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_79 *lang.Var

var A_arbace_repr_clojure_rules_A_const_80 *lang.Var

var A_arbace_repr_clojure_rules_A_const_81 *lang.Var

var A_arbace_repr_clojure_rules_A_const_82 *lang.Var

var A_arbace_repr_clojure_rules_A_const_83 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_84 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_85 *lang.Var

var A_arbace_repr_clojure_rules_A_const_86 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_87 *lang.Var

var A_arbace_repr_clojure_rules_A_const_88 *lang.Var

var A_arbace_repr_clojure_rules_A_const_89 *lang.Var

var A_arbace_repr_clojure_rules_A_const_90 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_91 *lang.Var

var A_arbace_repr_clojure_rules_A_init jrt.ClassInit

func A_arbace_repr_clojure_rules_A_Init() { if !A_arbace_repr_clojure_rules_A_init.Done() { A_arbace_repr_clojure_rules_A_init.Run(A_arbace_repr_clojure_rules_A_clinit) } }

func A_arbace_repr_clojure_rules_A_clinit() { A_arbace_repr_clojure_rules_A_clinit_p0(); A_arbace_repr_clojure_rules_A_clinit_p1(); A_arbace_repr_clojure_rules_A_clinit_p2(); A_arbace_repr_clojure_rules_A_clinit_p3(); A_arbace_repr_clojure_rules_A_clinit_p4(); A_arbace_repr_clojure_rules_A_clinit_p5(); A_arbace_repr_clojure_rules_A_clinit_p6(); A_arbace_repr_clojure_rules_A_clinit_p7() }

func A_arbace_repr_clojure_rules_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rules_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 113); A_arbace_repr_clojure_rules_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[21]); A_arbace_repr_clojure_rules_A_const_1 = A_arbace_repr_clojure_rules_A_const_pool.A[22]; A_arbace_repr_clojure_rules_A_const_2 = A_arbace_repr_clojure_rules_A_const_pool.A[23]; A_arbace_repr_clojure_rules_A_const_3 = A_arbace_repr_clojure_rules_A_const_pool.A[24]; A_arbace_repr_clojure_rules_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[25]); A_arbace_repr_clojure_rules_A_const_5 = A_arbace_repr_clojure_rules_A_const_pool.A[26]; A_arbace_repr_clojure_rules_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[27]); A_arbace_repr_clojure_rules_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[28]); A_arbace_repr_clojure_rules_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[29]); A_arbace_repr_clojure_rules_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[30]); A_arbace_repr_clojure_rules_A_const_10 = A_arbace_repr_clojure_rules_A_const_pool.A[31]; A_arbace_repr_clojure_rules_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[32]) }

func A_arbace_repr_clojure_rules_A_clinit_p1() { A_arbace_repr_clojure_rules_A_const_12 = A_arbace_repr_clojure_rules_A_const_pool.A[33]; A_arbace_repr_clojure_rules_A_const_13 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[34]); A_arbace_repr_clojure_rules_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[35]); A_arbace_repr_clojure_rules_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[36]); A_arbace_repr_clojure_rules_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[37]); A_arbace_repr_clojure_rules_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[38]); A_arbace_repr_clojure_rules_A_const_18 = A_arbace_repr_clojure_rules_A_const_pool.A[39]; A_arbace_repr_clojure_rules_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[40]); A_arbace_repr_clojure_rules_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[41]); A_arbace_repr_clojure_rules_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[42]); A_arbace_repr_clojure_rules_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[43]); A_arbace_repr_clojure_rules_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[44]) }

func A_arbace_repr_clojure_rules_A_clinit_p2() { A_arbace_repr_clojure_rules_A_const_24 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[45]); A_arbace_repr_clojure_rules_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[46]); A_arbace_repr_clojure_rules_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[47]); A_arbace_repr_clojure_rules_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[48]); A_arbace_repr_clojure_rules_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[49]); A_arbace_repr_clojure_rules_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[50]); A_arbace_repr_clojure_rules_A_const_30 = A_arbace_repr_clojure_rules_A_const_pool.A[51]; A_arbace_repr_clojure_rules_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[52]); A_arbace_repr_clojure_rules_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[53]); A_arbace_repr_clojure_rules_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[54]); A_arbace_repr_clojure_rules_A_const_34 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[55]); A_arbace_repr_clojure_rules_A_const_35 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[56]) }

func A_arbace_repr_clojure_rules_A_clinit_p3() { A_arbace_repr_clojure_rules_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[57]); A_arbace_repr_clojure_rules_A_const_37 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[58]); A_arbace_repr_clojure_rules_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[59]); A_arbace_repr_clojure_rules_A_const_39 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[60]); A_arbace_repr_clojure_rules_A_const_40 = A_arbace_repr_clojure_rules_A_const_pool.A[61]; A_arbace_repr_clojure_rules_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[62]); A_arbace_repr_clojure_rules_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[63]); A_arbace_repr_clojure_rules_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[64]); A_arbace_repr_clojure_rules_A_const_44 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[65]); A_arbace_repr_clojure_rules_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[66]); A_arbace_repr_clojure_rules_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[67]); A_arbace_repr_clojure_rules_A_const_47 = A_arbace_repr_clojure_rules_A_const_pool.A[68] }

func A_arbace_repr_clojure_rules_A_clinit_p4() { A_arbace_repr_clojure_rules_A_const_48 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[69]); A_arbace_repr_clojure_rules_A_const_49 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[70]); A_arbace_repr_clojure_rules_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[71]); A_arbace_repr_clojure_rules_A_const_51 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[72]); A_arbace_repr_clojure_rules_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[73]); A_arbace_repr_clojure_rules_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[74]); A_arbace_repr_clojure_rules_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[75]); A_arbace_repr_clojure_rules_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[76]); A_arbace_repr_clojure_rules_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[77]); A_arbace_repr_clojure_rules_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[78]); A_arbace_repr_clojure_rules_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[79]); A_arbace_repr_clojure_rules_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[80]) }

func A_arbace_repr_clojure_rules_A_clinit_p5() { A_arbace_repr_clojure_rules_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[81]); A_arbace_repr_clojure_rules_A_const_61 = A_arbace_repr_clojure_rules_A_const_pool.A[82]; A_arbace_repr_clojure_rules_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[83]); A_arbace_repr_clojure_rules_A_const_63 = A_arbace_repr_clojure_rules_A_const_pool.A[84]; A_arbace_repr_clojure_rules_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[85]); A_arbace_repr_clojure_rules_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[86]); A_arbace_repr_clojure_rules_A_const_66 = A_arbace_repr_clojure_rules_A_const_pool.A[87]; A_arbace_repr_clojure_rules_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[88]); A_arbace_repr_clojure_rules_A_const_68 = A_arbace_repr_clojure_rules_A_const_pool.A[89]; A_arbace_repr_clojure_rules_A_const_69 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[90]); A_arbace_repr_clojure_rules_A_const_70 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[91]); A_arbace_repr_clojure_rules_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[92]); A_arbace_repr_clojure_rules_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[93]) }

func A_arbace_repr_clojure_rules_A_clinit_p6() { A_arbace_repr_clojure_rules_A_const_73 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[94]); A_arbace_repr_clojure_rules_A_const_74 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[95]); A_arbace_repr_clojure_rules_A_const_75 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[96]); A_arbace_repr_clojure_rules_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[97]); A_arbace_repr_clojure_rules_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[98]); A_arbace_repr_clojure_rules_A_const_78 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[99]); A_arbace_repr_clojure_rules_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[100]); A_arbace_repr_clojure_rules_A_const_80 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[101]); A_arbace_repr_clojure_rules_A_const_81 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[102]); A_arbace_repr_clojure_rules_A_const_82 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[103]); A_arbace_repr_clojure_rules_A_const_83 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[104]); A_arbace_repr_clojure_rules_A_const_84 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[105]) }

func A_arbace_repr_clojure_rules_A_clinit_p7() { A_arbace_repr_clojure_rules_A_const_85 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[106]); A_arbace_repr_clojure_rules_A_const_86 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[107]); A_arbace_repr_clojure_rules_A_const_87 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[108]); A_arbace_repr_clojure_rules_A_const_88 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[109]); A_arbace_repr_clojure_rules_A_const_89 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[110]); A_arbace_repr_clojure_rules_A_const_90 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[111]); A_arbace_repr_clojure_rules_A_const_91 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[112]) }

func A_arbace_repr_clojure_rules_A_New() *A_arbace_repr_clojure_rules_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_A_class }

func (t *A_arbace_repr_clojure_rules_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_A); return ok }

func A_arbace_repr_clojure_rules_A_Cast(x any) *A_arbace_repr_clojure_rules_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_A_class)) }; return v }



type A_arbace_repr_clojure_rules_applicable_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_applicable_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_applicable_fn__1700000166_A struct{ j2g_header uint64; F_ctx, F_skip any }

var A_arbace_repr_clojure_rules_applicable_fn__1700000166_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000096_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000098_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_clojure_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_cut_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_cut_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_defined_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A struct{ j2g_header uint64; F_iter__1700000101, F_s, F_s__1700000102 any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A struct{ j2g_header uint64; F_b__1700000104, F_s any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000107_fn__1700000111_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000101__1700000105_fn__1700000106_fn__1700000117_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000004_A_New() *A_arbace_repr_clojure_rules_eval1700000004_A { t := &A_arbace_repr_clojure_rules_eval1700000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000004_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000004_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000004_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000008_A_New() *A_arbace_repr_clojure_rules_eval1700000008_A { t := &A_arbace_repr_clojure_rules_eval1700000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000008_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000008_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000008_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000143_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000143_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000145_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000145_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000147_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000147_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000149_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000149_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000151_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000151_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000153_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000153_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000155_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000155_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000157_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000157_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000159_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000159_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000161_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000161_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000163_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000163_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_imports_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_insert_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_insert_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_print_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_print_text_fn__1700000169_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_print_text_fn__1700000169_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_security_manager_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000037_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000043_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000049_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A struct{ j2g_header uint64; F_sb, F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000055_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A struct{ j2g_header uint64; F_import_spans any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000028_fn__1700000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_translate_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_fn__1700000172_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_translate_fn__1700000172_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_uncore_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A struct{ j2g_header uint64; F_s, F_added any }

var A_arbace_repr_clojure_rules_uncore_names_fn__1700000140_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_uncore_names_suffix_QMARK___1700000138_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unproxy_methods_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unproxy_methods_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unproxy_methods_fn__1700000021_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_unqualify_security_manager_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000070_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000076_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000082_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A struct{ j2g_header uint64; F_sb, F_s any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_fn__1700000088_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A struct{ j2g_header uint64; F_import_spans any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_rules_unqualify_security_manager_in_import_QMARK___1700000061_fn__1700000063_A_fn_class *jrt.Class
