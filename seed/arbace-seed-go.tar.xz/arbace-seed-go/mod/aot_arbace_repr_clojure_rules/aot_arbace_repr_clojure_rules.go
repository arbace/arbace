//line aot_arbace_repr_clojure_rules.ae:1
package aot_arbace_repr_clojure_rules

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_New() *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_rules_A_const_3, A_arbace_repr_clojure_rules_A_const_4, A_arbace_repr_clojure_rules_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_New() *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules_A_const_10), A_arbace_repr_clojure_rules_A_const_8.GetRawRoot__O(), A_arbace_repr_clojure_rules_A_const_9) }


















func A_arbace_repr_clojure_rules_clojure_source_QMARK__A_New() *A_arbace_repr_clojure_rules_clojure_source_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_clojure_source_QMARK__A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Ctor() {}
//line :20:1
func (t *A_arbace_repr_clojure_rules_clojure_source_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_rules_A_const_12; return tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0)) }







func A_arbace_repr_clojure_rules_proxy_methods_A_New() *A_arbace_repr_clojure_rules_proxy_methods_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Ctor() {}
//line :28:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), s__0, A_arbace_repr_clojure_rules_A_const_16.GetRawRoot__O()) }
//line :31:1
func A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_New() *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A) Invoke_O_O_O__O(self, s__1, p__1700000013__2 any) any { var vec__1700000015__3 any = p__1700000013__2; var re__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000015__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(s__1, re__4, to__5) }





func A_arbace_repr_clojure_rules_imports_QMARK__A_New() *A_arbace_repr_clojure_rules_imports_QMARK__A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_imports_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_repr_clojure_rules_imports_QMARK__A) Invoke_O_O__O(self, head__0 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_clojure_rules_A_const_17, head__0) }

func A_arbace_repr_clojure_rules_security_manager_A_New() *A_arbace_repr_clojure_rules_security_manager_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Ctor() {}
//line :39:1
func (t *A_arbace_repr_clojure_rules_security_manager_A) Invoke_O_O__O(self, s__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O()))) { return s__0 } else { var import_spans__2 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_repr_clojure_rules_A_const_26.GetRawRoot__O()); var in_import_QMARK___3 any; var tmp1 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A_New_O(import_spans__2); var tmp2 *jrt.Class
		var fncls__13 /*line :43:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A_fn_class


		if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :43:1
		var tokens__4 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O()); var tmp4 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A_New_O(s__0); var tmp5 *jrt.Class
		var fncls__14 /*line :43:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A_fn_class



		if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A_fn_class = fncls__14d; tmp5 = fncls__14d } else { tmp5 = fncls__14 }; tokens__4 = tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_28.GetRawRoot__O()).Invoke_O__O(s__0))
//line :43:1
		var imported_QMARK___5 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O()); var tmp7 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A_New_O_O(s__0, in_import_QMARK___3); var tmp8 *jrt.Class
		var fncls__15 /*line :43:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A_fn_class




		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A_fn_class = fncls__15d; tmp8 = fncls__15d } else { tmp8 = fncls__15 }; imported_QMARK___5 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), tokens__4)
//line :43:1
		var uses__6 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O()); var tmp10 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A_New_O_O(s__0, in_import_QMARK___3); var tmp11 *jrt.Class
		var fncls__16 /*line :43:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A_fn_class







		if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A_fn_class = fncls__16d; tmp11 = fncls__16d } else { tmp11 = fncls__16 }; uses__6 = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), tokens__4)




		var tmp12 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp12 = or__1927000174__auto____7 } else { tmp12 = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O()).Invoke_O__O(uses__6) }; if jrt.J2g_Truth(tmp12) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O()); var tmp14 any = A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A_New_O_O(sb__7, s__0); var tmp15 *jrt.Class
			var fncls__17 /*line :56:1*/*jrt.Class = A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A_fn_class


			if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A_fn_class = fncls__17d; tmp15 = fncls__17d } else { tmp15 = fncls__17 }; end__8 = tmp13.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), A_arbace_repr_clojure_rules_A_const_30, uses__6)




			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I_NoInit(end__8), lang.RT_Count_O__I_NoInit(s__0))
			return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_23.GetRawRoot__O()).Invoke_O__O(sb__7) } } }
//line :46:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A{}; t.Ctor_O(p0); return t }
//line :46:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :46:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_20.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A_New_O(i__1); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_import_spans) }
//line :46:1
func A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A{}; t.Ctor_O(p0); return t }
//line :46:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :46:1
func (t *A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A) Invoke_O_O__O(self, p__1700000022__1 any) any { var vec__1700000024__2 any = p__1700000022__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000024__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000024__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 bool; var na_2 any = a__3; var na_3 any = t.F_i; var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(na_2); if tmp2 { tmp2 = jrt.Long_InstanceOf(na_3) }; tmp1 = tmp2; if tmp1 { var n0_4 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); var n1_5 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); and__1927000168__auto____5 = n0_4 <= n1_5 } else { var tmp3 bool; var tmp4 bool; tmp4 = jrt.Double_InstanceOf(na_2); if tmp4 { tmp4 = jrt.Double_InstanceOf(na_3) }; tmp3 = tmp4; if tmp3 { var n0_4_2 float64 = jrt.NN(jrt.Double_Cast(na_2)).DoubleValue__D(); var n1_5_2 float64 = jrt.NN(jrt.Double_Cast(na_3)).DoubleValue__D(); and__1927000168__auto____5 = n0_4_2 <= n1_5_2 } else { and__1927000168__auto____5 = lang.Numbers_Lte_O_O__Z_NoInit(na_2, na_3) } }; if and__1927000168__auto____5 { var tmp5 bool; var na_7 any = t.F_i; var na_8 any = b__4; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_7); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_8) }; tmp6 = tmp7; if tmp6 { var n0_9 int64 = jrt.NN(jrt.Long_Cast(na_7)).LongValue__J(); var n1_10 int64 = jrt.NN(jrt.Long_Cast(na_8)).LongValue__J(); tmp5 = n0_9 < n1_10 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_7); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_8) }; tmp8 = tmp9; if tmp8 { var n0_9_2 float64 = jrt.NN(jrt.Double_Cast(na_7)).DoubleValue__D(); var n1_10_2 float64 = jrt.NN(jrt.Double_Cast(na_8)).DoubleValue__D(); tmp5 = n0_9_2 < n1_10_2 } else { tmp5 = lang.Numbers_Lt_O_O__Z_NoInit(na_7, na_8) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A_New_O(p0 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A{}; t.Ctor_O(p0); return t }
//line :47:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :47:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A) Invoke_O_O__O(self, p__1700000029__1 any) any { var vec__1700000031__2 any = p__1700000029__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4), A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O()) }
func A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A{}; t.Ctor_O_O(p0, p1); return t }
//line :48:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :48:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A) Invoke_O_O__O(self, p__1700000035__1 any) any { var vec__1700000037__2 any = p__1700000035__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000037__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000037__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.J2g_Truth(and__1927000168__auto____5) {
															return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O())).Ref())), lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4)) } else {
//line :48:1
		return and__1927000168__auto____5 } }


func A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :51:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A) Invoke_O_O__O(self, p__1700000041__1 any) any { var vec__1700000043__2 any = p__1700000041__1; var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000043__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000043__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t__5 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4); var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3)); if

	jrt.J2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_25), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_29.GetRawRoot__O()).Invoke_O_O__O(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_rules_A_const_25.GetRawRoot__O(), nil)).Ref()) } } } else {
//line :53:1
			return and__1927000168__auto____6 } }





func A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :59:1
func (t *A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A) Invoke_O_O_O__O(self, i__1, p__1700000047__2 any) any { var vec__1700000049__3 any = p__1700000047__2; var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000049__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000049__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
																jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(i__1), lang.RT_IntCast_O__I_NoInit(a__4)); var tmp3 /*line :61:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp3).Append_String__StringBuilder(Lit_24); return a__4 }







func A_arbace_repr_clojure_rules_arbace_core_names_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Ctor() {}
//line :69:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_A) Invoke_O__O(self any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_31.GetRawRoot__O()); var tmp2 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_32.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O()); var tmp5 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A_New(); var tmp6 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A_fn_class = fncls__18d; tmp6 = fncls__18d } else { tmp6 = fncls__18 }; var tmp7 any = tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_34.GetRawRoot__O()); var tmp9 any = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A_New(); var tmp10 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A_fn_class = fncls__19d; tmp10 = fncls__19d } else { tmp10 = fncls__19 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp7, tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil))), lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rules_A_const_38))) }
//line :73:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A) Ctor() {}
//line :73:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A) Invoke_O_O__O(self, p1__1700000054_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_repr_clojure_rules_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_4, tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1700000054_SHARP___1)))).Ref() }
//line :73:1
func A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A_New() *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A) Ctor() {}
//line :73:1
func (t *A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A) Invoke_O_O__O(self, p1__1700000055_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(p1__1700000055_SHARP___1).F_sym.Ref()) }






func A_arbace_repr_clojure_rules_defined_names_A_New() *A_arbace_repr_clojure_rules_defined_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Ctor() {}
//line :80:1
func (t *A_arbace_repr_clojure_rules_defined_names_A) Invoke_O_O__O(self, s__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A_New_O(s__0); var tmp2 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A_fn_class; if


	fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_repr_clojure_rules_A_const_55.GetRawRoot__O())) }
//line :83:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A_New_O(p0 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A{}; t.Ctor_O(p0); return t }
//line :83:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :83:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A) Invoke_O_O__O(self, s__1700000062__1 any) any { var tmp1 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A_New_O_O_O(t.F_s, s__1700000062__1, self); var tmp2 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A_fn_class = fncls__51d; tmp2 = fncls__51d } else { tmp2 = fncls__51 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :83:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :83:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A) Ctor_O_O_O(c__s, c__s__1700000062, c__iter__1700000061 any) { t.F_s = c__s; t.F_s__1700000062 = c__s__1700000062; t.F_iter__1700000061 = c__iter__1700000061 }
//line :83:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A) Invoke_O__O(self any) any { { var s__1700000062__1 any; var t_ any = t.F_s__1700000062; t.F_s__1700000062 = nil; s__1700000062__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_39.GetRawRoot__O()).Invoke_O__O(s__1700000062__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1700000062__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_40.GetRawRoot__O()).Invoke_O__O(s__1700000062__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1700000062__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1700000064__6 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_42.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A_New_O_O_I_O(b__1700000064__6, t.F_s, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1700000061); return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O()).Invoke_O__O(b__1700000064__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_53.GetRawRoot__O()).Invoke_O__O(s__1700000062__3))) } else { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_52.GetRawRoot__O()).Invoke_O__O(b__1700000064__6), nil) } } else { var vec__1700000074__4 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_50.GetRawRoot__O()).Invoke_O__O(s__1700000062__3); var a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000074__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000074__4, lang.RT_IntCast_J__I_NoInit(1), nil); var h__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp5 any = t.F_s; var tmp6 jrt.Number_I; var na_49 any = a__5; _ = ___6
																if jrt.Long_InstanceOf(na_49) { var n0_50 int64 = jrt.NN(jrt.Long_Cast(na_49)).LongValue__J(); if n0_50 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_49) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_50 + 1)) } } else { if jrt.Double_InstanceOf(na_49) { var n0_50_2 float64 = jrt.NN(jrt.Double_Cast(na_49)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_50_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_49) } }; h__7 = tmp4.Invoke_O_O__O(tmp5, tmp6)
//line :83:1
	var j__8 any; var tmp7 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A_New_O_O(h__7, t.F_s); var tmp8 *jrt.Class
	var fncls__48 /*line :83:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A_fn_class

	if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A_fn_class = fncls__48d; tmp8 = fncls__48d } else { tmp8 = fncls__48 }; j__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :83:1
	var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()); var tmp10 any = t.F_s; var t__9 any = tmp9.Invoke_O_O_O__O(tmp10, j__8, lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O()).Invoke_O_O__O(t.F_s, j__8)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_39.GetRawRoot__O()).Invoke_O__O(t__9)) { var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1700000061); return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_51.GetRawRoot__O()).Invoke_O_O__O(t__9, tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O()).Invoke_O__O(s__1700000062__3))) } else { s__1700000062__1 = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_54.GetRawRoot__O()).Invoke_O__O(s__1700000062__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :83:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :83:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A) Ctor_O_O_I_O(c__b__1700000064, c__s any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1700000064 = c__b__1700000064; t.F_s = c__s; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :83:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A) Invoke_O__O(self any) any { { var i__1700000063__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1700000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1700000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1700000063__1)); var a__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000068__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000068__2, lang.RT_IntCast_J__I_NoInit(1), nil); var h__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp3 any = t.F_s; var tmp4 jrt.Number_I; var na_33 any = a__3; _ = ___4
																		if jrt.Long_InstanceOf(na_33) { var n0_34 int64 = jrt.NN(jrt.Long_Cast(na_33)).LongValue__J(); if n0_34 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_33) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_34 + 1)) } } else { if jrt.Double_InstanceOf(na_33) { var n0_34_2 float64 = jrt.NN(jrt.Double_Cast(na_33)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_34_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_33) } }; h__5 = tmp2.Invoke_O_O__O(tmp3, tmp4)
//line :83:1
	var j__6 any; var tmp5 any = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A_New_O_O(h__5, t.F_s); var tmp6 *jrt.Class
	var fncls__32 /*line :83:1*/*jrt.Class = A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A_fn_class

	if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A_fn_class = fncls__32d; tmp6 = fncls__32d } else { tmp6 = fncls__32 }; j__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :83:1
	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()); var tmp8 any = t.F_s; var t__7 any = tmp7.Invoke_O_O_O__O(tmp8, j__6, lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O()).Invoke_O_O__O(t.F_s, j__6)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_39.GetRawRoot__O()).Invoke_O__O(t__7)) { lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_48.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1700000064, t__7); i__1700000063__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000063__1); continue L1 } else { i__1700000063__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1700000063__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :85:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :85:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp2 any = t.F_s; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O()); var tmp4 any = t.F_s; var tmp5 any; var t_ any = t.F_h; t.F_h = nil; tmp5 = t_; j__1 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5)); L1: for {

	var tmp6 bool; var na_20 any = j__1; var na_21 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_20) { var n0_22 int64 = jrt.NN(jrt.Long_Cast(na_20)).LongValue__J(); var n1_23 int64 = na_21; tmp6 = n0_22 >= n1_23 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_20, na_21) }; if tmp6 { return j__1 } else { var tmp7 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_44)).CharValue__C(), jrt.NN(tmp7).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp9 any = t.F_s; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_47.GetRawRoot__O()); var tmp11 any = t.F_s; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp13 any = t.F_s; var tmp14 jrt.Number_I; var na_25 any = j__1; if jrt.Long_InstanceOf(na_25) { var n0_26 int64 = jrt.NN(jrt.Long_Cast(na_25)).LongValue__J(); if n0_26 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_25) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_26 + 1)) } } else { if jrt.Double_InstanceOf(na_25) { var n0_26_2 float64 = jrt.NN(jrt.Double_Cast(na_25)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_26_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_25) } }; j__1 = tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13, tmp14))); continue L1 } else {
//line :87:1
			var tmp15 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp15).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp17 any = t.F_s; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_47.GetRawRoot__O()); var tmp19 any = t.F_s; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp21 any = t.F_s; var tmp22 jrt.Number_I; var na_27 any = j__1; var na_28 int64 = 2; if jrt.Long_InstanceOf(na_27) { var n0_29 int64 = jrt.NN(jrt.Long_Cast(na_27)).LongValue__J(); var n1_30 int64 = na_28; var nr_31 int64 = n0_29 + n1_30; if (n0_29^nr_31)&(n1_30^nr_31) >= 0 { tmp22 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_31)) } else { tmp22 = lang.Numbers_Add_O_J__Number_NoInit(na_27, na_28) } } else { tmp22 = lang.Numbers_Add_O_J__Number_NoInit(na_27, na_28) }; j__1 = tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O__O(tmp21, tmp22))); continue L1 } else {
//line :87:1
					if A_arbace_repr_clojure_rules_A_const_45 != nil { return j__1 } else { return nil } } } } } }; /*line :85:1*/panic("j2g: unreachable") }
//line :85:1
func A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :85:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :85:1
func (t *A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp2 any = t.F_s; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_46.GetRawRoot__O()); var tmp4 any = t.F_s; var tmp5 any; var t_ any = t.F_h; t.F_h = nil; tmp5 = t_; j__1 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5)); L1: for {

	var tmp6 bool; var na_36 any = j__1; var na_37 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_36) { var n0_38 int64 = jrt.NN(jrt.Long_Cast(na_36)).LongValue__J(); var n1_39 int64 = na_37; tmp6 = n0_38 >= n1_39 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_36, na_37) }; if tmp6 { return j__1 } else { var tmp7 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_rules_A_const_44)).CharValue__C(), jrt.NN(tmp7).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {

		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp9 any = t.F_s; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_47.GetRawRoot__O()); var tmp11 any = t.F_s; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp13 any = t.F_s; var tmp14 jrt.Number_I; var na_41 any = j__1; if jrt.Long_InstanceOf(na_41) { var n0_42 int64 = jrt.NN(jrt.Long_Cast(na_41)).LongValue__J(); if n0_42 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_41) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_42 + 1)) } } else { if jrt.Double_InstanceOf(na_41) { var n0_42_2 float64 = jrt.NN(jrt.Double_Cast(na_41)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_42_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_41) } }; j__1 = tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13, tmp14))); continue L1 } else {
//line :87:1
			var tmp15 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp15).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I_NoInit(j__1)) {



				var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp17 any = t.F_s; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_47.GetRawRoot__O()); var tmp19 any = t.F_s; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp21 any = t.F_s; var tmp22 jrt.Number_I; var na_43 any = j__1; var na_44 int64 = 2; if jrt.Long_InstanceOf(na_43) { var n0_45 int64 = jrt.NN(jrt.Long_Cast(na_43)).LongValue__J(); var n1_46 int64 = na_44; var nr_47 int64 = n0_45 + n1_46; if (n0_45^nr_47)&(n1_46^nr_47) >= 0 { tmp22 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_47)) } else { tmp22 = lang.Numbers_Add_O_J__Number_NoInit(na_43, na_44) } } else { tmp22 = lang.Numbers_Add_O_J__Number_NoInit(na_43, na_44) }; j__1 = tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O__O(tmp21, tmp22))); continue L1 } else {
//line :87:1
					if A_arbace_repr_clojure_rules_A_const_45 != nil { return j__1 } else { return nil } } } } } }; /*line :85:1*/panic("j2g: unreachable") }











func A_arbace_repr_clojure_rules_insert_at_A_New() *A_arbace_repr_clojure_rules_insert_at_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_insert_at_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_clojure_rules_insert_at_A) Invoke_O_O_O_O__O(self, s__0, i__1, x__2 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(s__0, A_arbace_repr_clojure_rules_A_const_30, i__1), x__2, lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1))).Ref() }

func A_arbace_repr_clojure_rules_core_names_A_New() *A_arbace_repr_clojure_rules_core_names_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_core_names_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Ctor() {}
//line :99:1
func (t *A_arbace_repr_clojure_rules_core_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O()).Invoke_O_O__O(added__1, lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_61.GetRawRoot__O()).Invoke_O__O(s__0)))); var vec__1700000083__4 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_repr_clojure_rules_A_const_62)); var ns_a__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000083__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_22.GetRawRoot__O()).Invoke_O__O(names__3); if








	jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ns_a__5, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var ns_text__7 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(s__0, ns_a__5, ns_b__6); var names_text__8 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_57.GetRawRoot__O()).Invoke_O_O__O(Lit_5, names__3); var vec__1700000086__9 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(ns_text__7, A_arbace_repr_clojure_rules_A_const_63)); var ra__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000086__9, lang.RT_IntCast_J__I_NoInit(0), nil); var rb__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1700000086__9, lang.RT_IntCast_J__I_NoInit(1), nil)




		if lang.Util_Identical_O_O__Z_NoInit(ra__10, nil) {

			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O()); var tmp3 jrt.Number_I; var na_53 any = ns_b__6; if jrt.Long_InstanceOf(na_53) { var n0_54 int64 = jrt.NN(jrt.Long_Cast(na_53)).LongValue__J(); if n0_54 == -9223372036854775808 { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_53) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_54 - 1)) } } else { if jrt.Double_InstanceOf(na_53) { var n0_54_2 float64 = jrt.NN(jrt.Double_Cast(na_53)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_54_2 - 1.0)) } else { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_53) } }; return tmp2.Invoke_O_O_O__O(s__0, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref()) } else {
//line :113:1
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(ns_text__7, ra__10, rb__11), Lit_8)) { return s__0 } else { if A_arbace_repr_clojure_rules_A_const_45 != nil { var rc__12 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(ns_text__7, ra__10, rb__11); var ex__13 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_59.GetRawRoot__O()).Invoke_O_O__O(rc__12, Lit_9)







					if lang.Util_Identical_O_O__Z_NoInit(ex__13, nil) {
						var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_55 any; var na_57 any = ns_a__5; var na_58 any = ra__10; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_57); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_58) }; tmp6 = tmp7; if tmp6 { var n0_59 int64 = jrt.NN(jrt.Long_Cast(na_57)).LongValue__J(); var n1_60 int64 = jrt.NN(jrt.Long_Cast(na_58)).LongValue__J(); var nr_61 int64 = n0_59 + n1_60; if (n0_59^nr_61)&(n1_60^nr_61) >= 0 { na_55 = jrt.Long_ValueOf_J__Long_NoInit(nr_61).Ref() } else { na_55 = lang.Numbers_Add_O_O__Number_NoInit(na_57, na_58) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_57); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_58) }; tmp8 = tmp9; if tmp8 { var n0_59_2 float64 = jrt.NN(jrt.Double_Cast(na_57)).DoubleValue__D(); var n1_60_2 float64 = jrt.NN(jrt.Double_Cast(na_58)).DoubleValue__D(); na_55 = jrt.Double_ValueOf_D__Double_NoInit(n0_59_2 + n1_60_2).Ref() } else { na_55 = lang.Numbers_Add_O_O__Number_NoInit(na_57, na_58) } }; var na_56 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rc__12))); if jrt.Long_InstanceOf(na_55) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_55)).LongValue__J(); var n1_63 int64 = na_56; var nr_64 int64 = n0_62 + n1_63; if (n0_62^nr_64)&(n1_63^nr_64) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_64)) } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_55, na_56) } } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_55, na_56) }; return tmp4.Invoke_O_O_O__O(s__0, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref()) } else {
//line :121:1
							var v__14 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_43.GetRawRoot__O()); var tmp11 jrt.Number_I; var na_65 any = ex__13; var na_66 int64 = int64(lang.RT_Count_O__I_NoInit(Lit_9))

							if jrt.Long_InstanceOf(na_65) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); var n1_68 int64 = na_66; var nr_69 int64 = n0_67 + n1_68; if (n0_67^nr_69)&(n1_68^nr_69) >= 0 { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_69)) } else { tmp11 = lang.Numbers_Add_O_J__Number_NoInit(na_65, na_66) } } else { tmp11 = lang.Numbers_Add_O_J__Number_NoInit(na_65, na_66) }; v__14 = tmp10.Invoke_O_O__O(rc__12, tmp11)
//line :121:1
							var ve__15 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_47.GetRawRoot__O()).Invoke_O_O__O(rc__12, v__14); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_58.GetRawRoot__O()); var tmp13 jrt.Number_I; var na_70 any; var na_72 any = ns_a__5; var na_73 any = ra__10; var tmp14 bool; var tmp15 bool



							tmp15 = jrt.Long_InstanceOf(na_72); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_73) }; tmp14 = tmp15; if tmp14 { var n0_74 int64 = jrt.NN(jrt.Long_Cast(na_72)).LongValue__J(); var n1_75 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); var nr_76 int64 = n0_74 + n1_75; if (n0_74^nr_76)&(n1_75^nr_76) >= 0 { na_70 = jrt.Long_ValueOf_J__Long_NoInit(nr_76).Ref() } else { na_70 = lang.Numbers_Add_O_O__Number_NoInit(na_72, na_73) } } else { var tmp16 bool; var tmp17 bool; tmp17 = jrt.Double_InstanceOf(na_72); if tmp17 { tmp17 = jrt.Double_InstanceOf(na_73) }; tmp16 = tmp17; if tmp16 { var n0_74_2 float64 = jrt.NN(jrt.Double_Cast(na_72)).DoubleValue__D(); var n1_75_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); na_70 = jrt.Double_ValueOf_D__Double_NoInit(n0_74_2 + n1_75_2).Ref() } else { na_70 = lang.Numbers_Add_O_O__Number_NoInit(na_72, na_73) } }; var na_71 any; var na_77 any = ve__15; if jrt.Long_InstanceOf(na_77) { var n0_78 int64 = jrt.NN(jrt.Long_Cast(na_77)).LongValue__J(); if n0_78 == -9223372036854775808 { na_71 = lang.Numbers_Dec_O__Number_NoInit(na_77) } else { na_71 = jrt.Long_ValueOf_J__Long_NoInit(n0_78 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_77) { var n0_78_2 float64 = jrt.NN(jrt.Double_Cast(na_77)).DoubleValue__D(); na_71 = jrt.Double_ValueOf_D__Double_NoInit(n0_78_2 - 1.0).Ref() } else { na_71 = lang.Numbers_Dec_O__Number_NoInit(na_77) } }; var tmp18 bool; var tmp19 bool; tmp19 = jrt.Long_InstanceOf(na_70); if tmp19 { tmp19 = jrt.Long_InstanceOf(na_71) }; tmp18 = tmp19; if tmp18 { var n0_79 int64 = jrt.NN(jrt.Long_Cast(na_70)).LongValue__J(); var n1_80 int64 = jrt.NN(jrt.Long_Cast(na_71)).LongValue__J(); var nr_81 int64 = n0_79 + n1_80; if (n0_79^nr_81)&(n1_80^nr_81) >= 0 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_81)) } else { tmp13 = lang.Numbers_Add_O_O__Number_NoInit(na_70, na_71) } } else { var tmp20 bool; var tmp21 bool; tmp21 = jrt.Double_InstanceOf(na_70); if tmp21 { tmp21 = jrt.Double_InstanceOf(na_71) }; tmp20 = tmp21; if tmp20 { var n0_79_2 float64 = jrt.NN(jrt.Double_Cast(na_70)).DoubleValue__D(); var n1_80_2 float64 = jrt.NN(jrt.Double_Cast(na_71)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_79_2 + n1_80_2)) } else { tmp13 = lang.Numbers_Add_O_O__Number_NoInit(na_70, na_71) } }; return tmp12.Invoke_O_O_O__O(s__0, tmp13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8)).Ref()) } } else {
//line :113:1
								return nil } } } } }



















func A_arbace_repr_clojure_rules_fn__1700000090_A_New() *A_arbace_repr_clojure_rules_fn__1700000090_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000090_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_repr_clojure_rules_fn__1700000090_A) Ctor() {}
//line :133:1
func (t *A_arbace_repr_clojure_rules_fn__1700000090_A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 any = A_arbace_repr_clojure_rules_A_const_64; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_rules_A_const_13.Invoke_O__O(ctx__0)); if and__1927000168__auto____2 { return A_arbace_repr_clojure_rules_A_const_65.Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_repr_clojure_rules_fn__1700000092_A_New() *A_arbace_repr_clojure_rules_fn__1700000092_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000092_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_repr_clojure_rules_fn__1700000092_A) Ctor() {}
//line :134:1
func (t *A_arbace_repr_clojure_rules_fn__1700000092_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_66.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_repr_clojure_rules_A_const_67.Invoke_O__O(ctx__1)) }






func A_arbace_repr_clojure_rules_fn__1700000094_A_New() *A_arbace_repr_clojure_rules_fn__1700000094_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000094_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_repr_clojure_rules_fn__1700000094_A) Ctor() {}
//line :141:1
func (t *A_arbace_repr_clojure_rules_fn__1700000094_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_68.GetRawRoot__O()).Invoke_O__O(s__0) }





func A_arbace_repr_clojure_rules_fn__1700000096_A_New() *A_arbace_repr_clojure_rules_fn__1700000096_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000096_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_repr_clojure_rules_fn__1700000096_A) Ctor() {}
//line :147:1
func (t *A_arbace_repr_clojure_rules_fn__1700000096_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_69.GetRawRoot__O()).Invoke_O__O(s__0) }





func A_arbace_repr_clojure_rules_fn__1700000098_A_New() *A_arbace_repr_clojure_rules_fn__1700000098_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000098_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_repr_clojure_rules_fn__1700000098_A) Ctor() {}
//line :153:1
func (t *A_arbace_repr_clojure_rules_fn__1700000098_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_70.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____3 any = A_arbace_repr_clojure_rules_A_const_71.Invoke_O__O(ctx__1); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_72.GetRawRoot__O()).Invoke__O() }; return tmp1.Invoke_O_O__O(s__0, tmp2) }




func A_arbace_repr_clojure_rules_fn__1700000100_A_New() *A_arbace_repr_clojure_rules_fn__1700000100_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_fn__1700000100_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_repr_clojure_rules_fn__1700000100_A) Ctor() {}
//line :158:1
func (t *A_arbace_repr_clojure_rules_fn__1700000100_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_73.GetRawRoot__O()).Invoke_O__O(s__0) }































func A_arbace_repr_clojure_rules_applicable_A_New() *A_arbace_repr_clojure_rules_applicable_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Ctor() {}
//line :190:1
func (t *A_arbace_repr_clojure_rules_applicable_A) Invoke_O_O_O__O(self, ctx__0, skip__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_rules_applicable_fn__1700000103_A_New_O_O(ctx__0, skip__1); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_repr_clojure_rules_applicable_fn__1700000103_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_clojure_rules_applicable_fn__1700000103_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_repr_clojure_rules_A_const_76.GetRawRoot__O()) }
//line :193:1
func A_arbace_repr_clojure_rules_applicable_fn__1700000103_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_rules_applicable_fn__1700000103_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_applicable_fn__1700000103_A{}; t.Ctor_O_O(p0, p1); return t }
//line :193:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000103_A) Ctor_O_O(c__ctx, c__skip any) { t.F_ctx = c__ctx; t.F_skip = c__skip }
//line :193:1
func (t *A_arbace_repr_clojure_rules_applicable_fn__1700000103_A) Invoke_O_O__O(self, p1__1700000102_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_11.GetRawRoot__O()); var tmp2 any = t.F_skip; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_18.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_clojure_rules_A_const_75.Invoke_O__O(p1__1700000102_SHARP___1))); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_74.Invoke_O__O(p1__1700000102_SHARP___1)).Invoke_O__O(t.F_ctx) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_clojure_rules_translate_A_New() *A_arbace_repr_clojure_rules_translate_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repr_clojure_rules_translate_A) Ctor() {}
//line :195:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_rules_translate_fn__1700000106_A_New_O(ctx__1); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_repr_clojure_rules_translate_fn__1700000106_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_clojure_rules_translate_fn__1700000106_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), s__0, lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_78.GetRawRoot__O()).Invoke_O_O__O(ctx__1, skip__2)) }
//line :195:1
func (t *A_arbace_repr_clojure_rules_translate_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {


	return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(s__0, ctx__1, lang.PersistentHashSet_EMPTY.Ref())
}
func A_arbace_repr_clojure_rules_translate_fn__1700000106_A_New_O(p0 any) *A_arbace_repr_clojure_rules_translate_fn__1700000106_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_translate_fn__1700000106_A{}; t.Ctor_O(p0); return t }
//line :200:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000106_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :200:1
func (t *A_arbace_repr_clojure_rules_translate_fn__1700000106_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rules_A_const_77.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

















type A_arbace_repr_clojure_rules_A struct{ jrt.Object }

var A_arbace_repr_clojure_rules_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rules_A_const_0 *lang.Var

var A_arbace_repr_clojure_rules_A_const_1 *lang.Var

var A_arbace_repr_clojure_rules_A_const_2 any

var A_arbace_repr_clojure_rules_A_const_3 any

var A_arbace_repr_clojure_rules_A_const_4 any

var A_arbace_repr_clojure_rules_A_const_5 any

var A_arbace_repr_clojure_rules_A_const_6 *lang.Var

var A_arbace_repr_clojure_rules_A_const_7 *lang.Var

var A_arbace_repr_clojure_rules_A_const_8 *lang.Var

var A_arbace_repr_clojure_rules_A_const_9 any

var A_arbace_repr_clojure_rules_A_const_10 *lang.Var

var A_arbace_repr_clojure_rules_A_const_11 *lang.Var

var A_arbace_repr_clojure_rules_A_const_12 any

var A_arbace_repr_clojure_rules_A_const_13 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_14 *lang.Var

var A_arbace_repr_clojure_rules_A_const_15 *lang.Var

var A_arbace_repr_clojure_rules_A_const_16 *lang.Var

var A_arbace_repr_clojure_rules_A_const_17 any

var A_arbace_repr_clojure_rules_A_const_18 *lang.Var

var A_arbace_repr_clojure_rules_A_const_19 *lang.Var

var A_arbace_repr_clojure_rules_A_const_20 *lang.Var

var A_arbace_repr_clojure_rules_A_const_21 *lang.Var

var A_arbace_repr_clojure_rules_A_const_22 *lang.Var

var A_arbace_repr_clojure_rules_A_const_23 *lang.Var

var A_arbace_repr_clojure_rules_A_const_24 *lang.Var

var A_arbace_repr_clojure_rules_A_const_25 *lang.Var

var A_arbace_repr_clojure_rules_A_const_26 *lang.Var

var A_arbace_repr_clojure_rules_A_const_27 *lang.Var

var A_arbace_repr_clojure_rules_A_const_28 *lang.Var

var A_arbace_repr_clojure_rules_A_const_29 *lang.Var

var A_arbace_repr_clojure_rules_A_const_30 any

var A_arbace_repr_clojure_rules_A_const_31 *lang.Var

var A_arbace_repr_clojure_rules_A_const_32 *lang.Var

var A_arbace_repr_clojure_rules_A_const_33 *lang.Var

var A_arbace_repr_clojure_rules_A_const_34 *lang.Var

var A_arbace_repr_clojure_rules_A_const_35 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_36 *lang.Var

var A_arbace_repr_clojure_rules_A_const_37 *lang.Var

var A_arbace_repr_clojure_rules_A_const_38 any

var A_arbace_repr_clojure_rules_A_const_39 *lang.Var

var A_arbace_repr_clojure_rules_A_const_40 *lang.Var

var A_arbace_repr_clojure_rules_A_const_41 *lang.Var

var A_arbace_repr_clojure_rules_A_const_42 *lang.Var

var A_arbace_repr_clojure_rules_A_const_43 *lang.Var

var A_arbace_repr_clojure_rules_A_const_44 any

var A_arbace_repr_clojure_rules_A_const_45 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_46 *lang.Var

var A_arbace_repr_clojure_rules_A_const_47 *lang.Var

var A_arbace_repr_clojure_rules_A_const_48 *lang.Var

var A_arbace_repr_clojure_rules_A_const_49 *lang.Var

var A_arbace_repr_clojure_rules_A_const_50 *lang.Var

var A_arbace_repr_clojure_rules_A_const_51 *lang.Var

var A_arbace_repr_clojure_rules_A_const_52 *lang.Var

var A_arbace_repr_clojure_rules_A_const_53 *lang.Var

var A_arbace_repr_clojure_rules_A_const_54 *lang.Var

var A_arbace_repr_clojure_rules_A_const_55 *lang.Var

var A_arbace_repr_clojure_rules_A_const_56 *lang.Var

var A_arbace_repr_clojure_rules_A_const_57 *lang.Var

var A_arbace_repr_clojure_rules_A_const_58 *lang.Var

var A_arbace_repr_clojure_rules_A_const_59 *lang.Var

var A_arbace_repr_clojure_rules_A_const_60 *lang.Var

var A_arbace_repr_clojure_rules_A_const_61 *lang.Var

var A_arbace_repr_clojure_rules_A_const_62 any

var A_arbace_repr_clojure_rules_A_const_63 any

var A_arbace_repr_clojure_rules_A_const_64 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_65 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_66 *lang.Var

var A_arbace_repr_clojure_rules_A_const_67 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_68 *lang.Var

var A_arbace_repr_clojure_rules_A_const_69 *lang.Var

var A_arbace_repr_clojure_rules_A_const_70 *lang.Var

var A_arbace_repr_clojure_rules_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_72 *lang.Var

var A_arbace_repr_clojure_rules_A_const_73 *lang.Var

var A_arbace_repr_clojure_rules_A_const_74 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_75 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_76 *lang.Var

var A_arbace_repr_clojure_rules_A_const_77 *lang.Keyword

var A_arbace_repr_clojure_rules_A_const_78 *lang.Var

var A_arbace_repr_clojure_rules_A_const_79 *lang.Var

var A_arbace_repr_clojure_rules_A_init jrt.ClassInit

func A_arbace_repr_clojure_rules_A_Init() { if !A_arbace_repr_clojure_rules_A_init.Done() { A_arbace_repr_clojure_rules_A_init.Run(A_arbace_repr_clojure_rules_A_clinit) } }

func A_arbace_repr_clojure_rules_A_clinit() { A_arbace_repr_clojure_rules_A_clinit_p0(); A_arbace_repr_clojure_rules_A_clinit_p1(); A_arbace_repr_clojure_rules_A_clinit_p2(); A_arbace_repr_clojure_rules_A_clinit_p3(); A_arbace_repr_clojure_rules_A_clinit_p4(); A_arbace_repr_clojure_rules_A_clinit_p5(); A_arbace_repr_clojure_rules_A_clinit_p6() }

func A_arbace_repr_clojure_rules_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rules_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 100); A_arbace_repr_clojure_rules_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[20]); A_arbace_repr_clojure_rules_A_const_1 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[21]); A_arbace_repr_clojure_rules_A_const_2 = A_arbace_repr_clojure_rules_A_const_pool.A[22]; A_arbace_repr_clojure_rules_A_const_3 = A_arbace_repr_clojure_rules_A_const_pool.A[23]; A_arbace_repr_clojure_rules_A_const_4 = A_arbace_repr_clojure_rules_A_const_pool.A[24]; A_arbace_repr_clojure_rules_A_const_5 = A_arbace_repr_clojure_rules_A_const_pool.A[25]; A_arbace_repr_clojure_rules_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[26]); A_arbace_repr_clojure_rules_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[27]); A_arbace_repr_clojure_rules_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[28]); A_arbace_repr_clojure_rules_A_const_9 = A_arbace_repr_clojure_rules_A_const_pool.A[29]; A_arbace_repr_clojure_rules_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[30]); A_arbace_repr_clojure_rules_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[31]) }

func A_arbace_repr_clojure_rules_A_clinit_p1() { A_arbace_repr_clojure_rules_A_const_12 = A_arbace_repr_clojure_rules_A_const_pool.A[32]; A_arbace_repr_clojure_rules_A_const_13 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[33]); A_arbace_repr_clojure_rules_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[34]); A_arbace_repr_clojure_rules_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[35]); A_arbace_repr_clojure_rules_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[36]); A_arbace_repr_clojure_rules_A_const_17 = A_arbace_repr_clojure_rules_A_const_pool.A[37]; A_arbace_repr_clojure_rules_A_const_18 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[38]); A_arbace_repr_clojure_rules_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[39]); A_arbace_repr_clojure_rules_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[40]); A_arbace_repr_clojure_rules_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[41]); A_arbace_repr_clojure_rules_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[42]); A_arbace_repr_clojure_rules_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[43]) }

func A_arbace_repr_clojure_rules_A_clinit_p2() { A_arbace_repr_clojure_rules_A_const_24 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[44]); A_arbace_repr_clojure_rules_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[45]); A_arbace_repr_clojure_rules_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[46]); A_arbace_repr_clojure_rules_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[47]); A_arbace_repr_clojure_rules_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[48]); A_arbace_repr_clojure_rules_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[49]); A_arbace_repr_clojure_rules_A_const_30 = A_arbace_repr_clojure_rules_A_const_pool.A[50]; A_arbace_repr_clojure_rules_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[51]); A_arbace_repr_clojure_rules_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[52]); A_arbace_repr_clojure_rules_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[53]); A_arbace_repr_clojure_rules_A_const_34 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[54]); A_arbace_repr_clojure_rules_A_const_35 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[55]) }

func A_arbace_repr_clojure_rules_A_clinit_p3() { A_arbace_repr_clojure_rules_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[56]); A_arbace_repr_clojure_rules_A_const_37 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[57]); A_arbace_repr_clojure_rules_A_const_38 = A_arbace_repr_clojure_rules_A_const_pool.A[58]; A_arbace_repr_clojure_rules_A_const_39 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[59]); A_arbace_repr_clojure_rules_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[60]); A_arbace_repr_clojure_rules_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[61]); A_arbace_repr_clojure_rules_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[62]); A_arbace_repr_clojure_rules_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[63]); A_arbace_repr_clojure_rules_A_const_44 = A_arbace_repr_clojure_rules_A_const_pool.A[64]; A_arbace_repr_clojure_rules_A_const_45 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[65]); A_arbace_repr_clojure_rules_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[66]); A_arbace_repr_clojure_rules_A_const_47 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[67]) }

func A_arbace_repr_clojure_rules_A_clinit_p4() { A_arbace_repr_clojure_rules_A_const_48 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[68]); A_arbace_repr_clojure_rules_A_const_49 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[69]); A_arbace_repr_clojure_rules_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[70]); A_arbace_repr_clojure_rules_A_const_51 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[71]); A_arbace_repr_clojure_rules_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[72]); A_arbace_repr_clojure_rules_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[73]); A_arbace_repr_clojure_rules_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[74]); A_arbace_repr_clojure_rules_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[75]); A_arbace_repr_clojure_rules_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[76]); A_arbace_repr_clojure_rules_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[77]); A_arbace_repr_clojure_rules_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[78]); A_arbace_repr_clojure_rules_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[79]) }

func A_arbace_repr_clojure_rules_A_clinit_p5() { A_arbace_repr_clojure_rules_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[80]); A_arbace_repr_clojure_rules_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[81]); A_arbace_repr_clojure_rules_A_const_62 = A_arbace_repr_clojure_rules_A_const_pool.A[82]; A_arbace_repr_clojure_rules_A_const_63 = A_arbace_repr_clojure_rules_A_const_pool.A[83]; A_arbace_repr_clojure_rules_A_const_64 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[84]); A_arbace_repr_clojure_rules_A_const_65 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[85]); A_arbace_repr_clojure_rules_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[86]); A_arbace_repr_clojure_rules_A_const_67 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[87]); A_arbace_repr_clojure_rules_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[88]); A_arbace_repr_clojure_rules_A_const_69 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[89]); A_arbace_repr_clojure_rules_A_const_70 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[90]); A_arbace_repr_clojure_rules_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[91]) }

func A_arbace_repr_clojure_rules_A_clinit_p6() { A_arbace_repr_clojure_rules_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[92]); A_arbace_repr_clojure_rules_A_const_73 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[93]); A_arbace_repr_clojure_rules_A_const_74 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[94]); A_arbace_repr_clojure_rules_A_const_75 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[95]); A_arbace_repr_clojure_rules_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[96]); A_arbace_repr_clojure_rules_A_const_77 = lang.Keyword_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[97]); A_arbace_repr_clojure_rules_A_const_78 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[98]); A_arbace_repr_clojure_rules_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_rules_A_const_pool.A[99]) }

func A_arbace_repr_clojure_rules_A_New() *A_arbace_repr_clojure_rules_A { A_arbace_repr_clojure_rules_A_Init(); t := &A_arbace_repr_clojure_rules_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_A_class }

func (t *A_arbace_repr_clojure_rules_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_A); return ok }

func A_arbace_repr_clojure_rules_A_Cast(x any) *A_arbace_repr_clojure_rules_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_A_class)) }; return v }



type A_arbace_repr_clojure_rules_applicable_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_applicable_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_applicable_fn__1700000103_A struct{ j2g_header uint64; F_ctx, F_skip any }

var A_arbace_repr_clojure_rules_applicable_fn__1700000103_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000056_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_arbace_core_names_fn__1700000058_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_clojure_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_clojure_source_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_core_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_core_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_defined_names_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A struct{ j2g_header uint64; F_s, F_s__1700000062, F_iter__1700000061 any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A struct{ j2g_header uint64; F_b__1700000064, F_s any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000067_fn__1700000071_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A struct{ j2g_header uint64; F_h, F_s any }

var A_arbace_repr_clojure_rules_defined_names_iter__1700000061__1700000065_fn__1700000066_fn__1700000077_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000004_A_New() *A_arbace_repr_clojure_rules_eval1700000004_A { t := &A_arbace_repr_clojure_rules_eval1700000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000004_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000004_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000004_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000004_loading__1927001464__auto____1700000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_eval1700000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_rules_eval1700000008_A_New() *A_arbace_repr_clojure_rules_eval1700000008_A { t := &A_arbace_repr_clojure_rules_eval1700000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rules_eval1700000008_A_class }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rules_eval1700000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rules_eval1700000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); return ok }

func A_arbace_repr_clojure_rules_eval1700000008_A_Cast(x any) *A_arbace_repr_clojure_rules_eval1700000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rules_eval1700000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rules_eval1700000008_A_class)) }; return v }



type A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_eval1700000008_fn__1700000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000090_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000090_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000092_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000092_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000094_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000094_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000096_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000096_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000098_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000098_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_fn__1700000100_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_fn__1700000100_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_imports_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_imports_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_insert_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_insert_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_proxy_methods_fn__1700000014_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_security_manager_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000036_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A struct{ j2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000042_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A struct{ j2g_header uint64; F_sb, F_s any }

var A_arbace_repr_clojure_rules_security_manager_fn__1700000048_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A struct{ j2g_header uint64; F_import_spans any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_rules_security_manager_in_import_QMARK___1700000021_fn__1700000023_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rules_translate_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rules_translate_fn__1700000106_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_repr_clojure_rules_translate_fn__1700000106_A_fn_class *jrt.Class
