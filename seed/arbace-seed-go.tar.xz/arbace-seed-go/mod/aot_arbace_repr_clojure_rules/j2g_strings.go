//line j2g_strings.ae:1
package aot_arbace_repr_clojure_rules

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn26,arbace.repr.clojure.renamekn2,asyn6,renameyn24,arbace.repr.clojure.textyn4,textyn13,arbace.stringyn3,stryn11,arbace.corekn3,dockn4,cljckn3,cljkn4,kindkn5,addedkn4,elsekn5,to-aekn8,featureskn10,core-nameskn2,idkn7,applieskn5,printkn7,rewritev11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,v11,arbace.core5,referR7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn25,arbace.repr.clojure.rulesm2,R8,s1109,repr/clojure's rules: the table of rewrites that translate Clojure source into Arbace source\n  (doc/REPR-CLOJURE.md), and the dialect divergences they come from (doc/VENDOR-NOTES.md,\n  \"Dialect divergences\"), each with the rule that answers it or why none can.\n\n  A rule is a map:\n    :id       a keyword, its name on the command line (--skip ID)\n    :doc      what it rewrites\n    :applies  (fn [ctx]) whether it applies to a file; ctx holds :kind (:clj, :cljc, :java or\n              :text: a file renamed as text only), :to-ae (the file becomes a .ae file),\n              :features (the reader's platform features, #{:clj}) and :path\n    :rewrite  (fn [text ctx]) the file's new text\n    :way      :reversible, or :one-way when read drops what print cannot restore\n    :loss     what print cannot restore, if anything\n    :print    (fn [text ctx]) :rewrite reversed, for print (Arbace text back to Clojure)\n  The rules apply in the table's order. Adding a rule (a later divergence of the dialects) is\n  adding an entry here, a unit test (test/repr/clojure/read_test.ae) and a line in\n  doc/REPR-CLOJURE.md.v11,arbace.core9,contains?S2,R9,R10,R11,v11,arbace.core6,reducev13,arbace.string7,replacev25,arbace.repr.clojure.rules11,proxy-namesv25,arbace.repr.clojure.rules13,unproxy-namesS2,s6,imports7,:importv11,arbace.core3,notv13,arbace.string9,includes?v25,arbace.repr.clojure.rules2,smv24,arbace.repr.clojure.text10,list-spansv25,arbace.repr.clojure.rules8,imports?v11,arbace.core4,somev11,arbace.core6,filterv11,arbace.core4,subsv24,arbace.repr.clojure.text11,code-tokensv13,arbace.string12,starts-with?v11,arbace.core6,empty?l0,v11,arbace.core3,strv25,arbace.repr.clojure.rules12,qualified-smv11,arbace.core4,intov11,arbace.core4,compR12,v11,arbace.core3,mapv11,arbace.core4,namev11,arbace.core4,valsv11,arbace.core10,ns-publicsR7,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv24,arbace.repr.clojure.text7,skip-wsv24,arbace.repr.clojure.text9,token-endc94,R13,v24,arbace.repr.clojure.text8,form-endv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv25,arbace.repr.clojure.rules9,def-headsv11,arbace.core4,sortv11,arbace.core8,distinctv25,arbace.repr.clojure.rules13,defined-namesS1,s2,nsv13,arbace.string4,joinS1,s14,:refer-clojurev25,arbace.repr.clojure.rules9,insert-atv13,arbace.string8,index-ofS1,s2,nsv25,arbace.repr.clojure.rules3,cutS1,s14,:refer-clojurev25,arbace.repr.clojure.rules10,core-namesR9,R14,v24,arbace.repr.clojure.text20,resolve-conditionalsR15,v26,arbace.repr.clojure.rename6,renamev26,arbace.repr.clojure.rename8,unrenamev25,arbace.repr.clojure.rules13,proxy-methodsv25,arbace.repr.clojure.rules15,unproxy-methodsR16,v25,arbace.repr.clojure.rules17,arbace-core-namesv25,arbace.repr.clojure.rules12,uncore-namesv25,arbace.repr.clojure.rules16,security-managerv25,arbace.repr.clojure.rules26,unqualify-security-managerR17,R18,v25,arbace.repr.clojure.rules5,rulesR19,v11,arbace.core7,reversev25,arbace.repr.clojure.rules10,applicablev25,arbace.repr.clojure.rules10,print-textR20,v25,arbace.repr.clojure.rules9,translate")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$applicable$fn__1700000166")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$arbace_core_names$fn__1700000096")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$arbace_core_names$fn__1700000098")

var Lit_4 *jrt.String = jrt.Intern("arbace")

var Lit_5 *jrt.String = jrt.Intern(" ")

var Lit_6 *jrt.String = jrt.Intern("\n  (:refer-clojure :exclude [")

var Lit_7 *jrt.String = jrt.Intern("])")

var Lit_8 *jrt.String = jrt.Intern(":only")

var Lit_9 *jrt.String = jrt.Intern(":exclude")

var Lit_10 *jrt.String = jrt.Intern(" :exclude [")

var Lit_11 *jrt.String = jrt.Intern("]")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$defined_names$iter__1700000101__1700000105")

var Lit_13 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$defined_names$iter__1700000101__1700000105$fn__1700000106")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$defined_names$iter__1700000101__1700000105$fn__1700000106$fn__1700000107")

var Lit_15 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$defined_names$iter__1700000101__1700000105$fn__1700000106$fn__1700000117")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$defined_names$iter__1700000101__1700000105$fn__1700000106$fn__1700000107$fn__1700000111")

var Lit_17 *jrt.String = jrt.Intern("#^")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$print_text$fn__1700000169")

var Lit_19 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$proxy_methods$fn__1700000014")

var Lit_20 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$security_manager$in_import_QMARK___1700000028")

var Lit_21 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$security_manager$fn__1700000037")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$security_manager$fn__1700000043")

var Lit_23 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$security_manager$fn__1700000049")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$security_manager$fn__1700000055")

var Lit_25 *jrt.String = jrt.Intern("java.lang.")

var Lit_26 *jrt.String = jrt.Intern(".")

var Lit_27 *jrt.String = jrt.Intern("/")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$security_manager$in_import_QMARK___1700000028$fn__1700000030")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$translate$fn__1700000172")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$uncore_names$suffix_QMARK___1700000138")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$uncore_names$fn__1700000140")

var Lit_32 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unproxy_methods$fn__1700000021")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unqualify_security_manager$in_import_QMARK___1700000061")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unqualify_security_manager$fn__1700000070")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unqualify_security_manager$fn__1700000076")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unqualify_security_manager$fn__1700000082")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unqualify_security_manager$fn__1700000088")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unqualify_security_manager$in_import_QMARK___1700000061$fn__1700000063")

var Lit_39 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,ctxkn4,linekn6,columnkn4,fileyn1,syn4,headkn3,tagyn6,Stringyn1,iyn5,addedyn1,ayn1,bkn2,idkn19,reader-conditionalskn7,applieskn7,rewritekn3,waykn7,one-waykn4,losskn5,printkn6,renamekn10,reversiblekn13,proxy-methodskn10,core-nameskn16,security-managerkn10,divergencekn4,rulekn4,nonekn3,whyyn4,skipv11,arbace.core5,in-nsMyn25,arbace.repr.clojure.rulesm2,R0,s1109,repr/clojure's rules: the table of rewrites that translate Clojure source into Arbace source\n  (doc/REPR-CLOJURE.md), and the dialect divergences they come from (doc/VENDOR-NOTES.md,\n  \"Dialect divergences\"), each with the rule that answers it or why none can.\n\n  A rule is a map:\n    :id       a keyword, its name on the command line (--skip ID)\n    :doc      what it rewrites\n    :applies  (fn [ctx]) whether it applies to a file; ctx holds :kind (:clj, :cljc, :java or\n              :text: a file renamed as text only), :to-ae (the file becomes a .ae file),\n              :features (the reader's platform features, #{:clj}) and :path\n    :rewrite  (fn [text ctx]) the file's new text\n    :way      :reversible, or :one-way when read drops what print cannot restore\n    :loss     what print cannot restore, if anything\n    :print    (fn [text ctx]) :rewrite reversed, for print (Arbace text back to Clojure)\n  The rules apply in the table's order. Adding a rule (a later divergence of the dialects) is\n  adding an entry here, a unit test (test/repr/clojure/read_test.ae) and a line in\n  doc/REPR-CLOJURE.md.m2,R0,s1109,repr/clojure's rules: the table of rewrites that translate Clojure source into Arbace source\n  (doc/REPR-CLOJURE.md), and the dialect divergences they come from (doc/VENDOR-NOTES.md,\n  \"Dialect divergences\"), each with the rule that answers it or why none can.\n\n  A rule is a map:\n    :id       a keyword, its name on the command line (--skip ID)\n    :doc      what it rewrites\n    :applies  (fn [ctx]) whether it applies to a file; ctx holds :kind (:clj, :cljc, :java or\n              :text: a file renamed as text only), :to-ae (the file becomes a .ae file),\n              :features (the reader's platform features, #{:clj}) and :path\n    :rewrite  (fn [text ctx]) the file's new text\n    :way      :reversible, or :one-way when read drops what print cannot restore\n    :loss     what print cannot restore, if anything\n    :print    (fn [text ctx]) :rewrite reversed, for print (Arbace text back to Clojure)\n  The rules apply in the table's order. Adding a rule (a later divergence of the dialects) is\n  adding an entry here, a unit test (test/repr/clojure/read_test.ae) and a line in\n  doc/REPR-CLOJURE.md.R1,v25,arbace.repr.clojure.rules15,clojure-source?m10,R2,TR3,L1,V1,R4,R5,i23,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules11,proxy-namesV2,V2,p55,(?<![\\w$])__(init|update|get)ClojureFnMappings(?![\\w$])s20,__$1ArbaceFnMappingsV2,p33,(?<![\\w$])__clojureFnMap(?![\\w$])s13,__arbaceFnMapm8,R2,TR5,i27,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules13,proxy-methodsm10,R3,L1,V1,R8,R0,s71,The methods every proxy class has, and its field, as Arbace names them.R5,i31,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules13,unproxy-namesV2,V2,p54,(?<![\\w$])__(init|update|get)ArbaceFnMappings(?![\\w$])s21,__$1ClojureFnMappingsV2,p32,(?<![\\w$])__arbaceFnMap(?![\\w$])s14,__clojureFnMapm8,R2,TR5,i36,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules15,unproxy-methodsm10,R3,L1,V1,R8,R0,s76,proxy-methods reversed: the proxy's methods and field as Clojure names them.R5,i40,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules2,smm8,R2,TR5,i47,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules8,imports?m10,R2,TR3,L1,V1,R9,R5,i49,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules16,security-managerm10,R3,L1,V1,Myn1,sm2,R10,R11,R0,s169,Unqualified uses of the class SecurityManager qualified as java.lang.SecurityManager, which\n  Arbace does not import by default; a file that imports it is left as it is.R5,i51,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules12,qualified-smv11,arbace.core3,strm8,R2,TR5,i81,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules26,unqualify-security-managerm10,R3,L1,V1,Myn1,sm2,R10,R11,R0,s369,:security-manager reversed: java.lang.SecurityManager outside imports (as a symbol,\n  java.lang.SecurityManager/x, java.lang.SecurityManager. or a hint) unqualified again, as\n  Clojure imports it by default; a file that imports SecurityManager is left as it is, as read\n  leaves it. One way only where the Clojure file wrote it qualified (doc/REPR-CLOJURE.md, \"Print\").R5,i83,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules17,arbace-core-namesm10,R3,L1,V0,R0,s150,The public names arbace.core has and clojure.core has not (their metadata says\n  {:added \"arbace\"}: the Java forms' macros and operators), as strings.R5,i115,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules9,def-headsS12,s4,defns9,definlines9,defrecords8,defmultis12,definterfaces7,defonces11,defprotocols5,defn-s3,defs9,defstructs7,deftypes8,defmacrom8,R2,TR5,i122,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules13,defined-namesm12,R2,TR3,L1,V1,Myn1,sm2,R10,R11,R0,s85,The names the def forms of s define (the token after the head, its metadata skipped).R5,i126,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules9,insert-atm10,R2,TR3,L1,V3,Myn1,sm2,R10,R11,R12,Myn1,xm2,R10,R11,R5,i143,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules10,core-namesm10,R3,L1,V2,Myn1,sm2,R10,R11,R13,R0,s384,The names arbace.core adds (`added`, a set of strings) that the file defines, excluded from\n  its ns form's :refer-clojure, so they replace nothing (Arbace would warn \"return already\n  refers to: #'arbace.core/return\" and replace it): added to an :exclude, or a\n  (:refer-clojure :exclude [...]) added. A file without an ns form, or whose :refer-clojure\n  has :only, is left as it is.R5,i145,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules3,cutm10,R2,TR3,L1,V3,Myn1,sm2,R10,R11,R14,R15,R5,i173,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules12,uncore-namesm10,R3,L1,V2,Myn1,sm2,R10,R11,R13,R0,s523,:core-names reversed: the exclusion core-names would add for the names arbace.core adds\n  (`added`) that the file defines removed again. The text it added is one of three, by what the\n  ns form had: a (:refer-clojure :exclude [...]) at the ns form's end, an :exclude [...] at its\n  :refer-clojure's end, or the names at its :exclude's end; each candidate is kept only when\n  core-names gives the text back from it, so print inverts read exactly. With none, the text is\n  left as it is (Arbace source excluding them itself).R5,i175,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules5,rulesm8,R5,i208,R6,i1,R7,s28,arbace/repr/clojure/rules.aeR0,s35,The rules, in the order they apply.R16,R17,R0,R18,R19,R20,R21,R22,R23,R24,v11,arbace.core10,constantlyR25,R26,R27,R28,v25,arbace.repr.clojure.rules11,divergencesV8,m6,R29,s55,reduce without an init on an IReduceInit-only reducibleR30,R31,R32,s78,Arbace reduces what upstream rejects: code that runs on Clojure runs the same.m4,R29,s39,SecurityManager is not a default importR30,R28,m6,R29,s33,A multimethod's ambiguity messageR30,R31,R32,s85,A message's wording; code does not depend on it (a test comparing it must be edited).m6,R29,s38,bean ignores explicit BeanInfo classesR30,R31,R32,s62,What bean returns at run time; nothing in the source names it.m6,R29,s51,Optional modules (java.sql, java.xml, java.desktop)R30,R31,R32,s160,The JVM's runtime image, not the source (on arbace-for-java-26; on main since S4 the\n         three namespaces are removed, VENDOR-NOTES.md, \"Without the JVM\").m6,R29,s20,Source files are .aeR30,R17,R32,s142,repr/clojure writes .ae files (a .cljc file's conditionals resolved); source paths of the\n         vendored namespaces are renamed by :rename.m6,R29,s61,Names arbace.core adds (the Java forms' macros and operators)R30,R27,R32,s81,A file defining one of them gets them excluded from its ns form's :refer-clojure.m6,R29,s66,Runtime-visible names (threads, error report files, proxy methods)R30,R26,R32,s159,The proxy methods and field are names code calls; thread names and report file\n         prefixes are data in strings, left alone (doc/REPR-CLOJURE.md, limits).m8,R5,i261,R6,i1,R7,s28,arbace/repr/clojure/rules.aeR0,s132,The dialect divergences of doc/VENDOR-NOTES.md, in its order: the rule answering each, or\n  :none and why no source rewrite applies.v25,arbace.repr.clojure.rules10,applicablem10,R3,L1,V2,R4,R33,R0,s72,The rules that apply to a file, without the skipped ones (a set of ids).R5,i291,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules10,print-textm10,R3,L2,V2,R8,R4,V3,R8,R4,R33,R0,s235,Arbace text s printed back as Clojure: each rule that applies (ctx as translate's, for the\n  Clojure file the Arbace one stands for) reversed by its :print, in the reverse order, minus\n  the skipped ones (doc/REPR-CLOJURE.md, \"Print\").R5,i296,R6,i1,R7,s28,arbace/repr/clojure/rules.aev25,arbace.repr.clojure.rules9,translatem10,R3,L2,V2,R8,R4,V3,R8,R4,R33,R0,s109,Text s of a file translated by the rules that apply (ctx: see the namespace's doc), minus\n  the skipped ones.R5,i304,R6,i1,R7,s28,arbace/repr/clojure/rules.ae")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$eval1700000004$loading__1927001464__auto____1700000005")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$eval1700000008$fn__1700000009")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$clojure_source_QMARK_")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$proxy_methods")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unproxy_methods")

var Lit_45 *jrt.String = jrt.Intern("SecurityManager")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$imports_QMARK_")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$security_manager")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$unqualify_security_manager")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$arbace_core_names")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$defined_names")

var Lit_51 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$insert_at")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$core_names")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$cut")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$uncore_names")

var Lit_55 *jrt.String = jrt.Intern("A .cljc file becoming a .ae file: each reader conditional (#?, #?@) replaced by the\n         text of the branch the reader selects on Arbace (features #{:clj}, then :default),\n         spliced for #?@, or by nothing; a .ae file is read without conditionals.")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000143")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000145")

var Lit_58 *jrt.String = jrt.Intern("The branches not selected, and the conditional around the one selected: print\n          writes the .ae as a .clj file, the :clj reading of the .cljc (a file kept .cljc,\n          --keep-ext, keeps its conditionals and goes back whole).")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000147")

var Lit_60 *jrt.String = jrt.Intern("The names of the vendored Clojure: clojure.* -> arbace.* for its namespaces, the\n         Java packages clojure.lang, clojure.asm (with commons, signature), clojure.java.api,\n         the keyword namespace clojure.error, the system properties clojure.*, spec; and\n         source paths clojure/<ns>.clj -> arbace/<ns>.ae (arbace.repr.clojure.rename).")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000149")

var Lit_62 *jrt.String = jrt.Intern("None for Clojure source, which names no arbace.* (an Arbace text that names\n          clojure.core reads back as arbace.core).")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000151")

var Lit_64 *jrt.String = jrt.Intern("A proxy's methods __initClojureFnMappings, __updateClojureFnMappings,\n         __getClojureFnMappings and its field __clojureFnMap: __initArbaceFnMappings and the\n         rest, __arbaceFnMap (VENDOR-NOTES.md, hand change 2).")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000153")

var Lit_66 *jrt.String = jrt.Intern("None for Clojure source, which has no __arbaceFnMap.")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000155")

var Lit_68 *jrt.String = jrt.Intern("Names arbace.core adds to Clojure's core (the Java forms' macros and operators:\n         return, switch, label, lambda, ...) that a file defines: excluded in its ns form's\n         :refer-clojure, as a library does for a core name it redefines.")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000157")

var Lit_70 *jrt.String = jrt.Intern("None: print removes the exclusion only when core-names gives the text back from\n          what is left.")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000159")

var Lit_72 *jrt.String = jrt.Intern("SecurityManager unqualified -> java.lang.SecurityManager (not a default import in\n         Arbace, VENDOR-NOTES.md, hand change 11), unless the file imports it.")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000161")

var Lit_74 *jrt.String = jrt.Intern("Which uses the Clojure file wrote java.lang.SecurityManager: read qualifies all, so\n          print unqualifies all (the same class in Clojure, which imports it by default).")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$fn__1700000163")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$applicable")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$print_text")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.clojure.rules$translate")
