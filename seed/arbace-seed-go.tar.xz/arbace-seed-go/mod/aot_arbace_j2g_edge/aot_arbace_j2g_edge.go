//line aot_arbace_j2g_edge.ae:1
package aot_arbace_j2g_edge

import (
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_New() *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_edge_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_edge_A_const_1, A_arbace_j2g_edge_A_const_2, A_arbace_j2g_edge_A_const_3, A_arbace_j2g_edge_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_edge_eval233000008_fn__233000009_A_New() *A_arbace_j2g_edge_eval233000008_fn__233000009_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000008_fn__233000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_edge_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_edge_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_edge_A_const_10.GetRawRoot__O(), A_arbace_j2g_edge_A_const_11) }



























func A_arbace_j2g_edge_jvm_A_New() *A_arbace_j2g_edge_jvm_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {



	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		var root_22 any = A_arbace_j2g_edge_A_const_13.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_edge_A_const_12.Get__O(); var arg_26 any = lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1); if linked_23 == nil { return ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { return linked_23.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) } } else {
//line :33:1
			var v__4 any = lang.IFn_Cast(f__2).Invoke__O(); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_27 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = v__4; if linked_28 == nil { tmp1 = ifn_29.Invoke_O__O(arg_30) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_27, arg_30) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var root_31 any = A_arbace_j2g_edge_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = A_arbace_j2g_edge_A_const_14.Get__O(); var arg_35 any = A_arbace_j2g_edge_A_const_17.GetRawRoot__O(); var arg_36 any = lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1); var arg_37 any = v__4; if linked_32 == nil { ifn_33.Invoke_O_O_O_O__O(arg_34, arg_35, arg_36, arg_37) } else { linked_32.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_31, arg_34, arg_35, arg_36, arg_37) } }
//line :33:1
			return v__4
		}
}



func A_arbace_j2g_edge_jvm_QMARK__A_New() *A_arbace_j2g_edge_jvm_QMARK__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_QMARK__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {


	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		var root_38 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_edge_A_const_12.Get__O(), section__0); var arg_42 any = k__1; if linked_39 == nil { return ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { return linked_39.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_38, arg_41, arg_42) } } else {
//line :42:1
			var v__4 bool = lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(f__2).Invoke__O()); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(v__4).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_16.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_14.Get__O(); var tmp4 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var tmp5 any; var root_51 any = A_arbace_j2g_edge_A_const_20.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_j2g_edge_A_const_10.GetRawRoot__O(); var arg_55 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_52 == nil { tmp5 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { tmp5 = linked_52.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, section__0, tmp5, k__1) }
//line :42:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(v__4).Ref()
		}
}







func A_arbace_j2g_edge_pr_string_A_New() *A_arbace_j2g_edge_pr_string_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_string_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Ctor() {}
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_80); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(s__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__4))

		if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_22)).CharValue__C()) { jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_81) } else { if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_23)).CharValue__C()) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_82) } else {
//line :56:1
				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_25; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(c__5)).Ref(), A_arbace_j2g_edge_A_const_26)) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(c__5) } else {
//line :56:1
						if A_arbace_j2g_edge_A_const_27 != nil {


							jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_j2g_edge_A_const_28.GetRawRoot__O()).Invoke_O_O__O(Lit_83, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(c__5)).Ref()))) } } } }
//line :54:1
		i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :52:1
	break L1 }; var root_56 any =







	A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_80).Ref(); if linked_57 == nil { return ifn_58.Invoke_O__O(arg_59) } else { return linked_57.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_56, arg_59) } }

func A_arbace_j2g_edge_pr_double_A_New() *A_arbace_j2g_edge_pr_double_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_double_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Ctor() {}
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) InvokePrim_O_D__O(self any, d__0 float64) any {
	if jrt.Double_IsNaN_D__Z_NoInit(d__0) { return Lit_77 } else { if lang.Util_Equiv_D_D__Z_NoInit(d__0, jrt.PosInf64) { return Lit_78 } else { if lang.Util_Equiv_D_D__Z_NoInit(d__0, jrt.NegInf64) { return Lit_79 } else { if A_arbace_j2g_edge_A_const_27 != nil {


		return jrt.Double_ToString_D__String_NoInit(d__0).Ref() } else {
//line :63:1
			return nil } } } } }
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }





func A_arbace_j2g_edge_pr_data_A_New() *A_arbace_j2g_edge_pr_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Ctor() {}
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Invoke_O_O__O(self, x__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return Lit_70 } else { var tmp1 any; var root_71 any = A_arbace_j2g_edge_A_const_29.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_73 lang.IFn

		if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = x__0; if linked_72 == nil { tmp1 = ifn_73.Invoke_O__O(arg_74) } else { tmp1 = linked_72.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_71, arg_74) }
//line :71:1
		if jrt.J2g_Truth(tmp1) {

			var root_75 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = x__0; if linked_76 == nil { return ifn_77.Invoke_O__O(arg_78) } else { return linked_76.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_75, arg_78) } } else {
//line :71:1
				var tmp2 any; var root_79 any = A_arbace_j2g_edge_A_const_30.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_81 lang.IFn


				if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = x__0; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_79, arg_82) }
//line :71:1
				if jrt.J2g_Truth(tmp2) {


					var root_83 any = A_arbace_j2g_edge_A_const_31.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, A_arbace_j2g_edge_pr_string_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = x__0; if linked_84 == nil { return ifn_85.Invoke_O__O(arg_86) } else { return linked_84.(*A_arbace_j2g_edge_pr_string_A).Invoke_O_O__O(root_83, arg_86) } } else {
//line :71:1
						var tmp3 any; var root_87 any = A_arbace_j2g_edge_A_const_32.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_89 lang.IFn



						if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = x__0; if linked_88 == nil { tmp3 = ifn_89.Invoke_O__O(arg_90) } else { tmp3 = linked_88.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_87, arg_90) }
//line :71:1
						if jrt.J2g_Truth(tmp3) {



							var root_91 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = x__0; if linked_92 == nil { return ifn_93.Invoke_O__O(arg_94) } else { return linked_92.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_91, arg_94) } } else {
//line :71:1
								var tmp4 any; var root_95 any = A_arbace_j2g_edge_A_const_33.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_97 lang.IFn




								if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = x__0; if linked_96 == nil { tmp4 = ifn_97.Invoke_O__O(arg_98) } else { tmp4 = linked_96.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_95, arg_98) }
//line :71:1
								if jrt.J2g_Truth(tmp4) {




									var root_99 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = x__0; if linked_100 == nil { return ifn_101.Invoke_O__O(arg_102) } else { return linked_100.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_99, arg_102) } } else {
//line :71:1
										var tmp5 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)





										if or__1927000174__auto____2 { tmp5 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp5 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp5 = or__1927000174__auto____4 } else { tmp5 = jrt.Byte_InstanceOf(x__0) } } }
//line :71:1
										if tmp5 {





											var root_103 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = x__0; if linked_104 == nil { return ifn_105.Invoke_O__O(arg_106) } else { return linked_104.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_103, arg_106) } } else {
//line :71:1
												var tmp6 bool; var or__1927000174__auto____2_2 bool = jrt.Double_InstanceOf(x__0)






												if or__1927000174__auto____2_2 { tmp6 = or__1927000174__auto____2_2 } else { tmp6 = jrt.Float_InstanceOf(x__0) }
//line :71:1
												if tmp6 {






													var root_107 any = A_arbace_j2g_edge_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_107, A_arbace_j2g_edge_pr_double_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0); if linked_108 == nil { return ifn_109.Invoke_O__O(jrt.Double_ValueOf_D__Double_NoInit(arg_110).Ref()) } else { return linked_108.(*A_arbace_j2g_edge_pr_double_A).InvokePrim_O_D__O(root_107, arg_110) } } else {
//line :71:1
														if jrt.Character_InstanceOf(x__0) {







															var root_111 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(lang.RT_CharCast_O__C_NoInit(x__0))).Ref(); if linked_112 == nil { return ifn_113.Invoke_O__O(arg_114) } else { return linked_112.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_111, arg_114) } } else {
//line :71:1
																var tmp7 any; var root_115 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn








																if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = x__0; if linked_116 == nil { tmp7 = ifn_117.Invoke_O__O(arg_118) } else { tmp7 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }
//line :71:1
																if jrt.J2g_Truth(tmp7) {








																	var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_11); var tmp9 any; var root_119 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = Lit_20; var arg_123 any; var iter__1927001039__auto____5 any; var tmp10 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New(); var tmp11 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class = fncls__198d; tmp11 = fncls__198d } else { tmp11 = fncls__198 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp12 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp13 any; var root_199 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_204 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_208 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_205 == nil { arg_202 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { arg_202 = linked_205.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; var arg_203 any = x__0; if linked_200 == nil { tmp13 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { tmp13 = linked_200.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; arg_123 = tmp12.Invoke_O__O(tmp13); if linked_120 == nil { tmp9 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { tmp9 = linked_120.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() } else {
//line :71:1
																		var tmp14 any; var root_209 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_211 lang.IFn









																		if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = x__0; if linked_210 == nil { tmp14 = ifn_211.Invoke_O__O(arg_212) } else { tmp14 = linked_210.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_209, arg_212) }
//line :71:1
																		if jrt.J2g_Truth(tmp14) {









																			var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_11); var tmp16 any; var root_213 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = Lit_20; var arg_217 any; var root_218 any = A_arbace_j2g_edge_A_const_53.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var root_222 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_226 any = x__0; if linked_223 == nil { arg_221 = ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { arg_221 = linked_223.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }; if linked_219 == nil { arg_217 = ifn_220.Invoke_O__O(arg_221) } else { arg_217 = linked_219.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_218, arg_221) }; if linked_214 == nil { tmp16 = ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { tmp16 = linked_214.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16, nil)).Ref() } else {
//line :71:1
																				var tmp17 any; var root_227 any = A_arbace_j2g_edge_A_const_55.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_229 lang.IFn










																				if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = x__0; if linked_228 == nil { tmp17 = ifn_229.Invoke_O__O(arg_230) } else { tmp17 = linked_228.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_227, arg_230) }
//line :71:1
																				if jrt.J2g_Truth(tmp17) {










																					var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_73, nil, Lit_18); var tmp19 any; var root_231 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = Lit_20; var arg_235 any; var root_236 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_240 any = x__0; if linked_237 == nil { arg_235 = ifn_238.Invoke_O_O__O(arg_239, arg_240) } else { arg_235 = linked_237.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_236, arg_239, arg_240) }; if linked_232 == nil { tmp19 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { tmp19 = linked_232.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil)).Ref() } else {
//line :71:1
																						if A_arbace_j2g_edge_A_const_27 != nil { var tmp20 any; var root_241 any = A_arbace_j2g_edge_A_const_56.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_243 lang.IFn











																							if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_74, nil); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_57.GetRawRoot__O()); var tmp23 any; var root_250 any = A_arbace_j2g_edge_A_const_58.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = x__0; if linked_251 == nil { tmp23 = ifn_252.Invoke_O__O(arg_253) } else { tmp23 = linked_251.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_250, arg_253) }; arg_244 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22.Invoke_O__O(tmp23))).Ref(); var arg_245 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_59, x__0)); if linked_242 == nil { tmp20 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { tmp20 = linked_242.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }
//line :71:1
																							panic(jrt.Thrown(jrt.Throwable_Cast(tmp20))) } else { return nil
																							}
																					}
																			}
																	}
															}
													}
											}
									} } } } } }
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New() *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Ctor() {}
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Invoke_O_O__O(self, s__233000017__1 any) any { var tmp1 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(s__233000017__1, self); var tmp2 *jrt.Class; var fncls__197 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class; if fncls__197 == nil { var fncls__197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class = fncls__197d; tmp2 = fncls__197d } else { tmp2 = fncls__197 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Ctor_O_O(c__s__233000017, c__iter__233000016 any) { t.F_s__233000017 = c__s__233000017; t.F_iter__233000016 = c__iter__233000016 }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Invoke_O__O(self any) any { { var s__233000017__1 any; var t_ any = t.F_s__233000017; t.F_s__233000017 = nil; s__233000017__1 = t_; for { var temp__1927000414__auto____2 any; var root_124 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__233000017__1; if linked_125 == nil { temp__1927000414__auto____2 = ifn_126.Invoke_O__O(arg_127) } else { temp__1927000414__auto____2 = linked_125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_124, arg_127) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000017__3 any = temp__1927000414__auto____2; var tmp1 any; var root_128 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = s__233000017__3; if linked_129 == nil { tmp1 = ifn_130.Invoke_O__O(arg_131) } else { tmp1 = linked_129.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_128, arg_131) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_132 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__233000017__3; if linked_133 == nil { c__1927001037__auto____4 = ifn_134.Invoke_O__O(arg_135) } else { c__1927001037__auto____4 = linked_133.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_132, arg_135) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000019__6 any; var root_136 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_137 == nil { b__233000019__6 = ifn_138.Invoke_O__O(arg_139) } else { b__233000019__6 = linked_137.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_136, arg_139) }; var tmp2 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(b__233000019__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_154 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any; var root_159 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = b__233000019__6; if linked_160 == nil { arg_157 = ifn_161.Invoke_O__O(arg_162) } else { arg_157 = linked_160.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_159, arg_162) }; var arg_158 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); var tmp5 any; var root_163 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = s__233000017__3; if linked_164 == nil { tmp5 = ifn_165.Invoke_O__O(arg_166) } else { tmp5 = linked_164.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_163, arg_166) }; arg_158 = tmp4.Invoke_O__O(tmp5); if linked_155 == nil { return ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { return linked_155.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) } } else { var root_167 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any; var root_172 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = b__233000019__6; if linked_173 == nil { arg_170 = ifn_174.Invoke_O__O(arg_175) } else { arg_170 = linked_173.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_172, arg_175) }; var arg_171 any; if linked_168 == nil { return ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { return linked_168.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) } } } else { var vec__233000027__4 any; var root_176 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__233000017__3; if linked_177 == nil { vec__233000027__4 = ifn_178.Invoke_O__O(arg_179) } else { vec__233000027__4 = linked_177.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_176, arg_179) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000027__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000027__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_180 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp7 any; var root_185 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = k__5; if linked_186 == nil { tmp7 = ifn_187.Invoke_O__O(arg_188) } else { tmp7 = linked_186.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_185, arg_188) }; var tmp8 any = tmp7; var tmp9 any; var root_189 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = v__6; if linked_190 == nil { tmp9 = ifn_191.Invoke_O__O(arg_192) } else { tmp9 = linked_190.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_189, arg_192) }; arg_183 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_184 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); var tmp11 any; var root_193 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = s__233000017__3; if linked_194 == nil { tmp11 = ifn_195.Invoke_O__O(arg_196) } else { tmp11 = linked_194.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_193, arg_196) }; arg_184 = tmp10.Invoke_O__O(tmp11); if linked_181 == nil { return ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { return linked_181.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_180, arg_183, arg_184) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Ctor_O_I_O(c__b__233000019 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000019 = c__b__233000019; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Invoke_O__O(self any) any { { var i__233000018__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000018__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000023__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000018__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000023__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000023__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_140 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = t.F_b__233000019; var arg_144 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp3 any; var root_145 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = k__3; if linked_146 == nil { tmp3 = ifn_147.Invoke_O__O(arg_148) } else { tmp3 = linked_146.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_145, arg_148) }; var tmp4 any = tmp3; var tmp5 any; var root_149 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = v__4; if linked_150 == nil { tmp5 = ifn_151.Invoke_O__O(arg_152) } else { tmp5 = linked_150.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_149, arg_152) }; arg_144 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_141 == nil { ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { linked_141.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }; i__233000018__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000018__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_const_data_A_New() *A_arbace_j2g_edge_const_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_const_data_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Invoke_O_O__O(self, v__0 any) any {


	if jrt.Character_InstanceOf(v__0) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_C__I_NoInit(lang.RT_CharCast_O__C_NoInit(v__0)))).Ref() } else { return v__0
	} }
func A_arbace_j2g_edge_ann_data_A_New() *A_arbace_j2g_edge_ann_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_254 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = x__0; if linked_255 == nil { and__1927000168__auto____2 = ifn_256.Invoke_O__O(arg_257) } else { and__1927000168__auto____2 = linked_255.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_258 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = x__0; var arg_262 any = A_arbace_j2g_edge_A_const_60; if linked_259 == nil { and__1927000168__auto____3 = ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { and__1927000168__auto____3 = linked_259.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_258, arg_261, arg_262) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_263 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); if linked_264 == nil { tmp1 = ifn_265.Invoke_O__O(arg_266) } else { tmp1 = linked_264.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_263, arg_266) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_62; return tmp2.Invoke_O_O_O__O(x__0, tmp3, A_arbace_j2g_edge_A_const_63.GetRawRoot__O()) } else {
//line :93:1
			var tmp4 any; var root_273 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_275 lang.IFn

			if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = x__0; if linked_274 == nil { tmp4 = ifn_275.Invoke_O__O(arg_276) } else { tmp4 = linked_274.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_273, arg_276) }
//line :93:1
			if jrt.J2g_Truth(tmp4) {

				var root_277 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_281 any; var root_282 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var tmp5 any = A_arbace_j2g_edge_ann_data_fn__233000035_A_New(); var tmp6 *jrt.Class; var fncls__291 *jrt.Class = A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class; if fncls__291 == nil { var fncls__291d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class = fncls__291d; tmp6 = fncls__291d } else { tmp6 = fncls__291 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_286 any = x__0; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } } else {
//line :93:1
					var tmp7 any; var root_292 any = A_arbace_j2g_edge_A_const_55.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_294 lang.IFn


					if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = x__0; if linked_293 == nil { tmp7 = ifn_294.Invoke_O__O(arg_295) } else { tmp7 = linked_293.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_292, arg_295) }
//line :93:1
					if jrt.J2g_Truth(tmp7) {


						var root_296 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var arg_300 any = x__0; if linked_297 == nil { return ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { return linked_297.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) } } else {
//line :93:1
							if A_arbace_j2g_edge_A_const_27 != nil { return x__0 } else { return nil
							} } } } }
func A_arbace_j2g_edge_ann_data_fn__233000035_A_New() *A_arbace_j2g_edge_ann_data_fn__233000035_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_fn__233000035_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Invoke_O_O__O(self, p__233000034__1 any) any { var vec__233000036__2 any = p__233000034__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_287 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, A_arbace_j2g_edge_ann_data_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = v__4; if linked_288 == nil { tmp1 = ifn_289.Invoke_O__O(arg_290) } else { tmp1 = linked_288.(*A_arbace_j2g_edge_ann_data_A).Invoke_O_O__O(root_287, arg_290) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }










func A_arbace_j2g_edge_fn__233000042_A_New() *A_arbace_j2g_edge_fn__233000042_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Ctor() {}
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Invoke_O__O(self any) any { var f__1 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_67.GetRawRoot__O()).Invoke_O_O_O__O(jrt.System_GetProperty_String__String(Lit_44).Ref(), Lit_45, Lit_46); var tmp1 any; var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(f__1)).IsFile__Z(); if and__1927000168__auto____2 {

	var root_307 any = A_arbace_j2g_edge_A_const_68.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var root_312 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = jrt.System_GetProperty_String__String(Lit_47).Ref(); if linked_313 == nil { arg_310 = ifn_314.Invoke_O__O(arg_315) } else { arg_310 = linked_313.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_312, arg_315) }; var arg_311 any = Lit_48; if linked_308 == nil { tmp1 = ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { tmp1 = linked_308.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_307, arg_310, arg_311) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
		var root_316 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_320 any; var root_322 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any; var tmp2 any = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New(); var tmp3 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class = fncls__331d; tmp3 = fncls__331d } else { tmp3 = fncls__331 }; arg_325 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_323 == nil { arg_320 = ifn_324.Invoke_O__O(arg_325) } else { arg_320 = linked_323.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_322, arg_325) }; var arg_321 any; var root_332 any = A_arbace_j2g_edge_A_const_72.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()).Invoke_O__O(f__1); if linked_333 == nil { arg_321 = ifn_334.Invoke_O__O(arg_335) } else { arg_321 = linked_333.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_332, arg_335) }; if linked_317 == nil { return ifn_318.Invoke_O_O_O__O(arg_319, arg_320, arg_321) } else { return linked_317.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_316, arg_319, arg_320, arg_321) } } else {
			var root_349 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_edge_A_const_78; var arg_352 any = tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_edge_A_const_79.Get__O()); if linked_350 == nil { ifn_351.Invoke_O__O(arg_352) } else { linked_350.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_349, arg_352) }; var tmp6 any = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New(); var tmp7 *jrt.Class; var fncls__348 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class; if fncls__348 == nil { var fncls__348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class = fncls__348d; tmp7 = fncls__348d } else { tmp7 = fncls__348 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :108:1
			return lang.PersistentHashSet_EMPTY.Ref() } }
func A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000043_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000043_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Invoke_O_O__O(self, p1__233000041_SHARP___1 any) any { var root_326 any = A_arbace_j2g_edge_A_const_70.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = A_arbace_j2g_edge_A_const_71; var arg_330 any = p1__233000041_SHARP___1; if linked_327 == nil { return ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { return linked_327.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) } }
func A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000045_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000045_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_74.GetRawRoot__O()).Invoke_O_O__O(Lit_51, Lit_52)
//line :110:1
	return nil }(); var root_345 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; if linked_346 == nil { ifn_347.Invoke__O() } else { linked_346.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_345) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_j2g_edge_method_key_A_New() *A_arbace_j2g_edge_method_key_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_method_key_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Ctor() {}
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Invoke_O_O__O(self, m__0 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__0), A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__0)) }






func A_arbace_j2g_edge_info_data_A_New() *A_arbace_j2g_edge_info_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Ctor() {}
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Invoke_O_O__O(self, info__0 any) any {









	var root_358 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any; var root_364 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_366 lang.IFn
//line :129:1
	if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any; var root_370 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_372 lang.IFn
//line :128:1
	if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = info__0; var arg_374 any = A_arbace_j2g_edge_A_const_83; if linked_371 == nil { arg_367 = ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { arg_367 = linked_371.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }
	var arg_368 any = A_arbace_j2g_edge_A_const_84; var arg_369 any; var tmp1 any = A_arbace_j2g_edge_info_data_fn__233000050_A_New(); var tmp2 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class; if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class = fncls__397d; tmp2 = fncls__397d } else { tmp2 = fncls__397 }; arg_369 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_365 == nil { arg_361 = ifn_366.Invoke_O_O_O__O(arg_367, arg_368, arg_369) } else { arg_361 = linked_365.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_364, arg_367, arg_368, arg_369)
	}

	var arg_362 any = A_arbace_j2g_edge_A_const_86; var arg_363 any; var tmp3 any = A_arbace_j2g_edge_info_data_fn__233000055_A_New(); var tmp4 *jrt.Class; var fncls__469 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class; if fncls__469 == nil { var fncls__469d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class = fncls__469d; tmp4 = fncls__469d } else { tmp4 = fncls__469 }; arg_363 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_359 == nil { return ifn_360.Invoke_O_O_O__O(arg_361, arg_362, arg_363) } else { return linked_359.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_358, arg_361, arg_362, arg_363) } }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Invoke_O_O__O(self, fs__1 any) any { var root_375 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var tmp1 any = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New(); var tmp2 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class = fncls__396d; tmp2 = fncls__396d } else { tmp2 = fncls__396 }; arg_378 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_379 any = fs__1; if linked_376 == nil { return ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { return linked_376.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) } }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Invoke_O_O__O(self, p1__233000049_SHARP___1 any) any { var G__233000052__2_ any; var root_380 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any; var root_386 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = p1__233000049_SHARP___1; var arg_390 any = A_arbace_j2g_edge_A_const_85; if linked_387 == nil { arg_383 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { arg_383 = linked_387.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }; var arg_384 any = A_arbace_j2g_edge_A_const_60; var arg_385 any = A_arbace_j2g_edge_A_const_63.GetRawRoot__O(); if linked_381 == nil { G__233000052__2_ = ifn_382.Invoke_O_O_O__O(arg_383, arg_384, arg_385) } else { G__233000052__2_ = linked_381.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_380, arg_383, arg_384, arg_385) }; if lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_edge_A_const_60.Invoke_O__O(p1__233000049_SHARP___1), nil) {
																var root_391 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = G__233000052__2_; var arg_395 any = A_arbace_j2g_edge_A_const_60; if linked_392 == nil { return ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { return linked_392.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) } } else {
//line :129:1
		return G__233000052__2_ } }


func A_arbace_j2g_edge_info_data_fn__233000055_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Invoke_O_O__O(self, ms__1 any) any {
	var root_398 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var tmp1 any = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New(); var tmp2 *jrt.Class; var fncls__468 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class; if fncls__468 == nil { var fncls__468d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class = fncls__468d; tmp2 = fncls__468d } else { tmp2 = fncls__468 }; arg_401 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_402 any = ms__1; if linked_399 == nil { return ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { return linked_399.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) } }
//line :133:1
func A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Ctor() {}
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Invoke_O_O__O(self, m__1 any) any { var a__2 any; var tmp1 any; var root_403 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_405 lang.IFn; if
													linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = m__1; var arg_407 any = A_arbace_j2g_edge_A_const_87; if linked_404 == nil { tmp1 = ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { tmp1 = linked_404.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_403, arg_406, arg_407) }; if jrt.J2g_Truth(tmp1) { var root_408 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_j2g_edge_ann_data_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var root_412 any = A_arbace_j2g_edge_A_const_88.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__1); if linked_413 == nil { arg_411 = ifn_414.Invoke_O__O(arg_415) } else { arg_411 = linked_413.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_412, arg_415) }; if linked_409 == nil { a__2 = ifn_410.Invoke_O__O(arg_411) } else { a__2 = linked_409.(*A_arbace_j2g_edge_ann_data_A).Invoke_O_O__O(root_408, arg_411) } } else { a__2 = nil }; var pa__3 any; var tmp2 any; var root_416 any = /*line :133:1*/A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_418 lang.IFn; if

	linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = m__1; var arg_420 any = A_arbace_j2g_edge_A_const_89; if linked_417 == nil { tmp2 = ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { tmp2 = linked_417.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_416, arg_419, arg_420) }; if jrt.J2g_Truth(tmp2) {
		var root_421 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any; var root_426 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var arg_430 any = A_arbace_j2g_edge_A_const_88.GetRawRoot__O(); if linked_427 == nil { arg_424 = ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { arg_424 = linked_427.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_426, arg_429, arg_430) }; var arg_425 any = A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__1); if linked_422 == nil { pa__3 = ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { pa__3 = linked_422.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } } else {
//line :135:1
			pa__3 = nil }; var G__233000057__4_ any = /*line :133:1*/lang.IFn_Cast(A_arbace_j2g_edge_A_const_82.GetRawRoot__O()).Invoke_O_O_O_O__O(m__1, A_arbace_j2g_edge_A_const_85, A_arbace_j2g_edge_A_const_87, A_arbace_j2g_edge_A_const_89); var G__233000057__5_ any; var tmp3 any; var root_438 any = A_arbace_j2g_edge_A_const_90.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_440 lang.IFn; if




	linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_j2g_edge_A_const_91.Invoke_O__O(m__1); if linked_439 == nil { tmp3 = ifn_440.Invoke_O__O(arg_441) } else { tmp3 = linked_439.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_438, arg_441) }; if /*line :137:1*/ jrt.J2g_Truth(tmp3) {
		var root_442 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = G__233000057__4_; var arg_446 any = A_arbace_j2g_edge_A_const_91; if linked_443 == nil { G__233000057__5_ = ifn_444.Invoke_O_O__O(arg_445, arg_446) } else { G__233000057__5_ = linked_443.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_442, arg_445, arg_446) } } else {
//line :137:1
			G__233000057__5_ = G__233000057__4_ }; var G__233000057__6_ any; var tmp4 any; var root_447 any = /*line :133:1*/A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_449 lang.IFn; if





	linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = a__2; if linked_448 == nil { tmp4 = ifn_449.Invoke_O__O(arg_450) } else { tmp4 = linked_448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_447, arg_450) }; if /*line :137:1*/ jrt.J2g_Truth(tmp4) {

		var root_451 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = G__233000057__5_; var arg_455 any = A_arbace_j2g_edge_A_const_87; var arg_456 any = a__2; if linked_452 == nil { G__233000057__6_ = ifn_453.Invoke_O_O_O__O(arg_454, arg_455, arg_456) } else { G__233000057__6_ = linked_452.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_451, arg_454, arg_455, arg_456) } } else {
//line :137:1
			G__233000057__6_ = G__233000057__5_ }; var tmp5 any; var root_457 any = A_arbace_j2g_edge_A_const_93.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_459 lang.IFn; if


	linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var arg_461 any = pa__3; if linked_458 == nil { tmp5 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { tmp5 = linked_458.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }; if /*line :137:1*/ jrt.J2g_Truth(tmp5) {


		var root_462 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = G__233000057__6_; var arg_466 any = A_arbace_j2g_edge_A_const_89; var arg_467 any = pa__3; if linked_463 == nil { return ifn_464.Invoke_O_O_O__O(arg_465, arg_466, arg_467) } else { return linked_463.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_462, arg_465, arg_466, arg_467) } } else {
//line :137:1
			return G__233000057__6_ } }





func A_arbace_j2g_edge_class_entry_text_A_New() *A_arbace_j2g_edge_class_entry_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Ctor() {}
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any { var info__3 any = A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1); var rest_text__4 any; var root_470 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_472 lang.IFn; if

	linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var root_474 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = facets__1; var arg_478 any = A_arbace_j2g_edge_A_const_94; if linked_475 == nil { arg_473 = ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { arg_473 = linked_475.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) }; if linked_471 == nil { rest_text__4 = ifn_472.Invoke_O__O(arg_473) } else { rest_text__4 = linked_471.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_470, arg_473) }; var tmp1 /*line :146:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp2 any; var root_479 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = n__0; if linked_480 == nil { tmp2 = ifn_481.Invoke_O__O(arg_482) } else { tmp2 = linked_480.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_479, arg_482) }; var tmp3 any = tmp2; var tmp4 any; if
	jrt.J2g_Truth(info__3) {
		var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11, nil, Lit_11); var tmp6 any; var root_483 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_485 lang.IFn
		if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = Lit_12; var arg_487 any; var iter__1927001039__auto____13 any; var tmp7 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New(); var tmp8 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class
		if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class = fncls__620d; tmp8 = fncls__620d } else { tmp8 = fncls__620 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp10 any; var root_621 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var root_626 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_630 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_627 == nil { arg_624 = ifn_628.Invoke_O_O__O(arg_629, arg_630) } else { arg_624 = linked_627.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_626, arg_629, arg_630) }; var arg_625 any = info__3; if linked_622 == nil { tmp10 = ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { tmp10 = linked_622.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_621, arg_624, arg_625) }; arg_487 = tmp9.Invoke_O__O(tmp10)
//line :149:1
		if linked_484 == nil { tmp6 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { tmp6 = linked_484.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_483, arg_486, arg_487) }
//line :148:1
		var tmp11 any = tmp6; var tmp12 *jrt.String; var more__13 any; var root_631 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_633 lang.IFn







		if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = facets__1; var arg_635 any = A_arbace_j2g_edge_A_const_94; if linked_632 == nil { more__13 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { more__13 = linked_632.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }
		var tmp13 any; var root_636 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = more__13; if linked_637 == nil { tmp13 = ifn_638.Invoke_O__O(arg_639) } else { tmp13 = linked_637.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_636, arg_639) }; if jrt.J2g_Truth(tmp13) { var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp15 any; var root_640 any = A_arbace_j2g_edge_A_const_95.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = rest_text__4; var arg_644 any = A_arbace_j2g_edge_A_const_96; var arg_645 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rest_text__4)))).Ref(); if linked_641 == nil { tmp15 = ifn_642.Invoke_O_O_O__O(arg_643, arg_644, arg_645) } else { tmp15 = linked_641.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_640, arg_643, arg_644, arg_645) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)) } else { tmp12 = nil }
//line :148:1
		tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, tmp12.Ref(), nil)).Ref() } else {
//line :147:1
			tmp4 = rest_text__4 }; return /*line :146:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref() }



func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New() *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Invoke_O_O__O(self, s__233000062__1 any) any { var tmp1 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(self, s__233000062__1); var tmp2 *jrt.Class; var fncls__619 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class; if fncls__619 == nil { var fncls__619d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class = fncls__619d; tmp2 = fncls__619d } else { tmp2 = fncls__619 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Ctor_O_O(c__iter__233000061, c__s__233000062 any) { t.F_iter__233000061 = c__iter__233000061; t.F_s__233000062 = c__s__233000062 }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Invoke_O__O(self any) any { { var s__233000062__1 any; var t_ any = t.F_s__233000062; t.F_s__233000062 = nil; s__233000062__1 = t_; for { var temp__1927000414__auto____2 any; var root_488 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = s__233000062__1; if linked_489 == nil { temp__1927000414__auto____2 = ifn_490.Invoke_O__O(arg_491) } else { temp__1927000414__auto____2 = linked_489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_488, arg_491) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000062__3 any = temp__1927000414__auto____2; var tmp1 any; var root_492 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = s__233000062__3; if linked_493 == nil { tmp1 = ifn_494.Invoke_O__O(arg_495) } else { tmp1 = linked_493.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_492, arg_495) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_496 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__233000062__3; if linked_497 == nil { c__1927001037__auto____4 = ifn_498.Invoke_O__O(arg_499) } else { c__1927001037__auto____4 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_496, arg_499) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000064__6 any; var root_500 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_501 == nil { b__233000064__6 = ifn_502.Invoke_O__O(arg_503) } else { b__233000064__6 = linked_501.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_500, arg_503) }; var tmp2 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(b__233000064__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__546 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class; if fncls__546 == nil { var fncls__546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class = fncls__546d; tmp3 = fncls__546d } else { tmp3 = fncls__546 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_547 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var root_552 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = b__233000064__6; if linked_553 == nil { arg_550 = ifn_554.Invoke_O__O(arg_555) } else { arg_550 = linked_553.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_552, arg_555) }; var arg_551 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); var tmp5 any; var root_556 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = s__233000062__3; if linked_557 == nil { tmp5 = ifn_558.Invoke_O__O(arg_559) } else { tmp5 = linked_557.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_556, arg_559) }; arg_551 = tmp4.Invoke_O__O(tmp5); if linked_548 == nil { return ifn_549.Invoke_O_O__O(arg_550, arg_551) } else { return linked_548.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_547, arg_550, arg_551) } } else { var root_560 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any; var root_565 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = b__233000064__6; if linked_566 == nil { arg_563 = ifn_567.Invoke_O__O(arg_568) } else { arg_563 = linked_566.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_565, arg_568) }; var arg_564 any; if linked_561 == nil { return ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { return linked_561.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) } } } else { var vec__233000073__4 any; var root_569 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = s__233000062__3; if linked_570 == nil { vec__233000073__4 = ifn_571.Invoke_O__O(arg_572) } else { vec__233000073__4 = linked_570.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_569, arg_572) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000073__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000073__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_573 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var G__233000076__7_ any = k__5
L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__233000076__7_) >> 0 & 1 { case 0: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_86) {

	var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp7 any; var root_579 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = k__5; if linked_580 == nil { tmp7 = ifn_581.Invoke_O__O(arg_582) } else { tmp7 = linked_580.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_579, arg_582) }; var tmp8 any = tmp7; var tmp9 any; var root_583 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = Lit_19; var arg_587 any; var root_588 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_592 any = v__6; if linked_589 == nil { arg_587 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { arg_587 = linked_589.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }; if linked_584 == nil { tmp9 = ifn_585.Invoke_O_O__O(arg_586, arg_587) } else { tmp9 = linked_584.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_583, arg_586, arg_587) }; arg_576 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :151:1
	break L2 }; case 1: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_84) {

		var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp11 any; var root_593 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = k__5; if linked_594 == nil { tmp11 = ifn_595.Invoke_O__O(arg_596) } else { tmp11 = linked_594.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_593, arg_596) }; var tmp12 any = tmp11; var tmp13 any; var root_597 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = Lit_19; var arg_601 any; var root_602 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_606 any = v__6; if linked_603 == nil { arg_601 = ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { arg_601 = linked_603.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) }; if linked_598 == nil { tmp13 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { tmp13 = linked_598.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }; arg_576 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, tmp13, nil)).Ref()
//line :151:1
		break L2 }; default:
}

	var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp15 any; var root_607 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = k__5; if linked_608 == nil { tmp15 = ifn_609.Invoke_O__O(arg_610) } else { tmp15 = linked_608.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_607, arg_610) }; var tmp16 any = tmp15; var tmp17 any; var root_611 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = v__6; if linked_612 == nil { tmp17 = ifn_613.Invoke_O__O(arg_614) } else { tmp17 = linked_612.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_611, arg_614) }; arg_576 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, tmp16, nil, tmp17)).Ref()}
//line :150:1
	var arg_577 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); var tmp19 any; var root_615 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = s__233000062__3; if linked_616 == nil { tmp19 = ifn_617.Invoke_O__O(arg_618) } else { tmp19 = linked_616.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_615, arg_618) }; arg_577 = tmp18.Invoke_O__O(tmp19); if linked_574 == nil { return ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { return linked_574.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_573, arg_576, arg_577) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Ctor_O_I_O(c__b__233000064 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000064 = c__b__233000064; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Invoke_O__O(self any) any { { var i__233000063__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000063__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000068__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000068__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_504 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = t.F_b__233000064; var arg_508 any; var G__233000071__5_ any = k__3
L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__233000071__5_) >> 0 & 1 { case 0: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_86) {

	var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp3 any; var root_510 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = k__3; if linked_511 == nil { tmp3 = ifn_512.Invoke_O__O(arg_513) } else { tmp3 = linked_511.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_510, arg_513) }; var tmp4 any = tmp3; var tmp5 any; var root_514 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = Lit_19; var arg_518 any; var root_519 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_523 any = v__4; if linked_520 == nil { arg_518 = ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { arg_518 = linked_520.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_519, arg_522, arg_523) }; if linked_515 == nil { tmp5 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { tmp5 = linked_515.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }; arg_508 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()
//line :151:1
	break L2 }; case 1: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_84) {

		var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp7 any; var root_524 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = k__3; if linked_525 == nil { tmp7 = ifn_526.Invoke_O__O(arg_527) } else { tmp7 = linked_525.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_524, arg_527) }; var tmp8 any = tmp7; var tmp9 any; var root_528 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = Lit_19; var arg_532 any; var root_533 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_537 any = v__4; if linked_534 == nil { arg_532 = ifn_535.Invoke_O_O__O(arg_536, arg_537) } else { arg_532 = linked_534.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_533, arg_536, arg_537) }; if linked_529 == nil { tmp9 = ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { tmp9 = linked_529.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_528, arg_531, arg_532) }; arg_508 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :151:1
		break L2 }; default:
}

	var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp11 any; var root_538 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = k__3; if linked_539 == nil { tmp11 = ifn_540.Invoke_O__O(arg_541) } else { tmp11 = linked_539.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_538, arg_541) }; var tmp12 any = tmp11; var tmp13 any; var root_542 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = v__4; if linked_543 == nil { tmp13 = ifn_544.Invoke_O__O(arg_545) } else { tmp13 = linked_543.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_542, arg_545) }; arg_508 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, tmp13)).Ref()}
//line :150:1
	if linked_505 == nil { ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { linked_505.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; i__233000063__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000063__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_j2g_edge_edge_text_A_New() *A_arbace_j2g_edge_edge_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Ctor() {}
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Invoke_O_O__O(self, p__233000080__0 any) any { var map__233000081__2 any = p__233000080__0; var map__233000081__3 any; if lang.ISeq_InstanceOf(map__233000081__2) { var tmp1 any; var root_646 any = A_arbace_j2g_edge_A_const_97.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = map__233000081__2; if linked_647 == nil { tmp1 = ifn_648.Invoke_O__O(arg_649) } else { tmp1 = linked_647.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_650 any = A_arbace_j2g_edge_A_const_98.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = map__233000081__2; if linked_651 == nil { tmp2 = ifn_652.Invoke_O__O(arg_653) } else { tmp2 = linked_651.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_650, arg_653) }; map__233000081__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_654 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = map__233000081__2; if linked_655 == nil { tmp3 = ifn_656.Invoke_O__O(arg_657) } else { tmp3 = linked_655.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_654, arg_657) }; if jrt.J2g_Truth(tmp3) { var root_658 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = map__233000081__2; if linked_659 == nil { map__233000081__3 = ifn_660.Invoke_O__O(arg_661) } else { map__233000081__3 = linked_659.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_658, arg_661) } } else { map__233000081__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__233000081__3 = map__233000081__2 }; var edge__4 any = map__233000081__3; var classes__5 any = lang.RT_Get_O_O__O_NoInit(map__233000081__3, A_arbace_j2g_edge_A_const_99); var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,7,s92:;; j2g's edge (doc/STANDALONE-NOTES.md, S2): the classes outside the forms as j2g sees them\ns84:;; on the JVM, written by bin/j2g-edge update (bin/j2g --record-edge); do not edit.\ns12:{:classes\n {ns2:}\nns2:}\n", []*jrt.Class{jrt.String_class}); var tmp5 any; var root_662 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_664 lang.IFn; if





	linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = Lit_9; var arg_666 any; var iter__1927001039__auto____13 any; var tmp6 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New(); var tmp7 *jrt.Class; var fncls__735 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class; if fncls__735 == nil { var fncls__735d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class = fncls__735d; tmp7 = fncls__735d } else { tmp7 = fncls__735 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp9 any; var root_736 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); var arg_740 any = classes__5; if linked_737 == nil { tmp9 = ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { tmp9 = linked_737.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) }; arg_666 = tmp8.Invoke_O__O(tmp9); if linked_663 == nil { tmp5 = ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { tmp5 = linked_663.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }; var tmp10 any = tmp5; var tmp11 any; var root_741 any = /*line :164:1*/A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_743 lang.IFn; if




	linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any; var iter__1927001039__auto____13_2 any; var tmp12 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New(); var tmp13 *jrt.Class; var fncls__1007 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class; if fncls__1007 == nil { var fncls__1007d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class = fncls__1007d; tmp13 = fncls__1007d } else { tmp13 = fncls__1007 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp15 any; var root_1008 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); var arg_1012 any; var root_1013 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = edge__4; var arg_1017 any = A_arbace_j2g_edge_A_const_99; if linked_1014 == nil { arg_1012 = ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { arg_1012 = linked_1014.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) }; if linked_1009 == nil { tmp15 = ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { tmp15 = linked_1009.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) }; arg_744 = tmp14.Invoke_O__O(tmp15); if linked_742 == nil { tmp11 = ifn_743.Invoke_O__O(arg_744) } else { tmp11 = linked_742.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_741, arg_744) }; return /*line :164:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp10, nil, tmp11, nil)).Ref() }


func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New() *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Invoke_O_O__O(self, s__233000084__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(self, s__233000084__1); var tmp2 *jrt.Class; var fncls__734 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class; if fncls__734 == nil { var fncls__734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class = fncls__734d; tmp2 = fncls__734d } else { tmp2 = fncls__734 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Ctor_O_O(c__iter__233000083, c__s__233000084 any) { t.F_iter__233000083 = c__iter__233000083; t.F_s__233000084 = c__s__233000084 }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Invoke_O__O(self any) any { { var s__233000084__1 any; var t_ any = t.F_s__233000084; t.F_s__233000084 = nil; s__233000084__1 = t_; for { var temp__1927000414__auto____2 any; var root_667 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = s__233000084__1; if linked_668 == nil { temp__1927000414__auto____2 = ifn_669.Invoke_O__O(arg_670) } else { temp__1927000414__auto____2 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000084__3 any = temp__1927000414__auto____2; var tmp1 any; var root_671 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = s__233000084__3; if linked_672 == nil { tmp1 = ifn_673.Invoke_O__O(arg_674) } else { tmp1 = linked_672.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_671, arg_674) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_675 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = s__233000084__3; if linked_676 == nil { c__1927001037__auto____4 = ifn_677.Invoke_O__O(arg_678) } else { c__1927001037__auto____4 = linked_676.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_675, arg_678) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000086__6 any; var root_679 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_680 == nil { b__233000086__6 = ifn_681.Invoke_O__O(arg_682) } else { b__233000086__6 = linked_680.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_679, arg_682) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(b__233000086__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__693 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class; if fncls__693 == nil { var fncls__693d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class = fncls__693d; tmp3 = fncls__693d } else { tmp3 = fncls__693 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_694 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any; var root_699 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = b__233000086__6; if linked_700 == nil { arg_697 = ifn_701.Invoke_O__O(arg_702) } else { arg_697 = linked_700.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_699, arg_702) }; var arg_698 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); var tmp5 any; var root_703 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = s__233000084__3; if linked_704 == nil { tmp5 = ifn_705.Invoke_O__O(arg_706) } else { tmp5 = linked_704.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_703, arg_706) }; arg_698 = tmp4.Invoke_O__O(tmp5); if linked_695 == nil { return ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { return linked_695.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_694, arg_697, arg_698) } } else { var root_707 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var root_712 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = b__233000086__6; if linked_713 == nil { arg_710 = ifn_714.Invoke_O__O(arg_715) } else { arg_710 = linked_713.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_712, arg_715) }; var arg_711 any; if linked_708 == nil { return ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { return linked_708.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_707, arg_710, arg_711) } } } else { var vec__233000094__4 any; var root_716 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__233000084__3; if linked_717 == nil { vec__233000094__4 = ifn_718.Invoke_O__O(arg_719) } else { vec__233000094__4 = linked_717.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_716, arg_719) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000094__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000094__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_720 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any; var root_725 any = A_arbace_j2g_edge_A_const_100.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, A_arbace_j2g_edge_class_entry_text_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = n__5; var arg_729 any = facets__6; if linked_726 == nil { arg_723 = ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { arg_723 = linked_726.(*A_arbace_j2g_edge_class_entry_text_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) }; var arg_724 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); var tmp7 any; var root_730 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__233000084__3; if linked_731 == nil { tmp7 = ifn_732.Invoke_O__O(arg_733) } else { tmp7 = linked_731.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_730, arg_733) }; arg_724 = tmp6.Invoke_O__O(tmp7); if linked_721 == nil { return ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { return linked_721.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_720, arg_723, arg_724) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Ctor_O_I_O(c__b__233000086 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000086 = c__b__233000086; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Invoke_O__O(self any) any { { var i__233000085__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000085__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000090__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000085__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000090__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000090__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_683 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = t.F_b__233000086; var arg_687 any; var root_688 any = A_arbace_j2g_edge_A_const_100.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, A_arbace_j2g_edge_class_entry_text_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = n__3; var arg_692 any = facets__4; if linked_689 == nil { arg_687 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { arg_687 = linked_689.(*A_arbace_j2g_edge_class_entry_text_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; if linked_684 == nil { ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { linked_684.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; i__233000085__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000085__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Invoke_O_O__O(self, s__233000100__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(self, s__233000100__1); var tmp2 *jrt.Class; var fncls__1006 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class; if fncls__1006 == nil { var fncls__1006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class = fncls__1006d; tmp2 = fncls__1006d } else { tmp2 = fncls__1006 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Ctor_O_O(c__iter__233000099, c__s__233000100 any) { t.F_iter__233000099 = c__iter__233000099; t.F_s__233000100 = c__s__233000100 }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Invoke_O__O(self any) any { { var s__233000100__1 any; var t_ any = t.F_s__233000100; t.F_s__233000100 = nil; s__233000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_745 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = s__233000100__1; if linked_746 == nil { temp__1927000414__auto____2 = ifn_747.Invoke_O__O(arg_748) } else { temp__1927000414__auto____2 = linked_746.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_745, arg_748) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_749 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = s__233000100__3; if linked_750 == nil { tmp1 = ifn_751.Invoke_O__O(arg_752) } else { tmp1 = linked_750.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_753 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = s__233000100__3; if linked_754 == nil { c__1927001037__auto____4 = ifn_755.Invoke_O__O(arg_756) } else { c__1927001037__auto____4 = linked_754.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_753, arg_756) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000102__6 any; var root_757 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_758 == nil { b__233000102__6 = ifn_759.Invoke_O__O(arg_760) } else { b__233000102__6 = linked_758.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_757, arg_760) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(b__233000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__868 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class; if fncls__868 == nil { var fncls__868d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class = fncls__868d; tmp3 = fncls__868d } else { tmp3 = fncls__868 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_869 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any; var root_874 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = b__233000102__6; if linked_875 == nil { arg_872 = ifn_876.Invoke_O__O(arg_877) } else { arg_872 = linked_875.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_874, arg_877) }; var arg_873 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); var tmp5 any; var root_878 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = s__233000100__3; if linked_879 == nil { tmp5 = ifn_880.Invoke_O__O(arg_881) } else { tmp5 = linked_879.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_878, arg_881) }; arg_873 = tmp4.Invoke_O__O(tmp5); if linked_870 == nil { return ifn_871.Invoke_O_O__O(arg_872, arg_873) } else { return linked_870.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_869, arg_872, arg_873) } } else { var root_882 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var root_887 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = b__233000102__6; if linked_888 == nil { arg_885 = ifn_889.Invoke_O__O(arg_890) } else { arg_885 = linked_888.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_887, arg_890) }; var arg_886 any; if linked_883 == nil { return ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { return linked_883.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) } } } else { var vec__233000126__4 any; var root_891 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = s__233000100__3; if linked_892 == nil { vec__233000126__4 = ifn_893.Invoke_O__O(arg_894) } else { vec__233000126__4 = linked_892.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_891, arg_894) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000126__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000126__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_895 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_35, nil, Lit_36); var tmp7 any; var root_900 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_902 lang.IFn
														if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = k__5; if linked_901 == nil { tmp7 = ifn_902.Invoke_O__O(arg_903) } else { tmp7 = linked_901.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_900, arg_903) }; var tmp8 any = tmp7; var tmp9 any; var tmp10 any; var root_904 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_906 lang.IFn
														if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = v__6; if linked_905 == nil { tmp10 = ifn_906.Invoke_O__O(arg_907) } else { tmp10 = linked_905.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_904, arg_907) }; if jrt.J2g_Truth(tmp10) {
															var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_11); var tmp12 any; var root_908 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = Lit_9; var arg_912 any; var iter__1927001039__auto____15 any; var tmp13 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New(); var tmp14 *jrt.Class; var fncls__987 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class; if fncls__987 == nil { var fncls__987d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class = fncls__987d; tmp14 = fncls__987d } else { tmp14 = fncls__987 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp15 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp16 any; var root_988 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var root_993 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_997 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_994 == nil { arg_991 = ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { arg_991 = linked_994.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_993, arg_996, arg_997) }; var arg_992 any = v__6; if linked_989 == nil { tmp16 = ifn_990.Invoke_O_O__O(arg_991, arg_992) } else { tmp16 = linked_989.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_988, arg_991, arg_992) }; arg_912 = tmp15.Invoke_O__O(tmp16); if linked_909 == nil { tmp12 = ifn_910.Invoke_O_O__O(arg_911, arg_912) } else { tmp12 = linked_909.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_908, arg_911, arg_912) }; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } else {
																var root_998 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = v__6; if linked_999 == nil { tmp9 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp9 = linked_999.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_998, arg_1001) } }
//line :170:1
	arg_898 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp9, nil)).Ref()
//line :169:1
	var arg_899 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); var tmp18 any; var root_1002 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = s__233000100__3; if linked_1003 == nil { tmp18 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp18 = linked_1003.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1002, arg_1005) }; arg_899 = tmp17.Invoke_O__O(tmp18); if linked_896 == nil { return ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { return linked_896.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Ctor_O_I_O(c__b__233000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000102 = c__b__233000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Invoke_O__O(self any) any { { var i__233000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000106__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000106__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_761 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = t.F_b__233000102; var arg_765 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_35, nil, Lit_36); var tmp3 any; var root_766 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_768 lang.IFn
																if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = k__3; if linked_767 == nil { tmp3 = ifn_768.Invoke_O__O(arg_769) } else { tmp3 = linked_767.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_766, arg_769) }; var tmp4 any = tmp3; var tmp5 any; var tmp6 any; var root_770 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_772 lang.IFn
																if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = v__4; if linked_771 == nil { tmp6 = ifn_772.Invoke_O__O(arg_773) } else { tmp6 = linked_771.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_770, arg_773) }; if jrt.J2g_Truth(tmp6) {
																	var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_11); var tmp8 any; var root_774 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = Lit_9; var arg_778 any; var iter__1927001039__auto____13 any; var tmp9 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New(); var tmp10 *jrt.Class; var fncls__853 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class; if fncls__853 == nil { var fncls__853d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class = fncls__853d; tmp10 = fncls__853d } else { tmp10 = fncls__853 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp12 any; var root_854 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any; var root_859 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_863 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_860 == nil { arg_857 = ifn_861.Invoke_O_O__O(arg_862, arg_863) } else { arg_857 = linked_860.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_859, arg_862, arg_863) }; var arg_858 any = v__4; if linked_855 == nil { tmp12 = ifn_856.Invoke_O_O__O(arg_857, arg_858) } else { tmp12 = linked_855.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_854, arg_857, arg_858) }; arg_778 = tmp11.Invoke_O__O(tmp12); if linked_775 == nil { tmp8 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { tmp8 = linked_775.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil)).Ref() } else {
																		var root_864 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = v__4; if linked_865 == nil { tmp5 = ifn_866.Invoke_O__O(arg_867) } else { tmp5 = linked_865.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_864, arg_867) } }
//line :170:1
	arg_765 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref()
//line :169:1
	if linked_762 == nil { ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { linked_762.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) }; i__233000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Invoke_O_O__O(self, s__233000110__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(self, s__233000110__1); var tmp2 *jrt.Class; var fncls__852 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class; if fncls__852 == nil { var fncls__852d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class = fncls__852d; tmp2 = fncls__852d } else { tmp2 = fncls__852 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Ctor_O_O(c__iter__233000109, c__s__233000110 any) { t.F_iter__233000109 = c__iter__233000109; t.F_s__233000110 = c__s__233000110 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Invoke_O__O(self any) any { { var s__233000110__1 any; var t_ any = t.F_s__233000110; t.F_s__233000110 = nil; s__233000110__1 = t_; for { var temp__1927000414__auto____2 any; var root_779 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = s__233000110__1; if linked_780 == nil { temp__1927000414__auto____2 = ifn_781.Invoke_O__O(arg_782) } else { temp__1927000414__auto____2 = linked_780.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_779, arg_782) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000110__3 any = temp__1927000414__auto____2; var tmp1 any; var root_783 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = s__233000110__3; if linked_784 == nil { tmp1 = ifn_785.Invoke_O__O(arg_786) } else { tmp1 = linked_784.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_783, arg_786) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_787 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = s__233000110__3; if linked_788 == nil { c__1927001037__auto____4 = ifn_789.Invoke_O__O(arg_790) } else { c__1927001037__auto____4 = linked_788.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_787, arg_790) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000112__6 any; var root_791 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_792 == nil { b__233000112__6 = ifn_793.Invoke_O__O(arg_794) } else { b__233000112__6 = linked_792.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_791, arg_794) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(b__233000112__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__808 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class; if fncls__808 == nil { var fncls__808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class = fncls__808d; tmp3 = fncls__808d } else { tmp3 = fncls__808 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_809 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_814 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = b__233000112__6; if linked_815 == nil { arg_812 = ifn_816.Invoke_O__O(arg_817) } else { arg_812 = linked_815.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_814, arg_817) }; var arg_813 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); var tmp5 any; var root_818 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = s__233000110__3; if linked_819 == nil { tmp5 = ifn_820.Invoke_O__O(arg_821) } else { tmp5 = linked_819.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_818, arg_821) }; arg_813 = tmp4.Invoke_O__O(tmp5); if linked_810 == nil { return ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { return linked_810.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_809, arg_812, arg_813) } } else { var root_822 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any; var root_827 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = b__233000112__6; if linked_828 == nil { arg_825 = ifn_829.Invoke_O__O(arg_830) } else { arg_825 = linked_828.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_827, arg_830) }; var arg_826 any; if linked_823 == nil { return ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { return linked_823.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_822, arg_825, arg_826) } } } else { var vec__233000120__4 any; var root_831 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = s__233000110__3; if linked_832 == nil { vec__233000120__4 = ifn_833.Invoke_O__O(arg_834) } else { vec__233000120__4 = linked_832.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_831, arg_834) }; var kk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_835 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp7 any; var root_840 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = kk__5; if linked_841 == nil { tmp7 = ifn_842.Invoke_O__O(arg_843) } else { tmp7 = linked_841.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_840, arg_843) }; var tmp8 any = tmp7; var tmp9 any; var root_844 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = vv__6; if linked_845 == nil { tmp9 = ifn_846.Invoke_O__O(arg_847) } else { tmp9 = linked_845.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_844, arg_847) }; arg_838 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_839 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); var tmp11 any; var root_848 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = s__233000110__3; if linked_849 == nil { tmp11 = ifn_850.Invoke_O__O(arg_851) } else { tmp11 = linked_849.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_848, arg_851) }; arg_839 = tmp10.Invoke_O__O(tmp11); if linked_836 == nil { return ifn_837.Invoke_O_O__O(arg_838, arg_839) } else { return linked_836.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_835, arg_838, arg_839) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Ctor_O_I_O(c__b__233000112 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000112 = c__b__233000112; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Invoke_O__O(self any) any { { var i__233000111__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000111__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000116__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000111__1)); var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000116__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000116__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_795 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = t.F_b__233000112; var arg_799 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp3 any; var root_800 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = kk__3; if linked_801 == nil { tmp3 = ifn_802.Invoke_O__O(arg_803) } else { tmp3 = linked_801.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_800, arg_803) }; var tmp4 any = tmp3; var tmp5 any; var root_804 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = vv__4; if linked_805 == nil { tmp5 = ifn_806.Invoke_O__O(arg_807) } else { tmp5 = linked_805.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_804, arg_807) }; arg_799 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_796 == nil { ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { linked_796.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }; i__233000111__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000111__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Invoke_O_O__O(self, s__233000130__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(self, s__233000130__1); var tmp2 *jrt.Class; var fncls__986 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class; if fncls__986 == nil { var fncls__986d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class = fncls__986d; tmp2 = fncls__986d } else { tmp2 = fncls__986 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Ctor_O_O(c__iter__233000129, c__s__233000130 any) { t.F_iter__233000129 = c__iter__233000129; t.F_s__233000130 = c__s__233000130 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Invoke_O__O(self any) any { { var s__233000130__1 any; var t_ any = t.F_s__233000130; t.F_s__233000130 = nil; s__233000130__1 = t_; for { var temp__1927000414__auto____2 any; var root_913 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = s__233000130__1; if linked_914 == nil { temp__1927000414__auto____2 = ifn_915.Invoke_O__O(arg_916) } else { temp__1927000414__auto____2 = linked_914.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_913, arg_916) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000130__3 any = temp__1927000414__auto____2; var tmp1 any; var root_917 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = s__233000130__3; if linked_918 == nil { tmp1 = ifn_919.Invoke_O__O(arg_920) } else { tmp1 = linked_918.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_917, arg_920) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_921 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = s__233000130__3; if linked_922 == nil { c__1927001037__auto____4 = ifn_923.Invoke_O__O(arg_924) } else { c__1927001037__auto____4 = linked_922.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_921, arg_924) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000132__6 any; var root_925 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_926 == nil { b__233000132__6 = ifn_927.Invoke_O__O(arg_928) } else { b__233000132__6 = linked_926.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_925, arg_928) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(b__233000132__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__942 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class; if fncls__942 == nil { var fncls__942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class = fncls__942d; tmp3 = fncls__942d } else { tmp3 = fncls__942 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_943 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any; var root_948 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = b__233000132__6; if linked_949 == nil { arg_946 = ifn_950.Invoke_O__O(arg_951) } else { arg_946 = linked_949.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_948, arg_951) }; var arg_947 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); var tmp5 any; var root_952 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = s__233000130__3; if linked_953 == nil { tmp5 = ifn_954.Invoke_O__O(arg_955) } else { tmp5 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_952, arg_955) }; arg_947 = tmp4.Invoke_O__O(tmp5); if linked_944 == nil { return ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { return linked_944.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_943, arg_946, arg_947) } } else { var root_956 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any; var root_961 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = b__233000132__6; if linked_962 == nil { arg_959 = ifn_963.Invoke_O__O(arg_964) } else { arg_959 = linked_962.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_961, arg_964) }; var arg_960 any; if linked_957 == nil { return ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { return linked_957.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) } } } else { var vec__233000140__4 any; var root_965 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = s__233000130__3; if linked_966 == nil { vec__233000140__4 = ifn_967.Invoke_O__O(arg_968) } else { vec__233000140__4 = linked_966.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_965, arg_968) }; var kk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000140__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000140__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_969 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp7 any; var root_974 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = kk__5; if linked_975 == nil { tmp7 = ifn_976.Invoke_O__O(arg_977) } else { tmp7 = linked_975.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_974, arg_977) }; var tmp8 any = tmp7; var tmp9 any; var root_978 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = vv__6; if linked_979 == nil { tmp9 = ifn_980.Invoke_O__O(arg_981) } else { tmp9 = linked_979.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_978, arg_981) }; arg_972 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_973 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); var tmp11 any; var root_982 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = s__233000130__3; if linked_983 == nil { tmp11 = ifn_984.Invoke_O__O(arg_985) } else { tmp11 = linked_983.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_982, arg_985) }; arg_973 = tmp10.Invoke_O__O(tmp11); if linked_970 == nil { return ifn_971.Invoke_O_O__O(arg_972, arg_973) } else { return linked_970.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_969, arg_972, arg_973) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Ctor_O_I_O(c__b__233000132 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000132 = c__b__233000132; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Invoke_O__O(self any) any { { var i__233000131__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000131__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000136__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000131__1)); var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000136__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000136__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_929 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = t.F_b__233000132; var arg_933 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp3 any; var root_934 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = kk__3; if linked_935 == nil { tmp3 = ifn_936.Invoke_O__O(arg_937) } else { tmp3 = linked_935.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_934, arg_937) }; var tmp4 any = tmp3; var tmp5 any; var root_938 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = vv__4; if linked_939 == nil { tmp5 = ifn_940.Invoke_O__O(arg_941) } else { tmp5 = linked_939.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_938, arg_941) }; arg_933 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_930 == nil { ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { linked_930.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_929, arg_932, arg_933) }; i__233000131__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000131__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_recorded_edge_A_New() *A_arbace_j2g_edge_recorded_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Invoke_O_O_O__O(self, env_rec__0, j2g_rec__1_ any) any { var classes__3 any; var root_1147 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1149 lang.IFn; if



	linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_107, nil); if linked_1148 == nil { ifn_1149.Invoke_O__O(arg_1150) } else { linked_1148.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1147, arg_1150) }; var tmp1 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(env_rec__0); var tmp2 *jrt.Class; var fncls__1141 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class; if fncls__1141 == nil { var fncls__1141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class = fncls__1141d; tmp2 = fncls__1141d } else { tmp2 = fncls__1141 }; classes__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var root_1142 any =




	A_arbace_j2g_edge_A_const_106.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_99, classes__3)); var arg_1146 any = j2g_rec__1_; if linked_1143 == nil { return ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { return linked_1143.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) } }
//line :181:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(p0 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Ctor_O(c__env_rec any) { t.F_env_rec = c__env_rec }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1018 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1022 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New(); var tmp3 *jrt.Class; var fncls__1137 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class; if fncls__1137 == nil { var fncls__1137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class = fncls__1137d; tmp3 = fncls__1137d } else { tmp3 = fncls__1137 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var t_ any = t.F_env_rec; t.F_env_rec = nil; tmp5 = t_; arg_1022 = tmp4.Invoke_O__O(tmp5); if linked_1019 == nil { tmp1 = ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { tmp1 = linked_1019.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) } }
//line :181:1
	return nil }(); var root_1138 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; if linked_1139 == nil { ifn_1140.Invoke__O() } else { linked_1139.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1138) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New() *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Invoke_O_O__O(self, s__233000150__1 any) any { var tmp1 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(self, s__233000150__1); var tmp2 *jrt.Class; var fncls__1136 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class; if fncls__1136 == nil { var fncls__1136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class = fncls__1136d; tmp2 = fncls__1136d } else { tmp2 = fncls__1136 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Ctor_O_O(c__iter__233000149, c__s__233000150 any) { t.F_iter__233000149 = c__iter__233000149; t.F_s__233000150 = c__s__233000150 }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Invoke_O__O(self any) any { { var s__233000150__1 any; var t_ any = t.F_s__233000150; t.F_s__233000150 = nil; s__233000150__1 = t_; for { var temp__1927000414__auto____2 any; var root_1023 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = s__233000150__1; if linked_1024 == nil { temp__1927000414__auto____2 = ifn_1025.Invoke_O__O(arg_1026) } else { temp__1927000414__auto____2 = linked_1024.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1023, arg_1026) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000150__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1027 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = s__233000150__3; if linked_1028 == nil { tmp1 = ifn_1029.Invoke_O__O(arg_1030) } else { tmp1 = linked_1028.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1027, arg_1030) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1031 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = s__233000150__3; if linked_1032 == nil { c__1927001037__auto____4 = ifn_1033.Invoke_O__O(arg_1034) } else { c__1927001037__auto____4 = linked_1032.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1031, arg_1034) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000152__6 any; var root_1035 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1036 == nil { b__233000152__6 = ifn_1037.Invoke_O__O(arg_1038) } else { b__233000152__6 = linked_1036.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1035, arg_1038) }; var tmp2 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(b__233000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1072 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class; if fncls__1072 == nil { var fncls__1072d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class = fncls__1072d; tmp3 = fncls__1072d } else { tmp3 = fncls__1072 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1073 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any; var root_1078 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = b__233000152__6; if linked_1079 == nil { arg_1076 = ifn_1080.Invoke_O__O(arg_1081) } else { arg_1076 = linked_1079.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1078, arg_1081) }; var arg_1077 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); var tmp5 any; var root_1082 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = s__233000150__3; if linked_1083 == nil { tmp5 = ifn_1084.Invoke_O__O(arg_1085) } else { tmp5 = linked_1083.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1082, arg_1085) }; arg_1077 = tmp4.Invoke_O__O(tmp5); if linked_1074 == nil { return ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { return linked_1074.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) } } else { var root_1086 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any; var root_1091 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = b__233000152__6; if linked_1092 == nil { arg_1089 = ifn_1093.Invoke_O__O(arg_1094) } else { arg_1089 = linked_1092.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1091, arg_1094) }; var arg_1090 any; if linked_1087 == nil { return ifn_1088.Invoke_O_O__O(arg_1089, arg_1090) } else { return linked_1087.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1086, arg_1089, arg_1090) } } } else { var vec__233000161__4 any; var root_1095 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = s__233000150__3; if linked_1096 == nil { vec__233000161__4 = ifn_1097.Invoke_O__O(arg_1098) } else { vec__233000161__4 = linked_1096.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1095, arg_1098) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000161__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000161__4, lang.RT_IntCast_J__I_NoInit(1), nil); var c__7 any; var tmp6 any; var root_1099 any = A_arbace_j2g_edge_A_const_101.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1101 lang.IFn
																if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = n__5; var arg_1103 any = Lit_73; if linked_1100 == nil { tmp6 = ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { tmp6 = linked_1100.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) }; if jrt.J2g_Truth(tmp6) { c__7 = nil } else { var root_1104 any = A_arbace_j2g_edge_A_const_102.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_classes_env.A_arbace_classes_env_load_class_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = n__5; if linked_1105 == nil { c__7 = ifn_1106.Invoke_O__O(arg_1107) } else { c__7 = linked_1105.(*aot_arbace_classes_env.A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_1104, arg_1107) } }
//line :182:1
	var root_1108 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any; var tmp7 any; var root_1113 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1115 lang.IFn

	if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = n__5; var arg_1117 any; var G__233000164__8_ any = facets__6; if jrt.J2g_Truth(c__7) {
		var root_1118 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = G__233000164__8_; var arg_1122 any = A_arbace_j2g_edge_A_const_94; var arg_1123 any; var root_1124 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, A_arbace_j2g_edge_info_data_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any; var root_1128 any = A_arbace_j2g_edge_A_const_105.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = c__7; if linked_1129 == nil { arg_1127 = ifn_1130.Invoke_O__O(arg_1131) } else { arg_1127 = linked_1129.(*aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_1128, arg_1131) }; if linked_1125 == nil { arg_1123 = ifn_1126.Invoke_O__O(arg_1127) } else { arg_1123 = linked_1125.(*A_arbace_j2g_edge_info_data_A).Invoke_O_O__O(root_1124, arg_1127) }; if linked_1119 == nil { arg_1117 = ifn_1120.Invoke_O_O_O__O(arg_1121, arg_1122, arg_1123) } else { arg_1117 = linked_1119.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1118, arg_1121, arg_1122, arg_1123) } } else {
//line :184:1
			arg_1117 = G__233000164__8_ }; if linked_1114 == nil { tmp7 = ifn_1115.Invoke_O_O__O(arg_1116, arg_1117) } else { tmp7 = linked_1114.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1113, arg_1116, arg_1117) }
//line :182:1
	arg_1111 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp7); var arg_1112 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); var tmp9 any; var root_1132 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = s__233000150__3; if linked_1133 == nil { tmp9 = ifn_1134.Invoke_O__O(arg_1135) } else { tmp9 = linked_1133.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1132, arg_1135) }; arg_1112 = tmp8.Invoke_O__O(tmp9); if linked_1109 == nil { return ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { return linked_1109.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Ctor_O_I_O(c__b__233000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000152 = c__b__233000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Invoke_O__O(self any) any { { var i__233000151__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000156__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000156__2, lang.RT_IntCast_J__I_NoInit(1), nil); var c__5 any; var tmp2 any; var root_1039 any = A_arbace_j2g_edge_A_const_101.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1041 lang.IFn
																		if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = n__3; var arg_1043 any = Lit_73; if linked_1040 == nil { tmp2 = ifn_1041.Invoke_O_O__O(arg_1042, arg_1043) } else { tmp2 = linked_1040.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1039, arg_1042, arg_1043) }; if jrt.J2g_Truth(tmp2) { c__5 = nil } else { var root_1044 any = A_arbace_j2g_edge_A_const_102.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_classes_env.A_arbace_classes_env_load_class_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = n__3; if linked_1045 == nil { c__5 = ifn_1046.Invoke_O__O(arg_1047) } else { c__5 = linked_1045.(*aot_arbace_classes_env.A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_1044, arg_1047) } }
//line :182:1
	var root_1048 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = t.F_b__233000152; var arg_1052 any; var tmp3 any; var root_1053 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1055 lang.IFn

	if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = n__3; var arg_1057 any; var G__233000159__6_ any = facets__4; if jrt.J2g_Truth(c__5) {
		var root_1058 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = G__233000159__6_; var arg_1062 any = A_arbace_j2g_edge_A_const_94; var arg_1063 any; var root_1064 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, A_arbace_j2g_edge_info_data_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any; var root_1068 any = A_arbace_j2g_edge_A_const_105.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = c__5; if linked_1069 == nil { arg_1067 = ifn_1070.Invoke_O__O(arg_1071) } else { arg_1067 = linked_1069.(*aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_1068, arg_1071) }; if linked_1065 == nil { arg_1063 = ifn_1066.Invoke_O__O(arg_1067) } else { arg_1063 = linked_1065.(*A_arbace_j2g_edge_info_data_A).Invoke_O_O__O(root_1064, arg_1067) }; if linked_1059 == nil { arg_1057 = ifn_1060.Invoke_O_O_O__O(arg_1061, arg_1062, arg_1063) } else { arg_1057 = linked_1059.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1058, arg_1061, arg_1062, arg_1063) } } else {
//line :184:1
			arg_1057 = G__233000159__6_ }; if linked_1054 == nil { tmp3 = ifn_1055.Invoke_O_O__O(arg_1056, arg_1057) } else { tmp3 = linked_1054.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1053, arg_1056, arg_1057) }
//line :182:1
	arg_1052 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp3); if linked_1049 == nil { ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { linked_1049.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) }; i__233000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000151__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_edge_merge_edges_A_New() *A_arbace_j2g_edge_merge_edges_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Ctor() {}
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Invoke_O_O__O(self, edges__0 any) any {


	var root_1156 any = A_arbace_j2g_edge_A_const_108.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = A_arbace_j2g_edge_A_const_109.GetRawRoot__O(); var arg_1160 any; var tmp1 any = A_arbace_j2g_edge_merge_edges_fn__233000169_A_New(); var tmp2 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class; if fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class = fncls__1195d; tmp2 = fncls__1195d } else { tmp2 = fncls__1195 }; arg_1160 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1161 any = edges__0; if linked_1157 == nil { return ifn_1158.Invoke_O_O_O__O(arg_1159, arg_1160, arg_1161) } else { return linked_1157.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1156, arg_1159, arg_1160, arg_1161) } }
//line :191:1
func A_arbace_j2g_edge_merge_edges_fn__233000169_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Ctor() {}
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var tmp1 any; var root_1162 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = a__1; if linked_1163 == nil { tmp1 = ifn_1164.Invoke_O__O(arg_1165) } else { tmp1 = linked_1163.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1162, arg_1165) }; if jrt.J2g_Truth(tmp1) { var root_1166 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = a__1; var arg_1170 any = b__2; if linked_1167 == nil { return ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { return linked_1167.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) } } else { var tmp2 any; var root_1171 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1173 lang.IFn
													if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = a__1; if linked_1172 == nil { tmp2 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp2 = linked_1172.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1171, arg_1174) }
//line :191:1
	if jrt.J2g_Truth(tmp2) {
		var root_1175 any = A_arbace_j2g_edge_A_const_109.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any; var tmp3 any = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New(); var tmp4 *jrt.Class; var fncls__1194 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class; if fncls__1194 == nil { var fncls__1194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class = fncls__1194d; tmp4 = fncls__1194d } else { tmp4 = fncls__1194 }; arg_1178 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1179 any = a__1; var arg_1180 any = b__2; if linked_1176 == nil { return ifn_1177.Invoke_O_O_O__O(arg_1178, arg_1179, arg_1180) } else { return linked_1176.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1175, arg_1178, arg_1179, arg_1180) } } else {
//line :191:1
			if A_arbace_j2g_edge_A_const_27 != nil { return b__2 } else { return nil } } } }
func A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Invoke_O_O_O__O(self, x__1, y__2 any) any { var tmp1 any; var and__1927000168__auto____3 any; var root_1181 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = x__1; if linked_1182 == nil { and__1927000168__auto____3 = ifn_1183.Invoke_O__O(arg_1184) } else { and__1927000168__auto____3 = linked_1182.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1181, arg_1184) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1185 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = y__2; if linked_1186 == nil { tmp1 = ifn_1187.Invoke_O__O(arg_1188) } else { tmp1 = linked_1186.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1185, arg_1188) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var root_1189 any = A_arbace_j2g_edge_A_const_106.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = x__1; var arg_1193 any = y__2; if linked_1190 == nil { return ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { return linked_1190.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) } } else { return y__2 } }






func A_arbace_j2g_edge_coerce_const_A_New() *A_arbace_j2g_edge_coerce_const_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_coerce_const_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any {
	var tmp1 any; var root_1196 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = v__1; if linked_1197 == nil { tmp1 = ifn_1198.Invoke_O__O(arg_1199) } else { tmp1 = linked_1197.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1196, arg_1199) }; if jrt.J2g_Truth(tmp1) { var G__233000174__3_ any = desc__0
		switch lang.Util_Hash_O__I_NoInit(G__233000174__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_21) {
			return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :201:1
		case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_22) {
			return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :201:1
		case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_23) {

			return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__1)).Ref() }
//line :201:1
		case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_24) {

			return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__1)).Ref() }
//line :201:1
		case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_25) {
			return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__1)).Ref() }
//line :201:1
		case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_26) {
			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__1)).Ref() }
//line :201:1
		case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_27) {
			return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :201:1
		case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_28) {

			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(v__1)).Ref() }
//line :201:1
		default:}; return v__1 } else {
//line :200:1
			return nil
		}
}



func A_arbace_j2g_edge_ann_value_A_New() *A_arbace_j2g_edge_ann_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Ctor() {}
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1201 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = x__0; if linked_1202 == nil { and__1927000168__auto____2 = ifn_1203.Invoke_O__O(arg_1204) } else { and__1927000168__auto____2 = linked_1202.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1201, arg_1204) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1205 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); if linked_1206 == nil { and__1927000168__auto____3 = ifn_1207.Invoke_O__O(arg_1208) } else { and__1927000168__auto____3 = linked_1206.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1205, arg_1208) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1209 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); var arg_1213 any = A_arbace_j2g_edge_A_const_110; if linked_1210 == nil { tmp1 = ifn_1211.Invoke_O_O__O(arg_1212, arg_1213) } else { tmp1 = linked_1210.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1209, arg_1212, arg_1213) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_111; var tmp4 any = A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(x__0); var tmp5 *jrt.Class; var fncls__1230 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class; if fncls__1230 == nil { var fncls__1230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class = fncls__1230d; tmp5 = fncls__1230d } else { tmp5 = fncls__1230 }; return tmp2.Invoke_O_O_O__O(x__0, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } else {
//line :207:1
			var tmp6 any; var root_1231 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1233 lang.IFn

			if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = x__0; if linked_1232 == nil { tmp6 = ifn_1233.Invoke_O__O(arg_1234) } else { tmp6 = linked_1232.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1231, arg_1234) }
//line :207:1
			if jrt.J2g_Truth(tmp6) {

				var root_1235 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1239 any; var root_1240 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var tmp7 any = A_arbace_j2g_edge_ann_value_fn__233000180_A_New(); var tmp8 *jrt.Class; var fncls__1249 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class; if fncls__1249 == nil { var fncls__1249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class = fncls__1249d; tmp8 = fncls__1249d } else { tmp8 = fncls__1249 }; arg_1243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1244 any = x__0; if linked_1241 == nil { arg_1239 = ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { arg_1239 = linked_1241.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) }; if linked_1236 == nil { return ifn_1237.Invoke_O_O__O(arg_1238, arg_1239) } else { return linked_1236.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1235, arg_1238, arg_1239) } } else {
//line :207:1
					var tmp9 any; var root_1250 any = A_arbace_j2g_edge_A_const_115.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1252 lang.IFn


					if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = x__0; if linked_1251 == nil { tmp9 = ifn_1252.Invoke_O__O(arg_1253) } else { tmp9 = linked_1251.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1250, arg_1253) }
//line :207:1
					if jrt.J2g_Truth(tmp9) {


						var root_1254 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var arg_1258 any = x__0; if linked_1255 == nil { return ifn_1256.Invoke_O_O__O(arg_1257, arg_1258) } else { return linked_1255.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1254, arg_1257, arg_1258) } } else {
//line :207:1
							if A_arbace_j2g_edge_A_const_27 != nil { return x__0 } else { return nil } } } } }
func A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(p0 any) *A_arbace_j2g_edge_ann_value_fn__233000177_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000177_A{}; t.Ctor_O(p0); return t }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Invoke_O_O__O(self, p1__233000176_SHARP___1 any) any { var root_1220 any = A_arbace_j2g_edge_A_const_112.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, A_arbace_j2g_edge_coerce_const_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any; var root_1225 any = A_arbace_j2g_edge_A_const_13.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = t.F_x; var arg_1229 any = A_arbace_j2g_edge_A_const_113; if linked_1226 == nil { arg_1223 = ifn_1227.Invoke_O_O__O(arg_1228, arg_1229) } else { arg_1223 = linked_1226.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1225, arg_1228, arg_1229) }; var arg_1224 any = p1__233000176_SHARP___1; if linked_1221 == nil { return ifn_1222.Invoke_O_O__O(arg_1223, arg_1224) } else { return linked_1221.(*A_arbace_j2g_edge_coerce_const_A).Invoke_O_O_O__O(root_1220, arg_1223, arg_1224) } }
func A_arbace_j2g_edge_ann_value_fn__233000180_A_New() *A_arbace_j2g_edge_ann_value_fn__233000180_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000180_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Invoke_O_O__O(self, p__233000179__1 any) any { var vec__233000181__2 any = p__233000179__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000181__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000181__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1245 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = v__4; if linked_1246 == nil { tmp1 = ifn_1247.Invoke_O__O(arg_1248) } else { tmp1 = linked_1246.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1245, arg_1248) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }



func A_arbace_j2g_edge_info_value_A_New() *A_arbace_j2g_edge_info_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Ctor() {}
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Invoke_O_O__O(self, info__0 any) any { var n__2 any = A_arbace_j2g_edge_A_const_80.Invoke_O__O(info__0); var root_1259 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1261 lang.IFn; if









	linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any; var root_1265 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1267 lang.IFn; if /*line :220:1*/ linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any; var root_1271 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1273 lang.IFn; if /*line :219:1*/ linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = info__0; var arg_1275 any = A_arbace_j2g_edge_A_const_116; var arg_1276 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1272 == nil { arg_1268 = ifn_1273.Invoke_O_O_O__O(arg_1274, arg_1275, arg_1276) } else { arg_1268 = linked_1272.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1271, arg_1274, arg_1275, arg_1276) }; var arg_1269 any = A_arbace_j2g_edge_A_const_84; var arg_1270 any; var tmp1 any =
	A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(n__2); var tmp2 *jrt.Class; var fncls__1306 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class; if fncls__1306 == nil { var fncls__1306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class = fncls__1306d; tmp2 = fncls__1306d } else { tmp2 = fncls__1306 }; arg_1270 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1266 == nil { arg_1262 = ifn_1267.Invoke_O_O_O__O(arg_1268, arg_1269, arg_1270) } else { arg_1262 = linked_1266.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1265, arg_1268, arg_1269, arg_1270) }; var arg_1263 any = A_arbace_j2g_edge_A_const_86; var arg_1264 any; var tmp3 any =


	A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(n__2); var tmp4 *jrt.Class; var fncls__1373 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class; if fncls__1373 == nil { var fncls__1373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class = fncls__1373d; tmp4 = fncls__1373d } else { tmp4 = fncls__1373 }; arg_1264 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_1260 == nil { return ifn_1261.Invoke_O_O_O__O(arg_1262, arg_1263, arg_1264) } else { return linked_1260.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1259, arg_1262, arg_1263, arg_1264) } }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Invoke_O_O__O(self, fs__1 any) any { var root_1277 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any; var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(t.F_n); var tmp2 *jrt.Class; var fncls__1305 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class; if fncls__1305 == nil { var fncls__1305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class = fncls__1305d; tmp2 = fncls__1305d } else { tmp2 = fncls__1305 }; arg_1280 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1281 any = fs__1; if linked_1278 == nil { return ifn_1279.Invoke_O_O__O(arg_1280, arg_1281) } else { return linked_1278.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1277, arg_1280, arg_1281) } }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Invoke_O_O__O(self, p1__233000186_SHARP___1 any) any {
	var root_1282 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var root_1288 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1290 lang.IFn
//line :220:1
	if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any; var root_1294 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = p1__233000186_SHARP___1; var arg_1298 any = A_arbace_j2g_edge_A_const_85; var arg_1299 any = t.F_n; if linked_1295 == nil { arg_1291 = ifn_1296.Invoke_O_O_O__O(arg_1297, arg_1298, arg_1299) } else { arg_1291 = linked_1295.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1294, arg_1297, arg_1298, arg_1299) }; var arg_1292 any = A_arbace_j2g_edge_A_const_116; var arg_1293 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1289 == nil { arg_1285 = ifn_1290.Invoke_O_O_O__O(arg_1291, arg_1292, arg_1293) } else { arg_1285 = linked_1289.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1288, arg_1291, arg_1292, arg_1293) }
	var arg_1286 any = A_arbace_j2g_edge_A_const_60; var arg_1287 any; var root_1300 any = A_arbace_j2g_edge_A_const_112.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, A_arbace_j2g_edge_coerce_const_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = A_arbace_j2g_edge_A_const_81.Invoke_O__O(p1__233000186_SHARP___1); var arg_1304 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(p1__233000186_SHARP___1); if linked_1301 == nil { arg_1287 = ifn_1302.Invoke_O_O__O(arg_1303, arg_1304) } else { arg_1287 = linked_1301.(*A_arbace_j2g_edge_coerce_const_A).Invoke_O_O_O__O(root_1300, arg_1303, arg_1304) }; if linked_1283 == nil { return ifn_1284.Invoke_O_O_O__O(arg_1285, arg_1286, arg_1287) } else { return linked_1283.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1282, arg_1285, arg_1286, arg_1287)
	} }
func A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Invoke_O_O__O(self, ms__1 any) any {
	var root_1307 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(t.F_n); var tmp2 *jrt.Class; var fncls__1372 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class; if fncls__1372 == nil { var fncls__1372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class = fncls__1372d; tmp2 = fncls__1372d } else { tmp2 = fncls__1372 }; arg_1310 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1311 any = ms__1; if linked_1308 == nil { return ifn_1309.Invoke_O_O__O(arg_1310, arg_1311) } else { return linked_1308.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1307, arg_1310, arg_1311) } }
//line :224:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Invoke_O_O__O(self, m__1 any) any { var m__2 any; var root_1312 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1314 lang.IFn; if
													linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any; var root_1318 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any; var root_1324 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = m__1; var arg_1328 any = A_arbace_j2g_edge_A_const_85; var arg_1329 any = t.F_n; if linked_1325 == nil { arg_1321 = ifn_1326.Invoke_O_O_O__O(arg_1327, arg_1328, arg_1329) } else { arg_1321 = linked_1325.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1324, arg_1327, arg_1328, arg_1329) }; var arg_1322 any = A_arbace_j2g_edge_A_const_116; var arg_1323 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1319 == nil { arg_1315 = ifn_1320.Invoke_O_O_O__O(arg_1321, arg_1322, arg_1323) } else { arg_1315 = linked_1319.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1318, arg_1321, arg_1322, arg_1323) }; var arg_1316 any = A_arbace_j2g_edge_A_const_91; var arg_1317 any; var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New(); var tmp2 *jrt.Class; var fncls__1330 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class; if fncls__1330 == nil { var fncls__1330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class = fncls__1330d; tmp2 = fncls__1330d } else { tmp2 = fncls__1330 }; arg_1317 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1313 == nil { m__2 = ifn_1314.Invoke_O_O_O__O(arg_1315, arg_1316, arg_1317) } else { m__2 = linked_1313.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1312, arg_1315, arg_1316, arg_1317) }; if
													lang.Util_Equiv_O_O__Z_NoInit(Lit_64, A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__2)) { return m__2 } else { var a__3 any; var root_1331 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1333 lang.IFn

		if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any; var or__1927000174__auto____3 any = A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__2); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_1334 = or__1927000174__auto____3 } else { arg_1334 = lang.PersistentVector_EMPTY.Ref() }; if linked_1332 == nil { a__3 = ifn_1333.Invoke_O__O(arg_1334) } else { a__3 = linked_1332.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1331, arg_1334) }
//line :226:1
		var pa__4 any; var or__1927000174__auto____4 any; var G__233000196__4_ any = A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__2)


		if lang.Util_Identical_O_O__Z_NoInit(G__233000196__4_, nil) { or__1927000174__auto____4 = nil } else { var root_1335 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = G__233000196__4_; if linked_1336 == nil { or__1927000174__auto____4 = ifn_1337.Invoke_O__O(arg_1338) } else { or__1927000174__auto____4 = linked_1336.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1335, arg_1338) } }; if jrt.J2g_Truth(or__1927000174__auto____4) { pa__4 = or__1927000174__auto____4 } else {
			var root_1339 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any; var root_1343 any = A_arbace_j2g_edge_A_const_119.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any; var tmp3 any; var root_1348 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var root_1352 any = A_arbace_j2g_edge_A_const_120.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__2); if linked_1353 == nil { arg_1351 = ifn_1354.Invoke_O__O(arg_1355) } else { arg_1351 = linked_1353.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1352, arg_1355) }; if linked_1349 == nil { tmp3 = ifn_1350.Invoke_O__O(arg_1351) } else { tmp3 = linked_1349.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1348, arg_1351) }; arg_1346 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp3)).Ref(); var arg_1347 any = lang.PersistentVector_EMPTY.Ref(); if linked_1344 == nil { arg_1342 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { arg_1342 = linked_1344.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }; if linked_1340 == nil { pa__4 = ifn_1341.Invoke_O__O(arg_1342) } else { pa__4 = linked_1340.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1339, arg_1342) } }
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_92.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_edge_A_const_87; var tmp6 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(a__3); var tmp7 *jrt.Class; var fncls__1364 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class
		if fncls__1364 == nil { var fncls__1364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class = fncls__1364d; tmp7 = fncls__1364d } else { tmp7 = fncls__1364 }
//line :231:1
		var tmp8 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp9 any = A_arbace_j2g_edge_A_const_89; var tmp10 any; var root_1365 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1367 lang.IFn

		if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any; var tmp11 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New(); var tmp12 *jrt.Class; var fncls__1371 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class; if fncls__1371 == nil { var fncls__1371d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class = fncls__1371d; tmp12 = fncls__1371d } else { tmp12 = fncls__1371 }; arg_1368 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_1369 any = pa__4; if linked_1366 == nil { tmp10 = ifn_1367.Invoke_O_O__O(arg_1368, arg_1369) } else { tmp10 = linked_1366.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1365, arg_1368, arg_1369) }
//line :231:1
		return tmp4.Invoke_O_O_O_O_O__O(m__2, tmp5, tmp8, tmp9, tmp10) } }
//line :225:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Ctor() {}
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Invoke_O_O__O(self, p1__233000187_SHARP___1 any) any { var or__1927000174__auto____2 any = p1__233000187_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.PersistentVector_EMPTY.Ref() } }






func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Invoke_O__O(self any) any { var t_ any = t.F_a; t.F_a = nil; return t_ }
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Ctor() {}
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(x__1); var tmp2 *jrt.Class; var fncls__1370 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class; if fncls__1370 == nil { var fncls__1370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class = fncls__1370d; tmp2 = fncls__1370d } else { tmp2 = fncls__1370 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :233:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Invoke_O__O(self any) any { var t_ any = t.F_x; t.F_x = nil; return t_ }


func A_arbace_j2g_edge_generics_value_A_New() *A_arbace_j2g_edge_generics_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Ctor() {}
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Invoke_O_O__O(self, g__0 any) any {
	if jrt.J2g_Truth(g__0) {
		var root_1374 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = g__0; var arg_1378 any = A_arbace_j2g_edge_A_const_86; var arg_1379 any; var tmp1 any = A_arbace_j2g_edge_generics_value_fn__233000207_A_New(); var tmp2 *jrt.Class; var fncls__1392 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class; if fncls__1392 == nil { var fncls__1392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class = fncls__1392d; tmp2 = fncls__1392d } else { tmp2 = fncls__1392 }; arg_1379 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1375 == nil { return ifn_1376.Invoke_O_O_O__O(arg_1377, arg_1378, arg_1379) } else { return linked_1375.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1374, arg_1377, arg_1378, arg_1379) } } else {
//line :237:1
			return nil } }
func A_arbace_j2g_edge_generics_value_fn__233000207_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Invoke_O_O__O(self, ms__1 any) any { var root_1380 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any; var tmp1 any = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New(); var tmp2 *jrt.Class; var fncls__1391 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class; if fncls__1391 == nil { var fncls__1391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class = fncls__1391d; tmp2 = fncls__1391d } else { tmp2 = fncls__1391 }; arg_1383 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1384 any = ms__1; if linked_1381 == nil { return ifn_1382.Invoke_O_O__O(arg_1383, arg_1384) } else { return linked_1381.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1380, arg_1383, arg_1384) } }
//line :238:1
func A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Invoke_O_O__O(self, p1__233000206_SHARP___1 any) any { var root_1385 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = p1__233000206_SHARP___1; var arg_1389 any = A_arbace_j2g_edge_A_const_116; var arg_1390 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1386 == nil { return ifn_1387.Invoke_O_O_O__O(arg_1388, arg_1389, arg_1390) } else { return linked_1386.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1385, arg_1388, arg_1389, arg_1390) } }

func A_arbace_j2g_edge_canonical_A_New() *A_arbace_j2g_edge_canonical_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any {



	var tmp1 any; var root_1393 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any; var root_1398 any = A_arbace_j2g_edge_A_const_8.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = A_arbace_j2g_edge_A_const_121.GetRawRoot__O(); if linked_1399 == nil { arg_1396 = ifn_1400.Invoke_O__O(arg_1401) } else { arg_1396 = linked_1399.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1398, arg_1401) }; var arg_1397 any = n__0; if linked_1394 == nil { tmp1 = ifn_1395.Invoke_O_O__O(arg_1396, arg_1397) } else { tmp1 = linked_1394.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1393, arg_1396, arg_1397) }; if jrt.J2g_Truth(tmp1) { return facets__1 } else { var G__233000214__3_ any = facets__1; var G__233000214__4_ any

		if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1)) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_122; var tmp4 any = A_arbace_j2g_edge_canonical_fn__233000215_A_New(); var tmp5 *jrt.Class; var fncls__1417 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class; if fncls__1417 == nil { var fncls__1417d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class = fncls__1417d; tmp5 = fncls__1417d } else { tmp5 = fncls__1417 }; G__233000214__4_ = tmp2.Invoke_O_O_O__O(G__233000214__3_, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } else {
//line :246:1
				G__233000214__4_ = G__233000214__3_ }; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_124.Invoke_O__O(facets__1)) {

					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_edge_A_const_125; var tmp8 any = A_arbace_j2g_edge_canonical_fn__233000217_A_New(); var tmp9 *jrt.Class; var fncls__1433 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class; if fncls__1433 == nil { var fncls__1433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class = fncls__1433d; tmp9 = fncls__1433d } else { tmp9 = fncls__1433 }; return tmp6.Invoke_O_O_O__O(G__233000214__4_, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else {
//line :246:1
						return G__233000214__4_ } } }
func A_arbace_j2g_edge_canonical_fn__233000215_A_New() *A_arbace_j2g_edge_canonical_fn__233000215_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000215_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Ctor() {}
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Invoke_O_O__O(self, p1__233000212_SHARP___1 any) any { var root_1408 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var root_1412 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = A_arbace_j2g_edge_A_const_123.GetRawRoot__O(); var arg_1416 any = p1__233000212_SHARP___1; if linked_1413 == nil { arg_1411 = ifn_1414.Invoke_O_O__O(arg_1415, arg_1416) } else { arg_1411 = linked_1413.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1412, arg_1415, arg_1416) }; if linked_1409 == nil { return ifn_1410.Invoke_O__O(arg_1411) } else { return linked_1409.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1408, arg_1411) } }
func A_arbace_j2g_edge_canonical_fn__233000217_A_New() *A_arbace_j2g_edge_canonical_fn__233000217_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000217_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Ctor() {}
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Invoke_O_O__O(self, p1__233000213_SHARP___1 any) any { var root_1424 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any; var root_1428 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = A_arbace_j2g_edge_A_const_123.GetRawRoot__O(); var arg_1432 any = p1__233000213_SHARP___1; if linked_1429 == nil { arg_1427 = ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { arg_1427 = linked_1429.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; if linked_1425 == nil { return ifn_1426.Invoke_O__O(arg_1427) } else { return linked_1425.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1424, arg_1427) } }

func A_arbace_j2g_edge_read_edge_A_New() *A_arbace_j2g_edge_read_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) DoInvoke_O_O_O__O(self, f__0, more__1 any) any { var rd__3 any; var tmp1 any = A_arbace_j2g_edge_read_edge_rd__233000220_A_New(); var tmp2 *jrt.Class; var fncls__1454 *jrt.Class = A_arbace_j2g_edge_read_edge_rd__233000220_A_fn_class; if




	fncls__1454 == nil { var fncls__1454d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_j2g_edge_read_edge_rd__233000220_A_fn_class = fncls__1454d; tmp2 = fncls__1454d } else { tmp2 = fncls__1454 }; rd__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var e__4 any; var tmp3 any; var root_1455 any = /*line :250:1*/A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1457 lang.IFn; if





	linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = more__1; if linked_1456 == nil { tmp3 = ifn_1457.Invoke_O__O(arg_1458) } else { tmp3 = linked_1456.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1455, arg_1458) }; if jrt.J2g_Truth(tmp3) { var root_1459 any = A_arbace_j2g_edge_A_const_128.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, A_arbace_j2g_edge_merge_edges_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any; var root_1463 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = rd__3; var arg_1467 any; var root_1468 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = f__0; var arg_1472 any = more__1; if linked_1469 == nil { arg_1467 = ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { arg_1467 = linked_1469.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) }; if linked_1464 == nil { arg_1462 = ifn_1465.Invoke_O_O__O(arg_1466, arg_1467) } else { arg_1462 = linked_1464.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1463, arg_1466, arg_1467) }; if linked_1460 == nil { e__4 = ifn_1461.Invoke_O__O(arg_1462) } else { e__4 = linked_1460.(*A_arbace_j2g_edge_merge_edges_A).Invoke_O_O__O(root_1459, arg_1462) } } else { e__4 = lang.IFn_Cast(rd__3).Invoke_O__O(f__0) }; var root_1473 any =
	A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = e__4; var arg_1477 any = A_arbace_j2g_edge_A_const_99; var arg_1478 any; var tmp4 any = A_arbace_j2g_edge_read_edge_fn__233000222_A_New(); var tmp5 *jrt.Class; var fncls__1577 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class; if
	fncls__1577 == nil { var fncls__1577d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class = fncls__1577d; tmp5 = fncls__1577d } else { tmp5 = fncls__1577 }; arg_1478 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if /*line :257:1*/ linked_1474 == nil { return ifn_1475.Invoke_O_O_O__O(arg_1476, arg_1477, arg_1478) } else { return linked_1474.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1473, arg_1476, arg_1477, arg_1478) } }
//line :255:1
func A_arbace_j2g_edge_read_edge_rd__233000220_A_New() *A_arbace_j2g_edge_read_edge_rd__233000220_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_rd__233000220_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_rd__233000220_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_rd__233000220_A) Invoke_O_O__O(self, f__1 any) any { var root_1445 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_127, jrt.Boolean_FALSE.Ref()); if linked_1446 == nil { ifn_1447.Invoke_O__O(arg_1448) } else { linked_1446.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1445, arg_1448) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1434 any = A_arbace_j2g_edge_A_const_126.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()).Invoke_O__O(f__1); if linked_1435 == nil { tmp1 = ifn_1436.Invoke_O__O(arg_1437) } else { tmp1 = linked_1435.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1434, arg_1437) } }; return nil }(); var root_1442 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; if linked_1443 == nil { ifn_1444.Invoke__O() } else { linked_1443.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1442) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }


func A_arbace_j2g_edge_read_edge_fn__233000222_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Ctor() {}
//line :258:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Invoke_O_O__O(self, cs__1 any) any {
	var root_1479 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1483 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New(); var tmp2 *jrt.Class; var fncls__1576 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class; if fncls__1576 == nil { var fncls__1576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class = fncls__1576d; tmp2 = fncls__1576d } else { tmp2 = fncls__1576 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1483 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); if linked_1480 == nil { return ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { return linked_1480.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) } }
//line :259:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Ctor() {}
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Invoke_O_O__O(self, s__233000224__1 any) any { var tmp1 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(s__233000224__1, self); var tmp2 *jrt.Class; var fncls__1575 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class; if fncls__1575 == nil { var fncls__1575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class = fncls__1575d; tmp2 = fncls__1575d } else { tmp2 = fncls__1575 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :259:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Ctor_O_O(c__s__233000224, c__iter__233000223 any) { t.F_s__233000224 = c__s__233000224; t.F_iter__233000223 = c__iter__233000223 }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Invoke_O__O(self any) any { { var s__233000224__1 any; var t_ any = t.F_s__233000224; t.F_s__233000224 = nil; s__233000224__1 = t_; for { var temp__1927000414__auto____2 any; var root_1484 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = s__233000224__1; if linked_1485 == nil { temp__1927000414__auto____2 = ifn_1486.Invoke_O__O(arg_1487) } else { temp__1927000414__auto____2 = linked_1485.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1484, arg_1487) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000224__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1488 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = s__233000224__3; if linked_1489 == nil { tmp1 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp1 = linked_1489.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1488, arg_1491) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1492 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = s__233000224__3; if linked_1493 == nil { c__1927001037__auto____4 = ifn_1494.Invoke_O__O(arg_1495) } else { c__1927001037__auto____4 = linked_1493.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1492, arg_1495) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000226__6 any; var root_1496 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1497 == nil { b__233000226__6 = ifn_1498.Invoke_O__O(arg_1499) } else { b__233000226__6 = linked_1497.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1496, arg_1499) }; var tmp2 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(b__233000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1522 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class; if fncls__1522 == nil { var fncls__1522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class = fncls__1522d; tmp3 = fncls__1522d } else { tmp3 = fncls__1522 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1523 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any; var root_1528 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = b__233000226__6; if linked_1529 == nil { arg_1526 = ifn_1530.Invoke_O__O(arg_1531) } else { arg_1526 = linked_1529.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1528, arg_1531) }; var arg_1527 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); var tmp5 any; var root_1532 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = s__233000224__3; if linked_1533 == nil { tmp5 = ifn_1534.Invoke_O__O(arg_1535) } else { tmp5 = linked_1533.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1532, arg_1535) }; arg_1527 = tmp4.Invoke_O__O(tmp5); if linked_1524 == nil { return ifn_1525.Invoke_O_O__O(arg_1526, arg_1527) } else { return linked_1524.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1523, arg_1526, arg_1527) } } else { var root_1536 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any; var root_1541 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = b__233000226__6; if linked_1542 == nil { arg_1539 = ifn_1543.Invoke_O__O(arg_1544) } else { arg_1539 = linked_1542.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1541, arg_1544) }; var arg_1540 any; if linked_1537 == nil { return ifn_1538.Invoke_O_O__O(arg_1539, arg_1540) } else { return linked_1537.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1536, arg_1539, arg_1540) } } } else { var vec__233000235__4 any; var root_1545 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = s__233000224__3; if linked_1546 == nil { vec__233000235__4 = ifn_1547.Invoke_O__O(arg_1548) } else { vec__233000235__4 = linked_1546.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1545, arg_1548) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000235__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000235__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1549 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any; var tmp6 any; var G__233000238__7_ any = facets__6; var G__233000238__8_ any
																if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var root_1554 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = G__233000238__7_; var arg_1558 any = A_arbace_j2g_edge_A_const_94; var arg_1559 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1555 == nil { G__233000238__8_ = ifn_1556.Invoke_O_O_O__O(arg_1557, arg_1558, arg_1559) } else { G__233000238__8_ = linked_1555.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1554, arg_1557, arg_1558, arg_1559) } } else {
//line :260:1
			G__233000238__8_ = G__233000238__7_ }; var tmp7 any; var root_1560 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1562 lang.IFn

	if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = facets__6; var arg_1564 any = A_arbace_j2g_edge_A_const_124; if linked_1561 == nil { tmp7 = ifn_1562.Invoke_O_O__O(arg_1563, arg_1564) } else { tmp7 = linked_1561.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1560, arg_1563, arg_1564) }
//line :260:1
	if jrt.J2g_Truth(tmp7) {

		var root_1565 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = G__233000238__8_; var arg_1569 any = A_arbace_j2g_edge_A_const_124; var arg_1570 any = A_arbace_j2g_edge_A_const_130.GetRawRoot__O(); if linked_1566 == nil { tmp6 = ifn_1567.Invoke_O_O_O__O(arg_1568, arg_1569, arg_1570) } else { tmp6 = linked_1566.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1565, arg_1568, arg_1569, arg_1570) } } else {
//line :260:1
			tmp6 = G__233000238__8_ }
//line :259:1
	arg_1552 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_1553 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); var tmp9 any; var root_1571 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = s__233000224__3; if linked_1572 == nil { tmp9 = ifn_1573.Invoke_O__O(arg_1574) } else { tmp9 = linked_1572.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1571, arg_1574) }; arg_1553 = tmp8.Invoke_O__O(tmp9); if linked_1550 == nil { return ifn_1551.Invoke_O_O__O(arg_1552, arg_1553) } else { return linked_1550.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1549, arg_1552, arg_1553) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :259:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Ctor_O_I_O(c__b__233000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000226 = c__b__233000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Invoke_O__O(self any) any { { var i__233000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000230__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000225__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000230__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000230__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1500 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = t.F_b__233000226; var arg_1504 any; var tmp2 any; var G__233000233__5_ any = facets__4; var G__233000233__6_ any
																	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																		var root_1505 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = G__233000233__5_; var arg_1509 any = A_arbace_j2g_edge_A_const_94; var arg_1510 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1506 == nil { G__233000233__6_ = ifn_1507.Invoke_O_O_O__O(arg_1508, arg_1509, arg_1510) } else { G__233000233__6_ = linked_1506.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1505, arg_1508, arg_1509, arg_1510) } } else {
//line :260:1
			G__233000233__6_ = G__233000233__5_ }; var tmp3 any; var root_1511 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1513 lang.IFn

	if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = facets__4; var arg_1515 any = A_arbace_j2g_edge_A_const_124; if linked_1512 == nil { tmp3 = ifn_1513.Invoke_O_O__O(arg_1514, arg_1515) } else { tmp3 = linked_1512.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1511, arg_1514, arg_1515) }
//line :260:1
	if jrt.J2g_Truth(tmp3) {

		var root_1516 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = G__233000233__6_; var arg_1520 any = A_arbace_j2g_edge_A_const_124; var arg_1521 any = A_arbace_j2g_edge_A_const_130.GetRawRoot__O(); if linked_1517 == nil { tmp2 = ifn_1518.Invoke_O_O_O__O(arg_1519, arg_1520, arg_1521) } else { tmp2 = linked_1517.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1516, arg_1519, arg_1520, arg_1521) } } else {
//line :260:1
			tmp2 = G__233000233__6_ }
//line :259:1
	arg_1504 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_1501 == nil { ifn_1502.Invoke_O_O__O(arg_1503, arg_1504) } else { linked_1501.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1500, arg_1503, arg_1504) }; i__233000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000225__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_read_edge_data_A_New() *A_arbace_j2g_edge_read_edge_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Ctor() {}
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var root_1693 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1695 lang.IFn; if


	linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_127, jrt.Boolean_FALSE.Ref()); if linked_1694 == nil { ifn_1695.Invoke_O__O(arg_1696) } else { linked_1694.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1693, arg_1696) }; var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__1589 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class; if fncls__1589 == nil { var fncls__1589d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class = fncls__1589d; tmp2 = fncls__1589d } else { tmp2 = fncls__1589 }; e__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var root_1590 any =
	A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = e__2; var arg_1594 any = A_arbace_j2g_edge_A_const_99; var arg_1595 any; var tmp3 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New(); var tmp4 *jrt.Class; var fncls__1692 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class; if
	fncls__1692 == nil { var fncls__1692d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class = fncls__1692d; tmp4 = fncls__1692d } else { tmp4 = fncls__1692 }; arg_1595 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if /*line :268:1*/ linked_1591 == nil { return ifn_1592.Invoke_O_O_O__O(arg_1593, arg_1594, arg_1595) } else { return linked_1591.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1590, arg_1593, arg_1594, arg_1595) } }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(p0 any) *A_arbace_j2g_edge_read_edge_data_fn__233000243_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000243_A{}; t.Ctor_O(p0); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1578 any = A_arbace_j2g_edge_A_const_126.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; arg_1581 = tmp2.Invoke_O__O(tmp3); if linked_1579 == nil { tmp1 = ifn_1580.Invoke_O__O(arg_1581) } else { tmp1 = linked_1579.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1578, arg_1581) } }; return nil }(); var root_1586 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; if linked_1587 == nil { ifn_1588.Invoke__O() } else { linked_1587.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1586) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Invoke_O_O__O(self, cs__1 any) any {
	var root_1596 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1600 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New(); var tmp2 *jrt.Class; var fncls__1691 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class; if fncls__1691 == nil { var fncls__1691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class = fncls__1691d; tmp2 = fncls__1691d } else { tmp2 = fncls__1691 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1600 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); if linked_1597 == nil { return ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { return linked_1597.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) } }
//line :270:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Ctor() {}
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Invoke_O_O__O(self, s__233000247__1 any) any { var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(s__233000247__1, self); var tmp2 *jrt.Class; var fncls__1690 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class; if fncls__1690 == nil { var fncls__1690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class = fncls__1690d; tmp2 = fncls__1690d } else { tmp2 = fncls__1690 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :270:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Ctor_O_O(c__s__233000247, c__iter__233000246 any) { t.F_s__233000247 = c__s__233000247; t.F_iter__233000246 = c__iter__233000246 }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Invoke_O__O(self any) any { { var s__233000247__1 any; var t_ any = t.F_s__233000247; t.F_s__233000247 = nil; s__233000247__1 = t_; for { var temp__1927000414__auto____2 any; var root_1601 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = s__233000247__1; if linked_1602 == nil { temp__1927000414__auto____2 = ifn_1603.Invoke_O__O(arg_1604) } else { temp__1927000414__auto____2 = linked_1602.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1601, arg_1604) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000247__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1605 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = s__233000247__3; if linked_1606 == nil { tmp1 = ifn_1607.Invoke_O__O(arg_1608) } else { tmp1 = linked_1606.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1605, arg_1608) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1609 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = s__233000247__3; if linked_1610 == nil { c__1927001037__auto____4 = ifn_1611.Invoke_O__O(arg_1612) } else { c__1927001037__auto____4 = linked_1610.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1609, arg_1612) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000249__6 any; var root_1613 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1614 == nil { b__233000249__6 = ifn_1615.Invoke_O__O(arg_1616) } else { b__233000249__6 = linked_1614.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1613, arg_1616) }; var tmp2 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(b__233000249__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1638 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class; if fncls__1638 == nil { var fncls__1638d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class = fncls__1638d; tmp3 = fncls__1638d } else { tmp3 = fncls__1638 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1639 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any; var root_1644 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = b__233000249__6; if linked_1645 == nil { arg_1642 = ifn_1646.Invoke_O__O(arg_1647) } else { arg_1642 = linked_1645.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1644, arg_1647) }; var arg_1643 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); var tmp5 any; var root_1648 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = s__233000247__3; if linked_1649 == nil { tmp5 = ifn_1650.Invoke_O__O(arg_1651) } else { tmp5 = linked_1649.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1648, arg_1651) }; arg_1643 = tmp4.Invoke_O__O(tmp5); if linked_1640 == nil { return ifn_1641.Invoke_O_O__O(arg_1642, arg_1643) } else { return linked_1640.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1639, arg_1642, arg_1643) } } else { var root_1652 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any; var root_1657 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = b__233000249__6; if linked_1658 == nil { arg_1655 = ifn_1659.Invoke_O__O(arg_1660) } else { arg_1655 = linked_1658.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1657, arg_1660) }; var arg_1656 any; if linked_1653 == nil { return ifn_1654.Invoke_O_O__O(arg_1655, arg_1656) } else { return linked_1653.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1652, arg_1655, arg_1656) } } } else { var vec__233000258__4 any; var root_1661 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = s__233000247__3; if linked_1662 == nil { vec__233000258__4 = ifn_1663.Invoke_O__O(arg_1664) } else { vec__233000258__4 = linked_1662.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1661, arg_1664) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000258__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000258__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1665 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any; var tmp6 any; var root_1670 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1672 lang.IFn
																if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = n__5; var arg_1674 any; var G__233000261__7_ any = facets__6; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var root_1675 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = G__233000261__7_; var arg_1679 any = A_arbace_j2g_edge_A_const_94; var arg_1680 any; var root_1681 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var arg_1685 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1682 == nil { arg_1680 = ifn_1683.Invoke_O_O__O(arg_1684, arg_1685) } else { arg_1680 = linked_1682.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1681, arg_1684, arg_1685) }; if linked_1676 == nil { arg_1674 = ifn_1677.Invoke_O_O_O__O(arg_1678, arg_1679, arg_1680) } else { arg_1674 = linked_1676.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1675, arg_1678, arg_1679, arg_1680) } } else {
//line :271:1
			arg_1674 = G__233000261__7_ }; if linked_1671 == nil { tmp6 = ifn_1672.Invoke_O_O__O(arg_1673, arg_1674) } else { tmp6 = linked_1671.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1670, arg_1673, arg_1674) }
//line :270:1
	arg_1668 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_1669 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); var tmp8 any; var root_1686 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = s__233000247__3; if linked_1687 == nil { tmp8 = ifn_1688.Invoke_O__O(arg_1689) } else { tmp8 = linked_1687.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1686, arg_1689) }; arg_1669 = tmp7.Invoke_O__O(tmp8); if linked_1666 == nil { return ifn_1667.Invoke_O_O__O(arg_1668, arg_1669) } else { return linked_1666.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1665, arg_1668, arg_1669) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :270:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Ctor_O_I_O(c__b__233000249 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000249 = c__b__233000249; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Invoke_O__O(self any) any { { var i__233000248__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000248__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000253__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000248__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000253__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000253__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1617 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = t.F_b__233000249; var arg_1621 any; var tmp2 any; var root_1622 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1624 lang.IFn
																		if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = n__3; var arg_1626 any; var G__233000256__5_ any = facets__4; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																			var root_1627 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = G__233000256__5_; var arg_1631 any = A_arbace_j2g_edge_A_const_94; var arg_1632 any; var root_1633 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var arg_1637 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1634 == nil { arg_1632 = ifn_1635.Invoke_O_O__O(arg_1636, arg_1637) } else { arg_1632 = linked_1634.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1633, arg_1636, arg_1637) }; if linked_1628 == nil { arg_1626 = ifn_1629.Invoke_O_O_O__O(arg_1630, arg_1631, arg_1632) } else { arg_1626 = linked_1628.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1627, arg_1630, arg_1631, arg_1632) } } else {
//line :271:1
			arg_1626 = G__233000256__5_ }; if linked_1623 == nil { tmp2 = ifn_1624.Invoke_O_O__O(arg_1625, arg_1626) } else { tmp2 = linked_1623.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1622, arg_1625, arg_1626) }
//line :270:1
	arg_1621 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_1618 == nil { ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { linked_1618.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1617, arg_1620, arg_1621) }; i__233000248__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000248__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_edge_write_edge_BANG__A_New() *A_arbace_j2g_edge_write_edge_BANG__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_write_edge_BANG__A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Ctor() {}
//line :274:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Invoke_O_O_O__O(self, f__0, edge__1 any) any {
	lang.IFn_Cast(A_arbace_j2g_edge_A_const_133.GetRawRoot__O()).Invoke_O__O(f__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_131.GetRawRoot__O()); var tmp2 any; var root_1707 any = A_arbace_j2g_edge_A_const_132.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, A_arbace_j2g_edge_edge_text_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = edge__1; if linked_1708 == nil { tmp2 = ifn_1709.Invoke_O__O(arg_1710) } else { tmp2 = linked_1708.(*A_arbace_j2g_edge_edge_text_A).Invoke_O_O__O(root_1707, arg_1710) }; return tmp1.Invoke_O_O__O(f__0, tmp2)
}
func A_arbace_j2g_edge_subtract_edge_A_New() *A_arbace_j2g_edge_subtract_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_j2g_edge_subtract_edge_A) Ctor() {}
//line :278:1
func (t *A_arbace_j2g_edge_subtract_edge_A) Invoke_O_O_O__O(self, e__0, base__1 any) any {




	var root_1715 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1719 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_New_O(base__1); var tmp2 *jrt.Class; var fncls__1884 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_fn_class; if fncls__1884 == nil { var fncls__1884d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_fn_class = fncls__1884d; tmp2 = fncls__1884d } else { tmp2 = fncls__1884 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1719 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(e__0); if linked_1716 == nil { return ifn_1717.Invoke_O_O__O(arg_1718, arg_1719) } else { return linked_1716.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1715, arg_1718, arg_1719) } }
//line :283:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A{}; t.Ctor_O(p0); return t }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A) Invoke_O_O__O(self, s__233000269__1 any) any { var tmp1 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_New_O_O_O(s__233000269__1, t.F_base, self); var tmp2 *jrt.Class; var fncls__1883 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_fn_class; if fncls__1883 == nil { var fncls__1883d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_fn_class = fncls__1883d; tmp2 = fncls__1883d } else { tmp2 = fncls__1883 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :283:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A) Ctor_O_O_O(c__s__233000269, c__base, c__iter__233000268 any) { t.F_s__233000269 = c__s__233000269; t.F_base = c__base; t.F_iter__233000268 = c__iter__233000268 }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A) Invoke_O__O(self any) any { { var s__233000269__1 any; var t_ any = t.F_s__233000269; t.F_s__233000269 = nil; s__233000269__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1720 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = s__233000269__1; if linked_1721 == nil { temp__1927000414__auto____2 = ifn_1722.Invoke_O__O(arg_1723) } else { temp__1927000414__auto____2 = linked_1721.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1720, arg_1723) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000269__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1724 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = s__233000269__3; if linked_1725 == nil { tmp1 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp1 = linked_1725.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1724, arg_1727) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1728 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = s__233000269__3; if linked_1729 == nil { c__1927001037__auto____4 = ifn_1730.Invoke_O__O(arg_1731) } else { c__1927001037__auto____4 = linked_1729.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1728, arg_1731) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000271__6 any; var root_1732 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1733 == nil { b__233000271__6 = ifn_1734.Invoke_O__O(arg_1735) } else { b__233000271__6 = linked_1733.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1732, arg_1735) }; var tmp2 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_New_O_O_I_O(b__233000271__6, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1792 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_fn_class; if fncls__1792 == nil { var fncls__1792d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_fn_class = fncls__1792d; tmp3 = fncls__1792d } else { tmp3 = fncls__1792 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1793 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any; var root_1798 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = b__233000271__6; if linked_1799 == nil { arg_1796 = ifn_1800.Invoke_O__O(arg_1801) } else { arg_1796 = linked_1799.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1798, arg_1801) }; var arg_1797 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000268); var tmp5 any; var root_1802 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = s__233000269__3; if linked_1803 == nil { tmp5 = ifn_1804.Invoke_O__O(arg_1805) } else { tmp5 = linked_1803.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1802, arg_1805) }; arg_1797 = tmp4.Invoke_O__O(tmp5); if linked_1794 == nil { return ifn_1795.Invoke_O_O__O(arg_1796, arg_1797) } else { return linked_1794.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1793, arg_1796, arg_1797) } } else { var root_1806 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1808 lang.IFn; if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any; var root_1811 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = b__233000271__6; if linked_1812 == nil { arg_1809 = ifn_1813.Invoke_O__O(arg_1814) } else { arg_1809 = linked_1812.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1811, arg_1814) }; var arg_1810 any; if linked_1807 == nil { return ifn_1808.Invoke_O_O__O(arg_1809, arg_1810) } else { return linked_1807.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1806, arg_1809, arg_1810) } } } else { var vec__233000287__4 any; var root_1815 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = s__233000269__3; if linked_1816 == nil { vec__233000287__4 = ifn_1817.Invoke_O__O(arg_1818) } else { vec__233000287__4 = linked_1816.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1815, arg_1818) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000287__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000287__4, lang.RT_IntCast_J__I_NoInit(1), nil); var b__7 any = lang.RT_Get_O_O__O_NoInit(t.F_base, k__5); var d__8 any; var tmp6 any; var root_1819 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1821 lang.IFn

	if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = v__6; if linked_1820 == nil { tmp6 = ifn_1821.Invoke_O__O(arg_1822) } else { tmp6 = linked_1820.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1819, arg_1822) }; if jrt.J2g_Truth(tmp6) { var root_1823 any = A_arbace_j2g_edge_A_const_134.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any; var root_1827 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any; var tmp7 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_New_O(b__7); var tmp8 *jrt.Class; var fncls__1837 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_fn_class; if fncls__1837 == nil { var fncls__1837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_fn_class = fncls__1837d; tmp8 = fncls__1837d } else { tmp8 = fncls__1837 }; arg_1830 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1831 any = v__6; if linked_1828 == nil { arg_1826 = ifn_1829.Invoke_O_O__O(arg_1830, arg_1831) } else { arg_1826 = linked_1828.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1827, arg_1830, arg_1831) }; if linked_1824 == nil { d__8 = ifn_1825.Invoke_O__O(arg_1826) } else { d__8 = linked_1824.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1823, arg_1826) } } else { var tmp9 any; var root_1838 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1840 lang.IFn
		if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = v__6; if linked_1839 == nil { tmp9 = ifn_1840.Invoke_O__O(arg_1841) } else { tmp9 = linked_1839.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1838, arg_1841) }
//line :285:1
		if jrt.J2g_Truth(tmp9) {
			var root_1842 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1846 any; var root_1847 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any; var tmp10 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_New_O(b__7); var tmp11 *jrt.Class; var fncls__1852 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_fn_class; if fncls__1852 == nil { var fncls__1852d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_fn_class = fncls__1852d; tmp11 = fncls__1852d } else { tmp11 = fncls__1852 }; arg_1850 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1851 any = v__6; if linked_1848 == nil { arg_1846 = ifn_1849.Invoke_O_O__O(arg_1850, arg_1851) } else { arg_1846 = linked_1848.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1847, arg_1850, arg_1851) }; if linked_1843 == nil { d__8 = ifn_1844.Invoke_O_O__O(arg_1845, arg_1846) } else { d__8 = linked_1843.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1842, arg_1845, arg_1846) } } else {
//line :285:1
				if A_arbace_j2g_edge_A_const_27 != nil {

					var tmp12 any; var root_1853 any = A_arbace_j2g_edge_A_const_135.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = v__6; var arg_1857 any = b__7; if linked_1854 == nil { tmp12 = ifn_1855.Invoke_O_O__O(arg_1856, arg_1857) } else { tmp12 = linked_1854.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1853, arg_1856, arg_1857) }; if jrt.J2g_Truth(tmp12) { d__8 = v__6 } else { d__8 = nil } } else {
//line :285:1
						d__8 = nil } } }
//line :283:1
	var tmp13 any; var tmp14 any; var root_1858 any = A_arbace_j2g_edge_A_const_136.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, aot_arbace_core.A_arbace_core_coll_QMARK__A_fn_class); var ifn_1860 lang.IFn




	if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = d__8; if linked_1859 == nil { tmp14 = ifn_1860.Invoke_O__O(arg_1861) } else { tmp14 = linked_1859.(*aot_arbace_core.A_arbace_core_coll_QMARK__A).Invoke_O_O__O(root_1858, arg_1861) }; if jrt.J2g_Truth(tmp14) { var root_1862 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = d__8; if linked_1863 == nil { tmp13 = ifn_1864.Invoke_O__O(arg_1865) } else { tmp13 = linked_1863.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1862, arg_1865) } } else { var root_1866 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1868 lang.IFn; if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = d__8; if linked_1867 == nil { tmp13 = ifn_1868.Invoke_O__O(arg_1869) } else { tmp13 = linked_1867.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1866, arg_1869) } }
//line :283:1
	if jrt.J2g_Truth(tmp13) { var root_1870 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, d__8); var arg_1874 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__233000268); var tmp16 any; var root_1875 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = s__233000269__3; if linked_1876 == nil { tmp16 = ifn_1877.Invoke_O__O(arg_1878) } else { tmp16 = linked_1876.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1875, arg_1878) }; arg_1874 = tmp15.Invoke_O__O(tmp16); if linked_1871 == nil { return ifn_1872.Invoke_O_O__O(arg_1873, arg_1874) } else { return linked_1871.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1870, arg_1873, arg_1874) } } else { var tmp17 any; var root_1879 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = s__233000269__3; if linked_1880 == nil { tmp17 = ifn_1881.Invoke_O__O(arg_1882) } else { tmp17 = linked_1880.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1879, arg_1882) }; s__233000269__1 = tmp17; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :283:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A) Ctor_O_O_I_O(c__b__233000271, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000271 = c__b__233000271; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A) Invoke_O__O(self any) any { { var i__233000270__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000275__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000270__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000275__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000275__2, lang.RT_IntCast_J__I_NoInit(1), nil); var b__5 any = lang.RT_Get_O_O__O_NoInit(t.F_base, k__3); var d__6 any; var tmp2 any; var root_1736 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1738 lang.IFn

	if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = v__4; if linked_1737 == nil { tmp2 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp2 = linked_1737.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1736, arg_1739) }; if jrt.J2g_Truth(tmp2) { var root_1740 any = A_arbace_j2g_edge_A_const_134.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any; var root_1744 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any; var tmp3 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_New_O(b__5); var tmp4 *jrt.Class; var fncls__1754 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_fn_class; if fncls__1754 == nil { var fncls__1754d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_fn_class = fncls__1754d; tmp4 = fncls__1754d } else { tmp4 = fncls__1754 }; arg_1747 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1748 any = v__4; if linked_1745 == nil { arg_1743 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { arg_1743 = linked_1745.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; if linked_1741 == nil { d__6 = ifn_1742.Invoke_O__O(arg_1743) } else { d__6 = linked_1741.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1740, arg_1743) } } else { var tmp5 any; var root_1755 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1757 lang.IFn
		if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = v__4; if linked_1756 == nil { tmp5 = ifn_1757.Invoke_O__O(arg_1758) } else { tmp5 = linked_1756.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1755, arg_1758) }
//line :285:1
		if jrt.J2g_Truth(tmp5) {
			var root_1759 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1763 any; var root_1764 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any; var tmp6 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_New_O(b__5); var tmp7 *jrt.Class; var fncls__1769 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_fn_class; if fncls__1769 == nil { var fncls__1769d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_fn_class = fncls__1769d; tmp7 = fncls__1769d } else { tmp7 = fncls__1769 }; arg_1767 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1768 any = v__4; if linked_1765 == nil { arg_1763 = ifn_1766.Invoke_O_O__O(arg_1767, arg_1768) } else { arg_1763 = linked_1765.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1764, arg_1767, arg_1768) }; if linked_1760 == nil { d__6 = ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { d__6 = linked_1760.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) } } else {
//line :285:1
				if A_arbace_j2g_edge_A_const_27 != nil {

					var tmp8 any; var root_1770 any = A_arbace_j2g_edge_A_const_135.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = v__4; var arg_1774 any = b__5; if linked_1771 == nil { tmp8 = ifn_1772.Invoke_O_O__O(arg_1773, arg_1774) } else { tmp8 = linked_1771.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1770, arg_1773, arg_1774) }; if jrt.J2g_Truth(tmp8) { d__6 = v__4 } else { d__6 = nil } } else {
//line :285:1
						d__6 = nil } } }
//line :283:1
	var tmp9 any; var tmp10 any; var root_1775 any = A_arbace_j2g_edge_A_const_136.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_coll_QMARK__A_fn_class); var ifn_1777 lang.IFn




	if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = d__6; if linked_1776 == nil { tmp10 = ifn_1777.Invoke_O__O(arg_1778) } else { tmp10 = linked_1776.(*aot_arbace_core.A_arbace_core_coll_QMARK__A).Invoke_O_O__O(root_1775, arg_1778) }; if jrt.J2g_Truth(tmp10) { var root_1779 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = d__6; if linked_1780 == nil { tmp9 = ifn_1781.Invoke_O__O(arg_1782) } else { tmp9 = linked_1780.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1779, arg_1782) } } else { var root_1783 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = d__6; if linked_1784 == nil { tmp9 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp9 = linked_1784.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1783, arg_1786) } }
//line :283:1
	if jrt.J2g_Truth(tmp9) { var root_1787 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = t.F_b__233000271; var arg_1791 any = lang.Tuple_Create_O_O__IPersistentVector(k__3, d__6); if linked_1788 == nil { ifn_1789.Invoke_O_O__O(arg_1790, arg_1791) } else { linked_1788.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1787, arg_1790, arg_1791) }; i__233000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000270__1); continue L1 } else { i__233000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000270__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A) Invoke_O_O__O(self, p1__233000267_SHARP___1 any) any { var root_1749 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any; var or__1927000174__auto____2 any = t.F_b; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_1752 = or__1927000174__auto____2 } else { arg_1752 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_1753 any = p1__233000267_SHARP___1; if linked_1750 == nil { return ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { return linked_1750.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) } }
//line :285:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A) Invoke_O_O__O(self, p1__233000267_SHARP___1 any) any { var root_1832 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any; var or__1927000174__auto____2 any = t.F_b; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_1835 = or__1927000174__auto____2 } else { arg_1835 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_1836 any = p1__233000267_SHARP___1; if linked_1833 == nil { return ifn_1834.Invoke_O_O__O(arg_1835, arg_1836) } else { return linked_1833.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1832, arg_1835, arg_1836) } }
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A) Invoke_O_O__O(self, p__233000280__1 any) any { var vec__233000282__2 any = p__233000280__1; var k2__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000282__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v2__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000282__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(v2__4, lang.RT_Get_O_O__O_NoInit(t.F_b, k2__3))).Ref() }
//line :286:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A) Invoke_O_O__O(self, p__233000292__1 any) any { var vec__233000294__2 any = p__233000292__1; var k2__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000294__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v2__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000294__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(v2__4, lang.RT_Get_O_O__O_NoInit(t.F_b, k2__3))).Ref() }




func A_arbace_j2g_edge__main_A_New() *A_arbace_j2g_edge__main_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge__main_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_j2g_edge__main_A) Ctor() {}
//line :291:1
func (t *A_arbace_j2g_edge__main_A) DoInvoke_O_O_O__O(self, cmd__0, args__1 any) any { var G__233000301__3_ any = cmd__0; switch



	lang.Util_Hash_O__I_NoInit(G__233000301__3_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__233000301__3_, Lit_1) { var vec__233000302__4 any = args__1; var seq__233000303__5 any; var root_1886 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1888 lang.IFn
		if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any = vec__233000302__4; if linked_1887 == nil { seq__233000303__5 = ifn_1888.Invoke_O__O(arg_1889) } else { seq__233000303__5 = linked_1887.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1886, arg_1889) }
//line :295:1
		var first__233000304__6 any; var root_1890 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1892 lang.IFn
		if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = seq__233000303__5; if linked_1891 == nil { first__233000304__6 = ifn_1892.Invoke_O__O(arg_1893) } else { first__233000304__6 = linked_1891.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1890, arg_1893) }
//line :295:1
		var seq__233000303__7 any; var root_1894 any = A_arbace_j2g_edge_A_const_97.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1896 lang.IFn
		if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = seq__233000303__5; if linked_1895 == nil { seq__233000303__7 = ifn_1896.Invoke_O__O(arg_1897) } else { seq__233000303__7 = linked_1895.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1894, arg_1897) }
//line :295:1
		var out__8 any = first__233000304__6; var ins__9 any = seq__233000303__7; var root_1898 any = A_arbace_j2g_edge_A_const_137.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, A_arbace_j2g_edge_write_edge_BANG__A_fn_class); var ifn_1900 lang.IFn

		if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = out__8; var arg_1902 any; var root_1903 any = A_arbace_j2g_edge_A_const_128.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, A_arbace_j2g_edge_merge_edges_A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any; var root_1907 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = A_arbace_j2g_edge_A_const_138.GetRawRoot__O(); var arg_1911 any = ins__9; if linked_1908 == nil { arg_1906 = ifn_1909.Invoke_O_O__O(arg_1910, arg_1911) } else { arg_1906 = linked_1908.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1907, arg_1910, arg_1911) }; if linked_1904 == nil { arg_1902 = ifn_1905.Invoke_O__O(arg_1906) } else { arg_1902 = linked_1904.(*A_arbace_j2g_edge_merge_edges_A).Invoke_O_O__O(root_1903, arg_1906) }; if linked_1899 == nil { return ifn_1900.Invoke_O_O__O(arg_1901, arg_1902) } else { return linked_1899.(*A_arbace_j2g_edge_write_edge_BANG__A).Invoke_O_O_O__O(root_1898, arg_1901, arg_1902) } }
//line :295:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__233000301__3_, Lit_2) { var vec__233000305__4 any = args__1; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000305__4, lang.RT_IntCast_J__I_NoInit(0), nil); var in__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000305__4, lang.RT_IntCast_J__I_NoInit(1), nil); var base__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000305__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_1912 any = A_arbace_j2g_edge_A_const_137.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, A_arbace_j2g_edge_write_edge_BANG__A_fn_class); var ifn_1914 lang.IFn



		if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = out__5; var arg_1916 any; var root_1917 any = A_arbace_j2g_edge_A_const_139.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, A_arbace_j2g_edge_subtract_edge_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any; var root_1922 any = A_arbace_j2g_edge_A_const_138.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, A_arbace_j2g_edge_read_edge_data_A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = in__6; if linked_1923 == nil { arg_1920 = ifn_1924.Invoke_O__O(arg_1925) } else { arg_1920 = linked_1923.(*A_arbace_j2g_edge_read_edge_data_A).Invoke_O_O__O(root_1922, arg_1925) }; var arg_1921 any; var root_1926 any = A_arbace_j2g_edge_A_const_138.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, A_arbace_j2g_edge_read_edge_data_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = base__7; if linked_1927 == nil { arg_1921 = ifn_1928.Invoke_O__O(arg_1929) } else { arg_1921 = linked_1927.(*A_arbace_j2g_edge_read_edge_data_A).Invoke_O_O__O(root_1926, arg_1929) }; if linked_1918 == nil { arg_1916 = ifn_1919.Invoke_O_O__O(arg_1920, arg_1921) } else { arg_1916 = linked_1918.(*A_arbace_j2g_edge_subtract_edge_A).Invoke_O_O_O__O(root_1917, arg_1920, arg_1921) }; if linked_1913 == nil { return ifn_1914.Invoke_O_O__O(arg_1915, arg_1916) } else { return linked_1913.(*A_arbace_j2g_edge_write_edge_BANG__A).Invoke_O_O_O__O(root_1912, arg_1915, arg_1916) } }
//line :295:1
	default:}; var tmp1 any; var root_1930 any = A_arbace_j2g_edge_A_const_56.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1932 lang.IFn; if




	linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, cmd__0)).Ref(); var arg_1934 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1931 == nil { tmp1 = ifn_1932.Invoke_O_O__O(arg_1933, arg_1934) } else { tmp1 = linked_1931.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1930, arg_1933, arg_1934) }; /*line :295:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }
















































































































































































































































































type A_arbace_j2g_edge_A struct{ jrt.Object }

var A_arbace_j2g_edge_A_const_pool *jrt.RefArray

var A_arbace_j2g_edge_A_const_0 *lang.Var

var A_arbace_j2g_edge_A_const_1 any

var A_arbace_j2g_edge_A_const_2 any

var A_arbace_j2g_edge_A_const_3 any

var A_arbace_j2g_edge_A_const_4 any

var A_arbace_j2g_edge_A_const_5 *lang.Var

var A_arbace_j2g_edge_A_const_6 any

var A_arbace_j2g_edge_A_const_7 *lang.Var

var A_arbace_j2g_edge_A_const_8 *lang.Var

var A_arbace_j2g_edge_A_const_9 *lang.Var

var A_arbace_j2g_edge_A_const_10 *lang.Var

var A_arbace_j2g_edge_A_const_11 any

var A_arbace_j2g_edge_A_const_12 *lang.Var

var A_arbace_j2g_edge_A_const_13 *lang.Var

var A_arbace_j2g_edge_A_const_14 *lang.Var

var A_arbace_j2g_edge_A_const_15 *lang.Var

var A_arbace_j2g_edge_A_const_16 *lang.Var

var A_arbace_j2g_edge_A_const_17 *lang.Var

var A_arbace_j2g_edge_A_const_18 *lang.Var

var A_arbace_j2g_edge_A_const_19 *lang.Var

var A_arbace_j2g_edge_A_const_20 *lang.Var

var A_arbace_j2g_edge_A_const_21 *lang.Var

var A_arbace_j2g_edge_A_const_22 any

var A_arbace_j2g_edge_A_const_23 any

var A_arbace_j2g_edge_A_const_24 *lang.Var

var A_arbace_j2g_edge_A_const_25 any

var A_arbace_j2g_edge_A_const_26 any

var A_arbace_j2g_edge_A_const_27 *lang.Keyword

var A_arbace_j2g_edge_A_const_28 *lang.Var

var A_arbace_j2g_edge_A_const_29 *lang.Var

var A_arbace_j2g_edge_A_const_30 *lang.Var

var A_arbace_j2g_edge_A_const_31 *lang.Var

var A_arbace_j2g_edge_A_const_32 *lang.Var

var A_arbace_j2g_edge_A_const_33 *lang.Var

var A_arbace_j2g_edge_A_const_34 *lang.Var

var A_arbace_j2g_edge_A_const_35 *lang.Var

var A_arbace_j2g_edge_A_const_36 *lang.Var

var A_arbace_j2g_edge_A_const_37 *lang.Var

var A_arbace_j2g_edge_A_const_38 *lang.Var

var A_arbace_j2g_edge_A_const_39 *lang.Var

var A_arbace_j2g_edge_A_const_40 *lang.Var

var A_arbace_j2g_edge_A_const_41 *lang.Var

var A_arbace_j2g_edge_A_const_42 *lang.Var

var A_arbace_j2g_edge_A_const_43 *lang.Var

var A_arbace_j2g_edge_A_const_44 *lang.Var

var A_arbace_j2g_edge_A_const_45 *lang.Var

var A_arbace_j2g_edge_A_const_46 *lang.Var

var A_arbace_j2g_edge_A_const_47 *lang.Var

var A_arbace_j2g_edge_A_const_48 *lang.Var

var A_arbace_j2g_edge_A_const_49 *lang.Var

var A_arbace_j2g_edge_A_const_50 *lang.Var

var A_arbace_j2g_edge_A_const_51 *lang.Var

var A_arbace_j2g_edge_A_const_52 *lang.Var

var A_arbace_j2g_edge_A_const_53 *lang.Var

var A_arbace_j2g_edge_A_const_54 *lang.Var

var A_arbace_j2g_edge_A_const_55 *lang.Var

var A_arbace_j2g_edge_A_const_56 *lang.Var

var A_arbace_j2g_edge_A_const_57 *lang.Var

var A_arbace_j2g_edge_A_const_58 *lang.Var

var A_arbace_j2g_edge_A_const_59 *lang.Keyword

var A_arbace_j2g_edge_A_const_60 *lang.Keyword

var A_arbace_j2g_edge_A_const_61 *lang.Var

var A_arbace_j2g_edge_A_const_62 any

var A_arbace_j2g_edge_A_const_63 *lang.Var

var A_arbace_j2g_edge_A_const_64 *lang.Var

var A_arbace_j2g_edge_A_const_65 *lang.Var

var A_arbace_j2g_edge_A_const_66 *lang.Var

var A_arbace_j2g_edge_A_const_67 *lang.Var

var A_arbace_j2g_edge_A_const_68 *lang.Var

var A_arbace_j2g_edge_A_const_69 *lang.Var

var A_arbace_j2g_edge_A_const_70 *lang.Var

var A_arbace_j2g_edge_A_const_71 any

var A_arbace_j2g_edge_A_const_72 *lang.Var

var A_arbace_j2g_edge_A_const_73 *lang.Var

var A_arbace_j2g_edge_A_const_74 *lang.Var

var A_arbace_j2g_edge_A_const_75 *lang.Var

var A_arbace_j2g_edge_A_const_76 *lang.Var

var A_arbace_j2g_edge_A_const_77 *lang.Var

var A_arbace_j2g_edge_A_const_78 *lang.Var

var A_arbace_j2g_edge_A_const_79 *lang.Var

var A_arbace_j2g_edge_A_const_80 *lang.Keyword

var A_arbace_j2g_edge_A_const_81 *lang.Keyword

var A_arbace_j2g_edge_A_const_82 *lang.Var

var A_arbace_j2g_edge_A_const_83 *lang.Keyword

var A_arbace_j2g_edge_A_const_84 *lang.Keyword

var A_arbace_j2g_edge_A_const_85 *lang.Keyword

var A_arbace_j2g_edge_A_const_86 *lang.Keyword

var A_arbace_j2g_edge_A_const_87 *lang.Keyword

var A_arbace_j2g_edge_A_const_88 *lang.Var

var A_arbace_j2g_edge_A_const_89 *lang.Keyword

var A_arbace_j2g_edge_A_const_90 *lang.Var

var A_arbace_j2g_edge_A_const_91 *lang.Keyword

var A_arbace_j2g_edge_A_const_92 *lang.Var

var A_arbace_j2g_edge_A_const_93 *lang.Var

var A_arbace_j2g_edge_A_const_94 *lang.Keyword

var A_arbace_j2g_edge_A_const_95 *lang.Var

var A_arbace_j2g_edge_A_const_96 any

var A_arbace_j2g_edge_A_const_97 *lang.Var

var A_arbace_j2g_edge_A_const_98 *lang.Var

var A_arbace_j2g_edge_A_const_99 *lang.Keyword

var A_arbace_j2g_edge_A_const_100 *lang.Var

var A_arbace_j2g_edge_A_const_101 *lang.Var

var A_arbace_j2g_edge_A_const_102 *lang.Var

var A_arbace_j2g_edge_A_const_103 *lang.Var

var A_arbace_j2g_edge_A_const_104 *lang.Var

var A_arbace_j2g_edge_A_const_105 *lang.Var

var A_arbace_j2g_edge_A_const_106 *lang.Var

var A_arbace_j2g_edge_A_const_107 *lang.Var

var A_arbace_j2g_edge_A_const_108 *lang.Var

var A_arbace_j2g_edge_A_const_109 *lang.Var

var A_arbace_j2g_edge_A_const_110 *lang.Keyword

var A_arbace_j2g_edge_A_const_111 any

var A_arbace_j2g_edge_A_const_112 *lang.Var

var A_arbace_j2g_edge_A_const_113 any

var A_arbace_j2g_edge_A_const_114 *lang.Var

var A_arbace_j2g_edge_A_const_115 *lang.Var

var A_arbace_j2g_edge_A_const_116 *lang.Keyword

var A_arbace_j2g_edge_A_const_117 *lang.Var

var A_arbace_j2g_edge_A_const_118 *lang.Var

var A_arbace_j2g_edge_A_const_119 *lang.Var

var A_arbace_j2g_edge_A_const_120 *lang.Var

var A_arbace_j2g_edge_A_const_121 *lang.Var

var A_arbace_j2g_edge_A_const_122 any

var A_arbace_j2g_edge_A_const_123 *lang.Var

var A_arbace_j2g_edge_A_const_124 *lang.Keyword

var A_arbace_j2g_edge_A_const_125 any

var A_arbace_j2g_edge_A_const_126 *lang.Var

var A_arbace_j2g_edge_A_const_127 *lang.Var

var A_arbace_j2g_edge_A_const_128 *lang.Var

var A_arbace_j2g_edge_A_const_129 *lang.Var

var A_arbace_j2g_edge_A_const_130 *lang.Var

var A_arbace_j2g_edge_A_const_131 *lang.Var

var A_arbace_j2g_edge_A_const_132 *lang.Var

var A_arbace_j2g_edge_A_const_133 *lang.Var

var A_arbace_j2g_edge_A_const_134 *lang.Var

var A_arbace_j2g_edge_A_const_135 *lang.Var

var A_arbace_j2g_edge_A_const_136 *lang.Var

var A_arbace_j2g_edge_A_const_137 *lang.Var

var A_arbace_j2g_edge_A_const_138 *lang.Var

var A_arbace_j2g_edge_A_const_139 *lang.Var

var A_arbace_j2g_edge_A_init jrt.ClassInit

func A_arbace_j2g_edge_A_Init() { if !A_arbace_j2g_edge_A_init.Done() { A_arbace_j2g_edge_A_init.Run(A_arbace_j2g_edge_A_clinit) } }

func A_arbace_j2g_edge_A_clinit() { A_arbace_j2g_edge_A_clinit_p0(); A_arbace_j2g_edge_A_clinit_p1(); A_arbace_j2g_edge_A_clinit_p2(); A_arbace_j2g_edge_A_clinit_p3(); A_arbace_j2g_edge_A_clinit_p4(); A_arbace_j2g_edge_A_clinit_p5(); A_arbace_j2g_edge_A_clinit_p6(); A_arbace_j2g_edge_A_clinit_p7(); A_arbace_j2g_edge_A_clinit_p8(); A_arbace_j2g_edge_A_clinit_p9(); A_arbace_j2g_edge_A_clinit_p10(); A_arbace_j2g_edge_A_clinit_p11() }

func A_arbace_j2g_edge_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_edge_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 169); A_arbace_j2g_edge_A_const_0 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[29]); A_arbace_j2g_edge_A_const_1 = A_arbace_j2g_edge_A_const_pool.A[30]; A_arbace_j2g_edge_A_const_2 = A_arbace_j2g_edge_A_const_pool.A[31]; A_arbace_j2g_edge_A_const_3 = A_arbace_j2g_edge_A_const_pool.A[32]; A_arbace_j2g_edge_A_const_4 = A_arbace_j2g_edge_A_const_pool.A[33]; A_arbace_j2g_edge_A_const_5 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[34]); A_arbace_j2g_edge_A_const_6 = A_arbace_j2g_edge_A_const_pool.A[35]; A_arbace_j2g_edge_A_const_7 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[36]); A_arbace_j2g_edge_A_const_8 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[37]); A_arbace_j2g_edge_A_const_9 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[38]); A_arbace_j2g_edge_A_const_10 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[39]); A_arbace_j2g_edge_A_const_11 = A_arbace_j2g_edge_A_const_pool.A[40] }

func A_arbace_j2g_edge_A_clinit_p1() { A_arbace_j2g_edge_A_const_12 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[41]); A_arbace_j2g_edge_A_const_13 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[42]); A_arbace_j2g_edge_A_const_14 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[43]); A_arbace_j2g_edge_A_const_15 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[44]); A_arbace_j2g_edge_A_const_16 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[45]); A_arbace_j2g_edge_A_const_17 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[46]); A_arbace_j2g_edge_A_const_18 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[47]); A_arbace_j2g_edge_A_const_19 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[48]); A_arbace_j2g_edge_A_const_20 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[49]); A_arbace_j2g_edge_A_const_21 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[50]); A_arbace_j2g_edge_A_const_22 = A_arbace_j2g_edge_A_const_pool.A[51]; A_arbace_j2g_edge_A_const_23 = A_arbace_j2g_edge_A_const_pool.A[52] }

func A_arbace_j2g_edge_A_clinit_p2() { A_arbace_j2g_edge_A_const_24 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[53]); A_arbace_j2g_edge_A_const_25 = A_arbace_j2g_edge_A_const_pool.A[54]; A_arbace_j2g_edge_A_const_26 = A_arbace_j2g_edge_A_const_pool.A[55]; A_arbace_j2g_edge_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[56]); A_arbace_j2g_edge_A_const_28 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[57]); A_arbace_j2g_edge_A_const_29 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[58]); A_arbace_j2g_edge_A_const_30 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[59]); A_arbace_j2g_edge_A_const_31 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[60]); A_arbace_j2g_edge_A_const_32 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[61]); A_arbace_j2g_edge_A_const_33 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[62]); A_arbace_j2g_edge_A_const_34 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[63]); A_arbace_j2g_edge_A_const_35 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[64]) }

func A_arbace_j2g_edge_A_clinit_p3() { A_arbace_j2g_edge_A_const_36 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[65]); A_arbace_j2g_edge_A_const_37 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[66]); A_arbace_j2g_edge_A_const_38 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[67]); A_arbace_j2g_edge_A_const_39 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[68]); A_arbace_j2g_edge_A_const_40 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[69]); A_arbace_j2g_edge_A_const_41 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[70]); A_arbace_j2g_edge_A_const_42 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[71]); A_arbace_j2g_edge_A_const_43 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[72]); A_arbace_j2g_edge_A_const_44 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[73]); A_arbace_j2g_edge_A_const_45 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[74]); A_arbace_j2g_edge_A_const_46 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[75]); A_arbace_j2g_edge_A_const_47 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[76]) }

func A_arbace_j2g_edge_A_clinit_p4() { A_arbace_j2g_edge_A_const_48 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[77]); A_arbace_j2g_edge_A_const_49 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[78]); A_arbace_j2g_edge_A_const_50 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[79]); A_arbace_j2g_edge_A_const_51 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[80]); A_arbace_j2g_edge_A_const_52 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[81]); A_arbace_j2g_edge_A_const_53 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[82]); A_arbace_j2g_edge_A_const_54 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[83]); A_arbace_j2g_edge_A_const_55 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[84]); A_arbace_j2g_edge_A_const_56 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[85]); A_arbace_j2g_edge_A_const_57 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[86]); A_arbace_j2g_edge_A_const_58 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[87]); A_arbace_j2g_edge_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[88]) }

func A_arbace_j2g_edge_A_clinit_p5() { A_arbace_j2g_edge_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[89]); A_arbace_j2g_edge_A_const_61 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[90]); A_arbace_j2g_edge_A_const_62 = A_arbace_j2g_edge_A_const_pool.A[91]; A_arbace_j2g_edge_A_const_63 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[92]); A_arbace_j2g_edge_A_const_64 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[93]); A_arbace_j2g_edge_A_const_65 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[94]); A_arbace_j2g_edge_A_const_66 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[95]); A_arbace_j2g_edge_A_const_67 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[96]); A_arbace_j2g_edge_A_const_68 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[97]); A_arbace_j2g_edge_A_const_69 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[98]); A_arbace_j2g_edge_A_const_70 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[99]); A_arbace_j2g_edge_A_const_71 = A_arbace_j2g_edge_A_const_pool.A[100] }

func A_arbace_j2g_edge_A_clinit_p6() { A_arbace_j2g_edge_A_const_72 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[101]); A_arbace_j2g_edge_A_const_73 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[102]); A_arbace_j2g_edge_A_const_74 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[103]); A_arbace_j2g_edge_A_const_75 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[104]); A_arbace_j2g_edge_A_const_76 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[105]); A_arbace_j2g_edge_A_const_77 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[106]); A_arbace_j2g_edge_A_const_78 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[107]); A_arbace_j2g_edge_A_const_79 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[108]); A_arbace_j2g_edge_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[109]); A_arbace_j2g_edge_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[110]); A_arbace_j2g_edge_A_const_82 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[111]); A_arbace_j2g_edge_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[112]) }

func A_arbace_j2g_edge_A_clinit_p7() { A_arbace_j2g_edge_A_const_84 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[113]); A_arbace_j2g_edge_A_const_85 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[114]); A_arbace_j2g_edge_A_const_86 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[115]); A_arbace_j2g_edge_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[116]); A_arbace_j2g_edge_A_const_88 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[117]); A_arbace_j2g_edge_A_const_89 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[118]); A_arbace_j2g_edge_A_const_90 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[119]); A_arbace_j2g_edge_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[120]); A_arbace_j2g_edge_A_const_92 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[121]); A_arbace_j2g_edge_A_const_93 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[122]); A_arbace_j2g_edge_A_const_94 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[123]); A_arbace_j2g_edge_A_const_95 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[124]) }

func A_arbace_j2g_edge_A_clinit_p8() { A_arbace_j2g_edge_A_const_96 = A_arbace_j2g_edge_A_const_pool.A[125]; A_arbace_j2g_edge_A_const_97 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[126]); A_arbace_j2g_edge_A_const_98 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[127]); A_arbace_j2g_edge_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[128]); A_arbace_j2g_edge_A_const_100 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[129]); A_arbace_j2g_edge_A_const_101 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[130]); A_arbace_j2g_edge_A_const_102 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[131]); A_arbace_j2g_edge_A_const_103 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[132]); A_arbace_j2g_edge_A_const_104 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[133]); A_arbace_j2g_edge_A_const_105 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[134]); A_arbace_j2g_edge_A_const_106 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[135]); A_arbace_j2g_edge_A_const_107 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[136]) }

func A_arbace_j2g_edge_A_clinit_p9() { A_arbace_j2g_edge_A_const_108 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[137]); A_arbace_j2g_edge_A_const_109 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[138]); A_arbace_j2g_edge_A_const_110 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[139]); A_arbace_j2g_edge_A_const_111 = A_arbace_j2g_edge_A_const_pool.A[140]; A_arbace_j2g_edge_A_const_112 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[141]); A_arbace_j2g_edge_A_const_113 = A_arbace_j2g_edge_A_const_pool.A[142]; A_arbace_j2g_edge_A_const_114 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[143]); A_arbace_j2g_edge_A_const_115 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[144]); A_arbace_j2g_edge_A_const_116 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[145]); A_arbace_j2g_edge_A_const_117 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[146]); A_arbace_j2g_edge_A_const_118 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[147]); A_arbace_j2g_edge_A_const_119 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[148]) }

func A_arbace_j2g_edge_A_clinit_p10() { A_arbace_j2g_edge_A_const_120 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[149]); A_arbace_j2g_edge_A_const_121 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[150]); A_arbace_j2g_edge_A_const_122 = A_arbace_j2g_edge_A_const_pool.A[151]; A_arbace_j2g_edge_A_const_123 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[152]); A_arbace_j2g_edge_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[153]); A_arbace_j2g_edge_A_const_125 = A_arbace_j2g_edge_A_const_pool.A[154]; A_arbace_j2g_edge_A_const_126 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[155]); A_arbace_j2g_edge_A_const_127 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[156]); A_arbace_j2g_edge_A_const_128 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[157]); A_arbace_j2g_edge_A_const_129 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[158]); A_arbace_j2g_edge_A_const_130 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[159]); A_arbace_j2g_edge_A_const_131 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[160]) }

func A_arbace_j2g_edge_A_clinit_p11() { A_arbace_j2g_edge_A_const_132 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[161]); A_arbace_j2g_edge_A_const_133 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[162]); A_arbace_j2g_edge_A_const_134 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[163]); A_arbace_j2g_edge_A_const_135 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[164]); A_arbace_j2g_edge_A_const_136 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[165]); A_arbace_j2g_edge_A_const_137 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[166]); A_arbace_j2g_edge_A_const_138 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[167]); A_arbace_j2g_edge_A_const_139 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[168]) }

func A_arbace_j2g_edge_A_New() *A_arbace_j2g_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_A) Ctor() {}

func (t *A_arbace_j2g_edge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_A_class }

func (t *A_arbace_j2g_edge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_A); return ok }

func A_arbace_j2g_edge_A_Cast(x any) *A_arbace_j2g_edge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_A_class)) }; return v }



type A_arbace_j2g_edge__main_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge__main_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_fn__233000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000177_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000180_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000217_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A struct{ j2g_header uint64; F_iter__233000061, F_s__233000062 any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A struct{ j2g_header uint64; F_b__233000064 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class *jrt.Class



type A_arbace_j2g_edge_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_coerce_const_A_fn_class *jrt.Class



type A_arbace_j2g_edge_const_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_const_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A struct{ j2g_header uint64; F_iter__233000083, F_s__233000084 any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A struct{ j2g_header uint64; F_b__233000086 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A struct{ j2g_header uint64; F_iter__233000099, F_s__233000100 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A struct{ j2g_header uint64; F_b__233000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A struct{ j2g_header uint64; F_iter__233000109, F_s__233000110 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A struct{ j2g_header uint64; F_b__233000112 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A struct{ j2g_header uint64; F_iter__233000129, F_s__233000130 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A struct{ j2g_header uint64; F_b__233000132 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000004_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000004_A_New() *A_arbace_j2g_edge_eval233000004_A { t := &A_arbace_j2g_edge_eval233000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000004_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000004_A_class }

func (t *A_arbace_j2g_edge_eval233000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000004_A); return ok }

func A_arbace_j2g_edge_eval233000004_A_Cast(x any) *A_arbace_j2g_edge_eval233000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000004_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000008_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000008_A_New() *A_arbace_j2g_edge_eval233000008_A { t := &A_arbace_j2g_edge_eval233000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000008_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000008_A_class }

func (t *A_arbace_j2g_edge_eval233000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000008_A); return ok }

func A_arbace_j2g_edge_eval233000008_A_Cast(x any) *A_arbace_j2g_edge_eval233000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000008_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000008_fn__233000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000008_fn__233000009_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000045_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A struct{ j2g_header uint64; F_a any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class *jrt.Class



type A_arbace_j2g_edge_method_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_method_key_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A struct{ j2g_header uint64; F_s__233000017, F_iter__233000016 any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A struct{ j2g_header uint64; F_b__233000019 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_double_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_double_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_string_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_string_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A struct{ j2g_header uint64; F_s__233000224, F_iter__233000223 any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A struct{ j2g_header uint64; F_b__233000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_rd__233000220_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_rd__233000220_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000243_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A struct{ j2g_header uint64; F_s__233000247, F_iter__233000246 any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A struct{ j2g_header uint64; F_b__233000249 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_A struct{ j2g_header uint64; F_env_rec any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A struct{ j2g_header uint64; F_iter__233000149, F_s__233000150 any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A struct{ j2g_header uint64; F_b__233000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_subtract_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A struct{ j2g_header uint64; F_s__233000269, F_base, F_iter__233000268 any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A struct{ j2g_header uint64; F_b__233000271, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_fn_class *jrt.Class



type A_arbace_j2g_edge_write_edge_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_write_edge_BANG__A_fn_class *jrt.Class
