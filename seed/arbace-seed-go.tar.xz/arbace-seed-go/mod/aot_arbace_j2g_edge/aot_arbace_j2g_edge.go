//line aot_arbace_j2g_edge.ae:1
package aot_arbace_j2g_edge

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_New() *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_edge_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_edge_A_const_3, A_arbace_j2g_edge_A_const_4, A_arbace_j2g_edge_A_const_5, A_arbace_j2g_edge_A_const_6); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_j2g_edge_eval233000008_fn__233000009_A_New() *A_arbace_j2g_edge_eval233000008_fn__233000009_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000008_fn__233000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_11), A_arbace_j2g_edge_A_const_9.GetRawRoot__O(), A_arbace_j2g_edge_A_const_10) }



























func A_arbace_j2g_edge_jvm_A_New() *A_arbace_j2g_edge_jvm_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {



	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		return lang.IFn_Cast(A_arbace_j2g_edge_A_const_13.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_12.Get__O(), lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1)) } else {
//line :33:1
			var v__4 any = lang.IFn_Cast(f__2).Invoke__O(); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_15.GetRawRoot__O()).Invoke_O__O(v__4) } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { lang.IFn_Cast(A_arbace_j2g_edge_A_const_16.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_edge_A_const_14.Get__O(), A_arbace_j2g_edge_A_const_17.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1), v__4) }
//line :33:1
			return v__4
		}
}



func A_arbace_j2g_edge_jvm_QMARK__A_New() *A_arbace_j2g_edge_jvm_QMARK__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_QMARK__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {


	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		return lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Get_O_O__O(A_arbace_j2g_edge_A_const_12.Get__O(), section__0), k__1) } else {
//line :42:1
			var v__4 bool = lang.RT_BooleanCast_O__Z(lang.IFn_Cast(f__2).Invoke__O()); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(v__4).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_16.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_14.Get__O(); var tmp4 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_20.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_edge_A_const_9.GetRawRoot__O(); var tmp7 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp7 = lang.PersistentHashSet_EMPTY; tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, section__0, tmp5.Invoke_O_O__O(tmp6, tmp7.Ref()), k__1) }
//line :42:1
			return jrt.Boolean_ValueOf_Z__Boolean(v__4).Ref()
		}
}







func A_arbace_j2g_edge_pr_string_A_New() *A_arbace_j2g_edge_pr_string_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_string_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Ctor() {}
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_79); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J(lang.RT_Count_O__I(s__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z(i__4, n__1927000701__auto____3) { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(i__4))

		if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_22)).CharValue__C()) { jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_80) } else { if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_23)).CharValue__C()) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_81) } else {
//line :56:1
				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_27; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_C__I(c__5)).Ref(), A_arbace_j2g_edge_A_const_28)) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(c__5) } else {
//line :56:1
						if A_arbace_j2g_edge_A_const_25 != nil {


							jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_j2g_edge_A_const_26.GetRawRoot__O()).Invoke_O_O__O(Lit_82, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_C__I(c__5)).Ref()))) } } } }
//line :54:1
		i__4 = lang.Numbers_Unchecked_inc_J__J(i__4); continue L1 }
//line :52:1
	break L1 }; return /*line :60:1*/ lang.IFn_Cast(A_arbace_j2g_edge_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_79).Ref()) }

func A_arbace_j2g_edge_pr_double_A_New() *A_arbace_j2g_edge_pr_double_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_double_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Ctor() {}
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); if
										jrt.Double_IsNaN_D__Z(d__0) { return Lit_76 } else { if lang.Util_Equiv_D_D__Z(d__0, jrt.PosInf64) { return Lit_77 } else { if lang.Util_Equiv_D_D__Z(d__0, jrt.NegInf64) { return Lit_78 } else { if A_arbace_j2g_edge_A_const_25 != nil {


		return jrt.Double_ToString_D__String(d__0).Ref() } else {
//line :63:1
			return nil } } } } }




func A_arbace_j2g_edge_pr_data_A_New() *A_arbace_j2g_edge_pr_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Ctor() {}
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Invoke_O_O__O(self, x__0 any) any {


	if lang.Util_Identical_O_O__Z(x__0, nil) { return Lit_69 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_29.GetRawRoot__O()).Invoke_O__O(x__0)) {

		return lang.IFn_Cast(A_arbace_j2g_edge_A_const_21.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_30.GetRawRoot__O()).Invoke_O__O(x__0)) {


				return lang.IFn_Cast(A_arbace_j2g_edge_A_const_31.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_32.GetRawRoot__O()).Invoke_O__O(x__0)) {



						return lang.IFn_Cast(A_arbace_j2g_edge_A_const_21.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_33.GetRawRoot__O()).Invoke_O__O(x__0)) {




								return lang.IFn_Cast(A_arbace_j2g_edge_A_const_21.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
									var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)





									if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = jrt.Byte_InstanceOf(x__0) } } }
//line :71:1
									if tmp1 {





										return lang.IFn_Cast(A_arbace_j2g_edge_A_const_21.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
											var tmp2 bool; var or__1927000174__auto____2_2 bool = jrt.Double_InstanceOf(x__0)






											if or__1927000174__auto____2_2 { tmp2 = or__1927000174__auto____2_2 } else { tmp2 = jrt.Float_InstanceOf(x__0) }
//line :71:1
											if tmp2 {






												return lang.IFn_Cast(A_arbace_j2g_edge_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Double_ValueOf_D__Double(lang.RT_DoubleCast_O__D(x__0)).Ref()) } else {
//line :71:1
													if jrt.Character_InstanceOf(x__0) {







														return lang.IFn_Cast(A_arbace_j2g_edge_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_C__I(lang.RT_CharCast_O__C(x__0))).Ref()) } else {
//line :71:1
															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0)) {








																var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_10); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()); var tmp5 any; var iter__1927001039__auto____5 any; var tmp6 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New(); var tmp7 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class = fncls__3d; tmp7 = fncls__3d } else { tmp7 = fncls__3 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), A_arbace_j2g_edge_A_const_54.GetRawRoot__O()), x__0)); return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O_O__O(Lit_19, tmp5), nil)).Ref() } else {
//line :71:1
																	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_37.GetRawRoot__O()).Invoke_O__O(x__0)) {









																		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()).Invoke_O_O__O(Lit_19, lang.IFn_Cast(A_arbace_j2g_edge_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), x__0))), nil)).Ref() } else {
//line :71:1
																			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_38.GetRawRoot__O()).Invoke_O__O(x__0)) {










																				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()).Invoke_O_O__O(Lit_19, lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :71:1
																					if A_arbace_j2g_edge_A_const_25 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_j2g_edge_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_59.GetRawRoot__O()).Invoke_O__O(x__0)))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_58, x__0)))))) } else { return nil
																					}
																				}
																		}
																}
														}
												}
										}
								} } } } } }
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New() *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Ctor() {}
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Invoke_O_O__O(self, s__233000017__1 any) any { var tmp1 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(s__233000017__1, self); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Ctor_O_O(c__s__233000017, c__iter__233000016 any) { t.F_s__233000017 = c__s__233000017; t.F_iter__233000016 = c__iter__233000016 }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Invoke_O__O(self any) any { { var s__233000017__1 any; var t_ any = t.F_s__233000017; t.F_s__233000017 = nil; s__233000017__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000017__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000017__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000017__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000017__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000019__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(b__233000019__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000019__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000017__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000019__6), nil) } } else { var vec__233000027__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000017__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__233000027__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__233000027__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__5), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(v__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000017__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Ctor_O_I_O(c__b__233000019 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000019 = c__b__233000019; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Invoke_O__O(self any) any { { var i__233000018__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000018__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000023__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000018__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__233000023__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__233000023__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000019; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__3), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__233000018__1 = lang.Numbers_Unchecked_inc_J__J(i__233000018__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_const_data_A_New() *A_arbace_j2g_edge_const_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_const_data_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Invoke_O_O__O(self, v__0 any) any {


	if jrt.Character_InstanceOf(v__0) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(lang.RT_IntCast_C__I(lang.RT_CharCast_O__C(v__0)))).Ref() } else { return v__0
	} }
func A_arbace_j2g_edge_ann_data_A_New() *A_arbace_j2g_edge_ann_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(x__0, A_arbace_j2g_edge_A_const_63); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_63.Invoke_O__O(x__0)) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_60.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_64; return tmp2.Invoke_O_O_O__O(x__0, tmp3, A_arbace_j2g_edge_A_const_65.GetRawRoot__O()) } else {
//line :93:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_edge_ann_data_fn__233000035_A_New(); var tmp9 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class = fncls__4d; tmp9 = fncls__4d } else { tmp9 = fncls__4 }; return tmp4.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), x__0)) } else {
//line :93:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_38.GetRawRoot__O()).Invoke_O__O(x__0)) {


						return lang.IFn_Cast(A_arbace_j2g_edge_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_66.GetRawRoot__O(), x__0) } else {
//line :93:1
							if A_arbace_j2g_edge_A_const_25 != nil { return x__0 } else { return nil
							} } } } }
func A_arbace_j2g_edge_ann_data_fn__233000035_A_New() *A_arbace_j2g_edge_ann_data_fn__233000035_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_fn__233000035_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Invoke_O_O__O(self, p__233000034__1 any) any { var vec__233000036__2 any = p__233000034__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__233000036__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__233000036__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.IFn_Cast(A_arbace_j2g_edge_A_const_66.GetRawRoot__O()).Invoke_O__O(v__4)) }










func A_arbace_j2g_edge_fn__233000042_A_New() *A_arbace_j2g_edge_fn__233000042_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Ctor() {}
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Invoke_O__O(self any) any { var f__1 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_67.GetRawRoot__O()).Invoke_O_O_O__O(jrt.System_GetProperty_String__String(Lit_43).Ref(), Lit_44, Lit_45); var tmp1 any; var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(f__1)).IsFile__Z(); if and__1927000168__auto____2 {

	tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_68.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.System_GetProperty_String__String(Lit_46).Ref()), Lit_47) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp3 = lang.PersistentHashSet_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_69.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New(); var tmp7 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class = fncls__5d; tmp7 = fncls__5d } else { tmp7 = fncls__5 }; return tmp2.Invoke_O_O_O__O(tmp4, tmp5.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)), lang.IFn_Cast(A_arbace_j2g_edge_A_const_70.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()).Invoke_O__O(f__1))) } else {
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_edge_A_const_78; lang.IFn_Cast(A_arbace_j2g_edge_A_const_76.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, A_arbace_j2g_edge_A_const_79.Get__O())); var tmp10 any = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New(); var tmp11 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class = fncls__6d; tmp11 = fncls__6d } else { tmp11 = fncls__6 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :108:1
			lang.PersistentHashSet_Init(); return lang.PersistentHashSet_EMPTY.Ref() } }
func A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000043_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000043_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Invoke_O_O__O(self, p1__233000041_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_71.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_72, p1__233000041_SHARP___1) }
func A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000045_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000045_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_74.GetRawRoot__O()).Invoke_O_O__O(Lit_50, Lit_51)
//line :110:1
	return nil }(); lang.IFn_Cast(A_arbace_j2g_edge_A_const_75.GetRawRoot__O()).Invoke__O(); if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_j2g_edge_method_key_A_New() *A_arbace_j2g_edge_method_key_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_method_key_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Ctor() {}
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Invoke_O_O__O(self, m__0 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__0), A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__0)) }






func A_arbace_j2g_edge_info_data_A_New() *A_arbace_j2g_edge_info_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Ctor() {}
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Invoke_O_O__O(self, info__0 any) any {









	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O__O(info__0, A_arbace_j2g_edge_A_const_93); var tmp4 any = A_arbace_j2g_edge_A_const_92; var tmp5 any = A_arbace_j2g_edge_info_data_fn__233000050_A_New(); var tmp6 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class
//line :129:1
	if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class = fncls__10d; tmp6 = fncls__10d } else { tmp6 = fncls__10
	}

	var tmp7 any = tmp2.Invoke_O_O_O__O(tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var tmp8 any = A_arbace_j2g_edge_A_const_82; var tmp9 any = A_arbace_j2g_edge_info_data_fn__233000055_A_New(); var tmp10 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class = fncls__8d; tmp10 = fncls__8d } else { tmp10 = fncls__8 }; return tmp1.Invoke_O_O_O__O(tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_62.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Invoke_O_O__O(self, p1__233000049_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O__O(p1__233000049_SHARP___1, A_arbace_j2g_edge_A_const_90); var tmp3 any = A_arbace_j2g_edge_A_const_63; var G__233000052__2_ any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_j2g_edge_A_const_65.GetRawRoot__O()); if lang.Util_Identical_O_O__Z(A_arbace_j2g_edge_A_const_63.Invoke_O__O(p1__233000049_SHARP___1), nil) {
																return lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O__O(G__233000052__2_, A_arbace_j2g_edge_A_const_63) } else {
//line :129:1
		return G__233000052__2_ } }


func A_arbace_j2g_edge_info_data_fn__233000055_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Invoke_O_O__O(self, ms__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_62.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ms__1) }
//line :133:1
func A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Ctor() {}
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Invoke_O_O__O(self, m__1 any) any { var a__2 any; if
													jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(m__1, A_arbace_j2g_edge_A_const_87)) { a__2 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_66.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_88.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__1))) } else { a__2 = nil }; var pa__3 any; if
													jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(m__1, A_arbace_j2g_edge_A_const_89)) {
														pa__3 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_62.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_66.GetRawRoot__O(), A_arbace_j2g_edge_A_const_88.GetRawRoot__O()), A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__1)) } else {
//line :135:1
			pa__3 = nil }; var G__233000057__4_ any = /*line :133:1*/lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O_O_O__O(m__1, A_arbace_j2g_edge_A_const_90, A_arbace_j2g_edge_A_const_87, A_arbace_j2g_edge_A_const_89); var G__233000057__5_ any; if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_91.Invoke_O__O(m__1))) {
		G__233000057__5_ = lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O__O(G__233000057__4_, A_arbace_j2g_edge_A_const_91) } else {
//line :137:1
			G__233000057__5_ = G__233000057__4_ }; var G__233000057__6_ any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(a__2)) {

				G__233000057__6_ = lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()).Invoke_O_O_O__O(G__233000057__5_, A_arbace_j2g_edge_A_const_87, a__2) } else {
//line :137:1
					G__233000057__6_ = G__233000057__5_ }; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_86.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_40.GetRawRoot__O(), pa__3)) {


						return lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()).Invoke_O_O_O__O(G__233000057__6_, A_arbace_j2g_edge_A_const_89, pa__3) } else {
//line :137:1
							return G__233000057__6_ } }





func A_arbace_j2g_edge_class_entry_text_A_New() *A_arbace_j2g_edge_class_entry_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Ctor() {}
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any { var info__3 any = A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1); var rest_text__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O__O(facets__1, A_arbace_j2g_edge_A_const_94)); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_8, nil); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(n__0); var tmp3 any; if



	jrt.J2g_Truth(info__3) {
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____13 any; var tmp7 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New(); var tmp8 *jrt.Class
		var fncls__15 /*line :148:1*/*jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class

		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class = fncls__15d; tmp8 = fncls__15d } else { tmp8 = fncls__15 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), A_arbace_j2g_edge_A_const_54.GetRawRoot__O()), info__3))
//line :148:1
		var tmp9 any = tmp5.Invoke_O_O__O(Lit_11, tmp6); var tmp10 *jrt.String; var more__13 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O__O(facets__1, A_arbace_j2g_edge_A_const_94)








		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(more__13)) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_95.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_edge_A_const_96; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp11.Invoke_O_O_O__O(rest_text__4, tmp12, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(rest_text__4)))).Ref()))) } else { tmp10 = nil }
//line :148:1
		tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, tmp10.Ref(), nil)).Ref() } else {
//line :147:1
			tmp3 = rest_text__4 }; return /*line :146:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, tmp3)).Ref() }



func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New() *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Invoke_O_O__O(self, s__233000062__1 any) any { var tmp1 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(self, s__233000062__1); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Ctor_O_O(c__iter__233000061, c__s__233000062 any) { t.F_iter__233000061 = c__iter__233000061; t.F_s__233000062 = c__s__233000062 }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Invoke_O__O(self any) any { { var s__233000062__1 any; var t_ any = t.F_s__233000062; t.F_s__233000062 = nil; s__233000062__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000062__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000062__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000062__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000062__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000064__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(b__233000064__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000064__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000062__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000064__6), nil) } } else { var vec__233000073__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000062__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__233000073__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__233000073__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()); var tmp5 *jrt.String; var G__233000076__7_ any = k__5
L2: switch { default: switch lang.Util_Hash_O__I(G__233000076__7_) >> 0 & 1 { case 0: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_82) {

	tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__5), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()).Invoke_O_O__O(Lit_18, lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), v__6)), nil))
//line :151:1
	break L2 }; case 1: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_92) {

		tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__5), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()).Invoke_O_O__O(Lit_18, lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), v__6)), nil))
//line :151:1
		break L2 }; default:
}

	tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__5), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(v__6)))}
//line :150:1
	var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); return tmp4.Invoke_O_O__O(tmp5.Ref(), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000062__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Ctor_O_I_O(c__b__233000064 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000064 = c__b__233000064; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Invoke_O__O(self any) any { { var i__233000063__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000063__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__233000068__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__233000068__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000064; var tmp4 *jrt.String; var G__233000071__5_ any = k__3
L2: switch { default: switch lang.Util_Hash_O__I(G__233000071__5_) >> 0 & 1 { case 0: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_82) {

	tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__3), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()).Invoke_O_O__O(Lit_18, lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), v__4)), nil))
//line :151:1
	break L2 }; case 1: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_92) {

		tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__3), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()).Invoke_O_O__O(Lit_18, lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), v__4)), nil))
//line :151:1
		break L2 }; default:
}

	tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__3), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(v__4)))}
//line :150:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Ref()); i__233000063__1 = lang.Numbers_Unchecked_inc_J__J(i__233000063__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_j2g_edge_edge_text_A_New() *A_arbace_j2g_edge_edge_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Ctor() {}
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Invoke_O_O__O(self, p__233000080__0 any) any { var map__233000081__2 any = p__233000080__0; var map__233000081__3 any; if lang.ISeq_InstanceOf(map__233000081__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_97.GetRawRoot__O()).Invoke_O__O(map__233000081__2)) { map__233000081__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_edge_A_const_98.GetRawRoot__O()).Invoke_O__O(map__233000081__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(map__233000081__2)) { map__233000081__3 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(map__233000081__2) } else { lang.PersistentArrayMap_Init(); map__233000081__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__233000081__3 = map__233000081__2 }; var edge__4 any = map__233000081__3; var classes__5 any = lang.RT_Get_O_O__O(map__233000081__3, A_arbace_j2g_edge_A_const_99); var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,7,s92:;; j2g's edge (doc/STANDALONE-NOTES.md, S2): the classes outside the forms as j2g sees them\ns84:;; on the JVM, written by bin/j2g-edge update (bin/j2g --record-edge); do not edit.\ns12:{:classes\n {ns2:}\nns2:}\n", []*jrt.Class{jrt.String_class}); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()); var tmp3 any; var iter__1927001039__auto____13 any; var tmp4 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New(); var tmp5 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class; if





	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class = fncls__18d; tmp5 = fncls__18d } else { tmp5 = fncls__18 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_54.GetRawRoot__O(), classes__5)); var tmp6 any = /*line :164:1*/tmp2.Invoke_O_O__O(Lit_8, tmp3); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()); var tmp8 any; var iter__1927001039__auto____13_2 any; var tmp9 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New(); var tmp10 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class; if




	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class = fncls__27d; tmp10 = fncls__27d } else { tmp10 = fncls__27 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); tmp8 = lang.IFn_Cast(iter__1927001039__auto____13_2).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_54.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_edge_A_const_83.GetRawRoot__O()).Invoke_O_O__O(edge__4, A_arbace_j2g_edge_A_const_99))); return /*line :164:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp6, nil, tmp7.Invoke_O__O(tmp8), nil)).Ref() }


func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New() *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Invoke_O_O__O(self, s__233000084__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(self, s__233000084__1); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Ctor_O_O(c__iter__233000083, c__s__233000084 any) { t.F_iter__233000083 = c__iter__233000083; t.F_s__233000084 = c__s__233000084 }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Invoke_O__O(self any) any { { var s__233000084__1 any; var t_ any = t.F_s__233000084; t.F_s__233000084 = nil; s__233000084__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000084__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000084__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000084__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000084__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000086__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(b__233000086__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000086__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000084__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000086__6), nil) } } else { var vec__233000094__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000084__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__233000094__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__233000094__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_100.GetRawRoot__O()).Invoke_O_O__O(n__5, facets__6), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000084__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Ctor_O_I_O(c__b__233000086 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000086 = c__b__233000086; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Invoke_O__O(self any) any { { var i__233000085__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000085__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000090__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000085__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__233000090__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__233000090__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000086; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_edge_A_const_100.GetRawRoot__O()).Invoke_O_O__O(n__3, facets__4)); i__233000085__1 = lang.Numbers_Unchecked_inc_J__J(i__233000085__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Invoke_O_O__O(self, s__233000100__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(self, s__233000100__1); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Ctor_O_O(c__iter__233000099, c__s__233000100 any) { t.F_iter__233000099 = c__iter__233000099; t.F_s__233000100 = c__s__233000100 }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Invoke_O__O(self any) any { { var s__233000100__1 any; var t_ any = t.F_s__233000100; t.F_s__233000100 = nil; s__233000100__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000100__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000100__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000100__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000100__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000102__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(b__233000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000102__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000100__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000102__6), nil) } } else { var vec__233000126__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000100__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__233000126__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__233000126__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_34, nil, Lit_35); var tmp6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__5); var tmp7 any

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(v__6)) {
		var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_10); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____15 any; var tmp11 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New(); var tmp12 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class = fncls__25d; tmp12 = fncls__25d } else { tmp12 = fncls__25 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), A_arbace_j2g_edge_A_const_54.GetRawRoot__O()), v__6)); tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9.Invoke_O_O__O(Lit_8, tmp10), nil)).Ref() } else {
			tmp7 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(v__6) }
//line :169:1
	var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); return tmp4.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7, nil)).Ref(), tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000100__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Ctor_O_I_O(c__b__233000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000102 = c__b__233000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Invoke_O__O(self any) any { { var i__233000101__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__233000106__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__233000106__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000102; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_34, nil, Lit_35); var tmp5 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(k__3); var tmp6 any

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(v__4)) {
		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_10); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_36.GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____13 any; var tmp10 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New(); var tmp11 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class = fncls__21d; tmp11 = fncls__21d } else { tmp11 = fncls__21 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_45.GetRawRoot__O(), A_arbace_j2g_edge_A_const_54.GetRawRoot__O()), v__4)); tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O_O__O(Lit_8, tmp9), nil)).Ref() } else {
			tmp6 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(v__4) }
//line :169:1
	tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6, nil)).Ref()); i__233000101__1 = lang.Numbers_Unchecked_inc_J__J(i__233000101__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Invoke_O_O__O(self, s__233000110__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(self, s__233000110__1); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Ctor_O_O(c__iter__233000109, c__s__233000110 any) { t.F_iter__233000109 = c__iter__233000109; t.F_s__233000110 = c__s__233000110 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Invoke_O__O(self any) any { { var s__233000110__1 any; var t_ any = t.F_s__233000110; t.F_s__233000110 = nil; s__233000110__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000110__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000110__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000110__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000110__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000112__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(b__233000112__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000112__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000110__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000112__6), nil) } } else { var vec__233000120__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000110__3); var kk__5 any = lang.RT_Nth_O_I_O__O(vec__233000120__4, lang.RT_IntCast_J__I(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O(vec__233000120__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(kk__5), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(vv__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000110__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Ctor_O_I_O(c__b__233000112 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000112 = c__b__233000112; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Invoke_O__O(self any) any { { var i__233000111__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000111__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000116__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000111__1)); var kk__3 any = lang.RT_Nth_O_I_O__O(vec__233000116__2, lang.RT_IntCast_J__I(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O(vec__233000116__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000112; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(kk__3), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(vv__4))).Ref()); i__233000111__1 = lang.Numbers_Unchecked_inc_J__J(i__233000111__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Invoke_O_O__O(self, s__233000130__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(self, s__233000130__1); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Ctor_O_O(c__iter__233000129, c__s__233000130 any) { t.F_iter__233000129 = c__iter__233000129; t.F_s__233000130 = c__s__233000130 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Invoke_O__O(self any) any { { var s__233000130__1 any; var t_ any = t.F_s__233000130; t.F_s__233000130 = nil; s__233000130__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000130__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000130__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000130__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000130__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000132__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(b__233000132__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000132__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000130__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000132__6), nil) } } else { var vec__233000140__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000130__3); var kk__5 any = lang.RT_Nth_O_I_O__O(vec__233000140__4, lang.RT_IntCast_J__I(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O(vec__233000140__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(kk__5), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(vv__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000130__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Ctor_O_I_O(c__b__233000132 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000132 = c__b__233000132; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Invoke_O__O(self any) any { { var i__233000131__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000131__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000136__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000131__1)); var kk__3 any = lang.RT_Nth_O_I_O__O(vec__233000136__2, lang.RT_IntCast_J__I(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O(vec__233000136__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000132; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(kk__3), nil, lang.IFn_Cast(A_arbace_j2g_edge_A_const_45.GetRawRoot__O()).Invoke_O__O(vv__4))).Ref()); i__233000131__1 = lang.Numbers_Unchecked_inc_J__J(i__233000131__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_recorded_edge_A_New() *A_arbace_j2g_edge_recorded_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Invoke_O_O_O__O(self, env_rec__0, j2g_rec__1_ any) any { var classes__3 any;



	lang.IFn_Cast(A_arbace_j2g_edge_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_107, nil)); var tmp1 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(env_rec__0); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; classes__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); return /*line :186:1*/ lang.IFn_Cast(A_arbace_j2g_edge_A_const_106.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_99, classes__3)), j2g_rec__1_) }
//line :181:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(p0 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Ctor_O(c__env_rec any) { t.F_env_rec = c__env_rec }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____3 any; var tmp6 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New(); var tmp7 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class = fncls__30d; tmp7 = fncls__30d } else { tmp7 = fncls__30 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp9 any; var t_ any = t.F_env_rec; t.F_env_rec = nil; tmp9 = t_; tmp5 = tmp8.Invoke_O__O(tmp9); tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }
//line :181:1
	return nil }(); lang.IFn_Cast(A_arbace_j2g_edge_A_const_75.GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New() *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Invoke_O_O__O(self, s__233000150__1 any) any { var tmp1 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(self, s__233000150__1); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Ctor_O_O(c__iter__233000149, c__s__233000150 any) { t.F_iter__233000149 = c__iter__233000149; t.F_s__233000150 = c__s__233000150 }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Invoke_O__O(self any) any { { var s__233000150__1 any; var t_ any = t.F_s__233000150; t.F_s__233000150 = nil; s__233000150__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000150__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000150__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000150__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000150__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000152__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(b__233000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000152__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000150__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000152__6), nil) } } else { var vec__233000161__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000150__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__233000161__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__233000161__4, lang.RT_IntCast_J__I(1), nil); var c__7 any
																if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_101.GetRawRoot__O()).Invoke_O_O__O(n__5, Lit_72)) { c__7 = nil } else { c__7 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_102.GetRawRoot__O()).Invoke_O__O(n__5) }
//line :182:1
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_103.GetRawRoot__O()); var tmp6 any
	var G__233000164__8_ any = facets__6
	if jrt.J2g_Truth(c__7) {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_edge_A_const_94; tmp6 = tmp7.Invoke_O_O_O__O(G__233000164__8_, tmp8, lang.IFn_Cast(A_arbace_j2g_edge_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_105.GetRawRoot__O()).Invoke_O__O(c__7))) } else {
//line :184:1
			tmp6 = G__233000164__8_ }
//line :182:1
	var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp5.Invoke_O_O__O(n__5, tmp6)), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000150__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Ctor_O_I_O(c__b__233000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000152 = c__b__233000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Invoke_O__O(self any) any { { var i__233000151__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__233000156__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__233000156__2, lang.RT_IntCast_J__I(1), nil); var c__5 any
																		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_101.GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_72)) { c__5 = nil } else { c__5 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_102.GetRawRoot__O()).Invoke_O__O(n__3) }
//line :182:1
	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000152; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_103.GetRawRoot__O()); var tmp5 any
	var G__233000159__6_ any = facets__4
	if jrt.J2g_Truth(c__5) {
		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_edge_A_const_94; tmp5 = tmp6.Invoke_O_O_O__O(G__233000159__6_, tmp7, lang.IFn_Cast(A_arbace_j2g_edge_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_105.GetRawRoot__O()).Invoke_O__O(c__5))) } else {
//line :184:1
			tmp5 = G__233000159__6_ }
//line :182:1
	tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp4.Invoke_O_O__O(n__3, tmp5))); i__233000151__1 = lang.Numbers_Unchecked_inc_J__J(i__233000151__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_edge_merge_edges_A_New() *A_arbace_j2g_edge_merge_edges_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Ctor() {}
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Invoke_O_O__O(self, edges__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_108.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_109.GetRawRoot__O(); var tmp3 any = A_arbace_j2g_edge_merge_edges_fn__233000169_A_New(); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; return tmp1.Invoke_O_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), edges__0) }
//line :191:1
func A_arbace_j2g_edge_merge_edges_fn__233000169_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Ctor() {}
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_37.GetRawRoot__O()).Invoke_O__O(a__1)) { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()).Invoke_O_O__O(a__1, b__2) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(a__1)) {
													var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_109.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), a__1, b__2) } else {
//line :191:1
		if A_arbace_j2g_edge_A_const_25 != nil { return b__2 } else { return nil } } } }
func A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Invoke_O_O_O__O(self, x__1, y__2 any) any { var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(y__2) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_106.GetRawRoot__O()).Invoke_O_O__O(x__1, y__2) } else { return y__2 } }






func A_arbace_j2g_edge_coerce_const_A_New() *A_arbace_j2g_edge_coerce_const_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_coerce_const_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_15.GetRawRoot__O()).Invoke_O__O(v__1)) { var G__233000174__3_ any = desc__0
		switch lang.Util_Hash_O__I(G__233000174__3_) { case 66: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_20) {
			return jrt.Byte_ValueOf_B__Byte(lang.RT_ByteCast_O__B(v__1)).Ref() }
//line :201:1
		case 67: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_21) {
			return jrt.Character_ValueOf_C__Character(lang.RT_CharCast_I__C(lang.RT_IntCast_O__I(v__1))).Ref() }
//line :201:1
		case 68: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_22) {

			return jrt.Double_ValueOf_D__Double(lang.RT_DoubleCast_O__D(v__1)).Ref() }
//line :201:1
		case 70: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_23) {

			return jrt.Float_ValueOf_F__Float(lang.RT_FloatCast_O__F(v__1)).Ref() }
//line :201:1
		case 73: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_24) {
			return jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(v__1)).Ref() }
//line :201:1
		case 74: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_25) {
			return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__1)).Ref() }
//line :201:1
		case 83: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_26) {
			return jrt.Short_ValueOf_S__Short(lang.RT_ShortCast_O__S(v__1)).Ref() }
//line :201:1
		case 90: if lang.Util_Equiv_O_O__Z(G__233000174__3_, Lit_27) {

			return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(v__1)).Ref() }
//line :201:1
		default:}; return v__1 } else {
//line :200:1
			return nil
		}
}



func A_arbace_j2g_edge_ann_value_A_New() *A_arbace_j2g_edge_ann_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Ctor() {}
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_63.Invoke_O__O(x__0)); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_63.Invoke_O__O(x__0), A_arbace_j2g_edge_A_const_111) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_60.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_112; var tmp4 any = A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(x__0); var tmp5 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class = fncls__35d; tmp5 = fncls__35d } else { tmp5 = fncls__35 }; return tmp2.Invoke_O_O_O__O(x__0, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } else {
//line :207:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_35.GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_edge_ann_value_fn__233000180_A_New(); var tmp11 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class = fncls__36d; tmp11 = fncls__36d } else { tmp11 = fncls__36 }; return tmp6.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), x__0)) } else {
//line :207:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_110.GetRawRoot__O()).Invoke_O__O(x__0)) {


						return lang.IFn_Cast(A_arbace_j2g_edge_A_const_62.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_115.GetRawRoot__O(), x__0) } else {
//line :207:1
							if A_arbace_j2g_edge_A_const_25 != nil { return x__0 } else { return nil } } } } }
func A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(p0 any) *A_arbace_j2g_edge_ann_value_fn__233000177_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000177_A{}; t.Ctor_O(p0); return t }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Invoke_O_O__O(self, p1__233000176_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_113.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_13.GetRawRoot__O()).Invoke_O_O__O(t.F_x, A_arbace_j2g_edge_A_const_114), p1__233000176_SHARP___1) }
func A_arbace_j2g_edge_ann_value_fn__233000180_A_New() *A_arbace_j2g_edge_ann_value_fn__233000180_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000180_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Invoke_O_O__O(self, p__233000179__1 any) any { var vec__233000181__2 any = p__233000179__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__233000181__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__233000181__2, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.IFn_Cast(A_arbace_j2g_edge_A_const_115.GetRawRoot__O()).Invoke_O__O(v__4)) }



func A_arbace_j2g_edge_info_value_A_New() *A_arbace_j2g_edge_info_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Ctor() {}
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Invoke_O_O__O(self, info__0 any) any { var n__2 any = A_arbace_j2g_edge_A_const_80.Invoke_O__O(info__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_edge_A_const_117; var tmp5 any = tmp3.Invoke_O_O_O__O(info__0, tmp4, A_arbace_j2g_edge_A_const_118.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_edge_A_const_92; var tmp7 any = A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(n__2); var tmp8 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class; if






	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class = fncls__44d; tmp8 = fncls__44d } else { tmp8 = fncls__44 }; var tmp9 any =


	tmp2.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var tmp10 any = A_arbace_j2g_edge_A_const_82; var tmp11 any = A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(n__2); var tmp12 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class = fncls__42d; tmp12 = fncls__42d } else { tmp12 = fncls__42 }; return tmp1.Invoke_O_O_O__O(tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)) }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_62.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(t.F_n); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Invoke_O_O__O(self, p1__233000186_SHARP___1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()).Invoke_O_O_O__O(p1__233000186_SHARP___1, A_arbace_j2g_edge_A_const_90, t.F_n); var tmp4 any = A_arbace_j2g_edge_A_const_117; var tmp5 any = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_j2g_edge_A_const_118.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_edge_A_const_63; return tmp1.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_j2g_edge_A_const_113.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_81.Invoke_O__O(p1__233000186_SHARP___1), A_arbace_j2g_edge_A_const_63.Invoke_O__O(p1__233000186_SHARP___1)))
}
func A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Invoke_O_O__O(self, ms__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_62.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(t.F_n); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ms__1) }
//line :224:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Invoke_O_O__O(self, m__1 any) any { var m__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()).Invoke_O_O_O__O(m__1, A_arbace_j2g_edge_A_const_90, t.F_n); var tmp4 any = A_arbace_j2g_edge_A_const_117; var tmp5 any = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_j2g_edge_A_const_118.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_edge_A_const_91; var tmp7 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New(); var tmp8 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class; if
													fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class = fncls__37d; tmp8 = fncls__37d } else { tmp8 = fncls__37 }; m__2 = tmp1.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); if
													lang.Util_Equiv_O_O__Z(Lit_63, A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__2)) { return m__2 } else { var a__3 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_115.GetRawRoot__O()); var tmp10 any; var or__1927000174__auto____3 any = A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__2)

		if jrt.J2g_Truth(or__1927000174__auto____3) { tmp10 = or__1927000174__auto____3 } else { lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY.Ref() }; a__3 = tmp9.Invoke_O__O(tmp10)
//line :226:1
		var pa__4 any; var or__1927000174__auto____4 any; var G__233000196__4_ any = A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__2)


		if lang.Util_Identical_O_O__Z(G__233000196__4_, nil) { or__1927000174__auto____4 = nil } else { or__1927000174__auto____4 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_115.GetRawRoot__O()).Invoke_O__O(G__233000196__4_) }; if jrt.J2g_Truth(or__1927000174__auto____4) { pa__4 = or__1927000174__auto____4 } else {
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_116.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_119.GetRawRoot__O()); var tmp13 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__2))))).Ref(); var tmp14 *lang.PersistentVector; lang.PersistentVector_Init(); tmp14 = lang.PersistentVector_EMPTY; pa__4 = tmp11.Invoke_O__O(tmp12.Invoke_O_O__O(tmp13, tmp14.Ref())) }
		var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_85.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_edge_A_const_87; var tmp17 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(a__3); var tmp18 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class
		if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class = fncls__38d; tmp18 = fncls__38d } else { tmp18 = fncls__38 }
//line :231:1
		var tmp19 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)); var tmp20 any = A_arbace_j2g_edge_A_const_89; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New(); var tmp23 *jrt.Class
		var fncls__40 /*line :231:1*/*jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class

		if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class = fncls__40d; tmp23 = fncls__40d } else { tmp23 = fncls__40 }
//line :231:1
		return tmp15.Invoke_O_O_O_O_O__O(m__2, tmp16, tmp19, tmp20, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), pa__4)) } }
//line :225:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Ctor() {}
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Invoke_O_O__O(self, p1__233000187_SHARP___1 any) any { var or__1927000174__auto____2 any = p1__233000187_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { lang.PersistentVector_Init(); return lang.PersistentVector_EMPTY.Ref() } }






func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Invoke_O__O(self any) any { var t_ any = t.F_a; t.F_a = nil; return t_ }
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Ctor() {}
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(x__1); var tmp2 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class = fncls__39d; tmp2 = fncls__39d } else { tmp2 = fncls__39 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :233:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Invoke_O__O(self any) any { var t_ any = t.F_x; t.F_x = nil; return t_ }


func A_arbace_j2g_edge_generics_value_A_New() *A_arbace_j2g_edge_generics_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Ctor() {}
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Invoke_O_O__O(self, g__0 any) any {
	if jrt.J2g_Truth(g__0) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_82; var tmp3 any = A_arbace_j2g_edge_generics_value_fn__233000207_A_New(); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; return tmp1.Invoke_O_O_O__O(g__0, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } else {
//line :237:1
			return nil } }
func A_arbace_j2g_edge_generics_value_fn__233000207_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Invoke_O_O__O(self, ms__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ms__1) }
//line :238:1
func A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Invoke_O_O__O(self, p1__233000206_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_117; return tmp1.Invoke_O_O_O__O(p1__233000206_SHARP___1, tmp2, A_arbace_j2g_edge_A_const_118.GetRawRoot__O()) }

func A_arbace_j2g_edge_canonical_A_New() *A_arbace_j2g_edge_canonical_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_122.GetRawRoot__O()), n__0)) { return facets__1 } else { var G__233000214__3_ any = facets__1; var G__233000214__4_ any

		if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1)) {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_60.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_123; var tmp3 any = A_arbace_j2g_edge_canonical_fn__233000215_A_New(); var tmp4 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class = fncls__47d; tmp4 = fncls__47d } else { tmp4 = fncls__47 }; G__233000214__4_ = tmp1.Invoke_O_O_O__O(G__233000214__3_, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } else {
//line :246:1
				G__233000214__4_ = G__233000214__3_ }; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_121.Invoke_O__O(facets__1)) {

					var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_60.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_edge_A_const_125; var tmp7 any = A_arbace_j2g_edge_canonical_fn__233000217_A_New(); var tmp8 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class = fncls__48d; tmp8 = fncls__48d } else { tmp8 = fncls__48 }; return tmp5.Invoke_O_O_O__O(G__233000214__4_, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {
//line :246:1
						return G__233000214__4_ } } }
func A_arbace_j2g_edge_canonical_fn__233000215_A_New() *A_arbace_j2g_edge_canonical_fn__233000215_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000215_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Ctor() {}
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Invoke_O_O__O(self, p1__233000212_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_116.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_124.GetRawRoot__O(), p1__233000212_SHARP___1)) }
func A_arbace_j2g_edge_canonical_fn__233000217_A_New() *A_arbace_j2g_edge_canonical_fn__233000217_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000217_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Ctor() {}
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Invoke_O_O__O(self, p1__233000213_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_116.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_52.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_124.GetRawRoot__O(), p1__233000213_SHARP___1)) }

func A_arbace_j2g_edge_read_edge_A_New() *A_arbace_j2g_edge_read_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_76.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_127; var tmp4 *jrt.Boolean;


	jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any = A_arbace_j2g_edge_read_edge_fn__233000220_A_New_O(f__0); var tmp6 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000220_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_j2g_edge_read_edge_fn__233000220_A_fn_class = fncls__49d; tmp6 = fncls__49d } else { tmp6 = fncls__49 }; e__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_edge_A_const_99; var tmp9 any = A_arbace_j2g_edge_read_edge_fn__233000222_A_New(); var tmp10 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class; if
	fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class = fncls__53d; tmp10 = fncls__53d } else { tmp10 = fncls__53 }; return /*line :254:1*/ tmp7.Invoke_O_O_O__O(e__2, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) }
//line :253:1
func A_arbace_j2g_edge_read_edge_fn__233000220_A_New_O(p0 any) *A_arbace_j2g_edge_read_edge_fn__233000220_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000220_A{}; t.Ctor_O(p0); return t }
//line :253:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000220_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :253:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000220_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_126.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_edge_A_const_75.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }

func A_arbace_j2g_edge_read_edge_fn__233000222_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Invoke_O_O__O(self, cs__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____2 any; var tmp5 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New(); var tmp6 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class = fncls__52d; tmp6 = fncls__52d } else { tmp6 = fncls__52 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); return tmp1.Invoke_O_O__O(tmp3, tmp4) }
//line :256:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Ctor() {}
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Invoke_O_O__O(self, s__233000224__1 any) any { var tmp1 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(s__233000224__1, self); var tmp2 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class = fncls__51d; tmp2 = fncls__51d } else { tmp2 = fncls__51 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :256:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Ctor_O_O(c__s__233000224, c__iter__233000223 any) { t.F_s__233000224 = c__s__233000224; t.F_iter__233000223 = c__iter__233000223 }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Invoke_O__O(self any) any { { var s__233000224__1 any; var t_ any = t.F_s__233000224; t.F_s__233000224 = nil; s__233000224__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000224__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000224__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000224__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000224__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000226__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(b__233000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class = fncls__50d; tmp2 = fncls__50d } else { tmp2 = fncls__50 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000226__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000224__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000226__6), nil) } } else { var vec__233000235__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000224__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__233000235__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__233000235__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()); var tmp5 any; var G__233000238__7_ any = facets__6; var G__233000238__8_ any
																if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_edge_A_const_94; G__233000238__8_ = tmp6.Invoke_O_O_O__O(G__233000238__7_, tmp7, A_arbace_j2g_edge_A_const_128.GetRawRoot__O()) } else {
//line :257:1
			G__233000238__8_ = G__233000238__7_ }; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(facets__6, A_arbace_j2g_edge_A_const_121)) {

				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_edge_A_const_121; tmp5 = tmp8.Invoke_O_O_O__O(G__233000238__8_, tmp9, A_arbace_j2g_edge_A_const_129.GetRawRoot__O()) } else {
//line :257:1
					tmp5 = G__233000238__8_ }
//line :256:1
	var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp5), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000224__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :256:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Ctor_O_I_O(c__b__233000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000226 = c__b__233000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Invoke_O__O(self any) any { { var i__233000225__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000230__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000225__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__233000230__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__233000230__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000226; var tmp4 any; var G__233000233__5_ any = facets__4; var G__233000233__6_ any
																	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_edge_A_const_94; G__233000233__6_ = tmp5.Invoke_O_O_O__O(G__233000233__5_, tmp6, A_arbace_j2g_edge_A_const_128.GetRawRoot__O()) } else {
//line :257:1
			G__233000233__6_ = G__233000233__5_ }; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_18.GetRawRoot__O()).Invoke_O_O__O(facets__4, A_arbace_j2g_edge_A_const_121)) {

				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_edge_A_const_121; tmp4 = tmp7.Invoke_O_O_O__O(G__233000233__6_, tmp8, A_arbace_j2g_edge_A_const_129.GetRawRoot__O()) } else {
//line :257:1
					tmp4 = G__233000233__6_ }
//line :256:1
	tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp4)); i__233000225__1 = lang.Numbers_Unchecked_inc_J__J(i__233000225__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_read_edge_data_A_New() *A_arbace_j2g_edge_read_edge_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Ctor() {}
//line :261:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_76.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_127; var tmp4 *jrt.Boolean;


	jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref())); var tmp5 any = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(f__0); var tmp6 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class = fncls__54d; tmp6 = fncls__54d } else { tmp6 = fncls__54 }; e__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_edge_A_const_99; var tmp9 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New(); var tmp10 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class; if
	fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class = fncls__58d; tmp10 = fncls__58d } else { tmp10 = fncls__58 }; return /*line :265:1*/ tmp7.Invoke_O_O_O__O(e__2, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) }
//line :264:1
func A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(p0 any) *A_arbace_j2g_edge_read_edge_data_fn__233000243_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000243_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_126.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_edge_A_const_75.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }

func A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Ctor() {}
//line :266:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Invoke_O_O__O(self, cs__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____2 any; var tmp5 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New(); var tmp6 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class = fncls__57d; tmp6 = fncls__57d } else { tmp6 = fncls__57 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); return tmp1.Invoke_O_O__O(tmp3, tmp4) }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Ctor() {}
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Invoke_O_O__O(self, s__233000247__1 any) any { var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(s__233000247__1, self); var tmp2 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class = fncls__56d; tmp2 = fncls__56d } else { tmp2 = fncls__56 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Ctor_O_O(c__s__233000247, c__iter__233000246 any) { t.F_s__233000247 = c__s__233000247; t.F_iter__233000246 = c__iter__233000246 }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Invoke_O__O(self any) any { { var s__233000247__1 any; var t_ any = t.F_s__233000247; t.F_s__233000247 = nil; s__233000247__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(s__233000247__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000247__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_edge_A_const_41.GetRawRoot__O()).Invoke_O__O(s__233000247__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_42.GetRawRoot__O()).Invoke_O__O(s__233000247__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__233000249__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(b__233000249__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class = fncls__55d; tmp2 = fncls__55d } else { tmp2 = fncls__55 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000249__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_50.GetRawRoot__O()).Invoke_O__O(s__233000247__3))) } else { return lang.IFn_Cast(A_arbace_j2g_edge_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_49.GetRawRoot__O()).Invoke_O__O(b__233000249__6), nil) } } else { var vec__233000258__4 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(s__233000247__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__233000258__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__233000258__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_48.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_103.GetRawRoot__O()); var tmp6 any; var G__233000261__7_ any = facets__6
																if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_edge_A_const_94; tmp6 = tmp7.Invoke_O_O_O__O(G__233000261__7_, tmp8, lang.IFn_Cast(A_arbace_j2g_edge_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_104.GetRawRoot__O(), A_arbace_j2g_edge_A_const_128.GetRawRoot__O())) } else {
//line :268:1
			tmp6 = G__233000261__7_ }
//line :267:1
	var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp5.Invoke_O_O__O(n__5, tmp6)), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_51.GetRawRoot__O()).Invoke_O__O(s__233000247__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Ctor_O_I_O(c__b__233000249 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000249 = c__b__233000249; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Invoke_O__O(self any) any { { var i__233000248__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__233000248__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000253__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__233000248__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__233000253__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__233000253__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_44.GetRawRoot__O()); var tmp3 any = t.F_b__233000249; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_103.GetRawRoot__O()); var tmp5 any; var G__233000256__5_ any = facets__4
																		if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_19.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_edge_A_const_94; tmp5 = tmp6.Invoke_O_O_O__O(G__233000256__5_, tmp7, lang.IFn_Cast(A_arbace_j2g_edge_A_const_53.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_104.GetRawRoot__O(), A_arbace_j2g_edge_A_const_128.GetRawRoot__O())) } else {
//line :268:1
			tmp5 = G__233000256__5_ }
//line :267:1
	tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp4.Invoke_O_O__O(n__3, tmp5))); i__233000248__1 = lang.Numbers_Unchecked_inc_J__J(i__233000248__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_edge_write_edge_BANG__A_New() *A_arbace_j2g_edge_write_edge_BANG__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_write_edge_BANG__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Ctor() {}
//line :271:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Invoke_O_O_O__O(self, f__0, edge__1 any) any {
	lang.IFn_Cast(A_arbace_j2g_edge_A_const_131.GetRawRoot__O()).Invoke_O__O(f__0)
	return lang.IFn_Cast(A_arbace_j2g_edge_A_const_130.GetRawRoot__O()).Invoke_O_O__O(f__0, lang.IFn_Cast(A_arbace_j2g_edge_A_const_132.GetRawRoot__O()).Invoke_O__O(edge__1))
}
func A_arbace_j2g_edge__main_A_New() *A_arbace_j2g_edge__main_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge__main_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_j2g_edge__main_A) Ctor() {}
//line :275:1
func (t *A_arbace_j2g_edge__main_A) DoInvoke_O_O_O__O(self, cmd__0, args__1 any) any { var G__233000267__3_ any = cmd__0; switch


	lang.Util_Hash_O__I(G__233000267__3_) { case 103785528: if lang.Util_Equiv_O_O__Z(G__233000267__3_, Lit_1) { var vec__233000268__4 any = args__1; var seq__233000269__5 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_40.GetRawRoot__O()).Invoke_O__O(vec__233000268__4); var first__233000270__6 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_47.GetRawRoot__O()).Invoke_O__O(seq__233000269__5); var seq__233000269__7 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_97.GetRawRoot__O()).Invoke_O__O(seq__233000269__5)
		var out__8 any = first__233000270__6; var ins__9 any = seq__233000269__7
		return lang.IFn_Cast(A_arbace_j2g_edge_A_const_133.GetRawRoot__O()).Invoke_O_O__O(out__8, lang.IFn_Cast(A_arbace_j2g_edge_A_const_134.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_edge_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_135.GetRawRoot__O(), ins__9))) }
//line :278:1
	default:}; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_39.GetRawRoot__O()); var tmp2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, cmd__0)).Ref(); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())))) }

















































































































































































































































type A_arbace_j2g_edge_A struct{ jrt.Object }

var A_arbace_j2g_edge_A_const_pool *jrt.RefArray

var A_arbace_j2g_edge_A_const_0 *lang.Var

var A_arbace_j2g_edge_A_const_1 *lang.Var

var A_arbace_j2g_edge_A_const_2 any

var A_arbace_j2g_edge_A_const_3 any

var A_arbace_j2g_edge_A_const_4 any

var A_arbace_j2g_edge_A_const_5 any

var A_arbace_j2g_edge_A_const_6 any

var A_arbace_j2g_edge_A_const_7 *lang.Var

var A_arbace_j2g_edge_A_const_8 *lang.Var

var A_arbace_j2g_edge_A_const_9 *lang.Var

var A_arbace_j2g_edge_A_const_10 any

var A_arbace_j2g_edge_A_const_11 *lang.Var

var A_arbace_j2g_edge_A_const_12 *lang.Var

var A_arbace_j2g_edge_A_const_13 *lang.Var

var A_arbace_j2g_edge_A_const_14 *lang.Var

var A_arbace_j2g_edge_A_const_15 *lang.Var

var A_arbace_j2g_edge_A_const_16 *lang.Var

var A_arbace_j2g_edge_A_const_17 *lang.Var

var A_arbace_j2g_edge_A_const_18 *lang.Var

var A_arbace_j2g_edge_A_const_19 *lang.Var

var A_arbace_j2g_edge_A_const_20 *lang.Var

var A_arbace_j2g_edge_A_const_21 *lang.Var

var A_arbace_j2g_edge_A_const_22 any

var A_arbace_j2g_edge_A_const_23 any

var A_arbace_j2g_edge_A_const_24 *lang.Var

var A_arbace_j2g_edge_A_const_25 *lang.Keyword

var A_arbace_j2g_edge_A_const_26 *lang.Var

var A_arbace_j2g_edge_A_const_27 any

var A_arbace_j2g_edge_A_const_28 any

var A_arbace_j2g_edge_A_const_29 *lang.Var

var A_arbace_j2g_edge_A_const_30 *lang.Var

var A_arbace_j2g_edge_A_const_31 *lang.Var

var A_arbace_j2g_edge_A_const_32 *lang.Var

var A_arbace_j2g_edge_A_const_33 *lang.Var

var A_arbace_j2g_edge_A_const_34 *lang.Var

var A_arbace_j2g_edge_A_const_35 *lang.Var

var A_arbace_j2g_edge_A_const_36 *lang.Var

var A_arbace_j2g_edge_A_const_37 *lang.Var

var A_arbace_j2g_edge_A_const_38 *lang.Var

var A_arbace_j2g_edge_A_const_39 *lang.Var

var A_arbace_j2g_edge_A_const_40 *lang.Var

var A_arbace_j2g_edge_A_const_41 *lang.Var

var A_arbace_j2g_edge_A_const_42 *lang.Var

var A_arbace_j2g_edge_A_const_43 *lang.Var

var A_arbace_j2g_edge_A_const_44 *lang.Var

var A_arbace_j2g_edge_A_const_45 *lang.Var

var A_arbace_j2g_edge_A_const_46 *lang.Var

var A_arbace_j2g_edge_A_const_47 *lang.Var

var A_arbace_j2g_edge_A_const_48 *lang.Var

var A_arbace_j2g_edge_A_const_49 *lang.Var

var A_arbace_j2g_edge_A_const_50 *lang.Var

var A_arbace_j2g_edge_A_const_51 *lang.Var

var A_arbace_j2g_edge_A_const_52 *lang.Var

var A_arbace_j2g_edge_A_const_53 *lang.Var

var A_arbace_j2g_edge_A_const_54 *lang.Var

var A_arbace_j2g_edge_A_const_55 *lang.Var

var A_arbace_j2g_edge_A_const_56 *lang.Var

var A_arbace_j2g_edge_A_const_57 *lang.Var

var A_arbace_j2g_edge_A_const_58 *lang.Keyword

var A_arbace_j2g_edge_A_const_59 *lang.Var

var A_arbace_j2g_edge_A_const_60 *lang.Var

var A_arbace_j2g_edge_A_const_61 *lang.Var

var A_arbace_j2g_edge_A_const_62 *lang.Var

var A_arbace_j2g_edge_A_const_63 *lang.Keyword

var A_arbace_j2g_edge_A_const_64 any

var A_arbace_j2g_edge_A_const_65 *lang.Var

var A_arbace_j2g_edge_A_const_66 *lang.Var

var A_arbace_j2g_edge_A_const_67 *lang.Var

var A_arbace_j2g_edge_A_const_68 *lang.Var

var A_arbace_j2g_edge_A_const_69 *lang.Var

var A_arbace_j2g_edge_A_const_70 *lang.Var

var A_arbace_j2g_edge_A_const_71 *lang.Var

var A_arbace_j2g_edge_A_const_72 any

var A_arbace_j2g_edge_A_const_73 *lang.Var

var A_arbace_j2g_edge_A_const_74 *lang.Var

var A_arbace_j2g_edge_A_const_75 *lang.Var

var A_arbace_j2g_edge_A_const_76 *lang.Var

var A_arbace_j2g_edge_A_const_77 *lang.Var

var A_arbace_j2g_edge_A_const_78 *lang.Var

var A_arbace_j2g_edge_A_const_79 *lang.Var

var A_arbace_j2g_edge_A_const_80 *lang.Keyword

var A_arbace_j2g_edge_A_const_81 *lang.Keyword

var A_arbace_j2g_edge_A_const_82 *lang.Keyword

var A_arbace_j2g_edge_A_const_83 *lang.Var

var A_arbace_j2g_edge_A_const_84 *lang.Var

var A_arbace_j2g_edge_A_const_85 *lang.Var

var A_arbace_j2g_edge_A_const_86 *lang.Var

var A_arbace_j2g_edge_A_const_87 *lang.Keyword

var A_arbace_j2g_edge_A_const_88 *lang.Var

var A_arbace_j2g_edge_A_const_89 *lang.Keyword

var A_arbace_j2g_edge_A_const_90 *lang.Keyword

var A_arbace_j2g_edge_A_const_91 *lang.Keyword

var A_arbace_j2g_edge_A_const_92 *lang.Keyword

var A_arbace_j2g_edge_A_const_93 *lang.Keyword

var A_arbace_j2g_edge_A_const_94 *lang.Keyword

var A_arbace_j2g_edge_A_const_95 *lang.Var

var A_arbace_j2g_edge_A_const_96 any

var A_arbace_j2g_edge_A_const_97 *lang.Var

var A_arbace_j2g_edge_A_const_98 *lang.Var

var A_arbace_j2g_edge_A_const_99 *lang.Keyword

var A_arbace_j2g_edge_A_const_100 *lang.Var

var A_arbace_j2g_edge_A_const_101 *lang.Var

var A_arbace_j2g_edge_A_const_102 *lang.Var

var A_arbace_j2g_edge_A_const_103 *lang.Var

var A_arbace_j2g_edge_A_const_104 *lang.Var

var A_arbace_j2g_edge_A_const_105 *lang.Var

var A_arbace_j2g_edge_A_const_106 *lang.Var

var A_arbace_j2g_edge_A_const_107 *lang.Var

var A_arbace_j2g_edge_A_const_108 *lang.Var

var A_arbace_j2g_edge_A_const_109 *lang.Var

var A_arbace_j2g_edge_A_const_110 *lang.Var

var A_arbace_j2g_edge_A_const_111 *lang.Keyword

var A_arbace_j2g_edge_A_const_112 any

var A_arbace_j2g_edge_A_const_113 *lang.Var

var A_arbace_j2g_edge_A_const_114 any

var A_arbace_j2g_edge_A_const_115 *lang.Var

var A_arbace_j2g_edge_A_const_116 *lang.Var

var A_arbace_j2g_edge_A_const_117 *lang.Keyword

var A_arbace_j2g_edge_A_const_118 *lang.Var

var A_arbace_j2g_edge_A_const_119 *lang.Var

var A_arbace_j2g_edge_A_const_120 *lang.Var

var A_arbace_j2g_edge_A_const_121 *lang.Keyword

var A_arbace_j2g_edge_A_const_122 *lang.Var

var A_arbace_j2g_edge_A_const_123 any

var A_arbace_j2g_edge_A_const_124 *lang.Var

var A_arbace_j2g_edge_A_const_125 any

var A_arbace_j2g_edge_A_const_126 *lang.Var

var A_arbace_j2g_edge_A_const_127 *lang.Var

var A_arbace_j2g_edge_A_const_128 *lang.Var

var A_arbace_j2g_edge_A_const_129 *lang.Var

var A_arbace_j2g_edge_A_const_130 *lang.Var

var A_arbace_j2g_edge_A_const_131 *lang.Var

var A_arbace_j2g_edge_A_const_132 *lang.Var

var A_arbace_j2g_edge_A_const_133 *lang.Var

var A_arbace_j2g_edge_A_const_134 *lang.Var

var A_arbace_j2g_edge_A_const_135 *lang.Var

var A_arbace_j2g_edge_A_init jrt.ClassInit

func A_arbace_j2g_edge_A_Init() { if !A_arbace_j2g_edge_A_init.Done() { A_arbace_j2g_edge_A_init.Run(A_arbace_j2g_edge_A_clinit) } }

func A_arbace_j2g_edge_A_clinit() { A_arbace_j2g_edge_A_clinit_p0(); A_arbace_j2g_edge_A_clinit_p1(); A_arbace_j2g_edge_A_clinit_p2(); A_arbace_j2g_edge_A_clinit_p3(); A_arbace_j2g_edge_A_clinit_p4(); A_arbace_j2g_edge_A_clinit_p5(); A_arbace_j2g_edge_A_clinit_p6(); A_arbace_j2g_edge_A_clinit_p7(); A_arbace_j2g_edge_A_clinit_p8(); A_arbace_j2g_edge_A_clinit_p9(); A_arbace_j2g_edge_A_clinit_p10(); A_arbace_j2g_edge_A_clinit_p11() }

func A_arbace_j2g_edge_A_clinit_p0() { A_arbace_j2g_edge_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 165); A_arbace_j2g_edge_A_const_0 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[29]); A_arbace_j2g_edge_A_const_1 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[30]); A_arbace_j2g_edge_A_const_2 = A_arbace_j2g_edge_A_const_pool.A[31]; A_arbace_j2g_edge_A_const_3 = A_arbace_j2g_edge_A_const_pool.A[32]; A_arbace_j2g_edge_A_const_4 = A_arbace_j2g_edge_A_const_pool.A[33]; A_arbace_j2g_edge_A_const_5 = A_arbace_j2g_edge_A_const_pool.A[34]; A_arbace_j2g_edge_A_const_6 = A_arbace_j2g_edge_A_const_pool.A[35]; A_arbace_j2g_edge_A_const_7 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[36]); A_arbace_j2g_edge_A_const_8 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[37]); A_arbace_j2g_edge_A_const_9 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[38]); A_arbace_j2g_edge_A_const_10 = A_arbace_j2g_edge_A_const_pool.A[39]; A_arbace_j2g_edge_A_const_11 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[40]); A_arbace_j2g_edge_A_const_12 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[41]) }

func A_arbace_j2g_edge_A_clinit_p1() { A_arbace_j2g_edge_A_const_13 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[42]); A_arbace_j2g_edge_A_const_14 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[43]); A_arbace_j2g_edge_A_const_15 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[44]); A_arbace_j2g_edge_A_const_16 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[45]); A_arbace_j2g_edge_A_const_17 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[46]); A_arbace_j2g_edge_A_const_18 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[47]); A_arbace_j2g_edge_A_const_19 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[48]); A_arbace_j2g_edge_A_const_20 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[49]); A_arbace_j2g_edge_A_const_21 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[50]); A_arbace_j2g_edge_A_const_22 = A_arbace_j2g_edge_A_const_pool.A[51]; A_arbace_j2g_edge_A_const_23 = A_arbace_j2g_edge_A_const_pool.A[52]; A_arbace_j2g_edge_A_const_24 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[53]) }

func A_arbace_j2g_edge_A_clinit_p2() { A_arbace_j2g_edge_A_const_25 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[54]); A_arbace_j2g_edge_A_const_26 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[55]); A_arbace_j2g_edge_A_const_27 = A_arbace_j2g_edge_A_const_pool.A[56]; A_arbace_j2g_edge_A_const_28 = A_arbace_j2g_edge_A_const_pool.A[57]; A_arbace_j2g_edge_A_const_29 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[58]); A_arbace_j2g_edge_A_const_30 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[59]); A_arbace_j2g_edge_A_const_31 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[60]); A_arbace_j2g_edge_A_const_32 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[61]); A_arbace_j2g_edge_A_const_33 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[62]); A_arbace_j2g_edge_A_const_34 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[63]); A_arbace_j2g_edge_A_const_35 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[64]); A_arbace_j2g_edge_A_const_36 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[65]) }

func A_arbace_j2g_edge_A_clinit_p3() { A_arbace_j2g_edge_A_const_37 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[66]); A_arbace_j2g_edge_A_const_38 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[67]); A_arbace_j2g_edge_A_const_39 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[68]); A_arbace_j2g_edge_A_const_40 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[69]); A_arbace_j2g_edge_A_const_41 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[70]); A_arbace_j2g_edge_A_const_42 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[71]); A_arbace_j2g_edge_A_const_43 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[72]); A_arbace_j2g_edge_A_const_44 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[73]); A_arbace_j2g_edge_A_const_45 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[74]); A_arbace_j2g_edge_A_const_46 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[75]); A_arbace_j2g_edge_A_const_47 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[76]); A_arbace_j2g_edge_A_const_48 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[77]) }

func A_arbace_j2g_edge_A_clinit_p4() { A_arbace_j2g_edge_A_const_49 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[78]); A_arbace_j2g_edge_A_const_50 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[79]); A_arbace_j2g_edge_A_const_51 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[80]); A_arbace_j2g_edge_A_const_52 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[81]); A_arbace_j2g_edge_A_const_53 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[82]); A_arbace_j2g_edge_A_const_54 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[83]); A_arbace_j2g_edge_A_const_55 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[84]); A_arbace_j2g_edge_A_const_56 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[85]); A_arbace_j2g_edge_A_const_57 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[86]); A_arbace_j2g_edge_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[87]); A_arbace_j2g_edge_A_const_59 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[88]); A_arbace_j2g_edge_A_const_60 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[89]) }

func A_arbace_j2g_edge_A_clinit_p5() { A_arbace_j2g_edge_A_const_61 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[90]); A_arbace_j2g_edge_A_const_62 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[91]); A_arbace_j2g_edge_A_const_63 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[92]); A_arbace_j2g_edge_A_const_64 = A_arbace_j2g_edge_A_const_pool.A[93]; A_arbace_j2g_edge_A_const_65 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[94]); A_arbace_j2g_edge_A_const_66 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[95]); A_arbace_j2g_edge_A_const_67 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[96]); A_arbace_j2g_edge_A_const_68 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[97]); A_arbace_j2g_edge_A_const_69 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[98]); A_arbace_j2g_edge_A_const_70 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[99]); A_arbace_j2g_edge_A_const_71 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[100]); A_arbace_j2g_edge_A_const_72 = A_arbace_j2g_edge_A_const_pool.A[101] }

func A_arbace_j2g_edge_A_clinit_p6() { A_arbace_j2g_edge_A_const_73 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[102]); A_arbace_j2g_edge_A_const_74 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[103]); A_arbace_j2g_edge_A_const_75 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[104]); A_arbace_j2g_edge_A_const_76 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[105]); A_arbace_j2g_edge_A_const_77 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[106]); A_arbace_j2g_edge_A_const_78 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[107]); A_arbace_j2g_edge_A_const_79 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[108]); A_arbace_j2g_edge_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[109]); A_arbace_j2g_edge_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[110]); A_arbace_j2g_edge_A_const_82 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[111]); A_arbace_j2g_edge_A_const_83 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[112]); A_arbace_j2g_edge_A_const_84 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[113]) }

func A_arbace_j2g_edge_A_clinit_p7() { A_arbace_j2g_edge_A_const_85 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[114]); A_arbace_j2g_edge_A_const_86 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[115]); A_arbace_j2g_edge_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[116]); A_arbace_j2g_edge_A_const_88 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[117]); A_arbace_j2g_edge_A_const_89 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[118]); A_arbace_j2g_edge_A_const_90 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[119]); A_arbace_j2g_edge_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[120]); A_arbace_j2g_edge_A_const_92 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[121]); A_arbace_j2g_edge_A_const_93 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[122]); A_arbace_j2g_edge_A_const_94 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[123]); A_arbace_j2g_edge_A_const_95 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[124]); A_arbace_j2g_edge_A_const_96 = A_arbace_j2g_edge_A_const_pool.A[125] }

func A_arbace_j2g_edge_A_clinit_p8() { A_arbace_j2g_edge_A_const_97 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[126]); A_arbace_j2g_edge_A_const_98 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[127]); A_arbace_j2g_edge_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[128]); A_arbace_j2g_edge_A_const_100 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[129]); A_arbace_j2g_edge_A_const_101 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[130]); A_arbace_j2g_edge_A_const_102 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[131]); A_arbace_j2g_edge_A_const_103 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[132]); A_arbace_j2g_edge_A_const_104 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[133]); A_arbace_j2g_edge_A_const_105 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[134]); A_arbace_j2g_edge_A_const_106 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[135]); A_arbace_j2g_edge_A_const_107 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[136]); A_arbace_j2g_edge_A_const_108 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[137]) }

func A_arbace_j2g_edge_A_clinit_p9() { A_arbace_j2g_edge_A_const_109 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[138]); A_arbace_j2g_edge_A_const_110 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[139]); A_arbace_j2g_edge_A_const_111 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[140]); A_arbace_j2g_edge_A_const_112 = A_arbace_j2g_edge_A_const_pool.A[141]; A_arbace_j2g_edge_A_const_113 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[142]); A_arbace_j2g_edge_A_const_114 = A_arbace_j2g_edge_A_const_pool.A[143]; A_arbace_j2g_edge_A_const_115 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[144]); A_arbace_j2g_edge_A_const_116 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[145]); A_arbace_j2g_edge_A_const_117 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[146]); A_arbace_j2g_edge_A_const_118 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[147]); A_arbace_j2g_edge_A_const_119 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[148]); A_arbace_j2g_edge_A_const_120 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[149]) }

func A_arbace_j2g_edge_A_clinit_p10() { A_arbace_j2g_edge_A_const_121 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[150]); A_arbace_j2g_edge_A_const_122 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[151]); A_arbace_j2g_edge_A_const_123 = A_arbace_j2g_edge_A_const_pool.A[152]; A_arbace_j2g_edge_A_const_124 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[153]); A_arbace_j2g_edge_A_const_125 = A_arbace_j2g_edge_A_const_pool.A[154]; A_arbace_j2g_edge_A_const_126 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[155]); A_arbace_j2g_edge_A_const_127 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[156]); A_arbace_j2g_edge_A_const_128 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[157]); A_arbace_j2g_edge_A_const_129 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[158]); A_arbace_j2g_edge_A_const_130 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[159]); A_arbace_j2g_edge_A_const_131 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[160]); A_arbace_j2g_edge_A_const_132 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[161]) }

func A_arbace_j2g_edge_A_clinit_p11() { A_arbace_j2g_edge_A_const_133 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[162]); A_arbace_j2g_edge_A_const_134 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[163]); A_arbace_j2g_edge_A_const_135 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[164]) }

func A_arbace_j2g_edge_A_New() *A_arbace_j2g_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_A) Ctor() {}

func (t *A_arbace_j2g_edge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_A_class }

func (t *A_arbace_j2g_edge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_A); return ok }

func A_arbace_j2g_edge_A_Cast(x any) *A_arbace_j2g_edge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_A_class)) }; return v }



type A_arbace_j2g_edge__main_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge__main_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_fn__233000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000177_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000180_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000217_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A struct{ j2g_header uint64; F_iter__233000061, F_s__233000062 any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A struct{ j2g_header uint64; F_b__233000064 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class *jrt.Class



type A_arbace_j2g_edge_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_coerce_const_A_fn_class *jrt.Class



type A_arbace_j2g_edge_const_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_const_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A struct{ j2g_header uint64; F_iter__233000083, F_s__233000084 any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A struct{ j2g_header uint64; F_b__233000086 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A struct{ j2g_header uint64; F_iter__233000099, F_s__233000100 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A struct{ j2g_header uint64; F_b__233000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A struct{ j2g_header uint64; F_iter__233000109, F_s__233000110 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A struct{ j2g_header uint64; F_b__233000112 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A struct{ j2g_header uint64; F_iter__233000129, F_s__233000130 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A struct{ j2g_header uint64; F_b__233000132 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000004_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000004_A_New() *A_arbace_j2g_edge_eval233000004_A { t := &A_arbace_j2g_edge_eval233000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000004_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000004_A_class }

func (t *A_arbace_j2g_edge_eval233000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000004_A); return ok }

func A_arbace_j2g_edge_eval233000004_A_Cast(x any) *A_arbace_j2g_edge_eval233000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000004_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000008_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000008_A_New() *A_arbace_j2g_edge_eval233000008_A { t := &A_arbace_j2g_edge_eval233000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000008_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000008_A_class }

func (t *A_arbace_j2g_edge_eval233000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000008_A); return ok }

func A_arbace_j2g_edge_eval233000008_A_Cast(x any) *A_arbace_j2g_edge_eval233000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000008_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000008_fn__233000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000008_fn__233000009_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000045_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A struct{ j2g_header uint64; F_a any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class *jrt.Class



type A_arbace_j2g_edge_method_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_method_key_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A struct{ j2g_header uint64; F_s__233000017, F_iter__233000016 any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A struct{ j2g_header uint64; F_b__233000019 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_double_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_double_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_string_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_string_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000220_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_edge_read_edge_fn__233000220_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A struct{ j2g_header uint64; F_s__233000224, F_iter__233000223 any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A struct{ j2g_header uint64; F_b__233000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000243_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A struct{ j2g_header uint64; F_s__233000247, F_iter__233000246 any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A struct{ j2g_header uint64; F_b__233000249 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_A struct{ j2g_header uint64; F_env_rec any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A struct{ j2g_header uint64; F_iter__233000149, F_s__233000150 any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A struct{ j2g_header uint64; F_b__233000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class *jrt.Class



type A_arbace_j2g_edge_write_edge_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_write_edge_BANG__A_fn_class *jrt.Class
