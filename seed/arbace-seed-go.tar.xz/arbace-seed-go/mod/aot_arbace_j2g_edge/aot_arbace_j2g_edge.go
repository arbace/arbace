//line aot_arbace_j2g_edge.ae:1
package aot_arbace_j2g_edge

import (
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_New() *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_edge_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_edge_A_const_1, A_arbace_j2g_edge_A_const_2, A_arbace_j2g_edge_A_const_3, A_arbace_j2g_edge_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_edge_eval233000008_fn__233000009_A_New() *A_arbace_j2g_edge_eval233000008_fn__233000009_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000008_fn__233000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_7.GetRawRoot__O()); var tmp2 any; var root_12 any = A_arbace_j2g_edge_A_const_8.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = A_arbace_j2g_edge_A_const_9; if linked_13 == nil { tmp2 = ifn_14.Invoke_O__O(arg_15) } else { tmp2 = linked_13.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_12, arg_15) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_edge_A_const_10.GetRawRoot__O(), A_arbace_j2g_edge_A_const_11) }



























func A_arbace_j2g_edge_jvm_A_New() *A_arbace_j2g_edge_jvm_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {



	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		var root_22 any = A_arbace_j2g_edge_A_const_13.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_edge_A_const_12.Get__O(); var arg_26 any = lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1); if linked_23 == nil { return ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { return linked_23.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) } } else {
//line :33:1
			var v__4 any = lang.IFn_Cast(f__2).Invoke__O(); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_27 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = v__4; if linked_28 == nil { tmp1 = ifn_29.Invoke_O__O(arg_30) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_27, arg_30) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var root_31 any = A_arbace_j2g_edge_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = A_arbace_j2g_edge_A_const_14.Get__O(); var arg_35 any = A_arbace_j2g_edge_A_const_17.GetRawRoot__O(); var arg_36 any = lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1); var arg_37 any = v__4; if linked_32 == nil { ifn_33.Invoke_O_O_O_O__O(arg_34, arg_35, arg_36, arg_37) } else { linked_32.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_31, arg_34, arg_35, arg_36, arg_37) } }
//line :33:1
			return v__4
		}
}



func A_arbace_j2g_edge_jvm_QMARK__A_New() *A_arbace_j2g_edge_jvm_QMARK__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_QMARK__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {


	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		var root_38 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_edge_A_const_12.Get__O(), section__0); var arg_42 any = k__1; if linked_39 == nil { return ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { return linked_39.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_38, arg_41, arg_42) } } else {
//line :42:1
			var v__4 bool = lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(f__2).Invoke__O()); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(v__4).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_16.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_14.Get__O(); var tmp4 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var tmp5 any; var root_43 any = A_arbace_j2g_edge_A_const_20.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = A_arbace_j2g_edge_A_const_10.GetRawRoot__O(); var arg_47 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_44 == nil { tmp5 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { tmp5 = linked_44.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, section__0, tmp5, k__1) }
//line :42:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(v__4).Ref()
		}
}







func A_arbace_j2g_edge_pr_string_A_New() *A_arbace_j2g_edge_pr_string_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_string_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Ctor() {}
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_79); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(s__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__4))

		if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_22)).CharValue__C()) { jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_80) } else { if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_23)).CharValue__C()) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_81) } else {
//line :56:1
				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_25; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(c__5)).Ref(), A_arbace_j2g_edge_A_const_26)) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(c__5) } else {
//line :56:1
						if A_arbace_j2g_edge_A_const_27 != nil {


							jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_j2g_edge_A_const_28.GetRawRoot__O()).Invoke_O_O__O(Lit_82, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(c__5)).Ref()))) } } } }
//line :54:1
		i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :52:1
	break L1 }; var root_56 any =







	A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_79).Ref(); if linked_57 == nil { return ifn_58.Invoke_O__O(arg_59) } else { return linked_57.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_56, arg_59) } }

func A_arbace_j2g_edge_pr_double_A_New() *A_arbace_j2g_edge_pr_double_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_double_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Ctor() {}
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); if
										jrt.Double_IsNaN_D__Z_NoInit(d__0) { return Lit_76 } else { if lang.Util_Equiv_D_D__Z_NoInit(d__0, jrt.PosInf64) { return Lit_77 } else { if lang.Util_Equiv_D_D__Z_NoInit(d__0, jrt.NegInf64) { return Lit_78 } else { if A_arbace_j2g_edge_A_const_27 != nil {


		return jrt.Double_ToString_D__String_NoInit(d__0).Ref() } else {
//line :63:1
			return nil } } } } }




func A_arbace_j2g_edge_pr_data_A_New() *A_arbace_j2g_edge_pr_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Ctor() {}
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Invoke_O_O__O(self, x__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return Lit_69 } else { var tmp1 any; var root_71 any = A_arbace_j2g_edge_A_const_29.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_73 lang.IFn

		if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = x__0; if linked_72 == nil { tmp1 = ifn_73.Invoke_O__O(arg_74) } else { tmp1 = linked_72.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_71, arg_74) }
//line :71:1
		if jrt.J2g_Truth(tmp1) {

			var root_75 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = x__0; if linked_76 == nil { return ifn_77.Invoke_O__O(arg_78) } else { return linked_76.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_75, arg_78) } } else {
//line :71:1
				var tmp2 any; var root_79 any = A_arbace_j2g_edge_A_const_30.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_81 lang.IFn


				if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = x__0; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_79, arg_82) }
//line :71:1
				if jrt.J2g_Truth(tmp2) {


					var root_83 any = A_arbace_j2g_edge_A_const_31.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, A_arbace_j2g_edge_pr_string_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = x__0; if linked_84 == nil { return ifn_85.Invoke_O__O(arg_86) } else { return linked_84.(*A_arbace_j2g_edge_pr_string_A).Invoke_O_O__O(root_83, arg_86) } } else {
//line :71:1
						var tmp3 any; var root_87 any = A_arbace_j2g_edge_A_const_32.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_89 lang.IFn



						if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = x__0; if linked_88 == nil { tmp3 = ifn_89.Invoke_O__O(arg_90) } else { tmp3 = linked_88.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_87, arg_90) }
//line :71:1
						if jrt.J2g_Truth(tmp3) {



							var root_91 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = x__0; if linked_92 == nil { return ifn_93.Invoke_O__O(arg_94) } else { return linked_92.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_91, arg_94) } } else {
//line :71:1
								var tmp4 any; var root_95 any = A_arbace_j2g_edge_A_const_33.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_97 lang.IFn




								if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = x__0; if linked_96 == nil { tmp4 = ifn_97.Invoke_O__O(arg_98) } else { tmp4 = linked_96.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_95, arg_98) }
//line :71:1
								if jrt.J2g_Truth(tmp4) {




									var root_99 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = x__0; if linked_100 == nil { return ifn_101.Invoke_O__O(arg_102) } else { return linked_100.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_99, arg_102) } } else {
//line :71:1
										var tmp5 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)





										if or__1927000174__auto____2 { tmp5 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp5 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp5 = or__1927000174__auto____4 } else { tmp5 = jrt.Byte_InstanceOf(x__0) } } }
//line :71:1
										if tmp5 {





											var root_103 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = x__0; if linked_104 == nil { return ifn_105.Invoke_O__O(arg_106) } else { return linked_104.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_103, arg_106) } } else {
//line :71:1
												var tmp6 bool; var or__1927000174__auto____2_2 bool = jrt.Double_InstanceOf(x__0)






												if or__1927000174__auto____2_2 { tmp6 = or__1927000174__auto____2_2 } else { tmp6 = jrt.Float_InstanceOf(x__0) }
//line :71:1
												if tmp6 {






													var root_107 any = A_arbace_j2g_edge_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_j2g_edge_pr_double_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__0)).Ref(); if linked_108 == nil { return ifn_109.Invoke_O__O(arg_110) } else { return linked_108.(*A_arbace_j2g_edge_pr_double_A).Invoke_O_O__O(root_107, arg_110) } } else {
//line :71:1
														if jrt.Character_InstanceOf(x__0) {







															var root_111 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(lang.RT_CharCast_O__C_NoInit(x__0))).Ref(); if linked_112 == nil { return ifn_113.Invoke_O__O(arg_114) } else { return linked_112.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_111, arg_114) } } else {
//line :71:1
																var tmp7 any; var root_115 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn








																if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = x__0; if linked_116 == nil { tmp7 = ifn_117.Invoke_O__O(arg_118) } else { tmp7 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }
//line :71:1
																if jrt.J2g_Truth(tmp7) {








																	var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_10); var tmp9 any; var root_204 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = Lit_19; var arg_208 any; var iter__1927001039__auto____5 any; var tmp10 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New(); var tmp11 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class = fncls__193d; tmp11 = fncls__193d } else { tmp11 = fncls__193 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp12 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp13 any; var root_199 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_194 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_198 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_195 == nil { arg_202 = ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { arg_202 = linked_195.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_194, arg_197, arg_198) }; var arg_203 any = x__0; if linked_200 == nil { tmp13 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { tmp13 = linked_200.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; arg_208 = tmp12.Invoke_O__O(tmp13); if linked_205 == nil { tmp9 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { tmp9 = linked_205.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() } else {
//line :71:1
																		var tmp14 any; var root_209 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_211 lang.IFn









																		if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = x__0; if linked_210 == nil { tmp14 = ifn_211.Invoke_O__O(arg_212) } else { tmp14 = linked_210.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_209, arg_212) }
//line :71:1
																		if jrt.J2g_Truth(tmp14) {









																			var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_10); var tmp16 any; var root_222 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = Lit_19; var arg_226 any; var root_218 any = A_arbace_j2g_edge_A_const_53.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var root_213 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_217 any = x__0; if linked_214 == nil { arg_221 = ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { arg_221 = linked_214.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }; if linked_219 == nil { arg_226 = ifn_220.Invoke_O__O(arg_221) } else { arg_226 = linked_219.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_218, arg_221) }; if linked_223 == nil { tmp16 = ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { tmp16 = linked_223.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16, nil)).Ref() } else {
//line :71:1
																				var tmp17 any; var root_227 any = A_arbace_j2g_edge_A_const_55.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_229 lang.IFn










																				if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = x__0; if linked_228 == nil { tmp17 = ifn_229.Invoke_O__O(arg_230) } else { tmp17 = linked_228.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_227, arg_230) }
//line :71:1
																				if jrt.J2g_Truth(tmp17) {










																					var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_17); var tmp19 any; var root_236 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = Lit_19; var arg_240 any; var root_231 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_235 any = x__0; if linked_232 == nil { arg_240 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { arg_240 = linked_232.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }; if linked_237 == nil { tmp19 = ifn_238.Invoke_O_O__O(arg_239, arg_240) } else { tmp19 = linked_237.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_236, arg_239, arg_240) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil)).Ref() } else {
//line :71:1
																						if A_arbace_j2g_edge_A_const_27 != nil { var tmp20 any; var root_249 any = A_arbace_j2g_edge_A_const_56.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_251 lang.IFn











																							if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_73, nil); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_57.GetRawRoot__O()); var tmp23 any; var root_241 any = A_arbace_j2g_edge_A_const_58.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = x__0; if linked_242 == nil { tmp23 = ifn_243.Invoke_O__O(arg_244) } else { tmp23 = linked_242.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_241, arg_244) }; arg_252 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22.Invoke_O__O(tmp23))).Ref(); var arg_253 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_59, x__0)); if linked_250 == nil { tmp20 = ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { tmp20 = linked_250.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_249, arg_252, arg_253) }
//line :71:1
																							panic(jrt.Thrown(jrt.Throwable_Cast(tmp20))) } else { return nil
																							}
																					}
																			}
																	}
															}
													}
											}
									} } } } } }
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New() *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Ctor() {}
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Invoke_O_O__O(self, s__233000017__1 any) any { var tmp1 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(s__233000017__1, self); var tmp2 *jrt.Class; var fncls__192 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class; if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class = fncls__192d; tmp2 = fncls__192d } else { tmp2 = fncls__192 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Ctor_O_O(c__s__233000017, c__iter__233000016 any) { t.F_s__233000017 = c__s__233000017; t.F_iter__233000016 = c__iter__233000016 }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Invoke_O__O(self any) any { { var s__233000017__1 any; var t_ any = t.F_s__233000017; t.F_s__233000017 = nil; s__233000017__1 = t_; for { var temp__1927000414__auto____2 any; var root_119 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = s__233000017__1; if linked_120 == nil { temp__1927000414__auto____2 = ifn_121.Invoke_O__O(arg_122) } else { temp__1927000414__auto____2 = linked_120.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_119, arg_122) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000017__3 any = temp__1927000414__auto____2; var tmp1 any; var root_123 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = s__233000017__3; if linked_124 == nil { tmp1 = ifn_125.Invoke_O__O(arg_126) } else { tmp1 = linked_124.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_123, arg_126) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_127 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = s__233000017__3; if linked_128 == nil { c__1927001037__auto____4 = ifn_129.Invoke_O__O(arg_130) } else { c__1927001037__auto____4 = linked_128.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_127, arg_130) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000019__6 any; var root_131 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_132 == nil { b__233000019__6 = ifn_133.Invoke_O__O(arg_134) } else { b__233000019__6 = linked_132.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_131, arg_134) }; var tmp2 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(b__233000019__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_157 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_149 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = b__233000019__6; if linked_150 == nil { arg_160 = ifn_151.Invoke_O__O(arg_152) } else { arg_160 = linked_150.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_149, arg_152) }; var arg_161 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); var tmp5 any; var root_153 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = s__233000017__3; if linked_154 == nil { tmp5 = ifn_155.Invoke_O__O(arg_156) } else { tmp5 = linked_154.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_153, arg_156) }; arg_161 = tmp4.Invoke_O__O(tmp5); if linked_158 == nil { return ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { return linked_158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) } } else { var root_166 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any; var root_162 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = b__233000019__6; if linked_163 == nil { arg_169 = ifn_164.Invoke_O__O(arg_165) } else { arg_169 = linked_163.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_162, arg_165) }; var arg_170 any; if linked_167 == nil { return ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { return linked_167.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) } } } else { var vec__233000027__4 any; var root_171 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = s__233000017__3; if linked_172 == nil { vec__233000027__4 = ifn_173.Invoke_O__O(arg_174) } else { vec__233000027__4 = linked_172.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_171, arg_174) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000027__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000027__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_187 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp7 any; var root_175 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = k__5; if linked_176 == nil { tmp7 = ifn_177.Invoke_O__O(arg_178) } else { tmp7 = linked_176.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_175, arg_178) }; var tmp8 any = tmp7; var tmp9 any; var root_179 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = v__6; if linked_180 == nil { tmp9 = ifn_181.Invoke_O__O(arg_182) } else { tmp9 = linked_180.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_179, arg_182) }; arg_190 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_191 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); var tmp11 any; var root_183 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = s__233000017__3; if linked_184 == nil { tmp11 = ifn_185.Invoke_O__O(arg_186) } else { tmp11 = linked_184.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_183, arg_186) }; arg_191 = tmp10.Invoke_O__O(tmp11); if linked_188 == nil { return ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { return linked_188.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Ctor_O_I_O(c__b__233000019 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000019 = c__b__233000019; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Invoke_O__O(self any) any { { var i__233000018__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000018__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000023__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000018__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000023__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000023__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_143 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = t.F_b__233000019; var arg_147 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp3 any; var root_135 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = k__3; if linked_136 == nil { tmp3 = ifn_137.Invoke_O__O(arg_138) } else { tmp3 = linked_136.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_135, arg_138) }; var tmp4 any = tmp3; var tmp5 any; var root_139 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = v__4; if linked_140 == nil { tmp5 = ifn_141.Invoke_O__O(arg_142) } else { tmp5 = linked_140.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_139, arg_142) }; arg_147 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_144 == nil { ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { linked_144.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; i__233000018__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000018__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_const_data_A_New() *A_arbace_j2g_edge_const_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_const_data_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Invoke_O_O__O(self, v__0 any) any {


	if jrt.Character_InstanceOf(v__0) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_C__I_NoInit(lang.RT_CharCast_O__C_NoInit(v__0)))).Ref() } else { return v__0
	} }
func A_arbace_j2g_edge_ann_data_A_New() *A_arbace_j2g_edge_ann_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_254 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = x__0; if linked_255 == nil { and__1927000168__auto____2 = ifn_256.Invoke_O__O(arg_257) } else { and__1927000168__auto____2 = linked_255.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_258 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = x__0; var arg_262 any = A_arbace_j2g_edge_A_const_60; if linked_259 == nil { and__1927000168__auto____3 = ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { and__1927000168__auto____3 = linked_259.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_258, arg_261, arg_262) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_263 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); if linked_264 == nil { tmp1 = ifn_265.Invoke_O__O(arg_266) } else { tmp1 = linked_264.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_263, arg_266) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_62; return tmp2.Invoke_O_O_O__O(x__0, tmp3, A_arbace_j2g_edge_A_const_63.GetRawRoot__O()) } else {
//line :93:1
			var tmp4 any; var root_273 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_275 lang.IFn

			if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = x__0; if linked_274 == nil { tmp4 = ifn_275.Invoke_O__O(arg_276) } else { tmp4 = linked_274.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_273, arg_276) }
//line :93:1
			if jrt.J2g_Truth(tmp4) {

				var root_287 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_291 any; var root_282 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var tmp5 any = A_arbace_j2g_edge_ann_data_fn__233000035_A_New(); var tmp6 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class; if fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class = fncls__281d; tmp6 = fncls__281d } else { tmp6 = fncls__281 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_286 any = x__0; if linked_283 == nil { arg_291 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_291 = linked_283.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if linked_288 == nil { return ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { return linked_288.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) } } else {
//line :93:1
					var tmp7 any; var root_292 any = A_arbace_j2g_edge_A_const_55.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_294 lang.IFn


					if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = x__0; if linked_293 == nil { tmp7 = ifn_294.Invoke_O__O(arg_295) } else { tmp7 = linked_293.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_292, arg_295) }
//line :93:1
					if jrt.J2g_Truth(tmp7) {


						var root_296 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var arg_300 any = x__0; if linked_297 == nil { return ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { return linked_297.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) } } else {
//line :93:1
							if A_arbace_j2g_edge_A_const_27 != nil { return x__0 } else { return nil
							} } } } }
func A_arbace_j2g_edge_ann_data_fn__233000035_A_New() *A_arbace_j2g_edge_ann_data_fn__233000035_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_fn__233000035_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Invoke_O_O__O(self, p__233000034__1 any) any { var vec__233000036__2 any = p__233000034__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_277 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_j2g_edge_ann_data_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = v__4; if linked_278 == nil { tmp1 = ifn_279.Invoke_O__O(arg_280) } else { tmp1 = linked_278.(*A_arbace_j2g_edge_ann_data_A).Invoke_O_O__O(root_277, arg_280) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }










func A_arbace_j2g_edge_fn__233000042_A_New() *A_arbace_j2g_edge_fn__233000042_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Ctor() {}
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Invoke_O__O(self any) any { var f__1 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_67.GetRawRoot__O()).Invoke_O_O_O__O(jrt.System_GetProperty_String__String(Lit_43).Ref(), Lit_44, Lit_45); var tmp1 any; var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(f__1)).IsFile__Z(); if and__1927000168__auto____2 {

	var root_311 any = A_arbace_j2g_edge_A_const_68.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var root_307 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = jrt.System_GetProperty_String__String(Lit_46).Ref(); if linked_308 == nil { arg_314 = ifn_309.Invoke_O__O(arg_310) } else { arg_314 = linked_308.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_307, arg_310) }; var arg_315 any = Lit_47; if linked_312 == nil { tmp1 = ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { tmp1 = linked_312.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_311, arg_314, arg_315) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
		var root_334 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_338 any; var root_322 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any; var tmp2 any = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New(); var tmp3 *jrt.Class; var fncls__321 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class; if fncls__321 == nil { var fncls__321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class = fncls__321d; tmp3 = fncls__321d } else { tmp3 = fncls__321 }; arg_325 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_323 == nil { arg_338 = ifn_324.Invoke_O__O(arg_325) } else { arg_338 = linked_323.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_322, arg_325) }; var arg_339 any; var root_330 any = A_arbace_j2g_edge_A_const_72.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()).Invoke_O__O(f__1); if linked_331 == nil { arg_339 = ifn_332.Invoke_O__O(arg_333) } else { arg_339 = linked_331.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_330, arg_333) }; if linked_335 == nil { return ifn_336.Invoke_O_O_O__O(arg_337, arg_338, arg_339) } else { return linked_335.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_334, arg_337, arg_338, arg_339) } } else {
			var root_354 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_edge_A_const_78; var arg_357 any = tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_edge_A_const_79.Get__O()); if linked_355 == nil { ifn_356.Invoke_O__O(arg_357) } else { linked_355.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_354, arg_357) }; var tmp6 any = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New(); var tmp7 *jrt.Class; var fncls__348 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class; if fncls__348 == nil { var fncls__348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class = fncls__348d; tmp7 = fncls__348d } else { tmp7 = fncls__348 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :108:1
			return lang.PersistentHashSet_EMPTY.Ref() } }
func A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000043_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000043_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Invoke_O_O__O(self, p1__233000041_SHARP___1 any) any { var root_316 any = A_arbace_j2g_edge_A_const_70.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_j2g_edge_A_const_71; var arg_320 any = p1__233000041_SHARP___1; if linked_317 == nil { return ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { return linked_317.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_316, arg_319, arg_320) } }
func A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000045_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000045_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_74.GetRawRoot__O()).Invoke_O_O__O(Lit_50, Lit_51)
//line :110:1
	return nil }(); var root_345 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; if linked_346 == nil { ifn_347.Invoke__O() } else { linked_346.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_345) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_j2g_edge_method_key_A_New() *A_arbace_j2g_edge_method_key_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_method_key_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Ctor() {}
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Invoke_O_O__O(self, m__0 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__0), A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__0)) }






func A_arbace_j2g_edge_info_data_A_New() *A_arbace_j2g_edge_info_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Ctor() {}
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Invoke_O_O__O(self, info__0 any) any {









	var root_464 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any; var root_386 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_388 lang.IFn
//line :129:1
	if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var root_358 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_360 lang.IFn
//line :128:1
	if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = info__0; var arg_362 any = A_arbace_j2g_edge_A_const_83; if linked_359 == nil { arg_389 = ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { arg_389 = linked_359.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) }
	var arg_390 any = A_arbace_j2g_edge_A_const_84; var arg_391 any; var tmp1 any = A_arbace_j2g_edge_info_data_fn__233000050_A_New(); var tmp2 *jrt.Class; var fncls__385 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class = fncls__385d; tmp2 = fncls__385d } else { tmp2 = fncls__385 }; arg_391 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_387 == nil { arg_467 = ifn_388.Invoke_O_O_O__O(arg_389, arg_390, arg_391) } else { arg_467 = linked_387.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_386, arg_389, arg_390, arg_391)
	}

	var arg_468 any = A_arbace_j2g_edge_A_const_86; var arg_469 any; var tmp3 any = A_arbace_j2g_edge_info_data_fn__233000055_A_New(); var tmp4 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class = fncls__463d; tmp4 = fncls__463d } else { tmp4 = fncls__463 }; arg_469 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_465 == nil { return ifn_466.Invoke_O_O_O__O(arg_467, arg_468, arg_469) } else { return linked_465.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_464, arg_467, arg_468, arg_469) } }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Invoke_O_O__O(self, fs__1 any) any { var root_380 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any; var tmp1 any = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New(); var tmp2 *jrt.Class; var fncls__379 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class; if fncls__379 == nil { var fncls__379d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class = fncls__379d; tmp2 = fncls__379d } else { tmp2 = fncls__379 }; arg_383 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_384 any = fs__1; if linked_381 == nil { return ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { return linked_381.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) } }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Invoke_O_O__O(self, p1__233000049_SHARP___1 any) any { var G__233000052__2_ any; var root_368 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any; var root_363 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = p1__233000049_SHARP___1; var arg_367 any = A_arbace_j2g_edge_A_const_85; if linked_364 == nil { arg_371 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { arg_371 = linked_364.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_363, arg_366, arg_367) }; var arg_372 any = A_arbace_j2g_edge_A_const_60; var arg_373 any = A_arbace_j2g_edge_A_const_63.GetRawRoot__O(); if linked_369 == nil { G__233000052__2_ = ifn_370.Invoke_O_O_O__O(arg_371, arg_372, arg_373) } else { G__233000052__2_ = linked_369.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_368, arg_371, arg_372, arg_373) }; if lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_edge_A_const_60.Invoke_O__O(p1__233000049_SHARP___1), nil) {
																var root_374 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = G__233000052__2_; var arg_378 any = A_arbace_j2g_edge_A_const_60; if linked_375 == nil { return ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { return linked_375.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) } } else {
//line :129:1
		return G__233000052__2_ } }


func A_arbace_j2g_edge_info_data_fn__233000055_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Invoke_O_O__O(self, ms__1 any) any {
	var root_458 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any; var tmp1 any = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New(); var tmp2 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class = fncls__457d; tmp2 = fncls__457d } else { tmp2 = fncls__457 }; arg_461 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_462 any = ms__1; if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } }
//line :133:1
func A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Ctor() {}
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Invoke_O_O__O(self, m__1 any) any { var a__2 any; var tmp1 any; var root_392 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_394 lang.IFn; if
													linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = m__1; var arg_396 any = A_arbace_j2g_edge_A_const_87; if linked_393 == nil { tmp1 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { tmp1 = linked_393.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }; if jrt.J2g_Truth(tmp1) { var root_401 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, A_arbace_j2g_edge_ann_data_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any; var root_397 any = A_arbace_j2g_edge_A_const_88.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__1); if linked_398 == nil { arg_404 = ifn_399.Invoke_O__O(arg_400) } else { arg_404 = linked_398.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_397, arg_400) }; if linked_402 == nil { a__2 = ifn_403.Invoke_O__O(arg_404) } else { a__2 = linked_402.(*A_arbace_j2g_edge_ann_data_A).Invoke_O_O__O(root_401, arg_404) } } else { a__2 = nil }; var pa__3 any; var tmp2 any; var root_405 any = /*line :133:1*/A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_407 lang.IFn; if

	linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = m__1; var arg_409 any = A_arbace_j2g_edge_A_const_89; if linked_406 == nil { tmp2 = ifn_407.Invoke_O_O__O(arg_408, arg_409) } else { tmp2 = linked_406.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_405, arg_408, arg_409) }; if jrt.J2g_Truth(tmp2) {
		var root_415 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var root_410 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var arg_414 any = A_arbace_j2g_edge_A_const_88.GetRawRoot__O(); if linked_411 == nil { arg_418 = ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { arg_418 = linked_411.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) }; var arg_419 any = A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__1); if linked_416 == nil { pa__3 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { pa__3 = linked_416.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) } } else {
//line :135:1
			pa__3 = nil }; var G__233000057__4_ any = /*line :133:1*/lang.IFn_Cast(A_arbace_j2g_edge_A_const_82.GetRawRoot__O()).Invoke_O_O_O_O__O(m__1, A_arbace_j2g_edge_A_const_85, A_arbace_j2g_edge_A_const_87, A_arbace_j2g_edge_A_const_89); var G__233000057__5_ any; var tmp3 any; var root_427 any = A_arbace_j2g_edge_A_const_90.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_429 lang.IFn; if




	linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = A_arbace_j2g_edge_A_const_91.Invoke_O__O(m__1); if linked_428 == nil { tmp3 = ifn_429.Invoke_O__O(arg_430) } else { tmp3 = linked_428.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_427, arg_430) }; if /*line :137:1*/ jrt.J2g_Truth(tmp3) {
		var root_431 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = G__233000057__4_; var arg_435 any = A_arbace_j2g_edge_A_const_91; if linked_432 == nil { G__233000057__5_ = ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { G__233000057__5_ = linked_432.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_431, arg_434, arg_435) } } else {
//line :137:1
			G__233000057__5_ = G__233000057__4_ }; var G__233000057__6_ any; var tmp4 any; var root_436 any = /*line :133:1*/A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_438 lang.IFn; if





	linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = a__2; if linked_437 == nil { tmp4 = ifn_438.Invoke_O__O(arg_439) } else { tmp4 = linked_437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_436, arg_439) }; if /*line :137:1*/ jrt.J2g_Truth(tmp4) {

		var root_440 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = G__233000057__5_; var arg_444 any = A_arbace_j2g_edge_A_const_87; var arg_445 any = a__2; if linked_441 == nil { G__233000057__6_ = ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { G__233000057__6_ = linked_441.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445) } } else {
//line :137:1
			G__233000057__6_ = G__233000057__5_ }; var tmp5 any; var root_446 any = A_arbace_j2g_edge_A_const_93.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_448 lang.IFn; if


	linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var arg_450 any = pa__3; if linked_447 == nil { tmp5 = ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { tmp5 = linked_447.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_446, arg_449, arg_450) }; if /*line :137:1*/ jrt.J2g_Truth(tmp5) {


		var root_451 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = G__233000057__6_; var arg_455 any = A_arbace_j2g_edge_A_const_89; var arg_456 any = pa__3; if linked_452 == nil { return ifn_453.Invoke_O_O_O__O(arg_454, arg_455, arg_456) } else { return linked_452.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_451, arg_454, arg_455, arg_456) } } else {
//line :137:1
			return G__233000057__6_ } }





func A_arbace_j2g_edge_class_entry_text_A_New() *A_arbace_j2g_edge_class_entry_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Ctor() {}
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any { var info__3 any = A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1); var rest_text__4 any; var root_475 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_477 lang.IFn; if

	linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any; var root_470 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = facets__1; var arg_474 any = A_arbace_j2g_edge_A_const_94; if linked_471 == nil { arg_478 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { arg_478 = linked_471.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if linked_476 == nil { rest_text__4 = ifn_477.Invoke_O__O(arg_478) } else { rest_text__4 = linked_476.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_475, arg_478) }; var tmp1 /*line :146:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_8, nil); var tmp2 any; var root_479 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = n__0; if linked_480 == nil { tmp2 = ifn_481.Invoke_O__O(arg_482) } else { tmp2 = linked_480.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_479, arg_482) }; var tmp3 any = tmp2; var tmp4 any; if
	jrt.J2g_Truth(info__3) {
		var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil, Lit_10, nil, Lit_10); var tmp6 any; var root_626 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_628 lang.IFn
		if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = Lit_11; var arg_630 any; var iter__1927001039__auto____13 any; var tmp7 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New(); var tmp8 *jrt.Class; var fncls__615 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class
		if fncls__615 == nil { var fncls__615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class = fncls__615d; tmp8 = fncls__615d } else { tmp8 = fncls__615 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp10 any; var root_621 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var root_616 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_620 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_617 == nil { arg_624 = ifn_618.Invoke_O_O__O(arg_619, arg_620) } else { arg_624 = linked_617.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_616, arg_619, arg_620) }; var arg_625 any = info__3; if linked_622 == nil { tmp10 = ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { tmp10 = linked_622.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_621, arg_624, arg_625) }; arg_630 = tmp9.Invoke_O__O(tmp10)
//line :149:1
		if linked_627 == nil { tmp6 = ifn_628.Invoke_O_O__O(arg_629, arg_630) } else { tmp6 = linked_627.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_626, arg_629, arg_630) }
//line :148:1
		var tmp11 any = tmp6; var tmp12 *jrt.String; var more__13 any; var root_631 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_633 lang.IFn







		if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = facets__1; var arg_635 any = A_arbace_j2g_edge_A_const_94; if linked_632 == nil { more__13 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { more__13 = linked_632.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }
		var tmp13 any; var root_636 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = more__13; if linked_637 == nil { tmp13 = ifn_638.Invoke_O__O(arg_639) } else { tmp13 = linked_637.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_636, arg_639) }; if jrt.J2g_Truth(tmp13) { var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp15 any; var root_640 any = A_arbace_j2g_edge_A_const_95.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = rest_text__4; var arg_644 any = A_arbace_j2g_edge_A_const_96; var arg_645 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rest_text__4)))).Ref(); if linked_641 == nil { tmp15 = ifn_642.Invoke_O_O_O__O(arg_643, arg_644, arg_645) } else { tmp15 = linked_641.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_640, arg_643, arg_644, arg_645) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)) } else { tmp12 = nil }
//line :148:1
		tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, tmp12.Ref(), nil)).Ref() } else {
//line :147:1
			tmp4 = rest_text__4 }; return /*line :146:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref() }



func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New() *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Invoke_O_O__O(self, s__233000062__1 any) any { var tmp1 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(self, s__233000062__1); var tmp2 *jrt.Class; var fncls__614 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class; if fncls__614 == nil { var fncls__614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class = fncls__614d; tmp2 = fncls__614d } else { tmp2 = fncls__614 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Ctor_O_O(c__iter__233000061, c__s__233000062 any) { t.F_iter__233000061 = c__iter__233000061; t.F_s__233000062 = c__s__233000062 }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Invoke_O__O(self any) any { { var s__233000062__1 any; var t_ any = t.F_s__233000062; t.F_s__233000062 = nil; s__233000062__1 = t_; for { var temp__1927000414__auto____2 any; var root_483 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = s__233000062__1; if linked_484 == nil { temp__1927000414__auto____2 = ifn_485.Invoke_O__O(arg_486) } else { temp__1927000414__auto____2 = linked_484.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_483, arg_486) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000062__3 any = temp__1927000414__auto____2; var tmp1 any; var root_487 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = s__233000062__3; if linked_488 == nil { tmp1 = ifn_489.Invoke_O__O(arg_490) } else { tmp1 = linked_488.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_487, arg_490) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_491 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = s__233000062__3; if linked_492 == nil { c__1927001037__auto____4 = ifn_493.Invoke_O__O(arg_494) } else { c__1927001037__auto____4 = linked_492.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_491, arg_494) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000064__6 any; var root_495 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_496 == nil { b__233000064__6 = ifn_497.Invoke_O__O(arg_498) } else { b__233000064__6 = linked_496.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_495, arg_498) }; var tmp2 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(b__233000064__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class = fncls__541d; tmp3 = fncls__541d } else { tmp3 = fncls__541 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_550 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any; var root_542 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = b__233000064__6; if linked_543 == nil { arg_553 = ifn_544.Invoke_O__O(arg_545) } else { arg_553 = linked_543.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_542, arg_545) }; var arg_554 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); var tmp5 any; var root_546 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = s__233000062__3; if linked_547 == nil { tmp5 = ifn_548.Invoke_O__O(arg_549) } else { tmp5 = linked_547.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_546, arg_549) }; arg_554 = tmp4.Invoke_O__O(tmp5); if linked_551 == nil { return ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { return linked_551.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) } } else { var root_559 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any; var root_555 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = b__233000064__6; if linked_556 == nil { arg_562 = ifn_557.Invoke_O__O(arg_558) } else { arg_562 = linked_556.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_555, arg_558) }; var arg_563 any; if linked_560 == nil { return ifn_561.Invoke_O_O__O(arg_562, arg_563) } else { return linked_560.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_559, arg_562, arg_563) } } } else { var vec__233000073__4 any; var root_564 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__233000062__3; if linked_565 == nil { vec__233000073__4 = ifn_566.Invoke_O__O(arg_567) } else { vec__233000073__4 = linked_565.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_564, arg_567) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000073__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000073__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_609 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any; var G__233000076__7_ any = k__5
L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__233000076__7_) >> 0 & 1 { case 0: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_86) {

	var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17); var tmp7 any; var root_569 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = k__5; if linked_570 == nil { tmp7 = ifn_571.Invoke_O__O(arg_572) } else { tmp7 = linked_570.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_569, arg_572) }; var tmp8 any = tmp7; var tmp9 any; var root_578 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = Lit_18; var arg_582 any; var root_573 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_577 any = v__6; if linked_574 == nil { arg_582 = ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { arg_582 = linked_574.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_573, arg_576, arg_577) }; if linked_579 == nil { tmp9 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { tmp9 = linked_579.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) }; arg_612 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :151:1
	break L2 }; case 1: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_84) {

		var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17); var tmp11 any; var root_583 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = k__5; if linked_584 == nil { tmp11 = ifn_585.Invoke_O__O(arg_586) } else { tmp11 = linked_584.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_583, arg_586) }; var tmp12 any = tmp11; var tmp13 any; var root_592 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = Lit_18; var arg_596 any; var root_587 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_591 any = v__6; if linked_588 == nil { arg_596 = ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { arg_596 = linked_588.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }; if linked_593 == nil { tmp13 = ifn_594.Invoke_O_O__O(arg_595, arg_596) } else { tmp13 = linked_593.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_592, arg_595, arg_596) }; arg_612 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, tmp13, nil)).Ref()
//line :151:1
		break L2 }; default:
}

	var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp15 any; var root_597 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = k__5; if linked_598 == nil { tmp15 = ifn_599.Invoke_O__O(arg_600) } else { tmp15 = linked_598.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_597, arg_600) }; var tmp16 any = tmp15; var tmp17 any; var root_601 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = v__6; if linked_602 == nil { tmp17 = ifn_603.Invoke_O__O(arg_604) } else { tmp17 = linked_602.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_601, arg_604) }; arg_612 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, tmp16, nil, tmp17)).Ref()}
//line :150:1
	var arg_613 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); var tmp19 any; var root_605 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = s__233000062__3; if linked_606 == nil { tmp19 = ifn_607.Invoke_O__O(arg_608) } else { tmp19 = linked_606.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_605, arg_608) }; arg_613 = tmp18.Invoke_O__O(tmp19); if linked_610 == nil { return ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { return linked_610.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Ctor_O_I_O(c__b__233000064 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000064 = c__b__233000064; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Invoke_O__O(self any) any { { var i__233000063__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000063__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000068__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000068__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_536 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = t.F_b__233000064; var arg_540 any; var G__233000071__5_ any = k__3
L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__233000071__5_) >> 0 & 1 { case 0: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_86) {

	var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17); var tmp3 any; var root_500 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = k__3; if linked_501 == nil { tmp3 = ifn_502.Invoke_O__O(arg_503) } else { tmp3 = linked_501.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_500, arg_503) }; var tmp4 any = tmp3; var tmp5 any; var root_509 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = Lit_18; var arg_513 any; var root_504 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_508 any = v__4; if linked_505 == nil { arg_513 = ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { arg_513 = linked_505.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; if linked_510 == nil { tmp5 = ifn_511.Invoke_O_O__O(arg_512, arg_513) } else { tmp5 = linked_510.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_509, arg_512, arg_513) }; arg_540 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()
//line :151:1
	break L2 }; case 1: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_84) {

		var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil, Lit_17); var tmp7 any; var root_514 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = k__3; if linked_515 == nil { tmp7 = ifn_516.Invoke_O__O(arg_517) } else { tmp7 = linked_515.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_514, arg_517) }; var tmp8 any = tmp7; var tmp9 any; var root_523 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = Lit_18; var arg_527 any; var root_518 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_522 any = v__4; if linked_519 == nil { arg_527 = ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { arg_527 = linked_519.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }; if linked_524 == nil { tmp9 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp9 = linked_524.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; arg_540 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :151:1
		break L2 }; default:
}

	var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp11 any; var root_528 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = k__3; if linked_529 == nil { tmp11 = ifn_530.Invoke_O__O(arg_531) } else { tmp11 = linked_529.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_528, arg_531) }; var tmp12 any = tmp11; var tmp13 any; var root_532 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = v__4; if linked_533 == nil { tmp13 = ifn_534.Invoke_O__O(arg_535) } else { tmp13 = linked_533.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_532, arg_535) }; arg_540 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, tmp13)).Ref()}
//line :150:1
	if linked_537 == nil { ifn_538.Invoke_O_O__O(arg_539, arg_540) } else { linked_537.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_536, arg_539, arg_540) }; i__233000063__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000063__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_j2g_edge_edge_text_A_New() *A_arbace_j2g_edge_edge_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Ctor() {}
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Invoke_O_O__O(self, p__233000080__0 any) any { var map__233000081__2 any = p__233000080__0; var map__233000081__3 any; if lang.ISeq_InstanceOf(map__233000081__2) { var tmp1 any; var root_646 any = A_arbace_j2g_edge_A_const_97.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = map__233000081__2; if linked_647 == nil { tmp1 = ifn_648.Invoke_O__O(arg_649) } else { tmp1 = linked_647.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_650 any = A_arbace_j2g_edge_A_const_98.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = map__233000081__2; if linked_651 == nil { tmp2 = ifn_652.Invoke_O__O(arg_653) } else { tmp2 = linked_651.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_650, arg_653) }; map__233000081__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_654 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = map__233000081__2; if linked_655 == nil { tmp3 = ifn_656.Invoke_O__O(arg_657) } else { tmp3 = linked_655.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_654, arg_657) }; if jrt.J2g_Truth(tmp3) { var root_658 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = map__233000081__2; if linked_659 == nil { map__233000081__3 = ifn_660.Invoke_O__O(arg_661) } else { map__233000081__3 = linked_659.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_658, arg_661) } } else { map__233000081__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__233000081__3 = map__233000081__2 }; var edge__4 any = map__233000081__3; var classes__5 any = lang.RT_Get_O_O__O_NoInit(map__233000081__3, A_arbace_j2g_edge_A_const_99); var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,7,s92:;; j2g's edge (doc/STANDALONE-NOTES.md, S2): the classes outside the forms as j2g sees them\ns84:;; on the JVM, written by bin/j2g-edge update (bin/j2g --record-edge); do not edit.\ns12:{:classes\n {ns2:}\nns2:}\n", []*jrt.Class{jrt.String_class}); var tmp5 any; var root_736 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_738 lang.IFn; if





	linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = Lit_8; var arg_740 any; var iter__1927001039__auto____13 any; var tmp6 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New(); var tmp7 *jrt.Class; var fncls__730 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class; if fncls__730 == nil { var fncls__730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class = fncls__730d; tmp7 = fncls__730d } else { tmp7 = fncls__730 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp9 any; var root_731 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); var arg_735 any = classes__5; if linked_732 == nil { tmp9 = ifn_733.Invoke_O_O__O(arg_734, arg_735) } else { tmp9 = linked_732.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_731, arg_734, arg_735) }; arg_740 = tmp8.Invoke_O__O(tmp9); if linked_737 == nil { tmp5 = ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { tmp5 = linked_737.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) }; var tmp10 any = tmp5; var tmp11 any; var root_1014 any = /*line :164:1*/A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1016 lang.IFn; if




	linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any; var iter__1927001039__auto____13_2 any; var tmp12 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New(); var tmp13 *jrt.Class; var fncls__1003 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class; if fncls__1003 == nil { var fncls__1003d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class = fncls__1003d; tmp13 = fncls__1003d } else { tmp13 = fncls__1003 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp15 any; var root_1009 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); var arg_1013 any; var root_1004 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = edge__4; var arg_1008 any = A_arbace_j2g_edge_A_const_99; if linked_1005 == nil { arg_1013 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { arg_1013 = linked_1005.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }; if linked_1010 == nil { tmp15 = ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { tmp15 = linked_1010.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }; arg_1017 = tmp14.Invoke_O__O(tmp15); if linked_1015 == nil { tmp11 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp11 = linked_1015.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_1014, arg_1017) }; return /*line :164:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp10, nil, tmp11, nil)).Ref() }


func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New() *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Invoke_O_O__O(self, s__233000084__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(self, s__233000084__1); var tmp2 *jrt.Class; var fncls__729 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class; if fncls__729 == nil { var fncls__729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class = fncls__729d; tmp2 = fncls__729d } else { tmp2 = fncls__729 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Ctor_O_O(c__iter__233000083, c__s__233000084 any) { t.F_iter__233000083 = c__iter__233000083; t.F_s__233000084 = c__s__233000084 }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Invoke_O__O(self any) any { { var s__233000084__1 any; var t_ any = t.F_s__233000084; t.F_s__233000084 = nil; s__233000084__1 = t_; for { var temp__1927000414__auto____2 any; var root_662 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = s__233000084__1; if linked_663 == nil { temp__1927000414__auto____2 = ifn_664.Invoke_O__O(arg_665) } else { temp__1927000414__auto____2 = linked_663.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_662, arg_665) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000084__3 any = temp__1927000414__auto____2; var tmp1 any; var root_666 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = s__233000084__3; if linked_667 == nil { tmp1 = ifn_668.Invoke_O__O(arg_669) } else { tmp1 = linked_667.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_666, arg_669) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_670 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = s__233000084__3; if linked_671 == nil { c__1927001037__auto____4 = ifn_672.Invoke_O__O(arg_673) } else { c__1927001037__auto____4 = linked_671.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_670, arg_673) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000086__6 any; var root_674 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_675 == nil { b__233000086__6 = ifn_676.Invoke_O__O(arg_677) } else { b__233000086__6 = linked_675.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_674, arg_677) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(b__233000086__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class; if fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class = fncls__688d; tmp3 = fncls__688d } else { tmp3 = fncls__688 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_697 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any; var root_689 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = b__233000086__6; if linked_690 == nil { arg_700 = ifn_691.Invoke_O__O(arg_692) } else { arg_700 = linked_690.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_689, arg_692) }; var arg_701 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); var tmp5 any; var root_693 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = s__233000084__3; if linked_694 == nil { tmp5 = ifn_695.Invoke_O__O(arg_696) } else { tmp5 = linked_694.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_693, arg_696) }; arg_701 = tmp4.Invoke_O__O(tmp5); if linked_698 == nil { return ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { return linked_698.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) } } else { var root_706 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any; var root_702 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = b__233000086__6; if linked_703 == nil { arg_709 = ifn_704.Invoke_O__O(arg_705) } else { arg_709 = linked_703.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_702, arg_705) }; var arg_710 any; if linked_707 == nil { return ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { return linked_707.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) } } } else { var vec__233000094__4 any; var root_711 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = s__233000084__3; if linked_712 == nil { vec__233000094__4 = ifn_713.Invoke_O__O(arg_714) } else { vec__233000094__4 = linked_712.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_711, arg_714) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000094__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000094__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_724 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any; var root_715 any = A_arbace_j2g_edge_A_const_100.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, A_arbace_j2g_edge_class_entry_text_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = n__5; var arg_719 any = facets__6; if linked_716 == nil { arg_727 = ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { arg_727 = linked_716.(*A_arbace_j2g_edge_class_entry_text_A).Invoke_O_O_O__O(root_715, arg_718, arg_719) }; var arg_728 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); var tmp7 any; var root_720 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = s__233000084__3; if linked_721 == nil { tmp7 = ifn_722.Invoke_O__O(arg_723) } else { tmp7 = linked_721.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_720, arg_723) }; arg_728 = tmp6.Invoke_O__O(tmp7); if linked_725 == nil { return ifn_726.Invoke_O_O__O(arg_727, arg_728) } else { return linked_725.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_724, arg_727, arg_728) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Ctor_O_I_O(c__b__233000086 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000086 = c__b__233000086; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Invoke_O__O(self any) any { { var i__233000085__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000085__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000090__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000085__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000090__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000090__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_683 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = t.F_b__233000086; var arg_687 any; var root_678 any = A_arbace_j2g_edge_A_const_100.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_j2g_edge_class_entry_text_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = n__3; var arg_682 any = facets__4; if linked_679 == nil { arg_687 = ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { arg_687 = linked_679.(*A_arbace_j2g_edge_class_entry_text_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) }; if linked_684 == nil { ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { linked_684.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; i__233000085__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000085__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Invoke_O_O__O(self, s__233000100__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(self, s__233000100__1); var tmp2 *jrt.Class; var fncls__1002 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class; if fncls__1002 == nil { var fncls__1002d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class = fncls__1002d; tmp2 = fncls__1002d } else { tmp2 = fncls__1002 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Ctor_O_O(c__iter__233000099, c__s__233000100 any) { t.F_iter__233000099 = c__iter__233000099; t.F_s__233000100 = c__s__233000100 }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Invoke_O__O(self any) any { { var s__233000100__1 any; var t_ any = t.F_s__233000100; t.F_s__233000100 = nil; s__233000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_741 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = s__233000100__1; if linked_742 == nil { temp__1927000414__auto____2 = ifn_743.Invoke_O__O(arg_744) } else { temp__1927000414__auto____2 = linked_742.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_741, arg_744) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_745 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = s__233000100__3; if linked_746 == nil { tmp1 = ifn_747.Invoke_O__O(arg_748) } else { tmp1 = linked_746.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_745, arg_748) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_749 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = s__233000100__3; if linked_750 == nil { c__1927001037__auto____4 = ifn_751.Invoke_O__O(arg_752) } else { c__1927001037__auto____4 = linked_750.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_749, arg_752) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000102__6 any; var root_753 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_754 == nil { b__233000102__6 = ifn_755.Invoke_O__O(arg_756) } else { b__233000102__6 = linked_754.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_753, arg_756) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(b__233000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__864 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class; if fncls__864 == nil { var fncls__864d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class = fncls__864d; tmp3 = fncls__864d } else { tmp3 = fncls__864 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_873 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any; var root_865 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = b__233000102__6; if linked_866 == nil { arg_876 = ifn_867.Invoke_O__O(arg_868) } else { arg_876 = linked_866.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_865, arg_868) }; var arg_877 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); var tmp5 any; var root_869 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = s__233000100__3; if linked_870 == nil { tmp5 = ifn_871.Invoke_O__O(arg_872) } else { tmp5 = linked_870.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_869, arg_872) }; arg_877 = tmp4.Invoke_O__O(tmp5); if linked_874 == nil { return ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { return linked_874.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) } } else { var root_882 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var root_878 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = b__233000102__6; if linked_879 == nil { arg_885 = ifn_880.Invoke_O__O(arg_881) } else { arg_885 = linked_879.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_878, arg_881) }; var arg_886 any; if linked_883 == nil { return ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { return linked_883.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) } } } else { var vec__233000126__4 any; var root_887 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = s__233000100__3; if linked_888 == nil { vec__233000126__4 = ifn_889.Invoke_O__O(arg_890) } else { vec__233000126__4 = linked_888.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_887, arg_890) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000126__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000126__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_997 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_34, nil, Lit_35); var tmp7 any; var root_891 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_893 lang.IFn
														if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = k__5; if linked_892 == nil { tmp7 = ifn_893.Invoke_O__O(arg_894) } else { tmp7 = linked_892.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_891, arg_894) }; var tmp8 any = tmp7; var tmp9 any; var tmp10 any; var root_895 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_897 lang.IFn
														if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = v__6; if linked_896 == nil { tmp10 = ifn_897.Invoke_O__O(arg_898) } else { tmp10 = linked_896.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_895, arg_898) }; if jrt.J2g_Truth(tmp10) {
															var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_10); var tmp12 any; var root_984 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = Lit_8; var arg_988 any; var iter__1927001039__auto____15 any; var tmp13 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New(); var tmp14 *jrt.Class; var fncls__973 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class; if fncls__973 == nil { var fncls__973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class = fncls__973d; tmp14 = fncls__973d } else { tmp14 = fncls__973 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp15 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp16 any; var root_979 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var root_974 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_978 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_975 == nil { arg_982 = ifn_976.Invoke_O_O__O(arg_977, arg_978) } else { arg_982 = linked_975.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_974, arg_977, arg_978) }; var arg_983 any = v__6; if linked_980 == nil { tmp16 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp16 = linked_980.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }; arg_988 = tmp15.Invoke_O__O(tmp16); if linked_985 == nil { tmp12 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { tmp12 = linked_985.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } else {
																var root_989 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = v__6; if linked_990 == nil { tmp9 = ifn_991.Invoke_O__O(arg_992) } else { tmp9 = linked_990.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_989, arg_992) } }
//line :170:1
	arg_1000 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp9, nil)).Ref()
//line :169:1
	var arg_1001 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); var tmp18 any; var root_993 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = s__233000100__3; if linked_994 == nil { tmp18 = ifn_995.Invoke_O__O(arg_996) } else { tmp18 = linked_994.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_993, arg_996) }; arg_1001 = tmp17.Invoke_O__O(tmp18); if linked_998 == nil { return ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { return linked_998.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Ctor_O_I_O(c__b__233000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000102 = c__b__233000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Invoke_O__O(self any) any { { var i__233000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000106__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000106__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_859 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = t.F_b__233000102; var arg_863 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_34, nil, Lit_35); var tmp3 any; var root_757 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_759 lang.IFn
																if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = k__3; if linked_758 == nil { tmp3 = ifn_759.Invoke_O__O(arg_760) } else { tmp3 = linked_758.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_757, arg_760) }; var tmp4 any = tmp3; var tmp5 any; var tmp6 any; var root_761 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_763 lang.IFn
																if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = v__4; if linked_762 == nil { tmp6 = ifn_763.Invoke_O__O(arg_764) } else { tmp6 = linked_762.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_761, arg_764) }; if jrt.J2g_Truth(tmp6) {
																	var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_10); var tmp8 any; var root_850 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = Lit_8; var arg_854 any; var iter__1927001039__auto____13 any; var tmp9 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New(); var tmp10 *jrt.Class; var fncls__839 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class; if fncls__839 == nil { var fncls__839d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class = fncls__839d; tmp10 = fncls__839d } else { tmp10 = fncls__839 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp12 any; var root_845 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any; var root_840 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_844 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_841 == nil { arg_848 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { arg_848 = linked_841.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_840, arg_843, arg_844) }; var arg_849 any = v__4; if linked_846 == nil { tmp12 = ifn_847.Invoke_O_O__O(arg_848, arg_849) } else { tmp12 = linked_846.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_845, arg_848, arg_849) }; arg_854 = tmp11.Invoke_O__O(tmp12); if linked_851 == nil { tmp8 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { tmp8 = linked_851.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil)).Ref() } else {
																		var root_855 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = v__4; if linked_856 == nil { tmp5 = ifn_857.Invoke_O__O(arg_858) } else { tmp5 = linked_856.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_855, arg_858) } }
//line :170:1
	arg_863 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref()
//line :169:1
	if linked_860 == nil { ifn_861.Invoke_O_O__O(arg_862, arg_863) } else { linked_860.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_859, arg_862, arg_863) }; i__233000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Invoke_O_O__O(self, s__233000110__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(self, s__233000110__1); var tmp2 *jrt.Class; var fncls__838 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class; if fncls__838 == nil { var fncls__838d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class = fncls__838d; tmp2 = fncls__838d } else { tmp2 = fncls__838 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Ctor_O_O(c__iter__233000109, c__s__233000110 any) { t.F_iter__233000109 = c__iter__233000109; t.F_s__233000110 = c__s__233000110 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Invoke_O__O(self any) any { { var s__233000110__1 any; var t_ any = t.F_s__233000110; t.F_s__233000110 = nil; s__233000110__1 = t_; for { var temp__1927000414__auto____2 any; var root_765 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = s__233000110__1; if linked_766 == nil { temp__1927000414__auto____2 = ifn_767.Invoke_O__O(arg_768) } else { temp__1927000414__auto____2 = linked_766.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_765, arg_768) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000110__3 any = temp__1927000414__auto____2; var tmp1 any; var root_769 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = s__233000110__3; if linked_770 == nil { tmp1 = ifn_771.Invoke_O__O(arg_772) } else { tmp1 = linked_770.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_769, arg_772) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_773 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = s__233000110__3; if linked_774 == nil { c__1927001037__auto____4 = ifn_775.Invoke_O__O(arg_776) } else { c__1927001037__auto____4 = linked_774.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_773, arg_776) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000112__6 any; var root_777 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_778 == nil { b__233000112__6 = ifn_779.Invoke_O__O(arg_780) } else { b__233000112__6 = linked_778.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_777, arg_780) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(b__233000112__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__794 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class; if fncls__794 == nil { var fncls__794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class = fncls__794d; tmp3 = fncls__794d } else { tmp3 = fncls__794 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_803 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any; var root_795 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = b__233000112__6; if linked_796 == nil { arg_806 = ifn_797.Invoke_O__O(arg_798) } else { arg_806 = linked_796.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_795, arg_798) }; var arg_807 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); var tmp5 any; var root_799 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = s__233000110__3; if linked_800 == nil { tmp5 = ifn_801.Invoke_O__O(arg_802) } else { tmp5 = linked_800.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_799, arg_802) }; arg_807 = tmp4.Invoke_O__O(tmp5); if linked_804 == nil { return ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { return linked_804.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) } } else { var root_812 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any; var root_808 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = b__233000112__6; if linked_809 == nil { arg_815 = ifn_810.Invoke_O__O(arg_811) } else { arg_815 = linked_809.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_808, arg_811) }; var arg_816 any; if linked_813 == nil { return ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { return linked_813.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_812, arg_815, arg_816) } } } else { var vec__233000120__4 any; var root_817 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = s__233000110__3; if linked_818 == nil { vec__233000120__4 = ifn_819.Invoke_O__O(arg_820) } else { vec__233000120__4 = linked_818.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_817, arg_820) }; var kk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_833 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp7 any; var root_821 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = kk__5; if linked_822 == nil { tmp7 = ifn_823.Invoke_O__O(arg_824) } else { tmp7 = linked_822.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_821, arg_824) }; var tmp8 any = tmp7; var tmp9 any; var root_825 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = vv__6; if linked_826 == nil { tmp9 = ifn_827.Invoke_O__O(arg_828) } else { tmp9 = linked_826.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_825, arg_828) }; arg_836 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_837 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); var tmp11 any; var root_829 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = s__233000110__3; if linked_830 == nil { tmp11 = ifn_831.Invoke_O__O(arg_832) } else { tmp11 = linked_830.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_829, arg_832) }; arg_837 = tmp10.Invoke_O__O(tmp11); if linked_834 == nil { return ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { return linked_834.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Ctor_O_I_O(c__b__233000112 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000112 = c__b__233000112; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Invoke_O__O(self any) any { { var i__233000111__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000111__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000116__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000111__1)); var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000116__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000116__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_789 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = t.F_b__233000112; var arg_793 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp3 any; var root_781 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = kk__3; if linked_782 == nil { tmp3 = ifn_783.Invoke_O__O(arg_784) } else { tmp3 = linked_782.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_781, arg_784) }; var tmp4 any = tmp3; var tmp5 any; var root_785 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = vv__4; if linked_786 == nil { tmp5 = ifn_787.Invoke_O__O(arg_788) } else { tmp5 = linked_786.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_785, arg_788) }; arg_793 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_790 == nil { ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { linked_790.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }; i__233000111__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000111__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Invoke_O_O__O(self, s__233000130__1 any) any { var tmp1 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(self, s__233000130__1); var tmp2 *jrt.Class; var fncls__972 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class; if fncls__972 == nil { var fncls__972d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class = fncls__972d; tmp2 = fncls__972d } else { tmp2 = fncls__972 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Ctor_O_O(c__iter__233000129, c__s__233000130 any) { t.F_iter__233000129 = c__iter__233000129; t.F_s__233000130 = c__s__233000130 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Invoke_O__O(self any) any { { var s__233000130__1 any; var t_ any = t.F_s__233000130; t.F_s__233000130 = nil; s__233000130__1 = t_; for { var temp__1927000414__auto____2 any; var root_899 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = s__233000130__1; if linked_900 == nil { temp__1927000414__auto____2 = ifn_901.Invoke_O__O(arg_902) } else { temp__1927000414__auto____2 = linked_900.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_899, arg_902) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000130__3 any = temp__1927000414__auto____2; var tmp1 any; var root_903 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = s__233000130__3; if linked_904 == nil { tmp1 = ifn_905.Invoke_O__O(arg_906) } else { tmp1 = linked_904.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_903, arg_906) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_907 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = s__233000130__3; if linked_908 == nil { c__1927001037__auto____4 = ifn_909.Invoke_O__O(arg_910) } else { c__1927001037__auto____4 = linked_908.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_907, arg_910) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000132__6 any; var root_911 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_912 == nil { b__233000132__6 = ifn_913.Invoke_O__O(arg_914) } else { b__233000132__6 = linked_912.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_911, arg_914) }; var tmp2 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(b__233000132__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__928 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class; if fncls__928 == nil { var fncls__928d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class = fncls__928d; tmp3 = fncls__928d } else { tmp3 = fncls__928 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_937 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any; var root_929 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = b__233000132__6; if linked_930 == nil { arg_940 = ifn_931.Invoke_O__O(arg_932) } else { arg_940 = linked_930.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_929, arg_932) }; var arg_941 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); var tmp5 any; var root_933 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = s__233000130__3; if linked_934 == nil { tmp5 = ifn_935.Invoke_O__O(arg_936) } else { tmp5 = linked_934.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_933, arg_936) }; arg_941 = tmp4.Invoke_O__O(tmp5); if linked_938 == nil { return ifn_939.Invoke_O_O__O(arg_940, arg_941) } else { return linked_938.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_937, arg_940, arg_941) } } else { var root_946 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var root_942 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = b__233000132__6; if linked_943 == nil { arg_949 = ifn_944.Invoke_O__O(arg_945) } else { arg_949 = linked_943.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_942, arg_945) }; var arg_950 any; if linked_947 == nil { return ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { return linked_947.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } } else { var vec__233000140__4 any; var root_951 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = s__233000130__3; if linked_952 == nil { vec__233000140__4 = ifn_953.Invoke_O__O(arg_954) } else { vec__233000140__4 = linked_952.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_951, arg_954) }; var kk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000140__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000140__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_967 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp7 any; var root_955 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = kk__5; if linked_956 == nil { tmp7 = ifn_957.Invoke_O__O(arg_958) } else { tmp7 = linked_956.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_955, arg_958) }; var tmp8 any = tmp7; var tmp9 any; var root_959 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = vv__6; if linked_960 == nil { tmp9 = ifn_961.Invoke_O__O(arg_962) } else { tmp9 = linked_960.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_959, arg_962) }; arg_970 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_971 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); var tmp11 any; var root_963 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = s__233000130__3; if linked_964 == nil { tmp11 = ifn_965.Invoke_O__O(arg_966) } else { tmp11 = linked_964.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_963, arg_966) }; arg_971 = tmp10.Invoke_O__O(tmp11); if linked_968 == nil { return ifn_969.Invoke_O_O__O(arg_970, arg_971) } else { return linked_968.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_967, arg_970, arg_971) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Ctor_O_I_O(c__b__233000132 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000132 = c__b__233000132; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Invoke_O__O(self any) any { { var i__233000131__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000131__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000136__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000131__1)); var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000136__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000136__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_923 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = t.F_b__233000132; var arg_927 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp3 any; var root_915 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = kk__3; if linked_916 == nil { tmp3 = ifn_917.Invoke_O__O(arg_918) } else { tmp3 = linked_916.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_915, arg_918) }; var tmp4 any = tmp3; var tmp5 any; var root_919 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = vv__4; if linked_920 == nil { tmp5 = ifn_921.Invoke_O__O(arg_922) } else { tmp5 = linked_920.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_919, arg_922) }; arg_927 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_924 == nil { ifn_925.Invoke_O_O__O(arg_926, arg_927) } else { linked_924.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_923, arg_926, arg_927) }; i__233000131__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000131__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_recorded_edge_A_New() *A_arbace_j2g_edge_recorded_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Invoke_O_O_O__O(self, env_rec__0, j2g_rec__1_ any) any { var classes__3 any; var root_1152 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1154 lang.IFn; if



	linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_107, nil); if linked_1153 == nil { ifn_1154.Invoke_O__O(arg_1155) } else { linked_1153.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1152, arg_1155) }; var tmp1 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(env_rec__0); var tmp2 *jrt.Class; var fncls__1141 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class; if fncls__1141 == nil { var fncls__1141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class = fncls__1141d; tmp2 = fncls__1141d } else { tmp2 = fncls__1141 }; classes__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var root_1142 any =




	A_arbace_j2g_edge_A_const_106.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_99, classes__3)); var arg_1146 any = j2g_rec__1_; if linked_1143 == nil { return ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { return linked_1143.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) } }
//line :181:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(p0 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Ctor_O(c__env_rec any) { t.F_env_rec = c__env_rec }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1133 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1137 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New(); var tmp3 *jrt.Class; var fncls__1132 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class; if fncls__1132 == nil { var fncls__1132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class = fncls__1132d; tmp3 = fncls__1132d } else { tmp3 = fncls__1132 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var t_ any = t.F_env_rec; t.F_env_rec = nil; tmp5 = t_; arg_1137 = tmp4.Invoke_O__O(tmp5); if linked_1134 == nil { tmp1 = ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { tmp1 = linked_1134.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) } }
//line :181:1
	return nil }(); var root_1138 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; if linked_1139 == nil { ifn_1140.Invoke__O() } else { linked_1139.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1138) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New() *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Invoke_O_O__O(self, s__233000150__1 any) any { var tmp1 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(self, s__233000150__1); var tmp2 *jrt.Class; var fncls__1131 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class; if fncls__1131 == nil { var fncls__1131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class = fncls__1131d; tmp2 = fncls__1131d } else { tmp2 = fncls__1131 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Ctor_O_O(c__iter__233000149, c__s__233000150 any) { t.F_iter__233000149 = c__iter__233000149; t.F_s__233000150 = c__s__233000150 }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Invoke_O__O(self any) any { { var s__233000150__1 any; var t_ any = t.F_s__233000150; t.F_s__233000150 = nil; s__233000150__1 = t_; for { var temp__1927000414__auto____2 any; var root_1018 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = s__233000150__1; if linked_1019 == nil { temp__1927000414__auto____2 = ifn_1020.Invoke_O__O(arg_1021) } else { temp__1927000414__auto____2 = linked_1019.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1018, arg_1021) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000150__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1022 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = s__233000150__3; if linked_1023 == nil { tmp1 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp1 = linked_1023.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1022, arg_1025) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1026 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = s__233000150__3; if linked_1027 == nil { c__1927001037__auto____4 = ifn_1028.Invoke_O__O(arg_1029) } else { c__1927001037__auto____4 = linked_1027.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1026, arg_1029) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000152__6 any; var root_1030 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1031 == nil { b__233000152__6 = ifn_1032.Invoke_O__O(arg_1033) } else { b__233000152__6 = linked_1031.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1030, arg_1033) }; var tmp2 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(b__233000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1067 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class; if fncls__1067 == nil { var fncls__1067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class = fncls__1067d; tmp3 = fncls__1067d } else { tmp3 = fncls__1067 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1076 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any; var root_1068 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = b__233000152__6; if linked_1069 == nil { arg_1079 = ifn_1070.Invoke_O__O(arg_1071) } else { arg_1079 = linked_1069.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1068, arg_1071) }; var arg_1080 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); var tmp5 any; var root_1072 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any = s__233000150__3; if linked_1073 == nil { tmp5 = ifn_1074.Invoke_O__O(arg_1075) } else { tmp5 = linked_1073.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1072, arg_1075) }; arg_1080 = tmp4.Invoke_O__O(tmp5); if linked_1077 == nil { return ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { return linked_1077.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) } } else { var root_1085 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var root_1081 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = b__233000152__6; if linked_1082 == nil { arg_1088 = ifn_1083.Invoke_O__O(arg_1084) } else { arg_1088 = linked_1082.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1081, arg_1084) }; var arg_1089 any; if linked_1086 == nil { return ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { return linked_1086.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) } } } else { var vec__233000161__4 any; var root_1090 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = s__233000150__3; if linked_1091 == nil { vec__233000161__4 = ifn_1092.Invoke_O__O(arg_1093) } else { vec__233000161__4 = linked_1091.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1090, arg_1093) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000161__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000161__4, lang.RT_IntCast_J__I_NoInit(1), nil); var c__7 any; var tmp6 any; var root_1094 any = A_arbace_j2g_edge_A_const_101.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1096 lang.IFn
																if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = n__5; var arg_1098 any = Lit_72; if linked_1095 == nil { tmp6 = ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { tmp6 = linked_1095.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }; if jrt.J2g_Truth(tmp6) { c__7 = nil } else { var root_1099 any = A_arbace_j2g_edge_A_const_102.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_classes_env.A_arbace_classes_env_load_class_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = n__5; if linked_1100 == nil { c__7 = ifn_1101.Invoke_O__O(arg_1102) } else { c__7 = linked_1100.(*aot_arbace_classes_env.A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_1099, arg_1102) } }
//line :182:1
	var root_1126 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any; var tmp7 any; var root_1117 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1119 lang.IFn

	if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = n__5; var arg_1121 any; var G__233000164__8_ any = facets__6; if jrt.J2g_Truth(c__7) {
		var root_1111 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = G__233000164__8_; var arg_1115 any = A_arbace_j2g_edge_A_const_94; var arg_1116 any; var root_1107 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, A_arbace_j2g_edge_info_data_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any; var root_1103 any = A_arbace_j2g_edge_A_const_105.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = c__7; if linked_1104 == nil { arg_1110 = ifn_1105.Invoke_O__O(arg_1106) } else { arg_1110 = linked_1104.(*aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_1103, arg_1106) }; if linked_1108 == nil { arg_1116 = ifn_1109.Invoke_O__O(arg_1110) } else { arg_1116 = linked_1108.(*A_arbace_j2g_edge_info_data_A).Invoke_O_O__O(root_1107, arg_1110) }; if linked_1112 == nil { arg_1121 = ifn_1113.Invoke_O_O_O__O(arg_1114, arg_1115, arg_1116) } else { arg_1121 = linked_1112.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1111, arg_1114, arg_1115, arg_1116) } } else {
//line :184:1
			arg_1121 = G__233000164__8_ }; if linked_1118 == nil { tmp7 = ifn_1119.Invoke_O_O__O(arg_1120, arg_1121) } else { tmp7 = linked_1118.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1117, arg_1120, arg_1121) }
//line :182:1
	arg_1129 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp7); var arg_1130 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); var tmp9 any; var root_1122 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = s__233000150__3; if linked_1123 == nil { tmp9 = ifn_1124.Invoke_O__O(arg_1125) } else { tmp9 = linked_1123.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1122, arg_1125) }; arg_1130 = tmp8.Invoke_O__O(tmp9); if linked_1127 == nil { return ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { return linked_1127.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Ctor_O_I_O(c__b__233000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000152 = c__b__233000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Invoke_O__O(self any) any { { var i__233000151__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000156__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000156__2, lang.RT_IntCast_J__I_NoInit(1), nil); var c__5 any; var tmp2 any; var root_1034 any = A_arbace_j2g_edge_A_const_101.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1036 lang.IFn
																		if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = n__3; var arg_1038 any = Lit_72; if linked_1035 == nil { tmp2 = ifn_1036.Invoke_O_O__O(arg_1037, arg_1038) } else { tmp2 = linked_1035.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1034, arg_1037, arg_1038) }; if jrt.J2g_Truth(tmp2) { c__5 = nil } else { var root_1039 any = A_arbace_j2g_edge_A_const_102.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_classes_env.A_arbace_classes_env_load_class_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = n__3; if linked_1040 == nil { c__5 = ifn_1041.Invoke_O__O(arg_1042) } else { c__5 = linked_1040.(*aot_arbace_classes_env.A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_1039, arg_1042) } }
//line :182:1
	var root_1062 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = t.F_b__233000152; var arg_1066 any; var tmp3 any; var root_1057 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1059 lang.IFn

	if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = n__3; var arg_1061 any; var G__233000159__6_ any = facets__4; if jrt.J2g_Truth(c__5) {
		var root_1051 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = G__233000159__6_; var arg_1055 any = A_arbace_j2g_edge_A_const_94; var arg_1056 any; var root_1047 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, A_arbace_j2g_edge_info_data_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any; var root_1043 any = A_arbace_j2g_edge_A_const_105.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = c__5; if linked_1044 == nil { arg_1050 = ifn_1045.Invoke_O__O(arg_1046) } else { arg_1050 = linked_1044.(*aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_1043, arg_1046) }; if linked_1048 == nil { arg_1056 = ifn_1049.Invoke_O__O(arg_1050) } else { arg_1056 = linked_1048.(*A_arbace_j2g_edge_info_data_A).Invoke_O_O__O(root_1047, arg_1050) }; if linked_1052 == nil { arg_1061 = ifn_1053.Invoke_O_O_O__O(arg_1054, arg_1055, arg_1056) } else { arg_1061 = linked_1052.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1051, arg_1054, arg_1055, arg_1056) } } else {
//line :184:1
			arg_1061 = G__233000159__6_ }; if linked_1058 == nil { tmp3 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { tmp3 = linked_1058.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }
//line :182:1
	arg_1066 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp3); if linked_1063 == nil { ifn_1064.Invoke_O_O__O(arg_1065, arg_1066) } else { linked_1063.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1062, arg_1065, arg_1066) }; i__233000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000151__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_edge_merge_edges_A_New() *A_arbace_j2g_edge_merge_edges_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Ctor() {}
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Invoke_O_O__O(self, edges__0 any) any {


	var root_1190 any = A_arbace_j2g_edge_A_const_108.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = A_arbace_j2g_edge_A_const_109.GetRawRoot__O(); var arg_1194 any; var tmp1 any = A_arbace_j2g_edge_merge_edges_fn__233000169_A_New(); var tmp2 *jrt.Class; var fncls__1189 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class; if fncls__1189 == nil { var fncls__1189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class = fncls__1189d; tmp2 = fncls__1189d } else { tmp2 = fncls__1189 }; arg_1194 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1195 any = edges__0; if linked_1191 == nil { return ifn_1192.Invoke_O_O_O__O(arg_1193, arg_1194, arg_1195) } else { return linked_1191.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1190, arg_1193, arg_1194, arg_1195) } }
//line :191:1
func A_arbace_j2g_edge_merge_edges_fn__233000169_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Ctor() {}
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var tmp1 any; var root_1156 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = a__1; if linked_1157 == nil { tmp1 = ifn_1158.Invoke_O__O(arg_1159) } else { tmp1 = linked_1157.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1156, arg_1159) }; if jrt.J2g_Truth(tmp1) { var root_1160 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1162 lang.IFn; if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = a__1; var arg_1164 any = b__2; if linked_1161 == nil { return ifn_1162.Invoke_O_O__O(arg_1163, arg_1164) } else { return linked_1161.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1160, arg_1163, arg_1164) } } else { var tmp2 any; var root_1165 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1167 lang.IFn
													if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = a__1; if linked_1166 == nil { tmp2 = ifn_1167.Invoke_O__O(arg_1168) } else { tmp2 = linked_1166.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1165, arg_1168) }
//line :191:1
	if jrt.J2g_Truth(tmp2) {
		var root_1183 any = A_arbace_j2g_edge_A_const_109.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any; var tmp3 any = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New(); var tmp4 *jrt.Class; var fncls__1182 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class; if fncls__1182 == nil { var fncls__1182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class = fncls__1182d; tmp4 = fncls__1182d } else { tmp4 = fncls__1182 }; arg_1186 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1187 any = a__1; var arg_1188 any = b__2; if linked_1184 == nil { return ifn_1185.Invoke_O_O_O__O(arg_1186, arg_1187, arg_1188) } else { return linked_1184.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1183, arg_1186, arg_1187, arg_1188) } } else {
//line :191:1
			if A_arbace_j2g_edge_A_const_27 != nil { return b__2 } else { return nil } } } }
func A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Invoke_O_O_O__O(self, x__1, y__2 any) any { var tmp1 any; var and__1927000168__auto____3 any; var root_1169 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = x__1; if linked_1170 == nil { and__1927000168__auto____3 = ifn_1171.Invoke_O__O(arg_1172) } else { and__1927000168__auto____3 = linked_1170.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1169, arg_1172) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1173 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = y__2; if linked_1174 == nil { tmp1 = ifn_1175.Invoke_O__O(arg_1176) } else { tmp1 = linked_1174.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1173, arg_1176) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var root_1177 any = A_arbace_j2g_edge_A_const_106.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = x__1; var arg_1181 any = y__2; if linked_1178 == nil { return ifn_1179.Invoke_O_O__O(arg_1180, arg_1181) } else { return linked_1178.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1177, arg_1180, arg_1181) } } else { return y__2 } }






func A_arbace_j2g_edge_coerce_const_A_New() *A_arbace_j2g_edge_coerce_const_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_coerce_const_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any {
	var tmp1 any; var root_1196 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = v__1; if linked_1197 == nil { tmp1 = ifn_1198.Invoke_O__O(arg_1199) } else { tmp1 = linked_1197.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1196, arg_1199) }; if jrt.J2g_Truth(tmp1) { var G__233000174__3_ any = desc__0
		switch lang.Util_Hash_O__I_NoInit(G__233000174__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_20) {
			return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :201:1
		case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_21) {
			return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :201:1
		case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_22) {

			return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__1)).Ref() }
//line :201:1
		case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_23) {

			return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__1)).Ref() }
//line :201:1
		case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_24) {
			return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__1)).Ref() }
//line :201:1
		case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_25) {
			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__1)).Ref() }
//line :201:1
		case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_26) {
			return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :201:1
		case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_27) {

			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(v__1)).Ref() }
//line :201:1
		default:}; return v__1 } else {
//line :200:1
			return nil
		}
}



func A_arbace_j2g_edge_ann_value_A_New() *A_arbace_j2g_edge_ann_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Ctor() {}
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1201 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = x__0; if linked_1202 == nil { and__1927000168__auto____2 = ifn_1203.Invoke_O__O(arg_1204) } else { and__1927000168__auto____2 = linked_1202.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1201, arg_1204) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1205 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); if linked_1206 == nil { and__1927000168__auto____3 = ifn_1207.Invoke_O__O(arg_1208) } else { and__1927000168__auto____3 = linked_1206.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1205, arg_1208) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1209 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); var arg_1213 any = A_arbace_j2g_edge_A_const_110; if linked_1210 == nil { tmp1 = ifn_1211.Invoke_O_O__O(arg_1212, arg_1213) } else { tmp1 = linked_1210.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1209, arg_1212, arg_1213) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_111; var tmp4 any = A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(x__0); var tmp5 *jrt.Class; var fncls__1224 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class; if fncls__1224 == nil { var fncls__1224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class = fncls__1224d; tmp5 = fncls__1224d } else { tmp5 = fncls__1224 }; return tmp2.Invoke_O_O_O__O(x__0, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } else {
//line :207:1
			var tmp6 any; var root_1231 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1233 lang.IFn

			if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = x__0; if linked_1232 == nil { tmp6 = ifn_1233.Invoke_O__O(arg_1234) } else { tmp6 = linked_1232.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1231, arg_1234) }
//line :207:1
			if jrt.J2g_Truth(tmp6) {

				var root_1245 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1249 any; var root_1240 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var tmp7 any = A_arbace_j2g_edge_ann_value_fn__233000180_A_New(); var tmp8 *jrt.Class; var fncls__1239 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class; if fncls__1239 == nil { var fncls__1239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class = fncls__1239d; tmp8 = fncls__1239d } else { tmp8 = fncls__1239 }; arg_1243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1244 any = x__0; if linked_1241 == nil { arg_1249 = ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { arg_1249 = linked_1241.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) }; if linked_1246 == nil { return ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { return linked_1246.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) } } else {
//line :207:1
					var tmp9 any; var root_1250 any = A_arbace_j2g_edge_A_const_115.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1252 lang.IFn


					if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = x__0; if linked_1251 == nil { tmp9 = ifn_1252.Invoke_O__O(arg_1253) } else { tmp9 = linked_1251.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1250, arg_1253) }
//line :207:1
					if jrt.J2g_Truth(tmp9) {


						var root_1254 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var arg_1258 any = x__0; if linked_1255 == nil { return ifn_1256.Invoke_O_O__O(arg_1257, arg_1258) } else { return linked_1255.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1254, arg_1257, arg_1258) } } else {
//line :207:1
							if A_arbace_j2g_edge_A_const_27 != nil { return x__0 } else { return nil } } } } }
func A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(p0 any) *A_arbace_j2g_edge_ann_value_fn__233000177_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000177_A{}; t.Ctor_O(p0); return t }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Invoke_O_O__O(self, p1__233000176_SHARP___1 any) any { var root_1219 any = A_arbace_j2g_edge_A_const_112.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, A_arbace_j2g_edge_coerce_const_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any; var root_1214 any = A_arbace_j2g_edge_A_const_13.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = t.F_x; var arg_1218 any = A_arbace_j2g_edge_A_const_113; if linked_1215 == nil { arg_1222 = ifn_1216.Invoke_O_O__O(arg_1217, arg_1218) } else { arg_1222 = linked_1215.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1214, arg_1217, arg_1218) }; var arg_1223 any = p1__233000176_SHARP___1; if linked_1220 == nil { return ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { return linked_1220.(*A_arbace_j2g_edge_coerce_const_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) } }
func A_arbace_j2g_edge_ann_value_fn__233000180_A_New() *A_arbace_j2g_edge_ann_value_fn__233000180_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000180_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Invoke_O_O__O(self, p__233000179__1 any) any { var vec__233000181__2 any = p__233000179__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000181__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000181__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1235 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = v__4; if linked_1236 == nil { tmp1 = ifn_1237.Invoke_O__O(arg_1238) } else { tmp1 = linked_1236.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1235, arg_1238) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }



func A_arbace_j2g_edge_info_value_A_New() *A_arbace_j2g_edge_info_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Ctor() {}
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Invoke_O_O__O(self, info__0 any) any { var n__2 any = A_arbace_j2g_edge_A_const_80.Invoke_O__O(info__0); var root_1368 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1370 lang.IFn; if









	linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var root_1295 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1297 lang.IFn; if /*line :220:1*/ linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any; var root_1259 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1261 lang.IFn; if /*line :219:1*/ linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = info__0; var arg_1263 any = A_arbace_j2g_edge_A_const_116; var arg_1264 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1260 == nil { arg_1298 = ifn_1261.Invoke_O_O_O__O(arg_1262, arg_1263, arg_1264) } else { arg_1298 = linked_1260.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1259, arg_1262, arg_1263, arg_1264) }; var arg_1299 any = A_arbace_j2g_edge_A_const_84; var arg_1300 any; var tmp1 any =
	A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(n__2); var tmp2 *jrt.Class; var fncls__1294 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class; if fncls__1294 == nil { var fncls__1294d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class = fncls__1294d; tmp2 = fncls__1294d } else { tmp2 = fncls__1294 }; arg_1300 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1296 == nil { arg_1371 = ifn_1297.Invoke_O_O_O__O(arg_1298, arg_1299, arg_1300) } else { arg_1371 = linked_1296.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1295, arg_1298, arg_1299, arg_1300) }; var arg_1372 any = A_arbace_j2g_edge_A_const_86; var arg_1373 any; var tmp3 any =


	A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(n__2); var tmp4 *jrt.Class; var fncls__1367 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class; if fncls__1367 == nil { var fncls__1367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class = fncls__1367d; tmp4 = fncls__1367d } else { tmp4 = fncls__1367 }; arg_1373 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_1369 == nil { return ifn_1370.Invoke_O_O_O__O(arg_1371, arg_1372, arg_1373) } else { return linked_1369.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1368, arg_1371, arg_1372, arg_1373) } }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Invoke_O_O__O(self, fs__1 any) any { var root_1289 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any; var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(t.F_n); var tmp2 *jrt.Class; var fncls__1288 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class; if fncls__1288 == nil { var fncls__1288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class = fncls__1288d; tmp2 = fncls__1288d } else { tmp2 = fncls__1288 }; arg_1292 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1293 any = fs__1; if linked_1290 == nil { return ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { return linked_1290.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) } }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Invoke_O_O__O(self, p1__233000186_SHARP___1 any) any {
	var root_1282 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var root_1271 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1273 lang.IFn
//line :220:1
	if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any; var root_1265 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = p1__233000186_SHARP___1; var arg_1269 any = A_arbace_j2g_edge_A_const_85; var arg_1270 any = t.F_n; if linked_1266 == nil { arg_1274 = ifn_1267.Invoke_O_O_O__O(arg_1268, arg_1269, arg_1270) } else { arg_1274 = linked_1266.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1265, arg_1268, arg_1269, arg_1270) }; var arg_1275 any = A_arbace_j2g_edge_A_const_116; var arg_1276 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1272 == nil { arg_1285 = ifn_1273.Invoke_O_O_O__O(arg_1274, arg_1275, arg_1276) } else { arg_1285 = linked_1272.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1271, arg_1274, arg_1275, arg_1276) }
	var arg_1286 any = A_arbace_j2g_edge_A_const_60; var arg_1287 any; var root_1277 any = A_arbace_j2g_edge_A_const_112.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, A_arbace_j2g_edge_coerce_const_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = A_arbace_j2g_edge_A_const_81.Invoke_O__O(p1__233000186_SHARP___1); var arg_1281 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(p1__233000186_SHARP___1); if linked_1278 == nil { arg_1287 = ifn_1279.Invoke_O_O__O(arg_1280, arg_1281) } else { arg_1287 = linked_1278.(*A_arbace_j2g_edge_coerce_const_A).Invoke_O_O_O__O(root_1277, arg_1280, arg_1281) }; if linked_1283 == nil { return ifn_1284.Invoke_O_O_O__O(arg_1285, arg_1286, arg_1287) } else { return linked_1283.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1282, arg_1285, arg_1286, arg_1287)
	} }
func A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Invoke_O_O__O(self, ms__1 any) any {
	var root_1362 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any; var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(t.F_n); var tmp2 *jrt.Class; var fncls__1361 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class; if fncls__1361 == nil { var fncls__1361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class = fncls__1361d; tmp2 = fncls__1361d } else { tmp2 = fncls__1361 }; arg_1365 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1366 any = ms__1; if linked_1363 == nil { return ifn_1364.Invoke_O_O__O(arg_1365, arg_1366) } else { return linked_1363.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1362, arg_1365, arg_1366) } }
//line :224:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Invoke_O_O__O(self, m__1 any) any { var m__2 any; var root_1314 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1316 lang.IFn; if
													linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any; var root_1307 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var root_1301 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = m__1; var arg_1305 any = A_arbace_j2g_edge_A_const_85; var arg_1306 any = t.F_n; if linked_1302 == nil { arg_1310 = ifn_1303.Invoke_O_O_O__O(arg_1304, arg_1305, arg_1306) } else { arg_1310 = linked_1302.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1301, arg_1304, arg_1305, arg_1306) }; var arg_1311 any = A_arbace_j2g_edge_A_const_116; var arg_1312 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1308 == nil { arg_1317 = ifn_1309.Invoke_O_O_O__O(arg_1310, arg_1311, arg_1312) } else { arg_1317 = linked_1308.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1307, arg_1310, arg_1311, arg_1312) }; var arg_1318 any = A_arbace_j2g_edge_A_const_91; var arg_1319 any; var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New(); var tmp2 *jrt.Class; var fncls__1313 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class; if fncls__1313 == nil { var fncls__1313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class = fncls__1313d; tmp2 = fncls__1313d } else { tmp2 = fncls__1313 }; arg_1319 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1315 == nil { m__2 = ifn_1316.Invoke_O_O_O__O(arg_1317, arg_1318, arg_1319) } else { m__2 = linked_1315.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1314, arg_1317, arg_1318, arg_1319) }; if
													lang.Util_Equiv_O_O__Z_NoInit(Lit_63, A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__2)) { return m__2 } else { var a__3 any; var root_1320 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1322 lang.IFn

		if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any; var or__1927000174__auto____3 any = A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__2); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_1323 = or__1927000174__auto____3 } else { arg_1323 = lang.PersistentVector_EMPTY.Ref() }; if linked_1321 == nil { a__3 = ifn_1322.Invoke_O__O(arg_1323) } else { a__3 = linked_1321.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1320, arg_1323) }
//line :226:1
		var pa__4 any; var or__1927000174__auto____4 any; var G__233000196__4_ any = A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__2)


		if lang.Util_Identical_O_O__Z_NoInit(G__233000196__4_, nil) { or__1927000174__auto____4 = nil } else { var root_1324 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = G__233000196__4_; if linked_1325 == nil { or__1927000174__auto____4 = ifn_1326.Invoke_O__O(arg_1327) } else { or__1927000174__auto____4 = linked_1325.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1324, arg_1327) } }; if jrt.J2g_Truth(or__1927000174__auto____4) { pa__4 = or__1927000174__auto____4 } else {
			var root_1341 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any; var root_1336 any = A_arbace_j2g_edge_A_const_119.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any; var tmp3 any; var root_1332 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any; var root_1328 any = A_arbace_j2g_edge_A_const_120.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__2); if linked_1329 == nil { arg_1335 = ifn_1330.Invoke_O__O(arg_1331) } else { arg_1335 = linked_1329.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1328, arg_1331) }; if linked_1333 == nil { tmp3 = ifn_1334.Invoke_O__O(arg_1335) } else { tmp3 = linked_1333.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1332, arg_1335) }; arg_1339 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp3)).Ref(); var arg_1340 any = lang.PersistentVector_EMPTY.Ref(); if linked_1337 == nil { arg_1344 = ifn_1338.Invoke_O_O__O(arg_1339, arg_1340) } else { arg_1344 = linked_1337.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_1336, arg_1339, arg_1340) }; if linked_1342 == nil { pa__4 = ifn_1343.Invoke_O__O(arg_1344) } else { pa__4 = linked_1342.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1341, arg_1344) } }
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_92.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_edge_A_const_87; var tmp6 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(a__3); var tmp7 *jrt.Class; var fncls__1345 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class
		if fncls__1345 == nil { var fncls__1345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class = fncls__1345d; tmp7 = fncls__1345d } else { tmp7 = fncls__1345 }
//line :231:1
		var tmp8 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp9 any = A_arbace_j2g_edge_A_const_89; var tmp10 any; var root_1348 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1350 lang.IFn

		if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var tmp11 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New(); var tmp12 *jrt.Class; var fncls__1347 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class; if fncls__1347 == nil { var fncls__1347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class = fncls__1347d; tmp12 = fncls__1347d } else { tmp12 = fncls__1347 }; arg_1351 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_1352 any = pa__4; if linked_1349 == nil { tmp10 = ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { tmp10 = linked_1349.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) }
//line :231:1
		return tmp4.Invoke_O_O_O_O_O__O(m__2, tmp5, tmp8, tmp9, tmp10) } }
//line :225:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Ctor() {}
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Invoke_O_O__O(self, p1__233000187_SHARP___1 any) any { var or__1927000174__auto____2 any = p1__233000187_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.PersistentVector_EMPTY.Ref() } }






func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Invoke_O__O(self any) any { var t_ any = t.F_a; t.F_a = nil; return t_ }
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Ctor() {}
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(x__1); var tmp2 *jrt.Class; var fncls__1346 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class; if fncls__1346 == nil { var fncls__1346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class = fncls__1346d; tmp2 = fncls__1346d } else { tmp2 = fncls__1346 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :233:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Invoke_O__O(self any) any { var t_ any = t.F_x; t.F_x = nil; return t_ }


func A_arbace_j2g_edge_generics_value_A_New() *A_arbace_j2g_edge_generics_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Ctor() {}
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Invoke_O_O__O(self, g__0 any) any {
	if jrt.J2g_Truth(g__0) {
		var root_1387 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = g__0; var arg_1391 any = A_arbace_j2g_edge_A_const_86; var arg_1392 any; var tmp1 any = A_arbace_j2g_edge_generics_value_fn__233000207_A_New(); var tmp2 *jrt.Class; var fncls__1386 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class; if fncls__1386 == nil { var fncls__1386d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class = fncls__1386d; tmp2 = fncls__1386d } else { tmp2 = fncls__1386 }; arg_1392 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1388 == nil { return ifn_1389.Invoke_O_O_O__O(arg_1390, arg_1391, arg_1392) } else { return linked_1388.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1387, arg_1390, arg_1391, arg_1392) } } else {
//line :237:1
			return nil } }
func A_arbace_j2g_edge_generics_value_fn__233000207_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Invoke_O_O__O(self, ms__1 any) any { var root_1381 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any; var tmp1 any = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New(); var tmp2 *jrt.Class; var fncls__1380 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class; if fncls__1380 == nil { var fncls__1380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class = fncls__1380d; tmp2 = fncls__1380d } else { tmp2 = fncls__1380 }; arg_1384 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1385 any = ms__1; if linked_1382 == nil { return ifn_1383.Invoke_O_O__O(arg_1384, arg_1385) } else { return linked_1382.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1381, arg_1384, arg_1385) } }
//line :238:1
func A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Invoke_O_O__O(self, p1__233000206_SHARP___1 any) any { var root_1374 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = p1__233000206_SHARP___1; var arg_1378 any = A_arbace_j2g_edge_A_const_116; var arg_1379 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1375 == nil { return ifn_1376.Invoke_O_O_O__O(arg_1377, arg_1378, arg_1379) } else { return linked_1375.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1374, arg_1377, arg_1378, arg_1379) } }

func A_arbace_j2g_edge_canonical_A_New() *A_arbace_j2g_edge_canonical_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any {



	var tmp1 any; var root_1397 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any; var root_1393 any = A_arbace_j2g_edge_A_const_8.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = A_arbace_j2g_edge_A_const_121.GetRawRoot__O(); if linked_1394 == nil { arg_1400 = ifn_1395.Invoke_O__O(arg_1396) } else { arg_1400 = linked_1394.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1393, arg_1396) }; var arg_1401 any = n__0; if linked_1398 == nil { tmp1 = ifn_1399.Invoke_O_O__O(arg_1400, arg_1401) } else { tmp1 = linked_1398.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1397, arg_1400, arg_1401) }; if jrt.J2g_Truth(tmp1) { return facets__1 } else { var G__233000214__3_ any = facets__1; var G__233000214__4_ any

		if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1)) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_122; var tmp4 any = A_arbace_j2g_edge_canonical_fn__233000215_A_New(); var tmp5 *jrt.Class; var fncls__1411 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class; if fncls__1411 == nil { var fncls__1411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class = fncls__1411d; tmp5 = fncls__1411d } else { tmp5 = fncls__1411 }; G__233000214__4_ = tmp2.Invoke_O_O_O__O(G__233000214__3_, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } else {
//line :246:1
				G__233000214__4_ = G__233000214__3_ }; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_124.Invoke_O__O(facets__1)) {

					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_edge_A_const_125; var tmp8 any = A_arbace_j2g_edge_canonical_fn__233000217_A_New(); var tmp9 *jrt.Class; var fncls__1427 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class; if fncls__1427 == nil { var fncls__1427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class = fncls__1427d; tmp9 = fncls__1427d } else { tmp9 = fncls__1427 }; return tmp6.Invoke_O_O_O__O(G__233000214__4_, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)) } else {
//line :246:1
						return G__233000214__4_ } } }
func A_arbace_j2g_edge_canonical_fn__233000215_A_New() *A_arbace_j2g_edge_canonical_fn__233000215_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000215_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Ctor() {}
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Invoke_O_O__O(self, p1__233000212_SHARP___1 any) any { var root_1407 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any; var root_1402 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = A_arbace_j2g_edge_A_const_123.GetRawRoot__O(); var arg_1406 any = p1__233000212_SHARP___1; if linked_1403 == nil { arg_1410 = ifn_1404.Invoke_O_O__O(arg_1405, arg_1406) } else { arg_1410 = linked_1403.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1402, arg_1405, arg_1406) }; if linked_1408 == nil { return ifn_1409.Invoke_O__O(arg_1410) } else { return linked_1408.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1407, arg_1410) } }
func A_arbace_j2g_edge_canonical_fn__233000217_A_New() *A_arbace_j2g_edge_canonical_fn__233000217_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000217_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Ctor() {}
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Invoke_O_O__O(self, p1__233000213_SHARP___1 any) any { var root_1423 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any; var root_1418 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = A_arbace_j2g_edge_A_const_123.GetRawRoot__O(); var arg_1422 any = p1__233000213_SHARP___1; if linked_1419 == nil { arg_1426 = ifn_1420.Invoke_O_O__O(arg_1421, arg_1422) } else { arg_1426 = linked_1419.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1418, arg_1421, arg_1422) }; if linked_1424 == nil { return ifn_1425.Invoke_O__O(arg_1426) } else { return linked_1424.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1423, arg_1426) } }

func A_arbace_j2g_edge_read_edge_A_New() *A_arbace_j2g_edge_read_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var root_1556 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1558 lang.IFn; if


	linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_129, jrt.Boolean_FALSE.Ref()); if linked_1557 == nil { ifn_1558.Invoke_O__O(arg_1559) } else { linked_1557.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1556, arg_1559) }; var tmp1 any = A_arbace_j2g_edge_read_edge_fn__233000220_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__1445 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000220_A_fn_class; if fncls__1445 == nil { var fncls__1445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_j2g_edge_read_edge_fn__233000220_A_fn_class = fncls__1445d; tmp2 = fncls__1445d } else { tmp2 = fncls__1445 }; e__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var root_1545 any =
	A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = e__2; var arg_1549 any = A_arbace_j2g_edge_A_const_99; var arg_1550 any; var tmp3 any = A_arbace_j2g_edge_read_edge_fn__233000222_A_New(); var tmp4 *jrt.Class; var fncls__1544 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class; if
	fncls__1544 == nil { var fncls__1544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class = fncls__1544d; tmp4 = fncls__1544d } else { tmp4 = fncls__1544 }; arg_1550 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if /*line :254:1*/ linked_1546 == nil { return ifn_1547.Invoke_O_O_O__O(arg_1548, arg_1549, arg_1550) } else { return linked_1546.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1545, arg_1548, arg_1549, arg_1550) } }
//line :253:1
func A_arbace_j2g_edge_read_edge_fn__233000220_A_New_O(p0 any) *A_arbace_j2g_edge_read_edge_fn__233000220_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000220_A{}; t.Ctor_O(p0); return t }
//line :253:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000220_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :253:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000220_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1438 any = A_arbace_j2g_edge_A_const_126.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; arg_1441 = tmp2.Invoke_O__O(tmp3); if linked_1439 == nil { tmp1 = ifn_1440.Invoke_O__O(arg_1441) } else { tmp1 = linked_1439.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1438, arg_1441) } }; return nil }(); var root_1442 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; if linked_1443 == nil { ifn_1444.Invoke__O() } else { linked_1443.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1442) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_j2g_edge_read_edge_fn__233000222_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Invoke_O_O__O(self, cs__1 any) any {
	var root_1539 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1543 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New(); var tmp2 *jrt.Class; var fncls__1538 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class; if fncls__1538 == nil { var fncls__1538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class = fncls__1538d; tmp2 = fncls__1538d } else { tmp2 = fncls__1538 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1543 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); if linked_1540 == nil { return ifn_1541.Invoke_O_O__O(arg_1542, arg_1543) } else { return linked_1540.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1539, arg_1542, arg_1543) } }
//line :256:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Ctor() {}
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Invoke_O_O__O(self, s__233000224__1 any) any { var tmp1 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(s__233000224__1, self); var tmp2 *jrt.Class; var fncls__1537 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class; if fncls__1537 == nil { var fncls__1537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class = fncls__1537d; tmp2 = fncls__1537d } else { tmp2 = fncls__1537 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :256:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Ctor_O_O(c__s__233000224, c__iter__233000223 any) { t.F_s__233000224 = c__s__233000224; t.F_iter__233000223 = c__iter__233000223 }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Invoke_O__O(self any) any { { var s__233000224__1 any; var t_ any = t.F_s__233000224; t.F_s__233000224 = nil; s__233000224__1 = t_; for { var temp__1927000414__auto____2 any; var root_1446 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = s__233000224__1; if linked_1447 == nil { temp__1927000414__auto____2 = ifn_1448.Invoke_O__O(arg_1449) } else { temp__1927000414__auto____2 = linked_1447.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1446, arg_1449) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000224__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1450 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = s__233000224__3; if linked_1451 == nil { tmp1 = ifn_1452.Invoke_O__O(arg_1453) } else { tmp1 = linked_1451.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1450, arg_1453) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1454 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = s__233000224__3; if linked_1455 == nil { c__1927001037__auto____4 = ifn_1456.Invoke_O__O(arg_1457) } else { c__1927001037__auto____4 = linked_1455.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1454, arg_1457) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000226__6 any; var root_1458 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1459 == nil { b__233000226__6 = ifn_1460.Invoke_O__O(arg_1461) } else { b__233000226__6 = linked_1459.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1458, arg_1461) }; var tmp2 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(b__233000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1484 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class; if fncls__1484 == nil { var fncls__1484d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class = fncls__1484d; tmp3 = fncls__1484d } else { tmp3 = fncls__1484 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1493 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any; var root_1485 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = b__233000226__6; if linked_1486 == nil { arg_1496 = ifn_1487.Invoke_O__O(arg_1488) } else { arg_1496 = linked_1486.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1485, arg_1488) }; var arg_1497 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); var tmp5 any; var root_1489 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = s__233000224__3; if linked_1490 == nil { tmp5 = ifn_1491.Invoke_O__O(arg_1492) } else { tmp5 = linked_1490.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1489, arg_1492) }; arg_1497 = tmp4.Invoke_O__O(tmp5); if linked_1494 == nil { return ifn_1495.Invoke_O_O__O(arg_1496, arg_1497) } else { return linked_1494.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1493, arg_1496, arg_1497) } } else { var root_1502 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any; var root_1498 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = b__233000226__6; if linked_1499 == nil { arg_1505 = ifn_1500.Invoke_O__O(arg_1501) } else { arg_1505 = linked_1499.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1498, arg_1501) }; var arg_1506 any; if linked_1503 == nil { return ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { return linked_1503.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) } } } else { var vec__233000235__4 any; var root_1507 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = s__233000224__3; if linked_1508 == nil { vec__233000235__4 = ifn_1509.Invoke_O__O(arg_1510) } else { vec__233000235__4 = linked_1508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1507, arg_1510) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000235__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000235__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1532 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var tmp6 any; var G__233000238__7_ any = facets__6; var G__233000238__8_ any
																if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var root_1511 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = G__233000238__7_; var arg_1515 any = A_arbace_j2g_edge_A_const_94; var arg_1516 any = A_arbace_j2g_edge_A_const_127.GetRawRoot__O(); if linked_1512 == nil { G__233000238__8_ = ifn_1513.Invoke_O_O_O__O(arg_1514, arg_1515, arg_1516) } else { G__233000238__8_ = linked_1512.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1511, arg_1514, arg_1515, arg_1516) } } else {
//line :257:1
			G__233000238__8_ = G__233000238__7_ }; var tmp7 any; var root_1517 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1519 lang.IFn

	if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = facets__6; var arg_1521 any = A_arbace_j2g_edge_A_const_124; if linked_1518 == nil { tmp7 = ifn_1519.Invoke_O_O__O(arg_1520, arg_1521) } else { tmp7 = linked_1518.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1517, arg_1520, arg_1521) }
//line :257:1
	if jrt.J2g_Truth(tmp7) {

		var root_1522 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = G__233000238__8_; var arg_1526 any = A_arbace_j2g_edge_A_const_124; var arg_1527 any = A_arbace_j2g_edge_A_const_128.GetRawRoot__O(); if linked_1523 == nil { tmp6 = ifn_1524.Invoke_O_O_O__O(arg_1525, arg_1526, arg_1527) } else { tmp6 = linked_1523.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1522, arg_1525, arg_1526, arg_1527) } } else {
//line :257:1
			tmp6 = G__233000238__8_ }
//line :256:1
	arg_1535 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_1536 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); var tmp9 any; var root_1528 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = s__233000224__3; if linked_1529 == nil { tmp9 = ifn_1530.Invoke_O__O(arg_1531) } else { tmp9 = linked_1529.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1528, arg_1531) }; arg_1536 = tmp8.Invoke_O__O(tmp9); if linked_1533 == nil { return ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { return linked_1533.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :256:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Ctor_O_I_O(c__b__233000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000226 = c__b__233000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :256:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Invoke_O__O(self any) any { { var i__233000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000230__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000225__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000230__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000230__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1479 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = t.F_b__233000226; var arg_1483 any; var tmp2 any; var G__233000233__5_ any = facets__4; var G__233000233__6_ any
																	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																		var root_1462 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = G__233000233__5_; var arg_1466 any = A_arbace_j2g_edge_A_const_94; var arg_1467 any = A_arbace_j2g_edge_A_const_127.GetRawRoot__O(); if linked_1463 == nil { G__233000233__6_ = ifn_1464.Invoke_O_O_O__O(arg_1465, arg_1466, arg_1467) } else { G__233000233__6_ = linked_1463.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1462, arg_1465, arg_1466, arg_1467) } } else {
//line :257:1
			G__233000233__6_ = G__233000233__5_ }; var tmp3 any; var root_1468 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1470 lang.IFn

	if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = facets__4; var arg_1472 any = A_arbace_j2g_edge_A_const_124; if linked_1469 == nil { tmp3 = ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { tmp3 = linked_1469.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) }
//line :257:1
	if jrt.J2g_Truth(tmp3) {

		var root_1473 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = G__233000233__6_; var arg_1477 any = A_arbace_j2g_edge_A_const_124; var arg_1478 any = A_arbace_j2g_edge_A_const_128.GetRawRoot__O(); if linked_1474 == nil { tmp2 = ifn_1475.Invoke_O_O_O__O(arg_1476, arg_1477, arg_1478) } else { tmp2 = linked_1474.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1473, arg_1476, arg_1477, arg_1478) } } else {
//line :257:1
			tmp2 = G__233000233__6_ }
//line :256:1
	arg_1483 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_1480 == nil { ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { linked_1480.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) }; i__233000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000225__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_read_edge_data_A_New() *A_arbace_j2g_edge_read_edge_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Ctor() {}
//line :261:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var root_1680 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1682 lang.IFn; if


	linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_129, jrt.Boolean_FALSE.Ref()); if linked_1681 == nil { ifn_1682.Invoke_O__O(arg_1683) } else { linked_1681.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1680, arg_1683) }; var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__1571 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class; if fncls__1571 == nil { var fncls__1571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class = fncls__1571d; tmp2 = fncls__1571d } else { tmp2 = fncls__1571 }; e__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var root_1669 any =
	A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = e__2; var arg_1673 any = A_arbace_j2g_edge_A_const_99; var arg_1674 any; var tmp3 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New(); var tmp4 *jrt.Class; var fncls__1668 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class; if
	fncls__1668 == nil { var fncls__1668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class = fncls__1668d; tmp4 = fncls__1668d } else { tmp4 = fncls__1668 }; arg_1674 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if /*line :265:1*/ linked_1670 == nil { return ifn_1671.Invoke_O_O_O__O(arg_1672, arg_1673, arg_1674) } else { return linked_1670.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1669, arg_1672, arg_1673, arg_1674) } }
//line :264:1
func A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(p0 any) *A_arbace_j2g_edge_read_edge_data_fn__233000243_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000243_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1564 any = A_arbace_j2g_edge_A_const_126.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; arg_1567 = tmp2.Invoke_O__O(tmp3); if linked_1565 == nil { tmp1 = ifn_1566.Invoke_O__O(arg_1567) } else { tmp1 = linked_1565.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1564, arg_1567) } }; return nil }(); var root_1568 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; if linked_1569 == nil { ifn_1570.Invoke__O() } else { linked_1569.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1568) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Ctor() {}
//line :266:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Invoke_O_O__O(self, cs__1 any) any {
	var root_1663 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1667 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New(); var tmp2 *jrt.Class; var fncls__1662 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class; if fncls__1662 == nil { var fncls__1662d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class = fncls__1662d; tmp2 = fncls__1662d } else { tmp2 = fncls__1662 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1667 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); if linked_1664 == nil { return ifn_1665.Invoke_O_O__O(arg_1666, arg_1667) } else { return linked_1664.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1663, arg_1666, arg_1667) } }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Ctor() {}
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Invoke_O_O__O(self, s__233000247__1 any) any { var tmp1 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(s__233000247__1, self); var tmp2 *jrt.Class; var fncls__1661 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class; if fncls__1661 == nil { var fncls__1661d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class = fncls__1661d; tmp2 = fncls__1661d } else { tmp2 = fncls__1661 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Ctor_O_O(c__s__233000247, c__iter__233000246 any) { t.F_s__233000247 = c__s__233000247; t.F_iter__233000246 = c__iter__233000246 }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Invoke_O__O(self any) any { { var s__233000247__1 any; var t_ any = t.F_s__233000247; t.F_s__233000247 = nil; s__233000247__1 = t_; for { var temp__1927000414__auto____2 any; var root_1572 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = s__233000247__1; if linked_1573 == nil { temp__1927000414__auto____2 = ifn_1574.Invoke_O__O(arg_1575) } else { temp__1927000414__auto____2 = linked_1573.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1572, arg_1575) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000247__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1576 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = s__233000247__3; if linked_1577 == nil { tmp1 = ifn_1578.Invoke_O__O(arg_1579) } else { tmp1 = linked_1577.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1576, arg_1579) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1580 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = s__233000247__3; if linked_1581 == nil { c__1927001037__auto____4 = ifn_1582.Invoke_O__O(arg_1583) } else { c__1927001037__auto____4 = linked_1581.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1580, arg_1583) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000249__6 any; var root_1584 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1585 == nil { b__233000249__6 = ifn_1586.Invoke_O__O(arg_1587) } else { b__233000249__6 = linked_1585.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1584, arg_1587) }; var tmp2 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(b__233000249__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1609 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class; if fncls__1609 == nil { var fncls__1609d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class = fncls__1609d; tmp3 = fncls__1609d } else { tmp3 = fncls__1609 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1618 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any; var root_1610 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = b__233000249__6; if linked_1611 == nil { arg_1621 = ifn_1612.Invoke_O__O(arg_1613) } else { arg_1621 = linked_1611.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1610, arg_1613) }; var arg_1622 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); var tmp5 any; var root_1614 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = s__233000247__3; if linked_1615 == nil { tmp5 = ifn_1616.Invoke_O__O(arg_1617) } else { tmp5 = linked_1615.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1614, arg_1617) }; arg_1622 = tmp4.Invoke_O__O(tmp5); if linked_1619 == nil { return ifn_1620.Invoke_O_O__O(arg_1621, arg_1622) } else { return linked_1619.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1618, arg_1621, arg_1622) } } else { var root_1627 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any; var root_1623 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = b__233000249__6; if linked_1624 == nil { arg_1630 = ifn_1625.Invoke_O__O(arg_1626) } else { arg_1630 = linked_1624.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1623, arg_1626) }; var arg_1631 any; if linked_1628 == nil { return ifn_1629.Invoke_O_O__O(arg_1630, arg_1631) } else { return linked_1628.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1627, arg_1630, arg_1631) } } } else { var vec__233000258__4 any; var root_1632 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = s__233000247__3; if linked_1633 == nil { vec__233000258__4 = ifn_1634.Invoke_O__O(arg_1635) } else { vec__233000258__4 = linked_1633.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1632, arg_1635) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000258__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000258__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1656 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any; var tmp6 any; var root_1647 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1649 lang.IFn
																if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = n__5; var arg_1651 any; var G__233000261__7_ any = facets__6; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var root_1641 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = G__233000261__7_; var arg_1645 any = A_arbace_j2g_edge_A_const_94; var arg_1646 any; var root_1636 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var arg_1640 any = A_arbace_j2g_edge_A_const_127.GetRawRoot__O(); if linked_1637 == nil { arg_1646 = ifn_1638.Invoke_O_O__O(arg_1639, arg_1640) } else { arg_1646 = linked_1637.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1636, arg_1639, arg_1640) }; if linked_1642 == nil { arg_1651 = ifn_1643.Invoke_O_O_O__O(arg_1644, arg_1645, arg_1646) } else { arg_1651 = linked_1642.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1641, arg_1644, arg_1645, arg_1646) } } else {
//line :268:1
			arg_1651 = G__233000261__7_ }; if linked_1648 == nil { tmp6 = ifn_1649.Invoke_O_O__O(arg_1650, arg_1651) } else { tmp6 = linked_1648.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1647, arg_1650, arg_1651) }
//line :267:1
	arg_1659 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_1660 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); var tmp8 any; var root_1652 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = s__233000247__3; if linked_1653 == nil { tmp8 = ifn_1654.Invoke_O__O(arg_1655) } else { tmp8 = linked_1653.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1652, arg_1655) }; arg_1660 = tmp7.Invoke_O__O(tmp8); if linked_1657 == nil { return ifn_1658.Invoke_O_O__O(arg_1659, arg_1660) } else { return linked_1657.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1656, arg_1659, arg_1660) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Ctor_O_I_O(c__b__233000249 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000249 = c__b__233000249; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Invoke_O__O(self any) any { { var i__233000248__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000248__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000253__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000248__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000253__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000253__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1604 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = t.F_b__233000249; var arg_1608 any; var tmp2 any; var root_1599 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1601 lang.IFn
																		if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = n__3; var arg_1603 any; var G__233000256__5_ any = facets__4; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																			var root_1593 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = G__233000256__5_; var arg_1597 any = A_arbace_j2g_edge_A_const_94; var arg_1598 any; var root_1588 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var arg_1592 any = A_arbace_j2g_edge_A_const_127.GetRawRoot__O(); if linked_1589 == nil { arg_1598 = ifn_1590.Invoke_O_O__O(arg_1591, arg_1592) } else { arg_1598 = linked_1589.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1588, arg_1591, arg_1592) }; if linked_1594 == nil { arg_1603 = ifn_1595.Invoke_O_O_O__O(arg_1596, arg_1597, arg_1598) } else { arg_1603 = linked_1594.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1593, arg_1596, arg_1597, arg_1598) } } else {
//line :268:1
			arg_1603 = G__233000256__5_ }; if linked_1600 == nil { tmp2 = ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { tmp2 = linked_1600.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) }
//line :267:1
	arg_1608 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_1605 == nil { ifn_1606.Invoke_O_O__O(arg_1607, arg_1608) } else { linked_1605.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1604, arg_1607, arg_1608) }; i__233000248__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000248__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_edge_write_edge_BANG__A_New() *A_arbace_j2g_edge_write_edge_BANG__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_write_edge_BANG__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Ctor() {}
//line :271:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Invoke_O_O_O__O(self, f__0, edge__1 any) any {
	lang.IFn_Cast(A_arbace_j2g_edge_A_const_132.GetRawRoot__O()).Invoke_O__O(f__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_130.GetRawRoot__O()); var tmp2 any; var root_1684 any = A_arbace_j2g_edge_A_const_131.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, A_arbace_j2g_edge_edge_text_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = edge__1; if linked_1685 == nil { tmp2 = ifn_1686.Invoke_O__O(arg_1687) } else { tmp2 = linked_1685.(*A_arbace_j2g_edge_edge_text_A).Invoke_O_O__O(root_1684, arg_1687) }; return tmp1.Invoke_O_O__O(f__0, tmp2)
}
func A_arbace_j2g_edge__main_A_New() *A_arbace_j2g_edge__main_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge__main_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_j2g_edge__main_A) Ctor() {}
//line :275:1
func (t *A_arbace_j2g_edge__main_A) DoInvoke_O_O_O__O(self, cmd__0, args__1 any) any { var G__233000267__3_ any = cmd__0; switch


	lang.Util_Hash_O__I_NoInit(G__233000267__3_) { case 103785528: if lang.Util_Equiv_O_O__Z_NoInit(G__233000267__3_, Lit_1) { var vec__233000268__4 any = args__1; var seq__233000269__5 any; var root_1698 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1700 lang.IFn
		if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any = vec__233000268__4; if linked_1699 == nil { seq__233000269__5 = ifn_1700.Invoke_O__O(arg_1701) } else { seq__233000269__5 = linked_1699.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1698, arg_1701) }
//line :278:1
		var first__233000270__6 any; var root_1702 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1704 lang.IFn
		if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any = seq__233000269__5; if linked_1703 == nil { first__233000270__6 = ifn_1704.Invoke_O__O(arg_1705) } else { first__233000270__6 = linked_1703.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1702, arg_1705) }
//line :278:1
		var seq__233000269__7 any; var root_1706 any = A_arbace_j2g_edge_A_const_97.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1708 lang.IFn
		if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = seq__233000269__5; if linked_1707 == nil { seq__233000269__7 = ifn_1708.Invoke_O__O(arg_1709) } else { seq__233000269__7 = linked_1707.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1706, arg_1709) }
//line :278:1
		var out__8 any = first__233000270__6; var ins__9 any = seq__233000269__7; var root_1719 any = A_arbace_j2g_edge_A_const_133.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, A_arbace_j2g_edge_write_edge_BANG__A_fn_class); var ifn_1721 lang.IFn

		if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = out__8; var arg_1723 any; var root_1715 any = A_arbace_j2g_edge_A_const_134.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, A_arbace_j2g_edge_merge_edges_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any; var root_1710 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = A_arbace_j2g_edge_A_const_135.GetRawRoot__O(); var arg_1714 any = ins__9; if linked_1711 == nil { arg_1718 = ifn_1712.Invoke_O_O__O(arg_1713, arg_1714) } else { arg_1718 = linked_1711.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1710, arg_1713, arg_1714) }; if linked_1716 == nil { arg_1723 = ifn_1717.Invoke_O__O(arg_1718) } else { arg_1723 = linked_1716.(*A_arbace_j2g_edge_merge_edges_A).Invoke_O_O__O(root_1715, arg_1718) }; if linked_1720 == nil { return ifn_1721.Invoke_O_O__O(arg_1722, arg_1723) } else { return linked_1720.(*A_arbace_j2g_edge_write_edge_BANG__A).Invoke_O_O_O__O(root_1719, arg_1722, arg_1723) } }
//line :278:1
	default:}; var tmp1 any; var root_1724 any = A_arbace_j2g_edge_A_const_56.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1726 lang.IFn; if


	linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, cmd__0)).Ref(); var arg_1728 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1725 == nil { tmp1 = ifn_1726.Invoke_O_O__O(arg_1727, arg_1728) } else { tmp1 = linked_1725.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1724, arg_1727, arg_1728) }; /*line :278:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }

















































































































































































































































type A_arbace_j2g_edge_A struct{ jrt.Object }

var A_arbace_j2g_edge_A_const_pool *jrt.RefArray

var A_arbace_j2g_edge_A_const_0 *lang.Var

var A_arbace_j2g_edge_A_const_1 any

var A_arbace_j2g_edge_A_const_2 any

var A_arbace_j2g_edge_A_const_3 any

var A_arbace_j2g_edge_A_const_4 any

var A_arbace_j2g_edge_A_const_5 *lang.Var

var A_arbace_j2g_edge_A_const_6 any

var A_arbace_j2g_edge_A_const_7 *lang.Var

var A_arbace_j2g_edge_A_const_8 *lang.Var

var A_arbace_j2g_edge_A_const_9 *lang.Var

var A_arbace_j2g_edge_A_const_10 *lang.Var

var A_arbace_j2g_edge_A_const_11 any

var A_arbace_j2g_edge_A_const_12 *lang.Var

var A_arbace_j2g_edge_A_const_13 *lang.Var

var A_arbace_j2g_edge_A_const_14 *lang.Var

var A_arbace_j2g_edge_A_const_15 *lang.Var

var A_arbace_j2g_edge_A_const_16 *lang.Var

var A_arbace_j2g_edge_A_const_17 *lang.Var

var A_arbace_j2g_edge_A_const_18 *lang.Var

var A_arbace_j2g_edge_A_const_19 *lang.Var

var A_arbace_j2g_edge_A_const_20 *lang.Var

var A_arbace_j2g_edge_A_const_21 *lang.Var

var A_arbace_j2g_edge_A_const_22 any

var A_arbace_j2g_edge_A_const_23 any

var A_arbace_j2g_edge_A_const_24 *lang.Var

var A_arbace_j2g_edge_A_const_25 any

var A_arbace_j2g_edge_A_const_26 any

var A_arbace_j2g_edge_A_const_27 *lang.Keyword

var A_arbace_j2g_edge_A_const_28 *lang.Var

var A_arbace_j2g_edge_A_const_29 *lang.Var

var A_arbace_j2g_edge_A_const_30 *lang.Var

var A_arbace_j2g_edge_A_const_31 *lang.Var

var A_arbace_j2g_edge_A_const_32 *lang.Var

var A_arbace_j2g_edge_A_const_33 *lang.Var

var A_arbace_j2g_edge_A_const_34 *lang.Var

var A_arbace_j2g_edge_A_const_35 *lang.Var

var A_arbace_j2g_edge_A_const_36 *lang.Var

var A_arbace_j2g_edge_A_const_37 *lang.Var

var A_arbace_j2g_edge_A_const_38 *lang.Var

var A_arbace_j2g_edge_A_const_39 *lang.Var

var A_arbace_j2g_edge_A_const_40 *lang.Var

var A_arbace_j2g_edge_A_const_41 *lang.Var

var A_arbace_j2g_edge_A_const_42 *lang.Var

var A_arbace_j2g_edge_A_const_43 *lang.Var

var A_arbace_j2g_edge_A_const_44 *lang.Var

var A_arbace_j2g_edge_A_const_45 *lang.Var

var A_arbace_j2g_edge_A_const_46 *lang.Var

var A_arbace_j2g_edge_A_const_47 *lang.Var

var A_arbace_j2g_edge_A_const_48 *lang.Var

var A_arbace_j2g_edge_A_const_49 *lang.Var

var A_arbace_j2g_edge_A_const_50 *lang.Var

var A_arbace_j2g_edge_A_const_51 *lang.Var

var A_arbace_j2g_edge_A_const_52 *lang.Var

var A_arbace_j2g_edge_A_const_53 *lang.Var

var A_arbace_j2g_edge_A_const_54 *lang.Var

var A_arbace_j2g_edge_A_const_55 *lang.Var

var A_arbace_j2g_edge_A_const_56 *lang.Var

var A_arbace_j2g_edge_A_const_57 *lang.Var

var A_arbace_j2g_edge_A_const_58 *lang.Var

var A_arbace_j2g_edge_A_const_59 *lang.Keyword

var A_arbace_j2g_edge_A_const_60 *lang.Keyword

var A_arbace_j2g_edge_A_const_61 *lang.Var

var A_arbace_j2g_edge_A_const_62 any

var A_arbace_j2g_edge_A_const_63 *lang.Var

var A_arbace_j2g_edge_A_const_64 *lang.Var

var A_arbace_j2g_edge_A_const_65 *lang.Var

var A_arbace_j2g_edge_A_const_66 *lang.Var

var A_arbace_j2g_edge_A_const_67 *lang.Var

var A_arbace_j2g_edge_A_const_68 *lang.Var

var A_arbace_j2g_edge_A_const_69 *lang.Var

var A_arbace_j2g_edge_A_const_70 *lang.Var

var A_arbace_j2g_edge_A_const_71 any

var A_arbace_j2g_edge_A_const_72 *lang.Var

var A_arbace_j2g_edge_A_const_73 *lang.Var

var A_arbace_j2g_edge_A_const_74 *lang.Var

var A_arbace_j2g_edge_A_const_75 *lang.Var

var A_arbace_j2g_edge_A_const_76 *lang.Var

var A_arbace_j2g_edge_A_const_77 *lang.Var

var A_arbace_j2g_edge_A_const_78 *lang.Var

var A_arbace_j2g_edge_A_const_79 *lang.Var

var A_arbace_j2g_edge_A_const_80 *lang.Keyword

var A_arbace_j2g_edge_A_const_81 *lang.Keyword

var A_arbace_j2g_edge_A_const_82 *lang.Var

var A_arbace_j2g_edge_A_const_83 *lang.Keyword

var A_arbace_j2g_edge_A_const_84 *lang.Keyword

var A_arbace_j2g_edge_A_const_85 *lang.Keyword

var A_arbace_j2g_edge_A_const_86 *lang.Keyword

var A_arbace_j2g_edge_A_const_87 *lang.Keyword

var A_arbace_j2g_edge_A_const_88 *lang.Var

var A_arbace_j2g_edge_A_const_89 *lang.Keyword

var A_arbace_j2g_edge_A_const_90 *lang.Var

var A_arbace_j2g_edge_A_const_91 *lang.Keyword

var A_arbace_j2g_edge_A_const_92 *lang.Var

var A_arbace_j2g_edge_A_const_93 *lang.Var

var A_arbace_j2g_edge_A_const_94 *lang.Keyword

var A_arbace_j2g_edge_A_const_95 *lang.Var

var A_arbace_j2g_edge_A_const_96 any

var A_arbace_j2g_edge_A_const_97 *lang.Var

var A_arbace_j2g_edge_A_const_98 *lang.Var

var A_arbace_j2g_edge_A_const_99 *lang.Keyword

var A_arbace_j2g_edge_A_const_100 *lang.Var

var A_arbace_j2g_edge_A_const_101 *lang.Var

var A_arbace_j2g_edge_A_const_102 *lang.Var

var A_arbace_j2g_edge_A_const_103 *lang.Var

var A_arbace_j2g_edge_A_const_104 *lang.Var

var A_arbace_j2g_edge_A_const_105 *lang.Var

var A_arbace_j2g_edge_A_const_106 *lang.Var

var A_arbace_j2g_edge_A_const_107 *lang.Var

var A_arbace_j2g_edge_A_const_108 *lang.Var

var A_arbace_j2g_edge_A_const_109 *lang.Var

var A_arbace_j2g_edge_A_const_110 *lang.Keyword

var A_arbace_j2g_edge_A_const_111 any

var A_arbace_j2g_edge_A_const_112 *lang.Var

var A_arbace_j2g_edge_A_const_113 any

var A_arbace_j2g_edge_A_const_114 *lang.Var

var A_arbace_j2g_edge_A_const_115 *lang.Var

var A_arbace_j2g_edge_A_const_116 *lang.Keyword

var A_arbace_j2g_edge_A_const_117 *lang.Var

var A_arbace_j2g_edge_A_const_118 *lang.Var

var A_arbace_j2g_edge_A_const_119 *lang.Var

var A_arbace_j2g_edge_A_const_120 *lang.Var

var A_arbace_j2g_edge_A_const_121 *lang.Var

var A_arbace_j2g_edge_A_const_122 any

var A_arbace_j2g_edge_A_const_123 *lang.Var

var A_arbace_j2g_edge_A_const_124 *lang.Keyword

var A_arbace_j2g_edge_A_const_125 any

var A_arbace_j2g_edge_A_const_126 *lang.Var

var A_arbace_j2g_edge_A_const_127 *lang.Var

var A_arbace_j2g_edge_A_const_128 *lang.Var

var A_arbace_j2g_edge_A_const_129 *lang.Var

var A_arbace_j2g_edge_A_const_130 *lang.Var

var A_arbace_j2g_edge_A_const_131 *lang.Var

var A_arbace_j2g_edge_A_const_132 *lang.Var

var A_arbace_j2g_edge_A_const_133 *lang.Var

var A_arbace_j2g_edge_A_const_134 *lang.Var

var A_arbace_j2g_edge_A_const_135 *lang.Var

var A_arbace_j2g_edge_A_init jrt.ClassInit

func A_arbace_j2g_edge_A_Init() { if !A_arbace_j2g_edge_A_init.Done() { A_arbace_j2g_edge_A_init.Run(A_arbace_j2g_edge_A_clinit) } }

func A_arbace_j2g_edge_A_clinit() { A_arbace_j2g_edge_A_clinit_p0(); A_arbace_j2g_edge_A_clinit_p1(); A_arbace_j2g_edge_A_clinit_p2(); A_arbace_j2g_edge_A_clinit_p3(); A_arbace_j2g_edge_A_clinit_p4(); A_arbace_j2g_edge_A_clinit_p5(); A_arbace_j2g_edge_A_clinit_p6(); A_arbace_j2g_edge_A_clinit_p7(); A_arbace_j2g_edge_A_clinit_p8(); A_arbace_j2g_edge_A_clinit_p9(); A_arbace_j2g_edge_A_clinit_p10(); A_arbace_j2g_edge_A_clinit_p11() }

func A_arbace_j2g_edge_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_edge_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 165); A_arbace_j2g_edge_A_const_0 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[29]); A_arbace_j2g_edge_A_const_1 = A_arbace_j2g_edge_A_const_pool.A[30]; A_arbace_j2g_edge_A_const_2 = A_arbace_j2g_edge_A_const_pool.A[31]; A_arbace_j2g_edge_A_const_3 = A_arbace_j2g_edge_A_const_pool.A[32]; A_arbace_j2g_edge_A_const_4 = A_arbace_j2g_edge_A_const_pool.A[33]; A_arbace_j2g_edge_A_const_5 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[34]); A_arbace_j2g_edge_A_const_6 = A_arbace_j2g_edge_A_const_pool.A[35]; A_arbace_j2g_edge_A_const_7 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[36]); A_arbace_j2g_edge_A_const_8 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[37]); A_arbace_j2g_edge_A_const_9 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[38]); A_arbace_j2g_edge_A_const_10 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[39]); A_arbace_j2g_edge_A_const_11 = A_arbace_j2g_edge_A_const_pool.A[40] }

func A_arbace_j2g_edge_A_clinit_p1() { A_arbace_j2g_edge_A_const_12 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[41]); A_arbace_j2g_edge_A_const_13 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[42]); A_arbace_j2g_edge_A_const_14 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[43]); A_arbace_j2g_edge_A_const_15 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[44]); A_arbace_j2g_edge_A_const_16 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[45]); A_arbace_j2g_edge_A_const_17 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[46]); A_arbace_j2g_edge_A_const_18 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[47]); A_arbace_j2g_edge_A_const_19 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[48]); A_arbace_j2g_edge_A_const_20 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[49]); A_arbace_j2g_edge_A_const_21 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[50]); A_arbace_j2g_edge_A_const_22 = A_arbace_j2g_edge_A_const_pool.A[51]; A_arbace_j2g_edge_A_const_23 = A_arbace_j2g_edge_A_const_pool.A[52] }

func A_arbace_j2g_edge_A_clinit_p2() { A_arbace_j2g_edge_A_const_24 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[53]); A_arbace_j2g_edge_A_const_25 = A_arbace_j2g_edge_A_const_pool.A[54]; A_arbace_j2g_edge_A_const_26 = A_arbace_j2g_edge_A_const_pool.A[55]; A_arbace_j2g_edge_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[56]); A_arbace_j2g_edge_A_const_28 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[57]); A_arbace_j2g_edge_A_const_29 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[58]); A_arbace_j2g_edge_A_const_30 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[59]); A_arbace_j2g_edge_A_const_31 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[60]); A_arbace_j2g_edge_A_const_32 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[61]); A_arbace_j2g_edge_A_const_33 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[62]); A_arbace_j2g_edge_A_const_34 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[63]); A_arbace_j2g_edge_A_const_35 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[64]) }

func A_arbace_j2g_edge_A_clinit_p3() { A_arbace_j2g_edge_A_const_36 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[65]); A_arbace_j2g_edge_A_const_37 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[66]); A_arbace_j2g_edge_A_const_38 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[67]); A_arbace_j2g_edge_A_const_39 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[68]); A_arbace_j2g_edge_A_const_40 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[69]); A_arbace_j2g_edge_A_const_41 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[70]); A_arbace_j2g_edge_A_const_42 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[71]); A_arbace_j2g_edge_A_const_43 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[72]); A_arbace_j2g_edge_A_const_44 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[73]); A_arbace_j2g_edge_A_const_45 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[74]); A_arbace_j2g_edge_A_const_46 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[75]); A_arbace_j2g_edge_A_const_47 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[76]) }

func A_arbace_j2g_edge_A_clinit_p4() { A_arbace_j2g_edge_A_const_48 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[77]); A_arbace_j2g_edge_A_const_49 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[78]); A_arbace_j2g_edge_A_const_50 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[79]); A_arbace_j2g_edge_A_const_51 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[80]); A_arbace_j2g_edge_A_const_52 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[81]); A_arbace_j2g_edge_A_const_53 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[82]); A_arbace_j2g_edge_A_const_54 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[83]); A_arbace_j2g_edge_A_const_55 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[84]); A_arbace_j2g_edge_A_const_56 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[85]); A_arbace_j2g_edge_A_const_57 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[86]); A_arbace_j2g_edge_A_const_58 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[87]); A_arbace_j2g_edge_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[88]) }

func A_arbace_j2g_edge_A_clinit_p5() { A_arbace_j2g_edge_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[89]); A_arbace_j2g_edge_A_const_61 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[90]); A_arbace_j2g_edge_A_const_62 = A_arbace_j2g_edge_A_const_pool.A[91]; A_arbace_j2g_edge_A_const_63 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[92]); A_arbace_j2g_edge_A_const_64 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[93]); A_arbace_j2g_edge_A_const_65 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[94]); A_arbace_j2g_edge_A_const_66 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[95]); A_arbace_j2g_edge_A_const_67 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[96]); A_arbace_j2g_edge_A_const_68 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[97]); A_arbace_j2g_edge_A_const_69 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[98]); A_arbace_j2g_edge_A_const_70 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[99]); A_arbace_j2g_edge_A_const_71 = A_arbace_j2g_edge_A_const_pool.A[100] }

func A_arbace_j2g_edge_A_clinit_p6() { A_arbace_j2g_edge_A_const_72 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[101]); A_arbace_j2g_edge_A_const_73 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[102]); A_arbace_j2g_edge_A_const_74 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[103]); A_arbace_j2g_edge_A_const_75 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[104]); A_arbace_j2g_edge_A_const_76 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[105]); A_arbace_j2g_edge_A_const_77 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[106]); A_arbace_j2g_edge_A_const_78 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[107]); A_arbace_j2g_edge_A_const_79 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[108]); A_arbace_j2g_edge_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[109]); A_arbace_j2g_edge_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[110]); A_arbace_j2g_edge_A_const_82 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[111]); A_arbace_j2g_edge_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[112]) }

func A_arbace_j2g_edge_A_clinit_p7() { A_arbace_j2g_edge_A_const_84 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[113]); A_arbace_j2g_edge_A_const_85 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[114]); A_arbace_j2g_edge_A_const_86 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[115]); A_arbace_j2g_edge_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[116]); A_arbace_j2g_edge_A_const_88 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[117]); A_arbace_j2g_edge_A_const_89 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[118]); A_arbace_j2g_edge_A_const_90 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[119]); A_arbace_j2g_edge_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[120]); A_arbace_j2g_edge_A_const_92 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[121]); A_arbace_j2g_edge_A_const_93 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[122]); A_arbace_j2g_edge_A_const_94 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[123]); A_arbace_j2g_edge_A_const_95 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[124]) }

func A_arbace_j2g_edge_A_clinit_p8() { A_arbace_j2g_edge_A_const_96 = A_arbace_j2g_edge_A_const_pool.A[125]; A_arbace_j2g_edge_A_const_97 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[126]); A_arbace_j2g_edge_A_const_98 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[127]); A_arbace_j2g_edge_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[128]); A_arbace_j2g_edge_A_const_100 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[129]); A_arbace_j2g_edge_A_const_101 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[130]); A_arbace_j2g_edge_A_const_102 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[131]); A_arbace_j2g_edge_A_const_103 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[132]); A_arbace_j2g_edge_A_const_104 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[133]); A_arbace_j2g_edge_A_const_105 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[134]); A_arbace_j2g_edge_A_const_106 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[135]); A_arbace_j2g_edge_A_const_107 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[136]) }

func A_arbace_j2g_edge_A_clinit_p9() { A_arbace_j2g_edge_A_const_108 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[137]); A_arbace_j2g_edge_A_const_109 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[138]); A_arbace_j2g_edge_A_const_110 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[139]); A_arbace_j2g_edge_A_const_111 = A_arbace_j2g_edge_A_const_pool.A[140]; A_arbace_j2g_edge_A_const_112 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[141]); A_arbace_j2g_edge_A_const_113 = A_arbace_j2g_edge_A_const_pool.A[142]; A_arbace_j2g_edge_A_const_114 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[143]); A_arbace_j2g_edge_A_const_115 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[144]); A_arbace_j2g_edge_A_const_116 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[145]); A_arbace_j2g_edge_A_const_117 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[146]); A_arbace_j2g_edge_A_const_118 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[147]); A_arbace_j2g_edge_A_const_119 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[148]) }

func A_arbace_j2g_edge_A_clinit_p10() { A_arbace_j2g_edge_A_const_120 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[149]); A_arbace_j2g_edge_A_const_121 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[150]); A_arbace_j2g_edge_A_const_122 = A_arbace_j2g_edge_A_const_pool.A[151]; A_arbace_j2g_edge_A_const_123 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[152]); A_arbace_j2g_edge_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[153]); A_arbace_j2g_edge_A_const_125 = A_arbace_j2g_edge_A_const_pool.A[154]; A_arbace_j2g_edge_A_const_126 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[155]); A_arbace_j2g_edge_A_const_127 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[156]); A_arbace_j2g_edge_A_const_128 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[157]); A_arbace_j2g_edge_A_const_129 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[158]); A_arbace_j2g_edge_A_const_130 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[159]); A_arbace_j2g_edge_A_const_131 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[160]) }

func A_arbace_j2g_edge_A_clinit_p11() { A_arbace_j2g_edge_A_const_132 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[161]); A_arbace_j2g_edge_A_const_133 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[162]); A_arbace_j2g_edge_A_const_134 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[163]); A_arbace_j2g_edge_A_const_135 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[164]) }

func A_arbace_j2g_edge_A_New() *A_arbace_j2g_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_A) Ctor() {}

func (t *A_arbace_j2g_edge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_A_class }

func (t *A_arbace_j2g_edge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_A); return ok }

func A_arbace_j2g_edge_A_Cast(x any) *A_arbace_j2g_edge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_A_class)) }; return v }



type A_arbace_j2g_edge__main_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge__main_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_fn__233000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000177_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000180_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000217_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A struct{ j2g_header uint64; F_iter__233000061, F_s__233000062 any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A struct{ j2g_header uint64; F_b__233000064 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class *jrt.Class



type A_arbace_j2g_edge_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_coerce_const_A_fn_class *jrt.Class



type A_arbace_j2g_edge_const_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_const_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A struct{ j2g_header uint64; F_iter__233000083, F_s__233000084 any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A struct{ j2g_header uint64; F_b__233000086 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A struct{ j2g_header uint64; F_iter__233000099, F_s__233000100 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A struct{ j2g_header uint64; F_b__233000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A struct{ j2g_header uint64; F_iter__233000109, F_s__233000110 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A struct{ j2g_header uint64; F_b__233000112 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A struct{ j2g_header uint64; F_iter__233000129, F_s__233000130 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A struct{ j2g_header uint64; F_b__233000132 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000004_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000004_A_New() *A_arbace_j2g_edge_eval233000004_A { t := &A_arbace_j2g_edge_eval233000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000004_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000004_A_class }

func (t *A_arbace_j2g_edge_eval233000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000004_A); return ok }

func A_arbace_j2g_edge_eval233000004_A_Cast(x any) *A_arbace_j2g_edge_eval233000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000004_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000008_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000008_A_New() *A_arbace_j2g_edge_eval233000008_A { t := &A_arbace_j2g_edge_eval233000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000008_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000008_A_class }

func (t *A_arbace_j2g_edge_eval233000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000008_A); return ok }

func A_arbace_j2g_edge_eval233000008_A_Cast(x any) *A_arbace_j2g_edge_eval233000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000008_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000008_fn__233000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000008_fn__233000009_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000045_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A struct{ j2g_header uint64; F_a any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class *jrt.Class



type A_arbace_j2g_edge_method_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_method_key_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A struct{ j2g_header uint64; F_s__233000017, F_iter__233000016 any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A struct{ j2g_header uint64; F_b__233000019 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_double_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_double_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_string_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_string_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000220_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_edge_read_edge_fn__233000220_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A struct{ j2g_header uint64; F_s__233000224, F_iter__233000223 any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A struct{ j2g_header uint64; F_b__233000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000243_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A struct{ j2g_header uint64; F_s__233000247, F_iter__233000246 any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A struct{ j2g_header uint64; F_b__233000249 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_A struct{ j2g_header uint64; F_env_rec any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A struct{ j2g_header uint64; F_iter__233000149, F_s__233000150 any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A struct{ j2g_header uint64; F_b__233000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class *jrt.Class



type A_arbace_j2g_edge_write_edge_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_write_edge_BANG__A_fn_class *jrt.Class
