//line aot_arbace_j2g_edge.ae:1
package aot_arbace_j2g_edge

import (
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_New() *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_edge_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_edge_A_const_6); tmp2 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_edge_A_const_1, A_arbace_j2g_edge_A_const_2, A_arbace_j2g_edge_A_const_3, A_arbace_j2g_edge_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_edge_eval233000008_fn__233000009_A_New() *A_arbace_j2g_edge_eval233000008_fn__233000009_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_eval233000008_fn__233000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_edge_eval233000008_fn__233000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_j2g_edge_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_j2g_edge_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_edge_A_const_10.GetRawRoot__O(), A_arbace_j2g_edge_A_const_11) }



























func A_arbace_j2g_edge_jvm_A_New() *A_arbace_j2g_edge_jvm_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Ctor() {}
//line :29:1
func (t *A_arbace_j2g_edge_jvm_A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {



	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		var root_22 any = A_arbace_j2g_edge_A_const_13.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_edge_A_const_12.Get__O(); var arg_26 any = lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1); if linked_23 == nil { return ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { return linked_23.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) } } else {
//line :33:1
			var v__4 any = lang.IFn_Cast(f__2).Invoke__O(); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_27 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = v__4; if linked_28 == nil { tmp1 = ifn_29.Invoke_O__O(arg_30) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_27, arg_30) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var root_31 any = A_arbace_j2g_edge_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = A_arbace_j2g_edge_A_const_14.Get__O(); var arg_35 any = A_arbace_j2g_edge_A_const_17.GetRawRoot__O(); var arg_36 any = lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1); var arg_37 any = v__4; if linked_32 == nil { ifn_33.Invoke_O_O_O_O__O(arg_34, arg_35, arg_36, arg_37) } else { linked_32.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_31, arg_34, arg_35, arg_36, arg_37) } }
//line :33:1
			return v__4
		}
}



func A_arbace_j2g_edge_jvm_QMARK__A_New() *A_arbace_j2g_edge_jvm_QMARK__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_jvm_QMARK__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_edge_jvm_QMARK__A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {


	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_12.Get__O()) {
		var root_38 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_edge_A_const_12.Get__O(), section__0); var arg_42 any = k__1; if linked_39 == nil { return ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { return linked_39.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_38, arg_41, arg_42) } } else {
//line :42:1
			var v__4 bool = lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(f__2).Invoke__O()); var tmp1 any; var and__1927000168__auto____5 any = A_arbace_j2g_edge_A_const_14.Get__O()


			if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(v__4).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_16.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_14.Get__O(); var tmp4 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var tmp5 any; var root_51 any = A_arbace_j2g_edge_A_const_20.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_j2g_edge_A_const_10.GetRawRoot__O(); var arg_55 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_52 == nil { tmp5 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { tmp5 = linked_52.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, section__0, tmp5, k__1) }
//line :42:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(v__4).Ref()
		}
}







func A_arbace_j2g_edge_pr_string_A_New() *A_arbace_j2g_edge_pr_string_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_string_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Ctor() {}
//line :52:1
func (t *A_arbace_j2g_edge_pr_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_80); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(s__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__4))

		if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_22)).CharValue__C()) { jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_81) } else { if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_j2g_edge_A_const_23)).CharValue__C()) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_82) } else {
//line :56:1
				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_edge_A_const_25; if jrt.J2g_Truth(tmp1.Invoke_O_O_O__O(tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(c__5)).Ref(), A_arbace_j2g_edge_A_const_26)) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(c__5) } else {
//line :56:1
						if A_arbace_j2g_edge_A_const_27 != nil {


							jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_j2g_edge_A_const_28.GetRawRoot__O()).Invoke_O_O__O(Lit_83, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(c__5)).Ref()))) } } } }
//line :54:1
		i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :52:1
	break L1 }; var root_56 any =







	A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_80).Ref(); if linked_57 == nil { return ifn_58.Invoke_O__O(arg_59) } else { return linked_57.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_56, arg_59) } }

func A_arbace_j2g_edge_pr_double_A_New() *A_arbace_j2g_edge_pr_double_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_double_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Ctor() {}
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) InvokePrim_O_D__O(self any, d__0 float64) any {
	if jrt.Double_IsNaN_D__Z_NoInit(d__0) { return Lit_77 } else { if lang.Util_Equiv_D_D__Z_NoInit(d__0, jrt.PosInf64) { return Lit_78 } else { if lang.Util_Equiv_D_D__Z_NoInit(d__0, jrt.NegInf64) { return Lit_79 } else { if A_arbace_j2g_edge_A_const_27 != nil {


		return jrt.Double_ToString_D__String_NoInit(d__0).Ref() } else {
//line :63:1
			return nil } } } } }
//line :62:1
func (t *A_arbace_j2g_edge_pr_double_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }





func A_arbace_j2g_edge_pr_data_A_New() *A_arbace_j2g_edge_pr_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Ctor() {}
//line :68:1
func (t *A_arbace_j2g_edge_pr_data_A) Invoke_O_O__O(self, x__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return Lit_70 } else { var tmp1 any; var root_71 any = A_arbace_j2g_edge_A_const_29.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_73 lang.IFn

		if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = x__0; if linked_72 == nil { tmp1 = ifn_73.Invoke_O__O(arg_74) } else { tmp1 = linked_72.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_71, arg_74) }
//line :71:1
		if jrt.J2g_Truth(tmp1) {

			var root_75 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = x__0; if linked_76 == nil { return ifn_77.Invoke_O__O(arg_78) } else { return linked_76.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_75, arg_78) } } else {
//line :71:1
				var tmp2 any; var root_79 any = A_arbace_j2g_edge_A_const_30.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_81 lang.IFn


				if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = x__0; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_79, arg_82) }
//line :71:1
				if jrt.J2g_Truth(tmp2) {


					var root_83 any = A_arbace_j2g_edge_A_const_31.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, A_arbace_j2g_edge_pr_string_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = x__0; if linked_84 == nil { return ifn_85.Invoke_O__O(arg_86) } else { return linked_84.(*A_arbace_j2g_edge_pr_string_A).Invoke_O_O__O(root_83, arg_86) } } else {
//line :71:1
						var tmp3 any; var root_87 any = A_arbace_j2g_edge_A_const_32.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_89 lang.IFn



						if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = x__0; if linked_88 == nil { tmp3 = ifn_89.Invoke_O__O(arg_90) } else { tmp3 = linked_88.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_87, arg_90) }
//line :71:1
						if jrt.J2g_Truth(tmp3) {



							var root_91 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = x__0; if linked_92 == nil { return ifn_93.Invoke_O__O(arg_94) } else { return linked_92.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_91, arg_94) } } else {
//line :71:1
								var tmp4 any; var root_95 any = A_arbace_j2g_edge_A_const_33.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_97 lang.IFn




								if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = x__0; if linked_96 == nil { tmp4 = ifn_97.Invoke_O__O(arg_98) } else { tmp4 = linked_96.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_95, arg_98) }
//line :71:1
								if jrt.J2g_Truth(tmp4) {




									var root_99 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = x__0; if linked_100 == nil { return ifn_101.Invoke_O__O(arg_102) } else { return linked_100.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_99, arg_102) } } else {
//line :71:1
										var tmp5 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)





										if or__1927000174__auto____2 { tmp5 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp5 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp5 = or__1927000174__auto____4 } else { tmp5 = jrt.Byte_InstanceOf(x__0) } } }
//line :71:1
										if tmp5 {





											var root_103 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = x__0; if linked_104 == nil { return ifn_105.Invoke_O__O(arg_106) } else { return linked_104.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_103, arg_106) } } else {
//line :71:1
												var tmp6 bool; var or__1927000174__auto____2_2 bool = jrt.Double_InstanceOf(x__0)






												if or__1927000174__auto____2_2 { tmp6 = or__1927000174__auto____2_2 } else { tmp6 = jrt.Float_InstanceOf(x__0) }
//line :71:1
												if tmp6 {






													var root_107 any = A_arbace_j2g_edge_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_107, A_arbace_j2g_edge_pr_double_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0); if linked_108 == nil { return ifn_109.Invoke_O__O(jrt.Double_ValueOf_D__Double_NoInit(arg_110).Ref()) } else { return linked_108.(*A_arbace_j2g_edge_pr_double_A).InvokePrim_O_D__O(root_107, arg_110) } } else {
//line :71:1
														if jrt.Character_InstanceOf(x__0) {







															var root_111 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(lang.RT_CharCast_O__C_NoInit(x__0))).Ref(); if linked_112 == nil { return ifn_113.Invoke_O__O(arg_114) } else { return linked_112.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_111, arg_114) } } else {
//line :71:1
																var tmp7 any; var root_115 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn








																if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = x__0; if linked_116 == nil { tmp7 = ifn_117.Invoke_O__O(arg_118) } else { tmp7 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }
//line :71:1
																if jrt.J2g_Truth(tmp7) {








																	var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_11); var tmp9 any; var root_119 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = Lit_20; var arg_123 any; var iter__1927001039__auto____5 any; var fnbody__201 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New(); var tmp10 *jrt.Class; var fncls__200 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class; if fncls__200 == nil { var fncls__200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class = fncls__200d; tmp10 = fncls__200d } else { tmp10 = fncls__200 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__201, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp12 any; var root_202 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any; var root_207 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_211 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_208 == nil { arg_205 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { arg_205 = linked_208.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }; var arg_206 any = x__0; if linked_203 == nil { tmp12 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { tmp12 = linked_203.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }; arg_123 = tmp11.Invoke_O__O(tmp12); if linked_120 == nil { tmp9 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { tmp9 = linked_120.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() } else {
//line :71:1
																		var tmp13 any; var root_212 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_214 lang.IFn









																		if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = x__0; if linked_213 == nil { tmp13 = ifn_214.Invoke_O__O(arg_215) } else { tmp13 = linked_213.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_212, arg_215) }
//line :71:1
																		if jrt.J2g_Truth(tmp13) {









																			var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_11); var tmp15 any; var root_216 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = Lit_20; var arg_220 any; var root_221 any = A_arbace_j2g_edge_A_const_53.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var root_225 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_229 any = x__0; if linked_226 == nil { arg_224 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { arg_224 = linked_226.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) }; if linked_222 == nil { arg_220 = ifn_223.Invoke_O__O(arg_224) } else { arg_220 = linked_222.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_221, arg_224) }; if linked_217 == nil { tmp15 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { tmp15 = linked_217.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15, nil)).Ref() } else {
//line :71:1
																				var tmp16 any; var root_230 any = A_arbace_j2g_edge_A_const_55.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_232 lang.IFn










																				if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = x__0; if linked_231 == nil { tmp16 = ifn_232.Invoke_O__O(arg_233) } else { tmp16 = linked_231.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_230, arg_233) }
//line :71:1
																				if jrt.J2g_Truth(tmp16) {










																					var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_73, nil, Lit_18); var tmp18 any; var root_234 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = Lit_20; var arg_238 any; var root_239 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_243 any = x__0; if linked_240 == nil { arg_238 = ifn_241.Invoke_O_O__O(arg_242, arg_243) } else { arg_238 = linked_240.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_239, arg_242, arg_243) }; if linked_235 == nil { tmp18 = ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { tmp18 = linked_235.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_234, arg_237, arg_238) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18, nil)).Ref() } else {
//line :71:1
																						if A_arbace_j2g_edge_A_const_27 != nil { var tmp19 any; var root_244 any = A_arbace_j2g_edge_A_const_56.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_246 lang.IFn











																							if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any; var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_74, nil); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_57.GetRawRoot__O()); var tmp22 any; var root_253 any = A_arbace_j2g_edge_A_const_58.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = x__0; if linked_254 == nil { tmp22 = ifn_255.Invoke_O__O(arg_256) } else { tmp22 = linked_254.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_253, arg_256) }; arg_247 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21.Invoke_O__O(tmp22))).Ref(); var arg_248 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_59, x__0)); if linked_245 == nil { tmp19 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { tmp19 = linked_245.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }
//line :71:1
																							panic(jrt.Thrown(jrt.Throwable_Cast(tmp19))) } else { return nil
																							}
																					}
																			}
																	}
															}
													}
											}
									} } } } } }
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_New() *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Ctor() {}
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A) Invoke_O_O__O(self, s__233000017__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__199 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(s__233000017__1, self); var tmp2 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__199); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class = fncls__198d; tmp2 = fncls__198d } else { tmp2 = fncls__198 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__199, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Ctor_O_O(c__s__233000017, c__iter__233000016 any) { t.F_s__233000017 = c__s__233000017; t.F_iter__233000016 = c__iter__233000016 }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A) Invoke_O__O(self any) any { { var s__233000017__1 any; var t_ any = t.F_s__233000017; t.F_s__233000017 = nil; s__233000017__1 = t_; for { var temp__1927000414__auto____2 any; var root_124 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__233000017__1; if linked_125 == nil { temp__1927000414__auto____2 = ifn_126.Invoke_O__O(arg_127) } else { temp__1927000414__auto____2 = linked_125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_124, arg_127) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000017__3 any = temp__1927000414__auto____2; var tmp1 any; var root_128 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = s__233000017__3; if linked_129 == nil { tmp1 = ifn_130.Invoke_O__O(arg_131) } else { tmp1 = linked_129.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_128, arg_131) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_132 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__233000017__3; if linked_133 == nil { c__1927001037__auto____4 = ifn_134.Invoke_O__O(arg_135) } else { c__1927001037__auto____4 = linked_133.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_132, arg_135) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000019__6 any; var root_136 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_137 == nil { b__233000019__6 = ifn_138.Invoke_O__O(arg_139) } else { b__233000019__6 = linked_137.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_136, arg_139) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(b__233000019__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__154); A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_155 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_160 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = b__233000019__6; if linked_161 == nil { arg_158 = ifn_162.Invoke_O__O(arg_163) } else { arg_158 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_160, arg_163) }; var arg_159 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); var tmp5 any; var root_164 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__233000017__3; if linked_165 == nil { tmp5 = ifn_166.Invoke_O__O(arg_167) } else { tmp5 = linked_165.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_164, arg_167) }; arg_159 = tmp4.Invoke_O__O(tmp5); if linked_156 == nil { return ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { return linked_156.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) } } else { var root_168 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any; var root_173 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = b__233000019__6; if linked_174 == nil { arg_171 = ifn_175.Invoke_O__O(arg_176) } else { arg_171 = linked_174.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_173, arg_176) }; var arg_172 any; if linked_169 == nil { return ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { return linked_169.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) } } } else { var vec__233000027__4 any; var root_177 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = s__233000017__3; if linked_178 == nil { vec__233000027__4 = ifn_179.Invoke_O__O(arg_180) } else { vec__233000027__4 = linked_178.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_177, arg_180) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000027__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000027__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_181 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp7 any; var root_186 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = k__5; if linked_187 == nil { tmp7 = ifn_188.Invoke_O__O(arg_189) } else { tmp7 = linked_187.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_186, arg_189) }; var tmp8 any = tmp7; var tmp9 any; var root_190 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = v__6; if linked_191 == nil { tmp9 = ifn_192.Invoke_O__O(arg_193) } else { tmp9 = linked_191.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_190, arg_193) }; arg_184 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_185 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000016); var tmp11 any; var root_194 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = s__233000017__3; if linked_195 == nil { tmp11 = ifn_196.Invoke_O__O(arg_197) } else { tmp11 = linked_195.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_194, arg_197) }; arg_185 = tmp10.Invoke_O__O(tmp11); if linked_182 == nil { return ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { return linked_182.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :80:1
func A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Ctor_O_I_O(c__b__233000019 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000019 = c__b__233000019; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A) Invoke_O__O(self any) any { { var i__233000018__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000018__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000023__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000018__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000023__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000023__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_140 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = t.F_b__233000019; var arg_144 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp3 any; var root_145 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = k__3; if linked_146 == nil { tmp3 = ifn_147.Invoke_O__O(arg_148) } else { tmp3 = linked_146.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_145, arg_148) }; var tmp4 any = tmp3; var tmp5 any; var root_149 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = v__4; if linked_150 == nil { tmp5 = ifn_151.Invoke_O__O(arg_152) } else { tmp5 = linked_150.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_149, arg_152) }; arg_144 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_141 == nil { ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { linked_141.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }; i__233000018__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000018__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_const_data_A_New() *A_arbace_j2g_edge_const_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_const_data_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Ctor() {}
//line :85:1
func (t *A_arbace_j2g_edge_const_data_A) Invoke_O_O__O(self, v__0 any) any {


	if jrt.Character_InstanceOf(v__0) { return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_C__I_NoInit(lang.RT_CharCast_O__C_NoInit(v__0)))).Ref() } else { return v__0
	} }
func A_arbace_j2g_edge_ann_data_A_New() *A_arbace_j2g_edge_ann_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_edge_ann_data_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_257 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = x__0; if linked_258 == nil { and__1927000168__auto____2 = ifn_259.Invoke_O__O(arg_260) } else { and__1927000168__auto____2 = linked_258.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_257, arg_260) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_261 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = x__0; var arg_265 any = A_arbace_j2g_edge_A_const_60; if linked_262 == nil { and__1927000168__auto____3 = ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { and__1927000168__auto____3 = linked_262.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_261, arg_264, arg_265) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_266 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); if linked_267 == nil { tmp1 = ifn_268.Invoke_O__O(arg_269) } else { tmp1 = linked_267.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_266, arg_269) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_62; return tmp2.Invoke_O_O_O__O(x__0, tmp3, A_arbace_j2g_edge_A_const_63.GetRawRoot__O()) } else {
//line :93:1
			var tmp4 any; var root_276 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_278 lang.IFn

			if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = x__0; if linked_277 == nil { tmp4 = ifn_278.Invoke_O__O(arg_279) } else { tmp4 = linked_277.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_276, arg_279) }
//line :93:1
			if jrt.J2g_Truth(tmp4) {

				var root_280 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_284 any; var root_285 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any; var fnbody__295 any = A_arbace_j2g_edge_ann_data_fn__233000035_A_New(); var tmp5 *jrt.Class; var fncls__294 *jrt.Class = A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class; if fncls__294 == nil { var fncls__294d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class = fncls__294d; tmp5 = fncls__294d } else { tmp5 = fncls__294 }; arg_288 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__295, tmp5, nil); var arg_289 any = x__0; if linked_286 == nil { arg_284 = ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { arg_284 = linked_286.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_285, arg_288, arg_289) }; if linked_281 == nil { return ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { return linked_281.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) } } else {
//line :93:1
					var tmp6 any; var root_296 any = A_arbace_j2g_edge_A_const_55.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_298 lang.IFn


					if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = x__0; if linked_297 == nil { tmp6 = ifn_298.Invoke_O__O(arg_299) } else { tmp6 = linked_297.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_296, arg_299) }
//line :93:1
					if jrt.J2g_Truth(tmp6) {


						var root_300 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var arg_304 any = x__0; if linked_301 == nil { return ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { return linked_301.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } } else {
//line :93:1
							if A_arbace_j2g_edge_A_const_27 != nil { return x__0 } else { return nil
							} } } } }
func A_arbace_j2g_edge_ann_data_fn__233000035_A_New() *A_arbace_j2g_edge_ann_data_fn__233000035_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_data_fn__233000035_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_edge_ann_data_fn__233000035_A) Invoke_O_O__O(self, p__233000034__1 any) any { var vec__233000036__2 any = p__233000034__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_290 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_j2g_edge_ann_data_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = v__4; if linked_291 == nil { tmp1 = ifn_292.Invoke_O__O(arg_293) } else { tmp1 = linked_291.(*A_arbace_j2g_edge_ann_data_A).Invoke_O_O__O(root_290, arg_293) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }










func A_arbace_j2g_edge_fn__233000042_A_New() *A_arbace_j2g_edge_fn__233000042_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Ctor() {}
//line :106:1
func (t *A_arbace_j2g_edge_fn__233000042_A) Invoke_O__O(self any) any { var f__1 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_67.GetRawRoot__O()).Invoke_O_O_O__O(jrt.System_GetProperty_String__String(Lit_44).Ref(), Lit_45, Lit_46); var tmp1 any; var and__1927000168__auto____2 bool = jrt.File_Cast(f__1).IsFile__Z(); if and__1927000168__auto____2 {

	var root_311 any = A_arbace_j2g_edge_A_const_68.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var root_316 any = A_arbace_j2g_edge_A_const_21.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = jrt.System_GetProperty_String__String(Lit_47).Ref(); if linked_317 == nil { arg_314 = ifn_318.Invoke_O__O(arg_319) } else { arg_314 = linked_317.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_316, arg_319) }; var arg_315 any = Lit_48; if linked_312 == nil { tmp1 = ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { tmp1 = linked_312.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_311, arg_314, arg_315) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
		var root_320 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_324 any; var root_326 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any; var fnbody__336 any = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New(); var tmp2 *jrt.Class; var fncls__335 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class; if fncls__335 == nil { var fncls__335d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class = fncls__335d; tmp2 = fncls__335d } else { tmp2 = fncls__335 }; arg_329 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__336, tmp2, nil); if linked_327 == nil { arg_324 = ifn_328.Invoke_O__O(arg_329) } else { arg_324 = linked_327.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_326, arg_329) }; var arg_325 any; var root_337 any = A_arbace_j2g_edge_A_const_72.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()).Invoke_O__O(f__1); if linked_338 == nil { arg_325 = ifn_339.Invoke_O__O(arg_340) } else { arg_325 = linked_338.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_337, arg_340) }; if linked_321 == nil { return ifn_322.Invoke_O_O_O__O(arg_323, arg_324, arg_325) } else { return linked_321.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_320, arg_323, arg_324, arg_325) } } else {
			var root_355 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_edge_A_const_78; var arg_358 any = tmp3.Invoke_O_O__O(tmp4, A_arbace_j2g_edge_A_const_79.Get__O()); if linked_356 == nil { ifn_357.Invoke_O__O(arg_358) } else { linked_356.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_355, arg_358) }; var tmp5 *lang.Compiler_AOTFn; var fnbody__354 any = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New(); var tmp6 *jrt.Class; var fncls__353 *jrt.Class = A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class; if fncls__353 == nil { var fncls__353d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class = fncls__353d; tmp6 = fncls__353d } else { tmp6 = fncls__353 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__354, tmp6, nil); Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :108:1
			return lang.PersistentHashSet_EMPTY.Ref() } }
func A_arbace_j2g_edge_fn__233000042_fn__233000043_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000043_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000043_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000043_A) Invoke_O_O__O(self, p1__233000041_SHARP___1 any) any { var root_330 any = A_arbace_j2g_edge_A_const_70.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = A_arbace_j2g_edge_A_const_71; var arg_334 any = p1__233000041_SHARP___1; if linked_331 == nil { return ifn_332.Invoke_O_O__O(arg_333, arg_334) } else { return linked_331.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_330, arg_333, arg_334) } }
func A_arbace_j2g_edge_fn__233000042_fn__233000045_A_New() *A_arbace_j2g_edge_fn__233000042_fn__233000045_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_fn__233000042_fn__233000045_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_edge_fn__233000042_fn__233000045_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											tmp1 = lang.IFn_Cast(A_arbace_j2g_edge_A_const_74.GetRawRoot__O()).Invoke_O_O__O(Lit_51, Lit_52)
//line :110:1
	return nil }(); var root_350 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; if linked_351 == nil { ifn_352.Invoke__O() } else { linked_351.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_350) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_j2g_edge_method_key_A_New() *A_arbace_j2g_edge_method_key_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_method_key_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Ctor() {}
//line :115:1
func (t *A_arbace_j2g_edge_method_key_A) Invoke_O_O__O(self, m__0 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__0), A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__0)) }






func A_arbace_j2g_edge_info_data_A_New() *A_arbace_j2g_edge_info_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Ctor() {}
//line :122:1
func (t *A_arbace_j2g_edge_info_data_A) Invoke_O_O__O(self, info__0 any) any {









	var root_364 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any; var root_370 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_372 lang.IFn
//line :129:1
	if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any; var root_376 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_378 lang.IFn
//line :128:1
	if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = info__0; var arg_380 any = A_arbace_j2g_edge_A_const_83; if linked_377 == nil { arg_373 = ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { arg_373 = linked_377.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) }
	var arg_374 any = A_arbace_j2g_edge_A_const_84; var arg_375 any; var fnbody__405 any = A_arbace_j2g_edge_info_data_fn__233000050_A_New(); var tmp1 *jrt.Class; var fncls__404 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class; if fncls__404 == nil { var fncls__404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class = fncls__404d; tmp1 = fncls__404d } else { tmp1 = fncls__404 }; arg_375 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__405, tmp1, nil); if linked_371 == nil { arg_367 = ifn_372.Invoke_O_O_O__O(arg_373, arg_374, arg_375) } else { arg_367 = linked_371.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_370, arg_373, arg_374, arg_375)
	}

	var arg_368 any = A_arbace_j2g_edge_A_const_86; var arg_369 any; var fnbody__479 any = A_arbace_j2g_edge_info_data_fn__233000055_A_New(); var tmp2 *jrt.Class; var fncls__478 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class; if fncls__478 == nil { var fncls__478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class = fncls__478d; tmp2 = fncls__478d } else { tmp2 = fncls__478 }; arg_369 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__479, tmp2, nil); if linked_365 == nil { return ifn_366.Invoke_O_O_O__O(arg_367, arg_368, arg_369) } else { return linked_365.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_364, arg_367, arg_368, arg_369) } }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_A) Invoke_O_O__O(self, fs__1 any) any { var root_381 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any; var fnbody__403 any = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New(); var tmp1 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class; if fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class = fncls__402d; tmp1 = fncls__402d } else { tmp1 = fncls__402 }; arg_384 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__403, tmp1, nil); var arg_385 any = fs__1; if linked_382 == nil { return ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { return linked_382.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) } }
//line :129:1
func A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_New() *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Ctor() {}
//line :129:1
func (t *A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A) Invoke_O_O__O(self, p1__233000049_SHARP___1 any) any { var G__233000052__2_ any; var root_386 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var root_392 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = p1__233000049_SHARP___1; var arg_396 any = A_arbace_j2g_edge_A_const_85; if linked_393 == nil { arg_389 = ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { arg_389 = linked_393.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) }; var arg_390 any = A_arbace_j2g_edge_A_const_60; var arg_391 any = A_arbace_j2g_edge_A_const_63.GetRawRoot__O(); if linked_387 == nil { G__233000052__2_ = ifn_388.Invoke_O_O_O__O(arg_389, arg_390, arg_391) } else { G__233000052__2_ = linked_387.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_386, arg_389, arg_390, arg_391) }; if lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_edge_A_const_60.Invoke_O__O(p1__233000049_SHARP___1), nil) {
																var root_397 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = G__233000052__2_; var arg_401 any = A_arbace_j2g_edge_A_const_60; if linked_398 == nil { return ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { return linked_398.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) } } else {
//line :129:1
		return G__233000052__2_ } }


func A_arbace_j2g_edge_info_data_fn__233000055_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_A) Invoke_O_O__O(self, ms__1 any) any {
	var root_406 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; var fnbody__477 any = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New(); var tmp1 *jrt.Class; var fncls__476 *jrt.Class = A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class; if fncls__476 == nil { var fncls__476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class = fncls__476d; tmp1 = fncls__476d } else { tmp1 = fncls__476 }; arg_409 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__477, tmp1, nil); var arg_410 any = ms__1; if linked_407 == nil { return ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { return linked_407.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) } }
//line :133:1
func A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_New() *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Ctor() {}
//line :133:1
func (t *A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A) Invoke_O_O__O(self, m__1 any) any { var a__2 any; var tmp1 any; var root_411 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_413 lang.IFn; if
													linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = m__1; var arg_415 any = A_arbace_j2g_edge_A_const_87; if linked_412 == nil { tmp1 = ifn_413.Invoke_O_O__O(arg_414, arg_415) } else { tmp1 = linked_412.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_411, arg_414, arg_415) }; if jrt.J2g_Truth(tmp1) { var root_416 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_j2g_edge_ann_data_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var root_420 any = A_arbace_j2g_edge_A_const_88.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_force_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__1); if linked_421 == nil { arg_419 = ifn_422.Invoke_O__O(arg_423) } else { arg_419 = linked_421.(*aot_arbace_core.A_arbace_core_force_A).Invoke_O_O__O(root_420, arg_423) }; if linked_417 == nil { a__2 = ifn_418.Invoke_O__O(arg_419) } else { a__2 = linked_417.(*A_arbace_j2g_edge_ann_data_A).Invoke_O_O__O(root_416, arg_419) } } else { a__2 = nil }; var pa__3 any; var tmp2 any; var root_424 any = /*line :133:1*/A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_426 lang.IFn; if

	linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = m__1; var arg_428 any = A_arbace_j2g_edge_A_const_89; if linked_425 == nil { tmp2 = ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { tmp2 = linked_425.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_424, arg_427, arg_428) }; if jrt.J2g_Truth(tmp2) {
		var root_429 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any; var root_434 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = A_arbace_j2g_edge_A_const_65.GetRawRoot__O(); var arg_438 any = A_arbace_j2g_edge_A_const_88.GetRawRoot__O(); if linked_435 == nil { arg_432 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { arg_432 = linked_435.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }; var arg_433 any = A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__1); if linked_430 == nil { pa__3 = ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { pa__3 = linked_430.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) } } else {
//line :135:1
			pa__3 = nil }; var G__233000057__4_ any = /*line :133:1*/lang.IFn_Cast(A_arbace_j2g_edge_A_const_82.GetRawRoot__O()).Invoke_O_O_O_O__O(m__1, A_arbace_j2g_edge_A_const_85, A_arbace_j2g_edge_A_const_87, A_arbace_j2g_edge_A_const_89); var G__233000057__5_ any; var tmp3 any; var root_446 any = A_arbace_j2g_edge_A_const_90.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_448 lang.IFn; if




	linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = A_arbace_j2g_edge_A_const_91.Invoke_O__O(m__1); if linked_447 == nil { tmp3 = ifn_448.Invoke_O__O(arg_449) } else { tmp3 = linked_447.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_446, arg_449) }; if /*line :137:1*/ jrt.J2g_Truth(tmp3) {
		var root_450 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = G__233000057__4_; var arg_454 any = A_arbace_j2g_edge_A_const_91; if linked_451 == nil { G__233000057__5_ = ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { G__233000057__5_ = linked_451.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) } } else {
//line :137:1
			G__233000057__5_ = G__233000057__4_ }; var G__233000057__6_ any; var tmp4 any; var root_455 any = /*line :133:1*/A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_457 lang.IFn; if





	linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = a__2; if linked_456 == nil { tmp4 = ifn_457.Invoke_O__O(arg_458) } else { tmp4 = linked_456.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_455, arg_458) }; if /*line :137:1*/ jrt.J2g_Truth(tmp4) {

		var root_459 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = G__233000057__5_; var arg_463 any = A_arbace_j2g_edge_A_const_87; var arg_464 any = a__2; if linked_460 == nil { G__233000057__6_ = ifn_461.Invoke_O_O_O__O(arg_462, arg_463, arg_464) } else { G__233000057__6_ = linked_460.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_459, arg_462, arg_463, arg_464) } } else {
//line :137:1
			G__233000057__6_ = G__233000057__5_ }; var tmp5 any; var root_465 any = A_arbace_j2g_edge_A_const_93.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_467 lang.IFn; if


	linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var arg_469 any = pa__3; if linked_466 == nil { tmp5 = ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { tmp5 = linked_466.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) }; if /*line :137:1*/ jrt.J2g_Truth(tmp5) {


		var root_470 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = G__233000057__6_; var arg_474 any = A_arbace_j2g_edge_A_const_89; var arg_475 any = pa__3; if linked_471 == nil { return ifn_472.Invoke_O_O_O__O(arg_473, arg_474, arg_475) } else { return linked_471.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_470, arg_473, arg_474, arg_475) } } else {
//line :137:1
			return G__233000057__6_ } }





func A_arbace_j2g_edge_class_entry_text_A_New() *A_arbace_j2g_edge_class_entry_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Ctor() {}
//line :143:1
func (t *A_arbace_j2g_edge_class_entry_text_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any { var info__3 any = A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1); var rest_text__4 any; var root_480 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_482 lang.IFn; if

	linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any; var root_484 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = facets__1; var arg_488 any = A_arbace_j2g_edge_A_const_94; if linked_485 == nil { arg_483 = ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { arg_483 = linked_485.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) }; if linked_481 == nil { rest_text__4 = ifn_482.Invoke_O__O(arg_483) } else { rest_text__4 = linked_481.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_480, arg_483) }; var tmp1 /*line :146:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp2 any; var root_489 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = n__0; if linked_490 == nil { tmp2 = ifn_491.Invoke_O__O(arg_492) } else { tmp2 = linked_490.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_489, arg_492) }; var tmp3 any = tmp2; var tmp4 any; if
	jrt.J2g_Truth(info__3) {
		var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11, nil, Lit_11); var tmp6 any; var root_493 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_495 lang.IFn
		if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = Lit_12; var arg_497 any; var iter__1927001039__auto____13 any; var fnbody__633 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New(); var tmp7 *jrt.Class; var fncls__632 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class
		if fncls__632 == nil { var fncls__632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class = fncls__632d; tmp7 = fncls__632d } else { tmp7 = fncls__632 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__633, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp9 any; var root_634 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any; var root_639 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_643 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_640 == nil { arg_637 = ifn_641.Invoke_O_O__O(arg_642, arg_643) } else { arg_637 = linked_640.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_639, arg_642, arg_643) }; var arg_638 any = info__3; if linked_635 == nil { tmp9 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp9 = linked_635.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; arg_497 = tmp8.Invoke_O__O(tmp9)
//line :149:1
		if linked_494 == nil { tmp6 = ifn_495.Invoke_O_O__O(arg_496, arg_497) } else { tmp6 = linked_494.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_493, arg_496, arg_497) }
//line :148:1
		var tmp10 any = tmp6; var tmp11 *jrt.String; var more__13 any; var root_644 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_646 lang.IFn







		if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = facets__1; var arg_648 any = A_arbace_j2g_edge_A_const_94; if linked_645 == nil { more__13 = ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { more__13 = linked_645.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) }
		var tmp12 any; var root_649 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = more__13; if linked_650 == nil { tmp12 = ifn_651.Invoke_O__O(arg_652) } else { tmp12 = linked_650.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_649, arg_652) }; if jrt.J2g_Truth(tmp12) { var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp14 any; var root_653 any = A_arbace_j2g_edge_A_const_95.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = rest_text__4; var arg_657 any = A_arbace_j2g_edge_A_const_96; var arg_658 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(rest_text__4)))).Ref(); if linked_654 == nil { tmp14 = ifn_655.Invoke_O_O_O__O(arg_656, arg_657, arg_658) } else { tmp14 = linked_654.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_653, arg_656, arg_657, arg_658) }; tmp11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)) } else { tmp11 = nil }
//line :148:1
		tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp11.Ref(), nil)).Ref() } else {
//line :147:1
			tmp4 = rest_text__4 }; return /*line :146:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref() }



func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_New() *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Ctor() {}
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A) Invoke_O_O__O(self, s__233000062__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__631 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(self, s__233000062__1); var tmp2 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__631); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class = fncls__630d; tmp2 = fncls__630d } else { tmp2 = fncls__630 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__631, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Ctor_O_O(c__iter__233000061, c__s__233000062 any) { t.F_iter__233000061 = c__iter__233000061; t.F_s__233000062 = c__s__233000062 }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A) Invoke_O__O(self any) any { { var s__233000062__1 any; var t_ any = t.F_s__233000062; t.F_s__233000062 = nil; s__233000062__1 = t_; for { var temp__1927000414__auto____2 any; var root_498 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__233000062__1; if linked_499 == nil { temp__1927000414__auto____2 = ifn_500.Invoke_O__O(arg_501) } else { temp__1927000414__auto____2 = linked_499.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_498, arg_501) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000062__3 any = temp__1927000414__auto____2; var tmp1 any; var root_502 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = s__233000062__3; if linked_503 == nil { tmp1 = ifn_504.Invoke_O__O(arg_505) } else { tmp1 = linked_503.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_502, arg_505) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_506 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = s__233000062__3; if linked_507 == nil { c__1927001037__auto____4 = ifn_508.Invoke_O__O(arg_509) } else { c__1927001037__auto____4 = linked_507.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_506, arg_509) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000064__6 any; var root_510 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_511 == nil { b__233000064__6 = ifn_512.Invoke_O__O(arg_513) } else { b__233000064__6 = linked_511.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_510, arg_513) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__557 any = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(b__233000064__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__556 *jrt.Class = A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class; if fncls__556 == nil { var fncls__556d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__557); A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class = fncls__556d; tmp3 = fncls__556d } else { tmp3 = fncls__556 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__557, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_558 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any; var root_563 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = b__233000064__6; if linked_564 == nil { arg_561 = ifn_565.Invoke_O__O(arg_566) } else { arg_561 = linked_564.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_563, arg_566) }; var arg_562 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); var tmp5 any; var root_567 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = s__233000062__3; if linked_568 == nil { tmp5 = ifn_569.Invoke_O__O(arg_570) } else { tmp5 = linked_568.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_567, arg_570) }; arg_562 = tmp4.Invoke_O__O(tmp5); if linked_559 == nil { return ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { return linked_559.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) } } else { var root_571 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any; var root_576 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = b__233000064__6; if linked_577 == nil { arg_574 = ifn_578.Invoke_O__O(arg_579) } else { arg_574 = linked_577.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_576, arg_579) }; var arg_575 any; if linked_572 == nil { return ifn_573.Invoke_O_O__O(arg_574, arg_575) } else { return linked_572.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_571, arg_574, arg_575) } } } else { var vec__233000073__4 any; var root_580 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = s__233000062__3; if linked_581 == nil { vec__233000073__4 = ifn_582.Invoke_O__O(arg_583) } else { vec__233000073__4 = linked_581.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_580, arg_583) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000073__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000073__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_584 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any; var G__233000076__7_ any = k__5
L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__233000076__7_) >> 0 & 1 { case 0: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_86) {

	var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp7 any; var root_590 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = k__5; if linked_591 == nil { tmp7 = ifn_592.Invoke_O__O(arg_593) } else { tmp7 = linked_591.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_590, arg_593) }; var tmp8 any = tmp7; var tmp9 any; var root_594 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = Lit_19; var arg_598 any; var root_599 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_603 any = v__6; if linked_600 == nil { arg_598 = ifn_601.Invoke_O_O__O(arg_602, arg_603) } else { arg_598 = linked_600.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_599, arg_602, arg_603) }; if linked_595 == nil { tmp9 = ifn_596.Invoke_O_O__O(arg_597, arg_598) } else { tmp9 = linked_595.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_594, arg_597, arg_598) }; arg_587 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :151:1
	break L2 }; case 1: if any(G__233000076__7_) == any(A_arbace_j2g_edge_A_const_84) {

		var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp11 any; var root_604 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = k__5; if linked_605 == nil { tmp11 = ifn_606.Invoke_O__O(arg_607) } else { tmp11 = linked_605.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_604, arg_607) }; var tmp12 any = tmp11; var tmp13 any; var root_608 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = Lit_19; var arg_612 any; var root_613 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_617 any = v__6; if linked_614 == nil { arg_612 = ifn_615.Invoke_O_O__O(arg_616, arg_617) } else { arg_612 = linked_614.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_613, arg_616, arg_617) }; if linked_609 == nil { tmp13 = ifn_610.Invoke_O_O__O(arg_611, arg_612) } else { tmp13 = linked_609.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_608, arg_611, arg_612) }; arg_587 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, tmp13, nil)).Ref()
//line :151:1
		break L2 }; default:
}

	var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp15 any; var root_618 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = k__5; if linked_619 == nil { tmp15 = ifn_620.Invoke_O__O(arg_621) } else { tmp15 = linked_619.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_618, arg_621) }; var tmp16 any = tmp15; var tmp17 any; var root_622 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = v__6; if linked_623 == nil { tmp17 = ifn_624.Invoke_O__O(arg_625) } else { tmp17 = linked_623.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_622, arg_625) }; arg_587 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, tmp16, nil, tmp17)).Ref()}
//line :150:1
	var arg_588 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__233000061); var tmp19 any; var root_626 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = s__233000062__3; if linked_627 == nil { tmp19 = ifn_628.Invoke_O__O(arg_629) } else { tmp19 = linked_627.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_626, arg_629) }; arg_588 = tmp18.Invoke_O__O(tmp19); if linked_585 == nil { return ifn_586.Invoke_O_O__O(arg_587, arg_588) } else { return linked_585.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_584, arg_587, arg_588) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :150:1
func A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Ctor_O_I_O(c__b__233000064 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000064 = c__b__233000064; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A) Invoke_O__O(self any) any { { var i__233000063__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000063__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000068__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000068__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_514 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = t.F_b__233000064; var arg_518 any; var G__233000071__5_ any = k__3
L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__233000071__5_) >> 0 & 1 { case 0: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_86) {

	var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp3 any; var root_520 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = k__3; if linked_521 == nil { tmp3 = ifn_522.Invoke_O__O(arg_523) } else { tmp3 = linked_521.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_520, arg_523) }; var tmp4 any = tmp3; var tmp5 any; var root_524 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = Lit_19; var arg_528 any; var root_529 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_533 any = v__4; if linked_530 == nil { arg_528 = ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { arg_528 = linked_530.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) }; if linked_525 == nil { tmp5 = ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { tmp5 = linked_525.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) }; arg_518 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()
//line :151:1
	break L2 }; case 1: if any(G__233000071__5_) == any(A_arbace_j2g_edge_A_const_84) {

		var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp7 any; var root_534 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = k__3; if linked_535 == nil { tmp7 = ifn_536.Invoke_O__O(arg_537) } else { tmp7 = linked_535.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_534, arg_537) }; var tmp8 any = tmp7; var tmp9 any; var root_538 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = Lit_19; var arg_542 any; var root_543 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_547 any = v__4; if linked_544 == nil { arg_542 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { arg_542 = linked_544.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; if linked_539 == nil { tmp9 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { tmp9 = linked_539.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }; arg_518 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :151:1
		break L2 }; default:
}

	var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp11 any; var root_548 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = k__3; if linked_549 == nil { tmp11 = ifn_550.Invoke_O__O(arg_551) } else { tmp11 = linked_549.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_548, arg_551) }; var tmp12 any = tmp11; var tmp13 any; var root_552 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = v__4; if linked_553 == nil { tmp13 = ifn_554.Invoke_O__O(arg_555) } else { tmp13 = linked_553.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_552, arg_555) }; arg_518 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp12, nil, tmp13)).Ref()}
//line :150:1
	if linked_515 == nil { ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { linked_515.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }; i__233000063__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000063__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_j2g_edge_edge_text_A_New() *A_arbace_j2g_edge_edge_text_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Ctor() {}
//line :161:1
func (t *A_arbace_j2g_edge_edge_text_A) Invoke_O_O__O(self, p__233000080__0 any) any { var map__233000081__2 any = p__233000080__0; var map__233000081__3 any; if lang.ISeq_InstanceOf(map__233000081__2) { var tmp1 any; var root_659 any = A_arbace_j2g_edge_A_const_97.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = map__233000081__2; if linked_660 == nil { tmp1 = ifn_661.Invoke_O__O(arg_662) } else { tmp1 = linked_660.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_659, arg_662) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_663 any = A_arbace_j2g_edge_A_const_98.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = map__233000081__2; if linked_664 == nil { tmp2 = ifn_665.Invoke_O__O(arg_666) } else { tmp2 = linked_664.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_663, arg_666) }; map__233000081__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_667 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = map__233000081__2; if linked_668 == nil { tmp3 = ifn_669.Invoke_O__O(arg_670) } else { tmp3 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(tmp3) { var root_671 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = map__233000081__2; if linked_672 == nil { map__233000081__3 = ifn_673.Invoke_O__O(arg_674) } else { map__233000081__3 = linked_672.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_671, arg_674) } } else { map__233000081__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__233000081__3 = map__233000081__2 }; var edge__4 any = map__233000081__3; var classes__5 any = lang.RT_Get_O_O__O_NoInit(map__233000081__3, A_arbace_j2g_edge_A_const_99); var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,7,s92:;; j2g's edge (doc/STANDALONE-NOTES.md, S2): the classes outside the forms as j2g sees them\ns84:;; on the JVM, written by bin/j2g-edge update (bin/j2g --record-edge); do not edit.\ns12:{:classes\n {ns2:}\nns2:}\n", []*jrt.Class{jrt.String_class}); var tmp5 any; var root_675 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_677 lang.IFn; if





	linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = Lit_9; var arg_679 any; var iter__1927001039__auto____13 any; var fnbody__751 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New(); var tmp6 *jrt.Class; var fncls__750 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class; if fncls__750 == nil { var fncls__750d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class = fncls__750d; tmp6 = fncls__750d } else { tmp6 = fncls__750 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__751, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp8 any; var root_752 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); var arg_756 any = classes__5; if linked_753 == nil { tmp8 = ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { tmp8 = linked_753.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) }; arg_679 = tmp7.Invoke_O__O(tmp8); if linked_676 == nil { tmp5 = ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { tmp5 = linked_676.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) }; var tmp9 any = tmp5; var tmp10 any; var root_757 any = /*line :164:1*/A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_759 lang.IFn; if




	linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any; var iter__1927001039__auto____13_2 any; var fnbody__1032 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New(); var tmp11 *jrt.Class; var fncls__1031 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class; if fncls__1031 == nil { var fncls__1031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class = fncls__1031d; tmp11 = fncls__1031d } else { tmp11 = fncls__1031 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1032, tmp11, nil); var tmp12 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp13 any; var root_1033 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); var arg_1037 any; var root_1038 any = A_arbace_j2g_edge_A_const_82.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = edge__4; var arg_1042 any = A_arbace_j2g_edge_A_const_99; if linked_1039 == nil { arg_1037 = ifn_1040.Invoke_O_O__O(arg_1041, arg_1042) } else { arg_1037 = linked_1039.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1038, arg_1041, arg_1042) }; if linked_1034 == nil { tmp13 = ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { tmp13 = linked_1034.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) }; arg_760 = tmp12.Invoke_O__O(tmp13); if linked_758 == nil { tmp10 = ifn_759.Invoke_O__O(arg_760) } else { tmp10 = linked_758.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_757, arg_760) }; return /*line :164:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp9, nil, tmp10, nil)).Ref() }


func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_New() *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A) Invoke_O_O__O(self, s__233000084__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__749 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(self, s__233000084__1); var tmp2 *jrt.Class; var fncls__748 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class; if fncls__748 == nil { var fncls__748d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__749); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class = fncls__748d; tmp2 = fncls__748d } else { tmp2 = fncls__748 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__749, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Ctor_O_O(c__iter__233000083, c__s__233000084 any) { t.F_iter__233000083 = c__iter__233000083; t.F_s__233000084 = c__s__233000084 }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A) Invoke_O__O(self any) any { { var s__233000084__1 any; var t_ any = t.F_s__233000084; t.F_s__233000084 = nil; s__233000084__1 = t_; for { var temp__1927000414__auto____2 any; var root_680 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = s__233000084__1; if linked_681 == nil { temp__1927000414__auto____2 = ifn_682.Invoke_O__O(arg_683) } else { temp__1927000414__auto____2 = linked_681.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_680, arg_683) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000084__3 any = temp__1927000414__auto____2; var tmp1 any; var root_684 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = s__233000084__3; if linked_685 == nil { tmp1 = ifn_686.Invoke_O__O(arg_687) } else { tmp1 = linked_685.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_684, arg_687) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_688 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = s__233000084__3; if linked_689 == nil { c__1927001037__auto____4 = ifn_690.Invoke_O__O(arg_691) } else { c__1927001037__auto____4 = linked_689.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_688, arg_691) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000086__6 any; var root_692 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_693 == nil { b__233000086__6 = ifn_694.Invoke_O__O(arg_695) } else { b__233000086__6 = linked_693.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_692, arg_695) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__707 any = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(b__233000086__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__706 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class; if fncls__706 == nil { var fncls__706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__707); A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class = fncls__706d; tmp3 = fncls__706d } else { tmp3 = fncls__706 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__707, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_708 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any; var root_713 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = b__233000086__6; if linked_714 == nil { arg_711 = ifn_715.Invoke_O__O(arg_716) } else { arg_711 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_713, arg_716) }; var arg_712 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); var tmp5 any; var root_717 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = s__233000084__3; if linked_718 == nil { tmp5 = ifn_719.Invoke_O__O(arg_720) } else { tmp5 = linked_718.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_717, arg_720) }; arg_712 = tmp4.Invoke_O__O(tmp5); if linked_709 == nil { return ifn_710.Invoke_O_O__O(arg_711, arg_712) } else { return linked_709.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_708, arg_711, arg_712) } } else { var root_721 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any; var root_726 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = b__233000086__6; if linked_727 == nil { arg_724 = ifn_728.Invoke_O__O(arg_729) } else { arg_724 = linked_727.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_726, arg_729) }; var arg_725 any; if linked_722 == nil { return ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { return linked_722.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) } } } else { var vec__233000094__4 any; var root_730 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__233000084__3; if linked_731 == nil { vec__233000094__4 = ifn_732.Invoke_O__O(arg_733) } else { vec__233000094__4 = linked_731.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_730, arg_733) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000094__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000094__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_734 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var root_739 any = A_arbace_j2g_edge_A_const_100.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, A_arbace_j2g_edge_class_entry_text_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = n__5; var arg_743 any = facets__6; if linked_740 == nil { arg_737 = ifn_741.Invoke_O_O__O(arg_742, arg_743) } else { arg_737 = linked_740.(*A_arbace_j2g_edge_class_entry_text_A).Invoke_O_O_O__O(root_739, arg_742, arg_743) }; var arg_738 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__233000083); var tmp7 any; var root_744 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = s__233000084__3; if linked_745 == nil { tmp7 = ifn_746.Invoke_O__O(arg_747) } else { tmp7 = linked_745.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_744, arg_747) }; arg_738 = tmp6.Invoke_O__O(tmp7); if linked_735 == nil { return ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { return linked_735.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :167:1
func A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Ctor_O_I_O(c__b__233000086 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000086 = c__b__233000086; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :167:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A) Invoke_O__O(self any) any { { var i__233000085__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000085__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000090__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000085__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000090__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000090__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_696 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = t.F_b__233000086; var arg_700 any; var root_701 any = A_arbace_j2g_edge_A_const_100.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, A_arbace_j2g_edge_class_entry_text_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = n__3; var arg_705 any = facets__4; if linked_702 == nil { arg_700 = ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { arg_700 = linked_702.(*A_arbace_j2g_edge_class_entry_text_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) }; if linked_697 == nil { ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { linked_697.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) }; i__233000085__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000085__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A) Invoke_O_O__O(self, s__233000100__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1030 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(self, s__233000100__1); var tmp2 *jrt.Class; var fncls__1029 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class; if fncls__1029 == nil { var fncls__1029d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__1030); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class = fncls__1029d; tmp2 = fncls__1029d } else { tmp2 = fncls__1029 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1030, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Ctor_O_O(c__iter__233000099, c__s__233000100 any) { t.F_iter__233000099 = c__iter__233000099; t.F_s__233000100 = c__s__233000100 }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A) Invoke_O__O(self any) any { { var s__233000100__1 any; var t_ any = t.F_s__233000100; t.F_s__233000100 = nil; s__233000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_761 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = s__233000100__1; if linked_762 == nil { temp__1927000414__auto____2 = ifn_763.Invoke_O__O(arg_764) } else { temp__1927000414__auto____2 = linked_762.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_761, arg_764) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_765 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = s__233000100__3; if linked_766 == nil { tmp1 = ifn_767.Invoke_O__O(arg_768) } else { tmp1 = linked_766.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_765, arg_768) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_769 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = s__233000100__3; if linked_770 == nil { c__1927001037__auto____4 = ifn_771.Invoke_O__O(arg_772) } else { c__1927001037__auto____4 = linked_770.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_769, arg_772) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000102__6 any; var root_773 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_774 == nil { b__233000102__6 = ifn_775.Invoke_O__O(arg_776) } else { b__233000102__6 = linked_774.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_773, arg_776) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__888 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(b__233000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__887 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class; if fncls__887 == nil { var fncls__887d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__888); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class = fncls__887d; tmp3 = fncls__887d } else { tmp3 = fncls__887 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__888, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_889 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var root_894 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = b__233000102__6; if linked_895 == nil { arg_892 = ifn_896.Invoke_O__O(arg_897) } else { arg_892 = linked_895.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_894, arg_897) }; var arg_893 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); var tmp5 any; var root_898 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = s__233000100__3; if linked_899 == nil { tmp5 = ifn_900.Invoke_O__O(arg_901) } else { tmp5 = linked_899.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_898, arg_901) }; arg_893 = tmp4.Invoke_O__O(tmp5); if linked_890 == nil { return ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { return linked_890.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) } } else { var root_902 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any; var root_907 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = b__233000102__6; if linked_908 == nil { arg_905 = ifn_909.Invoke_O__O(arg_910) } else { arg_905 = linked_908.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_907, arg_910) }; var arg_906 any; if linked_903 == nil { return ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { return linked_903.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) } } } else { var vec__233000126__4 any; var root_911 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = s__233000100__3; if linked_912 == nil { vec__233000126__4 = ifn_913.Invoke_O__O(arg_914) } else { vec__233000126__4 = linked_912.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_911, arg_914) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000126__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000126__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_915 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_35, nil, Lit_36); var tmp7 any; var root_920 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_922 lang.IFn
														if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = k__5; if linked_921 == nil { tmp7 = ifn_922.Invoke_O__O(arg_923) } else { tmp7 = linked_921.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_920, arg_923) }; var tmp8 any = tmp7; var tmp9 any; var tmp10 any; var root_924 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_926 lang.IFn
														if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = v__6; if linked_925 == nil { tmp10 = ifn_926.Invoke_O__O(arg_927) } else { tmp10 = linked_925.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_924, arg_927) }; if jrt.J2g_Truth(tmp10) {
															var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_11); var tmp12 any; var root_928 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = Lit_9; var arg_932 any; var iter__1927001039__auto____15 any; var fnbody__1010 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New(); var tmp13 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class; if fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class = fncls__1009d; tmp13 = fncls__1009d } else { tmp13 = fncls__1009 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1010, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp15 any; var root_1011 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any; var root_1016 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_1020 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_1017 == nil { arg_1014 = ifn_1018.Invoke_O_O__O(arg_1019, arg_1020) } else { arg_1014 = linked_1017.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1016, arg_1019, arg_1020) }; var arg_1015 any = v__6; if linked_1012 == nil { tmp15 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { tmp15 = linked_1012.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) }; arg_932 = tmp14.Invoke_O__O(tmp15); if linked_929 == nil { tmp12 = ifn_930.Invoke_O_O__O(arg_931, arg_932) } else { tmp12 = linked_929.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_928, arg_931, arg_932) }; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } else {
																var root_1021 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = v__6; if linked_1022 == nil { tmp9 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp9 = linked_1022.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_1021, arg_1024) } }
//line :170:1
	arg_918 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp9, nil)).Ref()
//line :169:1
	var arg_919 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__233000099); var tmp17 any; var root_1025 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = s__233000100__3; if linked_1026 == nil { tmp17 = ifn_1027.Invoke_O__O(arg_1028) } else { tmp17 = linked_1026.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1025, arg_1028) }; arg_919 = tmp16.Invoke_O__O(tmp17); if linked_916 == nil { return ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { return linked_916.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_915, arg_918, arg_919) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :169:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Ctor_O_I_O(c__b__233000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000102 = c__b__233000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :169:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A) Invoke_O__O(self any) any { { var i__233000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000106__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000106__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_777 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = t.F_b__233000102; var arg_781 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_35, nil, Lit_36); var tmp3 any; var root_782 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_784 lang.IFn
																if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = k__3; if linked_783 == nil { tmp3 = ifn_784.Invoke_O__O(arg_785) } else { tmp3 = linked_783.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_782, arg_785) }; var tmp4 any = tmp3; var tmp5 any; var tmp6 any; var root_786 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_788 lang.IFn
																if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = v__4; if linked_787 == nil { tmp6 = ifn_788.Invoke_O__O(arg_789) } else { tmp6 = linked_787.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_786, arg_789) }; if jrt.J2g_Truth(tmp6) {
																	var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_11); var tmp8 any; var root_790 any = A_arbace_j2g_edge_A_const_36.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = Lit_9; var arg_794 any; var iter__1927001039__auto____13 any; var fnbody__872 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New(); var tmp9 *jrt.Class; var fncls__871 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class; if fncls__871 == nil { var fncls__871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class = fncls__871d; tmp9 = fncls__871d } else { tmp9 = fncls__871 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__872, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp11 any; var root_873 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any; var root_878 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var arg_882 any = A_arbace_j2g_edge_A_const_51.GetRawRoot__O(); if linked_879 == nil { arg_876 = ifn_880.Invoke_O_O__O(arg_881, arg_882) } else { arg_876 = linked_879.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_878, arg_881, arg_882) }; var arg_877 any = v__4; if linked_874 == nil { tmp11 = ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { tmp11 = linked_874.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) }; arg_794 = tmp10.Invoke_O__O(tmp11); if linked_791 == nil { tmp8 = ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { tmp8 = linked_791.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) }; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil)).Ref() } else {
																		var root_883 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = v__4; if linked_884 == nil { tmp5 = ifn_885.Invoke_O__O(arg_886) } else { tmp5 = linked_884.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_883, arg_886) } }
//line :170:1
	arg_781 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref()
//line :169:1
	if linked_778 == nil { ifn_779.Invoke_O_O__O(arg_780, arg_781) } else { linked_778.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_777, arg_780, arg_781) }; i__233000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A) Invoke_O_O__O(self, s__233000110__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__870 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(self, s__233000110__1); var tmp2 *jrt.Class; var fncls__869 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class; if fncls__869 == nil { var fncls__869d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__870); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class = fncls__869d; tmp2 = fncls__869d } else { tmp2 = fncls__869 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__870, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Ctor_O_O(c__iter__233000109, c__s__233000110 any) { t.F_iter__233000109 = c__iter__233000109; t.F_s__233000110 = c__s__233000110 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A) Invoke_O__O(self any) any { { var s__233000110__1 any; var t_ any = t.F_s__233000110; t.F_s__233000110 = nil; s__233000110__1 = t_; for { var temp__1927000414__auto____2 any; var root_795 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = s__233000110__1; if linked_796 == nil { temp__1927000414__auto____2 = ifn_797.Invoke_O__O(arg_798) } else { temp__1927000414__auto____2 = linked_796.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_795, arg_798) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000110__3 any = temp__1927000414__auto____2; var tmp1 any; var root_799 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = s__233000110__3; if linked_800 == nil { tmp1 = ifn_801.Invoke_O__O(arg_802) } else { tmp1 = linked_800.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_799, arg_802) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_803 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = s__233000110__3; if linked_804 == nil { c__1927001037__auto____4 = ifn_805.Invoke_O__O(arg_806) } else { c__1927001037__auto____4 = linked_804.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_803, arg_806) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000112__6 any; var root_807 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_808 == nil { b__233000112__6 = ifn_809.Invoke_O__O(arg_810) } else { b__233000112__6 = linked_808.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_807, arg_810) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__825 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(b__233000112__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__824 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class; if fncls__824 == nil { var fncls__824d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__825); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class = fncls__824d; tmp3 = fncls__824d } else { tmp3 = fncls__824 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__825, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_826 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any; var root_831 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = b__233000112__6; if linked_832 == nil { arg_829 = ifn_833.Invoke_O__O(arg_834) } else { arg_829 = linked_832.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_831, arg_834) }; var arg_830 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); var tmp5 any; var root_835 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = s__233000110__3; if linked_836 == nil { tmp5 = ifn_837.Invoke_O__O(arg_838) } else { tmp5 = linked_836.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_835, arg_838) }; arg_830 = tmp4.Invoke_O__O(tmp5); if linked_827 == nil { return ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { return linked_827.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_826, arg_829, arg_830) } } else { var root_839 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var root_844 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = b__233000112__6; if linked_845 == nil { arg_842 = ifn_846.Invoke_O__O(arg_847) } else { arg_842 = linked_845.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_844, arg_847) }; var arg_843 any; if linked_840 == nil { return ifn_841.Invoke_O_O__O(arg_842, arg_843) } else { return linked_840.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_839, arg_842, arg_843) } } } else { var vec__233000120__4 any; var root_848 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = s__233000110__3; if linked_849 == nil { vec__233000120__4 = ifn_850.Invoke_O__O(arg_851) } else { vec__233000120__4 = linked_849.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_848, arg_851) }; var kk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_852 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp7 any; var root_857 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = kk__5; if linked_858 == nil { tmp7 = ifn_859.Invoke_O__O(arg_860) } else { tmp7 = linked_858.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_857, arg_860) }; var tmp8 any = tmp7; var tmp9 any; var root_861 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = vv__6; if linked_862 == nil { tmp9 = ifn_863.Invoke_O__O(arg_864) } else { tmp9 = linked_862.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_861, arg_864) }; arg_855 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_856 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000109); var tmp11 any; var root_865 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = s__233000110__3; if linked_866 == nil { tmp11 = ifn_867.Invoke_O__O(arg_868) } else { tmp11 = linked_866.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_865, arg_868) }; arg_856 = tmp10.Invoke_O__O(tmp11); if linked_853 == nil { return ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { return linked_853.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Ctor_O_I_O(c__b__233000112 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000112 = c__b__233000112; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A) Invoke_O__O(self any) any { { var i__233000111__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000111__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000116__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000111__1)); var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000116__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000116__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_811 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = t.F_b__233000112; var arg_815 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp3 any; var root_816 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = kk__3; if linked_817 == nil { tmp3 = ifn_818.Invoke_O__O(arg_819) } else { tmp3 = linked_817.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_816, arg_819) }; var tmp4 any = tmp3; var tmp5 any; var root_820 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = vv__4; if linked_821 == nil { tmp5 = ifn_822.Invoke_O__O(arg_823) } else { tmp5 = linked_821.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_820, arg_823) }; arg_815 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_812 == nil { ifn_813.Invoke_O_O__O(arg_814, arg_815) } else { linked_812.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_811, arg_814, arg_815) }; i__233000111__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000111__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_New() *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Ctor() {}
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A) Invoke_O_O__O(self, s__233000130__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1008 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(self, s__233000130__1); var tmp2 *jrt.Class; var fncls__1007 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class; if fncls__1007 == nil { var fncls__1007d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__1008); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class = fncls__1007d; tmp2 = fncls__1007d } else { tmp2 = fncls__1007 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1008, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Ctor_O_O(c__iter__233000129, c__s__233000130 any) { t.F_iter__233000129 = c__iter__233000129; t.F_s__233000130 = c__s__233000130 }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A) Invoke_O__O(self any) any { { var s__233000130__1 any; var t_ any = t.F_s__233000130; t.F_s__233000130 = nil; s__233000130__1 = t_; for { var temp__1927000414__auto____2 any; var root_933 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = s__233000130__1; if linked_934 == nil { temp__1927000414__auto____2 = ifn_935.Invoke_O__O(arg_936) } else { temp__1927000414__auto____2 = linked_934.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_933, arg_936) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000130__3 any = temp__1927000414__auto____2; var tmp1 any; var root_937 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = s__233000130__3; if linked_938 == nil { tmp1 = ifn_939.Invoke_O__O(arg_940) } else { tmp1 = linked_938.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_937, arg_940) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_941 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = s__233000130__3; if linked_942 == nil { c__1927001037__auto____4 = ifn_943.Invoke_O__O(arg_944) } else { c__1927001037__auto____4 = linked_942.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_941, arg_944) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000132__6 any; var root_945 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_946 == nil { b__233000132__6 = ifn_947.Invoke_O__O(arg_948) } else { b__233000132__6 = linked_946.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_945, arg_948) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__963 any = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(b__233000132__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__962 *jrt.Class = A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class; if fncls__962 == nil { var fncls__962d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__963); A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class = fncls__962d; tmp3 = fncls__962d } else { tmp3 = fncls__962 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__963, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_964 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any; var root_969 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = b__233000132__6; if linked_970 == nil { arg_967 = ifn_971.Invoke_O__O(arg_972) } else { arg_967 = linked_970.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_969, arg_972) }; var arg_968 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); var tmp5 any; var root_973 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = s__233000130__3; if linked_974 == nil { tmp5 = ifn_975.Invoke_O__O(arg_976) } else { tmp5 = linked_974.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_973, arg_976) }; arg_968 = tmp4.Invoke_O__O(tmp5); if linked_965 == nil { return ifn_966.Invoke_O_O__O(arg_967, arg_968) } else { return linked_965.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_964, arg_967, arg_968) } } else { var root_977 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any; var root_982 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = b__233000132__6; if linked_983 == nil { arg_980 = ifn_984.Invoke_O__O(arg_985) } else { arg_980 = linked_983.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_982, arg_985) }; var arg_981 any; if linked_978 == nil { return ifn_979.Invoke_O_O__O(arg_980, arg_981) } else { return linked_978.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_977, arg_980, arg_981) } } } else { var vec__233000140__4 any; var root_986 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = s__233000130__3; if linked_987 == nil { vec__233000140__4 = ifn_988.Invoke_O__O(arg_989) } else { vec__233000140__4 = linked_987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_986, arg_989) }; var kk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000140__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000140__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_990 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp7 any; var root_995 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = kk__5; if linked_996 == nil { tmp7 = ifn_997.Invoke_O__O(arg_998) } else { tmp7 = linked_996.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_995, arg_998) }; var tmp8 any = tmp7; var tmp9 any; var root_999 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = vv__6; if linked_1000 == nil { tmp9 = ifn_1001.Invoke_O__O(arg_1002) } else { tmp9 = linked_1000.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_999, arg_1002) }; arg_993 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_994 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__233000129); var tmp11 any; var root_1003 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = s__233000130__3; if linked_1004 == nil { tmp11 = ifn_1005.Invoke_O__O(arg_1006) } else { tmp11 = linked_1004.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1003, arg_1006) }; arg_994 = tmp10.Invoke_O__O(tmp11); if linked_991 == nil { return ifn_992.Invoke_O_O__O(arg_993, arg_994) } else { return linked_991.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_990, arg_993, arg_994) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :172:1
func A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Ctor_O_I_O(c__b__233000132 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000132 = c__b__233000132; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A) Invoke_O__O(self any) any { { var i__233000131__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000131__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000136__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000131__1)); var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000136__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000136__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_949 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = t.F_b__233000132; var arg_953 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil); var tmp3 any; var root_954 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = kk__3; if linked_955 == nil { tmp3 = ifn_956.Invoke_O__O(arg_957) } else { tmp3 = linked_955.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_954, arg_957) }; var tmp4 any = tmp3; var tmp5 any; var root_958 any = A_arbace_j2g_edge_A_const_42.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, A_arbace_j2g_edge_pr_data_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = vv__4; if linked_959 == nil { tmp5 = ifn_960.Invoke_O__O(arg_961) } else { tmp5 = linked_959.(*A_arbace_j2g_edge_pr_data_A).Invoke_O_O__O(root_958, arg_961) }; arg_953 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_950 == nil { ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { linked_950.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) }; i__233000131__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000131__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_recorded_edge_A_New() *A_arbace_j2g_edge_recorded_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_edge_recorded_edge_A) Invoke_O_O_O__O(self, env_rec__0, j2g_rec__1_ any) any { var classes__3 any; var root_1176 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1178 lang.IFn; if



	linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_107, nil); if linked_1177 == nil { ifn_1178.Invoke_O__O(arg_1179) } else { linked_1177.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1176, arg_1179) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__1170 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(env_rec__0); var tmp2 *jrt.Class; var fncls__1169 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class; if fncls__1169 == nil { var fncls__1169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__1170); A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class = fncls__1169d; tmp2 = fncls__1169d } else { tmp2 = fncls__1169 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1170, tmp2, nil); classes__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var root_1171 any =




	A_arbace_j2g_edge_A_const_106.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_edge_A_const_99, classes__3)); var arg_1175 any = j2g_rec__1_; if linked_1172 == nil { return ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { return linked_1172.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) } }
//line :181:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_A_New_O(p0 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Ctor_O(c__env_rec any) { t.F_env_rec = c__env_rec }
//line :181:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1043 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1047 any; var iter__1927001039__auto____3 any; var fnbody__1165 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New(); var tmp2 *jrt.Class; var fncls__1164 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class; if fncls__1164 == nil { var fncls__1164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, nil); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class = fncls__1164d; tmp2 = fncls__1164d } else { tmp2 = fncls__1164 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1165, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var t_ any = t.F_env_rec; t.F_env_rec = nil; tmp4 = t_; arg_1047 = tmp3.Invoke_O__O(tmp4); if linked_1044 == nil { tmp1 = ifn_1045.Invoke_O_O__O(arg_1046, arg_1047) } else { tmp1 = linked_1044.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1043, arg_1046, arg_1047) } }
//line :181:1
	return nil }(); var root_1166 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; if linked_1167 == nil { ifn_1168.Invoke__O() } else { linked_1167.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1166) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_New() *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A) Invoke_O_O__O(self, s__233000150__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1163 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(self, s__233000150__1); var tmp2 *jrt.Class; var fncls__1162 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class; if fncls__1162 == nil { var fncls__1162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__1163); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class = fncls__1162d; tmp2 = fncls__1162d } else { tmp2 = fncls__1162 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1163, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Ctor_O_O(c__iter__233000149, c__s__233000150 any) { t.F_iter__233000149 = c__iter__233000149; t.F_s__233000150 = c__s__233000150 }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A) Invoke_O__O(self any) any { { var s__233000150__1 any; var t_ any = t.F_s__233000150; t.F_s__233000150 = nil; s__233000150__1 = t_; for { var temp__1927000414__auto____2 any; var root_1048 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = s__233000150__1; if linked_1049 == nil { temp__1927000414__auto____2 = ifn_1050.Invoke_O__O(arg_1051) } else { temp__1927000414__auto____2 = linked_1049.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1048, arg_1051) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000150__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1052 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = s__233000150__3; if linked_1053 == nil { tmp1 = ifn_1054.Invoke_O__O(arg_1055) } else { tmp1 = linked_1053.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1052, arg_1055) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1056 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = s__233000150__3; if linked_1057 == nil { c__1927001037__auto____4 = ifn_1058.Invoke_O__O(arg_1059) } else { c__1927001037__auto____4 = linked_1057.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1056, arg_1059) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000152__6 any; var root_1060 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1061 == nil { b__233000152__6 = ifn_1062.Invoke_O__O(arg_1063) } else { b__233000152__6 = linked_1061.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1060, arg_1063) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1098 any = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(b__233000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1097 *jrt.Class = A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class; if fncls__1097 == nil { var fncls__1097d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__1098); A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class = fncls__1097d; tmp3 = fncls__1097d } else { tmp3 = fncls__1097 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1098, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1099 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any; var root_1104 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = b__233000152__6; if linked_1105 == nil { arg_1102 = ifn_1106.Invoke_O__O(arg_1107) } else { arg_1102 = linked_1105.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1104, arg_1107) }; var arg_1103 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); var tmp5 any; var root_1108 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = s__233000150__3; if linked_1109 == nil { tmp5 = ifn_1110.Invoke_O__O(arg_1111) } else { tmp5 = linked_1109.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1108, arg_1111) }; arg_1103 = tmp4.Invoke_O__O(tmp5); if linked_1100 == nil { return ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { return linked_1100.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) } } else { var root_1112 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any; var root_1117 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = b__233000152__6; if linked_1118 == nil { arg_1115 = ifn_1119.Invoke_O__O(arg_1120) } else { arg_1115 = linked_1118.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1117, arg_1120) }; var arg_1116 any; if linked_1113 == nil { return ifn_1114.Invoke_O_O__O(arg_1115, arg_1116) } else { return linked_1113.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1112, arg_1115, arg_1116) } } } else { var vec__233000161__4 any; var root_1121 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = s__233000150__3; if linked_1122 == nil { vec__233000161__4 = ifn_1123.Invoke_O__O(arg_1124) } else { vec__233000161__4 = linked_1122.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1121, arg_1124) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000161__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000161__4, lang.RT_IntCast_J__I_NoInit(1), nil); var c__7 any; var tmp6 any; var root_1125 any = A_arbace_j2g_edge_A_const_101.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1127 lang.IFn
																if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = n__5; var arg_1129 any = Lit_73; if linked_1126 == nil { tmp6 = ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { tmp6 = linked_1126.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) }; if jrt.J2g_Truth(tmp6) { c__7 = nil } else { var root_1130 any = A_arbace_j2g_edge_A_const_102.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_classes_env.A_arbace_classes_env_load_class_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = n__5; if linked_1131 == nil { c__7 = ifn_1132.Invoke_O__O(arg_1133) } else { c__7 = linked_1131.(*aot_arbace_classes_env.A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_1130, arg_1133) } }
//line :182:1
	var root_1134 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any; var tmp7 any; var root_1139 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1141 lang.IFn

	if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = n__5; var arg_1143 any; var G__233000164__8_ any = facets__6; if jrt.J2g_Truth(c__7) {
		var root_1144 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = G__233000164__8_; var arg_1148 any = A_arbace_j2g_edge_A_const_94; var arg_1149 any; var root_1150 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, A_arbace_j2g_edge_info_data_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any; var root_1154 any = A_arbace_j2g_edge_A_const_105.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = c__7; if linked_1155 == nil { arg_1153 = ifn_1156.Invoke_O__O(arg_1157) } else { arg_1153 = linked_1155.(*aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_1154, arg_1157) }; if linked_1151 == nil { arg_1149 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1149 = linked_1151.(*A_arbace_j2g_edge_info_data_A).Invoke_O_O__O(root_1150, arg_1153) }; if linked_1145 == nil { arg_1143 = ifn_1146.Invoke_O_O_O__O(arg_1147, arg_1148, arg_1149) } else { arg_1143 = linked_1145.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1144, arg_1147, arg_1148, arg_1149) } } else {
//line :184:1
			arg_1143 = G__233000164__8_ }; if linked_1140 == nil { tmp7 = ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { tmp7 = linked_1140.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) }
//line :182:1
	arg_1137 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp7); var arg_1138 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__233000149); var tmp9 any; var root_1158 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = s__233000150__3; if linked_1159 == nil { tmp9 = ifn_1160.Invoke_O__O(arg_1161) } else { tmp9 = linked_1159.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1158, arg_1161) }; arg_1138 = tmp8.Invoke_O__O(tmp9); if linked_1135 == nil { return ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { return linked_1135.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :182:1
func A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Ctor_O_I_O(c__b__233000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000152 = c__b__233000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A) Invoke_O__O(self any) any { { var i__233000151__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000156__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000156__2, lang.RT_IntCast_J__I_NoInit(1), nil); var c__5 any; var tmp2 any; var root_1064 any = A_arbace_j2g_edge_A_const_101.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1066 lang.IFn
																		if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = n__3; var arg_1068 any = Lit_73; if linked_1065 == nil { tmp2 = ifn_1066.Invoke_O_O__O(arg_1067, arg_1068) } else { tmp2 = linked_1065.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1064, arg_1067, arg_1068) }; if jrt.J2g_Truth(tmp2) { c__5 = nil } else { var root_1069 any = A_arbace_j2g_edge_A_const_102.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_classes_env.A_arbace_classes_env_load_class_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = n__3; if linked_1070 == nil { c__5 = ifn_1071.Invoke_O__O(arg_1072) } else { c__5 = linked_1070.(*aot_arbace_classes_env.A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_1069, arg_1072) } }
//line :182:1
	var root_1073 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = t.F_b__233000152; var arg_1077 any; var tmp3 any; var root_1078 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1080 lang.IFn

	if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = n__3; var arg_1082 any; var G__233000159__6_ any = facets__4; if jrt.J2g_Truth(c__5) {
		var root_1083 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = G__233000159__6_; var arg_1087 any = A_arbace_j2g_edge_A_const_94; var arg_1088 any; var root_1089 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, A_arbace_j2g_edge_info_data_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any; var root_1093 any = A_arbace_j2g_edge_A_const_105.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = c__5; if linked_1094 == nil { arg_1092 = ifn_1095.Invoke_O__O(arg_1096) } else { arg_1092 = linked_1094.(*aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_1093, arg_1096) }; if linked_1090 == nil { arg_1088 = ifn_1091.Invoke_O__O(arg_1092) } else { arg_1088 = linked_1090.(*A_arbace_j2g_edge_info_data_A).Invoke_O_O__O(root_1089, arg_1092) }; if linked_1084 == nil { arg_1082 = ifn_1085.Invoke_O_O_O__O(arg_1086, arg_1087, arg_1088) } else { arg_1082 = linked_1084.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1083, arg_1086, arg_1087, arg_1088) } } else {
//line :184:1
			arg_1082 = G__233000159__6_ }; if linked_1079 == nil { tmp3 = ifn_1080.Invoke_O_O__O(arg_1081, arg_1082) } else { tmp3 = linked_1079.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1078, arg_1081, arg_1082) }
//line :182:1
	arg_1077 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp3); if linked_1074 == nil { ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { linked_1074.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) }; i__233000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000151__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_edge_merge_edges_A_New() *A_arbace_j2g_edge_merge_edges_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Ctor() {}
//line :188:1
func (t *A_arbace_j2g_edge_merge_edges_A) Invoke_O_O__O(self, edges__0 any) any {


	var root_1185 any = A_arbace_j2g_edge_A_const_108.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = A_arbace_j2g_edge_A_const_109.GetRawRoot__O(); var arg_1189 any; var fnbody__1226 any = A_arbace_j2g_edge_merge_edges_fn__233000169_A_New(); var tmp1 *jrt.Class; var fncls__1225 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class; if fncls__1225 == nil { var fncls__1225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class = fncls__1225d; tmp1 = fncls__1225d } else { tmp1 = fncls__1225 }; arg_1189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1226, tmp1, nil); var arg_1190 any = edges__0; if linked_1186 == nil { return ifn_1187.Invoke_O_O_O__O(arg_1188, arg_1189, arg_1190) } else { return linked_1186.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1185, arg_1188, arg_1189, arg_1190) } }
//line :191:1
func A_arbace_j2g_edge_merge_edges_fn__233000169_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Ctor() {}
//line :191:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var tmp1 any; var root_1191 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = a__1; if linked_1192 == nil { tmp1 = ifn_1193.Invoke_O__O(arg_1194) } else { tmp1 = linked_1192.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1191, arg_1194) }; if jrt.J2g_Truth(tmp1) { var root_1195 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = a__1; var arg_1199 any = b__2; if linked_1196 == nil { return ifn_1197.Invoke_O_O__O(arg_1198, arg_1199) } else { return linked_1196.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1195, arg_1198, arg_1199) } } else { var tmp2 any; var root_1200 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1202 lang.IFn
													if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = a__1; if linked_1201 == nil { tmp2 = ifn_1202.Invoke_O__O(arg_1203) } else { tmp2 = linked_1201.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1200, arg_1203) }
//line :191:1
	if jrt.J2g_Truth(tmp2) {
		var root_1204 any = A_arbace_j2g_edge_A_const_109.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any; var fnbody__1224 any = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New(); var tmp3 *jrt.Class; var fncls__1223 *jrt.Class = A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class; if fncls__1223 == nil { var fncls__1223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class = fncls__1223d; tmp3 = fncls__1223d } else { tmp3 = fncls__1223 }; arg_1207 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1224, tmp3, nil); var arg_1208 any = a__1; var arg_1209 any = b__2; if linked_1205 == nil { return ifn_1206.Invoke_O_O_O__O(arg_1207, arg_1208, arg_1209) } else { return linked_1205.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1204, arg_1207, arg_1208, arg_1209) } } else {
//line :191:1
			if A_arbace_j2g_edge_A_const_27 != nil { return b__2 } else { return nil } } } }
func A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_New() *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A) Invoke_O_O_O__O(self, x__1, y__2 any) any { var tmp1 any; var and__1927000168__auto____3 any; var root_1210 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = x__1; if linked_1211 == nil { and__1927000168__auto____3 = ifn_1212.Invoke_O__O(arg_1213) } else { and__1927000168__auto____3 = linked_1211.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1210, arg_1213) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1214 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = y__2; if linked_1215 == nil { tmp1 = ifn_1216.Invoke_O__O(arg_1217) } else { tmp1 = linked_1215.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1214, arg_1217) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var root_1218 any = A_arbace_j2g_edge_A_const_106.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = x__1; var arg_1222 any = y__2; if linked_1219 == nil { return ifn_1220.Invoke_O_O__O(arg_1221, arg_1222) } else { return linked_1219.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1218, arg_1221, arg_1222) } } else { return y__2 } }






func A_arbace_j2g_edge_coerce_const_A_New() *A_arbace_j2g_edge_coerce_const_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_coerce_const_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Ctor() {}
//line :199:1
func (t *A_arbace_j2g_edge_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any {
	var tmp1 any; var root_1227 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = v__1; if linked_1228 == nil { tmp1 = ifn_1229.Invoke_O__O(arg_1230) } else { tmp1 = linked_1228.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1227, arg_1230) }; if jrt.J2g_Truth(tmp1) { var G__233000174__3_ any = desc__0
		switch lang.Util_Hash_O__I_NoInit(G__233000174__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_21) {
			return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :201:1
		case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_22) {
			return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :201:1
		case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_23) {

			return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__1)).Ref() }
//line :201:1
		case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_24) {

			return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_FloatCast_O__F_NoInit(v__1)).Ref() }
//line :201:1
		case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_25) {
			return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__1)).Ref() }
//line :201:1
		case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_26) {
			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__1)).Ref() }
//line :201:1
		case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_27) {
			return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :201:1
		case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__233000174__3_, Lit_28) {

			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(v__1)).Ref() }
//line :201:1
		default:}; return v__1 } else {
//line :200:1
			return nil
		}
}



func A_arbace_j2g_edge_ann_value_A_New() *A_arbace_j2g_edge_ann_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Ctor() {}
//line :206:1
func (t *A_arbace_j2g_edge_ann_value_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1232 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = x__0; if linked_1233 == nil { and__1927000168__auto____2 = ifn_1234.Invoke_O__O(arg_1235) } else { and__1927000168__auto____2 = linked_1233.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1232, arg_1235) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1236 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); if linked_1237 == nil { and__1927000168__auto____3 = ifn_1238.Invoke_O__O(arg_1239) } else { and__1927000168__auto____3 = linked_1237.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1236, arg_1239) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1240 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(x__0); var arg_1244 any = A_arbace_j2g_edge_A_const_110; if linked_1241 == nil { tmp1 = ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { tmp1 = linked_1241.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_111; var tmp4 *lang.Compiler_AOTFn; var fnbody__1262 any = A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(x__0); var tmp5 *jrt.Class; var fncls__1261 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class; if fncls__1261 == nil { var fncls__1261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__1262); A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class = fncls__1261d; tmp5 = fncls__1261d } else { tmp5 = fncls__1261 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1262, tmp5, nil); return tmp2.Invoke_O_O_O__O(x__0, tmp3, tmp4.Ref()) } else {
//line :207:1
			var tmp6 any; var root_1263 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1265 lang.IFn

			if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = x__0; if linked_1264 == nil { tmp6 = ifn_1265.Invoke_O__O(arg_1266) } else { tmp6 = linked_1264.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1263, arg_1266) }
//line :207:1
			if jrt.J2g_Truth(tmp6) {

				var root_1267 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1271 any; var root_1272 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any; var fnbody__1282 any = A_arbace_j2g_edge_ann_value_fn__233000180_A_New(); var tmp7 *jrt.Class; var fncls__1281 *jrt.Class = A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class; if fncls__1281 == nil { var fncls__1281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class = fncls__1281d; tmp7 = fncls__1281d } else { tmp7 = fncls__1281 }; arg_1275 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1282, tmp7, nil); var arg_1276 any = x__0; if linked_1273 == nil { arg_1271 = ifn_1274.Invoke_O_O__O(arg_1275, arg_1276) } else { arg_1271 = linked_1273.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1272, arg_1275, arg_1276) }; if linked_1268 == nil { return ifn_1269.Invoke_O_O__O(arg_1270, arg_1271) } else { return linked_1268.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1267, arg_1270, arg_1271) } } else {
//line :207:1
					var tmp8 any; var root_1283 any = A_arbace_j2g_edge_A_const_115.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1285 lang.IFn


					if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = x__0; if linked_1284 == nil { tmp8 = ifn_1285.Invoke_O__O(arg_1286) } else { tmp8 = linked_1284.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1283, arg_1286) }
//line :207:1
					if jrt.J2g_Truth(tmp8) {


						var root_1287 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var arg_1291 any = x__0; if linked_1288 == nil { return ifn_1289.Invoke_O_O__O(arg_1290, arg_1291) } else { return linked_1288.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1287, arg_1290, arg_1291) } } else {
//line :207:1
							if A_arbace_j2g_edge_A_const_27 != nil { return x__0 } else { return nil } } } } }
func A_arbace_j2g_edge_ann_value_fn__233000177_A_New_O(p0 any) *A_arbace_j2g_edge_ann_value_fn__233000177_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000177_A{}; t.Ctor_O(p0); return t }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :208:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000177_A) Invoke_O_O__O(self, p1__233000176_SHARP___1 any) any { var root_1251 any = A_arbace_j2g_edge_A_const_112.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, A_arbace_j2g_edge_coerce_const_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any; var root_1256 any = A_arbace_j2g_edge_A_const_13.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = t.F_x; var arg_1260 any = A_arbace_j2g_edge_A_const_113; if linked_1257 == nil { arg_1254 = ifn_1258.Invoke_O_O__O(arg_1259, arg_1260) } else { arg_1254 = linked_1257.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1256, arg_1259, arg_1260) }; var arg_1255 any = p1__233000176_SHARP___1; if linked_1252 == nil { return ifn_1253.Invoke_O_O__O(arg_1254, arg_1255) } else { return linked_1252.(*A_arbace_j2g_edge_coerce_const_A).Invoke_O_O_O__O(root_1251, arg_1254, arg_1255) } }
func A_arbace_j2g_edge_ann_value_fn__233000180_A_New() *A_arbace_j2g_edge_ann_value_fn__233000180_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_ann_value_fn__233000180_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_edge_ann_value_fn__233000180_A) Invoke_O_O__O(self, p__233000179__1 any) any { var vec__233000181__2 any = p__233000179__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000181__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000181__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1277 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = v__4; if linked_1278 == nil { tmp1 = ifn_1279.Invoke_O__O(arg_1280) } else { tmp1 = linked_1278.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1277, arg_1280) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }



func A_arbace_j2g_edge_info_value_A_New() *A_arbace_j2g_edge_info_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Ctor() {}
//line :213:1
func (t *A_arbace_j2g_edge_info_value_A) Invoke_O_O__O(self, info__0 any) any { var n__2 any = A_arbace_j2g_edge_A_const_80.Invoke_O__O(info__0); var root_1292 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1294 lang.IFn; if









	linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any; var root_1298 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1300 lang.IFn; if /*line :220:1*/ linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any; var root_1304 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1306 lang.IFn; if /*line :219:1*/ linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = info__0; var arg_1308 any = A_arbace_j2g_edge_A_const_116; var arg_1309 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1305 == nil { arg_1301 = ifn_1306.Invoke_O_O_O__O(arg_1307, arg_1308, arg_1309) } else { arg_1301 = linked_1305.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1304, arg_1307, arg_1308, arg_1309) }; var arg_1302 any = A_arbace_j2g_edge_A_const_84; var arg_1303 any; var fnbody__1341 any =
	A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(n__2); var tmp1 *jrt.Class; var fncls__1340 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class; if fncls__1340 == nil { var fncls__1340d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__1341); A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class = fncls__1340d; tmp1 = fncls__1340d } else { tmp1 = fncls__1340 }; arg_1303 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1341, tmp1, nil); if linked_1299 == nil { arg_1295 = ifn_1300.Invoke_O_O_O__O(arg_1301, arg_1302, arg_1303) } else { arg_1295 = linked_1299.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1298, arg_1301, arg_1302, arg_1303) }; var arg_1296 any = A_arbace_j2g_edge_A_const_86; var arg_1297 any; var fnbody__1414 any =


	A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(n__2); var tmp2 *jrt.Class; var fncls__1413 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class; if fncls__1413 == nil { var fncls__1413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__1414); A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class = fncls__1413d; tmp2 = fncls__1413d } else { tmp2 = fncls__1413 }; arg_1297 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1414, tmp2, nil); if linked_1293 == nil { return ifn_1294.Invoke_O_O_O__O(arg_1295, arg_1296, arg_1297) } else { return linked_1293.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1292, arg_1295, arg_1296, arg_1297) } }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_A) Invoke_O_O__O(self, fs__1 any) any { var root_1310 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any; var fnbody__1339 any = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(t.F_n); var tmp1 *jrt.Class; var fncls__1338 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class; if fncls__1338 == nil { var fncls__1338d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__1339); A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class = fncls__1338d; tmp1 = fncls__1338d } else { tmp1 = fncls__1338 }; arg_1313 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1339, tmp1, nil); var arg_1314 any = fs__1; if linked_1311 == nil { return ifn_1312.Invoke_O_O__O(arg_1313, arg_1314) } else { return linked_1311.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1310, arg_1313, arg_1314) } }
//line :220:1
func A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A) Invoke_O_O__O(self, p1__233000186_SHARP___1 any) any {
	var root_1315 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any; var root_1321 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1323 lang.IFn
//line :220:1
	if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any; var root_1327 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = p1__233000186_SHARP___1; var arg_1331 any = A_arbace_j2g_edge_A_const_85; var arg_1332 any = t.F_n; if linked_1328 == nil { arg_1324 = ifn_1329.Invoke_O_O_O__O(arg_1330, arg_1331, arg_1332) } else { arg_1324 = linked_1328.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1327, arg_1330, arg_1331, arg_1332) }; var arg_1325 any = A_arbace_j2g_edge_A_const_116; var arg_1326 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1322 == nil { arg_1318 = ifn_1323.Invoke_O_O_O__O(arg_1324, arg_1325, arg_1326) } else { arg_1318 = linked_1322.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1321, arg_1324, arg_1325, arg_1326) }
	var arg_1319 any = A_arbace_j2g_edge_A_const_60; var arg_1320 any; var root_1333 any = A_arbace_j2g_edge_A_const_112.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, A_arbace_j2g_edge_coerce_const_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = A_arbace_j2g_edge_A_const_81.Invoke_O__O(p1__233000186_SHARP___1); var arg_1337 any = A_arbace_j2g_edge_A_const_60.Invoke_O__O(p1__233000186_SHARP___1); if linked_1334 == nil { arg_1320 = ifn_1335.Invoke_O_O__O(arg_1336, arg_1337) } else { arg_1320 = linked_1334.(*A_arbace_j2g_edge_coerce_const_A).Invoke_O_O_O__O(root_1333, arg_1336, arg_1337) }; if linked_1316 == nil { return ifn_1317.Invoke_O_O_O__O(arg_1318, arg_1319, arg_1320) } else { return linked_1316.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1315, arg_1318, arg_1319, arg_1320)
	} }
func A_arbace_j2g_edge_info_value_fn__233000192_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :223:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_A) Invoke_O_O__O(self, ms__1 any) any {
	var root_1342 any = A_arbace_j2g_edge_A_const_66.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any; var fnbody__1412 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(t.F_n); var tmp1 *jrt.Class; var fncls__1411 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class; if fncls__1411 == nil { var fncls__1411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__1412); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class = fncls__1411d; tmp1 = fncls__1411d } else { tmp1 = fncls__1411 }; arg_1345 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1412, tmp1, nil); var arg_1346 any = ms__1; if linked_1343 == nil { return ifn_1344.Invoke_O_O__O(arg_1345, arg_1346) } else { return linked_1343.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1342, arg_1345, arg_1346) } }
//line :224:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :224:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A) Invoke_O_O__O(self, m__1 any) any { var m__2 any; var root_1347 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1349 lang.IFn; if
													linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any; var root_1353 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var root_1359 any = A_arbace_j2g_edge_A_const_92.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = m__1; var arg_1363 any = A_arbace_j2g_edge_A_const_85; var arg_1364 any = t.F_n; if linked_1360 == nil { arg_1356 = ifn_1361.Invoke_O_O_O__O(arg_1362, arg_1363, arg_1364) } else { arg_1356 = linked_1360.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1359, arg_1362, arg_1363, arg_1364) }; var arg_1357 any = A_arbace_j2g_edge_A_const_116; var arg_1358 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1354 == nil { arg_1350 = ifn_1355.Invoke_O_O_O__O(arg_1356, arg_1357, arg_1358) } else { arg_1350 = linked_1354.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1353, arg_1356, arg_1357, arg_1358) }; var arg_1351 any = A_arbace_j2g_edge_A_const_91; var arg_1352 any; var fnbody__1366 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New(); var tmp1 *jrt.Class; var fncls__1365 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class; if fncls__1365 == nil { var fncls__1365d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class = fncls__1365d; tmp1 = fncls__1365d } else { tmp1 = fncls__1365 }; arg_1352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1366, tmp1, nil); if linked_1348 == nil { m__2 = ifn_1349.Invoke_O_O_O__O(arg_1350, arg_1351, arg_1352) } else { m__2 = linked_1348.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1347, arg_1350, arg_1351, arg_1352) }; if
													lang.Util_Equiv_O_O__Z_NoInit(Lit_64, A_arbace_j2g_edge_A_const_80.Invoke_O__O(m__2)) { return m__2 } else { var a__3 any; var root_1367 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1369 lang.IFn

		if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any; var or__1927000174__auto____3 any = A_arbace_j2g_edge_A_const_87.Invoke_O__O(m__2); if jrt.J2g_Truth(or__1927000174__auto____3) { arg_1370 = or__1927000174__auto____3 } else { arg_1370 = lang.PersistentVector_EMPTY.Ref() }; if linked_1368 == nil { a__3 = ifn_1369.Invoke_O__O(arg_1370) } else { a__3 = linked_1368.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1367, arg_1370) }
//line :226:1
		var pa__4 any; var or__1927000174__auto____4 any; var G__233000196__4_ any = A_arbace_j2g_edge_A_const_89.Invoke_O__O(m__2)


		if lang.Util_Identical_O_O__Z_NoInit(G__233000196__4_, nil) { or__1927000174__auto____4 = nil } else { var root_1371 any = A_arbace_j2g_edge_A_const_114.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, A_arbace_j2g_edge_ann_value_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = G__233000196__4_; if linked_1372 == nil { or__1927000174__auto____4 = ifn_1373.Invoke_O__O(arg_1374) } else { or__1927000174__auto____4 = linked_1372.(*A_arbace_j2g_edge_ann_value_A).Invoke_O_O__O(root_1371, arg_1374) } }; if jrt.J2g_Truth(or__1927000174__auto____4) { pa__4 = or__1927000174__auto____4 } else {
			var root_1375 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any; var root_1379 any = A_arbace_j2g_edge_A_const_119.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any; var tmp2 any; var root_1384 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any; var root_1388 any = A_arbace_j2g_edge_A_const_120.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = A_arbace_j2g_edge_A_const_81.Invoke_O__O(m__2); if linked_1389 == nil { arg_1387 = ifn_1390.Invoke_O__O(arg_1391) } else { arg_1387 = linked_1389.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1388, arg_1391) }; if linked_1385 == nil { tmp2 = ifn_1386.Invoke_O__O(arg_1387) } else { tmp2 = linked_1385.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1384, arg_1387) }; arg_1382 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp2)).Ref(); var arg_1383 any = lang.PersistentVector_EMPTY.Ref(); if linked_1380 == nil { arg_1378 = ifn_1381.Invoke_O_O__O(arg_1382, arg_1383) } else { arg_1378 = linked_1380.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_1379, arg_1382, arg_1383) }; if linked_1376 == nil { pa__4 = ifn_1377.Invoke_O__O(arg_1378) } else { pa__4 = linked_1376.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1375, arg_1378) } }
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_92.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_edge_A_const_87; var tmp5 *lang.Compiler_AOTFn; var fnbody__1401 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(a__3); var tmp6 *jrt.Class; var fncls__1400 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class
		if fncls__1400 == nil { var fncls__1400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__1401); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class = fncls__1400d; tmp6 = fncls__1400d } else { tmp6 = fncls__1400 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1401, tmp6, nil)
//line :231:1
		var tmp7 any = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp5)); var tmp8 any = A_arbace_j2g_edge_A_const_89; var tmp9 any; var root_1402 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1404 lang.IFn

		if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any; var fnbody__1410 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New(); var tmp10 *jrt.Class; var fncls__1409 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class; if fncls__1409 == nil { var fncls__1409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class = fncls__1409d; tmp10 = fncls__1409d } else { tmp10 = fncls__1409 }; arg_1405 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1410, tmp10, nil); var arg_1406 any = pa__4; if linked_1403 == nil { tmp9 = ifn_1404.Invoke_O_O__O(arg_1405, arg_1406) } else { tmp9 = linked_1403.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1402, arg_1405, arg_1406) }
//line :231:1
		return tmp3.Invoke_O_O_O_O_O__O(m__2, tmp4, tmp7, tmp8, tmp9) } }
//line :225:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Ctor() {}
//line :225:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A) Invoke_O_O__O(self, p1__233000187_SHARP___1 any) any { var or__1927000174__auto____2 any = p1__233000187_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.PersistentVector_EMPTY.Ref() } }






func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :232:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A) Invoke_O__O(self any) any { var t_ any = t.F_a; t.F_a = nil; return t_ }
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_New() *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Ctor() {}
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1408 any = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(x__1); var tmp2 *jrt.Class; var fncls__1407 *jrt.Class = A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class; if fncls__1407 == nil { var fncls__1407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__1408); A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class = fncls__1407d; tmp2 = fncls__1407d } else { tmp2 = fncls__1407 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1408, tmp2, nil); return lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :233:1
func A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_New_O(p0 any) *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :233:1
func (t *A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A) Invoke_O__O(self any) any { var t_ any = t.F_x; t.F_x = nil; return t_ }


func A_arbace_j2g_edge_generics_value_A_New() *A_arbace_j2g_edge_generics_value_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Ctor() {}
//line :236:1
func (t *A_arbace_j2g_edge_generics_value_A) Invoke_O_O__O(self, g__0 any) any {
	if jrt.J2g_Truth(g__0) {
		var root_1415 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = g__0; var arg_1419 any = A_arbace_j2g_edge_A_const_86; var arg_1420 any; var fnbody__1435 any = A_arbace_j2g_edge_generics_value_fn__233000207_A_New(); var tmp1 *jrt.Class; var fncls__1434 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class; if fncls__1434 == nil { var fncls__1434d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class = fncls__1434d; tmp1 = fncls__1434d } else { tmp1 = fncls__1434 }; arg_1420 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1435, tmp1, nil); if linked_1416 == nil { return ifn_1417.Invoke_O_O_O__O(arg_1418, arg_1419, arg_1420) } else { return linked_1416.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1415, arg_1418, arg_1419, arg_1420) } } else {
//line :237:1
			return nil } }
func A_arbace_j2g_edge_generics_value_fn__233000207_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_A) Invoke_O_O__O(self, ms__1 any) any { var root_1421 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any; var fnbody__1433 any = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New(); var tmp1 *jrt.Class; var fncls__1432 *jrt.Class = A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class; if fncls__1432 == nil { var fncls__1432d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class = fncls__1432d; tmp1 = fncls__1432d } else { tmp1 = fncls__1432 }; arg_1424 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1433, tmp1, nil); var arg_1425 any = ms__1; if linked_1422 == nil { return ifn_1423.Invoke_O_O__O(arg_1424, arg_1425) } else { return linked_1422.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1421, arg_1424, arg_1425) } }
//line :238:1
func A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_New() *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Ctor() {}
//line :238:1
func (t *A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A) Invoke_O_O__O(self, p1__233000206_SHARP___1 any) any { var root_1426 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = p1__233000206_SHARP___1; var arg_1430 any = A_arbace_j2g_edge_A_const_116; var arg_1431 any = A_arbace_j2g_edge_A_const_117.GetRawRoot__O(); if linked_1427 == nil { return ifn_1428.Invoke_O_O_O__O(arg_1429, arg_1430, arg_1431) } else { return linked_1427.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1426, arg_1429, arg_1430, arg_1431) } }

func A_arbace_j2g_edge_canonical_A_New() *A_arbace_j2g_edge_canonical_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_edge_canonical_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any {



	var tmp1 any; var root_1436 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any; var root_1441 any = A_arbace_j2g_edge_A_const_8.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = A_arbace_j2g_edge_A_const_121.GetRawRoot__O(); if linked_1442 == nil { arg_1439 = ifn_1443.Invoke_O__O(arg_1444) } else { arg_1439 = linked_1442.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1441, arg_1444) }; var arg_1440 any = n__0; if linked_1437 == nil { tmp1 = ifn_1438.Invoke_O_O__O(arg_1439, arg_1440) } else { tmp1 = linked_1437.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1436, arg_1439, arg_1440) }; if jrt.J2g_Truth(tmp1) { return facets__1 } else { var G__233000214__3_ any = facets__1; var G__233000214__4_ any

		if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__1)) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_edge_A_const_122; var tmp4 *lang.Compiler_AOTFn; var fnbody__1461 any = A_arbace_j2g_edge_canonical_fn__233000215_A_New(); var tmp5 *jrt.Class; var fncls__1460 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class; if fncls__1460 == nil { var fncls__1460d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class = fncls__1460d; tmp5 = fncls__1460d } else { tmp5 = fncls__1460 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1461, tmp5, nil); G__233000214__4_ = tmp2.Invoke_O_O_O__O(G__233000214__3_, tmp3, tmp4.Ref()) } else {
//line :246:1
				G__233000214__4_ = G__233000214__3_ }; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_124.Invoke_O__O(facets__1)) {

					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_61.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_edge_A_const_125; var tmp8 *lang.Compiler_AOTFn; var fnbody__1478 any = A_arbace_j2g_edge_canonical_fn__233000217_A_New(); var tmp9 *jrt.Class; var fncls__1477 *jrt.Class = A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class; if fncls__1477 == nil { var fncls__1477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class = fncls__1477d; tmp9 = fncls__1477d } else { tmp9 = fncls__1477 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1478, tmp9, nil); return tmp6.Invoke_O_O_O__O(G__233000214__4_, tmp7, tmp8.Ref()) } else {
//line :246:1
						return G__233000214__4_ } } }
func A_arbace_j2g_edge_canonical_fn__233000215_A_New() *A_arbace_j2g_edge_canonical_fn__233000215_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000215_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Ctor() {}
//line :247:1
func (t *A_arbace_j2g_edge_canonical_fn__233000215_A) Invoke_O_O__O(self, p1__233000212_SHARP___1 any) any { var root_1451 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any; var root_1455 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = A_arbace_j2g_edge_A_const_123.GetRawRoot__O(); var arg_1459 any = p1__233000212_SHARP___1; if linked_1456 == nil { arg_1454 = ifn_1457.Invoke_O_O__O(arg_1458, arg_1459) } else { arg_1454 = linked_1456.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1455, arg_1458, arg_1459) }; if linked_1452 == nil { return ifn_1453.Invoke_O__O(arg_1454) } else { return linked_1452.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1451, arg_1454) } }
func A_arbace_j2g_edge_canonical_fn__233000217_A_New() *A_arbace_j2g_edge_canonical_fn__233000217_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_canonical_fn__233000217_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Ctor() {}
//line :248:1
func (t *A_arbace_j2g_edge_canonical_fn__233000217_A) Invoke_O_O__O(self, p1__233000213_SHARP___1 any) any { var root_1468 any = A_arbace_j2g_edge_A_const_118.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any; var root_1472 any = A_arbace_j2g_edge_A_const_49.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = A_arbace_j2g_edge_A_const_123.GetRawRoot__O(); var arg_1476 any = p1__233000213_SHARP___1; if linked_1473 == nil { arg_1471 = ifn_1474.Invoke_O_O__O(arg_1475, arg_1476) } else { arg_1471 = linked_1473.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1472, arg_1475, arg_1476) }; if linked_1469 == nil { return ifn_1470.Invoke_O__O(arg_1471) } else { return linked_1469.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1468, arg_1471) } }

func A_arbace_j2g_edge_read_edge_A_New() *A_arbace_j2g_edge_read_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_edge_read_edge_A) DoInvoke_O_O_O__O(self, f__0, more__1 any) any { var rd__3 any; var fnbody__1500 any = A_arbace_j2g_edge_read_edge_rd__233000220_A_New(); var tmp1 *jrt.Class; var fncls__1499 *jrt.Class = A_arbace_j2g_edge_read_edge_rd__233000220_A_fn_class; if




	fncls__1499 == nil { var fncls__1499d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_j2g_edge_read_edge_rd__233000220_A_fn_class = fncls__1499d; tmp1 = fncls__1499d } else { tmp1 = fncls__1499 }; rd__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1500, tmp1, nil); var e__4 any; var tmp2 any; var root_1501 any = /*line :250:1*/A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1503 lang.IFn; if





	linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = more__1; if linked_1502 == nil { tmp2 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp2 = linked_1502.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1501, arg_1504) }; if jrt.J2g_Truth(tmp2) { var root_1505 any = A_arbace_j2g_edge_A_const_128.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, A_arbace_j2g_edge_merge_edges_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any; var root_1509 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = rd__3; var arg_1513 any; var root_1514 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = f__0; var arg_1518 any = more__1; if linked_1515 == nil { arg_1513 = ifn_1516.Invoke_O_O__O(arg_1517, arg_1518) } else { arg_1513 = linked_1515.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1514, arg_1517, arg_1518) }; if linked_1510 == nil { arg_1508 = ifn_1511.Invoke_O_O__O(arg_1512, arg_1513) } else { arg_1508 = linked_1510.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1509, arg_1512, arg_1513) }; if linked_1506 == nil { e__4 = ifn_1507.Invoke_O__O(arg_1508) } else { e__4 = linked_1506.(*A_arbace_j2g_edge_merge_edges_A).Invoke_O_O__O(root_1505, arg_1508) } } else { e__4 = lang.IFn_Cast(rd__3).Invoke_O__O(f__0) }; var root_1519 any =
	A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any = e__4; var arg_1523 any = A_arbace_j2g_edge_A_const_99; var arg_1524 any; var fnbody__1627 any = A_arbace_j2g_edge_read_edge_fn__233000222_A_New(); var tmp3 *jrt.Class; var fncls__1626 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class; if
	fncls__1626 == nil { var fncls__1626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class = fncls__1626d; tmp3 = fncls__1626d } else { tmp3 = fncls__1626 }; arg_1524 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1627, tmp3, nil); if /*line :257:1*/ linked_1520 == nil { return ifn_1521.Invoke_O_O_O__O(arg_1522, arg_1523, arg_1524) } else { return linked_1520.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1519, arg_1522, arg_1523, arg_1524) } }
//line :255:1
func A_arbace_j2g_edge_read_edge_rd__233000220_A_New() *A_arbace_j2g_edge_read_edge_rd__233000220_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_rd__233000220_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_rd__233000220_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_edge_read_edge_rd__233000220_A) Invoke_O_O__O(self, f__1 any) any { var root_1490 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_127, jrt.Boolean_FALSE.Ref()); if linked_1491 == nil { ifn_1492.Invoke_O__O(arg_1493) } else { linked_1491.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1490, arg_1493) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1479 any = A_arbace_j2g_edge_A_const_126.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()).Invoke_O__O(f__1); if linked_1480 == nil { tmp1 = ifn_1481.Invoke_O__O(arg_1482) } else { tmp1 = linked_1480.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1479, arg_1482) } }; return nil }(); var root_1487 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; if linked_1488 == nil { ifn_1489.Invoke__O() } else { linked_1488.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1487) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }


func A_arbace_j2g_edge_read_edge_fn__233000222_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Ctor() {}
//line :258:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_A) Invoke_O_O__O(self, cs__1 any) any {
	var root_1525 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1529 any; var iter__1927001039__auto____2 any; var fnbody__1625 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New(); var tmp1 *jrt.Class; var fncls__1624 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class; if fncls__1624 == nil { var fncls__1624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, nil); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class = fncls__1624d; tmp1 = fncls__1624d } else { tmp1 = fncls__1624 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1625, tmp1, nil); arg_1529 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); if linked_1526 == nil { return ifn_1527.Invoke_O_O__O(arg_1528, arg_1529) } else { return linked_1526.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1525, arg_1528, arg_1529) } }
//line :259:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_New() *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Ctor() {}
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A) Invoke_O_O__O(self, s__233000224__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1623 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(s__233000224__1, self); var tmp2 *jrt.Class; var fncls__1622 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class; if fncls__1622 == nil { var fncls__1622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__1623); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class = fncls__1622d; tmp2 = fncls__1622d } else { tmp2 = fncls__1622 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1623, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :259:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Ctor_O_O(c__s__233000224, c__iter__233000223 any) { t.F_s__233000224 = c__s__233000224; t.F_iter__233000223 = c__iter__233000223 }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A) Invoke_O__O(self any) any { { var s__233000224__1 any; var t_ any = t.F_s__233000224; t.F_s__233000224 = nil; s__233000224__1 = t_; for { var temp__1927000414__auto____2 any; var root_1530 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = s__233000224__1; if linked_1531 == nil { temp__1927000414__auto____2 = ifn_1532.Invoke_O__O(arg_1533) } else { temp__1927000414__auto____2 = linked_1531.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1530, arg_1533) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000224__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1534 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = s__233000224__3; if linked_1535 == nil { tmp1 = ifn_1536.Invoke_O__O(arg_1537) } else { tmp1 = linked_1535.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1534, arg_1537) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1538 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = s__233000224__3; if linked_1539 == nil { c__1927001037__auto____4 = ifn_1540.Invoke_O__O(arg_1541) } else { c__1927001037__auto____4 = linked_1539.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1538, arg_1541) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000226__6 any; var root_1542 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1543 == nil { b__233000226__6 = ifn_1544.Invoke_O__O(arg_1545) } else { b__233000226__6 = linked_1543.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1542, arg_1545) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1569 any = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(b__233000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1568 *jrt.Class = A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class; if fncls__1568 == nil { var fncls__1568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__1569); A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class = fncls__1568d; tmp3 = fncls__1568d } else { tmp3 = fncls__1568 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1569, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1570 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any; var root_1575 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = b__233000226__6; if linked_1576 == nil { arg_1573 = ifn_1577.Invoke_O__O(arg_1578) } else { arg_1573 = linked_1576.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1575, arg_1578) }; var arg_1574 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); var tmp5 any; var root_1579 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = s__233000224__3; if linked_1580 == nil { tmp5 = ifn_1581.Invoke_O__O(arg_1582) } else { tmp5 = linked_1580.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1579, arg_1582) }; arg_1574 = tmp4.Invoke_O__O(tmp5); if linked_1571 == nil { return ifn_1572.Invoke_O_O__O(arg_1573, arg_1574) } else { return linked_1571.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1570, arg_1573, arg_1574) } } else { var root_1583 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any; var root_1588 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = b__233000226__6; if linked_1589 == nil { arg_1586 = ifn_1590.Invoke_O__O(arg_1591) } else { arg_1586 = linked_1589.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1588, arg_1591) }; var arg_1587 any; if linked_1584 == nil { return ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { return linked_1584.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) } } } else { var vec__233000235__4 any; var root_1592 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = s__233000224__3; if linked_1593 == nil { vec__233000235__4 = ifn_1594.Invoke_O__O(arg_1595) } else { vec__233000235__4 = linked_1593.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1592, arg_1595) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000235__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000235__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1596 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any; var tmp6 any; var G__233000238__7_ any = facets__6; var G__233000238__8_ any
																if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var root_1601 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = G__233000238__7_; var arg_1605 any = A_arbace_j2g_edge_A_const_94; var arg_1606 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1602 == nil { G__233000238__8_ = ifn_1603.Invoke_O_O_O__O(arg_1604, arg_1605, arg_1606) } else { G__233000238__8_ = linked_1602.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1601, arg_1604, arg_1605, arg_1606) } } else {
//line :260:1
			G__233000238__8_ = G__233000238__7_ }; var tmp7 any; var root_1607 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1609 lang.IFn

	if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = facets__6; var arg_1611 any = A_arbace_j2g_edge_A_const_124; if linked_1608 == nil { tmp7 = ifn_1609.Invoke_O_O__O(arg_1610, arg_1611) } else { tmp7 = linked_1608.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1607, arg_1610, arg_1611) }
//line :260:1
	if jrt.J2g_Truth(tmp7) {

		var root_1612 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = G__233000238__8_; var arg_1616 any = A_arbace_j2g_edge_A_const_124; var arg_1617 any = A_arbace_j2g_edge_A_const_130.GetRawRoot__O(); if linked_1613 == nil { tmp6 = ifn_1614.Invoke_O_O_O__O(arg_1615, arg_1616, arg_1617) } else { tmp6 = linked_1613.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1612, arg_1615, arg_1616, arg_1617) } } else {
//line :260:1
			tmp6 = G__233000238__8_ }
//line :259:1
	arg_1599 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_1600 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__233000223); var tmp9 any; var root_1618 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = s__233000224__3; if linked_1619 == nil { tmp9 = ifn_1620.Invoke_O__O(arg_1621) } else { tmp9 = linked_1619.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1618, arg_1621) }; arg_1600 = tmp8.Invoke_O__O(tmp9); if linked_1597 == nil { return ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { return linked_1597.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :259:1
func A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Ctor_O_I_O(c__b__233000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000226 = c__b__233000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :259:1
func (t *A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A) Invoke_O__O(self any) any { { var i__233000225__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000230__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000225__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000230__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000230__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1546 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = t.F_b__233000226; var arg_1550 any; var tmp2 any; var G__233000233__5_ any = facets__4; var G__233000233__6_ any
																	if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																		var root_1551 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = G__233000233__5_; var arg_1555 any = A_arbace_j2g_edge_A_const_94; var arg_1556 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1552 == nil { G__233000233__6_ = ifn_1553.Invoke_O_O_O__O(arg_1554, arg_1555, arg_1556) } else { G__233000233__6_ = linked_1552.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1551, arg_1554, arg_1555, arg_1556) } } else {
//line :260:1
			G__233000233__6_ = G__233000233__5_ }; var tmp3 any; var root_1557 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1559 lang.IFn

	if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = facets__4; var arg_1561 any = A_arbace_j2g_edge_A_const_124; if linked_1558 == nil { tmp3 = ifn_1559.Invoke_O_O__O(arg_1560, arg_1561) } else { tmp3 = linked_1558.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1557, arg_1560, arg_1561) }
//line :260:1
	if jrt.J2g_Truth(tmp3) {

		var root_1562 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = G__233000233__6_; var arg_1566 any = A_arbace_j2g_edge_A_const_124; var arg_1567 any = A_arbace_j2g_edge_A_const_130.GetRawRoot__O(); if linked_1563 == nil { tmp2 = ifn_1564.Invoke_O_O_O__O(arg_1565, arg_1566, arg_1567) } else { tmp2 = linked_1563.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1562, arg_1565, arg_1566, arg_1567) } } else {
//line :260:1
			tmp2 = G__233000233__6_ }
//line :259:1
	arg_1550 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_1547 == nil { ifn_1548.Invoke_O_O__O(arg_1549, arg_1550) } else { linked_1547.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1546, arg_1549, arg_1550) }; i__233000225__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000225__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_edge_read_edge_data_A_New() *A_arbace_j2g_edge_read_edge_data_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Ctor() {}
//line :264:1
func (t *A_arbace_j2g_edge_read_edge_data_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var root_1748 any = A_arbace_j2g_edge_A_const_76.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1750 lang.IFn; if


	linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = lang.IFn_Cast(A_arbace_j2g_edge_A_const_77.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_edge_A_const_127, jrt.Boolean_FALSE.Ref()); if linked_1749 == nil { ifn_1750.Invoke_O__O(arg_1751) } else { linked_1749.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1748, arg_1751) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__1640 any = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(f__0); var tmp2 *jrt.Class; var fncls__1639 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class; if fncls__1639 == nil { var fncls__1639d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__1640); A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class = fncls__1639d; tmp2 = fncls__1639d } else { tmp2 = fncls__1639 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1640, tmp2, nil); e__2 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var root_1641 any =
	A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = e__2; var arg_1645 any = A_arbace_j2g_edge_A_const_99; var arg_1646 any; var fnbody__1747 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New(); var tmp3 *jrt.Class; var fncls__1746 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class; if
	fncls__1746 == nil { var fncls__1746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class = fncls__1746d; tmp3 = fncls__1746d } else { tmp3 = fncls__1746 }; arg_1646 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1747, tmp3, nil); if /*line :268:1*/ linked_1642 == nil { return ifn_1643.Invoke_O_O_O__O(arg_1644, arg_1645, arg_1646) } else { return linked_1642.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1641, arg_1644, arg_1645, arg_1646) } }
//line :267:1
func A_arbace_j2g_edge_read_edge_data_fn__233000243_A_New_O(p0 any) *A_arbace_j2g_edge_read_edge_data_fn__233000243_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000243_A{}; t.Ctor_O(p0); return t }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :267:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000243_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1628 any = A_arbace_j2g_edge_A_const_126.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_73.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; arg_1631 = tmp2.Invoke_O__O(tmp3); if linked_1629 == nil { tmp1 = ifn_1630.Invoke_O__O(arg_1631) } else { tmp1 = linked_1629.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1628, arg_1631) } }; return nil }(); var root_1636 any = A_arbace_j2g_edge_A_const_75.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; if linked_1637 == nil { ifn_1638.Invoke__O() } else { linked_1637.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1636) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_j2g_edge_read_edge_data_fn__233000245_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_A) Invoke_O_O__O(self, cs__1 any) any {
	var root_1647 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1651 any; var iter__1927001039__auto____2 any; var fnbody__1745 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New(); var tmp1 *jrt.Class; var fncls__1744 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class; if fncls__1744 == nil { var fncls__1744d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class = fncls__1744d; tmp1 = fncls__1744d } else { tmp1 = fncls__1744 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1745, tmp1, nil); arg_1651 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); if linked_1648 == nil { return ifn_1649.Invoke_O_O__O(arg_1650, arg_1651) } else { return linked_1648.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1647, arg_1650, arg_1651) } }
//line :270:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_New() *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Ctor() {}
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A) Invoke_O_O__O(self, s__233000247__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1743 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(s__233000247__1, self); var tmp2 *jrt.Class; var fncls__1742 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class; if fncls__1742 == nil { var fncls__1742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__1743); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class = fncls__1742d; tmp2 = fncls__1742d } else { tmp2 = fncls__1742 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1743, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :270:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_New_O_O(p0, p1 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Ctor_O_O(c__s__233000247, c__iter__233000246 any) { t.F_s__233000247 = c__s__233000247; t.F_iter__233000246 = c__iter__233000246 }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A) Invoke_O__O(self any) any { { var s__233000247__1 any; var t_ any = t.F_s__233000247; t.F_s__233000247 = nil; s__233000247__1 = t_; for { var temp__1927000414__auto____2 any; var root_1652 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = s__233000247__1; if linked_1653 == nil { temp__1927000414__auto____2 = ifn_1654.Invoke_O__O(arg_1655) } else { temp__1927000414__auto____2 = linked_1653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1652, arg_1655) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000247__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1656 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = s__233000247__3; if linked_1657 == nil { tmp1 = ifn_1658.Invoke_O__O(arg_1659) } else { tmp1 = linked_1657.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1656, arg_1659) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1660 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = s__233000247__3; if linked_1661 == nil { c__1927001037__auto____4 = ifn_1662.Invoke_O__O(arg_1663) } else { c__1927001037__auto____4 = linked_1661.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1660, arg_1663) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000249__6 any; var root_1664 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1665 == nil { b__233000249__6 = ifn_1666.Invoke_O__O(arg_1667) } else { b__233000249__6 = linked_1665.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1664, arg_1667) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1690 any = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(b__233000249__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1689 *jrt.Class = A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class; if fncls__1689 == nil { var fncls__1689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__1690); A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class = fncls__1689d; tmp3 = fncls__1689d } else { tmp3 = fncls__1689 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1690, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1691 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any; var root_1696 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = b__233000249__6; if linked_1697 == nil { arg_1694 = ifn_1698.Invoke_O__O(arg_1699) } else { arg_1694 = linked_1697.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1696, arg_1699) }; var arg_1695 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); var tmp5 any; var root_1700 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = s__233000247__3; if linked_1701 == nil { tmp5 = ifn_1702.Invoke_O__O(arg_1703) } else { tmp5 = linked_1701.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1700, arg_1703) }; arg_1695 = tmp4.Invoke_O__O(tmp5); if linked_1692 == nil { return ifn_1693.Invoke_O_O__O(arg_1694, arg_1695) } else { return linked_1692.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1691, arg_1694, arg_1695) } } else { var root_1704 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any; var root_1709 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = b__233000249__6; if linked_1710 == nil { arg_1707 = ifn_1711.Invoke_O__O(arg_1712) } else { arg_1707 = linked_1710.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1709, arg_1712) }; var arg_1708 any; if linked_1705 == nil { return ifn_1706.Invoke_O_O__O(arg_1707, arg_1708) } else { return linked_1705.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1704, arg_1707, arg_1708) } } } else { var vec__233000258__4 any; var root_1713 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = s__233000247__3; if linked_1714 == nil { vec__233000258__4 = ifn_1715.Invoke_O__O(arg_1716) } else { vec__233000258__4 = linked_1714.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1713, arg_1716) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000258__4, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000258__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1717 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any; var tmp6 any; var root_1722 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1724 lang.IFn
																if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = n__5; var arg_1726 any; var G__233000261__7_ any = facets__6; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__6)) {
																	var root_1727 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = G__233000261__7_; var arg_1731 any = A_arbace_j2g_edge_A_const_94; var arg_1732 any; var root_1733 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var arg_1737 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1734 == nil { arg_1732 = ifn_1735.Invoke_O_O__O(arg_1736, arg_1737) } else { arg_1732 = linked_1734.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1733, arg_1736, arg_1737) }; if linked_1728 == nil { arg_1726 = ifn_1729.Invoke_O_O_O__O(arg_1730, arg_1731, arg_1732) } else { arg_1726 = linked_1728.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1727, arg_1730, arg_1731, arg_1732) } } else {
//line :271:1
			arg_1726 = G__233000261__7_ }; if linked_1723 == nil { tmp6 = ifn_1724.Invoke_O_O__O(arg_1725, arg_1726) } else { tmp6 = linked_1723.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1722, arg_1725, arg_1726) }
//line :270:1
	arg_1720 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_1721 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__233000246); var tmp8 any; var root_1738 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = s__233000247__3; if linked_1739 == nil { tmp8 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp8 = linked_1739.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1738, arg_1741) }; arg_1721 = tmp7.Invoke_O__O(tmp8); if linked_1718 == nil { return ifn_1719.Invoke_O_O__O(arg_1720, arg_1721) } else { return linked_1718.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1717, arg_1720, arg_1721) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :270:1
func A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Ctor_O_I_O(c__b__233000249 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000249 = c__b__233000249; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :270:1
func (t *A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A) Invoke_O__O(self any) any { { var i__233000248__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000248__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000253__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000248__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000253__2, lang.RT_IntCast_J__I_NoInit(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000253__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1668 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = t.F_b__233000249; var arg_1672 any; var tmp2 any; var root_1673 any = A_arbace_j2g_edge_A_const_103.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, A_arbace_j2g_edge_canonical_A_fn_class); var ifn_1675 lang.IFn
																		if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = n__3; var arg_1677 any; var G__233000256__5_ any = facets__4; if jrt.J2g_Truth(A_arbace_j2g_edge_A_const_94.Invoke_O__O(facets__4)) {
																			var root_1678 any = A_arbace_j2g_edge_A_const_19.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = G__233000256__5_; var arg_1682 any = A_arbace_j2g_edge_A_const_94; var arg_1683 any; var root_1684 any = A_arbace_j2g_edge_A_const_50.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = A_arbace_j2g_edge_A_const_104.GetRawRoot__O(); var arg_1688 any = A_arbace_j2g_edge_A_const_129.GetRawRoot__O(); if linked_1685 == nil { arg_1683 = ifn_1686.Invoke_O_O__O(arg_1687, arg_1688) } else { arg_1683 = linked_1685.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1684, arg_1687, arg_1688) }; if linked_1679 == nil { arg_1677 = ifn_1680.Invoke_O_O_O__O(arg_1681, arg_1682, arg_1683) } else { arg_1677 = linked_1679.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1678, arg_1681, arg_1682, arg_1683) } } else {
//line :271:1
			arg_1677 = G__233000256__5_ }; if linked_1674 == nil { tmp2 = ifn_1675.Invoke_O_O__O(arg_1676, arg_1677) } else { tmp2 = linked_1674.(*A_arbace_j2g_edge_canonical_A).Invoke_O_O_O__O(root_1673, arg_1676, arg_1677) }
//line :270:1
	arg_1672 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_1669 == nil { ifn_1670.Invoke_O_O__O(arg_1671, arg_1672) } else { linked_1669.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1668, arg_1671, arg_1672) }; i__233000248__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000248__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_edge_write_edge_BANG__A_New() *A_arbace_j2g_edge_write_edge_BANG__A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_write_edge_BANG__A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Ctor() {}
//line :274:1
func (t *A_arbace_j2g_edge_write_edge_BANG__A) Invoke_O_O_O__O(self, f__0, edge__1 any) any {
	lang.IFn_Cast(A_arbace_j2g_edge_A_const_133.GetRawRoot__O()).Invoke_O__O(f__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_edge_A_const_131.GetRawRoot__O()); var tmp2 any; var root_1762 any = A_arbace_j2g_edge_A_const_132.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, A_arbace_j2g_edge_edge_text_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = edge__1; if linked_1763 == nil { tmp2 = ifn_1764.Invoke_O__O(arg_1765) } else { tmp2 = linked_1763.(*A_arbace_j2g_edge_edge_text_A).Invoke_O_O__O(root_1762, arg_1765) }; return tmp1.Invoke_O_O__O(f__0, tmp2)
}
func A_arbace_j2g_edge_subtract_edge_A_New() *A_arbace_j2g_edge_subtract_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_j2g_edge_subtract_edge_A) Ctor() {}
//line :278:1
func (t *A_arbace_j2g_edge_subtract_edge_A) Invoke_O_O_O__O(self, e__0, base__1 any) any {




	var root_1770 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1774 any; var iter__1927001039__auto____3 any; var fnbody__1946 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_New_O(base__1); var tmp1 *jrt.Class; var fncls__1945 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_fn_class; if fncls__1945 == nil { var fncls__1945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__1946); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_fn_class = fncls__1945d; tmp1 = fncls__1945d } else { tmp1 = fncls__1945 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1946, tmp1, nil); arg_1774 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(e__0); if linked_1771 == nil { return ifn_1772.Invoke_O_O__O(arg_1773, arg_1774) } else { return linked_1771.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1770, arg_1773, arg_1774) } }
//line :283:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A{}; t.Ctor_O(p0); return t }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A) Invoke_O_O__O(self, s__233000269__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1944 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_New_O_O_O(s__233000269__1, t.F_base, self); var tmp2 *jrt.Class; var fncls__1943 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_fn_class; if fncls__1943 == nil { var fncls__1943d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, fnbody__1944); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_fn_class = fncls__1943d; tmp2 = fncls__1943d } else { tmp2 = fncls__1943 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1944, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :283:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A) Ctor_O_O_O(c__s__233000269, c__base, c__iter__233000268 any) { t.F_s__233000269 = c__s__233000269; t.F_base = c__base; t.F_iter__233000268 = c__iter__233000268 }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A) Invoke_O__O(self any) any { { var s__233000269__1 any; var t_ any = t.F_s__233000269; t.F_s__233000269 = nil; s__233000269__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1775 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = s__233000269__1; if linked_1776 == nil { temp__1927000414__auto____2 = ifn_1777.Invoke_O__O(arg_1778) } else { temp__1927000414__auto____2 = linked_1776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1775, arg_1778) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__233000269__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1779 any = A_arbace_j2g_edge_A_const_38.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = s__233000269__3; if linked_1780 == nil { tmp1 = ifn_1781.Invoke_O__O(arg_1782) } else { tmp1 = linked_1780.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1779, arg_1782) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1783 any = A_arbace_j2g_edge_A_const_39.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = s__233000269__3; if linked_1784 == nil { c__1927001037__auto____4 = ifn_1785.Invoke_O__O(arg_1786) } else { c__1927001037__auto____4 = linked_1784.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1783, arg_1786) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__233000271__6 any; var root_1787 any = A_arbace_j2g_edge_A_const_40.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1788 == nil { b__233000271__6 = ifn_1789.Invoke_O__O(arg_1790) } else { b__233000271__6 = linked_1788.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1787, arg_1790) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1850 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_New_O_O_I_O(b__233000271__6, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1849 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_fn_class; if fncls__1849 == nil { var fncls__1849d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__1850); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_fn_class = fncls__1849d; tmp3 = fncls__1849d } else { tmp3 = fncls__1849 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1850, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1851 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any; var root_1856 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = b__233000271__6; if linked_1857 == nil { arg_1854 = ifn_1858.Invoke_O__O(arg_1859) } else { arg_1854 = linked_1857.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1856, arg_1859) }; var arg_1855 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__233000268); var tmp5 any; var root_1860 any = A_arbace_j2g_edge_A_const_45.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = s__233000269__3; if linked_1861 == nil { tmp5 = ifn_1862.Invoke_O__O(arg_1863) } else { tmp5 = linked_1861.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1860, arg_1863) }; arg_1855 = tmp4.Invoke_O__O(tmp5); if linked_1852 == nil { return ifn_1853.Invoke_O_O__O(arg_1854, arg_1855) } else { return linked_1852.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1851, arg_1854, arg_1855) } } else { var root_1864 any = A_arbace_j2g_edge_A_const_43.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any; var root_1869 any = A_arbace_j2g_edge_A_const_44.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = b__233000271__6; if linked_1870 == nil { arg_1867 = ifn_1871.Invoke_O__O(arg_1872) } else { arg_1867 = linked_1870.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1869, arg_1872) }; var arg_1868 any; if linked_1865 == nil { return ifn_1866.Invoke_O_O__O(arg_1867, arg_1868) } else { return linked_1865.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1864, arg_1867, arg_1868) } } } else { var vec__233000287__4 any; var root_1873 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = s__233000269__3; if linked_1874 == nil { vec__233000287__4 = ifn_1875.Invoke_O__O(arg_1876) } else { vec__233000287__4 = linked_1874.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1873, arg_1876) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000287__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000287__4, lang.RT_IntCast_J__I_NoInit(1), nil); var b__7 any = lang.RT_Get_O_O__O_NoInit(t.F_base, k__5); var d__8 any; var tmp6 any; var root_1877 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1879 lang.IFn

	if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = v__6; if linked_1878 == nil { tmp6 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp6 = linked_1878.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1877, arg_1880) }; if jrt.J2g_Truth(tmp6) { var root_1881 any = A_arbace_j2g_edge_A_const_134.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any; var root_1885 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any; var fnbody__1896 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_New_O(b__7); var tmp7 *jrt.Class; var fncls__1895 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_fn_class; if fncls__1895 == nil { var fncls__1895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__1896); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_fn_class = fncls__1895d; tmp7 = fncls__1895d } else { tmp7 = fncls__1895 }; arg_1888 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1896, tmp7, nil); var arg_1889 any = v__6; if linked_1886 == nil { arg_1884 = ifn_1887.Invoke_O_O__O(arg_1888, arg_1889) } else { arg_1884 = linked_1886.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1885, arg_1888, arg_1889) }; if linked_1882 == nil { d__8 = ifn_1883.Invoke_O__O(arg_1884) } else { d__8 = linked_1882.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1881, arg_1884) } } else { var tmp8 any; var root_1897 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1899 lang.IFn
		if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = v__6; if linked_1898 == nil { tmp8 = ifn_1899.Invoke_O__O(arg_1900) } else { tmp8 = linked_1898.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1897, arg_1900) }
//line :285:1
		if jrt.J2g_Truth(tmp8) {
			var root_1901 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1905 any; var root_1906 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any; var fnbody__1912 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_New_O(b__7); var tmp9 *jrt.Class; var fncls__1911 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_fn_class; if fncls__1911 == nil { var fncls__1911d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, fnbody__1912); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_fn_class = fncls__1911d; tmp9 = fncls__1911d } else { tmp9 = fncls__1911 }; arg_1909 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1912, tmp9, nil); var arg_1910 any = v__6; if linked_1907 == nil { arg_1905 = ifn_1908.Invoke_O_O__O(arg_1909, arg_1910) } else { arg_1905 = linked_1907.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1906, arg_1909, arg_1910) }; if linked_1902 == nil { d__8 = ifn_1903.Invoke_O_O__O(arg_1904, arg_1905) } else { d__8 = linked_1902.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1901, arg_1904, arg_1905) } } else {
//line :285:1
				if A_arbace_j2g_edge_A_const_27 != nil {

					var tmp10 any; var root_1913 any = A_arbace_j2g_edge_A_const_135.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = v__6; var arg_1917 any = b__7; if linked_1914 == nil { tmp10 = ifn_1915.Invoke_O_O__O(arg_1916, arg_1917) } else { tmp10 = linked_1914.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1913, arg_1916, arg_1917) }; if jrt.J2g_Truth(tmp10) { d__8 = v__6 } else { d__8 = nil } } else {
//line :285:1
						d__8 = nil } } }
//line :283:1
	var tmp11 any; var tmp12 any; var root_1918 any = A_arbace_j2g_edge_A_const_136.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, aot_arbace_core.A_arbace_core_coll_QMARK__A_fn_class); var ifn_1920 lang.IFn




	if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = d__8; if linked_1919 == nil { tmp12 = ifn_1920.Invoke_O__O(arg_1921) } else { tmp12 = linked_1919.(*aot_arbace_core.A_arbace_core_coll_QMARK__A).Invoke_O_O__O(root_1918, arg_1921) }; if jrt.J2g_Truth(tmp12) { var root_1922 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = d__8; if linked_1923 == nil { tmp11 = ifn_1924.Invoke_O__O(arg_1925) } else { tmp11 = linked_1923.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1922, arg_1925) } } else { var root_1926 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = d__8; if linked_1927 == nil { tmp11 = ifn_1928.Invoke_O__O(arg_1929) } else { tmp11 = linked_1927.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1926, arg_1929) } }
//line :283:1
	if jrt.J2g_Truth(tmp11) { var root_1930 any = A_arbace_j2g_edge_A_const_47.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, d__8); var arg_1934 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__233000268); var tmp14 any; var root_1935 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = s__233000269__3; if linked_1936 == nil { tmp14 = ifn_1937.Invoke_O__O(arg_1938) } else { tmp14 = linked_1936.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1935, arg_1938) }; arg_1934 = tmp13.Invoke_O__O(tmp14); if linked_1931 == nil { return ifn_1932.Invoke_O_O__O(arg_1933, arg_1934) } else { return linked_1931.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1930, arg_1933, arg_1934) } } else { var tmp15 any; var root_1939 any = A_arbace_j2g_edge_A_const_48.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = s__233000269__3; if linked_1940 == nil { tmp15 = ifn_1941.Invoke_O__O(arg_1942) } else { tmp15 = linked_1940.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1939, arg_1942) }; s__233000269__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :283:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A) Ctor_O_O_I_O(c__b__233000271, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__233000271 = c__b__233000271; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :283:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A) Invoke_O__O(self any) any { { var i__233000270__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__233000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__233000275__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__233000270__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000275__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000275__2, lang.RT_IntCast_J__I_NoInit(1), nil); var b__5 any = lang.RT_Get_O_O__O_NoInit(t.F_base, k__3); var d__6 any; var tmp2 any; var root_1791 any = A_arbace_j2g_edge_A_const_52.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_set_QMARK__A_fn_class); var ifn_1793 lang.IFn

	if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = v__4; if linked_1792 == nil { tmp2 = ifn_1793.Invoke_O__O(arg_1794) } else { tmp2 = linked_1792.(*aot_arbace_core.A_arbace_core_set_QMARK__A).Invoke_O_O__O(root_1791, arg_1794) }; if jrt.J2g_Truth(tmp2) { var root_1795 any = A_arbace_j2g_edge_A_const_134.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any; var root_1799 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any; var fnbody__1810 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_New_O(b__5); var tmp3 *jrt.Class; var fncls__1809 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_fn_class; if fncls__1809 == nil { var fncls__1809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, fnbody__1810); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_fn_class = fncls__1809d; tmp3 = fncls__1809d } else { tmp3 = fncls__1809 }; arg_1802 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1810, tmp3, nil); var arg_1803 any = v__4; if linked_1800 == nil { arg_1798 = ifn_1801.Invoke_O_O__O(arg_1802, arg_1803) } else { arg_1798 = linked_1800.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1799, arg_1802, arg_1803) }; if linked_1796 == nil { d__6 = ifn_1797.Invoke_O__O(arg_1798) } else { d__6 = linked_1796.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1795, arg_1798) } } else { var tmp4 any; var root_1811 any = A_arbace_j2g_edge_A_const_35.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1813 lang.IFn
		if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = v__4; if linked_1812 == nil { tmp4 = ifn_1813.Invoke_O__O(arg_1814) } else { tmp4 = linked_1812.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1811, arg_1814) }
//line :285:1
		if jrt.J2g_Truth(tmp4) {
			var root_1815 any = A_arbace_j2g_edge_A_const_64.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1819 any; var root_1820 any = A_arbace_j2g_edge_A_const_69.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any; var fnbody__1826 any = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_New_O(b__5); var tmp5 *jrt.Class; var fncls__1825 *jrt.Class = A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_fn_class; if fncls__1825 == nil { var fncls__1825d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__1826); A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_fn_class = fncls__1825d; tmp5 = fncls__1825d } else { tmp5 = fncls__1825 }; arg_1823 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1826, tmp5, nil); var arg_1824 any = v__4; if linked_1821 == nil { arg_1819 = ifn_1822.Invoke_O_O__O(arg_1823, arg_1824) } else { arg_1819 = linked_1821.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1820, arg_1823, arg_1824) }; if linked_1816 == nil { d__6 = ifn_1817.Invoke_O_O__O(arg_1818, arg_1819) } else { d__6 = linked_1816.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1815, arg_1818, arg_1819) } } else {
//line :285:1
				if A_arbace_j2g_edge_A_const_27 != nil {

					var tmp6 any; var root_1827 any = A_arbace_j2g_edge_A_const_135.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = v__4; var arg_1831 any = b__5; if linked_1828 == nil { tmp6 = ifn_1829.Invoke_O_O__O(arg_1830, arg_1831) } else { tmp6 = linked_1828.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1827, arg_1830, arg_1831) }; if jrt.J2g_Truth(tmp6) { d__6 = v__4 } else { d__6 = nil } } else {
//line :285:1
						d__6 = nil } } }
//line :283:1
	var tmp7 any; var tmp8 any; var root_1832 any = A_arbace_j2g_edge_A_const_136.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_coll_QMARK__A_fn_class); var ifn_1834 lang.IFn




	if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = d__6; if linked_1833 == nil { tmp8 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp8 = linked_1833.(*aot_arbace_core.A_arbace_core_coll_QMARK__A).Invoke_O_O__O(root_1832, arg_1835) }; if jrt.J2g_Truth(tmp8) { var root_1836 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = d__6; if linked_1837 == nil { tmp7 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp7 = linked_1837.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1836, arg_1839) } } else { var root_1840 any = A_arbace_j2g_edge_A_const_15.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = d__6; if linked_1841 == nil { tmp7 = ifn_1842.Invoke_O__O(arg_1843) } else { tmp7 = linked_1841.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1840, arg_1843) } }
//line :283:1
	if jrt.J2g_Truth(tmp7) { var root_1844 any = A_arbace_j2g_edge_A_const_41.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = t.F_b__233000271; var arg_1848 any = lang.Tuple_Create_O_O__IPersistentVector(k__3, d__6); if linked_1845 == nil { ifn_1846.Invoke_O_O__O(arg_1847, arg_1848) } else { linked_1845.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1844, arg_1847, arg_1848) }; i__233000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000270__1); continue L1 } else { i__233000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__233000270__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A) Invoke_O_O__O(self, p1__233000267_SHARP___1 any) any { var root_1804 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var or__1927000174__auto____2 any = t.F_b; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_1807 = or__1927000174__auto____2 } else { arg_1807 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_1808 any = p1__233000267_SHARP___1; if linked_1805 == nil { return ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { return linked_1805.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) } }
//line :285:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :285:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A) Invoke_O_O__O(self, p1__233000267_SHARP___1 any) any { var root_1890 any = A_arbace_j2g_edge_A_const_18.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1892 lang.IFn; if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any; var or__1927000174__auto____2 any = t.F_b; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_1893 = or__1927000174__auto____2 } else { arg_1893 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_1894 any = p1__233000267_SHARP___1; if linked_1891 == nil { return ifn_1892.Invoke_O_O__O(arg_1893, arg_1894) } else { return linked_1891.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1890, arg_1893, arg_1894) } }
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A) Invoke_O_O__O(self, p__233000280__1 any) any { var vec__233000282__2 any = p__233000280__1; var k2__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000282__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v2__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000282__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(v2__4, lang.RT_Get_O_O__O_NoInit(t.F_b, k2__3))).Ref() }
//line :286:1
func A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_New_O(p0 any) *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :286:1
func (t *A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A) Invoke_O_O__O(self, p__233000292__1 any) any { var vec__233000294__2 any = p__233000292__1; var k2__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000294__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v2__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000294__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(v2__4, lang.RT_Get_O_O__O_NoInit(t.F_b, k2__3))).Ref() }




func A_arbace_j2g_edge__main_A_New() *A_arbace_j2g_edge__main_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge__main_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_j2g_edge__main_A) Ctor() {}
//line :291:1
func (t *A_arbace_j2g_edge__main_A) DoInvoke_O_O_O__O(self, cmd__0, args__1 any) any { var G__233000301__3_ any = cmd__0; switch



	lang.Util_Hash_O__I_NoInit(G__233000301__3_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__233000301__3_, Lit_1) { var vec__233000302__4 any = args__1; var seq__233000303__5 any; var root_1948 any = A_arbace_j2g_edge_A_const_37.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1950 lang.IFn
		if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = vec__233000302__4; if linked_1949 == nil { seq__233000303__5 = ifn_1950.Invoke_O__O(arg_1951) } else { seq__233000303__5 = linked_1949.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1948, arg_1951) }
//line :295:1
		var first__233000304__6 any; var root_1952 any = A_arbace_j2g_edge_A_const_46.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1954 lang.IFn
		if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = seq__233000303__5; if linked_1953 == nil { first__233000304__6 = ifn_1954.Invoke_O__O(arg_1955) } else { first__233000304__6 = linked_1953.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1952, arg_1955) }
//line :295:1
		var seq__233000303__7 any; var root_1956 any = A_arbace_j2g_edge_A_const_97.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1958 lang.IFn
		if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = seq__233000303__5; if linked_1957 == nil { seq__233000303__7 = ifn_1958.Invoke_O__O(arg_1959) } else { seq__233000303__7 = linked_1957.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1956, arg_1959) }
//line :295:1
		var out__8 any = first__233000304__6; var ins__9 any = seq__233000303__7; var root_1960 any = A_arbace_j2g_edge_A_const_137.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, A_arbace_j2g_edge_write_edge_BANG__A_fn_class); var ifn_1962 lang.IFn

		if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = out__8; var arg_1964 any; var root_1965 any = A_arbace_j2g_edge_A_const_128.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1965, A_arbace_j2g_edge_merge_edges_A_fn_class); var ifn_1967 lang.IFn; if linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any; var root_1969 any = A_arbace_j2g_edge_A_const_54.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = A_arbace_j2g_edge_A_const_138.GetRawRoot__O(); var arg_1973 any = ins__9; if linked_1970 == nil { arg_1968 = ifn_1971.Invoke_O_O__O(arg_1972, arg_1973) } else { arg_1968 = linked_1970.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1969, arg_1972, arg_1973) }; if linked_1966 == nil { arg_1964 = ifn_1967.Invoke_O__O(arg_1968) } else { arg_1964 = linked_1966.(*A_arbace_j2g_edge_merge_edges_A).Invoke_O_O__O(root_1965, arg_1968) }; if linked_1961 == nil { return ifn_1962.Invoke_O_O__O(arg_1963, arg_1964) } else { return linked_1961.(*A_arbace_j2g_edge_write_edge_BANG__A).Invoke_O_O_O__O(root_1960, arg_1963, arg_1964) } }
//line :295:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__233000301__3_, Lit_2) { var vec__233000305__4 any = args__1; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000305__4, lang.RT_IntCast_J__I_NoInit(0), nil); var in__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000305__4, lang.RT_IntCast_J__I_NoInit(1), nil); var base__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__233000305__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_1974 any = A_arbace_j2g_edge_A_const_137.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, A_arbace_j2g_edge_write_edge_BANG__A_fn_class); var ifn_1976 lang.IFn



		if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = out__5; var arg_1978 any; var root_1979 any = A_arbace_j2g_edge_A_const_139.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, A_arbace_j2g_edge_subtract_edge_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any; var root_1984 any = A_arbace_j2g_edge_A_const_138.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, A_arbace_j2g_edge_read_edge_data_A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = in__6; if linked_1985 == nil { arg_1982 = ifn_1986.Invoke_O__O(arg_1987) } else { arg_1982 = linked_1985.(*A_arbace_j2g_edge_read_edge_data_A).Invoke_O_O__O(root_1984, arg_1987) }; var arg_1983 any; var root_1988 any = A_arbace_j2g_edge_A_const_138.GetRawRoot__O(); var linked_1989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1988, A_arbace_j2g_edge_read_edge_data_A_fn_class); var ifn_1990 lang.IFn; if linked_1989 == nil { ifn_1990 = lang.IFn_Cast(root_1988) } else { ifn_1990 = nil }; var arg_1991 any = base__7; if linked_1989 == nil { arg_1983 = ifn_1990.Invoke_O__O(arg_1991) } else { arg_1983 = linked_1989.(*A_arbace_j2g_edge_read_edge_data_A).Invoke_O_O__O(root_1988, arg_1991) }; if linked_1980 == nil { arg_1978 = ifn_1981.Invoke_O_O__O(arg_1982, arg_1983) } else { arg_1978 = linked_1980.(*A_arbace_j2g_edge_subtract_edge_A).Invoke_O_O_O__O(root_1979, arg_1982, arg_1983) }; if linked_1975 == nil { return ifn_1976.Invoke_O_O__O(arg_1977, arg_1978) } else { return linked_1975.(*A_arbace_j2g_edge_write_edge_BANG__A).Invoke_O_O_O__O(root_1974, arg_1977, arg_1978) } }
//line :295:1
	default:}; var tmp1 any; var root_1992 any = A_arbace_j2g_edge_A_const_56.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1994 lang.IFn; if




	linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, cmd__0)).Ref(); var arg_1996 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1993 == nil { tmp1 = ifn_1994.Invoke_O_O__O(arg_1995, arg_1996) } else { tmp1 = linked_1993.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1992, arg_1995, arg_1996) }; /*line :295:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }
















































































































































































































































































type A_arbace_j2g_edge_A struct{ jrt.Object }

var A_arbace_j2g_edge_A_const_pool *jrt.RefArray

var A_arbace_j2g_edge_A_const_0 *lang.Var

var A_arbace_j2g_edge_A_const_1 any

var A_arbace_j2g_edge_A_const_2 any

var A_arbace_j2g_edge_A_const_3 any

var A_arbace_j2g_edge_A_const_4 any

var A_arbace_j2g_edge_A_const_5 *lang.Var

var A_arbace_j2g_edge_A_const_6 any

var A_arbace_j2g_edge_A_const_7 *lang.Var

var A_arbace_j2g_edge_A_const_8 *lang.Var

var A_arbace_j2g_edge_A_const_9 *lang.Var

var A_arbace_j2g_edge_A_const_10 *lang.Var

var A_arbace_j2g_edge_A_const_11 any

var A_arbace_j2g_edge_A_const_12 *lang.Var

var A_arbace_j2g_edge_A_const_13 *lang.Var

var A_arbace_j2g_edge_A_const_14 *lang.Var

var A_arbace_j2g_edge_A_const_15 *lang.Var

var A_arbace_j2g_edge_A_const_16 *lang.Var

var A_arbace_j2g_edge_A_const_17 *lang.Var

var A_arbace_j2g_edge_A_const_18 *lang.Var

var A_arbace_j2g_edge_A_const_19 *lang.Var

var A_arbace_j2g_edge_A_const_20 *lang.Var

var A_arbace_j2g_edge_A_const_21 *lang.Var

var A_arbace_j2g_edge_A_const_22 any

var A_arbace_j2g_edge_A_const_23 any

var A_arbace_j2g_edge_A_const_24 *lang.Var

var A_arbace_j2g_edge_A_const_25 any

var A_arbace_j2g_edge_A_const_26 any

var A_arbace_j2g_edge_A_const_27 *lang.Keyword

var A_arbace_j2g_edge_A_const_28 *lang.Var

var A_arbace_j2g_edge_A_const_29 *lang.Var

var A_arbace_j2g_edge_A_const_30 *lang.Var

var A_arbace_j2g_edge_A_const_31 *lang.Var

var A_arbace_j2g_edge_A_const_32 *lang.Var

var A_arbace_j2g_edge_A_const_33 *lang.Var

var A_arbace_j2g_edge_A_const_34 *lang.Var

var A_arbace_j2g_edge_A_const_35 *lang.Var

var A_arbace_j2g_edge_A_const_36 *lang.Var

var A_arbace_j2g_edge_A_const_37 *lang.Var

var A_arbace_j2g_edge_A_const_38 *lang.Var

var A_arbace_j2g_edge_A_const_39 *lang.Var

var A_arbace_j2g_edge_A_const_40 *lang.Var

var A_arbace_j2g_edge_A_const_41 *lang.Var

var A_arbace_j2g_edge_A_const_42 *lang.Var

var A_arbace_j2g_edge_A_const_43 *lang.Var

var A_arbace_j2g_edge_A_const_44 *lang.Var

var A_arbace_j2g_edge_A_const_45 *lang.Var

var A_arbace_j2g_edge_A_const_46 *lang.Var

var A_arbace_j2g_edge_A_const_47 *lang.Var

var A_arbace_j2g_edge_A_const_48 *lang.Var

var A_arbace_j2g_edge_A_const_49 *lang.Var

var A_arbace_j2g_edge_A_const_50 *lang.Var

var A_arbace_j2g_edge_A_const_51 *lang.Var

var A_arbace_j2g_edge_A_const_52 *lang.Var

var A_arbace_j2g_edge_A_const_53 *lang.Var

var A_arbace_j2g_edge_A_const_54 *lang.Var

var A_arbace_j2g_edge_A_const_55 *lang.Var

var A_arbace_j2g_edge_A_const_56 *lang.Var

var A_arbace_j2g_edge_A_const_57 *lang.Var

var A_arbace_j2g_edge_A_const_58 *lang.Var

var A_arbace_j2g_edge_A_const_59 *lang.Keyword

var A_arbace_j2g_edge_A_const_60 *lang.Keyword

var A_arbace_j2g_edge_A_const_61 *lang.Var

var A_arbace_j2g_edge_A_const_62 any

var A_arbace_j2g_edge_A_const_63 *lang.Var

var A_arbace_j2g_edge_A_const_64 *lang.Var

var A_arbace_j2g_edge_A_const_65 *lang.Var

var A_arbace_j2g_edge_A_const_66 *lang.Var

var A_arbace_j2g_edge_A_const_67 *lang.Var

var A_arbace_j2g_edge_A_const_68 *lang.Var

var A_arbace_j2g_edge_A_const_69 *lang.Var

var A_arbace_j2g_edge_A_const_70 *lang.Var

var A_arbace_j2g_edge_A_const_71 any

var A_arbace_j2g_edge_A_const_72 *lang.Var

var A_arbace_j2g_edge_A_const_73 *lang.Var

var A_arbace_j2g_edge_A_const_74 *lang.Var

var A_arbace_j2g_edge_A_const_75 *lang.Var

var A_arbace_j2g_edge_A_const_76 *lang.Var

var A_arbace_j2g_edge_A_const_77 *lang.Var

var A_arbace_j2g_edge_A_const_78 *lang.Var

var A_arbace_j2g_edge_A_const_79 *lang.Var

var A_arbace_j2g_edge_A_const_80 *lang.Keyword

var A_arbace_j2g_edge_A_const_81 *lang.Keyword

var A_arbace_j2g_edge_A_const_82 *lang.Var

var A_arbace_j2g_edge_A_const_83 *lang.Keyword

var A_arbace_j2g_edge_A_const_84 *lang.Keyword

var A_arbace_j2g_edge_A_const_85 *lang.Keyword

var A_arbace_j2g_edge_A_const_86 *lang.Keyword

var A_arbace_j2g_edge_A_const_87 *lang.Keyword

var A_arbace_j2g_edge_A_const_88 *lang.Var

var A_arbace_j2g_edge_A_const_89 *lang.Keyword

var A_arbace_j2g_edge_A_const_90 *lang.Var

var A_arbace_j2g_edge_A_const_91 *lang.Keyword

var A_arbace_j2g_edge_A_const_92 *lang.Var

var A_arbace_j2g_edge_A_const_93 *lang.Var

var A_arbace_j2g_edge_A_const_94 *lang.Keyword

var A_arbace_j2g_edge_A_const_95 *lang.Var

var A_arbace_j2g_edge_A_const_96 any

var A_arbace_j2g_edge_A_const_97 *lang.Var

var A_arbace_j2g_edge_A_const_98 *lang.Var

var A_arbace_j2g_edge_A_const_99 *lang.Keyword

var A_arbace_j2g_edge_A_const_100 *lang.Var

var A_arbace_j2g_edge_A_const_101 *lang.Var

var A_arbace_j2g_edge_A_const_102 *lang.Var

var A_arbace_j2g_edge_A_const_103 *lang.Var

var A_arbace_j2g_edge_A_const_104 *lang.Var

var A_arbace_j2g_edge_A_const_105 *lang.Var

var A_arbace_j2g_edge_A_const_106 *lang.Var

var A_arbace_j2g_edge_A_const_107 *lang.Var

var A_arbace_j2g_edge_A_const_108 *lang.Var

var A_arbace_j2g_edge_A_const_109 *lang.Var

var A_arbace_j2g_edge_A_const_110 *lang.Keyword

var A_arbace_j2g_edge_A_const_111 any

var A_arbace_j2g_edge_A_const_112 *lang.Var

var A_arbace_j2g_edge_A_const_113 any

var A_arbace_j2g_edge_A_const_114 *lang.Var

var A_arbace_j2g_edge_A_const_115 *lang.Var

var A_arbace_j2g_edge_A_const_116 *lang.Keyword

var A_arbace_j2g_edge_A_const_117 *lang.Var

var A_arbace_j2g_edge_A_const_118 *lang.Var

var A_arbace_j2g_edge_A_const_119 *lang.Var

var A_arbace_j2g_edge_A_const_120 *lang.Var

var A_arbace_j2g_edge_A_const_121 *lang.Var

var A_arbace_j2g_edge_A_const_122 any

var A_arbace_j2g_edge_A_const_123 *lang.Var

var A_arbace_j2g_edge_A_const_124 *lang.Keyword

var A_arbace_j2g_edge_A_const_125 any

var A_arbace_j2g_edge_A_const_126 *lang.Var

var A_arbace_j2g_edge_A_const_127 *lang.Var

var A_arbace_j2g_edge_A_const_128 *lang.Var

var A_arbace_j2g_edge_A_const_129 *lang.Var

var A_arbace_j2g_edge_A_const_130 *lang.Var

var A_arbace_j2g_edge_A_const_131 *lang.Var

var A_arbace_j2g_edge_A_const_132 *lang.Var

var A_arbace_j2g_edge_A_const_133 *lang.Var

var A_arbace_j2g_edge_A_const_134 *lang.Var

var A_arbace_j2g_edge_A_const_135 *lang.Var

var A_arbace_j2g_edge_A_const_136 *lang.Var

var A_arbace_j2g_edge_A_const_137 *lang.Var

var A_arbace_j2g_edge_A_const_138 *lang.Var

var A_arbace_j2g_edge_A_const_139 *lang.Var

var A_arbace_j2g_edge_A_init jrt.ClassInit

func A_arbace_j2g_edge_A_Init() { if !A_arbace_j2g_edge_A_init.Done() { A_arbace_j2g_edge_A_init.Run(A_arbace_j2g_edge_A_clinit) } }

func A_arbace_j2g_edge_A_clinit() { A_arbace_j2g_edge_A_clinit_p0(); A_arbace_j2g_edge_A_clinit_p1(); A_arbace_j2g_edge_A_clinit_p2(); A_arbace_j2g_edge_A_clinit_p3(); A_arbace_j2g_edge_A_clinit_p4(); A_arbace_j2g_edge_A_clinit_p5(); A_arbace_j2g_edge_A_clinit_p6(); A_arbace_j2g_edge_A_clinit_p7(); A_arbace_j2g_edge_A_clinit_p8(); A_arbace_j2g_edge_A_clinit_p9(); A_arbace_j2g_edge_A_clinit_p10(); A_arbace_j2g_edge_A_clinit_p11() }

func A_arbace_j2g_edge_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_edge_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 169); A_arbace_j2g_edge_A_const_0 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[29]); A_arbace_j2g_edge_A_const_1 = A_arbace_j2g_edge_A_const_pool.A[30]; A_arbace_j2g_edge_A_const_2 = A_arbace_j2g_edge_A_const_pool.A[31]; A_arbace_j2g_edge_A_const_3 = A_arbace_j2g_edge_A_const_pool.A[32]; A_arbace_j2g_edge_A_const_4 = A_arbace_j2g_edge_A_const_pool.A[33]; A_arbace_j2g_edge_A_const_5 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[34]); A_arbace_j2g_edge_A_const_6 = A_arbace_j2g_edge_A_const_pool.A[35]; A_arbace_j2g_edge_A_const_7 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[36]); A_arbace_j2g_edge_A_const_8 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[37]); A_arbace_j2g_edge_A_const_9 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[38]); A_arbace_j2g_edge_A_const_10 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[39]); A_arbace_j2g_edge_A_const_11 = A_arbace_j2g_edge_A_const_pool.A[40] }

func A_arbace_j2g_edge_A_clinit_p1() { A_arbace_j2g_edge_A_const_12 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[41]); A_arbace_j2g_edge_A_const_13 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[42]); A_arbace_j2g_edge_A_const_14 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[43]); A_arbace_j2g_edge_A_const_15 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[44]); A_arbace_j2g_edge_A_const_16 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[45]); A_arbace_j2g_edge_A_const_17 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[46]); A_arbace_j2g_edge_A_const_18 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[47]); A_arbace_j2g_edge_A_const_19 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[48]); A_arbace_j2g_edge_A_const_20 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[49]); A_arbace_j2g_edge_A_const_21 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[50]); A_arbace_j2g_edge_A_const_22 = A_arbace_j2g_edge_A_const_pool.A[51]; A_arbace_j2g_edge_A_const_23 = A_arbace_j2g_edge_A_const_pool.A[52] }

func A_arbace_j2g_edge_A_clinit_p2() { A_arbace_j2g_edge_A_const_24 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[53]); A_arbace_j2g_edge_A_const_25 = A_arbace_j2g_edge_A_const_pool.A[54]; A_arbace_j2g_edge_A_const_26 = A_arbace_j2g_edge_A_const_pool.A[55]; A_arbace_j2g_edge_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[56]); A_arbace_j2g_edge_A_const_28 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[57]); A_arbace_j2g_edge_A_const_29 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[58]); A_arbace_j2g_edge_A_const_30 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[59]); A_arbace_j2g_edge_A_const_31 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[60]); A_arbace_j2g_edge_A_const_32 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[61]); A_arbace_j2g_edge_A_const_33 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[62]); A_arbace_j2g_edge_A_const_34 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[63]); A_arbace_j2g_edge_A_const_35 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[64]) }

func A_arbace_j2g_edge_A_clinit_p3() { A_arbace_j2g_edge_A_const_36 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[65]); A_arbace_j2g_edge_A_const_37 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[66]); A_arbace_j2g_edge_A_const_38 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[67]); A_arbace_j2g_edge_A_const_39 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[68]); A_arbace_j2g_edge_A_const_40 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[69]); A_arbace_j2g_edge_A_const_41 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[70]); A_arbace_j2g_edge_A_const_42 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[71]); A_arbace_j2g_edge_A_const_43 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[72]); A_arbace_j2g_edge_A_const_44 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[73]); A_arbace_j2g_edge_A_const_45 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[74]); A_arbace_j2g_edge_A_const_46 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[75]); A_arbace_j2g_edge_A_const_47 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[76]) }

func A_arbace_j2g_edge_A_clinit_p4() { A_arbace_j2g_edge_A_const_48 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[77]); A_arbace_j2g_edge_A_const_49 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[78]); A_arbace_j2g_edge_A_const_50 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[79]); A_arbace_j2g_edge_A_const_51 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[80]); A_arbace_j2g_edge_A_const_52 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[81]); A_arbace_j2g_edge_A_const_53 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[82]); A_arbace_j2g_edge_A_const_54 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[83]); A_arbace_j2g_edge_A_const_55 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[84]); A_arbace_j2g_edge_A_const_56 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[85]); A_arbace_j2g_edge_A_const_57 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[86]); A_arbace_j2g_edge_A_const_58 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[87]); A_arbace_j2g_edge_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[88]) }

func A_arbace_j2g_edge_A_clinit_p5() { A_arbace_j2g_edge_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[89]); A_arbace_j2g_edge_A_const_61 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[90]); A_arbace_j2g_edge_A_const_62 = A_arbace_j2g_edge_A_const_pool.A[91]; A_arbace_j2g_edge_A_const_63 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[92]); A_arbace_j2g_edge_A_const_64 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[93]); A_arbace_j2g_edge_A_const_65 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[94]); A_arbace_j2g_edge_A_const_66 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[95]); A_arbace_j2g_edge_A_const_67 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[96]); A_arbace_j2g_edge_A_const_68 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[97]); A_arbace_j2g_edge_A_const_69 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[98]); A_arbace_j2g_edge_A_const_70 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[99]); A_arbace_j2g_edge_A_const_71 = A_arbace_j2g_edge_A_const_pool.A[100] }

func A_arbace_j2g_edge_A_clinit_p6() { A_arbace_j2g_edge_A_const_72 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[101]); A_arbace_j2g_edge_A_const_73 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[102]); A_arbace_j2g_edge_A_const_74 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[103]); A_arbace_j2g_edge_A_const_75 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[104]); A_arbace_j2g_edge_A_const_76 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[105]); A_arbace_j2g_edge_A_const_77 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[106]); A_arbace_j2g_edge_A_const_78 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[107]); A_arbace_j2g_edge_A_const_79 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[108]); A_arbace_j2g_edge_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[109]); A_arbace_j2g_edge_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[110]); A_arbace_j2g_edge_A_const_82 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[111]); A_arbace_j2g_edge_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[112]) }

func A_arbace_j2g_edge_A_clinit_p7() { A_arbace_j2g_edge_A_const_84 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[113]); A_arbace_j2g_edge_A_const_85 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[114]); A_arbace_j2g_edge_A_const_86 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[115]); A_arbace_j2g_edge_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[116]); A_arbace_j2g_edge_A_const_88 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[117]); A_arbace_j2g_edge_A_const_89 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[118]); A_arbace_j2g_edge_A_const_90 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[119]); A_arbace_j2g_edge_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[120]); A_arbace_j2g_edge_A_const_92 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[121]); A_arbace_j2g_edge_A_const_93 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[122]); A_arbace_j2g_edge_A_const_94 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[123]); A_arbace_j2g_edge_A_const_95 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[124]) }

func A_arbace_j2g_edge_A_clinit_p8() { A_arbace_j2g_edge_A_const_96 = A_arbace_j2g_edge_A_const_pool.A[125]; A_arbace_j2g_edge_A_const_97 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[126]); A_arbace_j2g_edge_A_const_98 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[127]); A_arbace_j2g_edge_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[128]); A_arbace_j2g_edge_A_const_100 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[129]); A_arbace_j2g_edge_A_const_101 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[130]); A_arbace_j2g_edge_A_const_102 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[131]); A_arbace_j2g_edge_A_const_103 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[132]); A_arbace_j2g_edge_A_const_104 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[133]); A_arbace_j2g_edge_A_const_105 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[134]); A_arbace_j2g_edge_A_const_106 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[135]); A_arbace_j2g_edge_A_const_107 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[136]) }

func A_arbace_j2g_edge_A_clinit_p9() { A_arbace_j2g_edge_A_const_108 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[137]); A_arbace_j2g_edge_A_const_109 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[138]); A_arbace_j2g_edge_A_const_110 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[139]); A_arbace_j2g_edge_A_const_111 = A_arbace_j2g_edge_A_const_pool.A[140]; A_arbace_j2g_edge_A_const_112 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[141]); A_arbace_j2g_edge_A_const_113 = A_arbace_j2g_edge_A_const_pool.A[142]; A_arbace_j2g_edge_A_const_114 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[143]); A_arbace_j2g_edge_A_const_115 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[144]); A_arbace_j2g_edge_A_const_116 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[145]); A_arbace_j2g_edge_A_const_117 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[146]); A_arbace_j2g_edge_A_const_118 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[147]); A_arbace_j2g_edge_A_const_119 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[148]) }

func A_arbace_j2g_edge_A_clinit_p10() { A_arbace_j2g_edge_A_const_120 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[149]); A_arbace_j2g_edge_A_const_121 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[150]); A_arbace_j2g_edge_A_const_122 = A_arbace_j2g_edge_A_const_pool.A[151]; A_arbace_j2g_edge_A_const_123 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[152]); A_arbace_j2g_edge_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_edge_A_const_pool.A[153]); A_arbace_j2g_edge_A_const_125 = A_arbace_j2g_edge_A_const_pool.A[154]; A_arbace_j2g_edge_A_const_126 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[155]); A_arbace_j2g_edge_A_const_127 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[156]); A_arbace_j2g_edge_A_const_128 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[157]); A_arbace_j2g_edge_A_const_129 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[158]); A_arbace_j2g_edge_A_const_130 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[159]); A_arbace_j2g_edge_A_const_131 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[160]) }

func A_arbace_j2g_edge_A_clinit_p11() { A_arbace_j2g_edge_A_const_132 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[161]); A_arbace_j2g_edge_A_const_133 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[162]); A_arbace_j2g_edge_A_const_134 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[163]); A_arbace_j2g_edge_A_const_135 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[164]); A_arbace_j2g_edge_A_const_136 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[165]); A_arbace_j2g_edge_A_const_137 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[166]); A_arbace_j2g_edge_A_const_138 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[167]); A_arbace_j2g_edge_A_const_139 = lang.Var_Cast(A_arbace_j2g_edge_A_const_pool.A[168]) }

func A_arbace_j2g_edge_A_New() *A_arbace_j2g_edge_A { A_arbace_j2g_edge_A_Init(); t := &A_arbace_j2g_edge_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_A) Ctor() {}

func (t *A_arbace_j2g_edge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_A_class }

func (t *A_arbace_j2g_edge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_A); return ok }

func A_arbace_j2g_edge_A_Cast(x any) *A_arbace_j2g_edge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_A_class)) }; return v }



type A_arbace_j2g_edge__main_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge__main_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_data_fn__233000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_data_fn__233000035_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000177_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_ann_value_fn__233000177_A_fn_class *jrt.Class



type A_arbace_j2g_edge_ann_value_fn__233000180_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_ann_value_fn__233000180_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000215_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000215_A_fn_class *jrt.Class



type A_arbace_j2g_edge_canonical_fn__233000217_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_canonical_fn__233000217_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A struct{ j2g_header uint64; F_iter__233000061, F_s__233000062 any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_A_fn_class *jrt.Class



type A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A struct{ j2g_header uint64; F_b__233000064 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_class_entry_text_iter__233000061__233000065_fn__233000066_fn__233000067_A_fn_class *jrt.Class



type A_arbace_j2g_edge_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_coerce_const_A_fn_class *jrt.Class



type A_arbace_j2g_edge_const_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_const_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A struct{ j2g_header uint64; F_iter__233000083, F_s__233000084 any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A struct{ j2g_header uint64; F_b__233000086 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000083__233000087_fn__233000088_fn__233000089_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A struct{ j2g_header uint64; F_iter__233000099, F_s__233000100 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A struct{ j2g_header uint64; F_b__233000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A struct{ j2g_header uint64; F_iter__233000109, F_s__233000110 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A struct{ j2g_header uint64; F_b__233000112 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_fn__233000105_iter__233000109__233000113_fn__233000114_fn__233000115_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A struct{ j2g_header uint64; F_iter__233000129, F_s__233000130 any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_A_fn_class *jrt.Class



type A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A struct{ j2g_header uint64; F_b__233000132 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_edge_text_iter__233000099__233000103_fn__233000104_iter__233000129__233000133_fn__233000134_fn__233000135_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000004_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000004_A_New() *A_arbace_j2g_edge_eval233000004_A { t := &A_arbace_j2g_edge_eval233000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000004_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000004_A_class }

func (t *A_arbace_j2g_edge_eval233000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000004_A); return ok }

func A_arbace_j2g_edge_eval233000004_A_Cast(x any) *A_arbace_j2g_edge_eval233000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000004_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000004_loading__1927001464__auto____233000005_A_fn_class *jrt.Class



type A_arbace_j2g_edge_eval233000008_A struct{ jrt.Object }

func A_arbace_j2g_edge_eval233000008_A_New() *A_arbace_j2g_edge_eval233000008_A { t := &A_arbace_j2g_edge_eval233000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_edge_eval233000008_A) Ctor() {}

func (t *A_arbace_j2g_edge_eval233000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_edge_eval233000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_edge_eval233000008_A_class }

func (t *A_arbace_j2g_edge_eval233000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_edge_eval233000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_edge_eval233000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_edge_eval233000008_A); return ok }

func A_arbace_j2g_edge_eval233000008_A_Cast(x any) *A_arbace_j2g_edge_eval233000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_edge_eval233000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_edge_eval233000008_A_class)) }; return v }



type A_arbace_j2g_edge_eval233000008_fn__233000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_eval233000008_fn__233000009_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000043_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000043_A_fn_class *jrt.Class



type A_arbace_j2g_edge_fn__233000042_fn__233000045_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_fn__233000042_fn__233000045_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_A_fn_class *jrt.Class



type A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_generics_value_fn__233000207_fn__233000208_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000050_fn__233000051_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_data_fn__233000055_fn__233000056_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000188_fn__233000189_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000194_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A struct{ j2g_header uint64; F_a any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000197_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_A_fn_class *jrt.Class



type A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_edge_info_value_fn__233000192_fn__233000193_fn__233000199_fn__233000200_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_A_fn_class *jrt.Class



type A_arbace_j2g_edge_jvm_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_jvm_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_A_fn_class *jrt.Class



type A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_merge_edges_fn__233000169_fn__233000170_A_fn_class *jrt.Class



type A_arbace_j2g_edge_method_key_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_method_key_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A struct{ j2g_header uint64; F_s__233000017, F_iter__233000016 any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A struct{ j2g_header uint64; F_b__233000019 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_pr_data_iter__233000016__233000020_fn__233000021_fn__233000022_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_double_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_double_A_fn_class *jrt.Class



type A_arbace_j2g_edge_pr_string_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_pr_string_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A struct{ j2g_header uint64; F_s__233000224, F_iter__233000223 any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A struct{ j2g_header uint64; F_b__233000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_fn__233000222_iter__233000223__233000227_fn__233000228_fn__233000229_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_rd__233000220_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_rd__233000220_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000243_A struct{ j2g_header uint64; F_f any }

var A_arbace_j2g_edge_read_edge_data_fn__233000243_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A struct{ j2g_header uint64; F_s__233000247, F_iter__233000246 any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_A_fn_class *jrt.Class



type A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A struct{ j2g_header uint64; F_b__233000249 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_read_edge_data_fn__233000245_iter__233000246__233000250_fn__233000251_fn__233000252_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_A struct{ j2g_header uint64; F_env_rec any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A struct{ j2g_header uint64; F_iter__233000149, F_s__233000150 any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_A_fn_class *jrt.Class



type A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A struct{ j2g_header uint64; F_b__233000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_recorded_edge_fn__233000148_iter__233000149__233000153_fn__233000154_fn__233000155_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_subtract_edge_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A struct{ j2g_header uint64; F_base any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A struct{ j2g_header uint64; F_s__233000269, F_base, F_iter__233000268 any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A struct{ j2g_header uint64; F_b__233000271, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000278_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000274_fn__233000281_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000290_A_fn_class *jrt.Class



type A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A struct{ j2g_header uint64; F_b any }

var A_arbace_j2g_edge_subtract_edge_iter__233000268__233000272_fn__233000273_fn__233000293_A_fn_class *jrt.Class



type A_arbace_j2g_edge_write_edge_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_edge_write_edge_BANG__A_fn_class *jrt.Class
