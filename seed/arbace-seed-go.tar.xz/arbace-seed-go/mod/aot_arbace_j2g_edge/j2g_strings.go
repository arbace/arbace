//line j2g_strings.ae:1
package aot_arbace_j2g_edge

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn11,arbace.corekn3,dockn4,elsekn1,xkn5,constkn3,valkn4,namekn4,desckn5,classkn6,fieldskn5,ownerkn7,methodskn11,annotationskn17,param-annotationskn6,throwskn4,infokn7,classeskn4,typekn5,flagskn8,genericsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,v11,arbace.core5,referR9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.j2g.edgem2,R10,s918,j2g's edge (doc/STANDALONE-NOTES.md, S2): what j2g knows of the classes outside the forms\n  (the JDK's classes jrt hand-writes or the world does not hold, the cut classes, Arbace's\n  runtime classes on the JVM), as data instead of the JVM's reflection and ASM. The declaration\n  file (jdk/edge.edn, Clojure-reader data) is written by recording what one j2g run asks the\n  JVM (--record-edge: arbace.classes.env's facets, and j2g's own questions below), and read back\n  by every other run, which then loads no class and reflects on nothing (arbace.classes.env's\n  *declared*). bin/j2g-edge updates and verifies it.\n\n  The file: {:classes {internal-name {:exists true :info class-info facet value ...}}\n  :method-order {internal-name {method-name [[param binary names] ...]}} :cut {internal-name\n  {:methods :fields :ctors}} :exists #{binary-name} :member-types {internal-name\n  [internal-name]} :unexported #{package}}.v15,arbace.j2g.edge6,*edge*v11,arbace.core6,get-inv15,arbace.j2g.edge11,*recording*v11,arbace.core5,some?v11,arbace.core5,swap!v11,arbace.core8,assoc-inv11,arbace.core9,contains?v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core3,strc34,c92,v11,arbace.core2,<=l32,l126,R11,v11,arbace.core6,formatv11,arbace.core8,boolean?v11,arbace.core7,string?v15,arbace.j2g.edge9,pr-stringv11,arbace.core8,keyword?v11,arbace.core7,symbol?v15,arbace.j2g.edge9,pr-doublev11,arbace.core4,map?v13,arbace.string4,joinv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv15,arbace.j2g.edge7,pr-datav11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core7,sort-byv11,arbace.core4,compv11,arbace.core3,keyv11,arbace.core4,set?v11,arbace.core4,sortv11,arbace.core3,mapv11,arbace.core11,sequential?v11,arbace.core7,ex-infov11,arbace.core6,pr-strv11,arbace.core5,classR12,R13,v11,arbace.core9,update-inV2,R13,R14,v15,arbace.j2g.edge10,const-datav11,arbace.core4,intov15,arbace.j2g.edge8,ann-datav11,arbace.core4,mapvv14,arbace.java.io4,filev13,arbace.string9,includes?v11,arbace.core6,removev11,arbace.core7,re-findp6,[\\s@#]v13,arbace.string11,split-linesv11,arbace.core5,slurpv11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*R15,R16,v11,arbace.core6,dissocR17,R18,R19,R20,R21,v11,arbace.core5,forceR22,v11,arbace.core6,empty?R23,v11,arbace.core5,assocv11,arbace.core4,someR24,v11,arbace.core4,subsl1,v11,arbace.core4,nextv11,arbace.core8,to-arrayR25,v15,arbace.j2g.edge16,class-entry-textv13,arbace.string12,starts-with?v18,arbace.classes.env10,load-classv15,arbace.j2g.edge9,canonicalv15,arbace.j2g.edge9,info-datav18,arbace.classes.env12,reflect-infov11,arbace.core5,mergev18,arbace.classes.env10,*recorded*v11,arbace.core5,applyv11,arbace.core10,merge-withR14,V2,R13,R14,v15,arbace.j2g.edge12,coerce-constV2,R13,R26,v15,arbace.j2g.edge9,ann-valuev11,arbace.core7,vector?R27,v11,arbace.core3,intv11,arbace.core3,vecv11,arbace.core6,repeatv20,arbace.classes.types17,parse-method-descv15,arbace.j2g.edge16,archived-classesV2,R24,R20,v15,arbace.j2g.edge10,method-keyR28,V2,R28,R20,v11,arbace.core11,read-stringv11,arbace.core11,*read-eval*v15,arbace.j2g.edge11,merge-edgesv15,arbace.j2g.edge10,info-valuev15,arbace.j2g.edge14,generics-valuev11,arbace.core4,spitv15,arbace.j2g.edge9,edge-textv14,arbace.java.io12,make-parentsv11,arbace.core3,setv11,arbace.core4,not=v11,arbace.core5,coll?v15,arbace.j2g.edge11,write-edge!v15,arbace.j2g.edge14,read-edge-datav15,arbace.j2g.edge13,subtract-edge")

var Lit_1 *jrt.String = jrt.Intern("merge")

var Lit_2 *jrt.String = jrt.Intern("subtract")

var Lit_3 *jrt.String = jrt.Intern("j2g edge: unknown command ")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.edge$ann_data$fn__233000035")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.edge$ann_value$fn__233000177")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.edge$ann_value$fn__233000180")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.edge$canonical$fn__233000215")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.edge$canonical$fn__233000217")

var Lit_9 *jrt.String = jrt.Intern("\n  ")

var Lit_10 *jrt.String = jrt.Intern("{:info {")

var Lit_11 *jrt.String = jrt.Intern("}")

var Lit_12 *jrt.String = jrt.Intern("\n          ")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.edge$class_entry_text$iter__233000061__233000065")

var Lit_14 *jrt.String = jrt.Intern("\n   ")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.edge$class_entry_text$iter__233000061__233000065$fn__233000066")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.edge$class_entry_text$iter__233000061__233000065$fn__233000066$fn__233000067")

var Lit_17 *jrt.String = jrt.Intern(" [")

var Lit_18 *jrt.String = jrt.Intern("]")

var Lit_19 *jrt.String = jrt.Intern("\n            ")

var Lit_20 *jrt.String = jrt.Intern(" ")

var Lit_21 *jrt.String = jrt.Intern("B")

var Lit_22 *jrt.String = jrt.Intern("C")

var Lit_23 *jrt.String = jrt.Intern("D")

var Lit_24 *jrt.String = jrt.Intern("F")

var Lit_25 *jrt.String = jrt.Intern("I")

var Lit_26 *jrt.String = jrt.Intern("J")

var Lit_27 *jrt.String = jrt.Intern("S")

var Lit_28 *jrt.String = jrt.Intern("Z")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000083__233000087")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000083__233000087$fn__233000088")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000083__233000087$fn__233000088$fn__233000089")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104$fn__233000105")

var Lit_35 *jrt.String = jrt.Intern("\n ")

var Lit_36 *jrt.String = jrt.Intern("\n")

var Lit_37 *jrt.String = jrt.Intern("{")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104$iter__233000129__233000133")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104$fn__233000105$iter__233000109__233000113")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104$fn__233000105$iter__233000109__233000113$fn__233000114")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104$fn__233000105$iter__233000109__233000113$fn__233000114$fn__233000115")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104$iter__233000129__233000133$fn__233000134")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text$iter__233000099__233000103$fn__233000104$iter__233000129__233000133$fn__233000134$fn__233000135")

var Lit_44 *jrt.String = jrt.Intern("java.home")

var Lit_45 *jrt.String = jrt.Intern("lib")

var Lit_46 *jrt.String = jrt.Intern("classlist")

var Lit_47 *jrt.String = jrt.Intern("java.vm.info")

var Lit_48 *jrt.String = jrt.Intern("sharing")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.edge$fn__233000042$fn__233000043")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.edge$fn__233000042$fn__233000045")

var Lit_51 *jrt.String = jrt.Intern("j2g: warning: the JVM does not use the JDK's CDS archive: member tables order")

var Lit_52 *jrt.String = jrt.Intern("every class's overloads by descriptor")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.edge$generics_value$fn__233000207")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.edge$generics_value$fn__233000207$fn__233000208")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.edge$info_data$fn__233000050")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.edge$info_data$fn__233000055")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.edge$info_data$fn__233000050$fn__233000051")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.edge$info_data$fn__233000055$fn__233000056")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000188")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000192")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000188$fn__233000189")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000192$fn__233000193")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000192$fn__233000193$fn__233000194")

var Lit_64 *jrt.String = jrt.Intern("<init>")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000192$fn__233000193$fn__233000197")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000192$fn__233000193$fn__233000199")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value$fn__233000192$fn__233000193$fn__233000199$fn__233000200")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.edge$merge_edges$fn__233000169")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.edge$merge_edges$fn__233000169$fn__233000170")

var Lit_70 *jrt.String = jrt.Intern("nil")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.edge$pr_data$iter__233000016__233000020")

var Lit_72 *jrt.String = jrt.Intern("#{")

var Lit_73 *jrt.String = jrt.Intern("[")

var Lit_74 *jrt.String = jrt.Intern("j2g edge: cannot write ")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.edge$pr_data$iter__233000016__233000020$fn__233000021")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.edge$pr_data$iter__233000016__233000020$fn__233000021$fn__233000022")

var Lit_77 *jrt.String = jrt.Intern("##NaN")

var Lit_78 *jrt.String = jrt.Intern("##Inf")

var Lit_79 *jrt.String = jrt.Intern("##-Inf")

var Lit_80 *jrt.String = jrt.Intern("\"")

var Lit_81 *jrt.String = jrt.Intern("\\\"")

var Lit_82 *jrt.String = jrt.Intern("\\\\")

var Lit_83 *jrt.String = jrt.Intern("\\u%04x")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge$rd__233000220")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge$fn__233000222")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge$fn__233000222$iter__233000223__233000227")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge$fn__233000222$iter__233000223__233000227$fn__233000228")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge$fn__233000222$iter__233000223__233000227$fn__233000228$fn__233000229")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge_data$fn__233000243")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge_data$fn__233000245")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge_data$fn__233000245$iter__233000246__233000250")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge_data$fn__233000245$iter__233000246__233000250$fn__233000251")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge_data$fn__233000245$iter__233000246__233000250$fn__233000251$fn__233000252")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.edge$recorded_edge$fn__233000148")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.edge$recorded_edge$fn__233000148$iter__233000149__233000153")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.edge$recorded_edge$fn__233000148$iter__233000149__233000153$fn__233000154")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.edge$recorded_edge$fn__233000148$iter__233000149__233000153$fn__233000154$fn__233000155")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge$iter__233000268__233000272")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge$iter__233000268__233000272$fn__233000273")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge$iter__233000268__233000272$fn__233000273$fn__233000274")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge$iter__233000268__233000272$fn__233000273$fn__233000290")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge$iter__233000268__233000272$fn__233000273$fn__233000293")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge$iter__233000268__233000272$fn__233000273$fn__233000274$fn__233000278")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge$iter__233000268__233000272$fn__233000273$fn__233000274$fn__233000281")

var Lit_105 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn7,dynamickn8,arglistsyn7,sectionyn1,kyn1,fkn7,privatekn3,tagyn6,Stringyn6,doubleyn1,xyn1,vyn1,myn4,infoyn1,nyn6,facetskn4,keysyn7,classeskn2,asyn4,edgeyn7,env-recyn7,j2g-recyn5,edgesyn4,descyn1,gyn1,&yn4,moreyn1,eyn4,baseyn3,cmdyn4,argsv11,arbace.core5,in-nsMyn15,arbace.j2g.edgem2,R0,s918,j2g's edge (doc/STANDALONE-NOTES.md, S2): what j2g knows of the classes outside the forms\n  (the JDK's classes jrt hand-writes or the world does not hold, the cut classes, Arbace's\n  runtime classes on the JVM), as data instead of the JVM's reflection and ASM. The declaration\n  file (jdk/edge.edn, Clojure-reader data) is written by recording what one j2g run asks the\n  JVM (--record-edge: arbace.classes.env's facets, and j2g's own questions below), and read back\n  by every other run, which then loads no class and reflects on nothing (arbace.classes.env's\n  *declared*). bin/j2g-edge updates and verifies it.\n\n  The file: {:classes {internal-name {:exists true :info class-info facet value ...}}\n  :method-order {internal-name {method-name [[param binary names] ...]}} :cut {internal-name\n  {:methods :fields :ctors}} :exists #{binary-name} :member-types {internal-name\n  [internal-name]} :unexported #{package}}.m2,R0,s918,j2g's edge (doc/STANDALONE-NOTES.md, S2): what j2g knows of the classes outside the forms\n  (the JDK's classes jrt hand-writes or the world does not hold, the cut classes, Arbace's\n  runtime classes on the JVM), as data instead of the JVM's reflection and ASM. The declaration\n  file (jdk/edge.edn, Clojure-reader data) is written by recording what one j2g run asks the\n  JVM (--record-edge: arbace.classes.env's facets, and j2g's own questions below), and read back\n  by every other run, which then loads no class and reflects on nothing (arbace.classes.env's\n  *declared*). bin/j2g-edge updates and verifies it.\n\n  The file: {:classes {internal-name {:exists true :info class-info facet value ...}}\n  :method-order {internal-name {method-name [[param binary names] ...]}} :cut {internal-name\n  {:methods :fields :ctors}} :exists #{binary-name} :member-types {internal-name\n  [internal-name]} :unexported #{package}}.R1,v15,arbace.j2g.edge10,info-valuem8,R2,TR3,i19,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge9,canonicalm8,R2,TR3,i19,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge6,*edge*m10,R6,TR3,i21,R4,i1,R5,s18,arbace/j2g/edge.aeR0,s61,The declared edge being used (sealed: no reflection), or nil.v15,arbace.j2g.edge11,*recording*m10,R6,TR3,i25,R4,i1,R5,s18,arbace/j2g/edge.aeR0,s76,nil, or an atom of j2g's own sections being recorded: {section {key value}}.v15,arbace.j2g.edge3,jvmm10,R7,L1,V3,R8,R9,R10,R0,s147,j2g's question k of section about the JVM: with an edge, its declared answer (nil when it has\n  none); else (f) on this JVM, recorded when not nil.R3,i29,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge4,jvm?m10,R7,L1,V3,R8,R9,R10,R0,s77,A yes-or-no question k of section (a set in the edge: the keys answered yes).R3,i39,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge9,pr-stringm10,R11,TR7,L1,V1,Myn1,sm2,R12,R13,R3,i52,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge9,pr-doublem10,R11,TR7,L1,V1,Myn1,dm2,R12,R14,R3,i62,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge7,pr-datam10,R7,L1,V1,R15,R0,s92,x as Clojure-reader text: maps with their keys sorted, sets sorted, every sequence a vector.R3,i68,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge10,const-datam12,R11,TR7,L1,V1,R16,R0,s75,A constant value as data: a char as its code (read back by its descriptor).R3,i85,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge8,ann-datam12,R11,TR7,L1,V1,R15,R0,s70,Annotation values ({:const {:val v :type d}} ...) with chars as codes.R3,i90,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge16,archived-classesm8,R3,i99,R4,i1,R5,s18,arbace/j2g/edge.aeR0,s519,The classes of the running JDK's default CDS archive (its lib/classlist, the archive's\n  input; internal names), when the JVM maps the archive (java.vm.info says sharing), else\n  #{}. HotSpot sorts a class's methods by the address of their name's Symbol, so the order of\n  getDeclaredMethods, a name's overloads included, varies from one JVM process to the next\n  for a class it loads and parses (Arbace's own, the JDK's outside the archive); an archived\n  class keeps the order of the archive, fixed for the JDK build.v15,arbace.j2g.edge10,method-keym12,R11,TR7,L1,V1,R17,R0,s263,The order of the methods of a class outside the JDK's CDS archive in the edge: by name, then\n  descriptor (getDeclaredMethods's order varies from one process to the next for them; an\n  archived class's methods keep the JVM's order, on which j2g's output depends).R3,i115,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge9,info-datam12,R11,TR7,L1,V1,R18,R0,s319,A class info of reflection (env/reflect-info) as data: no Class, no :owner (the class's\n  name), the delayed annotations forced, the methods in method-key's order; what reflect-info\n  always has left out: a field's nil :const, a method's empty :throws, :annotations and\n  :param-annotations (a constructor has neither).R3,i122,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge16,class-entry-textm10,R11,TR7,L1,V2,R19,R20,R3,i143,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge9,edge-textm10,R7,L1,V1,m4,R21,V1,R22,R23,R24,R0,s21,The edge's file text.R3,i161,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge13,recorded-edgem10,R7,L1,V2,R25,R26,R0,s115,The edge of what this run recorded: env's facets with each class's info (by reflection,\n  now), and j2g's sections.R3,i177,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge11,merge-edgesm10,R7,L1,V1,R27,R0,s63,The union of edges (the same JVM answers: their entries agree).R3,i188,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge12,coerce-constm10,R11,TR7,L1,V2,R28,R16,R3,i199,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge9,ann-valuem10,R11,TR7,L1,V1,R15,R3,i206,R4,i1,R5,s18,arbace/j2g/edge.aem12,R11,TR7,L1,V1,R18,R0,s169,A declared class info in env's own shape (reflect-info's): owners, int flags, constants of\n  their field's type, annotations delayed, what info-data leaves out restored.R3,i213,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge14,generics-valuem10,R11,TR7,L1,V1,R29,R3,i236,R4,i1,R5,s18,arbace/j2g/edge.aem12,R11,TR7,L1,V2,R19,R20,R0,s131,A class's facets with the methods of its info and generics in method-key's order when the\n  class is outside the JDK's CDS archive.R3,i240,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge9,read-edgem10,R7,L1,V3,R10,R30,R31,R0,s258,The edge of file f, ready for binding: :classes in env's shape (env/*declared*). With\n  several files, their union (merge-edges): the tool build's, jdk/edge.edn and the edge of\n  javac's world, jdk/javac/edge.edn (doc/classes/JAVA-FRONTEND-SURVEY.md, JFS14).R3,i250,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge14,read-edge-datam10,R7,L1,V1,R10,R0,s83,The edge of file f as data, as edge-text writes it (its infos in info-data's form).R3,i264,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge11,write-edge!m8,R7,L1,V2,R10,R24,R3,i274,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge13,subtract-edgem10,R7,L1,V2,R32,R33,R0,s269,What edge e holds beyond edge base: each section's entries that base lacks or answers\n  otherwise (a class's entry whole), so that (merge-edges [base (subtract-edge e base)]) is\n  (merge-edges [base e]): the edge of javac's world beside jdk/edge.edn (bin/javac-vendor).R3,i278,R4,i1,R5,s18,arbace/j2g/edge.aev15,arbace.j2g.edge5,-mainm10,R7,L1,V3,R34,R30,R35,R0,s148,merge OUT IN...: writes the union of the edges IN to OUT. subtract OUT IN BASE: writes what\n  edge IN holds beyond edge BASE to OUT (subtract-edge).R3,i291,R4,i1,R5,s18,arbace/j2g/edge.ae")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.edge$eval233000004$loading__1927001464__auto____233000005")

var Lit_107 *jrt.String = jrt.Intern("arbace.j2g.edge$eval233000008$fn__233000009")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.edge$jvm")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.edge$jvm_QMARK_")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.edge$pr_string")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.edge$pr_double")

var Lit_112 *jrt.String = jrt.Intern("arbace.j2g.edge$pr_data")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.edge$const_data")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.edge$ann_data")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.edge$fn__233000042")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.edge$method_key")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.edge$info_data")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.edge$class_entry_text")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.edge$edge_text")

var Lit_120 *jrt.String = jrt.Intern("arbace.j2g.edge$recorded_edge")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.edge$merge_edges")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.edge$coerce_const")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.edge$ann_value")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.edge$info_value")

var Lit_125 *jrt.String = jrt.Intern("arbace.j2g.edge$generics_value")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.edge$canonical")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.edge$read_edge_data")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.edge$write_edge_BANG_")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.edge$subtract_edge")

var Lit_131 *jrt.String = jrt.Intern("arbace.j2g.edge$_main")
