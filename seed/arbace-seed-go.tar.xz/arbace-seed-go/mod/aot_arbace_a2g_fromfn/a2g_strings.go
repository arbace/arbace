//line a2g_strings.ae:1
package aot_arbace_a2g_fromfn

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.a2g.modelyn1,myn16,arbace.a2g.namesyn2,nmyn22,arbace.classes.opcodesyn7,Opcodeskn3,dockn3,tagkn10,functionalkn4,typekn11,annotationskn4,elseys3,jrt3,Boxyn9,fromFnRefkn4,langyn10,fromFnCharyn11,.ArrayClassyn4,instys3,jrt13,A2g_CastArraykn4,descyn16,.ApplyTo_ISeq__Oyn1,fyn14,RT_Seq_O__ISeqys3,jrt10,RefArrayOfys3,jrt12,Object_classyn2,fnyn6,returnyn4,set!yn8,.-FromFnyn5,.Infoyn3,anyyn1,xyn3,letyn8,IFn_Castyn4,addryn3,litkn2,Fnys2,go4,funckn11,type-paramsyn1,Tyn1,*kn4,linekn6,columnyn4,whenyn2,==yn1,pyn6,uint16yn6,valuesyn1,vyn2,okys3,jrt5,Unboxys3,jrt9,Prim_charyn1,ryn3,notyn5,panicys3,jrt6,Thrownys3,jrt3,NPEys3,jrt9,ClassCastyn6,assertys3,a2g7,commentyn4,initv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn17,arbace.a2g.fromfnm2,R16,s660,A2G-SPEC §7.11, §5.11 (amendment R13): ClassInfo.FromFn of every functional interface of the\n  closed world (the @FunctionalInterface ones), which wraps a Clojure fn into the interface's\n  adapter F_Fn. jrt.AdaptFn calls it where the JVM's Reflector makes a java.lang.reflect.Proxy\n  (Reflector.boxArg), and jrt's isAnnotationPresent(FunctionalInterface) answers FromFn != nil.\n  The adapter behaves as that proxy's handler: the arguments boxed, the fn applied, the result\n  converted as Reflector.coerceAdapterReturn converts it. Written in arbace/lang\n  (a2g_fromfn.go), as it calls IFn and RT; it sets the jrt classes' FromFn at Go package\n  initialization.v11,arbace.core13,*loaded-libs*v11,arbace.core9,with-metaR17,v11,arbace.core6,concatv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restV1,V3,s14,arbace/lang/RTs3,seqs38,(Ljava/lang/Object;)Larbace/lang/ISeq;v17,arbace.a2g.fromfn5,castsv18,arbace.classes.env6,known?v18,arbace.classes.env9,reflectedv22,arbace.classes.analyze4,declv11,arbace.core4,someR18,R19,v11,arbace.core5,forceR20,v11,arbace.core9,contains?v11,arbace.core4,sortv11,arbace.core6,filterv18,arbace.classes.env10,interface?v11,arbace.core3,notv17,arbace.a2g.fromfn11,functional?v22,arbace.classes.analyze8,find-samv16,arbace.a2g.model10,reflected?v16,arbace.a2g.names13,compiled-pkg?v16,arbace.a2g.model3,pkgv20,arbace.classes.types5,prim?v11,arbace.core4,listv16,arbace.a2g.model13,pointer-desc?R21,R22,R23,v20,arbace.classes.types6,array?v16,arbace.a2g.model9,class-symR24,v16,arbace.a2g.names11,method-baseR25,v11,arbace.core7,iteratev20,arbace.classes.types9,elem-typeR26,v11,arbace.core6,symbolv20,arbace.classes.types15,prim-desc->namev20,arbace.classes.types14,desc->internalR27,R28,v16,arbace.a2g.model7,go-typev20,arbace.classes.types17,parse-method-descv11,arbace.core3,vecR29,v11,arbace.core5,rangeR30,R31,R32,v11,arbace.core5,applyR33,R34,v11,arbace.core3,mapv17,arbace.a2g.fromfn3,boxR35,v11,arbace.core4,not=v11,arbace.core9,vary-metav17,arbace.a2g.fromfn3,tagv11,arbace.core5,assocR36,v17,arbace.a2g.fromfn6,resultR37,R38,R39,R35,m2,R17,R40,R41,R40,R42,R31,R43,R41,R44,R45,R46,ML7,R47,R23,R48,V1,R49,MV1,Myn1,pm2,R17,ML2,R50,R49,m4,R51,i90,R52,i56,m2,R17,R40,ML3,R53,ML3,R54,R55,nm4,R51,i91,R52,i15,ML2,R36,nm4,R51,i91,R52,i26,m4,R51,i91,R52,i9,R55,m4,R51,i90,R52,i7,ML4,R47,R25,MV1,Myn1,rm2,R17,R40,m2,R17,R56,ML4,R42,V2,ML3,R57,R58,R59,m4,R51,i94,R52,i15,ML3,R60,R61,R62,m4,R51,i94,R52,i29,ML4,R53,ML2,R63,R59,m4,R51,i95,R52,i17,ML3,R53,ML3,R54,R62,nm4,R51,i96,R52,i19,ML2,R64,ML2,R65,ML1,R66,m4,R51,i96,R52,i49,m4,R51,i96,R52,i37,m4,R51,i96,R52,i30,m4,R51,i96,R52,i13,ML2,R64,ML3,R67,R62,R61,m4,R51,i97,R52,i20,m4,R51,i97,R52,i13,m4,R51,i95,R52,i11,ML3,R68,R56,R58,m4,R51,i98,R52,i11,m4,R51,i94,R52,i9,m4,R51,i93,R52,i7,R69,R47,R70,v17,arbace.a2g.fromfn8,set-form")

var Lit_1 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_2 *jrt.String = jrt.Intern("arbace/lang/IFn")

var Lit_3 *jrt.String = jrt.Intern("arbace.a2g.fromfn$fis$fn__332000037")

var Lit_4 *jrt.String = jrt.Intern("---- FromFn of ")

var Lit_5 *jrt.String = jrt.Intern(" functional interfaces (A2G-SPEC §7.11)")

var Lit_6 *jrt.String = jrt.Intern("arbace.a2g.fromfn$functional_QMARK_$fn__332000031")

var Lit_7 *jrt.String = jrt.Intern("arbace.a2g.fromfn$functional_QMARK_$fn__332000033")

var Lit_8 *jrt.String = jrt.Intern("java.lang.FunctionalInterface")

var Lit_9 *jrt.String = jrt.Intern("Ljava/lang/FunctionalInterface;")

var Lit_10 *jrt.String = jrt.Intern("_")

var Lit_11 *jrt.String = jrt.Intern("(Ljava/lang/Object;)")

var Lit_12 *jrt.String = jrt.Intern("C")

var Lit_13 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.fromfn$result$fn__332000042")

var Lit_15 *jrt.String = jrt.Intern("_Cast")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.fromfn$result$fn__332000042$fn__332000043")

var Lit_17 *jrt.String = jrt.Intern("jrt/Prim_")

var Lit_18 *jrt.String = jrt.Intern("_class")

var Lit_19 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots$iter__332000013__332000017")

var Lit_20 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018$fn__332000019")

var Lit_22 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$iter__332000052__332000056")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$fn__332000063")

var Lit_24 *jrt.String = jrt.Intern("V")

var Lit_25 *jrt.String = jrt.Intern("_Fn")

var Lit_26 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057")

var Lit_27 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057$fn__332000058")

var Lit_28 *jrt.String = jrt.Intern("p")

var Lit_29 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,symyn4,typekn4,linekn6,columnkn4,fileyn1,nyn1,Tyn1,pyn1,dyn1,ryn2,fiyn3,fisv11,arbace.core5,in-nsMyn17,arbace.a2g.fromfnm2,R0,s660,A2G-SPEC §7.11, §5.11 (amendment R13): ClassInfo.FromFn of every functional interface of the\n  closed world (the @FunctionalInterface ones), which wraps a Clojure fn into the interface's\n  adapter F_Fn. jrt.AdaptFn calls it where the JVM's Reflector makes a java.lang.reflect.Proxy\n  (Reflector.boxArg), and jrt's isAnnotationPresent(FunctionalInterface) answers FromFn != nil.\n  The adapter behaves as that proxy's handler: the arguments boxed, the fn applied, the result\n  converted as Reflector.coerceAdapterReturn converts it. Written in arbace/lang\n  (a2g_fromfn.go), as it calls IFn and RT; it sets the jrt classes' FromFn at Go package\n  initialization.m2,R0,s660,A2G-SPEC §7.11, §5.11 (amendment R13): ClassInfo.FromFn of every functional interface of the\n  closed world (the @FunctionalInterface ones), which wraps a Clojure fn into the interface's\n  adapter F_Fn. jrt.AdaptFn calls it where the JVM's Reflector makes a java.lang.reflect.Proxy\n  (Reflector.boxArg), and jrt's isAnnotationPresent(FunctionalInterface) answers FromFn != nil.\n  The adapter behaves as that proxy's handler: the arguments boxed, the fn applied, the result\n  converted as Reflector.coerceAdapterReturn converts it. Written in arbace/lang\n  (a2g_fromfn.go), as it calls IFn and RT; it sets the jrt classes' FromFn at Go package\n  initialization.R1,v17,arbace.a2g.fromfn3,tagm10,R2,TR3,L1,V2,R4,R5,R6,i18,R7,i1,R8,s20,arbace/a2g/fromfn.aev17,arbace.a2g.fromfn5,castsm14,s1,Zs11,booleanCasts1,Js8,longCasts1,Ds10,doubleCasts1,Is7,intCasts1,Ss9,shortCasts1,Bs8,byteCasts1,Fs9,floatCastm10,R2,TR6,i20,R7,i1,R8,s20,arbace/a2g/fromfn.aeR0,s83,Reflector.coerceAdapterReturn: a primitive result by RT's casts (boolean by truth).v17,arbace.a2g.fromfn5,rootsm10,R3,L1,V0,R0,s50,What the FromFn adapters call: reachability roots.R6,i25,R7,i1,R8,s20,arbace/a2g/fromfn.aev17,arbace.a2g.fromfn11,functional?m10,R2,TR3,L1,V1,R9,R6,i32,R7,i1,R8,s20,arbace/a2g/fromfn.aev17,arbace.a2g.fromfn3,fism10,R3,L1,V1,R10,R0,s175,The functional interfaces among the classes T that get FromFn: interfaces with\n  @FunctionalInterface and one abstract method (none when the program has no Clojure\n  runtime).R6,i38,R7,i1,R8,s20,arbace/a2g/fromfn.aev17,arbace.a2g.fromfn3,boxm10,R2,TR3,L1,V2,R11,R12,R6,i49,R7,i1,R8,s20,arbace/a2g/fromfn.aev17,arbace.a2g.fromfn6,resultm10,R2,TR3,L1,V2,R13,R12,R6,i54,R7,i1,R8,s20,arbace/a2g/fromfn.aev17,arbace.a2g.fromfn8,set-formm10,R3,L1,V1,R14,R0,s79,The statement setting FromFn of functional interface fi (in the init function).R6,i70,R7,i1,R8,s20,arbace/a2g/fromfn.aev17,arbace.a2g.fromfn5,formsm10,R3,L1,V1,R15,R0,s83,The forms of a2g_fromfn.go (package arbace/lang) for the functional interfaces fis.R6,i85,R7,i1,R8,s20,arbace/a2g/fromfn.ae")

var Lit_30 *jrt.String = jrt.Intern("arbace.a2g.fromfn$eval332000004$loading__1927001464__auto____332000005")

var Lit_31 *jrt.String = jrt.Intern("arbace.a2g.fromfn$eval332000008$fn__332000009")

var Lit_32 *jrt.String = jrt.Intern("arbace.a2g.fromfn$tag")

var Lit_33 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots")

var Lit_34 *jrt.String = jrt.Intern("arbace.a2g.fromfn$functional_QMARK_")

var Lit_35 *jrt.String = jrt.Intern("arbace.a2g.fromfn$fis")

var Lit_36 *jrt.String = jrt.Intern("arbace.a2g.fromfn$box")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.fromfn$result")

var Lit_38 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.fromfn$forms")
