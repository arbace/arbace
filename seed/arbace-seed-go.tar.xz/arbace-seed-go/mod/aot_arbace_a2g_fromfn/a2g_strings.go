//line a2g_strings.ae:1
package aot_arbace_a2g_fromfn

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_11 *jrt.String = jrt.Intern("a")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_13 *jrt.String = jrt.Intern("m")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_15 *jrt.String = jrt.Intern("nm")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_17 *jrt.String = jrt.Intern("Opcodes")

var Lit_18 *jrt.String = jrt.Intern("commute")

var Lit_19 *jrt.String = jrt.Intern("deref")

var Lit_20 *jrt.String = jrt.Intern("conj")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.fromfn")

var Lit_22 *jrt.String = jrt.Intern("doc")

var Lit_23 *jrt.String = jrt.Intern("A2G-SPEC §7.11, §5.11 (amendment R13): ClassInfo.FromFn of every functional interface of the\n  closed world (the @FunctionalInterface ones), which wraps a Clojure fn into the interface's\n  adapter F_Fn. jrt.AdaptFn calls it where the JVM's Reflector makes a java.lang.reflect.Proxy\n  (Reflector.boxArg), and jrt's isAnnotationPresent(FunctionalInterface) answers FromFn != nil.\n  The adapter behaves as that proxy's handler: the arguments boxed, the fn applied, the result\n  converted as Reflector.coerceAdapterReturn converts it. Written in arbace/lang\n  (a2g_fromfn.go), as it calls IFn and RT; it sets the jrt classes' FromFn at Go package\n  initialization.")

var Lit_24 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_25 *jrt.String = jrt.Intern("with-meta")

var Lit_26 *jrt.String = jrt.Intern("tag")

var Lit_27 *jrt.String = jrt.Intern("concat")

var Lit_28 *jrt.String = jrt.Intern("seq")

var Lit_29 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_30 *jrt.String = jrt.Intern("chunk-first")

var Lit_31 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_32 *jrt.String = jrt.Intern("chunk-append")

var Lit_33 *jrt.String = jrt.Intern("chunk-cons")

var Lit_34 *jrt.String = jrt.Intern("first")

var Lit_35 *jrt.String = jrt.Intern("cons")

var Lit_36 *jrt.String = jrt.Intern("chunk")

var Lit_37 *jrt.String = jrt.Intern("chunk-rest")

var Lit_38 *jrt.String = jrt.Intern("rest")

var Lit_39 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_40 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Larbace/lang/ISeq;")

var Lit_41 *jrt.String = jrt.Intern("casts")

var Lit_42 *jrt.String = jrt.Intern("known?")

var Lit_43 *jrt.String = jrt.Intern("reflected")

var Lit_44 *jrt.String = jrt.Intern("decl")

var Lit_45 *jrt.String = jrt.Intern("some")

var Lit_46 *jrt.String = jrt.Intern("functional")

var Lit_47 *jrt.String = jrt.Intern("type")

var Lit_48 *jrt.String = jrt.Intern("force")

var Lit_49 *jrt.String = jrt.Intern("annotations")

var Lit_50 *jrt.String = jrt.Intern("contains?")

var Lit_51 *jrt.String = jrt.Intern("sort")

var Lit_52 *jrt.String = jrt.Intern("filter")

var Lit_53 *jrt.String = jrt.Intern("interface?")

var Lit_54 *jrt.String = jrt.Intern("not")

var Lit_55 *jrt.String = jrt.Intern("functional?")

var Lit_56 *jrt.String = jrt.Intern("find-sam")

var Lit_57 *jrt.String = jrt.Intern("reflected?")

var Lit_58 *jrt.String = jrt.Intern("compiled-pkg?")

var Lit_59 *jrt.String = jrt.Intern("pkg")

var Lit_60 *jrt.String = jrt.Intern("prim?")

var Lit_61 *jrt.String = jrt.Intern("list")

var Lit_62 *jrt.String = jrt.Intern("pointer-desc?")

var Lit_63 *jrt.String = jrt.Intern("else")

var Lit_64 *jrt.String = jrt.Intern("jrt")

var Lit_65 *jrt.String = jrt.Intern("Box")

var Lit_66 *jrt.String = jrt.Intern("fromFnRef")

var Lit_67 *jrt.String = jrt.Intern("array?")

var Lit_68 *jrt.String = jrt.Intern("class-sym")

var Lit_69 *jrt.String = jrt.Intern("lang")

var Lit_70 *jrt.String = jrt.Intern("method-base")

var Lit_71 *jrt.String = jrt.Intern("fromFnChar")

var Lit_72 *jrt.String = jrt.Intern("iterate")

var Lit_73 *jrt.String = jrt.Intern("elem-type")

var Lit_74 *jrt.String = jrt.Intern(".ArrayClass")

var Lit_75 *jrt.String = jrt.Intern("symbol")

var Lit_76 *jrt.String = jrt.Intern("prim-desc->name")

var Lit_77 *jrt.String = jrt.Intern("desc->internal")

var Lit_78 *jrt.String = jrt.Intern("inst")

var Lit_79 *jrt.String = jrt.Intern("A2g_CastArray")

var Lit_80 *jrt.String = jrt.Intern("go-type")

var Lit_81 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_82 *jrt.String = jrt.Intern("vec")

var Lit_83 *jrt.String = jrt.Intern("desc")

var Lit_84 *jrt.String = jrt.Intern("range")

var Lit_85 *jrt.String = jrt.Intern(".ApplyTo_ISeq__O")

var Lit_86 *jrt.String = jrt.Intern("f")

var Lit_87 *jrt.String = jrt.Intern("RT_Seq_O__ISeq")

var Lit_88 *jrt.String = jrt.Intern("apply")

var Lit_89 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_90 *jrt.String = jrt.Intern("Object_class")

var Lit_91 *jrt.String = jrt.Intern("map")

var Lit_92 *jrt.String = jrt.Intern("box")

var Lit_93 *jrt.String = jrt.Intern("fn")

var Lit_94 *jrt.String = jrt.Intern("not=")

var Lit_95 *jrt.String = jrt.Intern("vary-meta")

var Lit_96 *jrt.String = jrt.Intern("assoc")

var Lit_97 *jrt.String = jrt.Intern("return")

var Lit_98 *jrt.String = jrt.Intern("result")

var Lit_99 *jrt.String = jrt.Intern("set!")

var Lit_100 *jrt.String = jrt.Intern(".-FromFn")

var Lit_101 *jrt.String = jrt.Intern(".Info")

var Lit_102 *jrt.String = jrt.Intern("any")

var Lit_103 *jrt.String = jrt.Intern("x")

var Lit_104 *jrt.String = jrt.Intern("let")

var Lit_105 *jrt.String = jrt.Intern("IFn_Cast")

var Lit_106 *jrt.String = jrt.Intern("addr")

var Lit_107 *jrt.String = jrt.Intern("lit")

var Lit_108 *jrt.String = jrt.Intern("Fn")

var Lit_109 *jrt.String = jrt.Intern("go")

var Lit_110 *jrt.String = jrt.Intern("func")

var Lit_111 *jrt.String = jrt.Intern("type-params")

var Lit_112 *jrt.String = jrt.Intern("T")

var Lit_113 *jrt.String = jrt.Intern("p")

var Lit_114 *jrt.String = jrt.Intern("*")

var Lit_115 *jrt.String = jrt.Intern("line")

var Lit_116 *jrt.String = jrt.Intern("column")

var Lit_117 *jrt.String = jrt.Intern("when")

var Lit_118 *jrt.String = jrt.Intern("==")

var Lit_119 *jrt.String = jrt.Intern("r")

var Lit_120 *jrt.String = jrt.Intern("uint16")

var Lit_121 *jrt.String = jrt.Intern("values")

var Lit_122 *jrt.String = jrt.Intern("v")

var Lit_123 *jrt.String = jrt.Intern("ok")

var Lit_124 *jrt.String = jrt.Intern("Unbox")

var Lit_125 *jrt.String = jrt.Intern("Prim_char")

var Lit_126 *jrt.String = jrt.Intern("panic")

var Lit_127 *jrt.String = jrt.Intern("Thrown")

var Lit_128 *jrt.String = jrt.Intern("NPE")

var Lit_129 *jrt.String = jrt.Intern("ClassCast")

var Lit_130 *jrt.String = jrt.Intern("assert")

var Lit_131 *jrt.String = jrt.Intern("a2g")

var Lit_132 *jrt.String = jrt.Intern("comment")

var Lit_133 *jrt.String = jrt.Intern("init")

var Lit_134 *jrt.String = jrt.Intern("set-form")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.fromfn$box")

var Lit_136 *jrt.String = jrt.Intern("arbace.a2g.fromfn$eval332000004$loading__1927001464__auto____332000005")

var Lit_137 *jrt.String = jrt.Intern("arbace.a2g.fromfn$eval332000008$fn__332000009")

var Lit_138 *jrt.String = jrt.Intern("arbace.a2g.fromfn$fis")

var Lit_139 *jrt.String = jrt.Intern("arbace/lang/IFn")

var Lit_140 *jrt.String = jrt.Intern("arbace.a2g.fromfn$fis$fn__332000037")

var Lit_141 *jrt.String = jrt.Intern("arbace.a2g.fromfn$forms")

var Lit_142 *jrt.String = jrt.Intern("---- FromFn of ")

var Lit_143 *jrt.String = jrt.Intern(" functional interfaces (A2G-SPEC §7.11)")

var Lit_144 *jrt.String = jrt.Intern("arbace.a2g.fromfn$functional_QMARK_")

var Lit_145 *jrt.String = jrt.Intern("arbace.a2g.fromfn$functional_QMARK_$fn__332000031")

var Lit_146 *jrt.String = jrt.Intern("java.lang.FunctionalInterface")

var Lit_147 *jrt.String = jrt.Intern("arbace.a2g.fromfn$functional_QMARK_$fn__332000033")

var Lit_148 *jrt.String = jrt.Intern("Ljava/lang/FunctionalInterface;")

var Lit_149 *jrt.String = jrt.Intern("arbace.a2g.fromfn$result")

var Lit_150 *jrt.String = jrt.Intern("_")

var Lit_151 *jrt.String = jrt.Intern("(Ljava/lang/Object;)")

var Lit_152 *jrt.String = jrt.Intern("C")

var Lit_153 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_154 *jrt.String = jrt.Intern("_Cast")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.fromfn$result$fn__332000042")

var Lit_156 *jrt.String = jrt.Intern("jrt/Prim_")

var Lit_157 *jrt.String = jrt.Intern("_class")

var Lit_158 *jrt.String = jrt.Intern("arbace.a2g.fromfn$result$fn__332000042$fn__332000043")

var Lit_159 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots")

var Lit_160 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots$iter__332000013__332000017")

var Lit_161 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018")

var Lit_162 *jrt.String = jrt.Intern("arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018$fn__332000019")

var Lit_163 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form")

var Lit_164 *jrt.String = jrt.Intern("V")

var Lit_165 *jrt.String = jrt.Intern("_Fn")

var Lit_166 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$fn__332000063")

var Lit_167 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$iter__332000052__332000056")

var Lit_168 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057")

var Lit_169 *jrt.String = jrt.Intern("arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057$fn__332000058")

var Lit_170 *jrt.String = jrt.Intern("arbace.a2g.fromfn$tag")

var Lit_171 *jrt.String = jrt.Intern("in-ns")

var Lit_172 *jrt.String = jrt.Intern("private")

var Lit_173 *jrt.String = jrt.Intern("arglists")

var Lit_174 *jrt.String = jrt.Intern("sym")

var Lit_175 *jrt.String = jrt.Intern("file")

var Lit_176 *jrt.String = jrt.Intern("arbace/a2g/fromfn.ae")

var Lit_177 *jrt.String = jrt.Intern("Reflector.coerceAdapterReturn: a primitive result by RT's casts (boolean by truth).")

var Lit_178 *jrt.String = jrt.Intern("roots")

var Lit_179 *jrt.String = jrt.Intern("What the FromFn adapters call: reachability roots.")

var Lit_180 *jrt.String = jrt.Intern("n")

var Lit_181 *jrt.String = jrt.Intern("fis")

var Lit_182 *jrt.String = jrt.Intern("The functional interfaces among the classes T that get FromFn: interfaces with\n  @FunctionalInterface and one abstract method (none when the program has no Clojure\n  runtime).")

var Lit_183 *jrt.String = jrt.Intern("d")

var Lit_184 *jrt.String = jrt.Intern("fi")

var Lit_185 *jrt.String = jrt.Intern("The statement setting FromFn of functional interface fi (in the init function).")

var Lit_186 *jrt.String = jrt.Intern("forms")

var Lit_187 *jrt.String = jrt.Intern("The forms of a2g_fromfn.go (package arbace/lang) for the functional interfaces fis.")
