//line a2g_classes.ae:1
package aot_arbace_a2g_fromfn

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_fromfn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_A_New()}; return nil }

var A_arbace_a2g_fromfn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_fromfn_A_new}

var A_arbace_a2g_fromfn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_A"})

func init() { i := A_arbace_a2g_fromfn_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_A_Init; i.Table = A_arbace_a2g_fromfn_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_A]()) }

func A_arbace_a2g_fromfn_box_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_box_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_fromfn_box_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_box_A_New()}; return nil }

func A_arbace_a2g_fromfn_box_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_box_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_box_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_box_A_invoke, New: A_arbace_a2g_fromfn_box_A_new, Get: A_arbace_a2g_fromfn_box_A_get}

var A_arbace_a2g_fromfn_box_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$box", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "box", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_box_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_box_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_box_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_box_A_Init; i.Table = A_arbace_a2g_fromfn_box_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_box_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_box_A]()) }

func A_arbace_a2g_fromfn_eval332000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_eval332000004_A_New()}; return nil }

var A_arbace_a2g_fromfn_eval332000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_fromfn_eval332000004_A_new}

var A_arbace_a2g_fromfn_eval332000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$eval332000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "eval332000004", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000004_A"})

func init() { i := A_arbace_a2g_fromfn_eval332000004_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_eval332000004_A_InstanceOf; i.Table = A_arbace_a2g_fromfn_eval332000004_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_eval332000004_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_eval332000004_A]()) }

func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_New()}; return nil }

func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_invoke, New: A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_new, Get: A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_get}

var A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$eval332000004$loading__1927001464__auto____332000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_eval332000004_A_class, Simple: "loading__1927001464__auto____332000005", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_Init; i.Table = A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A]()) }

func A_arbace_a2g_fromfn_eval332000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_eval332000008_A_New()}; return nil }

var A_arbace_a2g_fromfn_eval332000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_fromfn_eval332000008_A_new}

var A_arbace_a2g_fromfn_eval332000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$eval332000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "eval332000008", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000008_A"})

func init() { i := A_arbace_a2g_fromfn_eval332000008_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_eval332000008_A_InstanceOf; i.Table = A_arbace_a2g_fromfn_eval332000008_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_eval332000008_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_eval332000008_A]()) }

func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_eval332000008_fn__332000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_New()}; return nil }

func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_invoke, New: A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_new, Get: A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_get}

var A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$eval332000008$fn__332000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_eval332000008_A_class, Simple: "fn__332000009", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000008_fn__332000009_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_Init; i.Table = A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_eval332000008_fn__332000009_A]()) }

func A_arbace_a2g_fromfn_fis_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_fis_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_fis_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_fis_A_New()}; return nil }

func A_arbace_a2g_fromfn_fis_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_fis_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_fis_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_fis_A_invoke, New: A_arbace_a2g_fromfn_fis_A_new, Get: A_arbace_a2g_fromfn_fis_A_get}

var A_arbace_a2g_fromfn_fis_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$fis", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "fis", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_fis_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_fis_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_fis_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_fis_A_Init; i.Table = A_arbace_a2g_fromfn_fis_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_fis_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_fis_A]()) }

func A_arbace_a2g_fromfn_fis_fn__332000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_fis_fn__332000037_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_fis_fn__332000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_fis_fn__332000037_A_New()}; return nil }

func A_arbace_a2g_fromfn_fis_fn__332000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_fis_fn__332000037_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_fis_fn__332000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_fis_fn__332000037_A_invoke, New: A_arbace_a2g_fromfn_fis_fn__332000037_A_new, Get: A_arbace_a2g_fromfn_fis_fn__332000037_A_get}

var A_arbace_a2g_fromfn_fis_fn__332000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$fis$fn__332000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_fis_A_class, Simple: "fn__332000037", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_fis_fn__332000037_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_fis_fn__332000037_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_fis_fn__332000037_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_fis_fn__332000037_A_Init; i.Table = A_arbace_a2g_fromfn_fis_fn__332000037_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_fis_fn__332000037_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_fis_fn__332000037_A]()) }

func A_arbace_a2g_fromfn_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_forms_A_New()}; return nil }

func A_arbace_a2g_fromfn_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_forms_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_forms_A_invoke, New: A_arbace_a2g_fromfn_forms_A_new, Get: A_arbace_a2g_fromfn_forms_A_get}

var A_arbace_a2g_fromfn_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "forms", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_forms_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_forms_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_forms_A_Init; i.Table = A_arbace_a2g_fromfn_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_forms_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_forms_A]()) }

func A_arbace_a2g_fromfn_functional_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_functional_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_functional_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_functional_QMARK__A_New()}; return nil }

func A_arbace_a2g_fromfn_functional_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_functional_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_functional_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_functional_QMARK__A_invoke, New: A_arbace_a2g_fromfn_functional_QMARK__A_new, Get: A_arbace_a2g_fromfn_functional_QMARK__A_get}

var A_arbace_a2g_fromfn_functional_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$functional_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "functional_QMARK_", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_functional_QMARK__A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_functional_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_functional_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_fromfn_functional_QMARK__A_Init; i.Table = A_arbace_a2g_fromfn_functional_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_functional_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_fromfn_functional_QMARK__A]()) }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_New()}; return nil }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_invoke, New: A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_new, Get: A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_get}

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$functional_QMARK_$fn__332000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_functional_QMARK__A_class, Simple: "fn__332000031", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_Init; i.Table = A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A]()) }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_New()}; return nil }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_invoke, New: A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_new, Get: A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_get}

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$functional_QMARK_$fn__332000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_functional_QMARK__A_class, Simple: "fn__332000033", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_Init; i.Table = A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A]()) }

func A_arbace_a2g_fromfn_result_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_result_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_fromfn_result_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_result_A_New()}; return nil }

func A_arbace_a2g_fromfn_result_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_result_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_result_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_result_A_invoke, New: A_arbace_a2g_fromfn_result_A_new, Get: A_arbace_a2g_fromfn_result_A_get}

var A_arbace_a2g_fromfn_result_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$result", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "result", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_result_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_result_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_result_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_result_A_Init; i.Table = A_arbace_a2g_fromfn_result_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_result_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_result_A]()) }

func A_arbace_a2g_fromfn_result_fn__332000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_result_fn__332000042_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_result_fn__332000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_result_fn__332000042_A_New_O(args[0])}; return nil }

func A_arbace_a2g_fromfn_result_fn__332000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_result_fn__332000042_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_result_fn__332000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_result_fn__332000042_A_invoke, New: A_arbace_a2g_fromfn_result_fn__332000042_A_new, Get: A_arbace_a2g_fromfn_result_fn__332000042_A_get}

var A_arbace_a2g_fromfn_result_fn__332000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$result$fn__332000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_result_A_class, Simple: "fn__332000042", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_result_fn__332000042_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_result_fn__332000042_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_result_fn__332000042_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_result_fn__332000042_A_Init; i.Table = A_arbace_a2g_fromfn_result_fn__332000042_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_result_fn__332000042_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_result_fn__332000042_A]()) }

func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_New()}; return nil }

func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_invoke, New: A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_new, Get: A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_get}

var A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$result$fn__332000042$fn__332000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_result_fn__332000042_A_class, Simple: "fn__332000043", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_Init; i.Table = A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A]()) }

func A_arbace_a2g_fromfn_roots_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_roots_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_roots_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_roots_A_New()}; return nil }

func A_arbace_a2g_fromfn_roots_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_roots_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_roots_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_roots_A_invoke, New: A_arbace_a2g_fromfn_roots_A_new, Get: A_arbace_a2g_fromfn_roots_A_get}

var A_arbace_a2g_fromfn_roots_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$roots", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "roots", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_roots_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_roots_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_roots_A_Init; i.Table = A_arbace_a2g_fromfn_roots_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_roots_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_roots_A]()) }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_New()}; return nil }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_invoke, New: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_new, Get: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_get}

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$roots$iter__332000013__332000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_roots_A_class, Simple: "iter__332000013__332000017", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_Init; i.Table = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A]()) }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_invoke, New: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_new, Get: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_get}

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class, Simple: "fn__332000018", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_Init; i.Table = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A]()) }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_invoke, New: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_new, Get: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_get}

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018$fn__332000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class, Simple: "fn__332000019", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_Init; i.Table = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A]()) }

func A_arbace_a2g_fromfn_set_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_set_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_set_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_set_form_A_New()}; return nil }

func A_arbace_a2g_fromfn_set_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_set_form_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_set_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_set_form_A_invoke, New: A_arbace_a2g_fromfn_set_form_A_new, Get: A_arbace_a2g_fromfn_set_form_A_get}

var A_arbace_a2g_fromfn_set_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$set_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "set_form", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_set_form_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_set_form_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_set_form_A_Init; i.Table = A_arbace_a2g_fromfn_set_form_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_set_form_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_set_form_A]()) }

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_set_form_fn__332000063_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_set_form_fn__332000063_A_New()}; return nil }

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_set_form_fn__332000063_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_set_form_fn__332000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_set_form_fn__332000063_A_invoke, New: A_arbace_a2g_fromfn_set_form_fn__332000063_A_new, Get: A_arbace_a2g_fromfn_set_form_fn__332000063_A_get}

var A_arbace_a2g_fromfn_set_form_fn__332000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$set_form$fn__332000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_fromfn_set_form_A_class, Simple: "fn__332000063", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_fn__332000063_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_set_form_fn__332000063_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_set_form_fn__332000063_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_set_form_fn__332000063_A_Init; i.Table = A_arbace_a2g_fromfn_set_form_fn__332000063_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_set_form_fn__332000063_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_set_form_fn__332000063_A]()) }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_New()}; return nil }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_invoke, New: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_new, Get: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_get}

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$set_form$iter__332000052__332000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_fromfn_set_form_A_class, Simple: "iter__332000052__332000056", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_Init; i.Table = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A]()) }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_invoke, New: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_new, Get: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_get}

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class, Simple: "fn__332000057", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_Init; i.Table = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A]()) }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_invoke, New: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_new, Get: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_get}

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057$fn__332000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class, Simple: "fn__332000058", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_Init; i.Table = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A]()) }

func A_arbace_a2g_fromfn_tag_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_fromfn_tag_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_fromfn_tag_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_tag_A_New()}; return nil }

func A_arbace_a2g_fromfn_tag_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_fromfn_tag_A_fn_class)}; return nil }

var A_arbace_a2g_fromfn_tag_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_fromfn_tag_A_invoke, New: A_arbace_a2g_fromfn_tag_A_new, Get: A_arbace_a2g_fromfn_tag_A_get}

var A_arbace_a2g_fromfn_tag_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$tag", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "tag", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_tag_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn_tag_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_tag_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_tag_A_Init; i.Table = A_arbace_a2g_fromfn_tag_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn_tag_A_class, reflect.TypeFor[A_arbace_a2g_fromfn_tag_A]()) }

func A_arbace_a2g_fromfn__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn__init_A_Load__O(); case 1: return A_arbace_a2g_fromfn__init_A_Unit0__O(); case 2: return A_arbace_a2g_fromfn__init_A_Unit1__O(); case 3: return A_arbace_a2g_fromfn__init_A_Unit10__O(); case 4: return A_arbace_a2g_fromfn__init_A_Unit11__O(); case 5: return A_arbace_a2g_fromfn__init_A_Unit12__O(); case 6: return A_arbace_a2g_fromfn__init_A_Unit2__O(); case 7: return A_arbace_a2g_fromfn__init_A_Unit3__O(); case 8: return A_arbace_a2g_fromfn__init_A_Unit4__O(); case 9: return A_arbace_a2g_fromfn__init_A_Unit5__O(); case 10: return A_arbace_a2g_fromfn__init_A_Unit6__O(); case 11: return A_arbace_a2g_fromfn__init_A_Unit7__O(); case 12: return A_arbace_a2g_fromfn__init_A_Unit8__O(); case 13: return A_arbace_a2g_fromfn__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_fromfn__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn__init_A_New()}; return nil }

var A_arbace_a2g_fromfn__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_fromfn__init_A_invoke, New: A_arbace_a2g_fromfn__init_A_new}

var A_arbace_a2g_fromfn__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn__init_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn__init_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn__init_A_InstanceOf; i.Init = A_arbace_a2g_fromfn__init_A_Init; i.Table = A_arbace_a2g_fromfn__init_A_members; jrt.RegisterGoType(A_arbace_a2g_fromfn__init_A_class, reflect.TypeFor[A_arbace_a2g_fromfn__init_A]()) }
