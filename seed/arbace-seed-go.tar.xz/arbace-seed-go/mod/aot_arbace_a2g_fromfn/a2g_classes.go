//line a2g_classes.ae:1
package aot_arbace_a2g_fromfn

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_box_A_class, Name: "arbace.a2g.fromfn$box", Modifiers: 25, Simple: "box", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_box_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_class, Name: "arbace.a2g.fromfn$eval332000004$loading__1927001464__auto____332000005", Modifiers: 25, Simple: "loading__1927001464__auto____332000005", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_eval332000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_class, Name: "arbace.a2g.fromfn$eval332000008$fn__332000009", Modifiers: 25, Simple: "fn__332000009", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000008_fn__332000009_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_eval332000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_fis_A_class, Name: "arbace.a2g.fromfn$fis", Modifiers: 25, Simple: "fis", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_fis_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_fis_fn__332000037_A_class, Name: "arbace.a2g.fromfn$fis$fn__332000037", Modifiers: 25, Simple: "fn__332000037", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_fis_fn__332000037_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_fis_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_forms_A_class, Name: "arbace.a2g.fromfn$forms", Modifiers: 25, Simple: "forms", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_forms_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_functional_QMARK__A_class, Name: "arbace.a2g.fromfn$functional_QMARK_", Modifiers: 25, Simple: "functional_QMARK_", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_functional_QMARK__A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_class, Name: "arbace.a2g.fromfn$functional_QMARK_$fn__332000031", Modifiers: 25, Simple: "fn__332000031", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_functional_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_class, Name: "arbace.a2g.fromfn$functional_QMARK_$fn__332000033", Modifiers: 25, Simple: "fn__332000033", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_functional_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_result_A_class, Name: "arbace.a2g.fromfn$result", Modifiers: 25, Simple: "result", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_result_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_result_fn__332000042_A_class, Name: "arbace.a2g.fromfn$result$fn__332000042", Modifiers: 25, Simple: "fn__332000042", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_result_fn__332000042_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_result_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_class, Name: "arbace.a2g.fromfn$result$fn__332000042$fn__332000043", Modifiers: 25, Simple: "fn__332000043", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_result_fn__332000042_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_roots_A_class, Name: "arbace.a2g.fromfn$roots", Modifiers: 25, Simple: "roots", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class, Name: "arbace.a2g.fromfn$roots$iter__332000013__332000017", Modifiers: 25, Simple: "iter__332000013__332000017", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_roots_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class, Name: "arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018", Modifiers: 25, Simple: "fn__332000018", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_class, Name: "arbace.a2g.fromfn$roots$iter__332000013__332000017$fn__332000018$fn__332000019", Modifiers: 25, Simple: "fn__332000019", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_set_form_A_class, Name: "arbace.a2g.fromfn$set_form", Modifiers: 25, Simple: "set_form", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_set_form_fn__332000063_A_class, Name: "arbace.a2g.fromfn$set_form$fn__332000063", Modifiers: 25, Simple: "fn__332000063", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_fn__332000063_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_set_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class, Name: "arbace.a2g.fromfn$set_form$iter__332000052__332000056", Modifiers: 25, Simple: "iter__332000052__332000056", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_set_form_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class, Name: "arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057", Modifiers: 25, Simple: "fn__332000057", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_class, Name: "arbace.a2g.fromfn$set_form$iter__332000052__332000056$fn__332000057$fn__332000058", Modifiers: 25, Simple: "fn__332000058", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_fromfn_tag_A_class, Name: "arbace.a2g.fromfn$tag", Modifiers: 25, Simple: "tag", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_tag_A", Source: "fromfn.ae", Declaring: &A_arbace_a2g_fromfn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_a2g_fromfn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_A_New()}; return nil }

var A_arbace_a2g_fromfn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_fromfn_A_new}

var A_arbace_a2g_fromfn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_A"})

func init() { i := A_arbace_a2g_fromfn_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_A_InstanceOf; i.Init = A_arbace_a2g_fromfn_A_Init; i.Table = A_arbace_a2g_fromfn_A_members }

var A_arbace_a2g_fromfn_box_A_class *jrt.Class

func A_arbace_a2g_fromfn_eval332000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_eval332000004_A_New()}; return nil }

var A_arbace_a2g_fromfn_eval332000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_fromfn_eval332000004_A_new}

var A_arbace_a2g_fromfn_eval332000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$eval332000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "eval332000004", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000004_A"})

func init() { i := A_arbace_a2g_fromfn_eval332000004_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_eval332000004_A_InstanceOf; i.Table = A_arbace_a2g_fromfn_eval332000004_A_members }

var A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_class *jrt.Class

func A_arbace_a2g_fromfn_eval332000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn_eval332000008_A_New()}; return nil }

var A_arbace_a2g_fromfn_eval332000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_fromfn_eval332000008_A_new}

var A_arbace_a2g_fromfn_eval332000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn$eval332000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_fromfn_A_class, Simple: "eval332000008", Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn_eval332000008_A"})

func init() { i := A_arbace_a2g_fromfn_eval332000008_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn_eval332000008_A_InstanceOf; i.Table = A_arbace_a2g_fromfn_eval332000008_A_members }

var A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_class *jrt.Class

var A_arbace_a2g_fromfn_fis_A_class *jrt.Class

var A_arbace_a2g_fromfn_fis_fn__332000037_A_class *jrt.Class

var A_arbace_a2g_fromfn_forms_A_class *jrt.Class

var A_arbace_a2g_fromfn_functional_QMARK__A_class *jrt.Class

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_class *jrt.Class

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_class *jrt.Class

var A_arbace_a2g_fromfn_result_A_class *jrt.Class

var A_arbace_a2g_fromfn_result_fn__332000042_A_class *jrt.Class

var A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_class *jrt.Class

var A_arbace_a2g_fromfn_roots_A_class *jrt.Class

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class *jrt.Class

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class *jrt.Class

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_A_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_fn__332000063_A_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_class *jrt.Class

var A_arbace_a2g_fromfn_tag_A_class *jrt.Class

func A_arbace_a2g_fromfn__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn__init_A_Load__O()}; return nil }

func A_arbace_a2g_fromfn__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_fromfn__init_A_New()}; return nil }

var A_arbace_a2g_fromfn__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_fromfn__init_A_invoke, New: A_arbace_a2g_fromfn__init_A_new}

var A_arbace_a2g_fromfn__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.fromfn__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_fromfn.A_arbace_a2g_fromfn__init_A", Source: "fromfn.ae"})

func init() { i := A_arbace_a2g_fromfn__init_A_class.Info(); i.IsInstance = A_arbace_a2g_fromfn__init_A_InstanceOf; i.Init = A_arbace_a2g_fromfn__init_A_Init; i.Table = A_arbace_a2g_fromfn__init_A_members }
