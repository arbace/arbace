//line aot_arbace_a2g_fromfn.ae:1
package aot_arbace_a2g_fromfn

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_New() *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A { A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_Init(); t := &A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp22 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_fromfn_A_Init(); tmp6 = A_arbace_a2g_fromfn_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp7 = A_arbace_a2g_fromfn_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_fromfn_A_Init(); tmp11 = A_arbace_a2g_fromfn_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_fromfn_A_Init(); tmp13 = A_arbace_a2g_fromfn_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_fromfn_A_Init(); tmp15 = A_arbace_a2g_fromfn_A_const_6; var tmp16 any = tmp15; var tmp17 any; A_arbace_a2g_fromfn_A_Init(); tmp17 = A_arbace_a2g_fromfn_A_const_7; var tmp18 any = tmp17; var tmp19 any; A_arbace_a2g_fromfn_A_Init(); tmp19 = A_arbace_a2g_fromfn_A_const_8; var tmp20 any = tmp19; var tmp21 any; A_arbace_a2g_fromfn_A_Init(); tmp21 = A_arbace_a2g_fromfn_A_const_9; tmp3 = tmp8.Invoke_O_O_O_O_O_O_O__O(tmp10, tmp12, tmp14, tmp16, tmp18, tmp20, tmp21) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp22 != nil { panic(tmp22) }; return tmp3 }
//line :1:1
func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_New() *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A { A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_Init(); t := &A_arbace_a2g_fromfn_eval332000008_fn__332000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp5 = A_arbace_a2g_fromfn_A_const_14; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp7 = A_arbace_a2g_fromfn_A_const_12; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_13; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
















func A_arbace_a2g_fromfn_tag_A_New() *A_arbace_a2g_fromfn_tag_A { A_arbace_a2g_fromfn_tag_A_Init(); t := &A_arbace_a2g_fromfn_tag_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_a2g_fromfn_tag_A) Ctor() {}
//line :18:1
func (t *A_arbace_a2g_fromfn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_16; return tmp2.Invoke_O_O__O(sym__0, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3.Ref(), type__1))) }






func A_arbace_a2g_fromfn_roots_A_New() *A_arbace_a2g_fromfn_roots_A { A_arbace_a2g_fromfn_roots_A_Init(); t := &A_arbace_a2g_fromfn_roots_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_a2g_fromfn_roots_A) Ctor() {}
//line :25:1
func (t *A_arbace_a2g_fromfn_roots_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var iter__1927001039__auto____1 any; var tmp4 any = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_New(); var tmp5 *jrt.Class
	A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_Init(); tmp5 = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_fn_class; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp7 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp7 = A_arbace_a2g_fromfn_A_const_30; tmp3 = tmp6.Invoke_O__O(jrt.NN(tmp7).GetRawRoot__O())
//line :28:1
	var tmp8 any = tmp3; var tmp9 any; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_29; return tmp2.Invoke_O_O__O(tmp8, tmp9) }
func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_New() *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_Init(); t := &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) Ctor() {}
//line :29:1
func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) Invoke_O_O__O(self, s__332000014__1 any) any { var tmp1 any = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_New_O_O(s__332000014__1, self); var tmp2 *jrt.Class; A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_Init(); tmp2 = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :29:1
func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_New_O_O(p0, p1 any) *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_Init(); t := &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :29:1
func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) Ctor_O_O(c__s__332000014, c__iter__332000013 any) { t.F_s__332000014 = c__s__332000014; t.F_iter__332000013 = c__iter__332000013 }
//line :29:1
func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) Invoke_O__O(self any) any { { var s__332000014__1 any; var t_ any = t.F_s__332000014; t.F_s__332000014 = nil; s__332000014__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_18; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__332000014__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__332000014__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__332000014__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_20; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__332000014__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__332000016__6 any; var tmp4 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_21; b__332000016__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_New_O_I_O(b__332000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_Init(); tmp6 = A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp7 = A_arbace_a2g_fromfn_A_const_23; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_26; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__332000016__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__332000013); var tmp12 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp12 = A_arbace_a2g_fromfn_A_const_27; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__332000014__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp13 = A_arbace_a2g_fromfn_A_const_23; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp15 = A_arbace_a2g_fromfn_A_const_26; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__332000016__6), nil) } } else { var vec__332000024__4 any; var tmp16 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp16 = A_arbace_a2g_fromfn_A_const_24; vec__332000024__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__332000014__3); var r__5 any = lang.RT_Nth_O_I_O__O(vec__332000024__4, lang.RT_IntCast_J__I(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O(vec__332000024__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp17 = A_arbace_a2g_fromfn_A_const_25; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_39, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_151, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__332000013); var tmp21 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp21 = A_arbace_a2g_fromfn_A_const_28; return tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__332000014__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :29:1
func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_Init(); t := &A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :29:1
func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) Ctor_O_I_O(c__b__332000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__332000016 = c__b__332000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :29:1
func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) Invoke_O__O(self any) any { { var i__332000015__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__332000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__332000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__332000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O(vec__332000020__2, lang.RT_IntCast_J__I(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O(vec__332000020__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__332000016; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_39, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_151, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref())); i__332000015__1 = lang.Numbers_Unchecked_inc_J__J(i__332000015__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_fromfn_functional_QMARK__A_New() *A_arbace_a2g_fromfn_functional_QMARK__A { A_arbace_a2g_fromfn_functional_QMARK__A_Init(); t := &A_arbace_a2g_fromfn_functional_QMARK__A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_a2g_fromfn_functional_QMARK__A) Ctor() {}
//line :32:1
func (t *A_arbace_a2g_fromfn_functional_QMARK__A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0)) {
		var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_32; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_35; var tmp5 any = tmp4.Ref(); var tmp6 any = A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_New(); var tmp7 *jrt.Class; A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_Init(); tmp7 = A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_fn_class; return tmp3.Invoke_O_O_O__O(n__0, tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)) } else {
//line :33:1
			var temp__1927000414__auto____2 any; var tmp8 *lang.Var

			A_arbace_a2g_fromfn_A_Init(); tmp8 = A_arbace_a2g_fromfn_A_const_33; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(temp__1927000414__auto____2) { var d__3 any = temp__1927000414__auto____2; var tmp9 *lang.Var
				A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_34; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_New(); var tmp12 *jrt.Class; A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_Init(); tmp12 = A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_fn_class; var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp14 = A_arbace_a2g_fromfn_A_const_37; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp16 = A_arbace_a2g_fromfn_A_const_38; return tmp10.Invoke_O_O__O(tmp13, tmp15.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(d__3))) } else {
//line :35:1
					return nil } } }
//line :34:1
func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_New() *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A { A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_Init(); t := &A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) Ctor() {}
//line :34:1
func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) Invoke_O_O__O(self, c__1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__1)).IsAnnotationPresent_Class__Z(lang.RT_ClassForNameNonLoading_String__Class(Lit_146))).Ref() }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_New() *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A { A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_Init(); t := &A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) Ctor() {}
//line :36:1
func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) Invoke_O_O__O(self, p1__332000030_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_36; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_148, jrt.NN(tmp1).Invoke_O__O(p1__332000030_SHARP___1))).Ref() }

func A_arbace_a2g_fromfn_fis_A_New() *A_arbace_a2g_fromfn_fis_A { A_arbace_a2g_fromfn_fis_A_Init(); t := &A_arbace_a2g_fromfn_fis_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_a2g_fromfn_fis_A) Ctor() {}
//line :38:1
func (t *A_arbace_a2g_fromfn_fis_A) Invoke_O_O__O(self, T__0_ any) any {




	var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_39; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(T__0_, Lit_39); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_39; tmp1 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(T__0_, Lit_139) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp4 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_40; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp6 = A_arbace_a2g_fromfn_A_const_41; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_a2g_fromfn_fis_fn__332000037_A_New(); var tmp9 *jrt.Class; A_arbace_a2g_fromfn_fis_fn__332000037_A_Init(); tmp9 = A_arbace_a2g_fromfn_fis_fn__332000037_A_fn_class; return tmp5.Invoke_O__O(tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), T__0_)) } else {
//line :43:1
			return nil } }
func A_arbace_a2g_fromfn_fis_fn__332000037_A_New() *A_arbace_a2g_fromfn_fis_fn__332000037_A { A_arbace_a2g_fromfn_fis_fn__332000037_A_Init(); t := &A_arbace_a2g_fromfn_fis_fn__332000037_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) Ctor() {}
//line :44:1
func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) Invoke_O_O__O(self, p1__332000036_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_42; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__332000036_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_43; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_46; and__1927000168__auto____3 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(p1__332000036_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp5 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp5 = A_arbace_a2g_fromfn_A_const_44; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(p1__332000036_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp6 *lang.Var
													A_arbace_a2g_fromfn_A_Init(); tmp6 = A_arbace_a2g_fromfn_A_const_43; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp8 = A_arbace_a2g_fromfn_A_const_47; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp10 = A_arbace_a2g_fromfn_A_const_48; and__1927000168__auto____5 = tmp7.Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(p1__332000036_SHARP___1)))
//line :44:1
	if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp11 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp12 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp12 = A_arbace_a2g_fromfn_A_const_45; tmp11 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(p1__332000036_SHARP___1) }
//line :44:1
		return nil }(); if tmp13 != nil { if jrt.Exception_InstanceOf(tmp13) { var ___8 jrt.Exception_I = jrt.Exception_Cast(tmp13); _ = ___8; tmp11 = nil } else { panic(tmp13) } }; return tmp11 } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_a2g_fromfn_box_A_New() *A_arbace_a2g_fromfn_box_A { A_arbace_a2g_fromfn_box_A_Init(); t := &A_arbace_a2g_fromfn_box_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_a2g_fromfn_box_A) Ctor() {}
//line :49:1
func (t *A_arbace_a2g_fromfn_box_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__1)) { var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_50; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_53; return tmp3.Invoke_O_O__O(tmp4, p__0) } else { var tmp5 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp5 = A_arbace_a2g_fromfn_A_const_51; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(d__1)) {
		var tmp6 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp6 = A_arbace_a2g_fromfn_A_const_50; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_a2g_fromfn_A_Init(); tmp8 = A_arbace_a2g_fromfn_A_const_54; return tmp7.Invoke_O_O__O(tmp8, p__0) } else {
//line :50:1
			var tmp9 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_52; if tmp9 != nil { return p__0 } else { return nil
			}
		}
	} }
func A_arbace_a2g_fromfn_result_A_New() *A_arbace_a2g_fromfn_result_A { A_arbace_a2g_fromfn_result_A_Init(); t := &A_arbace_a2g_fromfn_result_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_fromfn_result_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_fromfn_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__1)) {
		var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_50; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_56; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp6 = A_arbace_a2g_fromfn_A_const_57; var tmp7 any = tmp6.Ref(); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_150, nil); var tmp9 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_58; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp11 = A_arbace_a2g_fromfn_A_const_30; return tmp3.Invoke_O_O__O(tmp5.Invoke_O_O_O__O(tmp7, Lit_39, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp10.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(d__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_151, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref()))).Ref()), r__0) } else {
//line :55:1
			if lang.Util_Equiv_O_O__Z(Lit_152, d__1) {

				var tmp12 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp12 = A_arbace_a2g_fromfn_A_const_50; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_a2g_fromfn_A_Init(); tmp14 = A_arbace_a2g_fromfn_A_const_59; return tmp13.Invoke_O_O__O(tmp14, r__0) } else {
//line :55:1
					if lang.Util_Equiv_O_O__Z(Lit_153, d__1) { return r__0 } else { var tmp15 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp15 = A_arbace_a2g_fromfn_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(d__1)) {






						var tmp16 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp16 = A_arbace_a2g_fromfn_A_const_50; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp18 = A_arbace_a2g_fromfn_A_const_50; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_a2g_fromfn_A_Init(); tmp20 = A_arbace_a2g_fromfn_A_const_66; var tmp21 any = tmp20; var tmp22 any; A_arbace_a2g_fromfn_A_Init(); tmp22 = A_arbace_a2g_fromfn_A_const_67; var tmp23 any = tmp22; var tmp24 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp24 = A_arbace_a2g_fromfn_A_const_68; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp26 = A_arbace_a2g_fromfn_A_const_57; var tmp27 any = tmp19.Invoke_O_O_O__O(tmp21, tmp23, tmp25.Invoke_O_O__O(tmp26.Ref(), d__1)); var tmp28 any = A_arbace_a2g_fromfn_result_fn__332000042_A_New_O(d__1); var tmp29 *jrt.Class; A_arbace_a2g_fromfn_result_fn__332000042_A_Init(); tmp29 = A_arbace_a2g_fromfn_result_fn__332000042_A_fn_class; return tmp17.Invoke_O_O_O__O(tmp27, r__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil).Invoke__O()) } else {
//line :55:1
							var tmp30 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp30 = A_arbace_a2g_fromfn_A_const_52; if tmp30 != nil {












								var tmp31 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp31 = A_arbace_a2g_fromfn_A_const_50; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp33 = A_arbace_a2g_fromfn_A_const_56; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp35 = A_arbace_a2g_fromfn_A_const_57; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp37 = A_arbace_a2g_fromfn_A_const_65; return tmp32.Invoke_O_O__O(tmp34.Invoke_O_O_O__O(tmp36, lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(d__1), Lit_154), r__0) } else {
//line :55:1
									return nil
								}
						}
					}
				}
		}
}

func A_arbace_a2g_fromfn_result_fn__332000042_A_New_O(p0 any) *A_arbace_a2g_fromfn_result_fn__332000042_A { A_arbace_a2g_fromfn_result_fn__332000042_A_Init(); t := &A_arbace_a2g_fromfn_result_fn__332000042_A{}; t.Ctor_O(p0); return t }
//line :63:1
func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :63:1
func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__1)) { var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_61; d__1, n__2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(d__1), lang.Numbers_Inc_J__J(n__2); continue L1 } else {
										var tmp3 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_60; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_New(); var tmp6 *jrt.Class; A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_Init(); tmp6 = A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any; var tmp9 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(d__1)) {
											var tmp10 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp10 = A_arbace_a2g_fromfn_A_const_63; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_156, nil); var tmp13 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp13 = A_arbace_a2g_fromfn_A_const_64; tmp8 = tmp11.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(d__1))).Ref()) } else {
												var tmp14 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp14 = A_arbace_a2g_fromfn_A_const_56; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp16 = A_arbace_a2g_fromfn_A_const_57; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp18 = A_arbace_a2g_fromfn_A_const_65; tmp8 = tmp15.Invoke_O_O_O__O(tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(d__1), Lit_157) }
//line :64:1
	return lang.RT_Nth_O_I__O(tmp4.Invoke_O_O__O(tmp7, tmp8), lang.RT_IntCast_J__I(n__2)) } } }; /*line :63:1*/panic("a2g: unreachable") }
func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_New() *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A { A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_Init(); t := &A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) Ctor() {}
//line :64:1
func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) Invoke_O_O__O(self, p1__332000041_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_62; return tmp2.Invoke_O_O__O(tmp3, p1__332000041_SHARP___1) }





func A_arbace_a2g_fromfn_set_form_A_New() *A_arbace_a2g_fromfn_set_form_A { A_arbace_a2g_fromfn_set_form_A_Init(); t := &A_arbace_a2g_fromfn_set_form_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_a2g_fromfn_set_form_A) Ctor() {}
//line :70:1
func (t *A_arbace_a2g_fromfn_set_form_A) Invoke_O_O__O(self, fi__0 any) any { var sam__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_45; sam__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(fi__0); var vec__332000049__3 any; var tmp2 /*line :70:1*/*lang.Var;



	A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_69; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_71; vec__332000049__3 = tmp3.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(sam__2)); var ps__4 any = /*line :70:1*/lang.RT_Nth_O_I_O__O(vec__332000049__3, lang.RT_IntCast_J__I(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O(vec__332000049__3, lang.RT_IntCast_J__I(1), nil); var pn__6 any; var tmp5 *lang.Var;




	A_arbace_a2g_fromfn_A_Init(); tmp5 = A_arbace_a2g_fromfn_A_const_70; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; var iter__1927001039__auto____6 any; var tmp8 any = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_New(); var tmp9 *jrt.Class; A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_Init(); tmp9 = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_fn_class; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp11 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp11 = A_arbace_a2g_fromfn_A_const_72; tmp7 = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__4)).Ref())); pn__6 = tmp6.Invoke_O__O(tmp7); var call__7 any; var tmp12 /*line :70:1*/*lang.Var;





	A_arbace_a2g_fromfn_A_Init(); tmp12 = A_arbace_a2g_fromfn_A_const_50; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_a2g_fromfn_A_Init(); tmp14 = A_arbace_a2g_fromfn_A_const_73; var tmp15 any = tmp14; var tmp16 any; A_arbace_a2g_fromfn_A_Init(); tmp16 = A_arbace_a2g_fromfn_A_const_74; var tmp17 any = tmp16; var tmp18 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp18 = A_arbace_a2g_fromfn_A_const_50; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_a2g_fromfn_A_Init(); tmp20 = A_arbace_a2g_fromfn_A_const_75; var tmp21 any = tmp20; var tmp22 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp22 = A_arbace_a2g_fromfn_A_const_76; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp24 = A_arbace_a2g_fromfn_A_const_50; var tmp25 any = jrt.NN(tmp24).GetRawRoot__O(); var tmp26 any; A_arbace_a2g_fromfn_A_Init(); tmp26 = A_arbace_a2g_fromfn_A_const_77; var tmp27 any = tmp26; var tmp28 any; A_arbace_a2g_fromfn_A_Init(); tmp28 = A_arbace_a2g_fromfn_A_const_78; var tmp29 any = tmp28; var tmp30 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp30 = A_arbace_a2g_fromfn_A_const_79; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp32 = A_arbace_a2g_fromfn_A_const_80; call__7 = tmp13.Invoke_O_O_O__O(tmp15, tmp17, tmp19.Invoke_O_O__O(tmp21, tmp23.Invoke_O_O_O_O__O(tmp25, tmp27, tmp29, tmp31.Invoke_O_O_O__O(jrt.NN(tmp32).GetRawRoot__O(), pn__6, ps__4)))); var fnf__8 any; var tmp33 /*line :70:1*/*lang.Var;






	A_arbace_a2g_fromfn_A_Init(); tmp33 = A_arbace_a2g_fromfn_A_const_50; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_a2g_fromfn_A_Init(); tmp35 = A_arbace_a2g_fromfn_A_const_81; var tmp36 any = tmp35; var tmp37 any; var G__332000062__8_ any; var tmp38 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp38 = A_arbace_a2g_fromfn_A_const_70; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp40 = A_arbace_a2g_fromfn_A_const_79; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 any = A_arbace_a2g_fromfn_set_form_fn__332000063_A_New(); var tmp43 *jrt.Class; A_arbace_a2g_fromfn_set_form_fn__332000063_A_Init(); tmp43 = A_arbace_a2g_fromfn_set_form_fn__332000063_A_fn_class; G__332000062__8_ = tmp39.Invoke_O__O(tmp41.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil), pn__6, ps__4)); var tmp44 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp44 = A_arbace_a2g_fromfn_A_const_82; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O_O__O(Lit_164, r__5)) {
		var tmp45 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp45 = A_arbace_a2g_fromfn_A_const_83; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp47 = A_arbace_a2g_fromfn_A_const_85; var tmp48 any = jrt.NN(tmp47).GetRawRoot__O(); var tmp49 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp49 = A_arbace_a2g_fromfn_A_const_16; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp51 = A_arbace_a2g_fromfn_A_const_68; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp53 = A_arbace_a2g_fromfn_A_const_57; tmp37 = tmp46.Invoke_O_O_O_O__O(G__332000062__8_, tmp48, tmp50, tmp52.Invoke_O_O__O(tmp53.Ref(), r__5)) } else {
//line :77:1
			tmp37 = G__332000062__8_ }; var tmp54 any = tmp37; var tmp55 any; if

	lang.Util_Equiv_O_O__Z(Lit_164, r__5) { tmp55 = call__7 } else { var tmp56 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp56 = A_arbace_a2g_fromfn_A_const_50; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 any; A_arbace_a2g_fromfn_A_Init(); tmp58 = A_arbace_a2g_fromfn_A_const_86; var tmp59 any = tmp58; var tmp60 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp60 = A_arbace_a2g_fromfn_A_const_87; tmp55 = tmp57.Invoke_O_O__O(tmp59, lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O_O__O(call__7, r__5)) }; fnf__8 = /*line :77:1*/tmp34.Invoke_O_O_O__O(tmp36, tmp54, tmp55); var tmp61 /*line :80:1*/*lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp61 = A_arbace_a2g_fromfn_A_const_50; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 any; A_arbace_a2g_fromfn_A_Init(); tmp63 = A_arbace_a2g_fromfn_A_const_88; var tmp64 any = tmp63; var tmp65 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp65 = A_arbace_a2g_fromfn_A_const_50; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 any; A_arbace_a2g_fromfn_A_Init(); tmp67 = A_arbace_a2g_fromfn_A_const_89; var tmp68 any = tmp67; var tmp69 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp69 = A_arbace_a2g_fromfn_A_const_50; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 any; A_arbace_a2g_fromfn_A_Init(); tmp71 = A_arbace_a2g_fromfn_A_const_90; var tmp72 any = tmp71; var tmp73 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp73 = A_arbace_a2g_fromfn_A_const_56; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp75 = A_arbace_a2g_fromfn_A_const_57; var tmp76 any = tmp66.Invoke_O_O__O(tmp68, tmp70.Invoke_O_O__O(tmp72, tmp74.Invoke_O_O_O__O(tmp75.Ref(), fi__0, Lit_157))); var tmp77 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp77 = A_arbace_a2g_fromfn_A_const_50; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 any; A_arbace_a2g_fromfn_A_Init(); tmp79 = A_arbace_a2g_fromfn_A_const_91; var tmp80 any = tmp79; var tmp81 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp81 = A_arbace_a2g_fromfn_A_const_15; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp83 = A_arbace_a2g_fromfn_A_const_84; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 any; A_arbace_a2g_fromfn_A_Init(); tmp85 = A_arbace_a2g_fromfn_A_const_93; var tmp86 any = tmp85; var tmp87 any; A_arbace_a2g_fromfn_A_Init(); tmp87 = A_arbace_a2g_fromfn_A_const_94; var tmp88 any = lang.Tuple_Create_O__IPersistentVector(tmp84.Invoke_O_O__O(tmp86, tmp87)); var tmp89 any; A_arbace_a2g_fromfn_A_Init(); tmp89 = A_arbace_a2g_fromfn_A_const_92; var tmp90 any = tmp82.Invoke_O_O__O(tmp88, tmp89); var tmp91 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp91 = A_arbace_a2g_fromfn_A_const_50; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 any; A_arbace_a2g_fromfn_A_Init(); tmp93 = A_arbace_a2g_fromfn_A_const_95; var tmp94 any = tmp93; var tmp95 any; A_arbace_a2g_fromfn_A_Init(); tmp95 = A_arbace_a2g_fromfn_A_const_96; var tmp96 any = tmp95; var tmp97 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp97 = A_arbace_a2g_fromfn_A_const_50; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 any; A_arbace_a2g_fromfn_A_Init(); tmp99 = A_arbace_a2g_fromfn_A_const_97; var tmp100 any = tmp99; var tmp101 any; A_arbace_a2g_fromfn_A_Init(); tmp101 = A_arbace_a2g_fromfn_A_const_98; var tmp102 any = lang.Tuple_Create_O_O__IPersistentVector(tmp96, tmp98.Invoke_O_O__O(tmp100, tmp101)); var tmp103 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp103 = A_arbace_a2g_fromfn_A_const_50; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 any; A_arbace_a2g_fromfn_A_Init(); tmp105 = A_arbace_a2g_fromfn_A_const_99; var tmp106 any = tmp105; var tmp107 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp107 = A_arbace_a2g_fromfn_A_const_50; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 any; A_arbace_a2g_fromfn_A_Init(); tmp109 = A_arbace_a2g_fromfn_A_const_100; var tmp110 any = tmp109; var tmp111 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp111 = A_arbace_a2g_fromfn_A_const_56; var tmp112 lang.IFn = lang.IFn_Cast(jrt.NN(tmp111).GetRawRoot__O()); var tmp113 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp113 = A_arbace_a2g_fromfn_A_const_57; var tmp114 any = tmp112.Invoke_O_O_O__O(tmp113.Ref(), fi__0, Lit_165); var tmp115 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp115 = A_arbace_a2g_fromfn_A_const_101; return tmp62.Invoke_O_O_O__O(tmp64, tmp76, tmp78.Invoke_O_O_O__O(tmp80, tmp90, tmp92.Invoke_O_O_O__O(tmp94, tmp102, tmp104.Invoke_O_O__O(tmp106, tmp108.Invoke_O_O_O_O__O(tmp110, tmp114, tmp115.Ref(), fnf__8))))) }
//line :75:1
func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_New() *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_Init(); t := &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) Ctor() {}
//line :75:1
func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) Invoke_O_O__O(self, s__332000053__1 any) any { var tmp1 any = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_New_O_O(self, s__332000053__1); var tmp2 *jrt.Class; A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_Init(); tmp2 = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :75:1
func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_New_O_O(p0, p1 any) *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_Init(); t := &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :75:1
func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) Ctor_O_O(c__iter__332000052, c__s__332000053 any) { t.F_iter__332000052 = c__iter__332000052; t.F_s__332000053 = c__s__332000053 }
//line :75:1
func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) Invoke_O__O(self any) any { { var s__332000053__1 any; var t_ any = t.F_s__332000053; t.F_s__332000053 = nil; s__332000053__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_18; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__332000053__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__332000053__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__332000053__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_20; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__332000053__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__332000055__6 any; var tmp4 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_21; b__332000055__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_New_O_I_O(b__332000055__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_Init(); tmp6 = A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp7 = A_arbace_a2g_fromfn_A_const_23; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_26; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__332000055__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__332000052); var tmp12 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp12 = A_arbace_a2g_fromfn_A_const_27; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__332000053__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp13 = A_arbace_a2g_fromfn_A_const_23; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp15 = A_arbace_a2g_fromfn_A_const_26; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__332000055__6), nil) } } else { var i__4 any; var tmp16 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp16 = A_arbace_a2g_fromfn_A_const_24; i__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__332000053__3); var tmp17 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp17 = A_arbace_a2g_fromfn_A_const_25; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp19 = A_arbace_a2g_fromfn_A_const_63; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__332000052); var tmp22 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp22 = A_arbace_a2g_fromfn_A_const_28; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__332000053__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :75:1
func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_Init(); t := &A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) Ctor_O_I_O(c__b__332000055 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__332000055 = c__b__332000055; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) Invoke_O__O(self any) any { { var i__332000054__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__332000054__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__332000054__1)); var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__332000055; var tmp5 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp5 = A_arbace_a2g_fromfn_A_const_63; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__332000054__1 = lang.Numbers_Unchecked_inc_J__J(i__332000054__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_New() *A_arbace_a2g_fromfn_set_form_fn__332000063_A { A_arbace_a2g_fromfn_set_form_fn__332000063_A_Init(); t := &A_arbace_a2g_fromfn_set_form_fn__332000063_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) Ctor() {}
//line :77:1
func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) Invoke_O_O_O__O(self, p1__332000047_SHARP___1, p2__332000048_SHARP___2 any) any { var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_84; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp3 = A_arbace_a2g_fromfn_A_const_68; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_fromfn_A_Init(); tmp5 = A_arbace_a2g_fromfn_A_const_57; return tmp2.Invoke_O_O__O(p1__332000047_SHARP___1, tmp4.Invoke_O_O__O(tmp5.Ref(), p2__332000048_SHARP___2)) }







func A_arbace_a2g_fromfn_forms_A_New() *A_arbace_a2g_fromfn_forms_A { A_arbace_a2g_fromfn_forms_A_Init(); t := &A_arbace_a2g_fromfn_forms_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_a2g_fromfn_forms_A) Ctor() {}
//line :85:1
func (t *A_arbace_a2g_fromfn_forms_A) Invoke_O_O__O(self, fis__0 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp1 = A_arbace_a2g_fromfn_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(fis__0)) { var tmp2 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp2 = A_arbace_a2g_fromfn_A_const_50; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_a2g_fromfn_A_Init(); tmp4 = A_arbace_a2g_fromfn_A_const_104; var tmp5 any = tmp4; var tmp6 any = tmp3.Invoke_O_O__O(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_142, nil, Lit_143), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(fis__0)).Ref(), nil)).Ref()); var tmp7 any; A_arbace_a2g_fromfn_A_Init(); tmp7 = A_arbace_a2g_fromfn_A_const_102; var tmp8 any = tmp7; var tmp9 any; A_arbace_a2g_fromfn_A_Init(); tmp9 = A_arbace_a2g_fromfn_A_const_103; var tmp10 any = tmp9; var tmp11 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp11 = A_arbace_a2g_fromfn_A_const_76; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp13 = A_arbace_a2g_fromfn_A_const_50; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 any; A_arbace_a2g_fromfn_A_Init(); tmp15 = A_arbace_a2g_fromfn_A_const_105; var tmp16 any = tmp15; var tmp17 any; A_arbace_a2g_fromfn_A_Init(); tmp17 = A_arbace_a2g_fromfn_A_const_106; var tmp18 any = tmp17; var tmp19 *lang.PersistentVector; lang.PersistentVector_Init(); tmp19 = lang.PersistentVector_EMPTY; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp21 = A_arbace_a2g_fromfn_A_const_79; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_fromfn_A_Init(); tmp23 = A_arbace_a2g_fromfn_A_const_107; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp10, tmp12.Invoke_O_O_O_O_O__O(tmp14, tmp16, tmp18, tmp20, tmp22.Invoke_O_O__O(jrt.NN(tmp23).GetRawRoot__O(), fis__0))) } else { return nil
	}
}


















































type A_arbace_a2g_fromfn_A struct{ jrt.Object }

var A_arbace_a2g_fromfn_A_const_0 *lang.Var

var A_arbace_a2g_fromfn_A_const_1 *lang.Var

var A_arbace_a2g_fromfn_A_const_2 any

var A_arbace_a2g_fromfn_A_const_3 any

var A_arbace_a2g_fromfn_A_const_4 any

var A_arbace_a2g_fromfn_A_const_5 any

var A_arbace_a2g_fromfn_A_const_6 any

var A_arbace_a2g_fromfn_A_const_7 any

var A_arbace_a2g_fromfn_A_const_8 any

var A_arbace_a2g_fromfn_A_const_9 any

var A_arbace_a2g_fromfn_A_const_10 *lang.Var

var A_arbace_a2g_fromfn_A_const_11 *lang.Var

var A_arbace_a2g_fromfn_A_const_12 *lang.Var

var A_arbace_a2g_fromfn_A_const_13 any

var A_arbace_a2g_fromfn_A_const_14 *lang.Var

var A_arbace_a2g_fromfn_A_const_15 *lang.Var

var A_arbace_a2g_fromfn_A_const_16 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_17 *lang.Var

var A_arbace_a2g_fromfn_A_const_18 *lang.Var

var A_arbace_a2g_fromfn_A_const_19 *lang.Var

var A_arbace_a2g_fromfn_A_const_20 *lang.Var

var A_arbace_a2g_fromfn_A_const_21 *lang.Var

var A_arbace_a2g_fromfn_A_const_22 *lang.Var

var A_arbace_a2g_fromfn_A_const_23 *lang.Var

var A_arbace_a2g_fromfn_A_const_24 *lang.Var

var A_arbace_a2g_fromfn_A_const_25 *lang.Var

var A_arbace_a2g_fromfn_A_const_26 *lang.Var

var A_arbace_a2g_fromfn_A_const_27 *lang.Var

var A_arbace_a2g_fromfn_A_const_28 *lang.Var

var A_arbace_a2g_fromfn_A_const_29 any

var A_arbace_a2g_fromfn_A_const_30 *lang.Var

var A_arbace_a2g_fromfn_A_const_31 *lang.Var

var A_arbace_a2g_fromfn_A_const_32 *lang.Var

var A_arbace_a2g_fromfn_A_const_33 *lang.Var

var A_arbace_a2g_fromfn_A_const_34 *lang.Var

var A_arbace_a2g_fromfn_A_const_35 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_36 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_37 *lang.Var

var A_arbace_a2g_fromfn_A_const_38 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_39 *lang.Var

var A_arbace_a2g_fromfn_A_const_40 *lang.Var

var A_arbace_a2g_fromfn_A_const_41 *lang.Var

var A_arbace_a2g_fromfn_A_const_42 *lang.Var

var A_arbace_a2g_fromfn_A_const_43 *lang.Var

var A_arbace_a2g_fromfn_A_const_44 *lang.Var

var A_arbace_a2g_fromfn_A_const_45 *lang.Var

var A_arbace_a2g_fromfn_A_const_46 *lang.Var

var A_arbace_a2g_fromfn_A_const_47 *lang.Var

var A_arbace_a2g_fromfn_A_const_48 *lang.Var

var A_arbace_a2g_fromfn_A_const_49 *lang.Var

var A_arbace_a2g_fromfn_A_const_50 *lang.Var

var A_arbace_a2g_fromfn_A_const_51 *lang.Var

var A_arbace_a2g_fromfn_A_const_52 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_53 any

var A_arbace_a2g_fromfn_A_const_54 any

var A_arbace_a2g_fromfn_A_const_55 *lang.Var

var A_arbace_a2g_fromfn_A_const_56 *lang.Var

var A_arbace_a2g_fromfn_A_const_57 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_58 *lang.Var

var A_arbace_a2g_fromfn_A_const_59 any

var A_arbace_a2g_fromfn_A_const_60 *lang.Var

var A_arbace_a2g_fromfn_A_const_61 *lang.Var

var A_arbace_a2g_fromfn_A_const_62 any

var A_arbace_a2g_fromfn_A_const_63 *lang.Var

var A_arbace_a2g_fromfn_A_const_64 *lang.Var

var A_arbace_a2g_fromfn_A_const_65 *lang.Var

var A_arbace_a2g_fromfn_A_const_66 any

var A_arbace_a2g_fromfn_A_const_67 any

var A_arbace_a2g_fromfn_A_const_68 *lang.Var

var A_arbace_a2g_fromfn_A_const_69 *lang.Var

var A_arbace_a2g_fromfn_A_const_70 *lang.Var

var A_arbace_a2g_fromfn_A_const_71 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_72 *lang.Var

var A_arbace_a2g_fromfn_A_const_73 any

var A_arbace_a2g_fromfn_A_const_74 any

var A_arbace_a2g_fromfn_A_const_75 any

var A_arbace_a2g_fromfn_A_const_76 *lang.Var

var A_arbace_a2g_fromfn_A_const_77 any

var A_arbace_a2g_fromfn_A_const_78 any

var A_arbace_a2g_fromfn_A_const_79 *lang.Var

var A_arbace_a2g_fromfn_A_const_80 *lang.Var

var A_arbace_a2g_fromfn_A_const_81 any

var A_arbace_a2g_fromfn_A_const_82 *lang.Var

var A_arbace_a2g_fromfn_A_const_83 *lang.Var

var A_arbace_a2g_fromfn_A_const_84 *lang.Var

var A_arbace_a2g_fromfn_A_const_85 *lang.Var

var A_arbace_a2g_fromfn_A_const_86 any

var A_arbace_a2g_fromfn_A_const_87 *lang.Var

var A_arbace_a2g_fromfn_A_const_88 any

var A_arbace_a2g_fromfn_A_const_89 any

var A_arbace_a2g_fromfn_A_const_90 any

var A_arbace_a2g_fromfn_A_const_91 any

var A_arbace_a2g_fromfn_A_const_92 any

var A_arbace_a2g_fromfn_A_const_93 any

var A_arbace_a2g_fromfn_A_const_94 any

var A_arbace_a2g_fromfn_A_const_95 any

var A_arbace_a2g_fromfn_A_const_96 any

var A_arbace_a2g_fromfn_A_const_97 any

var A_arbace_a2g_fromfn_A_const_98 any

var A_arbace_a2g_fromfn_A_const_99 any

var A_arbace_a2g_fromfn_A_const_100 any

var A_arbace_a2g_fromfn_A_const_101 *lang.Keyword

var A_arbace_a2g_fromfn_A_const_102 any

var A_arbace_a2g_fromfn_A_const_103 any

var A_arbace_a2g_fromfn_A_const_104 any

var A_arbace_a2g_fromfn_A_const_105 any

var A_arbace_a2g_fromfn_A_const_106 any

var A_arbace_a2g_fromfn_A_const_107 *lang.Var

var A_arbace_a2g_fromfn_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_A_Init() { if !A_arbace_a2g_fromfn_A_init.Done() { A_arbace_a2g_fromfn_A_init.Run(A_arbace_a2g_fromfn_A_clinit) } }

func A_arbace_a2g_fromfn_A_clinit() { A_arbace_a2g_fromfn_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_fromfn_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_fromfn_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_fromfn_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_fromfn_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_fromfn_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_fromfn_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_fromfn_A_const_7 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_a2g_fromfn_A_const_8 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref()); A_arbace_a2g_fromfn_A_const_9 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref()); A_arbace_a2g_fromfn_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_a2g_fromfn_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_a2g_fromfn_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_fromfn_A_const_13 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_21)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), Lit_23))); A_arbace_a2g_fromfn_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_a2g_fromfn_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_a2g_fromfn_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_a2g_fromfn_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_a2g_fromfn_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_fromfn_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_a2g_fromfn_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_fromfn_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_a2g_fromfn_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_fromfn_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_a2g_fromfn_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_fromfn_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_a2g_fromfn_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_a2g_fromfn_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_a2g_fromfn_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_a2g_fromfn_A_const_29 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(Lit_39, Lit_28, Lit_40)); A_arbace_a2g_fromfn_A_const_30 = lang.RT_Var_String_String__Var(Lit_21, Lit_41); A_arbace_a2g_fromfn_A_const_31 = lang.RT_Var_String_String__Var(Lit_8, Lit_42); A_arbace_a2g_fromfn_A_const_32 = lang.RT_Var_String_String__Var(Lit_8, Lit_43); A_arbace_a2g_fromfn_A_const_33 = lang.RT_Var_String_String__Var(Lit_10, Lit_44); A_arbace_a2g_fromfn_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_a2g_fromfn_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_a2g_fromfn_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_a2g_fromfn_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_a2g_fromfn_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_a2g_fromfn_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_a2g_fromfn_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_a2g_fromfn_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_a2g_fromfn_A_const_42 = lang.RT_Var_String_String__Var(Lit_8, Lit_53); A_arbace_a2g_fromfn_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_a2g_fromfn_A_const_44 = lang.RT_Var_String_String__Var(Lit_21, Lit_55); A_arbace_a2g_fromfn_A_const_45 = lang.RT_Var_String_String__Var(Lit_10, Lit_56); A_arbace_a2g_fromfn_A_const_46 = lang.RT_Var_String_String__Var(Lit_12, Lit_57); A_arbace_a2g_fromfn_A_const_47 = lang.RT_Var_String_String__Var(Lit_14, Lit_58); A_arbace_a2g_fromfn_A_const_48 = lang.RT_Var_String_String__Var(Lit_12, Lit_59); A_arbace_a2g_fromfn_A_const_49 = lang.RT_Var_String_String__Var(Lit_6, Lit_60); A_arbace_a2g_fromfn_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_a2g_fromfn_A_const_51 = lang.RT_Var_String_String__Var(Lit_12, Lit_62); A_arbace_a2g_fromfn_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_a2g_fromfn_A_const_53 = lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_65).Ref(); A_arbace_a2g_fromfn_A_const_54 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref(); A_arbace_a2g_fromfn_A_const_55 = lang.RT_Var_String_String__Var(Lit_6, Lit_67); A_arbace_a2g_fromfn_A_const_56 = lang.RT_Var_String_String__Var(Lit_12, Lit_68); A_arbace_a2g_fromfn_A_const_57 = lang.RT_Keyword_String_String__Keyword(nil, Lit_69); A_arbace_a2g_fromfn_A_const_58 = lang.RT_Var_String_String__Var(Lit_14, Lit_70); A_arbace_a2g_fromfn_A_const_59 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(); A_arbace_a2g_fromfn_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_a2g_fromfn_A_const_61 = lang.RT_Var_String_String__Var(Lit_6, Lit_73); A_arbace_a2g_fromfn_A_const_62 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(); A_arbace_a2g_fromfn_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_a2g_fromfn_A_const_64 = lang.RT_Var_String_String__Var(Lit_6, Lit_76); A_arbace_a2g_fromfn_A_const_65 = lang.RT_Var_String_String__Var(Lit_6, Lit_77); A_arbace_a2g_fromfn_A_const_66 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref(); A_arbace_a2g_fromfn_A_const_67 = lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_79).Ref(); A_arbace_a2g_fromfn_A_const_68 = lang.RT_Var_String_String__Var(Lit_12, Lit_80); A_arbace_a2g_fromfn_A_const_69 = lang.RT_Var_String_String__Var(Lit_6, Lit_81); A_arbace_a2g_fromfn_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_a2g_fromfn_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_83); A_arbace_a2g_fromfn_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_a2g_fromfn_A_const_73 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(); A_arbace_a2g_fromfn_A_const_74 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref(); A_arbace_a2g_fromfn_A_const_75 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(); A_arbace_a2g_fromfn_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_a2g_fromfn_A_const_77 = lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_89).Ref(); A_arbace_a2g_fromfn_A_const_78 = lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_90).Ref(); A_arbace_a2g_fromfn_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_a2g_fromfn_A_const_80 = lang.RT_Var_String_String__Var(Lit_21, Lit_92); A_arbace_a2g_fromfn_A_const_81 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(); A_arbace_a2g_fromfn_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_a2g_fromfn_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_a2g_fromfn_A_const_84 = lang.RT_Var_String_String__Var(Lit_21, Lit_26); A_arbace_a2g_fromfn_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_a2g_fromfn_A_const_86 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref(); A_arbace_a2g_fromfn_A_const_87 = lang.RT_Var_String_String__Var(Lit_21, Lit_98); A_arbace_a2g_fromfn_A_const_88 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(); A_arbace_a2g_fromfn_A_const_89 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref(); A_arbace_a2g_fromfn_A_const_90 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_a2g_fromfn_A_const_91 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(); A_arbace_a2g_fromfn_A_const_92 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref())); A_arbace_a2g_fromfn_A_const_93 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(); A_arbace_a2g_fromfn_A_const_94 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(); A_arbace_a2g_fromfn_A_const_95 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_104).Ref(); A_arbace_a2g_fromfn_A_const_96 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref(); A_arbace_a2g_fromfn_A_const_97 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref(); A_arbace_a2g_fromfn_A_const_98 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(); A_arbace_a2g_fromfn_A_const_99 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(); A_arbace_a2g_fromfn_A_const_100 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(); A_arbace_a2g_fromfn_A_const_101 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_a2g_fromfn_A_const_102 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_109, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_111).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref()), lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_113)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(90).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(56).Ref())))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_117).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_118).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_113).Ref(), nil)))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref(), nil)))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(9).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_113).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(90).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(7).Ref()))); A_arbace_a2g_fromfn_A_const_103 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_109, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(), lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_119)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_104).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_122).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(94).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_124).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(94).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref())))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_117).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_54).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_117).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_118).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref(), nil)))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_127).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_128).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_129).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_64, Lit_125).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_122).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(98).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(94).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(9).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_115).Ref(), jrt.Integer_ValueOf_I__Integer(93).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_116).Ref(), jrt.Integer_ValueOf_I__Integer(7).Ref()))); A_arbace_a2g_fromfn_A_const_104 = lang.Symbol_Intern_String_String__Symbol(Lit_131, Lit_132).Ref(); A_arbace_a2g_fromfn_A_const_105 = lang.Symbol_Intern_String_String__Symbol(Lit_109, Lit_110).Ref(); A_arbace_a2g_fromfn_A_const_106 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref(); A_arbace_a2g_fromfn_A_const_107 = lang.RT_Var_String_String__Var(Lit_21, Lit_134) }

func A_arbace_a2g_fromfn_A_New() *A_arbace_a2g_fromfn_A { A_arbace_a2g_fromfn_A_Init(); t := &A_arbace_a2g_fromfn_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_fromfn_A) Ctor() {}

func (t *A_arbace_a2g_fromfn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_A_class }

func (t *A_arbace_a2g_fromfn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_A); return ok }

func A_arbace_a2g_fromfn_A_Cast(x any) *A_arbace_a2g_fromfn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_A_class)) }; return v }



type A_arbace_a2g_fromfn_box_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_box_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_fromfn_box_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_box_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_box_A_Init() { if !A_arbace_a2g_fromfn_box_A_init.Done() { A_arbace_a2g_fromfn_box_A_init.Run(A_arbace_a2g_fromfn_box_A_clinit) } }

func A_arbace_a2g_fromfn_box_A_clinit() { A_arbace_a2g_fromfn_box_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_box_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_box_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_box_A_class }

func (t *A_arbace_a2g_fromfn_box_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_box_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_box_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_box_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_box_A); return ok }

func A_arbace_a2g_fromfn_box_A_Cast(x any) *A_arbace_a2g_fromfn_box_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_box_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_box_A_class)) }; return v }



type A_arbace_a2g_fromfn_eval332000004_A struct{ jrt.Object }

func A_arbace_a2g_fromfn_eval332000004_A_New() *A_arbace_a2g_fromfn_eval332000004_A { t := &A_arbace_a2g_fromfn_eval332000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_fromfn_eval332000004_A) Ctor() {}

func (t *A_arbace_a2g_fromfn_eval332000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_eval332000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_eval332000004_A_class }

func (t *A_arbace_a2g_fromfn_eval332000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_eval332000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_eval332000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_eval332000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_eval332000004_A); return ok }

func A_arbace_a2g_fromfn_eval332000004_A_Cast(x any) *A_arbace_a2g_fromfn_eval332000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_eval332000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_eval332000004_A_class)) }; return v }



type A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_Init() { if !A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_init.Done() { A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_init.Run(A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_clinit) } }

func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_clinit() { A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_class }

func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A); return ok }

func A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_Cast(x any) *A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_eval332000004_loading__1927001464__auto____332000005_A_class)) }; return v }



type A_arbace_a2g_fromfn_eval332000008_A struct{ jrt.Object }

func A_arbace_a2g_fromfn_eval332000008_A_New() *A_arbace_a2g_fromfn_eval332000008_A { t := &A_arbace_a2g_fromfn_eval332000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_fromfn_eval332000008_A) Ctor() {}

func (t *A_arbace_a2g_fromfn_eval332000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_eval332000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_eval332000008_A_class }

func (t *A_arbace_a2g_fromfn_eval332000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_eval332000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_eval332000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_eval332000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_eval332000008_A); return ok }

func A_arbace_a2g_fromfn_eval332000008_A_Cast(x any) *A_arbace_a2g_fromfn_eval332000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_eval332000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_eval332000008_A_class)) }; return v }



type A_arbace_a2g_fromfn_eval332000008_fn__332000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_Init() { if !A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_init.Done() { A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_init.Run(A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_clinit) } }

func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_clinit() { A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_class }

func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_eval332000008_fn__332000009_A); return ok }

func A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_Cast(x any) *A_arbace_a2g_fromfn_eval332000008_fn__332000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_eval332000008_fn__332000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_eval332000008_fn__332000009_A_class)) }; return v }



type A_arbace_a2g_fromfn_fis_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_fis_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_fis_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_fis_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_fis_A_Init() { if !A_arbace_a2g_fromfn_fis_A_init.Done() { A_arbace_a2g_fromfn_fis_A_init.Run(A_arbace_a2g_fromfn_fis_A_clinit) } }

func A_arbace_a2g_fromfn_fis_A_clinit() { A_arbace_a2g_fromfn_fis_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_fis_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_fis_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_fis_A_class }

func (t *A_arbace_a2g_fromfn_fis_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_fis_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_fis_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_fis_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_fis_A); return ok }

func A_arbace_a2g_fromfn_fis_A_Cast(x any) *A_arbace_a2g_fromfn_fis_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_fis_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_fis_A_class)) }; return v }



type A_arbace_a2g_fromfn_fis_fn__332000037_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_fis_fn__332000037_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_fis_fn__332000037_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_fis_fn__332000037_A_Init() { if !A_arbace_a2g_fromfn_fis_fn__332000037_A_init.Done() { A_arbace_a2g_fromfn_fis_fn__332000037_A_init.Run(A_arbace_a2g_fromfn_fis_fn__332000037_A_clinit) } }

func A_arbace_a2g_fromfn_fis_fn__332000037_A_clinit() { A_arbace_a2g_fromfn_fis_fn__332000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_fis_fn__332000037_A_class }

func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_fis_fn__332000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_fis_fn__332000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_fis_fn__332000037_A); return ok }

func A_arbace_a2g_fromfn_fis_fn__332000037_A_Cast(x any) *A_arbace_a2g_fromfn_fis_fn__332000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_fis_fn__332000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_fis_fn__332000037_A_class)) }; return v }



type A_arbace_a2g_fromfn_forms_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_forms_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_forms_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_forms_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_forms_A_Init() { if !A_arbace_a2g_fromfn_forms_A_init.Done() { A_arbace_a2g_fromfn_forms_A_init.Run(A_arbace_a2g_fromfn_forms_A_clinit) } }

func A_arbace_a2g_fromfn_forms_A_clinit() { A_arbace_a2g_fromfn_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_forms_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_forms_A_class }

func (t *A_arbace_a2g_fromfn_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_forms_A); return ok }

func A_arbace_a2g_fromfn_forms_A_Cast(x any) *A_arbace_a2g_fromfn_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_forms_A_class)) }; return v }



type A_arbace_a2g_fromfn_functional_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_functional_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_functional_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_functional_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_fromfn_functional_QMARK__A_Init() { if !A_arbace_a2g_fromfn_functional_QMARK__A_init.Done() { A_arbace_a2g_fromfn_functional_QMARK__A_init.Run(A_arbace_a2g_fromfn_functional_QMARK__A_clinit) } }

func A_arbace_a2g_fromfn_functional_QMARK__A_clinit() { A_arbace_a2g_fromfn_functional_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_functional_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_functional_QMARK__A_class }

func (t *A_arbace_a2g_fromfn_functional_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_functional_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_functional_QMARK__A); return ok }

func A_arbace_a2g_fromfn_functional_QMARK__A_Cast(x any) *A_arbace_a2g_fromfn_functional_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_functional_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_functional_QMARK__A_class)) }; return v }



type A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_Init() { if !A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_init.Done() { A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_init.Run(A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_clinit) } }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_clinit() { A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_class }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A); return ok }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_Cast(x any) *A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_functional_QMARK__fn__332000031_A_class)) }; return v }



type A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_Init() { if !A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_init.Done() { A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_init.Run(A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_clinit) } }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_clinit() { A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_class }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A); return ok }

func A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_Cast(x any) *A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_functional_QMARK__fn__332000033_A_class)) }; return v }



type A_arbace_a2g_fromfn_result_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_result_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_fromfn_result_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_result_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_result_A_Init() { if !A_arbace_a2g_fromfn_result_A_init.Done() { A_arbace_a2g_fromfn_result_A_init.Run(A_arbace_a2g_fromfn_result_A_clinit) } }

func A_arbace_a2g_fromfn_result_A_clinit() { A_arbace_a2g_fromfn_result_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_result_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_result_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_result_A_class }

func (t *A_arbace_a2g_fromfn_result_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_result_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_result_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_result_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_result_A); return ok }

func A_arbace_a2g_fromfn_result_A_Cast(x any) *A_arbace_a2g_fromfn_result_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_result_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_result_A_class)) }; return v }



type A_arbace_a2g_fromfn_result_fn__332000042_A struct{ jrt.Object; F_d any }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_result_fn__332000042_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_result_fn__332000042_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_result_fn__332000042_A_Init() { if !A_arbace_a2g_fromfn_result_fn__332000042_A_init.Done() { A_arbace_a2g_fromfn_result_fn__332000042_A_init.Run(A_arbace_a2g_fromfn_result_fn__332000042_A_clinit) } }

func A_arbace_a2g_fromfn_result_fn__332000042_A_clinit() { A_arbace_a2g_fromfn_result_fn__332000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_result_fn__332000042_A_class }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_result_fn__332000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_result_fn__332000042_A); return ok }

func A_arbace_a2g_fromfn_result_fn__332000042_A_Cast(x any) *A_arbace_a2g_fromfn_result_fn__332000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_result_fn__332000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_result_fn__332000042_A_class)) }; return v }



type A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_Init() { if !A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_init.Done() { A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_init.Run(A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_clinit) } }

func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_clinit() { A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_class }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A); return ok }

func A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_Cast(x any) *A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_result_fn__332000042_fn__332000043_A_class)) }; return v }



type A_arbace_a2g_fromfn_roots_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_roots_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_roots_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_roots_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_roots_A_Init() { if !A_arbace_a2g_fromfn_roots_A_init.Done() { A_arbace_a2g_fromfn_roots_A_init.Run(A_arbace_a2g_fromfn_roots_A_clinit) } }

func A_arbace_a2g_fromfn_roots_A_clinit() { A_arbace_a2g_fromfn_roots_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_159, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_roots_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_roots_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_roots_A_class }

func (t *A_arbace_a2g_fromfn_roots_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_roots_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_roots_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_roots_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_roots_A); return ok }

func A_arbace_a2g_fromfn_roots_A_Cast(x any) *A_arbace_a2g_fromfn_roots_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_roots_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_roots_A_class)) }; return v }



type A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_Init() { if !A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_init.Done() { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_init.Run(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_clinit) } }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_clinit() { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A); return ok }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_Cast(x any) *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_roots_iter__332000013__332000017_A_class)) }; return v }



type A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A struct{ jrt.Object; F_s__332000014, F_iter__332000013 any }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_Init() { if !A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_init.Done() { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_init.Run(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_clinit) } }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_clinit() { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A); return ok }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_Cast(x any) *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_A_class)) }; return v }



type A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A struct{ jrt.Object; F_b__332000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_Init() { if !A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_init.Done() { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_init.Run(A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_clinit) } }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_clinit() { A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_class }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A); return ok }

func A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_Cast(x any) *A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_roots_iter__332000013__332000017_fn__332000018_fn__332000019_A_class)) }; return v }



type A_arbace_a2g_fromfn_set_form_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_set_form_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_set_form_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_set_form_A_Init() { if !A_arbace_a2g_fromfn_set_form_A_init.Done() { A_arbace_a2g_fromfn_set_form_A_init.Run(A_arbace_a2g_fromfn_set_form_A_clinit) } }

func A_arbace_a2g_fromfn_set_form_A_clinit() { A_arbace_a2g_fromfn_set_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_set_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_set_form_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_set_form_A_class }

func (t *A_arbace_a2g_fromfn_set_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_set_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_set_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_set_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_set_form_A); return ok }

func A_arbace_a2g_fromfn_set_form_A_Cast(x any) *A_arbace_a2g_fromfn_set_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_set_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_set_form_A_class)) }; return v }



type A_arbace_a2g_fromfn_set_form_fn__332000063_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_fromfn_set_form_fn__332000063_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_fn__332000063_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_Init() { if !A_arbace_a2g_fromfn_set_form_fn__332000063_A_init.Done() { A_arbace_a2g_fromfn_set_form_fn__332000063_A_init.Run(A_arbace_a2g_fromfn_set_form_fn__332000063_A_clinit) } }

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_clinit() { A_arbace_a2g_fromfn_set_form_fn__332000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_set_form_fn__332000063_A_class }

func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_set_form_fn__332000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_set_form_fn__332000063_A); return ok }

func A_arbace_a2g_fromfn_set_form_fn__332000063_A_Cast(x any) *A_arbace_a2g_fromfn_set_form_fn__332000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_set_form_fn__332000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_set_form_fn__332000063_A_class)) }; return v }



type A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_Init() { if !A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_init.Done() { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_init.Run(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_clinit) } }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_clinit() { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A); return ok }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_Cast(x any) *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_A_class)) }; return v }



type A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A struct{ jrt.Object; F_iter__332000052, F_s__332000053 any }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_Init() { if !A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_init.Done() { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_init.Run(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_clinit) } }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_clinit() { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A); return ok }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_Cast(x any) *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_A_class)) }; return v }



type A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A struct{ jrt.Object; F_b__332000055 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_Init() { if !A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_init.Done() { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_init.Run(A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_clinit) } }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_clinit() { A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_class }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A); return ok }

func A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_Cast(x any) *A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_set_form_iter__332000052__332000056_fn__332000057_fn__332000058_A_class)) }; return v }



type A_arbace_a2g_fromfn_tag_A struct{ jrt.Object }

func (t *A_arbace_a2g_fromfn_tag_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_fromfn_tag_A_fn_class *jrt.Class

var A_arbace_a2g_fromfn_tag_A_init jrt.ClassInit

func A_arbace_a2g_fromfn_tag_A_Init() { if !A_arbace_a2g_fromfn_tag_A_init.Done() { A_arbace_a2g_fromfn_tag_A_init.Run(A_arbace_a2g_fromfn_tag_A_clinit) } }

func A_arbace_a2g_fromfn_tag_A_clinit() { A_arbace_a2g_fromfn_tag_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_fromfn_tag_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_fromfn_tag_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_fromfn_tag_A_class }

func (t *A_arbace_a2g_fromfn_tag_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_fromfn_tag_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_fromfn_tag_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_fromfn_tag_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_fromfn_tag_A); return ok }

func A_arbace_a2g_fromfn_tag_A_Cast(x any) *A_arbace_a2g_fromfn_tag_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_fromfn_tag_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_fromfn_tag_A_class)) }; return v }
