//line j2g_strings.ae:1
package aot_arbace_j2g_decls

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn14,arbace.j2g.jrtyn3,jrtyn15,arbace.j2g.codeyn1,cyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn3,tagkn3,pkgkn5,classkn5,fn-idkn7,targetskn9,try-framekn8,capturedkn5,nameskn5,takenkn4,usedkn7,counterkn10,label-usedyn5,panicyn3,letyn2,doyn6,returnyn2,ifkn4,namekn6,fieldskn5,statekn8,captureskn3,symkn2,idkn4,anonkn5,localkn5,outerkn15,outer-instance?kn7,nestingkn4,linekn6,memberks3,j2g4,linekn1,tkn4,thiskn6,statickn3,retkn6,paramskn4,bodykn5,flagsyn5,deferkn10,method-retkn11,method-namekn4,synckn9,method-fnkn4,desckn7,methodskn6,bodieskn5,superys6,atomic5,Int32ys6,atomic6,Uint64ys6,atomic6,Uint32ys6,atomic5,Int64ys6,atomic4,Boolys6,atomic7,Pointerkn4,typekn3,jrtkn4,elseyn4,thiskn4,kindkn4,ctorkn11,outer-paramkn11,super-outerkn17,super-outer-paramkn4,enumkn9,enum-bodykn11,enum-paramskn4,argskn10,cap-paramskn1,xkn9,enum-argskn9,anon-argskn20,super-outer-is-outerkn16,super-outer-pathkn2,opkn1,bkn13,outer-bindingkn7,derivedkn11,calls-superkn6,recordkn7,compactkn16,record-canonicalkn10,componentsyn4,set!kn11,nested-callyn4,instkn8,prologuekn4,callkn4,initkn9,ctor-callyn1,*ys2,go6,methodys2,go4,funcyn4,addryn3,litkn12,ctor-call-fnkn7,missingyn4,convyn5,int32yn7,bit-xoryn5,int64yn2,>>yn6,uint64yn1,+yn4,whenyn2,==yn3,anyyn2,oryn2,!=yn5,otheryn6,assertyn3,andkn6,bridgekn9,bridge-ofkn4,exprks15,arbace.j2g.code2,gokn7,specialkn5,ownerkn11,enum-valueskn20,record-object-methodkn15,record-accessorkn9,componentyn5,.Copykn12,enum-$valueskn12,enum-valueOfkn9,constantskn9,var-derefkn10,set-statickn10,get-statickn10,var-invokekn8,declarerkn5,fieldkn5,funcskn15,analysis-failedks15,arbace.j2g.code4,failkn7,defaultkn8,jrt-implkn6,objectyn3,Refyn15,GetClass__Classyn16,ToString__Stringyn8,Clone__Oyn12,CloneShallowys11,arbace.core5,derefyn12,.ClearHeaderkn8,promotedys2,go5,constkn3,valys2,go3,varyn7,recoveryn4,gotoyn8,continueyn11,fallthroughyn5,breakyn5,labelkn3,stskn1,wkn5,constkn3,varkn6,invokekn3,itfkn6,targetkn4,readkn4,castkn2,nskn4,textkn6,clinitkn10,clj-constsyn3,notyn5,.Doneyn4,.Runyn2,okyn1,xyn6,valuesyn1,dyn3,dynyn14,.DynImplementsyn4,boolyn1,_yn1,vys3,j2g7,commentys2,go4,typeyn9,interfaceyn6,structyn10,j2g_headerv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,v11,arbace.core5,referR19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.declsm2,R20,s410,j2g's declarations (J2G-SPEC §4.5, §5, §6, §7.11-§7.13): what a translated class becomes in\n  Go forms: its struct or interface, class interface C_I and accessor Self_C (non-leaf\n  classes), markers, method implementations, dispatch methods and forwarders, constructors,\n  statics and lazy class initialization, the Object protocol, instanceof and cast, and its\n  registration with member tables (j2g_classes).v11,arbace.core9,with-metaR21,v16,arbace.j2g.model4,has?v16,arbace.j2g.model7,go-typev11,arbace.core3,vecv11,arbace.core3,mapv16,arbace.j2g.decls3,tagv16,arbace.j2g.decls2,gtv16,arbace.j2g.decls11,result-metav11,arbace.core9,vary-metav11,arbace.core5,assocv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core5,mergeR22,R23,R24,v11,arbace.core6,gensymR25,R26,R27,R28,v11,arbace.core4,atomR29,v11,arbace.core4,intov16,arbace.j2g.names15,reserved-localsR30,R31,R32,v11,arbace.core4,seq?R33,R34,v16,arbace.j2g.decls12,terminating?v11,arbace.core4,lastR35,R36,R37,v11,arbace.core3,notv11,arbace.core6,concatv11,arbace.core4,listR33,R33,v16,arbace.j2g.model7,jrt-symv16,arbace.j2g.model3,pkgv13,arbace.string7,replacev22,arbace.classes.analyze4,declv11,arbace.core3,setR38,R39,R40,R41,R42,v11,arbace.core9,contains?R43,S2,R44,R45,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core6,symbolv16,arbace.j2g.names10,field-namev16,arbace.j2g.decls18,capture-field-namev11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restR46,R47,v16,arbace.j2g.model9,in-world?v15,arbace.j2g.code11,outer-fieldS2,R44,R45,v16,arbace.j2g.model5,leaf?v16,arbace.j2g.model7,go-nameR48,R49,R50,v16,arbace.j2g.decls11,member-lineR51,R52,R53,R54,R55,v15,arbace.j2g.code3,*f*v15,arbace.j2g.code11,binding-symR56,v15,arbace.j2g.code10,with-blockv15,arbace.j2g.code5,stmt!R57,v15,arbace.j2g.code4,ret!v16,arbace.j2g.decls4,has?R58,i32,v15,arbace.j2g.code4,csymv15,arbace.j2g.code5,emit!R59,v15,arbace.j2g.code4,jsymv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv16,arbace.j2g.decls12,new-fn-stateR60,v16,arbace.j2g.decls15,captured-fieldsR61,R62,v15,arbace.j2g.code6,*line*R63,v16,arbace.j2g.decls17,ensure-terminatedv11,arbace.core4,not=v16,arbace.j2g.model14,desc-in-world?R64,v16,arbace.j2g.model15,mdesc-in-world?v22,arbace.classes.analyze14,ctor-real-descR65,R66,v16,arbace.j2g.decls9,*reached*R67,v16,arbace.j2g.model9,class-symv15,arbace.j2g.code15,volatile-field?R68,R69,R70,v16,arbace.j2g.model13,pointer-desc?R68,R71,R72,R73,v11,arbace.core6,secondv22,arbace.classes.analyze10,this0-nameS2,R44,R45,R74,v20,arbace.classes.types17,parse-method-descv16,arbace.j2g.names11,method-basev16,arbace.j2g.decls8,with-retv11,arbace.core11,map-indexedv11,arbace.core6,filterv16,arbace.j2g.model10,interface?v16,arbace.j2g.model14,all-supertypesv13,arbace.string12,starts-with?v11,arbace.core4,subsl3,v14,arbace.j2g.jrt14,struct-methodsR75,v16,arbace.j2g.model3,*w*v16,arbace.j2g.model11,translated?v16,arbace.j2g.decls17,interface-closureR76,v16,arbace.j2g.decls10,hw-markersv11,arbace.core6,removeR4,R77,R78,v11,arbace.core4,somev16,arbace.j2g.model19,method-desc-classesR79,v15,arbace.j2g.code12,missing-exprv16,arbace.j2g.decls9,ctor-descv16,arbace.j2g.names9,ctor-baseR80,R81,R82,R83,R84,R85,v15,arbace.j2g.code8,operandsR86,S2,R44,R45,R87,v11,arbace.core5,applyR4,V1,R77,R88,R4,R77,R89,R90,R91,R92,v11,arbace.core6,reducev15,arbace.j2g.code8,use-sym!S2,R44,R45,v15,arbace.j2g.code9,local-valR93,R45,R94,S2,R44,R45,R4,v16,arbace.j2g.decls7,body-ofv16,arbace.j2g.decls8,reached?v15,arbace.j2g.code9,fresh-rawR95,v11,arbace.core5,swap!v11,arbace.core6,empty?v11,arbace.core5,rangeS2,R44,R45,v16,arbace.j2g.names10,munge-namev11,arbace.core6,zipmapR96,v16,arbace.j2g.decls9,stub-bodyR97,R98,R99,R100,v11,arbace.core6,vectorR101,R102,R4,R103,R102,R4,R104,R105,R106,v16,arbace.j2g.decls20,ctor-call-translatorR107,R108,m2,R64,s3,()VR4,R102,R4,R4,R109,v11,arbace.core5,list*R110,R77,v16,arbace.j2g.decls10,param-listi1024,R111,v16,arbace.j2g.names8,new-nameR109,v16,arbace.j2g.model13,trivial-init?v16,arbace.j2g.model8,nest-topv16,arbace.j2g.decls11,code-class?R34,R4,V1,R4,v11,arbace.core3,strR4,R4,R112,R113,v16,arbace.j2g.decls7,at-linev11,arbace.core4,nil?R4,R4,R77,R114,R4,R115,R116,R117,R116,R117,R118,R116,R119,R120,l32,R116,R121,R116,R117,R118,R116,R119,R120,R116,R121,v15,arbace.j2g.code6,coerceR116,R117,p4,.*\\$v15,arbace.j2g.code10,string-litR4,R36,R122,R109,l31,R4,R116,R117,l0,R36,R123,R124,R116,R125,R4,R36,R123,R126,R124,R127,R36,R36,R34,R128,R129,R109,R36,v11,arbace.core5,true?R4,R128,R124,R124,R124,R130,R4,R77,R131,R132,v20,arbace.classes.types4,ref?v18,arbace.classes.env11,assignable?v15,arbace.j2g.code8,cast-valR133,R134,R135,v16,arbace.j2g.model13,hand-written?R136,v16,arbace.j2g.names9,impl-nameR4,R4,R137,R138,v16,arbace.j2g.decls18,record-object-bodyR139,R140,R36,R36,R141,R142,R36,R4,R143,R36,v16,arbace.j2g.names17,static-field-nameR144,R36,R33,v11,arbace.core4,namev11,arbace.core9,volatile!v11,arbace.core4,map?v11,arbace.core4,run!v11,arbace.core4,valsv11,arbace.core7,vector?S4,R145,R146,R147,R148,R149,R150,v11,arbace.core7,vreset!v16,arbace.j2g.model12,benign-init?v16,arbace.j2g.decls16,touches-statics?v16,arbace.j2g.model16,superclass-chainv16,arbace.j2g.model7,static?i256,R151,V1,R4,R152,v16,arbace.j2g.decls17,method-code-formsR4,R77,R4,R77,R153,v11,arbace.core7,ex-datav11,arbace.core7,ex-infoR33,v16,arbace.j2g.names15,compiled-class?v13,arbace.string10,ends-with?v16,arbace.j2g.model12,start-class?R111,R111,v16,arbace.j2g.decls18,needs-entry-guard?R36,R111,R111,R77,R110,R4,R109,R110,R4,R109,R77,R36,v16,arbace.j2g.decls12,derived-bodyR4,R109,R154,R4,R4,R4,R155,R110,R4,R109,v16,arbace.j2g.model7,impl-ofV2,s8,toStrings20,()Ljava/lang/String;V2,s5,clones20,()Ljava/lang/Object;v16,arbace.j2g.decls12,class-fieldsR156,R110,R157,m2,R21,R125,R4,R123,R124,R4,R36,R110,R158,R109,R123,R127,R4,R36,R4,R110,R158,R109,R110,R159,R109,R4,R110,R160,m2,R21,R125,R4,R110,R161,m2,R21,R125,R34,R16,R162,R4,R163,R112,R16,R112,R16,R33,R4,v16,arbace.j2g.decls13,class-methodsR110,R4,R109,R33,v16,arbace.j2g.model26,abstract-method-error-textS2,R164,R156,v16,arbace.j2g.decls9,forwarderS2,R164,R156,v16,arbace.j2g.model8,vmethodsv11,arbace.core4,sortv16,arbace.j2g.model11,object-keysv18,arbace.classes.env11,const-valuev11,arbace.core5,some?v20,arbace.classes.types5,prim?i16,S2,s1,Fs1,Dv11,arbace.core5,char?v15,arbace.j2g.code9,float-litS2,s1,Fs1,Dv11,arbace.core7,string?R165,R166,R167,R167,R167,v16,arbace.j2g.decls13,field-go-typeS2,s1,Fs1,DS2,s1,Fs1,Dv11,arbace.core5,coll?v11,arbace.core1,+v16,arbace.j2g.decls8,calls-inv11,arbace.core8,not-any?S8,R168,R169,R36,R170,R59,R171,R172,R173,v11,arbace.core7,symbol?v11,arbace.core8,tree-seqv16,arbace.j2g.decls17,clinit-part-callsv16,arbace.j2g.decls11,splittable?v11,arbace.core4,peekR174,R175,v11,arbace.core3,popv11,arbace.core4,mapvR111,v20,arbace.classes.types10,lang-classR176,R177,R178,R179,R180,v20,arbace.classes.types9,lang-descR181,R182,R146,R183,R184,R33,R185,v16,arbace.j2g.model20,init-superinterfacesR186,v16,arbace.j2g.decls15,clj-const-storev16,arbace.j2g.decls12,split-clinitR111,R167,R111,R123,R187,R188,R189,R167,R109,R123,R130,R190,R191,R34,R192,R193,R194,R129,R191,R123,R194,R102,R190,R195,R193,R111,R191,R125,m2,R21,R196,v16,arbace.j2g.names13,compiled-pkg?R34,R190,R192,R197,R190,R129,R191,R123,R130,R187,R190,R127,R191,R191,R34,R192,R193,R194,R129,R191,R123,R194,R102,R190,R195,R193,R34,R190,R192,R197,R190,R129,R191,R111,R191,R125,R123,R124,R191,R36,R34,R198,R192,R198,R190,R129,R191,R123,R187,R190,R33,R191,R111,R191,R125,m2,R21,R196,R191,R34,R190,R192,R197,R190,R129,R191,R111,R191,R125,R123,R124,R191,R36,R34,R198,R192,R198,R190,R129,R191,R123,R187,R190,R33,R191,v16,arbace.j2g.model4,infoR199,R200,R201,v16,arbace.j2g.model8,private?v16,arbace.j2g.decls17,iface-method-elemv16,arbace.j2g.model11,abstract-m?R77,R111,v16,arbace.j2g.decls14,instance-formsR199,R200,R202,R203,R121,v16,arbace.j2g.decls17,super-struct-typev16,arbace.j2g.decls12,extra-fieldsR200,R201,v16,arbace.j2g.decls16,super-iface-typeR109,v16,arbace.j2g.model15,virtual-member?R110,R4,R109,R109,R4,v16,arbace.j2g.decls11,code-iface?R110,R4,R109,v16,arbace.j2g.decls7,markersR200,R201,v16,arbace.j2g.decls12,static-formsv16,arbace.j2g.decls16,clj-const-fieldsv16,arbace.j2g.decls10,init-formsv11,arbace.core6,mapcatv16,arbace.j2g.decls10,ctor-formsv16,arbace.j2g.decls12,method-formsv16,arbace.j2g.decls14,dispatch-formsv16,arbace.j2g.decls12,object-forms")

var Lit_1 *jrt.String = jrt.Intern("arbace.j2g.decls$at_line$fn__1464000074")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.decls$capture_field_name$fn__1464000036")

var Lit_3 *jrt.String = jrt.Intern("val$")

var Lit_4 *jrt.String = jrt.Intern("$")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.decls$capture_field_name$fn__1464000036$fn__1464000040")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$iter__1464000048__1464000052")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$fn__1464000058")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$fn__1464000058$iter__1464000060__1464000064")

var Lit_9 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$fn__1464000058$iter__1464000060__1464000064$fn__1464000065")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$fn__1464000058$iter__1464000060__1464000064$fn__1464000065$fn__1464000066")

var Lit_11 *jrt.String = jrt.Intern(".-")

var Lit_12 *jrt.String = jrt.Intern(".Self_")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$iter__1464000048__1464000052$fn__1464000053")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$iter__1464000048__1464000052$fn__1464000053$fn__1464000054")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields$iter__1464000093__1464000097")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields$iter__1464000093__1464000097$fn__1464000098")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields$iter__1464000093__1464000097$fn__1464000098$fn__1464000099")

var Lit_18 *jrt.String = jrt.Intern("---- ")

var Lit_19 *jrt.String = jrt.Intern("/")

var Lit_20 *jrt.String = jrt.Intern(".")

var Lit_21 *jrt.String = jrt.Intern("Object_I")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000665__1464000669")

var Lit_23 *jrt.String = jrt.Intern("Is_")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000675__1464000679")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000685__1464000689")

var Lit_26 *jrt.String = jrt.Intern("_I")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000695__1464000699")

var Lit_28 *jrt.String = jrt.Intern("Self_")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000705__1464000709")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000715__1464000719")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000725")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000727")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000729")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000731")

var Lit_35 *jrt.String = jrt.Intern("<init>")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000665__1464000669$fn__1464000670")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000665__1464000669$fn__1464000670$fn__1464000671")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000675__1464000679$fn__1464000680")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000675__1464000679$fn__1464000680$fn__1464000681")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000685__1464000689$fn__1464000690")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000685__1464000689$fn__1464000690$fn__1464000691")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000695__1464000699$fn__1464000700")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000695__1464000699$fn__1464000700$fn__1464000701")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000705__1464000709$fn__1464000710")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000705__1464000709$fn__1464000710$fn__1464000711")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000715__1464000719$fn__1464000720")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000715__1464000719$fn__1464000720$fn__1464000721")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods$iter__1464000104__1464000108")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods$iter__1464000104__1464000108$fn__1464000109")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods$iter__1464000104__1464000108$fn__1464000109$fn__1464000110")

var Lit_51 *jrt.String = jrt.Intern("<clinit>")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields$iter__1464000572__1464000576")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields$iter__1464000572__1464000576$fn__1464000577")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields$iter__1464000572__1464000576$fn__1464000577$fn__1464000578")

var Lit_55 *jrt.String = jrt.Intern("RT")

var Lit_56 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_store$strc__1464000538")

var Lit_58 *jrt.String = jrt.Intern("var")

var Lit_59 *jrt.String = jrt.Intern("(")

var Lit_60 *jrt.String = jrt.Intern(")")

var Lit_61 *jrt.String = jrt.Intern("Var")

var Lit_62 *jrt.String = jrt.Intern("readString")

var Lit_63 *jrt.String = jrt.Intern(")Ljava/lang/Object;")

var Lit_64 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_65 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$fn__1464000160")

var Lit_68 *jrt.String = jrt.Intern("constructor ")

var Lit_69 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_70 *jrt.String = jrt.Intern("V")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000165__1464000169")

var Lit_72 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_73 *jrt.String = jrt.Intern("superclass ")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$fn__1464000175")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000177__1464000181")

var Lit_76 *jrt.String = jrt.Intern("L")

var Lit_77 *jrt.String = jrt.Intern(";")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000190__1464000194")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000165__1464000169$fn__1464000170")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000165__1464000169$fn__1464000170$fn__1464000171")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000177__1464000181$fn__1464000182")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000177__1464000181$fn__1464000182$fn__1464000183")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000190__1464000194$fn__1464000195")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000159$iter__1464000190__1464000194$fn__1464000195$fn__1464000196")

var Lit_85 *jrt.String = jrt.Intern("this_0")

var Lit_86 *jrt.String = jrt.Intern("x0")

var Lit_87 *jrt.String = jrt.Intern("enumName")

var Lit_88 *jrt.String = jrt.Intern("enumOrdinal")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000206__1464000210")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000216__1464000220")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000226__1464000230")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000236")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000274__1464000278")

var Lit_94 *jrt.String = jrt.Intern("_Init")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000284")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000236$fn__1464000237")

var Lit_97 *jrt.String = jrt.Intern("NN")

var Lit_98 *jrt.String = jrt.Intern("J2g_NotNull")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000236$fn__1464000237$fn__1464000256")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000206__1464000210$fn__1464000211")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000206__1464000210$fn__1464000211$fn__1464000212")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000216__1464000220$fn__1464000221")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000216__1464000220$fn__1464000221$fn__1464000222")

var Lit_104 *jrt.String = jrt.Intern("a")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000226__1464000230$fn__1464000231")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000226__1464000230$fn__1464000231$fn__1464000232")

var Lit_107 *jrt.String = jrt.Intern("val_")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000274__1464000278$fn__1464000279")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000274__1464000278$fn__1464000279$fn__1464000280")

var Lit_110 *jrt.String = jrt.Intern("p")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$fn__1464000323")

var Lit_112 *jrt.String = jrt.Intern(".Impl_")

var Lit_113 *jrt.String = jrt.Intern("__VALUES")

var Lit_114 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_115 *jrt.String = jrt.Intern("_class")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$iter__1464000325__1464000329")

var Lit_117 *jrt.String = jrt.Intern("_Cast")

var Lit_118 *jrt.String = jrt.Intern("Enum_ValueOf_Class_String__Enum")

var Lit_119 *jrt.String = jrt.Intern("J2g_NotTranslated")

var Lit_120 *jrt.String = jrt.Intern("derived ")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$iter__1464000325__1464000329$fn__1464000330")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$iter__1464000325__1464000329$fn__1464000330$fn__1464000331")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000425__1464000429")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439")

var Lit_125 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000483__1464000487")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000425__1464000429$fn__1464000430")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000425__1464000429$fn__1464000430$fn__1464000431")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440$fn__1464000441")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440$iter__1464000471__1464000475")

var Lit_131 *jrt.String = jrt.Intern("AbstractMethodError_New_String")

var Lit_132 *jrt.String = jrt.Intern("Str")

var Lit_133 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440$fn__1464000441$iter__1464000451__1464000455")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440$fn__1464000441$iter__1464000451__1464000455$fn__1464000456")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440$fn__1464000441$iter__1464000451__1464000455$fn__1464000456$fn__1464000457")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440$iter__1464000471__1464000475$fn__1464000476")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000435__1464000439$fn__1464000440$iter__1464000471__1464000475$fn__1464000476$fn__1464000477")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000483__1464000487$fn__1464000488")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000483__1464000487$fn__1464000488$fn__1464000489")

var Lit_140 *jrt.String = jrt.Intern("j2g: unreachable")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields$iter__1464000121__1464000125")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields$iter__1464000121__1464000125$fn__1464000126")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields$iter__1464000121__1464000125$fn__1464000126$fn__1464000127")

var Lit_144 *jrt.String = jrt.Intern("B")

var Lit_145 *jrt.String = jrt.Intern("C")

var Lit_146 *jrt.String = jrt.Intern("D")

var Lit_147 *jrt.String = jrt.Intern("F")

var Lit_148 *jrt.String = jrt.Intern("I")

var Lit_149 *jrt.String = jrt.Intern("J")

var Lit_150 *jrt.String = jrt.Intern("S")

var Lit_151 *jrt.String = jrt.Intern("Z")

var Lit_152 *jrt.String = jrt.Intern("Volatile")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder$iter__1464000409__1464000413")

var Lit_154 *jrt.String = jrt.Intern("_")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder$iter__1464000409__1464000413$fn__1464000414")

var Lit_156 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder$iter__1464000409__1464000413$fn__1464000414$fn__1464000415")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers$iter__1464000142__1464000146")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers$iter__1464000142__1464000146$fn__1464000147")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers$iter__1464000142__1464000146$fn__1464000147$fn__1464000148")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.decls$iface_method_elem$fn__1464000135")

var Lit_161 *jrt.String = jrt.Intern("()V")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.decls$init_forms$fn__1464000545")

var Lit_163 *jrt.String = jrt.Intern("_init")

var Lit_164 *jrt.String = jrt.Intern("ClassInit")

var Lit_165 *jrt.String = jrt.Intern("_clinit")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.decls$init_forms$fn__1464000545$fn__1464000546")

var Lit_167 *jrt.String = jrt.Intern("StartCheck")

var Lit_168 *jrt.String = jrt.Intern(".<clinit>")

var Lit_169 *jrt.String = jrt.Intern("IsDynamic")

var Lit_170 *jrt.String = jrt.Intern("Dynamic")

var Lit_171 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_172 *jrt.String = jrt.Intern("ClassCast")

var Lit_173 *jrt.String = jrt.Intern("arbace/lang/GoValue")

var Lit_174 *jrt.String = jrt.Intern("IsGoValue")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.decls$interface_closure$fn__1464000139")

var Lit_176 *jrt.String = jrt.Intern("arbace.j2g.decls$markers$fn__1464000154")

var Lit_177 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$iter__1464000080__1464000084")

var Lit_178 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$fn__1464000090")

var Lit_179 *jrt.String = jrt.Intern("MonitorEnter")

var Lit_180 *jrt.String = jrt.Intern("MonitorExit")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$iter__1464000080__1464000084$fn__1464000085")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$iter__1464000080__1464000084$fn__1464000085$fn__1464000086")

var Lit_183 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000347__1464000351")

var Lit_184 *jrt.String = jrt.Intern("_native")

var Lit_185 *jrt.String = jrt.Intern("arbace/lang/GoInterp")

var Lit_186 *jrt.String = jrt.Intern("goi")

var Lit_187 *jrt.String = jrt.Intern("arbace/lang/CInterp")

var Lit_188 *jrt.String = jrt.Intern("cinterp")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000357__1464000361")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000367__1464000371")

var Lit_191 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000377")

var Lit_192 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000389__1464000393")

var Lit_193 *jrt.String = jrt.Intern("load")

var Lit_194 *jrt.String = jrt.Intern("__init")

var Lit_195 *jrt.String = jrt.Intern("_NoInit")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000399")

var Lit_197 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000377$iter__1464000378__1464000382")

var Lit_198 *jrt.String = jrt.Intern(": ")

var Lit_199 *jrt.String = jrt.Intern("j2g: translating ")

var Lit_200 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000377$iter__1464000378__1464000382$fn__1464000383")

var Lit_201 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000377$iter__1464000378__1464000382$fn__1464000383$fn__1464000384")

var Lit_202 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000347__1464000351$fn__1464000352")

var Lit_203 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000347__1464000351$fn__1464000352$fn__1464000353")

var Lit_204 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000357__1464000361$fn__1464000362")

var Lit_205 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000357__1464000361$fn__1464000362$fn__1464000363")

var Lit_206 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000367__1464000371$fn__1464000372")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000367__1464000371$fn__1464000372$fn__1464000373")

var Lit_208 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000389__1464000393$fn__1464000394")

var Lit_209 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000389__1464000393$fn__1464000394$fn__1464000395")

var Lit_210 *jrt.String = jrt.Intern("f")

var Lit_211 *jrt.String = jrt.Intern("Ljava/lang/Cloneable;")

var Lit_212 *jrt.String = jrt.Intern("arbace.j2g.decls$object_forms$fn__1464000422")

var Lit_213 *jrt.String = jrt.Intern("Class")

var Lit_214 *jrt.String = jrt.Intern("String")

var Lit_215 *jrt.String = jrt.Intern("Object_toString")

var Lit_216 *jrt.String = jrt.Intern("J2g_ObjectClone")

var Lit_217 *jrt.String = jrt.Intern("CloneNotSupported")

var Lit_218 *jrt.String = jrt.Intern("j2g$class")

var Lit_219 *jrt.String = jrt.Intern("arbace.j2g.decls$param_list$fn__1464000015")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$iter__1464000287__1464000291")

var Lit_221 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$js__1464000297")

var Lit_222 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fld__1464000299")

var Lit_223 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$hash__1464000301")

var Lit_224 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$strof__1464000304")

var Lit_225 *jrt.String = jrt.Intern("hashCode")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fn__1464000308")

var Lit_227 *jrt.String = jrt.Intern("toString")

var Lit_228 *jrt.String = jrt.Intern("")

var Lit_229 *jrt.String = jrt.Intern("[")

var Lit_230 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fn__1464000310")

var Lit_231 *jrt.String = jrt.Intern("]")

var Lit_232 *jrt.String = jrt.Intern("Concat")

var Lit_233 *jrt.String = jrt.Intern("equals")

var Lit_234 *jrt.String = jrt.Intern("GetClass")

var Lit_235 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fn__1464000312")

var Lit_236 *jrt.String = jrt.Intern("=")

var Lit_237 *jrt.String = jrt.Intern(", ")

var Lit_238 *jrt.String = jrt.Intern("J2g_DoubleBits")

var Lit_239 *jrt.String = jrt.Intern("J2g_FloatBits")

var Lit_240 *jrt.String = jrt.Intern("J2g_ObjEquals")

var Lit_241 *jrt.String = jrt.Intern("J2g_BoolHash")

var Lit_242 *jrt.String = jrt.Intern("J2g_ObjHash")

var Lit_243 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$iter__1464000287__1464000291$fn__1464000292")

var Lit_244 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$iter__1464000287__1464000291$fn__1464000292$fn__1464000293")

var Lit_245 *jrt.String = jrt.Intern("StrOfInt")

var Lit_246 *jrt.String = jrt.Intern("StrOfChar")

var Lit_247 *jrt.String = jrt.Intern("StrOfDouble")

var Lit_248 *jrt.String = jrt.Intern("StrOfFloat")

var Lit_249 *jrt.String = jrt.Intern("StrOfLong")

var Lit_250 *jrt.String = jrt.Intern("StrOfBool")

var Lit_251 *jrt.String = jrt.Intern("StrOfObj")

var Lit_252 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000594__1464000598")

var Lit_253 *jrt.String = jrt.Intern(" (declared from reflection)")

var Lit_254 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000604__1464000608")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000614__1464000618")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000594__1464000598$fn__1464000599")

var Lit_258 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000594__1464000598$fn__1464000599$fn__1464000600")

var Lit_259 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000604__1464000608$fn__1464000609")

var Lit_260 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000604__1464000608$fn__1464000609$fn__1464000610")

var Lit_261 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000614__1464000618$fn__1464000619")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000614__1464000618$fn__1464000619$fn__1464000620")

var Lit_263 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629$fn__1464000630")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629$iter__1464000648__1464000652")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629$fn__1464000630$iter__1464000634__1464000638")

var Lit_267 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629$fn__1464000630$iter__1464000634__1464000638$fn__1464000639")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629$fn__1464000630$iter__1464000634__1464000638$fn__1464000639$fn__1464000640")

var Lit_269 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629$iter__1464000648__1464000652$fn__1464000653")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000624__1464000628$fn__1464000629$iter__1464000648__1464000652$fn__1464000653$fn__1464000654")

var Lit_271 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$fn__1464000517")

var Lit_272 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$iter__1464000519__1464000523")

var Lit_273 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$fn__1464000530")

var Lit_274 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$iter__1464000519__1464000523$fn__1464000524")

var Lit_275 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$iter__1464000519__1464000523$fn__1464000524$fn__1464000525")

var Lit_276 *jrt.String = jrt.Intern("_clinit_p")

var Lit_277 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000494__1464000498")

var Lit_278 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000494__1464000498$fn__1464000499")

var Lit_279 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000494__1464000498$fn__1464000499$fn__1464000500")

var Lit_280 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000494__1464000498$fn__1464000499$fn__1464000508")

var Lit_281 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000494__1464000498$fn__1464000499$fn__1464000510")

var Lit_282 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000494__1464000498$fn__1464000499$fn__1464000500$fn__1464000502")

var Lit_283 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000494__1464000498$fn__1464000499$fn__1464000500$fn__1464000504")

var Lit_284 *jrt.String = jrt.Intern("Object")

var Lit_285 *jrt.String = jrt.Intern("arbace.j2g.decls$touches_statics_QMARK_$w__1464000336")

var Lit_286 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn3,symyn4,typeyn5,flagsyn1,fyn3,pkgyn1,dyn5,descsyn4,symsyn1,ryn1,vyn1,nyn1,&kn2,asyn4,moreyn5,formsyn11,has-resultsyn4,nameyn4,descyn1,byn4,tsymyn7,outer-pyn1,myn2,abkn4,keysyn1,tyn4,thisyn6,staticyn2,mmyn5,superyn4,infoyn2,psyn7,classesyn1,kyn4,implyn4,bodyyn1,gyn4,initv11,arbace.core5,in-nsMyn16,arbace.j2g.declsm2,R0,s410,j2g's declarations (J2G-SPEC §4.5, §5, §6, §7.11-§7.13): what a translated class becomes in\n  Go forms: its struct or interface, class interface C_I and accessor Self_C (non-leaf\n  classes), markers, method implementations, dispatch methods and forwarders, constructors,\n  statics and lazy class initialization, the Object protocol, instanceof and cast, and its\n  registration with member tables (j2g_classes).m2,R0,s410,j2g's declarations (J2G-SPEC §4.5, §5, §6, §7.11-§7.13): what a translated class becomes in\n  Go forms: its struct or interface, class interface C_I and accessor Self_C (non-leaf\n  classes), markers, method implementations, dispatch methods and forwarders, constructors,\n  statics and lazy class initialization, the Object protocol, instanceof and cast, and its\n  registration with member tables (j2g_classes).R1,v16,arbace.j2g.decls9,*reached*m10,R2,TR3,i17,R4,i1,R5,s19,arbace/j2g/decls.aeR0,s49,The set of reached method keys [class name desc].v16,arbace.j2g.decls3,tagm10,R6,TR7,L1,V2,R8,R9,R3,i19,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls4,has?m10,R6,TR7,L1,V2,R10,R11,R3,i21,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls2,gtm8,R7,L1,V2,R12,R13,R3,i23,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,param-listm12,R6,TR7,L1,V3,R12,R14,R15,R0,s105,Go parameter symbols tagged with the Go types of descs, named after the analyzer's\n  bindings when given.R3,i25,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,result-metam10,R6,TR7,L1,V2,R12,R16,R3,i31,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls8,with-retm10,R6,TR7,L1,V3,R17,R12,R16,R3,i33,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,new-fn-statem8,R7,L1,V4,R12,R18,R19,m2,R20,R21,R3,i35,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,terminating?m10,R7,L1,V1,R11,R0,s164,Is Go form f a terminating statement (Go spec, \"Terminating statements\"): a return or\n  panic, a block (let, do) ending in one, an if whose two branches end in one?R3,i42,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,ensure-terminatedm10,R7,L1,V2,R22,R23,R0,s107,Go needs a terminating statement in a function with results: a final panic when the last\n  form is not one.R3,i53,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls9,stub-bodym8,R7,L1,V3,R18,R24,R25,R3,i61,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls18,capture-field-namem12,R6,TR7,L1,V2,R18,R26,R0,s262,The name of the field of local or anonymous class n holding captured local b: val$x, a $\n  appended while the class declares a field of that name (as arbace.classes.analyze/\n  capture-field-name; here too, since j2g may run on a host whose analysis predates it).R3,i65,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls15,captured-fieldsm12,R6,TR7,L1,V4,R18,R27,R19,V1,R28,R0,s125,binding id -> Go form reading the captured local from the class's field (local and\n  anonymous classes), for code of class n.R3,i84,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,member-linem10,R7,L1,V1,R29,R0,s75,The Java forms line of method or constructor m (its member form's), or nil.R3,i112,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls7,at-linem12,R6,TR7,L1,V2,R29,R22,R0,s60,Declaration forms with the line of member m (J2G-SPEC §4.3).R3,i117,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,method-code-formsm12,R6,TR7,L1,V5,R12,R18,R29,R30,m2,R31,V3,R32,R33,R34,R0,s67,The Go statements of method m's body (analyzed body ab) of class n.R3,i124,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,class-fieldsm8,R7,L1,V1,R18,R3,i150,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls13,class-methodsm10,R7,L1,V1,R18,R0,s78,The methods of translated class n that exist in Go (descriptors in the world).R3,i155,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls7,body-ofm10,R6,TR7,L1,V2,R18,R35,R3,i165,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls8,reached?m8,R7,L1,V2,R18,R35,R3,i167,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,code-class?v16,arbace.j2g.model11,code-class?m6,R3,i172,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,code-iface?v16,arbace.j2g.model11,code-iface?m6,R3,i174,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,super-struct-typem10,R7,L1,V2,R12,R18,R0,s84,The Go struct type a class embeds: its superclass's struct (jrt.Object at the root).R3,i176,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls16,super-iface-typem8,R7,L1,V2,R12,R18,R3,i184,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls13,field-go-typem10,R7,L1,V2,R12,R11,R0,s57,The Go type of a field, atomic for a volatile one (§8.2).R3,i190,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,extra-fieldsm12,R6,TR7,L1,V2,R12,R18,R0,s85,The outer instance and captured locals' fields of an inner, local or anonymous class.R3,i203,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,iface-method-elemm8,R7,L1,V2,R12,R35,R3,i214,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,interface-closurem10,R7,L1,V1,R18,R0,s103,The interfaces a class or interface n implements (directly and through its supertypes),\n  in the world.R3,i219,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,hw-markersm10,R7,L1,V1,R36,R0,s66,The Is_ markers jrt's hand-written struct (and its ancestors) has.R3,i225,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls7,markersm10,R7,L1,V1,R18,R0,s109,The interfaces whose marker class n's struct declares: those not already marked by its\n  superclass's struct.R3,i231,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls9,ctor-descm8,R7,L1,V2,R18,R35,R3,i244,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls20,ctor-call-translatorm12,R6,TR7,L1,V3,R12,R18,R37,R0,s159,Translates the constructor call node of a constructor of class n (super. or this.):\n  the superclass's or this class's constructor body on the embedded struct.R3,i246,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,ctor-formsm10,R7,L1,V3,R12,R18,R35,R0,s118,The allocation function C_New_... (concrete classes) and the constructor body Ctor_... of\n  constructor mm of class n.R3,i310,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls18,record-object-bodym12,R6,TR7,L1,V4,R12,R18,R35,R38,R0,s257,A record's derived toString, hashCode or equals, as java.lang.runtime.ObjectMethods makes\n  them: Name[c=v, ...]; 31 * h + the component's hash, in order; the same class and equal\n  components (wrapper compare for primitives, Objects.equals for references).R3,i404,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,derived-bodym10,R7,L1,V4,R12,R18,R35,R38,R0,s245,Go statements of a derived method (enum values/valueOf/$values, bridges, record members).\n  The code's names are qualified as package pkg sees them (a bridge's casts in arbace/lang name\n  jrt's classes: the suite's Java fixtures, ConcreteClass).R3,i474,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls16,touches-statics?m12,R6,TR7,L1,V2,R30,R39,R0,s147,Does analyzed code ab access a static field of a class in classes (directly: the guarded\n  accesses of other classes run their own initialization)?R3,i520,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls18,needs-entry-guard?m10,R7,L1,V2,R18,R30,R0,s360,Does static method mm of class n (body ab) start with n's initialization guard (§6.2)? Not\n  when the initialization is benign (unobservable but through n's statics, model/benign-init?)\n  and the body reads none of the statics of n and its superclasses: then delaying the\n  initialization to the first guarded access cannot be told apart (J2G-NOTES, phase 2D).R3,i539,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,method-formsm10,R7,L1,V3,R12,R18,R35,R0,s113,The Go method (instance) or function (static) of method mm of class n: its body when\n  reached, a stub otherwise.R3,i550,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls9,forwarderm12,R6,TR7,L1,V4,R12,R18,V4,R24,R25,R20,R40,R41,R0,s85,A dispatch method of concrete class n for virtual method k: calls the implementation.R3,i637,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,object-formsm10,R7,L1,V2,R12,R18,R0,s90,Ref, GetClass__Class, ToString__String, Clone__O, CloneShallow of concrete class n (§5.8).R3,i652,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls14,dispatch-formsm10,R7,L1,V2,R12,R18,R0,s63,The dispatch methods and forwarders of concrete class n (§5.4).R3,i682,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,static-formsm8,R7,L1,V2,R12,R18,R3,i709,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,clinit-part-callsl48,m8,R3,i730,R4,i1,R5,s19,arbace/j2g/decls.aeR0,s75,The calls a part of a long static initializer holds at most (split-clinit).v16,arbace.j2g.decls8,calls-inm12,R6,TR7,L1,V1,R11,R0,s31,The calls (lists) in Go form f.R3,i734,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,splittable?m12,R6,TR7,L1,V1,R42,R0,s177,Can the statements of body run as consecutive functions of their own? Not when one leaves\n  the function or the block (return, goto, defer, a label's break), whatever its depth.R3,i739,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,split-clinitm10,R7,L1,V2,R43,R42,R0,s560,A long static initializer's statements (body) in parts of at most clinit-part-calls calls,\n  each the body of a function of its own, the initializer calling them in order: [calls parts]\n  (amendment SA153). gc's stack maps of one function are about its safepoints times its stack\n  slots, so a class's thousands of constants in one function made megabytes of them (and most\n  of gc's time); in parts they grow with the code. A statement declaring locals (a let) holds\n  the rest of the block, so it ends the last part; a body that may leave early is not split.R3,i746,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls15,clj-const-storem12,R6,TR7,L1,V2,R18,m4,R31,V2,R25,R44,R20,R11,R0,s214,The static initializer's store of Clojure constant f ({:name :desc :init}) of class n:\n  RT.var(ns, name) for a var, RT.readString(text) for a datum (a keyword, a symbol or quoted\n  data), cast to the field's type.R3,i768,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,init-formsm10,R7,L1,V2,R12,R18,R0,s78,C_init, C_Init and C_clinit of a class with non-trivial initialization (§6.2).R3,i787,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls16,clj-const-fieldsm8,R7,L1,V2,R12,R18,R3,i825,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls14,instance-formsm10,R7,L1,V2,R12,R18,R0,s31,C_InstanceOf and C_Cast (§5.7).R3,i832,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls15,reflected-formsm10,R7,L1,V1,R18,R0,s194,A JDK interface declared from reflection (no Java forms): its Go interface with the\n  methods in the world, its default and static methods as stubs (no code to translate), and\n  instanceof/cast.R3,i877,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,class-formsm10,R7,L1,V1,R18,R0,s62,All Go forms of translated class n (in package pkg), in order.R3,i908,R4,i1,R5,s19,arbace/j2g/decls.ae")

var Lit_287 *jrt.String = jrt.Intern("arbace.j2g.decls$eval1464000004$loading__1927001464__auto____1464000005")

var Lit_288 *jrt.String = jrt.Intern("arbace.j2g.decls$eval1464000008$fn__1464000009")

var Lit_289 *jrt.String = jrt.Intern("arbace.j2g.decls$tag")

var Lit_290 *jrt.String = jrt.Intern("arbace.j2g.decls$has_QMARK_")

var Lit_291 *jrt.String = jrt.Intern("arbace.j2g.decls$gt")

var Lit_292 *jrt.String = jrt.Intern("arbace.j2g.decls$param_list")

var Lit_293 *jrt.String = jrt.Intern("arbace.j2g.decls$result_meta")

var Lit_294 *jrt.String = jrt.Intern("arbace.j2g.decls$with_ret")

var Lit_295 *jrt.String = jrt.Intern("arbace.j2g.decls$new_fn_state")

var Lit_296 *jrt.String = jrt.Intern("arbace.j2g.decls$terminating_QMARK_")

var Lit_297 *jrt.String = jrt.Intern("arbace.j2g.decls$ensure_terminated")

var Lit_298 *jrt.String = jrt.Intern("arbace.j2g.decls$stub_body")

var Lit_299 *jrt.String = jrt.Intern("arbace.j2g.decls$capture_field_name")

var Lit_300 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields")

var Lit_301 *jrt.String = jrt.Intern("arbace.j2g.decls$member_line")

var Lit_302 *jrt.String = jrt.Intern("arbace.j2g.decls$at_line")

var Lit_303 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms")

var Lit_304 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields")

var Lit_305 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods")

var Lit_306 *jrt.String = jrt.Intern("arbace.j2g.decls$body_of")

var Lit_307 *jrt.String = jrt.Intern("arbace.j2g.decls$reached_QMARK_")

var Lit_308 *jrt.String = jrt.Intern("arbace.j2g.decls$super_struct_type")

var Lit_309 *jrt.String = jrt.Intern("arbace.j2g.decls$super_iface_type")

var Lit_310 *jrt.String = jrt.Intern("arbace.j2g.decls$field_go_type")

var Lit_311 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields")

var Lit_312 *jrt.String = jrt.Intern("arbace.j2g.decls$iface_method_elem")

var Lit_313 *jrt.String = jrt.Intern("arbace.j2g.decls$interface_closure")

var Lit_314 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers")

var Lit_315 *jrt.String = jrt.Intern("arbace.j2g.decls$markers")

var Lit_316 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_desc")

var Lit_317 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator")

var Lit_318 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms")

var Lit_319 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body")

var Lit_320 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body")

var Lit_321 *jrt.String = jrt.Intern("arbace.j2g.decls$touches_statics_QMARK_")

var Lit_322 *jrt.String = jrt.Intern("arbace.j2g.decls$needs_entry_guard_QMARK_")

var Lit_323 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms")

var Lit_324 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder")

var Lit_325 *jrt.String = jrt.Intern("arbace.j2g.decls$object_forms")

var Lit_326 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms")

var Lit_327 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms")

var Lit_328 *jrt.String = jrt.Intern("arbace.j2g.decls$calls_in")

var Lit_329 *jrt.String = jrt.Intern("arbace.j2g.decls$splittable_QMARK_")

var Lit_330 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit")

var Lit_331 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_store")

var Lit_332 *jrt.String = jrt.Intern("arbace.j2g.decls$init_forms")

var Lit_333 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields")

var Lit_334 *jrt.String = jrt.Intern("arbace.j2g.decls$instance_forms")

var Lit_335 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms")

var Lit_336 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms")
